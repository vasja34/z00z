---
post_title: "Scenario 1 Crypto Architect Report"
author1: "GitHub Copilot"
post_slug: "scenario-1-crypto-architect-report"
microsoft_alias: "n-a"
featured_image: ""
categories:
  - "internal"
tags:
  - "cryptography"
  - "simulator"
  - "review"
  - "scenario_1"
ai_note: "AI-assisted review prepared by GitHub Copilot (GPT-5.4)."
summary: "Cryptographic architecture review of scenario_1 covering threat model, proof semantics, claim soundness, secret lifecycle, checkpoint integrity, and simulator-only misuse risks."
post_date: "2026-03-26"
---

# Scenario 1 Crypto Architect Report

## Review Scope

**Executive verdict:** `Fundamentally broken`

**Final decision:** `Blocked: placeholder claim proof and authority signature, non-authoritative genesis root, checkpoint proof and spent-set stubs, and secret-dump behavior must be resolved before this flow can be treated as cryptographically trustworthy.`

**Input type and scope:** mixed implementation review of Rust source code under `crates/z00z_simulator/src/scenario_1`, with supporting verifier and proof code in `crates/z00z_crypto` and `crates/z00z_wallets` where the scenario depends on them.

This review treats `scenario_1` as a cryptographic workflow, not just a simulator demo, because it constructs claim statements, range proofs, nullifiers, checkpoint artifacts, wallet secrets, and verifier inputs that are accepted by adjacent crates.

## Security Model

**Security goals extracted from code:** claim authenticity, claim soundness, chain binding, nullifier uniqueness, committed-state integrity, wallet secret confidentiality, stealth ownership privacy, crash-safe replay resistance, and deterministic restart safety for simulator checkpoints.

**Assets at risk:** wallet passwords, seed phrases, receiver secrets, claim source commitments, nullifiers, claim statements, checkpoint drafts, spent-set state, post-transaction committed outputs, and any asset balance reachable through scenario-generated claim packages.

**Adversaries considered:** malicious claimant, malicious simulator operator, local filesystem reader, accidental artifact publisher, rollback attacker replaying scenario artifacts, and concurrent execution races across wallet service initialization and environment mutation.

**Trust boundaries extracted from code:** `scenario_1` orchestration, wallet RPC transport, filesystem artifact store, checkpoint store, `z00z_wallets` claim verifier, and `z00z_crypto::claim` placeholder proof/signature logic.

**Failure assumptions extracted from code:** simulator restarts, malformed artifacts, replayed checkpoint inputs, weak deterministic entropy, proof generation failure, concurrent task interleaving, and manual inspection of exported artifacts.

**Threat-model assessment:** usable but incomplete. The code reveals an implicit threat model for simulator happy-path validation, but it does not clearly state what guarantees are intentionally missing. Confidence is therefore reduced whenever simulator placeholders are accepted by verifiers outside a strictly isolated test boundary.

**Confidence:** medium for scope extraction, because the code clearly exposes goals and boundaries, but there is no explicit threat model document defining which cryptographic guarantees are intentionally out of scope.

## Critical And High Findings

| Severity | Component | Problem | Impact | Exploit path | Fix |
| --- | --- | --- | --- | --- | --- |
| S0 | `crates/z00z_crypto/src/claim/prover.rs`, `crates/z00z_crypto/src/claim/verifier.rs`, `crates/z00z_simulator/src/scenario_1/stage_3.rs` | `prove_genesis_claim` and `verify_genesis_claim` implement a deterministic placeholder digest over the public statement, not a proof tied to a secret witness. `ClaimAuthoritySig::from_statement` is likewise forgeable from public data. | Any party able to assemble a statement can generate a passing proof and authority signature without possessing secret authority material or a real witness. This is direct proof forgery and invalid authorization. | Build any desired `GenesisClaimStatement`, derive `proof_bytes(statement_hash)` and `sig_bytes(statement_hash)`, then submit through the normal claim verifier path. | Replace the placeholder claim proof and signature with a real authorization model. At minimum, require a real signing key for claim authority and an authenticated genesis-membership witness. If the design remains temporary, isolate it behind a verifier mode that cannot be enabled outside simulator tests. |
| S0 | `crates/z00z_simulator/src/scenario_1/stage_3.rs`, `crates/z00z_wallets/src/core/tx/claim_tx.rs` | The claim statement binds `genesis_root` to `ZERO_ROOT`, and wallet verification explicitly documents it as a transitional non-authoritative root. | Claim soundness is broken because the verifier does not authenticate the claimed source against a real genesis commitment set. A forged or arbitrary source commitment can be represented as if it came from genesis. | Construct a claim package for an arbitrary source commitment and asset id, then rely on the placeholder proof and zero-root statement binding to satisfy verification. | Bind claim statements to a real authenticated genesis root or equivalent commitment root, and require verifier-side membership validation against that root before any claim is accepted. |
| S1 | `crates/z00z_simulator/src/scenario_1/stage_6.rs`, `crates/z00z_simulator/src/scenario_1/stage_7.rs` | Checkpoint construction uses `PassProof` and `NoSpent` placeholders when building the checkpoint draft. | The checkpoint pipeline can accept state transitions without a real proof check or spent-set validation, undermining double-spend resistance and state integrity in the simulator's finalization flow. | Feed duplicate or invalid fragment inputs into the checkpoint flow and rely on the stubbed verifier path to produce a valid-looking draft and follow-on artifact chain. | Replace placeholders with the real proof verifier and real spent-index checks, or make the draft builder refuse execution unless an explicit simulator-only test mode is proven impossible to ship. |
| S1 | `crates/z00z_simulator/src/scenario_1/stage_2_utils/artifacts.rs`, `crates/z00z_simulator/src/scenario_1/stage_2_utils/flow.rs`, `crates/z00z_simulator/src/scenario_1/stage_3_utils/post_claim.rs` | Scenario artifacts store passwords, seed phrases, and receiver secrets in plaintext, including a Markdown dump and long-lived `String` fields. | Anyone with filesystem access, CI artifact access, or accidental repository exposure can recover wallet material and fully compromise scenario wallets. | Run the scenario with debug export enabled, read the generated secrets artifact, unlock or import wallets, and spend funds or decrypt owned outputs. | Remove plaintext secret dumps from the default workflow. Use `Hidden<T>` or `SecretBytes` wrappers, zeroizing containers, and explicit one-shot encrypted export flows only. If debug export is unavoidable, gate it behind a separate test-only binary and write to a guaranteed throwaway location with loud runtime confirmation. |

These are structural findings, not style concerns. The first two are enough on their own to block any claim that the scenario exercises a sound claim protocol.

**Confidence:** high for all four findings. The relevant code paths are direct, short, and unambiguous.

## Medium And Low Findings

| Severity | Component | Problem | Impact | Exploit path | Fix |
| --- | --- | --- | --- | --- | --- |
| S2 | `crates/z00z_simulator/src/scenario_1/stage_2_utils/transport.rs` | `SeqSecureRngProvider` derives seeds by XORing a fixed seed with a counter-based mixer, then feeds them into `StdRng`. | This is not a cryptographically defensible randomness construction for key material or unlinkability-sensitive flows, even if labeled simulator-only. The pattern is likely to be copied. | Predict future RNG streams from the small seed and public counter schedule, then reproduce ephemeral choices across runs. | Delete the custom RNG wrapper. Use `MockRngProvider` for deterministic tests and `CryptoRng`-backed sources for any key or stealth output generation. |
| S2 | `crates/z00z_simulator/src/scenario_1/stage_2_utils/actors.rs` | Actor passwords and mock seeds are fixed, human-readable, and low entropy. | The scenario normalizes weak credential habits and makes exported artifacts trivially reusable by anyone who knows the defaults. | Read default actor names, derive matching passwords from source, unlock exported wallets, and recover state. | Generate per-run test credentials, or derive them from a single test seed with a KDF and role-separated labels. |
| S2 | `crates/z00z_simulator/src/scenario_1/stage_2_utils/flow.rs` | `std::env::set_var` mutates global wallet network and chain settings during runtime assembly. | Concurrent scenario execution can cross-contaminate wallet configuration and silently misbind artifacts to the wrong chain or network context. | Run multiple scenario flows in the same process or runtime, interleave initialization, and observe configuration bleed-through. | Pass network and chain settings through explicit configuration objects instead of process-global environment mutation. |
| S3 | `crates/z00z_simulator/src/scenario_1/stage_2_utils/artifacts.rs` | Sensitive values live in ordinary `String` fields without zeroization. | Secret exposure surface is larger than necessary and survives longer in heap memory. | Memory dump, panic dump, or later debug logging can reveal material that should have been erased after use. | Replace with zeroizing secret wrappers and avoid cloning or formatting secrets. |
| S3 | `crates/z00z_simulator/src/scenario_1/Readme.md` | The scenario is described as a happy-path baseline without a prominent disclaimer that claim proof and authority semantics are placeholders. | Readers may over-trust the scenario and propagate broken constructions into adjacent code or docs. | Developers use the simulator as a reference implementation rather than a test harness. | Add an explicit cryptography status section listing placeholder components and banned reuse surfaces. |
| S4 | `crates/z00z_simulator/src/scenario_1/stage_7.rs`, `crates/z00z_simulator/src/scenario_1/jmt_wallet_scan.rs` | Several parts of the pipeline are otherwise disciplined: proof validation precedes ownership detection, state transitions are checkpointed, and report artifacts are emitted consistently. | This reduces operational ambiguity but does not compensate for the structural proof and root-binding failures. | None. | Preserve this sequencing while replacing placeholder crypto. |

Positive observations worth preserving after remediation:

- BLAKE3 domain separation for claim output leaf hashes and owner-binding hashes is explicit and distinct.
- Nullifier derivation is chain-bound in the scenario flow instead of being a bare claim identifier.
- Range-proof generation for claim outputs is tied to the derived blinding value rather than an obvious dummy scalar.
- Post-transaction JMT scanning validates proof data before ownership checks, which is the right direction for avoiding semantic false positives.

**Confidence:** high for the S2 findings, medium-high for the S3/S4 observations.

## Open Ambiguities

The following questions prevent stronger positive conclusions even after reading the full scenario module:

1. Who owns the long-term authority key that should authorize genesis claims, and where is that trust anchor anchored in chain state or configuration?
2. Is `scenario_1` expected to remain permanently simulator-only, or is it a migration path toward a production claim flow?
3. What exact spent-set invariant should `stage_6` enforce, and which storage component is the intended source of truth for it?
4. What are the maximum allowed amounts and asset classes for the stage-3 range-proof statements, and are those limits consensus-bound anywhere outside the simulator?
5. Is there an approved artifact-handling policy for `wallet_debug_dump`, including retention, cleanup, CI publishing, and accidental commit prevention?

**Confidence:** high that these are real blockers, because each ambiguity maps to a missing trust anchor or enforcement rule.

## Concrete Fixes

**Fix set A: replace placeholder claim authorization.**

1. Introduce a real genesis claim authority keypair and bind its public key in configuration or chain state.
2. Sign the canonical claim statement with a real signature scheme already present in `z00z_crypto`, not a statement-hash wrapper.
3. Make the verifier reject any placeholder mode unless compiled into an isolated simulator-only test target.

**Fix set B: authenticate genesis membership.**

1. Replace `ZERO_ROOT` with a real genesis commitment root.
2. Add membership witnesses or authenticated inclusion data for the source asset.
3. Ensure the claim statement binds asset id, source commitment, chain id, scenario or ruleset version, and the authenticated genesis root.

**Fix set C: remove checkpoint integrity placeholders.**

1. Replace `PassProof` with the real proof validation result used by storage finalization.
2. Replace `NoSpent` with an actual spent-set lookup against the checkpoint source of truth.
3. Add a fail-closed path so draft creation aborts if either proof validation or spent-set validation is unavailable.

**Fix set D: harden secret lifecycle.**

1. Delete plaintext secret Markdown export from the default path.
2. Use `Hidden<T>`, `SecretBytes`, or equivalent zeroizing wrappers for passwords, seed phrases, and receiver secrets.
3. Keep any debug export behind a separate feature and separate executable with runtime confirmation, artifact cleanup, and explicit non-production labeling.

**Fix set E: fix simulator randomness and configuration handling.**

1. Remove `SeqSecureRngProvider` and use existing deterministic test RNG abstractions already provided by the workspace.
2. Derive actor credentials from a scenario seed plus domain-separated labels instead of hard-coded literals.
3. Stop mutating process-global environment variables during runtime assembly.

**Confidence:** high that these changes address the identified issues without requiring vendor edits under `z00z_crypto/tari/`.

## Implementation Guidance

A minimally safe architecture for this scenario is:

1. Treat `scenario_1` as a harness around real verifier components, never as the place where proof semantics are weakened.
2. Keep proof generation and proof verification in `z00z_crypto` and `z00z_wallets`, but make simulator code supply only authenticated inputs, fixtures, and deterministic test configuration.
3. Make the source of truth for nullifier uniqueness and spent-set checks live in storage code, not scenario glue.
4. Keep domain separation explicit and versioned for every hash, proof transcript, KDF label, and authorization message.
5. Use canonical serialization before every signed or hashed statement and make the verifier reject any ambiguous encoding.

Recommended crate and primitive direction:

- Reuse existing Tari-backed signing and commitment primitives already exposed via `z00z_crypto`.
- Use Merlin-style transcript binding if the claim proof evolves beyond the current placeholder API.
- Keep `z00z_utils` as the only layer for filesystem and serialization concerns.

**Confidence:** medium-high. The structural direction is clear, but the exact claim-membership witness format still needs an owner decision.

## Test Plan

**Positive tests:**

1. Valid genesis claim with real authenticated root and authority signature passes end-to-end.
2. Valid restart after stage-3 or stage-6 resume points reproduces identical accepted state.
3. Charlie and Bob receive only outputs that they can actually decrypt after proof verification.

**Negative and misuse tests:**

1. Forged claim statement with arbitrary source commitment must fail because membership proof does not verify.
2. Forged authority signature must fail with a typed authorization error.
3. Replayed nullifier or duplicate spent input must fail before checkpoint draft creation.
4. Wrong chain id, wrong ruleset version, or wrong authenticated root must fail verifier binding checks.
5. Any attempt to enable placeholder proof mode in non-test builds must fail compilation or startup.

**Property and adversarial tests:**

1. Property-test canonical serialization and statement hashing for round-trip stability.
2. Fuzz claim package decoders, checkpoint artifact loaders, and resume-state files.
3. Test concurrent scenario execution to ensure network and chain configuration cannot bleed across runs.
4. Add artifact hygiene tests confirming that debug secret files are never produced in default runs.

**Dependency and primitive checks:**

1. Run `cargo audit` and `cargo deny` for crypto-relevant crates.
2. Add negative tests around range-proof parameter mismatches and malformed proof bytes.
3. If standard primitive wrappers are added, include Wycheproof coverage where applicable for signatures and ECDH-related flows.

**Confidence:** high that this test plan would expose regressions in the areas reviewed.

## Section Confidence Summary

| Section | Confidence | What would raise confidence |
| --- | --- | --- |
| Threat model extraction | Medium | An explicit scenario threat model and statement of simulator-only exclusions |
| Placeholder proof and signature finding | High | No additional evidence needed; the code is conclusive |
| Zero-root claim soundness finding | High | A verifier-side authenticated membership check that is not currently present |
| Checkpoint placeholder finding | High | Proof that `PassProof` and `NoSpent` are unreachable in all accepted flows |
| Secret lifecycle finding | High | Removal of plaintext exports and zeroizing secret containers |
| RNG and config hygiene findings | High | Replacement with explicit deterministic test RNG and non-global config plumbing |

## Final Decision

`Blocked:`

- Owner: `scenario_1` maintainers must remove placeholder claim proof and placeholder authority signature semantics.
- Owner: claim-verifier owners must bind claims to a real authenticated genesis root and membership witness.
- Owner: checkpoint pipeline owners must replace `PassProof` and `NoSpent` with real enforcement.
- Owner: simulator and wallet-debug owners must remove or quarantine plaintext secret artifacts.

Until these items are resolved, `scenario_1` can serve as a functional smoke harness, but it must not be treated as evidence of cryptographic correctness.
