# 041 Full Threats Audit

<!-- markdownlint-disable MD047 -->

Scope: phase 041 spend-proof and adjacent claim, digest, and verifier surfaces. This audit keeps only scenarios that survived a pros and cons filter and could matter at CRITICAL, HIGH, or MEDIUM severity. Trivial malformed-input cases, already-covered reject cases, and replay-only helpers are intentionally excluded.

## Filtered-Out Candidates

- Range-proof RNG reuse was not promoted because create_range_proof_rng is explicitly scoped to replayable output and simulation flows in [crates/z00z_crypto/src/lib_api.rs](../../../crates/z00z_crypto/src/lib_api.rs#L35) and [crates/z00z_wallets/src/core/stealth/output.rs](../../../crates/z00z_wallets/src/core/stealth/output.rs#L171).
- Claim leaf zip truncation was not promoted because verify_out_leaf requires every output leaf before verify_owner_attest runs in [crates/z00z_wallets/src/core/tx/claim_tx_verifier_impl.rs](../../../crates/z00z_wallets/src/core/tx/claim_tx_verifier_impl.rs#L180) and [crates/z00z_wallets/src/core/tx/claim_tx_verifier_impl_proof.rs](../../../crates/z00z_wallets/src/core/tx/claim_tx_verifier_impl_proof.rs#L2).
- Claim source synthetic-root bypass was not promoted for production because the simulator consumer rebinds claim packages to the persisted store contract in [crates/z00z_simulator/src/claim_pkg_consumer.rs](../../../crates/z00z_simulator/src/claim_pkg_consumer.rs#L210) and [crates/z00z_simulator/src/claim_pkg_consumer.rs](../../../crates/z00z_simulator/src/claim_pkg_consumer.rs#L278).

### ==CRITICAL - Final tx admission can be bypassed at the local verifier layer==

Attack idea: TxVerifierImpl::verify only checks local structure, balance, digest, signatures, and range proofs. It does not run the public spend contract. If any caller treats this as final admission, a package that is locally valid but missing spend proof or spend auth can enter the system.

Pseudo-code:

1. Build tx bytes that pass local structure, balance, signature, and range-proof checks.
2. Leave spend proof or spend auth missing, stale, or otherwise non-final.
3. Call TxVerifierImpl::verify(bytes).
4. If the caller accepts valid = true without verify_full_tx_package, the spend layer never runs.

Evidence:

- [crates/z00z_wallets/src/core/tx/tx_verifier.rs](../../../crates/z00z_wallets/src/core/tx/tx_verifier.rs#L103)
- [crates/z00z_wallets/src/core/tx/tx_verifier.rs](../../../crates/z00z_wallets/src/core/tx/tx_verifier.rs#L111)
- [crates/z00z_wallets/src/core/tx/test_tx_verifier_suite.rs](../../../crates/z00z_wallets/src/core/tx/test_tx_verifier_suite.rs#L164)
- [crates/z00z_wallets/src/core/tx/test_tx_verifier_suite.rs](../../../crates/z00z_wallets/src/core/tx/test_tx_verifier_suite.rs#L182)

Current defense:

- The canonical runtime path uses verify_full_tx_package in [crates/z00z_wallets/src/adapters/rpc/methods/tx_impl_server_lifecycle.rs](../../../crates/z00z_wallets/src/adapters/rpc/methods/tx_impl_server_lifecycle.rs#L187).
- The simulator stage-4 gate also uses verify_full_tx_package in [crates/z00z_simulator/src/scenario_1/stage_4_utils/tx_validation_gates.rs](../../../crates/z00z_simulator/src/scenario_1/stage_4_utils/tx_validation_gates.rs#L186).

Verdict: Critical if a production caller wires the wrong verifier. The repo currently appears to use the full verifier in the canonical paths, so this is a high-value seam rather than a confirmed live bypass.

### ==HIGH - Raw claim verification is unsafe without persisted-store rebinding==

Attack idea: ClaimTxVerifierImpl::verify validates internal claim-package consistency, but the authoritative consumer must also rebind the claim source proof to the live AssetStore contract. Without that second step, a helper-owned or synthetic tree can look valid from the verifier's point of view.

Pseudo-code:

1. Build a claim package whose claim source proof and statement agree with each other.
2. Use a synthetic or stale store root that is internally self-consistent.
3. Call ClaimTxVerifierImpl::verify(bytes).
4. If the caller skips AssetStore::claim_source_contract_for_item, the package can look valid even though it was not rebound to the persisted store.

Evidence:

- [crates/z00z_wallets/src/core/tx/claim_tx.rs](../../../crates/z00z_wallets/src/core/tx/claim_tx.rs#L227)
- [crates/z00z_wallets/src/core/tx/claim_tx_verifier_impl_proof.rs](../../../crates/z00z_wallets/src/core/tx/claim_tx_verifier_impl_proof.rs#L142)
- [crates/z00z_wallets/src/core/tx/claim_tx_verifier_impl_proof.rs](../../../crates/z00z_wallets/src/core/tx/claim_tx_verifier_impl_proof.rs#L277)
- [crates/z00z_simulator/src/claim_pkg_consumer.rs](../../../crates/z00z_simulator/src/claim_pkg_consumer.rs#L210)
- [crates/z00z_simulator/src/claim_pkg_consumer.rs](../../../crates/z00z_simulator/src/claim_pkg_consumer.rs#L278)

Current defense:

- The simulator consumer compares the carried proof against the persisted store contract before accepting a claim package.
- This closes the production path, but not the raw verifier API by itself.

Verdict: High-risk API seam. It is safe in the current consumer flow, but unsafe as a standalone admission gate.

### ==HIGH - tx_digest_hex is stable under auth drift, so digest-only trust is unsafe==

Attack idea: build_tx_package_digest normalizes regular txs by zeroing auth and spend blobs before hashing. That means auth drift does not change the digest. Any cache, dedupe path, or persistence layer that uses tx_digest_hex as the full identity of a package can be tricked into associating the tampered package with the original one.

Pseudo-code:

1. Start with a canonical tx package.
2. Change auth.spend_sig_hex or receiver_card_compact.
3. Recompute nothing.
4. Observe that tx_digest_hex stays the same.
5. If an upstream consumer trusts digest equality instead of re-verifying the payload, the tampered package can be misclassified.

Evidence:

- [crates/z00z_wallets/src/core/tx/tx_digest.rs](../../../crates/z00z_wallets/src/core/tx/tx_digest.rs#L22)
- [crates/z00z_wallets/tests/test_spend_statement.rs](../../../crates/z00z_wallets/tests/test_spend_statement.rs#L210)
- [crates/z00z_wallets/tests/test_spend_statement.rs](../../../crates/z00z_wallets/tests/test_spend_statement.rs#L232)
- [crates/z00z_simulator/tests/test_checkpoint_acceptance.rs](../../../crates/z00z_simulator/tests/test_checkpoint_acceptance.rs#L524)

Current defense:

- Stage-11 and full-package admission re-read the payload and reject digest tamper.
- That protection only works for consumers that actually re-run the verifier and do not trust the digest alone.

Verdict: High severity as a second-order integrity risk. The digest is an identity root for routing and storage, not a substitute for verification.

### ==MEDIUM - The public spend contract is not a full tx verifier==

Attack idea: verify_tx_public_spend_contract checks the statement-bound envelope only. It cannot re-establish the witness-only theorem and it does not replace local structure, balance, signature, or range-proof validation. If a caller uses this helper alone as the final gate, malformed or unbalanced packages can slip through.

Pseudo-code:

1. Build a tx package whose public spend envelope is self-consistent.
2. Leave the rest of the tx outside the full verifier's expectations.
3. Call verify_tx_public_spend_contract(pkg).
4. If the caller treats that result as complete admission, the rest of the pipeline is skipped.

Evidence:

- [crates/z00z_wallets/src/core/tx/tx_verifier.rs](../../../crates/z00z_wallets/src/core/tx/tx_verifier.rs#L103)
- [crates/z00z_wallets/src/core/tx/tx_verifier.rs](../../../crates/z00z_wallets/src/core/tx/tx_verifier.rs#L111)
- [crates/z00z_wallets/src/core/tx/tx_verifier.rs](../../../crates/z00z_wallets/src/core/tx/tx_verifier.rs#L121)
- [crates/z00z_wallets/src/core/tx/test_tx_verifier_suite.rs](../../../crates/z00z_wallets/src/core/tx/test_tx_verifier_suite.rs#L186)

Current defense:

- Canonical admission composes local verification plus the public spend contract in verify_full_tx_package.
- The simulator and RPC paths already use the combined entry point.

Verdict: Medium because this is mainly a caller-misuse hazard, but the API split is real and the boundary is intentionally narrower than a theorem proof.

### MEDIUM - File-sink RPC logging test does not prove secret redaction on disk

Attack idea: The file-sink path is exercised with a secret-bearing wallet RPC, but the test only checks that JSONL is written and that timestamps stay sane. If the rotating file logger or the logging transport regresses and starts emitting raw params, the password, seed phrase, or memo would be persisted to disk and this test would still pass.

Pseudo-code:

1. Send a secret-bearing wallet RPC through `LoggedRpcTransport` backed by `RotatingFileLogger`.
2. Append the file and parse the resulting JSON lines.
3. Introduce a regression that keeps the JSON shape but stops redacting secret fields.
4. The test still passes because it never asserts absence of the secret strings.

Evidence:

- [crates/z00z_wallets/tests/test_rpc_logging_file_sink.rs](../../../crates/z00z_wallets/tests/test_rpc_logging_file_sink.rs#L34)
- [crates/z00z_wallets/tests/test_rpc_logging_file_sink.rs](../../../crates/z00z_wallets/tests/test_rpc_logging_file_sink.rs#L94)
- [crates/z00z_wallets/tests/test_rpc_logging_file_sink.rs](../../../crates/z00z_wallets/tests/test_rpc_logging_file_sink.rs#L108)
- [crates/z00z_wallets/tests/test_rpc_logging_risk_policy.rs](../../../crates/z00z_wallets/tests/test_rpc_logging_risk_policy.rs#L192)
- [crates/z00z_wallets/tests/test_rpc_logging_risk_policy.rs](../../../crates/z00z_wallets/tests/test_rpc_logging_risk_policy.rs#L199)

Current defense:

- The in-memory risk-policy test does enforce `password` and `memo` absence and wallet-id truncation.
- The file-sink test currently proves only the formatter/rotation path, not secret redaction on disk.

Verdict: Medium. The production impact would be high if the file sink ever leaked secrets, but the concrete issue here is a missing assertion on a secret-bearing code path.

### MEDIUM - Replay-audit corpus never asserts redaction for sensitive methods

Attack idea: The CSV-driven replay-audit test exercises secret-bearing methods like `wallet.session.show_seed_phrase` and `wallet.tx.send_transaction` against the file logger, but it only proves the log tail still contains `rpc.request` and `request_id`. A regression that keeps JSONL valid but leaks plaintext seed phrases, passwords, or memos in the file sink would still pass.

Pseudo-code:

1. Rebuild the audit-method corpus.
2. Replay a sample of methods, including `show_seed_phrase` and `send_transaction`.
3. Emit raw params or responses into the file sink.
4. The test still passes because it never searches the persisted log for secret strings or redacted response summaries.

Evidence:

- [crates/z00z_wallets/tests/test_rpc_logging_replay_audit.rs](../../../crates/z00z_wallets/tests/test_rpc_logging_replay_audit.rs#L134)
- [crates/z00z_wallets/tests/test_rpc_logging_replay_audit.rs](../../../crates/z00z_wallets/tests/test_rpc_logging_replay_audit.rs#L164)
- [crates/z00z_wallets/tests/test_rpc_logging_replay_audit.rs](../../../crates/z00z_wallets/tests/test_rpc_logging_replay_audit.rs#L193)
- [crates/z00z_wallets/tests/test_rpc_logging_replay_audit.rs](../../../crates/z00z_wallets/tests/test_rpc_logging_replay_audit.rs#L323)
- [crates/z00z_wallets/tests/test_rpc_logging_replay_audit.rs](../../../crates/z00z_wallets/tests/test_rpc_logging_replay_audit.rs#L336)
- [crates/z00z_wallets/tests/test_rpc_logging_replay_audit.rs](../../../crates/z00z_wallets/tests/test_rpc_logging_replay_audit.rs#L354)

Current defense:

- The replay-audit test does verify the corpus can be replayed without hanging, and it checks basic log structure.
- The dedicated risk-policy test does enforce some redaction semantics, but only on a narrower in-memory path.

Verdict: Medium. It's a logging-corpus blind spot rather than a confirmed leak, but it leaves the sensitive methods in the replay set unasserted.

## Additional Wallet-* Sweep Closure Notes

### Stage-2 mock RNG zero-seed fallback stays simulator-scoped

Attack idea: if `use_mock_rng=true` and `mock_rng_seed` is omitted, stage-2 reproducibility collapses to the same deterministic seed-zero lane that the simulator transport uses for wallet identity and timestamp generation. An operator who assumes "unset" means random would get reproducible wallet IDs instead of fresh entropy.

Pseudo-code:

1. Set `cfg.simulation.use_mock_rng = true`.
2. Leave `cfg.simulation.mock_rng_seed = None`.
3. Run stage-2 wallet creation.
4. Observe the same wallet IDs as explicit seed `0`.

Evidence:

- [crates/z00z_simulator/src/config.rs](../../../crates/z00z_simulator/src/config.rs#L30)
- [crates/z00z_simulator/src/scenario_1/stage_2_utils/transport.rs](../../../crates/z00z_simulator/src/scenario_1/stage_2_utils/transport.rs#L48)
- [crates/z00z_simulator/tests/test_transport_rng_boundaries.rs](../../../crates/z00z_simulator/tests/test_transport_rng_boundaries.rs#L49)

Current defense:

- The config and transport code both mark the mock RNG lane as simulator-only and explicitly non-production.
- The boundary test verifies that the zero-seed fallback is a reproducibility contract, not a hidden selector for core runtime entropy.

Verdict: dropped after triage. This is a simulator reproducibility contract, not a reachable production vulnerability.

### Encrypted wallet JSON export example lacks its own secret-hygiene assertion

Attack idea: a regression could keep the export/import round-trip working while adding plaintext secret fields to the pretty-printed JSON payload emitted by the example test. The test would still pass because it only checks that import succeeds and the wallet state returns locked.

Pseudo-code:

1. Export a wallet payload.
2. Add a plaintext `seed_phrase` or password-bearing field to the JSON object.
3. Pretty-print the payload.
4. Keep the import path working with the same password.

Evidence:

- [crates/z00z_wallets/tests/test_wallet_json_export.rs](../../../crates/z00z_wallets/tests/test_wallet_json_export.rs#L15)
- [crates/z00z_wallets/tests/test_wallet_json_export.rs](../../../crates/z00z_wallets/tests/test_wallet_json_export.rs#L44)
- [crates/z00z_wallets/tests/test_wallet_export_pack_boundary.rs](../../../crates/z00z_wallets/tests/test_wallet_export_pack_boundary.rs)
- [crates/z00z_wallets/tests/test_wallet_persistence_backup_service.rs](../../../crates/z00z_wallets/tests/test_wallet_persistence_backup_service.rs#L209)

Current defense:

- `test_wallet_export_pack_boundary.rs` already checks that serialized export data does not contain a plaintext seed phrase.
- The backup-service export/import test also requires a non-empty ciphertext and a non-`none` algorithm.

Verdict: dropped as duplicate coverage. The same export path is already covered by stronger secret-hygiene assertions elsewhere.

### ==Committed-state JMT scan would need proof validation to stay safe==

Attack idea: if committed post-tx leaves were treated as valid without validating `proof_bytes`, an attacker could feed an unproven leaf into the ownership scan and still get a positive receive classification.

Pseudo-code:

1. Load a committed JMT candidate.
2. Blank or tamper `proof_bytes`.
3. Call `scan_candidate`.
4. If proof validation is skipped, ownership detection proceeds on an untrusted leaf.

Evidence:

- [crates/z00z_simulator/tests/test_stage7_jmt_wallet_scan.rs](../../../crates/z00z_simulator/tests/test_stage7_jmt_wallet_scan.rs#L83)
- [crates/z00z_simulator/src/scenario_1/stage_11_utils/jmt_wallet_scan.rs](../../../crates/z00z_simulator/src/scenario_1/stage_11_utils/jmt_wallet_scan.rs#L100)
- [crates/z00z_simulator/src/scenario_1/stage_11_utils/jmt_wallet_scan.rs](../../../crates/z00z_simulator/src/scenario_1/stage_11_utils/jmt_wallet_scan.rs#L163)

Current defense:

- `verify_candidate()` rejects empty and invalid proof bytes with `chk_blob(...)` before `receiver_scan_leaf` runs.
- The committed-state scan test asserts that proof validation happens before ownership detection.

Verdict: dropped. The implementation already validates the proof content before the scan can classify ownership.

## Summary Table

| Severity | Finding | Current Status | Short Risk Note |
| --- | --- | --- | --- |
| Critical | Final tx admission can be bypassed at the local verifier layer | Surviving finding | Local verifier-only admission can skip the public spend contract if a caller wires the wrong entry point. |
| High | Raw claim verification is unsafe without persisted-store rebinding | Surviving finding | Standalone claim verification can accept internally consistent but unbound claim packages. |
| High | tx_digest_hex is stable under auth drift, so digest-only trust is unsafe | Surviving finding | Digest equality alone does not prove payload integrity after auth-field tampering. |
| Medium | The public spend contract is not a full tx verifier | Surviving finding | The helper is narrower than final admission and must not be used as a complete gate. |
| Medium | File-sink RPC logging test does not prove secret redaction on disk | Surviving finding | The file logger path still lacks a direct negative assertion for secret leakage. |
| Medium | Replay-audit corpus never asserts redaction for sensitive methods | Surviving finding | The replay corpus checks structure, not on-disk secret absence for sensitive RPCs. |