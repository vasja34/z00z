# Phase 046 Wallet Storage Suggestions

**Status:** Architecture proposal
**Date:** 2026-05-15
**Reader:** Wallet engineer or simulator engineer deciding whether Phase 046 should keep the current Snapshot-owned asset model or refactor `.wlt` into a wallet-native object store.
**Post-read action:** Choose the target `.wlt` organization for wallet-owned assets, transaction state, scan state, and backup/restore before writing the next implementation plan.

## 🎯 Executive Recommendation

Do not keep wallet-owned assets as a growing `claimed_assets` vector inside the wallet Snapshot blob.

The current implementation is understandable as an incremental bridge: the wallet already had a snapshot/export shape, and adding `claimed_assets: Vec<AssetWire>` made owned assets durable quickly. But as a long-term `.wlt` design, it is the wrong center of gravity. Assets are not wallet profile metadata. They are operational state used by scanning, input selection, pending reservations, cancellation, reconcile, restore, and simulator proofs.

The better design is:

1. Keep `.wlt` as the canonical encrypted wallet database.
2. Keep `secrets` separate from public/encrypted object payloads.
3. Rename or replace Snapshot with a narrow `WalletProfile` object that stores only profile/config/restore metadata.
4. Store each wallet-owned asset as its own encrypted `OwnedAsset` object.
5. Store or migrate transaction lifecycle records into `.wlt` as `TxRecord` / `TxEvent` objects when ready; until then, treat JSONL tx history as an explicit sidecar plane.
6. Keep scan cursor as a separate `ScanState` object, as it already is.
7. Add indexes over asset id, asset definition id, spend status, pending tx id, and scan position so transaction building does not depend on reading and rewriting a full wallet snapshot.

This preserves the current functional behavior while making the storage model more robust, more testable, and easier to extend.

## 🔍 Current Code Reality

The current wallet has three important persistence shapes:

1. `.wlt` RedB tables:
   - `meta`
   - `secrets`
   - `objects`
   - index tables such as `index_asset_out_by_def`, `index_asset_out_by_spentflag`, and `index_tracked_asset_by_spentflag`

2. Encrypted wallet objects:
   - wallet root
   - account
   - derivation state
   - scan state
   - app / chain
   - keys
   - stealth metadata
   - TOFU pins
   - deprecated Snapshot container

3. Transaction history sidecar:
   - canonical JSONL history is currently outside `.wlt`
   - `wallet_<stem>_tx_history.jsonl` stores submitted/admitted/confirmed/imported/exported/cancelled lifecycle records

The important observation is that `.wlt` already has an object-store architecture. The current Snapshot blob is not the natural foundation of the database. It is a compatibility container living inside the object store.

Today, wallet-owned assets flow like this:

```text
WalletService.recv_range(...)
  -> StealthOutputScanner detects a wallet-owned output
  -> recv_route(..., ReceiveNext::PersistClaim)
  -> put_claimed_asset(...)
  -> wallet_claimed_assets in memory
  -> create_snapshot(...)
  -> WalletPersistenceState.claimed_assets: Vec<AssetWire>
  -> write_wallet_snapshot(...)
  -> encrypted Snapshot object in .wlt objects table
```

Transaction building then uses:

```text
wallet.tx.build_transaction
  -> list_claimed_assets(...)
  -> exclude pending reserved asset ids from tx history
  -> AssetSelector::select(...)
  -> build inputs / outputs / change / fee / proof package
```

Reconcile uses:

```text
wallet.tx.reconcile_transaction
  -> validate stored tx package and confirmation evidence
  -> remove spent claimed asset ids
  -> scan tx outputs with wallet receiver keys
  -> add wallet-owned change/import outputs
  -> set_claimed_assets(...)
  -> rewrite Snapshot claimed_assets
```

So yes: the wallet currently can function. It can find assets, store them, select inputs, reserve pending assets, cancel and release them, reconcile spent and change outputs, and restore claimed assets through the snapshot path.

The concern is not "this cannot work." The concern is "this is a poor long-term authority boundary."

## ⚠️ Why Snapshot-Owned Assets Are a Weak Design

Snapshot is a good name for an export image or point-in-time backup. It is a bad name and a bad abstraction for the live operational asset set.

Wallet-owned assets are not a profile snapshot. They are the wallet's active spendable inventory. The code needs to query, reserve, mark spent, reconcile, restore, and audit them. Storing them inside one full Snapshot object makes every small asset mutation look like a whole-wallet rewrite.

The main design problems are:

1. **Wrong ownership boundary**
   - `claimed_assets` are domain objects.
   - `wallet name`, `settings`, `receiver_deriver`, and `password_verifier` are wallet profile/config state.
   - Mixing them in one Snapshot couples unrelated mutation rates and unrelated invariants.

2. **Poor write granularity**
   - Adding one newly detected asset rewrites the full Snapshot.
   - Spending one asset and adding one change output rewrites the full claimed set.
   - This is acceptable for tiny demos but gets worse as asset count grows.

3. **Poor query shape**
   - Transaction building wants "spendable assets for wallet, optionally by asset definition, excluding pending reservations."
   - A Snapshot vector forces load/filter behavior instead of a direct indexed lookup.
   - The current code compensates by keeping `wallet_claimed_assets` in memory, but that means open/reload and restore must rebuild this cache correctly every time.

4. **Harder atomicity across related domains**
   - Reconcile changes asset status and tx evidence together.
   - Today tx history is JSONL and assets are Snapshot state, so rollback logic has to bridge two persistence planes.
   - A wallet-native object store can commit asset state, tx record, scan cursor, and index updates in one RedB transaction when those planes are moved into `.wlt`.

5. **Harder future extension**
   - Asset metadata will likely grow: source, confirmation status, spend reservation, proof references, imported/exported lifecycle, claim height, scan provenance, quarantine reason, user labels, policy state.
   - Adding all of that to `WalletPersistenceState.claimed_assets` turns Snapshot into a database hidden inside one field.

6. **Misleading mental model**
   - Calling this object `Snapshot` suggests a point-in-time copy.
   - The live wallet currently treats it as the canonical asset table.
   - That mismatch will confuse future code and future docs.

7. **Index tables already hint at the better design**
   - `.wlt` already defines object and asset-related index tables.
   - Keeping all assets inside Snapshot prevents those indexes from becoming the primary access path.

There are real advantages to the current design, but they are mostly short-term:

1. It was quick to implement.
2. It gives one encrypted payload for backup/restore.
3. It gives an easy checksum boundary.
4. It avoids partial migration work.
5. It keeps the simulator able to prove current behavior without inventing a second asset table.

Those advantages are valid, but they do not outweigh the long-term cost if this wallet is still in development and legacy compatibility is not required.

## 🧭 Gap Coverage From The Two Source Notes

The gap notes identified several real issues. Most of them moved into the Phase 046 spec, but the spec intentionally preserves current storage behavior instead of proposing a better target storage model.

Gaps that did move into the current spec:

1. Prove the canonical `wallet.tx.*` lifecycle instead of relying only on simulator-specific transaction helpers.
2. Show that transaction building selects inputs from the wallet-owned claimed asset set.
3. Show pending reservation, cancellation, rebuild, broadcast, and reconcile.
4. Show receiver export/import parity.
5. Show tamper/fail-closed behavior for bad packages or evidence.
6. Show backup restore with `WalletPlusHistory`.
7. Show TOFU and payment request negative paths.
8. Show session hardening and key-rotation boundary.
9. Keep `recv_range(...)` plus `StealthOutputScanner` as wallet-side scan authority.
10. Do not claim a JMT-side ownership scanner.
11. Reuse existing storage/root proof helpers instead of adding custom root math.
12. Clean stale placeholder/stub wording.

The gap that did not become a design improvement:

1. The notes correctly identified that assets need a real storage authority so future transactions can select inputs.
2. The spec answers that by saying "the current authority is `.wlt` Snapshot `claimed_assets`."
3. That is true as a current-state statement.
4. It is not a strong target architecture.

So the current Phase 046 spec is mostly correct as a demonstration spec, but it should not be treated as endorsement of Snapshot-as-asset-store. Decision 2 should be revised or supplemented:

```text
For Phase 046 demonstration, prove the current `.wlt` Snapshot claimed-asset behavior.
For the wallet storage target, replace Snapshot-owned claimed_assets with native `.wlt`
OwnedAsset objects and indexes.
```

## ⚙️ Requirements The New Design Must Preserve

The replacement design must not lose any behavior that currently works.

Required wallet behaviors:

1. Create/open wallet from `.wlt`.
2. Keep secrets separated from non-secret object payloads.
3. Unlock session and derive receiver keys.
4. Scan chunks with `StealthOutputScanner`.
5. Persist scan cursor.
6. Persist newly owned assets discovered by scan.
7. List owned assets for balance and UX.
8. Select spendable input assets for `wallet.tx.build_transaction`.
9. Exclude pending/reserved assets from selection.
10. Cancel pending tx and release reservations.
11. Broadcast tx and store submitted/admitted status.
12. Reconcile confirmed tx and update asset states.
13. Add wallet-owned change outputs.
14. Import portable tx and detect receiver-owned outputs.
15. Restore wallet assets and tx history with all-or-nothing behavior.
16. Reject wrong password, corrupted snapshot, corrupted tx history, and tampered packages without mutating existing state.
17. Keep TOFU/payment-request checks before building tx outputs.
18. Keep `wallet.asset.*` compatibility surfaces clearly non-canonical until they are tx/reconcile-backed.
19. Keep storage/root proof code delegated to the existing storage and settlement helpers.
20. Keep remote JMT/aggregator as a data/proof source only; wallet-side keys decide ownership.

Required storage properties:

1. Atomic mutation for all fields changed by one wallet operation.
2. Object-level encryption with correct AAD binding.
3. No secret material inside asset records, tx records, or profile objects.
4. Duplicate asset id rejection.
5. Indexed lookup by wallet/account/status/asset definition.
6. Deterministic restore.
7. Idempotent replay or recovery after interrupted writes.
8. Clear migration story while the project is still pre-production.

## 🧪 Design Options

### Native `.wlt` Domain Object Store

Interface shape:

```text
.wlt
  meta
  secrets
  objects
    WalletProfile
    Account
    DerivationState
    ScanState
    Keys
    StealthMeta
    TofuPins
    OwnedAsset
    TxRecord / TxEvent
    BackupManifest
  indexes
    asset_id -> object_id
    asset_def_id + status -> object_id set
    status -> object_id set
    tx_id -> object_id set
    scan_position -> object_id set
```

Caller-facing port:

```text
WalletAssetStore {
  put_owned_asset(wallet_id, asset, source, scan_ref)
  list_assets(wallet_id, filter)
  list_spendable(wallet_id, asset_def_id, exclude_pending)
  reserve_inputs(wallet_id, tx_id, asset_ids)
  release_reservation(wallet_id, tx_id)
  confirm_spend(wallet_id, tx_id, spent_asset_ids, new_owned_outputs)
  restore_assets(wallet_id, records)
}

WalletTxStore {
  append_event(wallet_id, tx_id, event)
  get_tx(wallet_id, tx_id)
  list_history(wallet_id, filter, cursor)
  bind_assets(wallet_id, tx_id, input_ids, output_ids)
}
```

What it hides:

1. Encryption envelope.
2. Object ids.
3. Index maintenance.
4. Atomic RedB write transactions.
5. Cache rebuild on open.
6. Rollback/commit ordering.

Pros:

1. Matches the existing `.wlt` object-store direction.
2. Keeps assets encrypted as wallet objects.
3. Gives object-level write granularity.
4. Gives clean indexes for input selection.
5. Makes scan, tx, and restore invariants explicit.
6. Allows future tx history migration into `.wlt`.
7. Avoids a hidden database inside `WalletPersistenceState`.
8. Keeps secrets separate.
9. Gives simulator a better storage contract to prove.

Cons:

1. Requires new object kinds and payload versions.
2. Requires index consistency tests.
3. Requires more migration/refactor work than keeping Snapshot.
4. Requires careful atomic batch APIs so asset and tx mutations do not drift.
5. Requires deciding whether tx JSONL remains a sidecar or becomes `.wlt` objects.

Recommendation:

Choose this. It is the best match for the existing `.wlt` architecture and the future wallet needs.



## ✅ Recommended `.wlt` Organization

The recommended organization is a domain object store inside `.wlt`.

```text
.wlt
  meta
    wallet id
    schema version
    save sequence
    integrity digest
    object pointers for singleton objects
    index manifest

  secrets
    encrypted seed material
    encrypted secret key material
    secret refs only, not duplicated in objects

  objects
    WalletProfile
    Account
    DerivationState
    ScanState
    Keys
    StealthMeta
    TofuPins
    OwnedAsset
    TxRecord
    TxEvent
    BackupManifest

  indexes
    asset_by_id
    asset_by_definition
    asset_by_status
    asset_by_tx
    asset_by_scan_position
    tx_by_status
    tx_by_time
```

### 🔑 `WalletProfile`

`WalletProfile` should replace the live semantic role currently played by Snapshot for non-asset profile state.

Fields:

```text
WalletProfile {
  version
  wallet_id
  name
  created_at
  updated_at
  settings
  password_verifier_ref_or_state
  seed_salt_ref_or_state
  profile_checksum
}
```

Rules:

1. No `claimed_assets`.
2. No transaction history.
3. No scan cursor.
4. No secret key material.
5. Only slow-changing wallet profile metadata.

Name choice:

1. `WalletProfile` is better than `Snapshot` for live state.
2. `Snapshot` may remain as an export/backup term only.
3. If no legacy compatibility is needed, rename now rather than carrying a misleading name.

### 🔑 `OwnedAsset`

Each wallet-owned asset should be one encrypted object.

Suggested fields:

```text
OwnedAsset {
  version
  wallet_id
  account_id
  asset_id
  asset_definition_id
  asset_wire
  status
  source
  first_seen
  last_updated
  scan_ref
  receive_ref
  spend_ref
  confirmation_ref
  labels
  policy
  integrity
}
```

Field details:

```text
version:
  Payload version for migrations.

wallet_id:
  The owning wallet.

account_id:
  Account/subaccount boundary for future multi-account wallets.

asset_id:
  Canonical asset id derived from the asset leaf/wire data.

asset_definition_id:
  Asset class/definition id used for filtering and balance grouping.

asset_wire:
  The serialized owned asset payload needed to spend or prove ownership.

status:
  Spendable
  PendingSpend
  Spent
  PendingReceive
  Quarantined
  Imported
  Archived

source:
  Scan
  Import
  Change
  Genesis
  Restore
  ManualClaim

first_seen:
  Optional block/checkpoint height, hash/root, chunk id, and local timestamp.

last_updated:
  Local timestamp or monotonic wallet sequence.

scan_ref:
  Optional pointer to scan cursor/chunk/proof context.

receive_ref:
  Optional payment request id, receiver card id, or import id.

spend_ref:
  Optional tx id if PendingSpend or Spent.

confirmation_ref:
  Optional confirmation evidence id or root binding.

labels:
  User labels or UX tags, if needed later.

policy:
  Wallet-local policy flags such as frozen/quarantined/manual-review.

integrity:
  Record checksum or object-level digest in addition to the encrypted object envelope.
```

Confidentiality note:

Do not add redundant plaintext amount fields unless the wallet already exposes that information at the same confidentiality level. If amount, commitment, or asset definition metadata is needed for UX, keep it inside the encrypted object and expose it only through wallet APIs that already enforce session rules.

### 🔑 `ScanState`

`ScanState` should remain a separate object.

Suggested fields:

```text
ScanState {
  version
  wallet_id
  account_id
  last_scanned_height
  last_scanned_hash
  last_scanned_root
  scanner_version
  updated_at
}
```

Rules:

1. Scan cursor is not scanner authority.
2. The scanner authority remains wallet-side `recv_range(...)` plus `StealthOutputScanner`.
3. A remote aggregator/JMT service may provide chunks and proofs, but it must not decide wallet ownership.
4. When a scan detects assets, asset inserts and scan cursor update should commit atomically.

### 🔑 `TxRecord` And `TxEvent`

The current JSONL tx history can remain for Phase 046 demonstration, but the target wallet storage should plan for tx records inside `.wlt`.

Suggested `TxRecord` fields:

```text
TxRecord {
  version
  wallet_id
  tx_id
  tx_hash
  status
  role
  package_ref_or_bytes
  input_asset_ids
  output_asset_ids
  imported
  exported
  submitted_at
  admitted_at
  confirmed_at
  cancelled_at
  confirmation_evidence_ref
  error_or_reject_reason
}
```

Suggested `TxEvent` fields:

```text
TxEvent {
  version
  wallet_id
  tx_id
  event_seq
  event_type
  event_time
  payload
}
```

Rules:

1. `TxRecord` gives current state for API queries.
2. `TxEvent` gives audit/history and can be optional at first.
3. Asset status and tx status must be updated in the same write transaction whenever one operation changes both.
4. If JSONL remains temporarily, the code must treat `.wlt` plus JSONL as two explicit persistence planes and keep all-or-nothing staged restore semantics.

### 🔑 `Keys` And `Secrets`

Keep keys and secrets separated.

Rules:

1. `secrets` stores encrypted secret material.
2. `Keys` stores public material, fingerprints, and secret references.
3. Asset objects reference key/account context but never embed seed material.
4. Master-key rotation must not be described as durable seed rotation until the secret storage layer actually rewrites persisted seed/master-key material.

## 🔁 Operation Flows In The Recommended Design

### Flow 1: Wallet Create

```text
create_wallet_store
  -> write secrets
  -> write WalletProfile
  -> write Account
  -> write DerivationState
  -> write ScanState
  -> write Keys / StealthMeta / TofuPins
  -> initialize index manifest
```

No asset objects exist at creation unless the wallet is restored from a backup.

### Flow 2: Wallet Open

```text
open_wallet_store
  -> validate object envelopes
  -> read singleton object pointers
  -> load WalletProfile and key refs
  -> load ScanState
  -> lazily load or index-query OwnedAsset objects
  -> rebuild in-memory caches from object store
```

The in-memory cache is a performance optimization, not the authority.

### Flow 3: Scan Detects A New Owned Asset

```text
recv_range(chunks)
  -> read ScanState
  -> derive receiver keys for unlocked wallet
  -> StealthOutputScanner scans public chunk data
  -> scanner identifies Mine leaf
  -> convert leaf to Asset
  -> begin wallet write transaction
  -> insert OwnedAsset object if asset_id is new
  -> update asset indexes
  -> update ScanState cursor
  -> bump save sequence and integrity
  -> commit
```

If the same asset is discovered again, the operation should be idempotent:

1. Same asset id and same wire data: no-op or metadata refresh.
2. Same asset id but conflicting wire data: fail closed and quarantine/report.

### Flow 4: Alice Builds A Transaction To Bob

```text
wallet.tx.build_transaction(Alice, Bob, amount, asset_id?)
  -> validate session, TOFU/payment request, chain binding
  -> query WalletAssetStore.list_spendable(...)
  -> exclude PendingSpend / reserved assets through indexed status
  -> AssetSelector::select(...)
  -> build inputs, recipient output, change output, fee output
  -> create tx package and proofs
  -> begin wallet write transaction
  -> create/update TxRecord as Pending
  -> mark selected OwnedAsset records as PendingSpend with tx_id
  -> commit
```

The important difference from the current design is that pending reservation should live on the asset records and tx record, not only be inferred from a JSONL sidecar.

### Flow 5: Alice Cancels Pending Transaction

```text
wallet.tx.cancel_transaction(tx_id)
  -> validate tx is cancellable
  -> begin wallet write transaction
  -> update TxRecord status to Cancelled
  -> release all OwnedAsset records reserved by tx_id back to Spendable
  -> append TxEvent Cancelled if event log is enabled
  -> commit
```

### Flow 6: Broadcast And Reconcile

```text
wallet.tx.broadcast_transaction(tx_data)
  -> verify package
  -> submit package
  -> update TxRecord Submitted / Admitted

wallet.tx.reconcile_transaction(tx_id)
  -> load TxRecord and package
  -> validate confirmation evidence and root binding
  -> scan tx outputs with wallet receiver keys
  -> begin wallet write transaction
  -> mark input OwnedAsset records as Spent
  -> insert wallet-owned change/output OwnedAsset records as Spendable
  -> update TxRecord Confirmed
  -> store confirmation evidence ref
  -> commit
```

This removes the current need to call `set_claimed_assets(...)` with a full replacement vector.

### Flow 7: Bob Receives Or Imports A Transaction

```text
wallet.tx.import_transaction(tx_data)
  -> verify package
  -> check chain id and package digest
  -> scan outputs with Bob receiver keys
  -> begin wallet write transaction
  -> create TxRecord as Imported/Pending
  -> insert Bob-owned output OwnedAsset records as PendingReceive or Spendable
  -> commit
```

Later broadcast/reconcile can move the same tx and asset objects to confirmed states.

### Flow 8: Backup And Restore

Backup should export a coherent wallet pack:

```text
WalletBackupPack {
  manifest
  wallet_profile
  singleton_objects
  owned_assets
  tx_records_or_history
  scan_state
  tofu_pins
  key_refs
  encrypted_secret_material
}
```

Restore should stage everything before mutating live state:

```text
restore_backup
  -> decrypt and decode pack
  -> validate schema versions
  -> validate wallet id / chain binding
  -> validate duplicate asset ids
  -> validate tx references to asset ids
  -> write staged .wlt
  -> write staged tx history if JSONL sidecar still exists
  -> atomically promote staged artifacts
```

If any step fails, the existing wallet must remain unchanged.

## 🧷 Index Strategy

The object store needs indexes that match wallet operations.

Minimum indexes:

```text
asset_by_id:
  key: wallet_id + asset_id
  value: object_id

asset_by_definition_status:
  key: wallet_id + asset_definition_id + status + asset_id
  value: object_id

asset_by_status:
  key: wallet_id + status + asset_id
  value: object_id

asset_by_tx:
  key: wallet_id + tx_id + asset_id
  value: object_id

asset_by_scan_position:
  key: wallet_id + height/root/chunk + asset_id
  value: object_id

tx_by_status:
  key: wallet_id + status + tx_id
  value: object_id

tx_by_time:
  key: wallet_id + timestamp + tx_id
  value: object_id
```

Rules:

1. Indexes are accelerators, not separate truth.
2. Object payload is the authority.
3. Every object write must update indexes in the same RedB write transaction.
4. Open-time validation should detect missing/stale index rows.
5. A repair/rebuild command can rebuild indexes from objects, but normal open should fail on integrity drift unless an explicit repair mode is requested.

## 🧱 Suggested Object Kinds

The exact numeric ids should be chosen once and kept in schema docs and Rust in sync.

Suggested logical kinds:

```text
WalletProfile
Account
DerivationState
ScanState
App
Chain
Keys
StealthMeta
TofuPins
OwnedAsset
TxRecord
TxEvent
BackupManifest
```

One concrete issue to fix during this redesign:

The Rust object-kind enum and the schema documentation appear to disagree on the Snapshot kind id. The Rust enum uses Snapshot as one value, while the RedB schema YAML describes a different Snapshot kind id. This does not directly decide the asset-store design, but it is exactly the kind of schema drift that becomes dangerous when the wallet adds more first-class object kinds.

## 🧩 Proposed Interfaces

The caller should not care whether assets are stored as encrypted objects, rows, or future event-sourced read models.

Suggested port:

```text
WalletAssetStore {
  put_owned(wallet_id, asset, source, context) -> PutAssetResult
  get(wallet_id, asset_id) -> Option<OwnedAsset>
  list(wallet_id, filter, cursor) -> Page<OwnedAsset>
  list_spendable(wallet_id, asset_def_id, amount_hint) -> Vec<OwnedAsset>
  reserve(wallet_id, tx_id, asset_ids) -> ReservationResult
  release(wallet_id, tx_id) -> ReleaseResult
  confirm_spend(wallet_id, tx_id, spent_ids, new_outputs) -> ConfirmResult
  replace_for_restore(wallet_id, assets) -> RestoreResult
}
```

Suggested filter:

```text
AssetFilter {
  account_id
  asset_definition_id
  status
  source
  tx_id
  min_height
  max_height
}
```

Misuse to prevent:

1. Caller must not directly mutate asset status without tx context.
2. Caller must not insert duplicate asset ids.
3. Caller must not mark an asset spent unless it is PendingSpend for the same tx or an explicit recovery mode is active.
4. Caller must not expose secret material through asset records.
5. Caller must not rebuild balances from untrusted external JMT ownership claims.

## 🧨 What Should Change In The Existing Phase 046 Spec

The current spec is useful as a proof plan, but it should separate "current behavior to demonstrate" from "target architecture to preserve."

Recommended edits:

1. Keep Decision 1.
   - Add the simulator stage. It is still valuable.

2. Revise Decision 2.
   - Current wording: use `.wlt` claimed assets as input authority and introduce no new simulator asset table.
   - Better wording: Phase 046 must prove the current `.wlt` claimed-assets path, but the target wallet storage is first-class `OwnedAsset` objects inside `.wlt`; no simulator-only asset table may be introduced.

3. Keep Decision 3.
   - `wallet.asset.*` send-like methods should remain non-canonical until tx/reconcile-backed.

4. Keep Decision 4.
   - `WalletPlusHistory` restore remains required while tx history is separate JSONL.
   - Add future target: move tx records into `.wlt` or explicitly keep JSONL as an audited sidecar.

5. Keep Decision 5.
   - Key rotation boundary remains separate from storage redesign.

6. Keep Decision 6.
   - Stale placeholder cleanup is still needed.

7. Keep Decision 7.
   - No custom root math.

8. Keep Decision 8.
   - Ownership detection remains wallet-side.
   - Remote JMT/aggregator is only a chunk/proof read adapter.

New decision to add:

```text
Decision 9: Treat Snapshot as an export/profile compatibility container, not as the
target live asset authority. Wallet-owned assets must become first-class encrypted
OwnedAsset objects in `.wlt`, indexed for spend selection and updated atomically with
tx status and scan cursor changes.
```

## 🛠️ Migration Plan While Still In Development

Because the project is still in development and no legacy wallet compatibility is required, prefer a clean cut instead of long compatibility scaffolding.

Recommended sequence:

1. Define new payload versions and object kinds:
   - `WalletProfile`
   - `OwnedAsset`
   - optionally `TxRecord`
   - optionally `TxEvent`

2. Remove `claimed_assets` from the live profile/snapshot object.
   - If tests still need export compatibility, keep it only in backup export structs, not as live authority.

3. Add a `WalletAssetStore` implementation over `.wlt` encrypted objects.
   - Use existing object encryption and AAD rules.
   - Use existing index validation patterns.

4. Replace `wallet_claimed_assets` authority with an object-store-backed cache.
   - The cache may remain, but open/reload must rebuild it from `OwnedAsset` objects.

5. Change receive persistence:
   - `put_claimed_asset(...)` becomes `put_owned_asset(...)`.
   - Scan cursor update and asset insert should share one DB transaction where possible.

6. Change tx build:
   - Query spendable assets from `WalletAssetStore`.
   - Reserve selected inputs by updating asset status to `PendingSpend`.

7. Change cancel:
   - Release `PendingSpend` assets for the tx id.

8. Change reconcile:
   - Mark spent inputs as `Spent`.
   - Insert wallet-owned outputs/change as `Spendable`.
   - Update tx status/evidence in the same transaction if tx records are in `.wlt`.

9. Change restore:
   - Restore `WalletProfile`, `OwnedAsset`, `ScanState`, `TofuPins`, key refs, secrets, and tx history as staged artifacts.

10. Update simulator Stage 13:
   - It should still prove `wallet.tx.*`.
   - Its report should say assets are stored as `.wlt` `OwnedAsset` objects once the refactor lands.
   - It should stop describing claimed assets as snapshot payload authority.

11. Retire or rewire the existing JSON-backed `AssetStorageImpl`.
   - Do not make it the new authority as-is.
   - It can inspire the trait shape, but persistent wallet assets should live in `.wlt`, not in `<db_path>.wallets/{wallet_id}.json`.

12. Fix schema drift.
   - Keep Rust object kind ids and schema YAML ids identical.
   - Add tests that fail on mismatch.

## 🧪 Validation Plan

Required unit tests:

1. Insert one `OwnedAsset`, reopen wallet, list it.
2. Duplicate asset id is rejected or idempotently accepted only if payload matches.
3. Asset indexes return the same records as full object scan.
4. Corrupt object payload fails closed.
5. Missing index row is detected on open or index validation.
6. Scan cursor and asset insert commit atomically.
7. `PendingSpend` assets are excluded from input selection.
8. Cancel releases pending assets.
9. Reconcile marks inputs spent and inserts change outputs.
10. Restore rejects duplicate asset ids.
11. Restore wrong password leaves existing wallet unchanged.
12. Snapshot object kind id in Rust matches schema documentation.

Required wallet RPC tests:

1. `wallet.tx.build_transaction` selects only `Spendable` assets.
2. `wallet.tx.list_pending_transactions` reflects reserved inputs.
3. `wallet.tx.cancel_transaction` releases inputs.
4. `wallet.tx.reconcile_transaction` updates asset states and tx status.
5. `wallet.tx.import_transaction` creates receiver-owned assets through wallet-side scan logic.
6. `wallet.asset.list_assets` reads from `OwnedAsset` objects, not Snapshot.
7. `wallet.asset.import_asset` persists through `OwnedAsset` objects.

Required simulator checks:

1. Stage 13 proves live `wallet.tx.*` lifecycle.
2. Stage 13 proves assets survive lock/reopen.
3. Stage 13 proves backup/restore with wallet state and tx history.
4. Stage 13 proves tamper failure does not mutate asset objects.
5. Stage 13 report distinguishes:
   - wallet-owned asset object state
   - tx history state
   - scan cursor state
   - storage/JMT roots

## 🚫 What Not To Do

1. Do not add a simulator-only asset table.
2. Do not make remote JMT ownership detection authoritative.
3. Do not store wallet secrets inside asset records.
4. Do not keep growing `WalletPersistenceState` into a hidden database.
5. Do not infer pending reservations only from JSONL once asset records exist.
6. Do not recompute storage roots with custom simulator math.
7. Do not describe `wallet.asset.send_asset` as canonical confirmed spend until it is backed by the same tx/reconcile path.
8. Do not keep the name Snapshot for live mutable wallet state if legacy compatibility is not needed.

## 📌 Final Position

Your instinct is right: rewriting a full wallet Snapshot every time an asset is claimed, spent, or reconciled is not the best wallet design.

The current code works because the wallet has an in-memory claimed-asset cache and persists that cache into an encrypted Snapshot object. That is a reasonable bridge, but it should not become the permanent storage model.

The best target is:

```text
WalletProfile object:
  slow-changing wallet metadata

OwnedAsset objects:
  one encrypted object per wallet-owned asset

ScanState object:
  scan cursor and resume metadata

TxRecord / TxEvent objects:
  tx lifecycle state, either now or as the next migration after assets

Secrets table:
  secret material only

Indexes:
  fast spendable/pending/spent lookup and tx binding
```

This design keeps the current wallet functionality, makes transaction input selection natural, gives simulator proofs a real wallet storage boundary, and leaves room for future features without turning Snapshot into an accidental database.
