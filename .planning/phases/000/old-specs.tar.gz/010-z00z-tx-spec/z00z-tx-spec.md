<!-- markdownlint-disable MD001 MD007 MD022 MD025 MD031 MD032 MD035 MD040 MD058 MD060 -->

# Z00Z Transaction Contract Specification

> 📌 Extracted from `crates/Z00Z-ECC-IDEAS.md`
> **Version:** 0.1  
> **Status:** Draft  
> **Date:** 2026-02-24

---

[TOC]

---

## 1) Glossary and Canonical Definitions


- **receiver_secret**: долгоживущий секрет кошелька получателя. Никогда не публикуется.
- **owner_handle**: публичный off-chain идентификатор получателя, полученный из `receiver_secret`:
  - `owner_handle = H("Z00Z/RID" || receiver_secret)`
  - НЕ даёт права траты.
  - ⚠️ **Wallet (Phase 1):** `derive_owner_handle` вычисляет `hash_zk<WalletReceiverIdHashProdDomain>("RID", [receiver_secret])` — wallet-private домен `"z00z.wallet.stealth.receiver_id.prod.v1"`, контекст `"RID"` (без `"Z00Z/"` префикса). ZK-схема §5 использует consensus `ReceiverIdDomain("Z00Z/RID")`. Расхождение — Phase 2 (§26.2 T-1).
- **view_sk / view_pk**: ключи “просмотра” для stealth (ECDH):
  - `view_sk = H2Scalar("Z00Z/VIEW" || receiver_secret)`
  - `view_pk = view_sk * G`
  - ⚠️ **Wallet (Phase 1):** `derive_view_secret_key` вычисляет `h2s_zk<WalletViewKeyHashProdDomain>("VIEW", [receiver_secret])` — wallet-private домен `"z00z.wallet.stealth.view_key.prod.v1"`, контекст `"VIEW"`. Расхождение — Phase 2 (§26.2 T-1).
- **r**: одноразовый секрет отправителя для конкретного output.
- **R_pub**: одноразовая публичная точка в leaf:
  - `R_pub = r * G`
- **dh**: общий секрет ECDH:
  - `dh = r * view_pk`
  - получатель вычисляет тот же `dh' = view_sk * R_pub`
- **k_dh**: симметрический ключ, полученный из `dh`:
  - `k_dh = KDF("Z00Z/DH" || Encode(dh))`
  - ⚠️ **Wallet (Phase 1):** `derive_k_dh` вычисляет `hash_zk<WalletDhKeyHashProdDomain>("Z00Z/DH", [dh])` — wallet-private домен `"z00z.wallet.stealth.dh_key.prod.v1"`. Consensus: `KdhDomain("Z00Z/DH")`. Расхождение — Phase 2 (§26.2 T-1).
- **s_out**: секрет монеты (coin secret) как объект собственности.
  - **Phase 1 wallet actual:** `s_out` детерминированно выводится из `k_dh`, `R_pub` и `serial_id` (см. §11).
  - **Security note:** уникальность достигается за счёт включения `R_pub` и `serial_id` в деривацию.
- **asset_id**: ключ leaf в JMT:
  - `asset_id = H("Z00Z/ASSET" || s_out)`
- **serial_id**: порядковый/версионный номер формата или внутренний номер (ты уже используешь).
- **v**: сумма.
- **r_out**: Pedersen blinding для суммы.
- **C_amount**: Pedersen commitment суммы:
  - `C_amount = Commit(v, r_out)`
- **leaf_ad**: AD (associated data), которое привязывает `enc_pack` к leaf:
  - `leaf_ad = H("Z00Z/LEAFAD" || asset_id || serial_id || R_pub || owner_tag || C_amount || ...)`
  - ⚠️ **Wallet (Phase 1):** использует `hash_zk<WalletLeafAdHashProdDomain>("Z00Z/LEAFAD", [...])` — wallet-private домен `"z00z.wallet.stealth.leaf_ad.prod.v1"`. Подробнее — §11.3.
- **enc_pack**: шифротекст “coin-pack” с payload `AssetPackPlain`.
  - **Phase 1 wallet actual:** payload фиксирован как `(value, blinding, s_out)` размером 72 байта (см. §12).
  - `serial_id` не сериализуется в payload; он участвует в AAD (`leaf_ad`) и деривациях.
- **owner_tag**: публичный “random-looking” якорь владения, unlinkable на chain/state:
  - `owner_tag = H("Z00Z/TAG" || owner_handle || k_dh)`
  - ⚠️ **Wallet (Phase 1):** `compute_owner_tag` вычисляет `hash_zk<WalletOwnerTagHashProdDomain>("Z00Z/TAG", [owner_handle, k_dh])` — wallet-private домен `"z00z.wallet.stealth.owner_tag.prod.v1"`. Consensus: `OwnerTagDomain("Z00Z/TAG")`. Расхождение — Phase 2 (§26.2 T-1).
- **TxPackage**: переносимый объект транзакции, который можно форвардить оффлайн и потом публиковать.
- **TxProof**: доказательство локальной математики транзакции (spend + balance + OWF).
- **CheckpointProof**: доказательство корректного перехода состояния `prev_root -> new_root` (membership + delete/insert + deltas).
- **spent_delta / created_delta**: диффы по чекпойнту (твой B1), чтобы поддерживать оффлайн-DAG и проверку “не потрачен после”.

### Canonical encoding (MUST for Phase 2 consensus; Phase 1 deviations are documented)

- Все хэши **MUST** иметь domain separation в каноническом consensus-профиле (`"Z00Z/..."`).
  - ⚠️ `Phase 1 wallet`: часть derivation-путей использует wallet-private domains (см. §1, §11, §26.2 T-1).

- Все массивы/списки **MUST** сериализоваться канонично:

  - фиксированный порядок полей,
  - фиксированная endian-форма для чисел (обычно LE),
  - точки ECC в одном стандарте (compressed encoding),
  - длины всегда включены (length-prefix), чтобы не было двусмысленностей.

- Все `tx_digest`, `leaf_ad`, `asset_id` **MUST** быть вычислимы одинаково в wallet и в proof после Phase 2 domain/proof alignment.
  - До alignment (`Phase 1`) допускается зафиксированное расхождение, явно указанное в §26.2.


---

### Section 1 Implementation Checklist
- [x] Validate every glossary term against current wallet/runtime code paths and remove stale aliases.
- [x] Freeze canonical byte-order/encoding examples for each critical field (`asset_id`, `leaf_ad`, `tx_digest`).
- [x] Add cross-links from each term to the exact module that owns the behavior.
- [x] Add one negative test case per critical term mismatch (domain/context/order drift).
- [x] Create `docs/tx/glossary_source_map.md` mapping every glossary term to an owning Rust symbol.
- [x] For each glossary hash formula, add one code reference and one byte-order note.
- [x] Add one negative test per critical term mismatch in `crates/z00z_wallets/tests/`.
- [x] Verify no ambiguous aliases remain by searching `grep -R -n -E "owner_handle|receiver_secret|asset_id" docs specs crates`.

## 2) Роли доказательств: TxProof vs CheckpointProof


TxProof доказывает:

- корректность spending-логики (ownership, баланс commitments, fee, range-правила),
- **OWF для outputs**: каждый output *не “мёртвый”*, т.е. получатель сможет открыть Pedersen после включения в state.

TxProof **НЕ** доказывает membership в текущем state (это дорого/не нужно внутри каждой транзакции).

### CheckpointProof (глобальная корректность state-перехода)

CheckpointProof доказывает:

- переход `prev_root -> new_root`,
- корректное применение операций “удалить inputs / добавить outputs” к JMT,
- проверку “inputs существовали в prev_root” (membership),
- проверку “inputs не были потрачены между `prev_root` и current” через твой механизм `spent_delta` (вариант B1),
- что все принятые TxProof были валидны (или агрегаторный рекурсивный “batch proof”).

### Section 2 Acceptance Artifacts

| Check | Proof type | Runtime owner | Evidence |
| --- | --- | --- | --- |
| ownership, range, fee, structure | TxProof-local (`TxVerifier`) | `z00z_wallets::core::tx::tx_verifier` | `crates/z00z_wallets/src/core/tx/tx_verifier.rs` |
| prev_root transition + spent gate | CheckpointProof-global | `z00z_wallets::core::tx::state_update` | `crates/z00z_wallets/tests/test_phase24_gate.rs` |
| no state-transition fields in local verifier input | TxProof-local boundary | `TxVerifierImpl::verify_structure` | `crates/z00z_wallets/tests/test_spec_terms_guard.rs` |

### Section 2 Failure Matrix

| Scenario | Expected owner | Expected result |
| --- | --- | --- |
| wrong-root | CheckpointProof-global | reject with `PrevRoot` |
| missing-membership / already-spent | CheckpointProof-global | reject with spent-path error |
| invalid-OWF / bad local structure | TxProof-local | local verifier rejects package |

---

---

### Section 2 Implementation Checklist
- [x] Define executable acceptance criteria that separate TxProof-local checks from CheckpointProof-global checks.
- [x] Add explicit input/output artifacts for both proof types and pin required transcript public inputs.
- [x] Add failure matrix for wrong-root, missing-membership, and invalid-OWF scenarios.
- [x] Create conformance tests to ensure no membership logic leaks into TxProof pipeline.
- [x] Add a matrix in this spec: `check -> proof_type -> runtime_owner`.
- [x] Add tests proving membership logic is absent from TxProof path.
- [x] Add tests proving state-transition logic is absent from local Tx verifier path.
- [x] Validate matrix completeness with `grep -R -n -E "membership|state update|TxProof|CheckpointProof" specs crates`.

## Phase 3) Форматы данных

### 3.1 Stealth addressing model (protocol)

The Z00Z transaction protocol is **addressless on-chain**: no reusable recipient address is stored in `AssetLeaf_ECDH_v1`, and validators do not rely on any on-chain address field.

Instead, the receiver identity and the ability to perform one-sided / offline payments are provided by **off-chain stealth artifacts** that bind the required public data:

- `ReceiverCard_v1` (see §3.4)
- `PaymentRequest_v1` (see §3.5)

These artifacts are the canonical “recipient identifier” for wallet-to-wallet interoperability in one-sided flows.

### 3.1.1 Legacy key-address codecs (DEPRECATED)

The wallet codebase historically included Bech32m-encoded key-address containers (`Z00ZSingleAddress`, `Z00ZDualAddress`).

**Protocol decision:** these formats are **LEGACY** and **DEPRECATED**. Z00Z is transitioning to a stealth-only receiving protocol.

Normative rules:

- Implementations that claim compliance with this tx contract spec **MUST NOT** use `Z00ZSingleAddress` / `Z00ZDualAddress` as a receiving identifier.
- Wallet-to-wallet interoperability for receiving **MUST** be based on `ReceiverCard_v1` and/or `PaymentRequest_v1`.
- User-facing “send to” inputs **SHOULD** be restricted to stealth artifacts (cards/requests). If legacy key-address strings are encountered, applications **MUST** treat them as non-protocol inputs and either reject them or require an explicit, out-of-band migration step.

Rationale: the stealth model is defined by `owner_handle`, `view_pk`, `R_pub`, and the ECDH-derived `k_dh` (see §1, §3.2, and §11). A reusable key-address string is not part of the on-chain contract.

### 3.2 Asset leaf (публично в JMT/state)

```yaml
AssetLeaf_ECDH_v1:
  asset_id: bytes32        # hash_zk<AssetIdDomain>("", [s_out])
  serial_id: u32
  c_amount: bytes32        # Pedersen commitment encoding
  range_proof: bytes       # BulletproofsPlusService, RANGE_PROOF_BITS_V1 bits

  r_pub: bytes32           # ephemeral ECC point R = r*G
  enc_pack: bytes          # ZkPack_v1 ciphertext of AssetPackPlain (72 bytes)
  owner_tag: bytes32       # unlinkable tag (random-looking)
  tag16: u16               # 2-byte prefilter for fast wallet scanning (see §11)
```

**`tag16`** — short prefilter tag. Receiver checks `tag16` first to skip non-owned leaves without decrypting `enc_pack`. Generated as:
```
tag16 = hash_zk<WalletTag16HashProdDomain>("Z00Z/TAG16", [k_dh, leaf_ad])[0..2] as u16
```

**Unlinkability**: тут нет `owner_handle`, нет `view_pk`, нет адреса.

### 3.3 TxPackage (Phase 2 target: то, что приходит агрегатору)

```yaml
TxPackage_v1:
  prev_root: bytes32

  inputs:
    - asset_id: bytes32
      serial_id: u32

  outputs:
    - leaf: AssetLeaf_ECDH_v1

  receiver_cards:           # NOT stored on chain (only for verification time)
    - output_index: u32
      receiver_card: ReceiverCard_v1

  tx_proof: bytes           # STARK/FRI proof
```

> `receiver_cards` — это “свидетельство назначения”, полученное из офлайн визиток.

>
> **Security boundary (M4):** эта схема гарантирует **state‑unlinkability**, но **не гарантирует приватность от агрегатора/валидаторов** в notary‑модели: во время приёма TxPackage они видят `receiver_cards`.
>
> **Operational (MUST):** реализации агрегатора/валидаторов **MUST NOT** логировать `ReceiverCard` поля по умолчанию (и любые telemetry должны быть opt‑in и scrub identifiers).
>
> **TransportPrivacyOptions (SHOULD):**
>
> ```yaml
> TransportPrivacyOptions(SHOULD):
>   - submit_over: [Tor, I2P, mixnet]          # best-effort anonymity
>   - submission_channel: end_to_end_encrypted  # TLS + app-level encryption
>   - strip_receiver_cards_after_verify: true   # keep only what’s needed for checkpoint build
> ```

> Оно нужно агрегатору/валидаторам, чтобы проверить OWF. При твоей “нотариальной” модели его можно **не хранить** как публичный артефакт (в state оно не попадает).

### 3.4 ReceiverCard_v1 (wallet canonical encoding)

`ReceiverCard_v1` is an **off-chain signed artifact** used to bind `owner_handle` and `view_pk` for non-interactive stealth outputs.

### 3.4.1 Structure (logical fields)

```yaml
ReceiverCard_v1:
  version: u8                 # MUST be 1
  owner_handle: bytes32
  view_pk: bytes32             # compressed Ristretto point
  identity_pk: bytes32         # compressed Ristretto point
  card_id: bytes16_optional
  metadata: CardMetadata_optional
  signature: bytes64           # nonce[32] || s[32] (Tari KernelSignature)

CardMetadata:
  display_name: string_optional
  valid_until: u64_unix_optional
  contact: string_optional
  created_at: u64_unix
```

### 3.4.2 Canonical bytes encoding

Unsigned (signed message) bytes:

```text
u8   version
32   owner_handle
32   view_pk
32   identity_pk
u8   has_card_id (0|1)
16?  card_id (present if has_card_id=1)
u8   has_metadata (0|1)
..?  metadata (present if has_metadata=1; see below)
```

Full canonical encoding is `unsigned_bytes || signature[64]`.

Metadata encoding (when present):

```text
opt_string display_name
u8 has_valid_until (0|1)
u64? valid_until_le (present if has_valid_until=1)
opt_string contact
u64 created_at_le
```

`opt_string` encoding:

```text
u8 flag (0|1)
u32 len_le (present if flag=1)
len bytes utf8 (present if flag=1)
```

### 3.4.3 Signature (Phase 1 wallet implementation)

Wallet code signs `unsigned_bytes` via `sign_identity(identity_sk, unsigned_bytes, CARD_SIGN_CTX)` with:

- `CARD_SIGN_CTX = "Z00Z/CARD_v1"` (byte string)
- signature scheme: Tari `KernelSignature` (Ristretto Schnorr)
- signature bytes: `nonce_point_bytes32 || s_scalar_bytes32`

The wallet does NOT currently use consensus domain `RcardDomain("Z00Z/RCARD")` from `z00z_crypto`.

---

### 3.5 PaymentRequest_v1 (wallet canonical encoding)

`PaymentRequest_v1` is an **off-chain signed artifact** used for payment intent (QR/NFC). It includes `chain_id: u32` and is validated by the wallet before paying.

### 3.5.1 Structure (logical fields)

```yaml
PaymentRequest_v1:
  version: u8                 # MUST be 1
  owner_handle: bytes32
  view_pk: bytes32             # compressed Ristretto point
  identity_pk: bytes32         # compressed Ristretto point
  req_id: bytes32              # anti-DoS id
  chain_id: u32
  amount: u64_optional
  expiry: u64_unix
  metadata: RequestMetadata_optional
  signature: bytes64           # nonce[32] || s[32] (Tari KernelSignature)

RequestMetadata:
  memo: string_optional
  payment_id: bytes16_optional
  min_confirmations: u32_optional
  return_address: string_optional
  created_at: u64_unix
```

### 3.5.2 Canonical bytes encoding

Unsigned (signed message) bytes:

```text
u8   version
32   owner_handle
32   view_pk
32   identity_pk
32   req_id
4    chain_id_le
u8   has_amount (0|1)
8?   amount_le (present if has_amount=1)
8    expiry_le
u8   has_metadata (0|1)
..?  metadata (present if has_metadata=1; same opt_* conventions as ReceiverCard)
```

Full canonical encoding is `unsigned_bytes || signature[64]`.

### 3.5.3 Signature (Phase 1 wallet implementation)

Wallet code signs `unsigned_bytes` via `sign_identity(identity_sk, unsigned_bytes, REQUEST_SIGN_CTX)` with:

- `REQUEST_SIGN_CTX = "Z00Z/REQUEST_v1"` (byte string)
- signature scheme: Tari `KernelSignature` (Ristretto Schnorr)

The wallet does NOT currently use consensus domain `ReqV1Domain("Z00Z/REQv1")` from `z00z_crypto`.

### 3.6 Compatibility policy (legacy encoding)

- Legacy key-address payloads are treated as non-protocol inputs in Phase 1 runtime paths.
- Canonical receiving interoperability is fixed to `ReceiverCard_v1` and `PaymentRequest_v1` encodings.
- Canonical fixtures are versioned and stored under `crates/z00z_wallets/tests/fixtures/`.
- Malformed fixture tests (flag/length/endian drift) are mandatory and executable.


---

### Section 3 Implementation Checklist
- [x] Phase 3 Step 1: add canonical fixtures and round-trip/malformed tests for `ReceiverCard` and `PaymentRequest`.
- [x] Phase 3 Step 2: add versioned fixtures and round-trip tests for `AssetLeaf` and `TxPackage`.
- [x] Freeze canonical encoding vectors for `AssetLeaf`, `TxPackage`, `ReceiverCard`, and `PaymentRequest`.
- [x] Add deterministic round-trip tests (encode/decode/re-encode equality) for every format variant.
- [x] Add strict validation rules for optional fields presence bits and length-prefixed strings.
- [x] Add compatibility policy documenting which legacy encodings are rejected vs migrated.
- [x] Produce canonical fixtures for `AssetLeaf`, `TxPackage`, `ReceiverCard`, `PaymentRequest`.
- [x] Store fixtures under `crates/z00z_wallets/tests/fixtures/` with versioned filenames.
- [x] Add round-trip tests (`encode -> decode -> encode`) in crate-level tests.
- [x] Add malformed fixture tests for wrong length, wrong flag, wrong endian.

## Phase 4) Tx contract boundary: Phase 1 actual vs Phase 2 target

### 4.1 Phase 1 actual (Stage 4 minimal contract, frozen)

Phase 1 runtime uses a **minimal local transaction contract** for preparation and local validation.

The canonical Rust boundary is defined by `crates/z00z_wallets/src/core/tx/tx_verifier.rs`:

```rust
pub struct TxInputWire {
  pub asset_id: [u8; 32],
  pub serial_id: u32,
}

pub struct TxOutputWire {
  pub leaf: AssetWire,
}

pub struct TxWire {
  pub inputs: Vec<TxInputWire>,
  pub outputs: Vec<TxOutputWire>,
  pub fee: u64,
}

pub struct TxPackage {
  pub kind: String,          // MUST be "TxPackage"
  pub version: u8,           // MUST be non-zero
  pub tx: TxWire,
  pub tx_digest_hex: String, // 64 hex chars
  pub status: String,        // non-empty
}
```

Phase 1 verifier contract (current behavior):

- `verify_structure(tx_bytes)` validates kind/version/digest/status and non-empty outputs.
- `verify_signatures(tx_bytes)` validates optional owner signatures for each output asset.
- `verify_range_proofs(tx_bytes)` validates each output range proof.
- `verify_balance(tx_bytes)` validates non-empty inputs/outputs, rejects duplicate `(asset_id, serial_id)`, rejects zero output amounts, rejects `fee > output_sum`.

Phase 1 Stage 4 scope excludes:

- consensus `prev_root/new_root` processing,
- `TxProof_v1` / `CheckpointProof_v1`,
- `ChainClient`-based fee-rate integration,
- full `TxAssembler::assemble()` pipeline.

### 4.2 Phase 2 target (portable consensus package)

The following YAML describes the **target protocol package** for consensus alignment.

### Tx (portable) — YAML (Phase 2 target)

```yaml
TxPackage_v1:
  version: 1
  chain_id: u32    # ⚠️ Phase 1: ChainId(u8) в wallet.rs. Протокол резервирует u32 wire field.
  created_at: u64_unix_optional
  ctx_id: bytes16_optional

  prev_root: bytes32

  inputs:
    - asset_id: bytes32
      serial_id: u32

  outputs:
    - AssetLeaf_ECDH_v1: "<leaf object>"

  receiver_cards:
    - output_index: u32
      receiver_card: ReceiverCard_v1

  tx_proof: TxProof_v1
  tx_digest: bytes32   # H("Z00Z/TXDIGEST" || CanonicalEncode(TxPackage fields excluding proof))
```

> Примечание: `receiver_cards` НЕ обязаны храниться в state. Они нужны ровно для верификации OWF на этапе нотаризации.

---

### Proofs: TxProof vs CheckpointProof (Phase 2 target)

### TxProof (локальная математика)

TxProof **MUST** доказывать:

- корректность spend-части (ownership = `s_in` + `receiver_secret`),
- корректность баланса commitment-ов (inputs/outputs/fee),
- корректность range для `C_amount`,
- **OWF** для каждого output: что получатель сможет вычислить `k_dh`, расшифровать `enc_pack`, извлечь `(v, r_out, s_out)` и проверить `C_amount`.

TxProof **MUST NOT** включать membership (иначе каждая tx становится “привязанной к текущему root” и ломает оффлайн-DAG).

### CheckpointProof (глобальная корректность состояния)

CheckpointProof **MUST** доказывать:

- membership всех inputs в `prev_root`,
- корректное применение операций delete/insert к JMT,
- формирование `new_root`,
- корректность `spent_delta` и `created_delta`,
- что агрегатор принимал только валидные TxProof (обычно через агрегаторный batch/recursive proof).

---

### TxProof — YAML (Phase 2 target)

```yaml
TxProof_v1:
  version: 1
  suite_id: bytes16

  public:
    chain_id: u32    # ⚠️ Phase 1: ChainId(u8) в wallet.rs. Протокол резервирует u32 wire field.
    prev_root: bytes32
    tx_digest: bytes32

    inputs_commit: bytes32     # commit to ordered list of input refs
    outputs_commit: bytes32    # commit to ordered list of output leaf hashes
    fee_commit: bytes32_optional

  subproofs:
    spend_proof: bytes          # proves ownership constraints for all inputs
    balance_proof: bytes        # proves sum(inputs) == sum(outputs)+fee in commitments
    range_proofs: bytes         # per-output or aggregated
    owf_proofs:                # one per output (or aggregated)
      - bytes

  transcript_bind:
    merlin_final_challenge: bytes32
```

------

### CheckpointProof (membership + state transition) — YAML (Phase 2 target)

```yaml
CheckpointProof_v1:
  version: 1
  suite_id: bytes16

  header:
    height: u64
    prev_root: bytes32
    new_root: bytes32

  deltas:
    spent_delta:
      - asset_id: bytes32
    created_delta:
      - asset_id: bytes32
        leaf_hash: bytes32

  op_log_commit:
    op_log_hash: bytes32        # commit to ordered delete/insert operations
    tx_digests_hash: bytes32    # commit to included tx_digests

  proofs:
    membership_witnesses: bytes # membership paths or commitment to them inside proof
    state_update_proof: bytes   # STARK/FRI proof of correct JMT transition
    recursion_proof: bytes      # optional recursive wrapper

  transcript_bind:
    merlin_final_challenge: bytes32
```

------

### Fiat–Shamir transcripts (`merlin`) binding guidance

Это место реально критично, потому что большинство “невидимых” багов в ZK-системах — это **непривязанные контексты**.

### Общие правила (MUST)

- TxProof transcript **MUST** начинаться с жёсткого домена и версии:
  - `Transcript::new(b"Z00Z/TXPROOF/V1")`
- CheckpointProof transcript **MUST** иметь отдельный домен:
  - `Transcript::new(b"Z00Z/CHECKPOINT/V1")`
- В transcript **MUST** добавляться ВСЕ публичные входы в фиксированном порядке:
  - `chain_id`, `suite_id`, `prev_root`, `tx_digest`,
  - коммиты `inputs_commit`, `outputs_commit`,
  - для OWF: commit на `(R_pub, owner_tag, C_amount, asset_id, serial_id, leaf_ad_hash, enc_pack_hash)` для каждого output.
- Любые списки **MUST** иметь:
  - сначала длину,
  - затем элементы в каноничном порядке.
- Если у тебя есть “под-доказательства” (OWF per-output, spend, balance), то:
  - либо один transcript и “labels” (`append_message(b"OWF_i", ...)`),
  - либо строго вложенные transcripts с финальным коммитом родителю (но это сложнее).

### Практика (SHOULD)

- Делай `tx_digest` независимым от `tx_proof`, чтобы было dedupe и offline bundle удобно.
- Все `*_hash` внутри transcript — это хэши от каноничной сериализации, не “сырые структуры”.

------

### 4.3 Phase 1 -> Phase 2 field mapping (single source of truth)

| phase_1_field | phase_2_field | migration_rule |
| --- | --- | --- |
| `TxPackage.kind` | `TxPackage_v1.version` + package type marker | Keep `kind="TxPackage"` in Phase 1 only; remove in Phase 2 canonical package and bind type by schema version + domain. |
| `TxPackage.version (u8!=0)` | `TxPackage_v1.version (=1)` | Reject `0` in Phase 1; on cutover require exact `1` for Phase 2 package. |
| `TxPackage.tx.inputs[*].asset_id` | `TxPackage_v1.inputs[*].asset_id` | 1:1 copy in canonical order. |
| `TxPackage.tx.inputs[*].serial_id` | `TxPackage_v1.inputs[*].serial_id` | 1:1 copy in canonical LE scalar encoding. |
| `TxPackage.tx.outputs[*].leaf` | `TxPackage_v1.outputs[*].AssetLeaf_ECDH_v1` | Map by canonical leaf encoding, no semantic change. |
| `TxPackage.tx.fee` | `TxProof_v1.public.fee_commit` | Keep explicit fee in Phase 1; bind as commitment in Phase 2 proof public inputs. |
| `TxPackage.tx_digest_hex` | `TxPackage_v1.tx_digest (bytes32)` | Convert hex string -> bytes32 at migration boundary; reject non-hex and wrong length. |
| `TxPackage.status` | runtime-only lifecycle metadata | Keep in Phase 1 runtime only; exclude from canonical Phase 2 package hash domain. |
| Phase 1 implicit chain context | `TxPackage_v1.chain_id (u32)` | Introduce explicit `chain_id` on Phase 2 boundary; mixed payloads are rejected. |
| N/A in Phase 1 | `TxPackage_v1.prev_root` | Fill only from notarization boundary at Phase 2 cutover. |
| N/A in Phase 1 | `TxPackage_v1.receiver_cards[]` | Keep off-chain verification witness; never store in public state. |
| N/A in Phase 1 | `TxPackage_v1.tx_proof` | Attach only after prover integration (Phase 2). |

### 4.4 Migration tasks (non-breaking sequence)

1. Keep Stage 4 serializer locked to Phase 1 minimal schema (`kind`, `version`, `tx`, `tx_digest_hex`, `status`).
2. Reject mixed-schema payloads (`phase1 + phase2` fields in one package) at verifier boundary.
3. Add explicit boundary adapter: Phase 1 runtime package -> Phase 2 canonical package DTO.
4. Enable dual-read only in migration window: read Phase 1 runtime package internally, emit Phase 2 only on notarization boundary.
5. Remove Phase 1-only fields (`kind`, `status`, `tx_digest_hex`) from consensus-path payload once cutover criteria are met.

### 4.5 Backward compatibility and cutover criteria

- Backward compatibility window: runtime keeps Phase 1 minimal package until all validators and aggregator endpoints accept Phase 2 canonical boundary.
- Hard reject policy: any payload mixing Phase 1 runtime fields with Phase 2 proof/root fields is rejected.
- Cutover criteria:
  1. Phase 2 package parser/verifier deployed on all required nodes.
  2. Deterministic mapping tests (`phase_1_field -> phase_2_field`) are green in CI.
  3. TxProof/CheckpointProof transcript binding checks are green.
  4. Replay tests confirm no semantic drift for inputs/outputs/fee and tx digest mapping.

```mermaid
flowchart LR
  P1[Phase 1 TxPackage] --> G{Mixed schema?}
  G -- yes --> R[Reject]
  G -- no --> A[Phase boundary adapter]
  A --> P2[Phase 2 TxPackage_v1]
  P2 --> V[TxProof/Checkpoint verifier]
```



---

### Section 4 Implementation Checklist

- [x] Keep a single source-of-truth table mapping Phase 1 runtime fields to Phase 2 portable fields.
- [x] Add schema-version gates to reject mixed Phase 1/Phase 2 package semantics.
- [x] Implement integration checks proving Stage 4 emits only the frozen Phase 1 minimal contract.
- [x] Add migration tasks for introducing canonical portable package boundary without breaking current flow.
- [x] Keep one strict table: `phase_1_field -> phase_2_field -> migration_rule`.
- [x] Add explicit reject rule for mixed-schema payloads.
- [x] Verify Stage 4 outputs match only Phase 1 minimal schema.
- [x] Add a migration note with backward-compatibility impact and cutover criteria.

## Phase 5) Spend TxProof: constraints (ownership В3)


TxProof при трате inputs доказывает:

### Witness spend

- `receiver_secret`
- `s_in` для каждого input
- (и всё для баланса commitments)

### MUST constraints spend

1. `owner_handle == H("Z00Z/RID" || receiver_secret)`
2. derived view key:
   - `view_sk == H2Scalar("Z00Z/VIEW" || receiver_secret)`
3. восстановить `k_in` по input leaf:
   - `k_in = KDF("Z00Z/DH" || Encode(view_sk * R_in))`
4. связать ownership с leaf:
   - `owner_tag_in == H("Z00Z/TAG" || owner_handle || k_in)`
5. связать input с секретом монеты:
   - `asset_id_in == H("Z00Z/ASSET" || s_in)`
6. баланс:
   - `Σ C_in - Σ C_out - fee_commit == 0` (в твоей модели)
7. range-условия на outputs

**Почему sender не может потратить**, хотя он знал `r`, `k`, `s_out`, `v`, `r_out`:
у него нет `receiver_secret`, значит он не выполнит constraint (1) и не восстановит корректный `owner_handle`.

> ⚠️ **Wallet (Phase 1) vs ZK circuit:** Constraints 1–4 описывают формулы для **ZK-схемы Phase 2**, которая будет использовать consensus-домены (`ReceiverIdDomain("Z00Z/RID")`, `ViewKeyDomain("Z00Z/VIEW")`, `KdhDomain("Z00Z/DH")`, `OwnerTagDomain("Z00Z/TAG")`). Текущая кодовая база wallet (Phase 1) использует wallet-private домены с теми же context-строками, но другими prefix'ами (см. §1 и §26.2 T-1). До Phase 2 ZK-интеграции формулы constraint'ов выражают **намерение**, но не совпадают с wallet-реализацией byte-for-byte.

------

---

### Section 5 Implementation Checklist
- [x] Translate each spend constraint into explicit circuit-level witness/public-input declarations.
- [x] Add domain-separation assertions for ownership-related hashes in prover/verifier tests.
- [x] Add negative proofs for invalid `owner_tag`, wrong `asset_id`, and broken balance equations.
- [x] Freeze constraint ordering to prevent accidental transcript incompatibility.
- [x] Convert every constraint into `witness/public_input/domain` triplets.
- [x] Add constraint-order lock to prevent accidental reordering.
- [x] Add negative tests for wrong owner_tag, wrong asset_id, wrong balance equation.
- [x] Document error surface for each failed constraint.

### Section 5 Error Surface

| Constraint | Error variant | Failure meaning |
|---|---|---|
| `view_sk` derive from `receiver_secret` | `SpendRuleErr::BadView` | Receiver secret cannot derive a valid view scalar |
| `k_in` restore from `view_sk * R_in` | `SpendRuleErr::BadRPub` / `SpendRuleErr::BadDh` | Input ephemeral key is malformed or DH restore fails |
| `owner_tag_in` binding | `SpendRuleErr::BadOwnerTag` | Ownership hash does not match claimed input leaf |
| `asset_id_in` from `s_in` | `SpendRuleErr::BadAssetId` | Input secret does not match claimed asset id |
| `Σ C_in - Σ C_out - fee_commit == 0` | `SpendRuleErr::BadBalance` | Commitment equation is broken |
| output range conditions | `SpendRuleErr::BadRange` | Output range proof gate reports invalid range |

## Phase 6) CheckpointProof: процедура агрегатора


### 6.1 Что делает агрегатор

Для TxPackage с `prev_root` агрегатор должен:

1. Проверить TxProof (включая OWF outputs и spend inputs).
2. Проверить membership каждого input в `prev_root`.
3. Проверить “не потрачен после `prev_root`”:
   input `asset_id` не должен встречаться в `spent_delta` на интервале `prev_root → current`.
4. Применить state update:
   - удалить input leaves
   - добавить output leaves
5. Сформировать checkpoint:
   - `spent_delta += inputs.asset_id`
   - `created_delta += outputs.asset_id + leaf_hash`
6. Построить CheckpointProof, который всё это доказывает.

### 6.2 Почему DAG оффлайн-цепочки работают

Потому что входы проверяются относительно **указанного** `prev_root`, а “не был потрачен позже” проверяется через `spent_delta` интервала. Это позволяет транзакции, сделанной оффлайн, прийти позже, пока её inputs не были потрачены в сети после того `prev_root`.

------

---

### Section 6 Implementation Checklist
- [x] Implement deterministic aggregator state-transition pipeline with explicit step-by-step validations.
- [x] Add replay/double-spend interval checks backed by `spent_delta` test vectors.
- [x] Add checkpoint build tests that validate `prev_root -> new_root` consistency under batch loads.
- [x] Add rejection-path tests for stale inputs and malformed membership witnesses.
- [x] Implement and document ordered pipeline: verify -> membership -> delta checks -> update root.
- [x] Add deterministic replay test with identical input order.
- [x] Add stale-root and double-spend interval tests.
- [x] Add one end-to-end checkpoint build test with expected `new_root` fixture.

### Section 6 Runtime Notes

- Stage 6 runtime now writes deterministic fragment artifacts and `checkpoint_s6.json` with explicit `spent_delta` and `created_delta`.
- Ordered pipeline is locked in code path: `verify_frag -> check_member -> check_spent -> calc_new_root`.
- Rejection tests cover stale root, malformed membership witness, and interval double-spend.
- Batch-load test coverage validates deterministic `prev_root -> new_root` consistency on 16-fragment bundle.

## Phase 7) Rust-интерфейсы (skeleton)

# 3) `proofs/spend.rs`

Скелет spend-доказательства под твою В3-ownership:

- receiver доказывает знание `receiver_secret`
- из него derives `owner_handle` и `view_sk`
- на каждом input leaf вычисляет `k_in = KDF(view_sk * R_in)`
- проверяет `owner_tag_in == H(owner_handle, k_in)`
- плюс `asset_id_in == H(s_in)`
- плюс баланс commitments

```rust
// crates/z00z_wallets/src/proofs/spend.rs

use crate::delivery::stealth::{AssetId, OwnerHandle, OwnerTag, SerialId, AssetLeafEcdhV1};

#[derive(Clone, Debug)]
pub struct SpendInputRef {
    pub asset_id: AssetId,
    pub serial_id: SerialId,
    // membership witness is verified in CheckpointProof, not here
}

#[derive(Clone, Debug)]
pub struct SpendStatementV1 {
    pub prev_root: [u8; 32], // tx declares the root it is relative to

    pub inputs: Vec<SpendInputRef>,
    pub input_leaf_summaries: Vec<InputLeafSummary>, // minimal leaf fields required for ownership check

    pub outputs: Vec<AssetLeafEcdhV1>, // outputs are validated by OWF constraints inside TxProof

    pub fee: u64,
}

#[derive(Clone, Debug)]
pub struct InputLeafSummary {
    pub asset_id: AssetId,
    pub r_pub_bytes: [u8; 32], // CompressedRistretto bytes
    pub owner_tag: OwnerTag,
    pub c_amount: Vec<u8>,
}

#[derive(Clone, Debug)]
pub struct SpendWitnessV1 {
    pub receiver_secret: [u8; 32],
    pub s_in_list: Vec<[u8; 32]>, // secret coin keys for inputs
    // plus witnesses for balance / openings / range logic as you implement
}

/// Constraint builder hook (your STARK/FRI engine).
pub trait SpendConstraintSystem {
    type Var;
    fn public_bytes(&mut self, bytes: &[u8]) -> Self::Var;
    fn witness_bytes(&mut self, bytes: &[u8]) -> Self::Var;

    fn assert_eq(&mut self, a: Self::Var, b: Self::Var);

    fn hash32(&mut self, domain: &'static [u8], parts: &[Self::Var]) -> Self::Var;

    // ECC gadgets
    fn ecc_decompress(&mut self, compressed: Self::Var) -> Self::Var;
    fn ecc_mul(&mut self, scalar: Self::Var, point: Self::Var) -> Self::Var;
    fn ecc_compress(&mut self, point: Self::Var) -> Self::Var;

    // Commitment/balance gadgets (placeholders)
    fn pedersen_commit(&mut self, v: Self::Var, r_out: Self::Var) -> Self::Var;
    fn enforce_balance(&mut self, inputs: &[Self::Var], outputs: &[Self::Var], fee: Self::Var);
}

pub fn build_spend_constraints(cs: &mut impl SpendConstraintSystem, st: &SpendStatementV1, wit: &SpendWitnessV1) {
    // 1) owner_handle = H("Z00Z/RID" || receiver_secret)
    let receiver_secret = cs.witness_bytes(&wit.receiver_secret);
    let owner_handle = cs.hash32(b"Z00Z/RID", &[receiver_secret]);

    // 2) view_sk = H2Scalar("Z00Z/VIEW" || receiver_secret) -- placeholder: you’ll implement hash-to-scalar gadget
    // For now: keep as witness var in your engine if needed.

    // 3) For each input:
    //    - asset_id == H("Z00Z/ASSET" || s_in)
    //    - k_in = H("DH" || Compress(view_sk * R_in))
    //    - owner_tag == H("Z00Z/TAG" || owner_handle || k_in)
    for (i, leaf) in st.input_leaf_summaries.iter().enumerate() {
        let asset_id_pub = cs.public_bytes(&leaf.asset_id.0);
        let owner_tag_pub = cs.public_bytes(&leaf.owner_tag.0);
        let r_pub = cs.public_bytes(&leaf.r_pub_bytes);

        let s_in = cs.witness_bytes(&wit.s_in_list[i]);
        let asset_calc = cs.hash32(b"Z00Z/ASSET", &[s_in]);
        cs.assert_eq(asset_calc, asset_id_pub);

        // NOTE: k_in derivation requires view_sk gadget; leave as TODO.
        // TODO: implement view_sk derivation + mul(view_sk, R_in):
        // let R_point = cs.ecc_decompress(r_pub);
        // let dh_point = cs.ecc_mul(view_sk, R_point);
        // let dh_comp = cs.ecc_compress(dh_point);
        // let k_in = cs.hash32(b"Z00Z/DH", &[dh_comp]);
        // let tag_calc = cs.hash32(b"Z00Z/TAG", &[owner_handle, k_in]);
        // cs.assert_eq(tag_calc, owner_tag_pub);
    }

    // 4) Balance constraints placeholder (commitments, fee, etc.)
    // TODO: wire up your commitment/balance model
}
```

------

# 4) `checkpoint/state_update.rs`

Скелет “apply tx batch” к state и генерация `spent_delta`/`created_delta`. Тут именно твой **B1-подход**: membership и “не потрачен после” живут на чекпойнтах.

```rust
// crates/z00z_wallets/src/checkpoint/state_update.rs

use crate::delivery::stealth::{AssetId, AssetLeafEcdhV1};

#[derive(Clone, Debug)]
pub struct CreatedEntry {
    pub asset_id: AssetId,
    pub leaf_hash: [u8; 32],
}

#[derive(Clone, Debug)]
pub struct CheckpointV1 {
    pub height: u64,
    pub prev_root: [u8; 32],
    pub new_root: [u8; 32],

    pub spent_delta: Vec<AssetId>,
    pub created_delta: Vec<CreatedEntry>,

    pub checkpoint_proof: Vec<u8>, // your recursive proof blob
}

#[derive(thiserror::Error, Debug)]
pub enum StateUpdateError {
    #[error("input not found in prev_root: {0:?}")]
    MissingInput(AssetId),

    #[error("input was already spent after declared prev_root: {0:?}")]
    SpentAfterPrevRoot(AssetId),

    #[error("txproof invalid")]
    InvalidTxProof,

    #[error("other: {0}")]
    Other(String),
}

/// Abstract over your JMT implementation.
pub trait AssetState {
    fn root(&self) -> [u8; 32];

    /// Get full leaf (or leaf hash + fetch) for membership checks.
    fn get_leaf(&self, id: &AssetId) -> Option<AssetLeafEcdhV1>;

    fn remove_leaf(&mut self, id: &AssetId);
    fn insert_leaf(&mut self, leaf: AssetLeafEcdhV1);

    /// Hash leaf exactly as the state commits it.
    fn leaf_hash(&self, leaf: &AssetLeafEcdhV1) -> [u8; 32];
}

/// TxPackage summary needed for checkpoint update.
#[derive(Clone, Debug)]
pub struct TxPackageSummary {
    pub prev_root: [u8; 32],
    pub inputs: Vec<AssetId>,
    pub outputs: Vec<AssetLeafEcdhV1>,
    pub tx_proof: Vec<u8>,
}

/// Hook to your proof verifier (TxProof).
pub trait TxProofVerifier {
    fn verify_tx_proof(&self, tx: &TxPackageSummary) -> bool;
}

/// Hook to your “spent after prev_root” checker.
/// For B1 you typically maintain cumulative/segment structures per checkpoint.
pub trait SpentDeltaIndex {
    /// Return true if asset_id appears in spent set between (prev_root_exclusive .. current_root_inclusive).
    fn is_spent_in_interval(&self, prev_root: [u8; 32], current_root: [u8; 32], asset_id: &AssetId) -> bool;
}

/// Apply a batch of tx packages to state and produce a new checkpoint.
/// Membership is checked here (not in TxProof).
pub fn apply_batch_and_build_checkpoint(
    height: u64,
    state: &mut impl AssetState,
    txs: &[TxPackageSummary],
    tx_verifier: &impl TxProofVerifier,
    spent_index: &impl SpentDeltaIndex,
) -> Result<CheckpointV1, StateUpdateError> {
    let prev_root = state.root();
    let mut spent_delta: Vec<AssetId> = Vec::new();
    let mut created_delta: Vec<CreatedEntry> = Vec::new();

    for tx in txs {
        // 1) TxProof validity (includes OWF + spend logic)
        if !tx_verifier.verify_tx_proof(tx) {
            return Err(StateUpdateError::InvalidTxProof);
        }

        // 2) Inputs must exist in declared prev_root snapshot
        // In a real implementation, you verify membership proofs against tx.prev_root, not current.
        // Here skeleton assumes state corresponds to prev_root at batch start.
        for inp in &tx.inputs {
            let leaf = state.get_leaf(inp).ok_or(StateUpdateError::MissingInput(*inp))?;

            // 3) "not spent after prev_root" check (B1)
            if spent_index.is_spent_in_interval(tx.prev_root, prev_root, inp) {
                return Err(StateUpdateError::SpentAfterPrevRoot(*inp));
            }

            // 4) Apply removal
            state.remove_leaf(inp);
            spent_delta.push(*inp);

            // Optionally: keep leaf for audit log
            let _ = leaf;
        }

        // 5) Apply outputs
        for out in &tx.outputs {
            let h = state.leaf_hash(out);
            state.insert_leaf(out.clone());
            created_delta.push(CreatedEntry { asset_id: out.asset_id, leaf_hash: h });
        }
    }

    let new_root = state.root();

    // 6) Build checkpoint proof (stub)
    // TODO: call your recursive proof pipeline over:
    // - prev_root, new_root
    // - membership checks performed
    // - spent_delta, created_delta
    // - tx_proof validity
    let checkpoint_proof = vec![];

    Ok(CheckpointV1 {
        height,
        prev_root,
        new_root,
        spent_delta,
        created_delta,
        checkpoint_proof,
    })
}
```

------



---

### Section 7 Implementation Checklist
- [x] Replace all remaining skeleton signatures with compile-checked interfaces aligned to current crates.
- [x] Add trait-level error contracts with typed errors and deterministic failure semantics.
- [x] Add module ownership table to prevent duplicated logic across wallet/core/simulator.
- [x] Add API stability notes (what is frozen in Phase 1 vs extension points for Phase 2).
- [x] Replace placeholder signatures with compile-checked interfaces.
- [x] Remove or gate non-compiling skeleton imports.
- [x] Add trait docs for input/output invariants.
- [x] Ensure interfaces do not leak unstable internals across crates.

### Section 7 Ownership Table

| Boundary | Owner crate | MUST responsibilities | MUST NOT |
|---|---|---|---|
| Spend interface (`SpendStmtV1`, `SpendCs`, `build_spend_cons`) | `z00z_wallets` | Bind spend statement/witness, expose typed interface errors, keep deterministic call order. | No state membership checks, no spent-interval checks. |
| Checkpoint state update (`TxPkgSum`, `AssetState`, `SpentIdx`, `apply_batch_cp`) | `z00z_wallets` | Validate `prev_root`, enforce input/output shape, call tx-proof hook, apply deltas. | No consensus storage internals leakage, no direct proof backend assumptions. |
| Canonical asset and leaf domain models | `z00z_core` | Provide stable `AssetId` and `AssetLeaf` wire/domain contracts. | No wallet-private witness handling. |
| Scenario execution and runtime orchestration | `z00z_simulator` | Execute staged flows and checkpoint runtime paths using stable wallet/core interfaces. | No duplicated spend/checkpoint logic that diverges from wallet interfaces. |

### Section 7 API Stability Notes

- Frozen in Phase 1:
  - `SpendStmtV1`, `SpendWitV1`, `SpendInRef`, `InputLeafSum` structure shape and field types.
  - `TxPkgSum`, `CheckpointV1`, `CreatedEnt` structure shape and field types.
  - Trait error enums: `SpendCsErr`, `SpendIfcErr`, `TxProofErr`, `SpentIdxErr`, `StateErr`.
  - Deterministic call order: `bind_root -> prove_input* -> check_bal` and checkpoint apply sequence inside `apply_batch_cp`.
- Phase 2 extension points:
  - Extend internals of `SpendCs` backend gadget implementation without changing public trait method signatures.
  - Replace empty `cp_proof` placeholder generation with recursive proof builder while preserving `CheckpointV1` envelope.
  - Add optional metadata via new versioned structs, not by mutating V1 field semantics.

## Phase 8) Граница ответственности (сводка)

| Что проверяется | Где |
|---|---|
| Владение монетой (`receiver_secret` + `s_in`) | TxProof / spend.rs |
| OWF outputs (receiver сможет открыть Pedersen) | TxProof / owf.rs |
| Баланс commitments (`Σ C_in == Σ C_out + fee`) | TxProof / balance |
| Range-proofs | TxProof / range |
| Membership inputs в `prev_root` | CheckpointProof / state_update.rs |
| "Не потрачен после prev_root" (B1 spent_delta) | CheckpointProof / state_update.rs |
| Корректность JMT transition (`prev_root → new_root`) | CheckpointProof |
| Агрегация batch TxProofs | CheckpointProof (recursive) |

---

### Section 8 Implementation Checklist
- [x] Convert responsibility summary into enforceable module boundaries with explicit MUST/MUST NOT checks.
- [x] Add architecture lint checks for forbidden cross-layer dependencies.
- [x] Add review checklist for new code touching tx flow to enforce boundary rules.
- [x] Add escalation policy for boundary violations detected in CI.
- [x] Add one owner per module boundary (`wallet`, `core`, `simulator`, `crypto`).
- [x] Add CI check preventing forbidden cross-layer imports.
- [x] Add architecture review checklist for PRs touching tx pipeline.
- [x] Add explicit escalation rule for boundary violations.

### Section 8 Boundary Owners

| Boundary | Owner | Scope |
| --- | --- | --- |
| `wallet` | `z00z_wallets` | Tx orchestration, TxProof-local interface wiring, wallet-facing tx adapters |
| `core` | `z00z_core` | Canonical asset/state domain contracts and stable wire/domain models |
| `simulator` | `z00z_simulator` | Scenario execution runtime and stage orchestration |
| `crypto` | `z00z_crypto` | Cryptographic primitives, domain-separated hashes, proof primitives |

### Section 8 CI Escalation Flow

When boundary CI fails (`tx-boundary-check`):

1. Block merge.
2. Apply label `architecture-boundary-violation`.
3. Request review from the affected boundary owner.
4. Require a follow-up commit restoring boundary rules before re-run.

## Phase 9) On-chain события: EventSpent / EventCommitment

При применении TxPackage к состоянию цепочки атомарно эмитируются две группы событий.

### EventSpent

Публикуется для каждого потреблённого входного Asset:

```yaml
EventSpent:
  asset_id: <asset_id потреблённого Asset>    # добавляется в SpentIdx
  burned_commitment: <C_in>                   # ссылочный Pedersen-коммитмент
```

### EventCommitment

Публикуется для каждого созданного выходного Asset:

```yaml
EventCommitment:
  asset_id:   <новый asset_id>
  commitment: <Pedersen C_out>
  jmt_path:   <JMT inclusion path после вставки>
```

### 9.1 — Инвариант атомарности

**MUST** — EventSpent и EventCommitment для одного TxPackage MUST применяться атомарно. Частичное применение (EventSpent без EventCommitment или наоборот) MUST отклоняться как невалидное.

### 9.2 — Отношение TxPackage → события

`TxPackage` — это *триггер* (данные пользователя); `EventSpent` + `EventCommitment` — это *изменения состояния*, фиксируемые валидаторами в блоке. После консенсуса `EventSpent` помечает входной Asset как безвозвратно недействительный; `EventCommitment` регистрирует новые Assets в JMT.

---

### Section 9 Implementation Checklist
- [x] Define canonical event schemas and versioning rules for `EventSpent` and `EventCommitment`.
- [x] Add event emission invariants to guarantee consistent ordering and dedupe behavior.
- [x] Add indexer-facing validation examples for malformed or partial event payloads.
- [x] Add replay tests validating event-derived state reconstruction.
- [x] Freeze event field order and type widths.
- [x] Add event schema tests and reject unknown required-field omissions.
- [x] Add replay test: rebuild state from event stream.
- [x] Add dedupe/idempotency tests for event consumers.

## Phase 10) Multi-input / Multi-output

TxPackage МОЖЕТ потреблять N ≥ 1 входов и создавать M ≥ 1 выходов.

### 10.1 — Ограничение баланса (Pedersen)

$$\sum_{i=1}^{N} C_{\text{in},i} = \sum_{j=1}^{M} C_{\text{out},j} + C_{\text{fee}}$$

Следует из линейности коммитментов Педерсена. CheckpointProof MUST выполнять эту проверку над всеми значениями.

### 10.2 — Правила входов

- Каждый input MUST быть в состоянии `Confirmed`.
- Все `asset_id` входов MUST быть уникальны в пределах одного TxPackage (нет дублей).
- TxProof MUST доказывать владение каждым входом одновременно (joint spend statement).

### 10.3 — Правила выходов

- Минимум один output MUST существовать (M ≥ 1).
- `asset_id` всех выходов MUST быть новыми: не в `SpentIdx` и не в текущем JMT.
- Типичный паттерн: один output получателю, один output сдачи отправителю.

### 10.4 — Rust-скелет (multi-input)

```rust
/// Joint spend statement for N inputs.
pub struct MultiSpendStatement {
    /// One entry per consumed input Asset; len >= 1.
    pub inputs: Vec<SpendInputRef>,
    /// One entry per created output Asset; len >= 1.
    pub outputs: Vec<OutputRef>,
    /// Pedersen blinding factor for each input (witness, kept in ZK).
    pub input_blindings: Vec<Hidden<Z00ZScalar>>,  // MUST: use Hidden<> to prevent key leaks
}

// ⚠️ Аудит-замечание: оригинальный скелет использовал Vec<RistrettoSecretKey> — заменено на
// Vec<Hidden<Z00ZScalar>> согласно security policy проекта (чувствительные данные ДОЛЖНЫ
// оборачиваться в Hidden<T> для предотвращения утечек через Debug/Clone/логирование).

// MUST: inputs.len() >= 1 && outputs.len() >= 1
// MUST: Sigma(value(input_i)) == Sigma(value(output_j)) + fee
```

---

### Section 10 Implementation Checklist
- [x] Add deterministic coin-selection scenarios for multiple inputs/outputs with stable fee/change outcomes.
- [x] Add uniqueness constraints and tests for `serial_id` and output derivation under batching.
- [x] Add overflow/underflow protections for aggregated amount and commitment calculations.
- [x] Add privacy regression tests for linkability signals under varied output topologies.
- [x] Add deterministic selection fixtures for 2-in/2-out, 3-in/2-out, 5-in/3-out.
- [x] Add overflow guards for aggregate amount and fee arithmetic.
- [x] Add uniqueness tests for serial_id per output under shared sender randomness.
- [x] Add privacy regression tests for linkability heuristics.

## Phase 11) Canonical derivation chain (code-derived)

Этот раздел фиксирует **точные формулы** из реализации. Все формулы должны совпадать между wallet и proof circuit.

### 11.1 — s_out: секрет монеты

`s_out` НЕ является просто случайным числом. Он детерминированно вычисляется из ECDH-сессии:

```
s_out = hash_zk<SOutProdDomain>("Z00Z/S_OUT", [k_dh, r_pub, serial_id_le4])
```

> ⚠️ **Область действия:** `SOutProdDomain = "z00z.wallet.stealth.s_out.prod.v1"` — это **wallet-private** домен (в `z00z_wallets/src/core/domains.rs`), НЕ consensus-домен. `s_out` является witness-данными; ZK-схема верифицирует только `asset_id = hash<AssetIdDomain>(s_out)`, а не саму деривацию `s_out`.

Где `serial_id_le4 = serial_id.to_le_bytes()` (4 байта, LE).

**MUST** — `s_out` MUST включать `r_pub` и `serial_id` в деривацию. Без них несколько outputs с одним `k_dh` могут иметь одинаковый `s_out`.

### 11.2 — asset_id из s_out

```
asset_id = hash_zk<AssetIdDomain>("", [s_out])
```

Примечание: первый аргумент — пустая строка (домен задан через тип `AssetIdDomain`).

### 11.3 — leaf_ad: AAD для enc_pack

`leaf_ad` привязывает `enc_pack` к конкретному листу. Изменение любого поля инвалидирует аутентификацию при расшифровке.

**Canonical 132-byte preimage layout (consensus-critical):**

```
[0..32]   asset_id
[32..36]  serial_id (u32 LE)
[36..68]  r_pub
[68..100] owner_tag
[100..132] c_amount
```

Вычисление:
```
leaf_ad = hash_zk<WalletLeafAdHashProdDomain>("Z00Z/LEAFAD", [asset_id, serial_le4, r_pub, owner_tag, c_amount])
```

**MUST** — порядок полей в preimage менять НЕЛЬЗЯ. Это consensus-critical (OWF circuit §5 constraint 4).

### 11.4 — Полная цепочка деривации (sender)

```
r          ←$ random scalar
R_pub      = r * G
dh         = r * view_pk          // ECDH
k_dh       = hash_zk<WalletDhKeyHashProdDomain>("Z00Z/DH", [encode(dh)])  // wallet-private domain
s_out      = hash_zk<SOutProdDomain>("Z00Z/S_OUT", [k_dh, R_pub_bytes, serial_le4])
asset_id   = hash_zk<AssetIdDomain>("", [s_out])  // domain "Z00Z/ASSET"
owner_tag  = hash_zk<WalletOwnerTagHashProdDomain>("Z00Z/TAG", [owner_handle, k_dh])  // wallet-private domain
c_amount   = Commit(value, blinding)  // Pedersen
leaf_ad    = hash_zk<WalletLeafAdHashProdDomain>("Z00Z/LEAFAD", [asset_id, serial_le4, R_pub_bytes, owner_tag, c_amount])
enc_pack   = ZkPack::encrypt(k_dh, leaf_ad, R_pub_bytes, asset_id, serial_id, payload)
             // internally: derive_pack_key   = hash_zk<PackKeyProdDomain>("Z00Z/PACKKEY", [k_dh, asset_id, serial_le4])
             //             derive_pack_nonce = hash_zk<PackNonceProdDomain>("Z00Z/PACKNONCE", [leaf_ad, r_pub, asset_id, serial_le4])
             // Both use wallet-private domains (NOT PackKeyDomain / PackNonceDomain consensus equivalents)
tag16      = hash_zk<WalletTag16HashProdDomain>("Z00Z/TAG16", [k_dh, leaf_ad])[0..2] as u16
```

> ⚠️ **Фасад facade_kdf:** в `z00z_wallets` функция `kdf::compute_leaf_ad` (через `facade_kdf::*`) принимает аргументы в порядке `(r_pub, asset_id, serial_id, ...)`, а каноническая `compute_leaf_ad` в `stealth/tag.rs` принимает `(asset_id, serial_id, r_pub, ...)`. Функционально обе эквивалентны (фасад перепорядичивает внутренне), но preimage-размещение каноническое (как в §11.3).

> ⚠️ **Консенсус-уровень vs wallet-private домены:** `z00z_crypto/kdf.rs` содержит отдельную функцию `derive_leaf_ad` с доменом `LeafAdDomain("Z00Z/LEAFAD")` + пустой context `""`. Эта функция предназначена для ZK-схемы (consensus). В настоящее время wallet использует `WalletLeafAdHashProdDomain` (другой prefix хэша). Они дают **разные хэши** для одинаковых входов. Расхождение должно быть устранено перед Phase 2 ZK-интеграцией.

### 11.5 — Migration compatibility notes (domain cutover)

Canonical migration vectors are frozen in:

- `crates/z00z_wallets/tests/fixtures/phase11_chain.json`
- `crates/z00z_wallets/tests/fixtures/phase11_sender.json`
- `crates/z00z_wallets/tests/fixtures/phase11_migration.json`

Current frozen drift vector (`serial_id=1`, fixed `recv_sec`, fixed `r_seed`, zero `c_amount`):

- `wallet_leaf_ad = 730870bd7fd38d98759389efaadf277993a8bdbaaa23fb376fb181f72af8cf15`
- `crypto_leaf_ad = 6d2c2c8fd73e23eeb7b52ee5dac55d14d0d232f9002253aa5f1e80c9c4424543`

Explicit break conditions for domain cutover:

1. If `wallet_leaf_ad` changes for the same vector without an explicit version bump, treat as consensus-breaking drift.
2. If wallet and crypto `leaf_ad` unexpectedly become equal without migration flag/version gate, treat as uncontrolled domain merge.
3. Any change in domain tag/prefix/context for `k_dh`, `owner_tag`, `leaf_ad`, `tag16`, `pack_key`, `pack_nonce` requires:
  - new versioned vectors,
  - migration test updates,
  - explicit backward-compatibility policy in this section.

---

### Section 11 Implementation Checklist
- [x] Freeze full derivation chain test vectors (`r`, `R_pub`, `k_dh`, `s_out`, `asset_id`, `leaf_ad`, `tag16`).
- [x] Add cross-crate parity tests to detect domain/context drift between wallet and crypto crates.
- [x] Add deterministic transcript fixtures for sender and receiver derivation paths.
- [x] Add compatibility notes for future domain migration with explicit break conditions.
- [x] Freeze vectors for `r`, `R_pub`, `k_dh`, `s_out`, `asset_id`, `leaf_ad`, `tag16`.
- [x] Add parity tests across `wallet` and `crypto` derivation APIs.
- [x] Add explicit mismatch test for domain/context divergence.
- [x] Add migration vectors for future domain cutover.

## Phase 12) AssetPackPlain: wire format (consensus-critical)

Полезная нагрузка внутри `enc_pack`. Размер **СТРОГО 72 байта** — часть OWF circuit contract (spec §4.5.6).

```
Offset  Size  Field
──────  ────  ─────────────────────────────────
0       8     value     (u64, LE)
8       32    blinding  ([u8; 32])
40      32    s_out     ([u8; 32])
```

Типы:
```rust
pub struct AssetPackPlain {
    pub value:    u64,
    pub blinding: [u8; 32],
    pub s_out:    [u8; 32],
}
pub const SIZE: usize = 8 + 32 + 32; // = 72
```

**MUST** — менять offset'ы или endianness НЕЛЬЗЯ без смены версии формата.

**MUST NOT** — `serial_id` в 72-байтовый пакет НЕ входит (он в `leaf_ad` AAD и в деривации `s_out`).

Compatibility policy (Phase 12):

- Any layout change in `AssetPackPlain` (offsets, field widths, endianness, total size) is a breaking wire-format change.
- Such change MUST increment payload/wire version and introduce a new decode path.
- Existing `V1` parser behavior MUST remain backward-compatible for already published `72-byte` payloads.
- Golden vectors in `crates/z00z_core/tests/vectors/asset_pack_vectors.yaml` MUST be extended (not overwritten) for each new version.

---

### Section 12 Implementation Checklist
- [x] Lock 72-byte payload contract with golden fixtures and strict offset assertions.
- [x] Add decode rejection tests for wrong length, wrong endian, and malformed payload bytes.
- [x] Add fuzz tests for parser robustness while preserving deterministic failure reasons.
- [x] Document version-bump policy for any future payload shape changes.
- [x] Keep golden binaries for 72-byte payload across multiple value/blinding pairs.
- [x] Add strict parser reject tests for `len != 72`.
- [x] Add endian conformance tests for value field.
- [x] Add compatibility note requiring version bump for any layout change.

## Phase 13) Blinding arithmetic

### 13.1 — Балансировка слепляющих факторов

Для корректного Pedersen-баланса на стороне sender:

```
r_change = r_in - (r_out_1 + r_out_2 + ... + r_out_N)
```

Реализовано в `balance::balance_blindings(r_in, r_outs)` — возвращает `r_change` для output сдачи.

Проверка баланса (для verifier):
```
verify: Σ r_in == Σ r_out_j + r_fee
```

### 13.2 — Инвариант гомоморфизма

Следует из линейности Pedersen и уже проверен в `commitment_homomorphism_test.rs`:

```
Commit(v1, r1) + Commit(v2, r2) == Commit(v1+v2, r1+r2)
```

Поэтому balance commitment CheckpointProof достаточно проверить через суммирование точек — не нужно раскрывать `v` и `r`.

---

### Section 13 Implementation Checklist
- [x] Add algebraic property tests for blinding balance across single and multi-output scenarios.
- [x] Add commitment homomorphism tests for edge-value boundaries and random blinding sets.
- [x] Add explicit invariants for fee commitment handling and verify failure diagnostics.
- [x] Add CI guards to block changes that break balance equations.
- [x] Add property tests: `sum(in_blind) == sum(out_blind)+fee_blind`.
- [x] Add randomized tests with varying output counts.
- [x] Add failure tests for overflow/invalid scalar conversion.
- [x] Keep homomorphism tests in release mode CI lane.

## Phase 14) Spending pipeline: статус реализации (Phase 1)

| Компонент | Модуль | Статус | Что реализовано |
|-----------|--------|--------|------------------|
| Output builder | `tx/builder.rs` | ✅ Done | `build_output_leaf()`, `build_output_with_blind()` |
| Blinding balance | `tx/balance.rs` | ✅ Done | `balance_blindings()`, `verify_blind_balance()`, `verify_tx_balance()` |
| Range proof | `tx/prover.rs` | ✅ Done | `ProverImpl` → `BulletproofsPlusService` |
| Signer (Schnorr) | `tx/signer.rs` | ✅ Done | `SignerImpl` → `RistrettoSchnorr` |
| Asset selector | `tx/asset_selector.rs` | ✅ Done | `MinInputs` \| `MinFees` \| `MaxPrivacy` |
| ECDH output | `tx/builder.rs` | ✅ Done | `sender_create_output_for(card, amount, serial_id: u32)` |
| Fee estimator | `tx/fee_estimator.rs` | ✅ Phase 1 functional | Weight-based estimate from tx JSON (`inputs/outputs/kernels`), static tiers 0.8/1.0/1.5×, static mode and network mode with TTL cache (`update_rates` fetches only in network mode). Details: §16 |
| Tx assembler | `tx/tx_assembler.rs` | ⏳ Phase 1 stub | `assemble()` / `sum_inputs()` / `sum_tx_outputs()` / `verify_balance()` return not-implemented; helper delegations (`check_commitment_balance`, `estimate_fee`, `verify_with`) are implemented |
| Tx verifier | `tx/tx_verifier.rs` | ✅ Phase 1 functional | Verifies `TxPackage/TxWire` structure + signatures + range proofs + package balance checks (`inputs/outputs`, duplicates, zero-amount, fee bound) |
| Tx identity | `tx/mod.rs` re-exports (`tx/pay_ref.rs`, `tx/tx_id.rs`) | ✅ Done | Unified facade for PayRef + TxId |

### 14.1 — Стратегии выбора входов

```rust
pub enum SelectionStrategy {
    MinInputs,   // меньше входов → меньше размер tx
    MinFees,     // Phase 1: то же что MinInputs
    MaxPrivacy,  // рандомизированный порядок выбора
}
```

Вход MUST быть в состоянии `Confirmed` перед выбором (§9).

### 14.2 — PayRef (квитанция платежа)

`PayRef` — детерминированный 32-байтовый идентификатор для квитанций и offline-доказательств:

```
pay_ref = hash("z00z.wallets.tx.pay_ref.v1", [block_hash, output_hash])
```

НЕ является on-chain объектом; используется wallet для корреляции без раскрытия структуры кошелька.

### 14.3 — Z00ZTxId (компактный DB-идентификатор)

`Z00ZTxId` — u64, вычисленный как `domain_hash<TxIdHasher>(mac_key, output_hash)[0..8]`, domain: `"z00z.wallets.tx_id.v1"` (BLAKE2b domain-separated hash, NOT RFC-2104 HMAC).

> ⚠️ **Аудит-замечание:** ранее ошибочно указывалось «HMAC» — в `tx_id.rs` используется `DomainHasher<TxIdHasher>` (BLAKE2b с доменной сепарацией), а не RFC-2104 HMAC.

**MUST NOT** использовать для криптографических целей или как уникальный on-chain идентификатор — только для индексации в локальной DB wallet.

### 14.4 — Component status matrix (owner + readiness)

| Component | Status | Owner | Ready criteria | Blocking dependency |
| --- | --- | --- | --- | --- |
| Output builder (`tx/builder.rs`) | frozen | wallet | deterministic output leaf build with valid `enc_pack`, `range_proof`, `c_amount` | none |
| Blinding balance (`tx/balance.rs`) | frozen | wallet | `sum(in_blind) == sum(out_blind) + fee_blind` and fee commitment diagnostics pass | none |
| Range proof (`tx/prover.rs`) | frozen | crypto | create/verify proof roundtrip and tamper rejection pass | none |
| Signer (`tx/signer.rs`) | frozen | wallet | sign/verify path returns valid signature bytes and accepts correct public key | none |
| Asset selector (`tx/asset_selector.rs`) | frozen | wallet | strategy-based selection returns enough amount and deterministic change formula | none |
| ECDH output (`tx/builder.rs::sender_create_output_for`) | frozen | wallet | receiver card path builds decryptable stealth leaf with non-zero `asset_id` | none |
| Fee estimator (`tx/fee_estimator.rs`) | partial | wallet | static/network mode returns bounded tiered fees and TTL update behavior stays deterministic | ChainClient/fee source integration |
| Tx assembler (`tx/tx_assembler.rs`) | target | wallet | `assemble/sum_inputs/sum_tx_outputs/verify_balance` implemented over canonical DTOs | portable tx DTO + proof-path integration |
| Tx verifier (`tx/tx_verifier.rs`) | frozen | wallet | structure + balance + signature + range checks pass on Phase 1 package | none |
| Tx identity (`tx/pay_ref.rs`, `tx/tx_id.rs`) | frozen | wallet | payref deterministic verification and tx-id deterministic derive/verify pass | none |

### 14.5 — Source and integration test links

| Component | Source | Integration test |
| --- | --- | --- |
| Output builder | `crates/z00z_wallets/src/core/tx/builder.rs` | `crates/z00z_wallets/tests/test_phase14_pipeline.rs::test_builder_live` |
| Blinding balance | `crates/z00z_wallets/src/core/tx/balance.rs` | `crates/z00z_wallets/tests/test_phase14_pipeline.rs::test_balance_live` |
| Range proof | `crates/z00z_wallets/src/core/tx/prover.rs` | `crates/z00z_wallets/tests/test_phase14_pipeline.rs::test_prover_live` |
| Signer | `crates/z00z_wallets/src/core/tx/signer.rs` | `crates/z00z_wallets/tests/test_phase14_pipeline.rs::test_signer_live` |
| Asset selector | `crates/z00z_wallets/src/core/tx/asset_selector.rs` | `crates/z00z_wallets/tests/test_phase14_pipeline.rs::test_selector_live` |
| ECDH output | `crates/z00z_wallets/src/core/tx/builder.rs` | `crates/z00z_wallets/tests/test_phase14_pipeline.rs::test_ecdh_out_live` |
| Fee estimator | `crates/z00z_wallets/src/core/tx/fee_estimator.rs` | `crates/z00z_wallets/tests/test_phase14_pipeline.rs::test_fee_est_live` |
| Tx verifier | `crates/z00z_wallets/src/core/tx/tx_verifier.rs` | `crates/z00z_wallets/tests/test_phase14_pipeline.rs::test_verifier_live` |
| Tx identity | `crates/z00z_wallets/src/core/tx/pay_ref.rs`, `crates/z00z_wallets/src/core/tx/tx_id.rs` | `crates/z00z_wallets/tests/test_phase14_pipeline.rs::test_id_payref_live` |

### 14.6 — Phase 2 blocking map

```mermaid
flowchart LR
  A[Tx assembler target] --> B[Canonical tx DTO]
  A --> C[Proof-path integration]
  D[Fee estimator partial] --> E[Chain fee source]
  D --> F[TTL cache policy]
  C --> G[Phase 2 rollout gate]
```

### 14.7 — Weekly status review for `⏳` rows

- Weekly review item: owner `wallet` MUST reassess `tx_assembler.rs` and `fee_estimator.rs` blockers, update readiness criteria, and record delta in this section.

---

### Section 14 Implementation Checklist
- [x] Mark each pipeline component as `frozen`, `partial`, or `target` with explicit exit criteria.
- [x] Add per-component integration tests proving real runtime coverage (not table-only status).
- [x] Add dependency map showing which components block Phase 2 proof-path rollout.
- [x] Add periodic status review task and owner assignment for each incomplete component.
- [x] Maintain status table with `owner`, `ready_criteria`, `blocking_dependency`.
- [x] Add one integration test proving each `✅` row is exercised.
- [x] Add link from each row to source file and test file.
- [x] Add weekly status review item for `⏳` rows.

## Phase 15) Известные дефекты активных файлов (исправить до Phase 2)

Раздел документирует конкретные дефекты в **уже реализованном, компилируемом** коде
`crates/z00z_wallets/src/core/tx/`.

> ✅ **Все три дефекта (§15.1, §15.2, §15.3) ИСПРАВЛЕНЫ** в кодовой базе (ветка `z00z-wallet`).
> Документация сохранена для исторического контекста.

---

### 15.1 — `builder.rs`: молчаливое усечение в `commitment_bytes()`

**Файл:** `crates/z00z_wallets/src/core/tx/builder.rs`, функция `commitment_bytes()` (≈строки 23–29).

**Текущий код:**

```rust
fn commitment_bytes(commitment: &Z00ZCommitment) -> [u8; 32] {
    let mut out = [0u8; 32];
    let bytes = commitment.as_bytes();
    let size = out.len().min(bytes.len());
    out[..size].copy_from_slice(&bytes[..size]);
    out
}
```

**Дефект:** если `commitment.as_bytes().len() > 32` — старшие байты молча отбрасываются.
Ошибка не бросается, `c_amount` становится усечённым.  
Дальнейшие вычисления (`leaf_ad`, `enc_pack`, `tag16`) получают некорректные входные данные —
**результат consensus-critical**.

**Требуемое исправление:**

```rust
fn commitment_bytes(commitment: &Z00ZCommitment) -> [u8; 32] {
    let bytes = commitment.as_bytes();
    debug_assert_eq!(
        bytes.len(), 32,
        "RistrettoCommitment must serialize to exactly 32 bytes; got {}",
        bytes.len()
    );
    let mut out = [0u8; 32];
    out.copy_from_slice(&bytes[..32]);
    out
}
```

**Когда исправлять:** до реализации `TxAssemblerImpl` (Phase 2), так как любой
multi-output путь вызывает `commitment_bytes()` для каждого выхода.

> ✅ **ИСПРАВЛЕНО:** `builder.rs` теперь использует `bytes.try_into().expect("...")` + `debug_assert_eq!` для проверки длины.

---

### 15.2 — `prover.rs`: вводящий в заблуждение `_proof` в `verify_proof`

**Файл:** `crates/z00z_wallets/src/core/tx/prover.rs`, строка 125.

**Текущий код:**

```rust
fn verify_proof(&self, _proof: &RangeProof, commitment: &[u8]) -> ProverResult<bool> {
    let commitment = Commitment::from_canonical_bytes(commitment)...;
    Ok(self.service.verify(_proof, commitment.reveal()))  // <-- _proof ИСПОЛЬЗУЕТСЯ
}
```

**Дефект:** параметр назван `_proof` (Rust-конвенция означает «не используется»), но
реально передаётся в `self.service.verify()`. Вызывает путаницу при code review и
ложное предупреждение Clippy `unused_variables` на некоторых версиях.

**Требуемое исправление:**

```rust
fn verify_proof(&self, proof: &RangeProof, commitment: &[u8]) -> ProverResult<bool> {
    let commitment = Commitment::from_canonical_bytes(commitment)...;
    Ok(self.service.verify(proof, commitment.reveal()))
}
```

**Когда исправлять:** совместно с реализацией `TxVerifierImpl::verify_range_proofs()`
(Phase 2), которая будет вызывать `verify_proof()` в цикле.

> ✅ **ИСПРАВЛЕНО:** параметр переименован в `proof` в `prover.rs`.

---

### 15.3 — `builder.rs`: hardcoded `serial_id = 0u32` — потенциальный consensus bug

**Файл:** `crates/z00z_wallets/src/core/tx/builder.rs`, функция `sender_create_output_for()`.

**Текущий код:**

```rust
pub fn sender_create_output_for(
  card: &ReceiverCard,
  amount: u64,
  serial_id: u32,
) -> Result<AssetLeaf, WalletError> {
    ...
    let s_out = derive_s_out(&k_dh, &r_pub, serial_id);
    build_output_leaf(&k_dh, &r_pub, &card.owner_handle, amount, serial_id, s_out)
}
```

**Дефект:** функция создаёт один выход с `serial_id=0`.  
При вызове для двух получателей с **одним** случайным `r` (один `k_dh`) оба выхода
получат одинаковый `s_out = hash(k_dh, r_pub, LE(0))` — нарушение уникальности,
`asset_id` совпадут, `enc_pack` перезапишут друг друга.

**Граница безопасности:** при одном выходе за транзакцию — безопасно.
`TxAssemblerImpl` (Phase 1 stub) не вызывается, поэтому пока не проявляется.

**Требуемое исправление в Phase 2 (batch-output path):**

```rust
/// Create `count` stealth output leaves for one receiver card.
/// Each output gets a unique `serial_id` derived from its index.
pub fn sender_create_outputs_for(
    card: &ReceiverCard,
    amounts: &[u64],
) -> Result<Vec<AssetLeaf>, WalletError> {
    let mut rng = SystemRngProvider.rng();
    let r = Z00ZScalar::random(&mut rng);
    let sender = sender_derive_dh_with_r(&card.view_pk, &r)?;
    let k_dh = derive_k_dh(&sender.dh);
    let r_pub = sender.r_pub.to_bytes();

    amounts
        .iter()
        .enumerate()
        .map(|(i, &amount)| {
            let serial_id = i as u32;  // unique per output within same r
            let s_out = derive_s_out(&k_dh, &r_pub, serial_id);
            build_output_leaf(&k_dh, &r_pub, &card.owner_handle, amount, serial_id, s_out)
        })
        .collect()
}
```

**MUST:** `serial_id` **ОБЯЗАН** быть уникальным в пределах одного `k_dh`.
Спецификация в §11.1 закреплена: `s_out = hash_zk<SOutProdDomain>("Z00Z/S_OUT", [k_dh, r_pub, serial_le4])`.

> ✅ **ИСПРАВЛЕНО:** `sender_create_output_for` теперь принимает `serial_id: u32` как параметр вместо hardcoded `0u32`.

### 15.4 — Defect registry and regression links

Machine-readable registry (single source):

- `reports/phase15_defects.yaml`

| Defect | Regression test ID | Introduced in | Fixed in |
| --- | --- | --- | --- |
| D15-1 (`commitment_bytes` truncation risk) | `REG-15-1` | `bec0163e3` | `cda9c30c5`, `fd7ddc7d4` |
| D15-2 (`verify_proof` misleading arg name) | `REG-15-2` | `1b5f8aa52` | `cda9c30c5` |
| D15-3 (`serial_id` hardcoded to zero) | `REG-15-3` | `bec0163e3` | `cfcf1f140` |

### 15.5 — SLA, closure, and reopen policy

| Severity | SLA | Rule |
| --- | --- | --- |
| critical | 1 day | fix required before next release cut |
| low | 14 days | fix required before phase boundary merge |

Closure criteria for a defect to stay `resolved`:

1. spec entry exists;
2. code fix is present in active path;
3. mapped regression test is green;
4. registry status in `reports/phase15_defects.yaml` is `resolved`.

Reopen criteria:

- guard/assert path removed;
- old failure pattern appears again in tests;
- regression test mapping is missing or broken.

```mermaid
flowchart LR
  A[Defect detected] --> B[Code fix]
  B --> C[Regression ID]
  C --> D[Registry update]
  D --> E[Resolved]
  E -->|guard removed or test fails| F[Reopen]
```

---

### Section 15 Implementation Checklist
- [x] Verify each historical defect is linked to a concrete commit and regression test.
- [x] Add automated checks to prevent reintroduction of fixed defect classes.
- [x] Define severity-based SLA for unresolved defects and debt items.
- [x] Add closure criteria requiring docs/tests/code parity before marking defect as resolved.
- [x] Convert every fixed defect into regression test ID.
- [x] Add `introduced_in` and `fixed_in` references.
- [x] Add reopen criteria for recurring defect patterns.
- [x] Keep unresolved defects in a single machine-readable list.

## Phase 16) `fee_estimator.rs`: Phase 1 actual and Phase 2 alignment

**File:** `crates/z00z_wallets/src/core/tx/fee_estimator.rs`

### 16.1 Phase 1 actual behavior (current code)

| Method | Status | Behavior |
|---|---|---|
| `estimate_by_size(size_bytes)` | ✅ Active | Computes `base_fee = max(size_bytes * fee_per_weight, min_fee)`, returns low/medium/high tiers with minimum-fee floor (`low = max(0.8x, min_fee)`, `medium = 1.0x`, `high = 1.5x`). |
| `estimate(tx_bytes)` | ✅ Active | Decodes JSON payload (`tx` node), counts `inputs/outputs/kernels`, computes weight units, then delegates to `estimate_by_size(weight)`. |
| `estimate_by_weight(TxWeight)` | ✅ Active | Converts `TxWeight` to weight units and delegates to `estimate_by_size`. |
| `get_fee_per_byte()` | ✅ Active | Returns current `fee_per_weight`. |
| `get_minimum_fee()` | ✅ Active | Returns configured `min_fee`. |
| `update_rates()` | ✅ Conditional | `Static` mode: no-op success. `Network` mode: TTL cache + fetch via `FeeRateSource::get_fee_per_weight()`. |

Phase 1 conclusion: fee estimator is **functional** for local flow and for pluggable network mode through `FeeRateSource`; it does not depend on `ChainClient` yet.

### 16.2 Phase 2 target (consensus/network alignment)

Phase 2 alignment goals:

1. Keep `compute_tx_weight()` contract stable across wallet/simulator/consensus paths.
2. Freeze one canonical network fee source interface and map external backends to it.
3. Keep static mode for deterministic tests and offline flows.
4. Define canonical mapping between tx-package schema versions and weight constants.

Reference shape (target-level, implementation may differ by module placement):

```rust
pub trait ChainClient {
  fn get_mempool_fee_per_weight(&self) -> Result<u64, FeeEstimatorError>;
}
```

Any Phase 2 integration MUST preserve deterministic fallback when network source is unavailable.

### 16.3 Phase 2 consensus alignment (domains and proof path)

This subsection is intentionally separated from Phase 1 runtime contract.

**Domain alignment target:**

- stealth derivation domains: migrate wallet-private prefixes to the canonical consensus set (`ReceiverIdDomain`, `ViewKeyDomain`, `KdhDomain`, `OwnerTagDomain`, `LeafAdDomain`), with one frozen byte-level preimage order.
- artifact signature domains: align `ReceiverCard` and `PaymentRequest` signing context with one canonical consensus domain policy.

**Proof-path alignment target:**

- keep current Phase 1 local verifier path (`TxVerifierImpl`) as pre-broadcast sanity gate;
- add canonical `TxProof_v1` generation/verification path for spend+balance+range+OWF constraints;
- add canonical `CheckpointProof_v1` path for membership and state transition (`prev_root -> new_root`);
- bind both proof paths to stable transcript domains and canonical field ordering.

No Phase 2 domain/proof migration is part of the frozen Phase 1 Stage 4 contract in §4.1.

### 16.4 Migration checklist (consensus-safe)

- Keep `FEE_WGT_VER_V1` and weight constants frozen for Phase 1 compatibility.
- Keep `Static` mode as deterministic offline fallback path.
- In `Network` mode, on source timeout/error, keep deterministic fallback to cached/current rate.
- Allow Phase 2 backend swap only behind `FeeRateSource` adapter.
- Keep tx-weight contract (`inputs/outputs/kernels`) unchanged until next model version tag.

```mermaid
flowchart LR
  A[Static mode] --> D[Deterministic fee path]
  B[Network source ok] --> C[TTL cache update]
  B2[Network source fail] --> E[Fallback cached or current]
  C --> D
  E --> D
```

---

### Section 16 Implementation Checklist
- [x] Finalize one canonical fee-weight model and publish stable constants with version tags.
- [x] Add deterministic fixtures for `estimate`, `estimate_by_weight`, and `update_rates` behavior.
- [x] Define and test network-source fallback policy under timeout/error conditions.
- [x] Add migration checklist for consensus alignment without breaking static/offline mode.
- [x] Freeze weight constants and document rationale.
- [x] Add fixtures for `estimate_by_size`, `estimate`, `estimate_by_weight`.
- [x] Add TTL-cache behavior tests for network mode.
- [x] Add deterministic fallback behavior when fee source is unavailable.

## Phase 17) AssetOutputs legacy: протокольные инварианты и контракты

📌 Section 17 is normative for current protocol decisions; legacy code references are non-authoritative.

### 17.1 Asset-class invariants (MUST)
- `Coin`: `amount > 0`, range proof required.
- `Token`: `amount > 0`, range proof required.
- `Nft`: `amount = 0` at leaf amount layer; NFT identity is in immutable `asset_id`/token identifier.
- `Void`: `amount = 0`; sink semantics are enforced by allowlisted sink ids.
- `TxVerifierImpl` (Phase 2 target) MUST reject `AssetClass::Coin && amount == 0`.

### 17.2 Asset ID invariants (MUST)
- Asset id is immutable across tx lifecycle for the same logical asset.
- Per-class id derivation/validation MUST be deterministic and domain-separated.
- Unknown or unauthorized asset ids MUST be rejected.
- Tx MUST reject mixed-identity substitution (input/output id drift).

### 17.3 Output feature invariants (MUST)
- `nonce` MUST be non-zero and unique per output.
- Lock semantics MUST use `current_height >= lock_height`.
- `Void` classification MUST be based on class, not on helper flags.

### 17.4 Burn and fee sink rules (MUST)
- Sink ids are protocol allowlisted: `FEE_SINK_ID`, `BURN_SINK_ID`, `SLASH_SINK_ID`.
- Void outputs to non-allowlisted sink ids MUST be rejected.
- Supply accounting MUST remain conserved with burned value explicitly tracked.

### 17.5 Per-asset balance and atomicity (MUST)
- Balance is checked per asset class/tag.
- Fees are paid only in native coin class.
- Assembly/validation MUST be atomic: all checks pass or tx is fully rejected.

### 17.6 Offline ownership records (migration target)
- Offline proof envelope MUST include ownership proof and metadata integrity hash.
- `metadata_hash` MUST be computed from canonical metadata bytes and never set manually.
- Migration decision: add `offline_owner` proof object to leaf/witness path in Phase 2.

### 17.7 Pedersen invariants (MUST)
- Homomorphism invariant MUST hold for all balance checks.
- Deterministic commitment encoding MUST be stable for same `(value, blinding)` inputs.
- Cross-asset commitment aggregation MUST be forbidden.

### 17.8 Double-spend model decision (MUST)
- Z00Z uses JMT membership/state transition as the single double-spend prevention model.
- Separate nullifier set is out-of-scope for Protocol v1.
- Spend validation MUST prove input existence in `prev_root` and absence after state update.

### 17.9 Migration decisions
- Keep legacy artifacts only as migration references, not as normative protocol behavior.
- Any rule ported from legacy must have: source mapping, executable test, and acceptance criterion.
- Any rule not ported must have explicit rationale and risk note.

### 17.10 Traceability matrix (legacy -> active)

| Legacy invariant | Category | Active source-of-truth | Executable test | Status |
| --- | --- | --- | --- | --- |
| Coin/Token amount must be positive | must-port | `crates/z00z_wallets/src/core/tx/tx_verifier.rs::verify_balance` | `test_coin_zero_reject` | port |
| Nft/Void amount must be zero | must-port | `crates/z00z_wallets/src/core/tx/tx_verifier.rs::verify_balance` | `test_nft_zero_accept`, `test_void_zero_accept` | port |
| Output nonce must be non-zero and unique | must-port | `crates/z00z_wallets/src/core/tx/tx_verifier.rs::verify_balance` | `test_nonce_dup_reject` | port |
| Range proof mandatory for Coin/Token | must-port | `crates/z00z_wallets/src/core/tx/tx_verifier.rs::verify_range_proofs` | `test_verify_package_ok` + range-proof verifier path | port |
| Legacy tx-legacy `is_burned` helper semantics | historical-only | `crates/z00z_wallets/src/core/tx/tx-legacy/common.rs` | n/a | historical |
| Legacy sink-id helpers from tx-legacy | deprecated | `crates/z00z_core/src/genesis/asset_std.rs` (reference only) | n/a | drop |

### 17.11 Unresolved legacy risk notes

| Risk ID | Description | Mitigation | Owner |
| --- | --- | --- | --- |
| R17-1 | Explicit sink allowlist (`FEE_SINK_ID/BURN_SINK_ID/SLASH_SINK_ID`) is not yet enforced in Phase 1 verifier path. | Add sink-id allowlist gate in Phase 2 runtime verifier and bind to canonical asset-id registry. | runtime |
| R17-2 | Offline ownership envelope (`offline_owner`, canonical `metadata_hash`) is migration target only. | Introduce Phase 2 witness envelope and canonical metadata hash check in proof path. | wallet |
| R17-3 | Per-asset-class fee-payment rule is not fully enforced in current pre-broadcast package checker. | Add class-aware fee-source check in canonical TxProof/TxVerifier Phase 2 pipeline. | protocol |
| R17-4 | Lock-height spend rule (`current_height >= lock_height`) is not enforced in current pre-broadcast package checker. | Add lock-height check in Phase 2 verifier where canonical chain height context is available. | runtime |

---

### Section 17 Implementation Checklist
- [x] Classify legacy invariants into `must-port`, `deprecated`, and `historical-only` categories.
- [x] Add traceability matrix from legacy invariant to current implementation/test.
- [x] Add validation tests for asset-class specific rules (Coin/Token/Nft/Void).
- [x] Freeze unresolved legacy assumptions as explicit risk items with mitigation owners.
- [x] Mark each legacy rule as `port`, `drop`, or `historical`.
- [x] Add source-of-truth links to active modules.
- [x] Add tests for preserved rules (Coin/Token/Nft/Void).
- [x] Add risk notes for rules intentionally not ported.

## Phase 18) tx-legacy: план утилизации

📌 Section 18 defines removal policy, not historical inventory.

### 18.1 Retention policy (ALLOWLIST)
- Keep only legacy artifacts that are still required for migration decisions or test-vector extraction.
- Allowed legacy references MUST be read-only and MUST NOT be imported by runtime modules.
- Each retained file MUST have a purpose tag: `migration`, `reference`, or `archival`.

### 18.2 Retirement policy (DENYLIST)
- Legacy modules that do not compile against current APIs are deprecated by default.
- Any deprecated module MUST be either:
  1) converted into executable tests/fixtures in active crates, or
  2) removed from repository paths used by CI/runtime.
- No new code may depend on retired paths.

### 18.3 Phased migration decisions
- Phase A: extract normative rules into active spec/tests.
- Phase B: replace legacy references with active API fixtures.
- Phase C: remove retired legacy directories and add CI guardrails.
- Phase D: close migration only after zero runtime references remain.

### 18.4 Acceptance criteria
- `rg` over active crates returns no imports from retired legacy modules.
- Required invariants from §17 have executable tests in active crates.
- CI contains a guard that fails on new legacy dependencies.

### 18.5 Decommission order and checkpoints
- Order D1: freeze tx-legacy as read-only reference and disallow runtime linkage.
- Order D2: ensure each normative rule has active executable test in non-legacy modules.
- Order D3: remove adapter-level legacy references from active flows.
- Order D4: archive and then delete retired legacy files after zero-reference gate.
- Checkpoint after each order: `cargo test -p z00z_wallets tx_verifier --release -F test-fast -q` and `cargo test -p z00z_simulator scenario_1 --release -F test-fast,wallet_debug_dump -q`.

### 18.6 Safe-removal criteria
- No production/runtime reference to target file path in active crates.
- Replacement tests/fixtures exist in active crates for migrated behavior.
- Spec references are migrated to active source-of-truth modules.
- CI guard `check_no_legacy_deps.sh` passes on branch and PR.

### 18.7 Rollback plan by phase
- Rollback R1 (D1 fail): keep legacy files, revert only guard/config commit.
- Rollback R2 (D2 fail): keep converted tests, restore prior reference docs, do not delete files.
- Rollback R3 (D3 fail): re-enable previous adapter path via single commit revert.
- Rollback R4 (D4 fail): restore deleted files from previous tagged commit and reopen migration checklist.

### 18.8 Removal sequence with rollback points
```mermaid
flowchart TD
  D1["D1 Freeze legacy read-only"] --> C1["CP1 no runtime link"]
  C1 --> D2["D2 Port rules to active tests"]
  D2 --> C2["CP2 tests green"]
  C2 --> D3["D3 Drop active adapters"]
  D3 --> C3["CP3 scenario_1 green"]
  C3 --> D4["D4 Archive or delete retired files"]
  D4 --> C4["CP4 zero runtime references"]
```

### 18.9 Migration checklist per removed file
| File | Tag | Replacement | Checkpoint | Status |
| --- | --- | --- | --- | --- |
| `crates/z00z_wallets/src/core/tx/tx-legacy/calculation.rs` | migration | `fee_estimator.rs` + `tx_verifier.rs` tests | CP2 | tracked |
| `crates/z00z_wallets/src/core/tx/tx-legacy/common.rs` | reference | `z00z_core/src/genesis/asset_std.rs` + verifier tests | CP2 | tracked |

### 18.10 Completion gate
- `scripts/check_no_legacy_deps.sh` MUST pass.
- `rg -n "tx-legacy/" crates --glob "*.rs"` MUST return zero matches.
- Runtime validation lane for `scenario_1` MUST pass with release/feature flags.

---

### Section 18 Implementation Checklist
- [x] Define decommission order for legacy modules with compatibility checkpoints.
- [x] Add safe-removal criteria (no production references, tests replaced, docs migrated).
- [x] Add rollback plan for each deletion phase.
- [x] Add CI rule that blocks new dependencies on legacy paths.
- [x] Define removal sequence with rollback points.
- [x] Add `no_new_dependency` CI guard for legacy paths.
- [x] Add migration checklist for each removed file.
- [x] Add completion gate: zero runtime references to retired modules.

## Phase 19) Gas fee model (из `calculation.rs`)

📌 Gas/fee model in this section is normative for acceptance checks.

### 19.1 Canonical fee formula (MUST)
```
gas_units = base_tx_cost
      + inputs  * per_input_cost
      + outputs * per_output_cost
      + range_proof_bits * per_range_proof_bit_cost

fee = gas_units * price_per_unit
```

### 19.2 Fee validation rules (MUST)
- Fee-paying class is native coin only.
- All fee-covering outputs must belong to native coin class.
- Declared fee must match deterministic fee calculation.
- Arithmetic overflow in gas/fee calculation must fail validation.

### 19.3 Migration decisions
- Phase 1 may keep placeholder schedule constants.
- Phase 2 must freeze production schedule with governance/versioning policy.
- Any schedule change requires new fixtures and compatibility review.

### 19.4 Frozen units and conversion rules (Phase 1)
- `base_tx_cost = 64` gas units.
- `per_input_cost = 96` gas units.
- `per_output_cost = 900` gas units.
- `per_range_proof_bit_cost = 1` gas unit per bit.
- Backward-compatible conversion for weight fixture path: `range_proof_bits = kernels * 120`.
- Deterministic fee uses integer arithmetic only (`u64` with checked overflow).

### 19.5 Parameter governance process
- Owner: protocol team (`z00z_core` + `z00z_wallets` maintainers).
- Trigger: economics update, security hardening, or compatibility incident.
- Required artifacts per change: updated constants, low/high/mixed fixtures, coherence tests, and compatibility note in this spec.
- Rollout rule: versioned tag update and release-lane validation before merge.

---

### Section 19 Implementation Checklist
- [x] Freeze gas/fee formulas with explicit units and conversion rules.
- [x] Add edge-case test vectors for low/high load and minimal fee floors.
- [x] Add consistency checks between estimator outputs and runtime acceptance rules.
- [x] Define parameter governance process (who/when/how formula constants can change).
- [x] Freeze formula units and conversion rules.
- [x] Add test vectors for low/high/mixed load cases.
- [x] Add coherence tests with tx acceptance policy.
- [x] Add governance procedure for parameter updates.

## Phase 20) AssetOutput legacy wire format (из `common.rs`)

📌 This section defines compatibility boundaries between legacy wire and active wire.

### 20.1 Canonical active wire (MUST)
- Active tx flow uses `AssetLeaf` + `AssetPackPlain` constraints from §§11–12.
- New protocol paths MUST NOT introduce new dependencies on legacy `AssetOutput` wire.

### 20.2 Legacy import compatibility (MAY)
- Legacy wire is allowed only in explicit import/migration adapters.
- Import adapter MUST validate version, length framing, checksum, and class invariants.
- Import adapter output MUST be converted to active canonical structures before use.

### 20.3 Migration decisions
- Keep legacy wire reader only while migration backlog is open.
- Remove legacy writer from active paths first, then remove reader after cutover.

### 20.4 Final wire-layout decision (v1)
- Legacy wire envelope is frozen as `version:u32(le) || payload_len:u32(le) || payload || checksum[32]`.
- `checksum` is Blake2b-256 over `version || payload_len || payload` in `ChecksumHashDomain`.
- In `Strict` mode, `bytes.len()` MUST equal `payload_end + 32` (no trailing extension bytes).
- Import adapter MUST reject malformed framing, checksum mismatch, unsupported version, and class invariant breaks.

### 20.5 Versioned compatibility matrix
| Wire version | Reader mode | Unknown trailing bytes | Unknown fields inside payload | Result |
|---|---|---|---|---|
| v1 | Strict | Reject | Reject (bincode schema mismatch) | Reject |
| v>1 | Strict | N/A | N/A | Reject (`unsupported version`) |

### 20.6 Canonical byte layout and field constraints
- Header: `version` (4 bytes LE), `payload_len` (4 bytes LE).
- Payload: canonical bincode encoding of legacy `AssetOutput`.
- Trailer: `checksum` (32 bytes).
- Constraints at import boundary:
  - `serial_id` in `[1, 50000]`.
  - `amount > 0` for non-`Nft` and non-`Void` classes.
  - `features.asset` MUST be present.

```mermaid
flowchart LR
    A[bytes] --> B[read version+length]
    B --> C{version == OFFLINE_RECORD_VERSION}
    C -- no --> X[reject unsupported version]
    C -- yes --> D[check payload_len framing]
    D --> E[verify checksum]
    E --> F{strict length exact?}
    F -- no --> Y[reject trailing bytes]
    F -- yes --> G[deserialize payload]
    G --> H[validate class+serial invariants]
    H --> I[convert to active canonical structs]
```

---

### Section 20 Implementation Checklist
- [x] Document final wire-layout decision and versioned compatibility matrix.
- [x] Add strict serializer/deserializer conformance tests with golden binaries.
- [x] Add malformed payload corpus and parser rejection tests.
- [x] Define forward-compatibility behavior for unknown/extended fields.
- [x] Capture canonical byte layout and field constraints.
- [x] Add serde conformance tests with golden vectors.
- [x] Add fuzz corpus for malformed payload rejection.
- [x] Add forward-compatibility handling for unknown optional fields.

## Phase 21) SerialAmount validation rules (из `common.rs`)

📌 Serial rules are normative and must be enforced uniformly.

### 21.1 SerialAmount (MUST)
- `serial_id` must be within configured bounded range.
- `amount` must be strictly positive for spendable value classes.
- Invalid serial entries must be rejected at parse/validation boundary.

### 21.2 SerialAmountSet (MUST)
- No duplicate `serial_id` values in one set/tx.
- Aggregate amount arithmetic must be overflow-safe.
- Validation outcome must be deterministic across all runtimes.

### 21.3 Unified validation API (v1)
- One validation module owns serial bounds and failure semantics.
- Canonical bounds are frozen: `SERIAL_MIN_ID = 1`, `SERIAL_MAX_ID = 50_000`.
- `check_pair(serial_id, amount)` is the canonical entry point for single entries.
- `check_set(items)` is the canonical entry point for duplicate/overflow-safe set validation.

### 21.4 Telemetry counters (non-test env)
- Validation layer emits counters for rejected serial cases:
  - invalid id,
  - zero amount,
  - duplicate serial id,
  - set sum overflow.
- Counters are monotonic and deterministic (`AtomicU64`, relaxed ordering).

```mermaid
flowchart LR
  A[serial_id, amount] --> B[check_pair]
  B --> C{valid id and amount}
  C -- no --> D[increment fail counters]
  C -- yes --> E[entry accepted]
  E --> F[check_set]
  F --> G{duplicate or overflow}
  G -- yes --> D
  G -- no --> H[set accepted]
```

---

### Section 21 Implementation Checklist
- [x] Codify all SerialAmount bounds and failure semantics in one validation module.
- [x] Add property-based tests for boundaries and random invalid payloads.
- [x] Add integration checks ensuring serial rules are enforced consistently across tx flow.
- [x] Add telemetry counters for serial validation failures in non-test environments.
- [x] Consolidate bounds into one validation API.
- [x] Add boundary tests: min-1, min, max, max+1.
- [x] Add random invalid input generation tests.
- [x] Add telemetry counters for validation failures.

## Phase 22) Performance baselines (из bench файлов)

📌 Baselines are quality gates, not historical notes.

### 22.1 Benchmark policy (MUST)
- Maintain reproducible benchmark profiles for prove/verify/serialize paths.
- Track p50/p95 and regression delta against pinned baseline snapshot.
- Fail CI on threshold breaches for critical hot paths.

### 22.2 Measurement policy (MUST)
- Benchmark environment and input profile must be versioned.
- Parallel and sequential benchmarks must be reported separately.
- Any optimization claim must include before/after benchmark evidence.

---

### Section 22 Implementation Checklist
- [x] Reproduce baseline benches on current hardware profile and store dated snapshots.
- [x] Add performance budget thresholds tied to CI/regression alerts.
- [x] Add benchmark coverage for prover/verifier hot paths and large batch scenarios.
- [x] Add optimization backlog items prioritized by measured bottlenecks.
- [x] Re-run baseline benchmarks and store dated outputs.
- [x] Add CI thresholds for proof generation and verification timings.
- [x] Add hot-path profiling notes and optimization targets.
- [x] Add regression alert checklist for benchmark drift.

## Phase 23) Lock height & spendability semantics

📌 Lock semantics are fixed protocol behavior.

### 23.1 Canonical rule (MUST)
- Output is spendable iff `lock_height` is absent or `current_height >= lock_height`.

### 23.2 Validation and compatibility
- Boundary condition at exact lock height MUST be accepted.
- Malformed lock metadata MUST be rejected.
- Compatibility mode for legacy edge values MUST be explicitly documented and tested.

### 23.3 Migration compatibility notes
- Legacy edge `lock_height = 0` is treated as absolute height and therefore spendable at `current_height >= 0`.
- Canonical absence remains `lock_height = None`; both forms are valid during migration window.
- Relative lock form is accepted only as explicit metadata object and must pass overflow-safe `base + delta` validation.

---

### Section 23 Implementation Checklist
- [x] Freeze lock-height semantics (`>=` rule) in executable tests and consensus notes.
- [x] Add tests for absolute/relative lock variants and boundary block heights.
- [x] Add explicit rejection cases for malformed or inconsistent lock metadata.
- [x] Add migration notes for any future lock policy changes.
- [x] Add tests for exact-boundary spendability (`current == lock_height`).
- [x] Add tests for `None`, absolute, and relative lock behaviors.
- [x] Add negative tests for malformed lock metadata.
- [x] Document migration constraints for lock-rule changes.

## Phase 24) Protocol invariants confirmed by full audit

📌 Section 24 contains invariants that are release-gating.

### 24.1 Core invariants (MUST)
- Class identification must rely on canonical class fields, not heuristics.
- `asset_id` immutability must hold across full tx lifecycle.
- Per-asset balance conservation must hold independently per class/tag.
- Commitment/proof binding must prevent cross-commitment proof reuse.

### 24.2 Operational decisions
- JMT is the canonical state source for existence/spend status.
- Legacy nullifier-set semantics are non-normative for current protocol.
- Any divergence between docs and executable checks is treated as a release blocker.

---

### Section 24 Implementation Checklist
- [x] Convert each invariant into a machine-checkable assertion or dedicated test.
- [x] Add invariant ownership metadata (module, owner, verification cadence).
- [x] Add drift detection between docs and executable invariants.
- [x] Add incident runbook for invariant violation in production/simulation.
- [x] Convert each invariant into executable assertions.
- [x] Add invariant ownership and review cadence.
- [x] Add drift detector: doc claim vs test result.
- [x] Add production incident checklist for invariant violation.

## Phase 25) Финальный результат полного рекурсивного аудита tx-legacy

📌 Section 25 is a decision register, not a narrative report.

### 25.1 Retain/remove decisions (MUST track)
- Retained legacy artifacts must have explicit purpose and owner.
- Removed legacy artifacts must have migration mapping to active tests/spec.
- Any undecided artifact blocks closure of legacy retirement stream.

### 25.2 Closure criteria
- All required rules ported to active code/tests.
- No runtime dependency on retired legacy modules.
- Decision log entries have status, owner, and verification evidence.

---

### Section 25 Implementation Checklist
- [x] Convert final audit conclusions into actionable tickets grouped by severity.
- [x] Define acceptance criteria for closing each audit stream.
- [x] Add regression packs that prove fixed findings remain fixed over time.
- [x] Add publication routine for periodic re-audit deltas.
- [x] Convert findings into issue IDs with severity labels.
- [x] Add closure checklist requiring code+tests+docs updates.
- [x] Add recurrence-prevention checks for each closed item.
- [x] Add periodic re-audit schedule.

## Phase 26) Результаты consistency-аудита (2025-12)

📌 This section is the active consistency backlog.

### 26.1 Open consistency items (Phase 2 decisions)

⚠️ Items below are tracked as code-alignment decisions; each item must end with executable acceptance checks.

#### Т-1 (КРИТИЧЕСКИ): Систематическое расхождение wallet-private и consensus доменов

**Проблема:** для ВСЕХ 7 stealth-операций wallet Phase 1 использует wallet-private домены (prefix `"z00z.wallet.stealth.*"`), тогда как `z00z_crypto` содержит consensus-домены (prefix `"Z00Z/..."`). Одинаковые входы дают **разные хэши** в wallet vs ZK-схеме.

| Операция | Wallet Phase 1 домен | Consensus домен | Context совпадает? |
|---|---|---|---|
| `owner_handle` | `WalletReceiverIdHashProdDomain` + ctx `"RID"` | `ReceiverIdDomain("Z00Z/RID")` + ctx `""` | ❌ (и prefix, и context) |
| `view_sk` | `WalletViewKeyHashProdDomain` + ctx `"VIEW"` | `ViewKeyDomain("Z00Z/VIEW")` + ctx `""` | ❌ (и prefix, и context) |
| `k_dh` | `WalletDhKeyHashProdDomain` + ctx `"Z00Z/DH"` | `KdhDomain("Z00Z/DH")` + ctx `""` | ⚠️ (только prefix) |
| `owner_tag` | `WalletOwnerTagHashProdDomain` + ctx `"Z00Z/TAG"` | `OwnerTagDomain("Z00Z/TAG")` + ctx `""` | ⚠️ (только prefix) |
| `leaf_ad` | `WalletLeafAdHashProdDomain` + ctx `"Z00Z/LEAFAD"` | `LeafAdDomain("Z00Z/LEAFAD")` + ctx `""` | ⚠️ (только prefix) |
| `tag16` | `WalletTag16HashProdDomain` + ctx `"Z00Z/TAG16"` | `Tag16Domain("Z00Z/TAG16")` + ctx `""` | ⚠️ (только prefix) |
| `s_out` | `SOutProdDomain` + ctx `"Z00Z/S_OUT"` | нет consensus-эквивалента | — |

**Последствие:** до Phase 2 ZK-интеграции wallet self-consistent, но не совместим с ZK-схемой §5. При попытке интегрировать Phase 2 ZK circuit, wallet должен перейти на consensus-домены либо ZK-схема адаптируется под wallet-domains.

**Особые замечания:**
- `owner_handle` и `view_sk`: context-строки тоже отличаются (`"RID"` vs `"Z00Z/RID"`, `"VIEW"` vs `"Z00Z/VIEW"`).
- `s_out`: consensus-домен ещё не существует — wallet-private является единственной реализацией.

**План решения Phase 2:** принять решение об едином каноническом наборе доменов. Обновить либо wallet (мигрировать на consensus-домены), либо ZK-схему. Changelog заморозить при переходе — все существующие stealth outputs станут невалидными для нового домена.

**Критерий приёмки:** один канонический доменный набор зафиксирован, векторы для wallet/proof совпадают byte-for-byte.

#### Т-2 (КРИТИЧЕСКИ): `DefaultTag16Ops` несовместим с leaf builder tag16

**Проблема:** `DefaultTag16Ops::compute(owner_handle, k_dh)` вычисляет `tag16` через proxy-leaf_ad:
```
label_proxy = hash_zk("Z00Z/TAG16/OWNER", [owner_handle])
tag16 = compute_tag16(k_dh, label_proxy)[0..2]
```
Однако `builder.rs` записывает leaf `tag16 = compute_tag16(k_dh, actual_leaf_ad)`.  
`DefaultTag16Ops` как сканер пропустит ВСЕ leaves от `builder.rs`.

**План Phase 2:** пересмотреть scan-путь `DefaultTag16Ops` либо упразднить, либо пересчитать на полный `leaf_ad` (field-перечисление без `DefaultTag16Ops`).

**Критерий приёмки:** scanner корректно находит листья, созданные builder-путём, без ложных пропусков.

#### Т-4 (НИЗКИЙ): §7 ссылка на несуществующий модуль

Скелет `proofs/spend.rs` использует:
```rust
use crate::delivery::stealth::{AssetId, ...};
```
Модуль `crate::delivery::stealth` не существует.  
Реальные пути: `z00z_core::assets::AssetLeaf`, `z00z_wallets::core::...`.  
Скелеты не компилируются — заапичено до Phase 2.  
Аналогично, скелет `checkpoint/state_update.rs` также использует тип `AssetLeafEcdhV1` — реальный тип: `z00z_core::assets::leaf::AssetLeaf`.

**Критерий приёмки:** все skeleton-модули либо компилируемы, либо удалены/зафичерфлажены вне release пути.

#### Т-5 (НИЗКИЙ): Тест `consensus_domain_count` самореференциален и неверен

В `z00z_crypto/domains.rs`:
```rust
// consensus_domains_unique() test: hardcoded array of 20 domains
let unique_domains: [&[u8]; 20] = [...];

// consensus_domain_count() test:
let actual = 21; // hardcoded — does NOT match the 20 in the array above
let expected = 21;
assert_eq!(actual, expected, ...);  // always passes, but 20 ≠ 21
```
**Двойная проблема:** (1) тест всегда проходит (самореференциален); (2) 20 доменов в массиве vs утверждение `actual = 21` — числа не совпадают. Следует заменить на динамический подсчёт через `inventory` или `ctor` macro в Phase 2.

**Критерий приёмки:** доменный тест считает значения динамически и падает при реальном рассинхроне.

#### Т-6 (СРЕДНИЙ): ZkPack ключ/нонс также используют wallet-private домены

**Проблема:** `facade_kdf.rs::derive_pack_key` использует `PackKeyProdDomain("z00z.wallet.stealth.pack_key.prod.v1")`, а `derive_pack_nonce` использует `PackNonceProdDomain("z00z.wallet.stealth.pack_nonce.prod.v1")`. Consensus-эквиваленты `PackKeyDomain("Z00Z/PACKKEY")` и `PackNonceDomain("Z00Z/PACKNONCE")` определены в `z00z_crypto/domains.rs` но не используются wallet.

Это частный случай Т-1, но выделен отдельно, так как затрагивает шифрование `enc_pack` — на порядки более критичную часть протокола, чем теги поиска.

**План Phase 2:** согласовать с T-1 в едином решении.

**Критерий приёмки:** `enc_pack` derivation использует тот же канонический доменный профиль, что и proof path.

#### Т-7 (НИЗКИЙ): `chain_id` тип: протокол `u32`, реализация `u8`

**Проблема:** §4 (`TxPackage_v1` и `TxProof_v1` YAML) объявляет `chain_id: u32`.
В `z00z_wallets/src/core/wallet/wallet.rs` реализован `pub struct ChainId(pub u8)`
с константами `MAINNET=1, TESTNET=2, DEVNET=3`. Три сети тривиально умещаются в `u8`.

В §4 добавлены inline-пометки: `# ⚠️ Phase 1: ChainId(u8) в wallet.rs. Протокол резервирует u32 wire field.`

**Последствие:** при сериализации TxPackage необходимо zero-extend `ChainId(u8) → u32 LE`,
иначе wire format будет на 3 байта короче ожидаемого.

**План Phase 2:** реализовать `impl From<ChainId> for u32` с явным zero-extend +
doc-комментарий о wire-формате. Проверить bincode/заголовочный сериализатор.

**Критерий приёмки:** сериализация/десериализация `chain_id` проходит фиксированные векторы для всех supported chains.

#### Т-8 (СРЕДНИЙ): ReceiverCard signature domain/context is not aligned with `z00z_crypto` consensus domains

**Problem:** the wallet signs `ReceiverCard` via `sign_identity(..., context = "Z00Z/CARD_v1")`, while `z00z_crypto/src/domains.rs` declares `RcardDomain("Z00Z/RCARD")` as the consensus domain for ReceiverCard signatures.

**Impact:** while `ReceiverCard` remains an off-chain artifact, the issue is limited to component interoperability. If Phase 2 makes ReceiverCard signatures consensus-verifiable, a single canonical choice is required: either the wallet migrates to `RcardDomain`, or the `z00z_crypto` domain/policy is adjusted.

**Критерий приёмки:** card signatures валидируются по единому домену в wallet + verifier path.

#### Т-9 (СРЕДНИЙ): PaymentRequest signature domain/context is not aligned with `z00z_crypto` consensus domains

**Problem:** the wallet signs `PaymentRequest` via `sign_identity(..., context = "Z00Z/REQUEST_v1")`, while `z00z_crypto/src/domains.rs` declares `ReqV1Domain("Z00Z/REQv1")` as the consensus domain for PaymentRequest signatures.

**Phase 2 plan:** same as T-8 — pick one canonical domain/context and freeze it in the protocol, because requests are used in QR/NFC and must be interoperable.

**Критерий приёмки:** request signatures валидируются по единому домену в QR/NFC flows.

### 26.2 Phase 2 remediation roadmap (T-1..T-9)

| Item | Milestone | Target outcome |
| --- | --- | --- |
| T-1 | M1 Domains Freeze | One canonical domain profile selected and documented |
| T-2 | M2 Tag16 Alignment | Scanner and builder use one compatible `tag16` path |
| T-4 | M3 Skeleton Hygiene | Skeleton modules compile or are feature-gated out of release |
| T-5 | M4 Domain Test Fix | Domain-count test is dynamic and fails on real drift |
| T-6 | M5 Pack KDF Align | `enc_pack` key/nonce derivation aligned with canonical domains |
| T-7 | M6 ChainId Wire | `ChainId(u8) -> u32` zero-extend conversion verified |
| T-8 | M7 Card Sign Domain | ReceiverCard signatures use one canonical domain/context |
| T-9 | M8 Request Sign Domain | PaymentRequest signatures use one canonical domain/context |

```mermaid
flowchart LR
  M1["M1 Domains Freeze"] --> M2["M2 Tag16 Alignment"]
  M2 --> M5["M5 Pack KDF Align"]
  M1 --> M7["M7 Card Sign Domain"]
  M1 --> M8["M8 Request Sign Domain"]
  M3["M3 Skeleton Hygiene"] --> M4["M4 Domain Test Fix"]
  M5 --> G["Phase 2 Convergence Gate"]
  M6["M6 ChainId Wire"] --> G
  M7 --> G
  M8 --> G
```

### 26.3 Milestone gates and evidence artifacts

| Milestone | Code evidence | Test evidence | Doc evidence |
| --- | --- | --- | --- |
| M1 Domains Freeze | Domain aliases/constants merged in active modules | Cross-crate parity vectors are green | Frozen canonical domain policy in this spec |
| M2 Tag16 Alignment | Scanner path uses canonical `leaf_ad`-compatible tag input | Positive scan on builder-made leaves, no false-miss regressions | Tag16 path note updated in §§11,26 |
| M3 Skeleton Hygiene | Skeleton imports compile or are gated from release | Build checks pass with release feature set | Skeleton status matrix updated |
| M4 Domain Test Fix | Dynamic domain counting implementation merged | Test fails on injected mismatch and passes on valid registry | Test method and rationale documented |
| M5 Pack KDF Align | `derive_pack_key/nonce` uses canonical domain profile | Golden `enc_pack` vectors match wallet+proof path | KDF migration note and cutover policy |
| M6 ChainId Wire | `From<ChainId> for u32` zero-extend path merged | Fixed vectors for all supported chain ids | T-7 status updated |
| M7 Card Sign Domain | One canonical ReceiverCard signature domain wired | Signature verify parity across wallet/verifier path | ReceiverCard domain rule frozen |
| M8 Request Sign Domain | One canonical PaymentRequest signature domain wired | QR/NFC signature verify parity tests are green | PaymentRequest domain rule frozen |

### 26.4 Verification checkpoints (code + tests + docs)

| Checkpoint | Required status |
| --- | --- |
| CP-1 Domain parity | Code merged + vectors green + docs frozen |
| CP-2 Wire parity | Serialization vectors green + parser tests green + wire notes updated |
| CP-3 Proof path parity | TxProof/CheckpointProof public inputs aligned + transcript tests green + spec fields frozen |
| CP-4 Interop parity | Card/Request signatures validated with one domain policy + interop tests green + migration guidance updated |
| CP-5 Release gate | No unresolved critical items in T-1..T-9 + CI release lane green |

### 26.5 Triage owners and deadlines

| Item | Severity | Status | Owner | Deadline |
| --- | --- | --- | --- | --- |
| T-1 | critical | done | wallet+crypto lead | 2026-03-20 |
| T-2 | critical | done | wallet lead | 2026-03-18 |
| T-4 | low | done | wallet core maintainer | 2026-03-25 |
| T-5 | low | done | crypto test maintainer | 2026-03-25 |
| T-6 | medium | done | wallet crypto maintainer | 2026-03-22 |
| T-7 | low | done | wallet core maintainer | 2026-03-12 |
| T-8 | high | done | wallet address maintainer | 2026-03-24 |
| T-9 | high | done | wallet address maintainer | 2026-03-24 |

### 26.6 Final convergence check

Convergence is accepted only if all checks below are green in the same release candidate:

- Domain parity: wallet and proof path produce identical vectors for `owner_handle`, `view_sk`, `k_dh`, `owner_tag`, `leaf_ad`, `tag16`, `pack_key`, `pack_nonce`.
- Proof parity: `TxProof` and `CheckpointProof` consume the same canonical field order and transcript labels defined in §4.
- Wire parity: `chain_id`, `AssetPackPlain`, and leaf/ad fields match fixed vectors and parser constraints.
- Signature parity: ReceiverCard and PaymentRequest validate under one canonical domain policy.

### 26.7 Final sign-off gate

Release is blocked unless all rules are satisfied:

- No unresolved critical items in T-1..T-9.
- CP-1..CP-5 all marked green with linked evidence.
- Required feature-flag test lane is green: `--release` + `test-fast` + `wallet_debug_dump`.
- Spec, code, and tests are synchronized for all Phase 2 items touched in this cycle.

### Section 26 Implementation Checklist
- [x] Implement T-7: safe `ChainId` wire conversion (`u8 <-> u32`) with tests.
- [x] Triage all consistency findings into `critical`, `high`, `medium`, `low` with owners and deadlines.
- [x] Create one canonical remediation roadmap that merges domain, proof-path, and wire-format items.
- [x] Add verification checkpoints proving each remediation step in code + tests + docs.
- [x] Add final sign-off gate requiring zero unresolved critical consistency gaps.
- [x] Build remediation roadmap for T-1..T-9 with milestones.
- [x] Add milestone gates with required evidence artifacts.
- [x] Add final convergence check: wallet domains, proof path, wire fields.
- [x] Block release if any critical consistency item remains unresolved.

## 27. Phase 2 Combat Plan for Full Crypto-Convergence (T-1..T-9)

📌 **Purpose:** this section defines an execution plan that treats the full T-1..T-9 set as one convergence backlog until CP-1..CP-5 are all green in the same release candidate.

⚠️ **Rule:** “Section 26 checklist completed” is not equivalent to “protocol converged.” Convergence is accepted only after evidence-backed closure against the gates in §26.4 and §26.7.

### 27.1 Convergence policy and scope lock

✅ **Operational policy:** from this point, every open item in T-1..T-9 is handled as a release-critical convergence dependency until CP-5 is green.

✅ **No-fragment execution:** remediation is accepted only if code, vectors, and spec updates are merged together for the same item.

✅ **Single release lane:** all closure evidence must be validated in the required lane:

```bash
cargo test --workspace --release -F z00z_simulator/test-fast,z00z_wallets/test-fast,z00z_simulator/wallet_debug_dump
```

### 27.2 Wave plan (execution order)

| Wave | Window | Items | Primary objective | Exit condition |
| --- | --- | --- | --- | --- |
| W1 | 2-3 days | T-6, T-8, T-9 | Close remaining domain/signature interoperability drift | CP-1 + CP-4 green |
| W2 | 1-2 days | T-4, T-5 | Remove skeleton/test drift that can mask regressions | CP-1 guard quality hardened |
| W3 | 1-2 days | Full T-1..T-9 audit | Re-run vectors/tests/docs against one RC branch | CP-1..CP-5 all green |

### 27.3 Item-by-item battle tasks

| Item | Required actions | Required evidence |
| --- | --- | --- |
| T-6 Pack KDF | Freeze one canonical domain profile for `pack_key` and `pack_nonce`; update KDF vectors and verifier path | Golden vectors + cross-path parity tests + spec delta |
| T-8 Card domain | Select one canonical ReceiverCard signature domain/context and remove dual-policy behavior | Wallet+verifier parity tests + QR/NFC interop check |
| T-9 Request domain | Select one canonical PaymentRequest signature domain/context and remove dual-policy behavior | Request sign/verify parity tests + QR/NFC flow tests |
| T-4 Skeleton hygiene | Gate or complete skeleton modules so release builds cannot consume incomplete paths | Release build logs + feature-gate matrix |
| T-5 Domain test fix | Replace static/fragile domain-count assumptions with drift-detection tests | Negative injected-drift test + positive baseline test |

### 27.4 Daily control loop (war-room cadence)

🔔 **D1 Standup artifact:** for each T-item, publish `status`, `risk`, `owner`, `next action`, `blocking dependency`.

🔔 **D2 End-of-day gate:** no item remains “in progress” without at least one of: merged code, merged vectors, merged spec update.

🔔 **D3 Escalation rule:** if an item has no measurable delta for 24h, escalate to wallet+crypto leads and reassign scope.

### 27.5 Evidence package required for sign-off

✅ **Code package:** merged implementation links for each touched T-item.

✅ **Test package:** command output and CI links for the required release lane plus targeted parity tests.

✅ **Spec package:** synchronized updates in §§4, 11, 26, and this section when policy/domain choices change.

✅ **Convergence package:** one summary table proving CP-1..CP-5 are green in the same RC.

### 27.6 Final release decision rule

⛔ **Release blocked** if any of the following is true:

- Any T-item lacks code+test+doc evidence in the same cycle.
- Any CP gate from §26.4 is not green.
- Required release feature lane is red.
- Domain/signature policy remains dual or ambiguous for card/request flows.

✅ **Release unblocked** only when all T-1..T-9 closure evidence is complete and CP-1..CP-5 are green together.

### 27.7 Implementation checklist (step-by-step)

- [x] W1-S1: align `T-6` pack derivation to canonical `PackKey/PackNonce` domain profile and refresh golden vectors.
- [x] W1-S2: align `T-8` ReceiverCard signature context to canonical domain policy.
- [x] W1-S3: align `T-9` PaymentRequest signature context to canonical domain policy.
- [x] W1-S4: run required release lane (`--release` + `test-fast` + `wallet_debug_dump`) and fix regressions until green.
- [x] W2-S1: close skeleton hygiene drift (`T-4`) in release lane.
- [x] W2-S2: close domain drift-test hygiene (`T-5`) with injected-drift negative checks.
- [x] W3-S1: run full CP-1..CP-5 evidence pack and attach links in this spec.

## 28. W2/W3 Blocker Closure Playbook (Spec-Only Execution Contract)

📌 **Purpose:** define one explicit, auditable, and sequence-locked plan to close remaining blockers in `W2`/`W3` (`T-4`, `T-5`, and `CP-1..CP-5` evidence convergence).

📌 **Scope lock:** this section governs closure actions only for:

- `W2-S1` (`T-4 Skeleton hygiene`)
- `W2-S2` (`T-5 Domain drift-test hygiene`)
- `W3-S1` (full convergence evidence pack)

📌 **Out of scope:** new protocol features, new cryptographic domains, or unrelated refactors.

### 28.1 Execution order and no-jump rule

✅ Work MUST follow this strict order:

1. `W2-S1` (`T-4`)
2. `W2-S2` (`T-5`)
3. `W3-S1` (`CP-1..CP-5` evidence pack)

⛔ It is forbidden to mark `W3-S1` done while any `W2` step is open.

⛔ It is forbidden to mark any closure item `done` without same-cycle evidence in all three tracks:

- code delta (or explicit `no-code-change` attestation when applicable),
- test evidence,
- synchronized spec update.

**28.1 Progress checklist:**

- [x] Confirmed execution order lock (`W2-S1` → `W2-S2` → `W3-S1`) in current cycle notes.
- [x] Confirmed no `W3-S1` completion mark exists while any `W2` item is open.
- [x] Attached same-cycle evidence references for code/test/spec tracks.
- [x] Recorded current cycle owner and timestamp for traceability.

### 28.2 W2-S1 closure plan (`T-4 Skeleton hygiene`)

🎯 **Objective:** ensure no skeleton/incomplete path can be consumed by release builds.

**Required actions:**

- Build a current inventory of skeleton/incomplete tx-related paths that are compiled in release mode.
- For each path, choose exactly one status:
  - `compile-ready` (fully valid in release), or
  - `release-gated` (excluded from release by feature/target gating).
- Remove ambiguous status where a path is partially wired but not release-safe.
- Produce a `feature-gate matrix` artifact that maps module → status → release impact.

**Mandatory evidence:**

- Required lane output is green:

```bash
cargo test --workspace --release -F z00z_simulator/test-fast,z00z_wallets/test-fast,z00z_simulator/wallet_debug_dump
```

- `T-4` status updated to `done` in triage/backlog artifacts.
- Link to `feature-gate matrix` attached in this spec section.

**W2-S1 linked evidence (current cycle):**

- `feature-gate matrix`: `crates/z00z_wallets/tests/fixtures/phase28_feature_gate_matrix.yaml`
- matrix integrity check: `scripts/check_phase28_w2s1.sh`
- required release lane command: `cargo test --workspace --release -F z00z_simulator/test-fast,z00z_wallets/test-fast,z00z_simulator/wallet_debug_dump`

**Definition of done (`W2-S1`):**

- Zero release-reachable skeleton path without explicit `compile-ready` or `release-gated` status.
- No release-lane regression introduced by hygiene actions.

**28.2 Progress checklist:**

- [x] Skeleton/incomplete path inventory captured and linked.
- [x] Every listed path tagged as `compile-ready` or `release-gated` (no third state).
- [x] Feature-gate matrix linked with module → status → release impact mapping.
- [x] Required release lane output linked and green for this cycle.
- [x] `T-4` updated to `done` in synchronized triage/backlog artifacts.

### 28.3 W2-S2 closure plan (`T-5 Domain drift-test hygiene`)

🎯 **Objective:** replace fragile/static domain assumptions with deterministic drift-detection tests.

**Required actions:**

- Replace static domain-count checks with dynamic baseline derived from active domain registry/constants.
- Add explicit injected-drift negative scenario that MUST fail when domain mapping/order/policy is altered.
- Add explicit baseline positive scenario that MUST pass on current canonical domain policy.
- Ensure tests verify both wallet and verifier-consumed domain behavior where applicable.

**Mandatory evidence:**

- One negative test artifact (injected drift) showing expected fail condition.
- One positive baseline artifact showing expected pass condition.
- `T-5` status updated to `done` in triage/backlog artifacts.
- Required release lane remains green after test changes.

**W2-S2 linked evidence (current cycle):**

- drift/baseline checker: `scripts/check_phase28_w2s2.sh`
- baseline positive tests: `test_rid_domain_parity`, `test_view_domain_parity`
- injected-drift negative tests: `test_rid_drift_fail`, `test_view_drift_fail`, `test_domain_base_live`
- required release lane command: `cargo test --workspace --release -F z00z_simulator/test-fast,z00z_wallets/test-fast,z00z_simulator/wallet_debug_dump`

**Definition of done (`W2-S2`):**

- Drift is detectable by tests (not by manual log inspection).
- Baseline and drift cases are both stable and non-flaky.
- `CP-1` guard quality is demonstrably hardened versus pre-fix static checks.

**28.3 Progress checklist:**

- [x] Static domain-count assumptions removed from active guard tests.
- [x] Injected-drift negative test added, linked, and verified to fail on drift.
- [x] Baseline positive test added, linked, and verified to pass on canonical policy.
- [x] Wallet/verifier domain-consumption parity coverage linked.
- [x] `T-5` updated to `done` in synchronized triage/backlog artifacts.
- [x] Required release lane output linked and green after drift-test changes.

### 28.4 W3-S1 closure plan (Full CP evidence convergence)

🎯 **Objective:** close final convergence gate by proving `CP-1..CP-5` green in the same RC cycle.

**Required actions:**

- Build one RC evidence bundle covering code, vectors, tests, and spec sync.
- Attach one proof row per checkpoint:
  - `CP-1 Domain parity`
  - `CP-2 Wire parity`
  - `CP-3 Proof path parity`
  - `CP-4 Interop parity`
  - `CP-5 Release gate`
- Add links in this section to all required artifacts (test logs, fixtures/vectors, docs/spec deltas).
- Reconfirm no unresolved closure-evidence gaps exist across `T-1..T-9` (and therefore no unresolved critical items) at sign-off time.

**Mandatory evidence table template (fill with links):**

| Checkpoint | Status | Evidence link(s) | Notes |
| --- | --- | --- | --- |
| CP-1 | green | `outputs/phase28_w3s1/check_phase28_w2s2.log`; `crates/z00z_wallets/tests/test_spec_terms_guard.rs`; `scripts/check_phase28_w2s2.sh` | Domain parity and injected-drift detection are both covered. |
| CP-2 | green | `outputs/phase28_w3s1/check_phase26_drift.log`; `outputs/phase28_w3s1/test_phase3_formats.log`; `crates/z00z_core/tests/vectors/asset_pack_vectors.yaml` | Wire vectors/parsers and phase wire checks are synchronized. |
| CP-3 | green | `outputs/phase28_w3s1/test_phase24_gate.log`; `outputs/phase28_w3s1/check_phase24_drift.log`; `crates/z00z_wallets/tests/test_phase24_gate.rs` | Proof-path and checkpoint invariants are green in the same cycle. |
| CP-4 | green | `outputs/phase28_w3s1/test_phase3_formats.log`; `outputs/phase28_w3s1/release_lane.log`; `specs/010-z00z-tx-spec/z00z-tx-spec.md` (§11, §26) | Card/Request interop parity is validated under canonical domain policy. |
| CP-5 | green | `scripts/check_phase28_w3s1.sh`; `outputs/phase28_w3s1/release_lane.log`; `outputs/phase28_w3s1/check_phase26_gate.log`; `crates/z00z_wallets/tests/fixtures/phase26_backlog.yaml` | Unified gate is green, release lane is green, and triage statuses are fully checked in one pass. |

📌 **Table integrity rule:** each checkpoint row MUST contain at least one immutable evidence pointer (CI job URL, artifact path, or commit hash), not free-text-only notes.

**Definition of done (`W3-S1`):**

- All `CP-1..CP-5` are marked `green` with concrete evidence links.
- All `T-1..T-9` items have closure evidence consistent with §27.6 (not only critical subset).
- Section `27.7` can be fully checked with no open items.

**28.4 Progress checklist:**

- [x] CP evidence table filled with final statuses (`green`/`red`) and immutable pointers.
- [x] CP-1 evidence linked (domain parity vectors/tests/docs).
- [x] CP-2 evidence linked (wire vectors/parsers/docs).
- [x] CP-3 evidence linked (proof path parity/transcript coverage).
- [x] CP-4 evidence linked (interop parity for card/request flows).
- [x] CP-5 evidence linked (release lane + triage gate consistency).
- [x] Final `T-1..T-9` closure-evidence consistency check linked (`scripts/check_phase28_w3s1.sh`).

### 28.5 Crypto-correctness guardrails for W2/W3

✅ `W2` tasks are hygiene/test-hardening tasks and MUST NOT silently change canonical crypto domain policy established by `W1` (`T-6`, `T-8`, `T-9`).

✅ If any crypto-sensitive behavior is touched while closing `W2`/`W3`, the cycle MUST include:

- refreshed affected vectors,
- parity tests for wallet/verifier paths,
- explicit spec delta in §§11/26/27/28.

⛔ Any untracked crypto behavior drift discovered during `W2`/`W3` immediately re-opens corresponding T-item and blocks sign-off.

**28.5 Progress checklist:**

- [x] Confirmed no silent domain-policy changes relative to `W1` (`T-6/T-8/T-9`).
- [x] For crypto-sensitive deltas, refreshed vectors are linked.
- [x] For crypto-sensitive deltas, wallet/verifier parity tests are linked.
- [x] For crypto-sensitive deltas, spec deltas in §§11/26/27/28 are linked.
- [x] If drift was detected, corresponding T-item re-open action is recorded (no drift detected in this cycle).

### 28.6 Final closure checklist (must all be true)

- [x] `W2-S1` done, with feature-gate matrix linked.
- [x] `W2-S2` done, with injected-drift negative + baseline positive evidence linked.
- [x] `W3-S1` done, with full CP-1..CP-5 table marked green.
- [x] Required release lane output linked for final RC.
- [x] Triage artifacts (`T-4`, `T-5`) updated to `done` and synchronized with this spec.
- [x] Section `27.7` updated to all checked.

