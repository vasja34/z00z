# Scenario 1 Asset Wire DTO Spec

## Step Plan

### Objective

📌 This document defines the only acceptable implementation plan for freezing the external `asset_wire` contract used by Scenario 1 artifacts, wallet RPC payloads, tx packages, and claim packages.

📌 The main objective is to eliminate every direct external JSON dependency on the internal `AssetWire` serde shape and to force all human-readable external payloads through one stable DTO contract.

📌 The implementation must build on the already existing `AssetPkgWire` type. It must not introduce a second external transport struct, a transitional alias, or a parallel JSON schema.

📌 This document is intentionally prescriptive. It is written to remove implementation ambiguity and to prevent a second migration or cleanup pass.

Checklist:

- [x] Treat this document as mandatory implementation guidance, not as a brainstorming note.
- [x] Reject any implementation that introduces a second external asset DTO.
- [x] Reject any implementation that keeps both `AssetWire` JSON and `AssetPkgWire` JSON active as equal public contracts.
- [x] Require one final state only: `AssetPkgWire` is the sole human-readable external asset DTO.
- [x] Require all code review comments and follow-up work to be measured against this final state.

### Current State

📌 The codebase currently has two related wire carriers.

```rust
// crates/z00z_core/src/assets/wire.rs
pub struct AssetWire {
    pub definition: AssetDefinition,
    pub serial_id: u32,
    pub amount: u64,
    pub commitment: Commitment,
    pub range_proof: Option<RangeProof>,
    pub nonce: [u8; 32],
    pub lock_height: Option<u64>,
    pub is_burned: bool,
    pub owner_pub: Option<PublicKey>,
    pub owner_signature: Option<KernelSignature>,
    pub is_frozen: bool,
    pub is_slashed: bool,
    pub r_pub: Option<[u8; 32]>,
    pub owner_tag: Option<[u8; 32]>,
    pub enc_pack: Option<ZkPackEncrypted>,
    pub secret: Option<[u8; 32]>,
    pub tag16: Option<u16>,
}
```

```rust
// crates/z00z_core/src/assets/wire_pkg.rs
pub struct AssetPkgWire {
    pub definition: AssetDefinition,
    pub serial_id: u32,
    pub amount: u64,
    pub commitment: Commitment,
    pub range_proof: Option<RangeProof>,
    pub nonce: [u8; 32],
    pub lock_height: Option<u64>,
    pub is_burned: bool,
    pub owner_pub: Option<PublicKey>,
    pub owner_signature: Option<KernelSignature>,
    pub r_pub: Option<[u8; 32]>,
    pub owner_tag: Option<[u8; 32]>,
    pub enc_pack: Option<ZkPackEncrypted>,
    pub tag16: Option<u16>,
}
```

📌 `AssetPkgWire` is already structurally close to the desired external DTO because it excludes wallet-local mutable runtime fields such as `is_frozen`, `is_slashed`, and `secret`.

📌 The remaining problem is not only type shape. The real problem is inconsistent boundary usage.

📌 One active outbound RPC path still serializes the internal `AssetWire` directly.

```rust
// crates/z00z_wallets/src/adapters/rpc/methods/tx_impl.rs
fn encode_asset_wire(wire: &z00z_core::assets::AssetWire) -> RpcResult<String> {
    let bytes = JsonCodec.serialize(wire)?;
    String::from_utf8(bytes)?
}
```

📌 One active inbound RPC path still accepts external JSON by deserializing directly into `AssetWire`.

```rust
// crates/z00z_wallets/src/adapters/rpc/methods/asset_impl.rs
let wire: AssetWire = codec.deserialize(asset_data.as_bytes())?;
```

📌 Multiple tests and simulator helpers still emit raw `AssetWire` JSON, which means the existing regression surface is broader than the verify RPC path alone.

Checklist:

- [x] Confirm that outbound direct serialization exists in `tx_impl.rs` before changing code.
- [x] Confirm that inbound direct deserialization exists in `asset_impl.rs` before changing code.
- [x] Enumerate every helper and test that still emits `serde_json::to_string(&wire)` or `JsonCodec.serialize(wire)`.
- [x] Record every file that treats raw `AssetWire` JSON as an external contract.
- [x] Reject any migration scope proposal that covers outbound only and ignores inbound acceptance.

### Decision Summary

📌 The implementation will treat `AssetPkgWire` as the canonical frozen external DTO for Scenario 1 version 1.

📌 The implementation will not introduce a new third transport struct unless the code proves a real representational gap. No such gap is currently known.

📌 The implementation will enforce the following layering.

```mermaid
flowchart TD
    A[Internal Asset] --> B[AssetWire internal mutable transport]
    B --> C[AssetPkgWire frozen external DTO]
    C --> D[JSON files]
    C --> E[TxPackage and ClaimTxPackage]
    C --> F[wallet.tx.verify_transaction_package RPC]
    C --> G[wallet.asset.import_asset payloads]
```

📌 After the migration, raw human-readable external JSON must never be produced from `AssetWire` directly.

📌 After the migration, raw human-readable external JSON must never be accepted by parsing directly into `AssetWire` at RPC boundaries.

📌 `AssetWire` will remain an internal mutable transport type. It will still be allowed behind typed Rust boundaries and for non-human-readable internal serde fallback behavior already implemented by `AssetPkgWire`.

Checklist:

- [x] Freeze one external DTO decision: `AssetPkgWire` only.
- [x] Freeze one inbound policy: RPC JSON must decode through `AssetPkgWire`, not `AssetWire`.
- [x] Freeze one outbound policy: RPC JSON must encode through `AssetPkgWire`, not `AssetWire`.
- [x] Preserve `AssetWire` only as an internal typed bridge.
- [x] Reject any patch that weakens this layering by reintroducing ad hoc JSON calls on `AssetWire`.

### Why This Change Is Needed

📌 `AssetWire` is an internal representation with fields that belong to mutable runtime state, wallet-local state, and secret-bearing state. That makes it unsuitable as a frozen transport contract.

📌 External artifacts must remain stable when internal code evolves. The JSON contract must not change because a local-only field is added, renamed, or retyped.

📌 Without this split, a harmless internal refactor can silently break:

- `outputs/transactions/tx_alice_to_bob_pkg.json`
- `outputs/claim/claimed_assets_*.json`
- Bob-side verify/import RPC payloads
- Stage 3 `wallet_debug_dump` post-analysis artifacts
- test fixtures that assert import taxonomy and replay behavior

📌 The migration therefore aims to freeze all externally visible `asset_wire` JSON behind one controlled type, one controlled encoding policy, and one controlled decode policy.

Checklist:

- [x] State explicitly in code comments that `AssetWire` is not a frozen external contract.
- [x] State explicitly in code comments that `AssetPkgWire` is the frozen external contract.
- [x] Tie the motivation to specific artifact classes, RPC boundaries, and security tests.
- [x] Reject generic wording such as “cleanup” or “consistency” without naming the broken boundaries.
- [x] Require reviewers to verify that the final implementation actually removes contract drift risk, not just one serializer call.

### Frozen DTO Contract

📌 The canonical external DTO for Scenario 1 will be `AssetPkgWire` with deny-unknown-fields behavior for human-readable JSON.

📌 The external contract must keep these fields.

| Field | Keep | Reason |
| --- | --- | --- |
| `definition` | yes | required for self-contained import |
| `serial_id` | yes | required for leaf identity and spend flow |
| `amount` | yes | required for wallet-visible recovered asset |
| `commitment` | yes | required for balance and proof validation |
| `range_proof` | yes | required for confidential amount validation |
| `nonce` | yes | required for deterministic binding |
| `lock_height` | yes | preserve transport semantics |
| `is_burned` | yes | preserve transport semantics |
| `owner_pub` | yes | preserve optional public ownership fields |
| `owner_signature` | yes | preserve optional public signature fields |
| `r_pub` | yes | required for scanner ECDH path |
| `owner_tag` | yes | required for ownership prefilter |
| `enc_pack` | yes | required for wallet recovery |
| `tag16` | yes | required for scan acceleration contract |

📌 The external contract must never expose these internal-only fields.

| Field | Keep | Reason |
| --- | --- | --- |
| `is_frozen` | no | mutable wallet-local state |
| `is_slashed` | no | mutable wallet-local state |
| `secret` | no | forbidden portable secret material |

📌 The external JSON encoding policy must stay hex-first because `AssetPkgWire` already serializes nested byte-like fields as hex strings instead of raw integer arrays.

📌 The migration must preserve cryptographic completeness. No implementation is allowed to drop `commitment`, `range_proof`, `owner_signature`, `r_pub`, `owner_tag`, `enc_pack`, or `tag16` from the external contract.

Checklist:

- [x] Preserve every field listed as required in the DTO.
- [x] Preserve current hex-oriented JSON encoding for binary-like fields.
- [x] Keep `serde(deny_unknown_fields)` for human-readable DTO JSON.
- [x] Verify that omitted fields are exactly `is_frozen`, `is_slashed`, and `secret`, and no others.
- [x] Reject any “simplification” that removes cryptographically relevant fields from the DTO.

### Inbound Boundary Policy

📌 The wallet import boundary must stop accepting human-readable external JSON by deserializing directly into `AssetWire`.

📌 `wallet.asset.import_asset` must decode the incoming JSON into `AssetPkgWire`, validate the DTO, and only then convert into `AssetWire` or `Asset` for internal verification and persistence.

📌 The import path must not rely on implicit compatibility between `AssetWire` serde and the external JSON contract.

📌 The only permitted decode flow is:

```mermaid
flowchart LR
    A[asset_data JSON] --> B[decode AssetPkgWire]
    B --> C[DTO validation]
    C --> D[convert to AssetWire or Asset]
    D --> E[verify_complete and storage path]
```

Checklist:

- [x] Change `wallet.asset.import_asset` to decode JSON into `AssetPkgWire` first.
- [x] Keep all subsequent asset verification on typed internal values after DTO decode.
- [x] Remove direct human-readable `AssetWire` decode from public RPC import paths.
- [x] Verify that simulator import helpers and wallet tests now pass DTO JSON, not raw `AssetWire` JSON.
- [x] Reject any implementation that leaves `asset_impl.rs` parsing human-readable JSON into `AssetWire`.

### Security Taxonomy Policy

📌 The migration must preserve the current error taxonomy semantics of `wallet.asset.import_asset`.

📌 The implementation must keep distinct outcomes for at least these cases:

- malformed JSON shape
- forbidden secret field in the incoming payload
- cryptographic verification failure such as tampered signature or invalid range proof
- stealth payload inconsistency such as partial stealth fields

📌 Because `AssetPkgWire` uses deny-unknown-fields for human-readable JSON, the implementation must add an explicit pre-decode guard for the forbidden `secret` field if the project still requires the dedicated `IMPORT_SECRET_FIELD_FORBIDDEN` error code.

📌 The implementation must not collapse the current taxonomy into a single generic invalid JSON failure.

Checklist:

- [x] Preserve `IMPORT_SECRET_FIELD_FORBIDDEN` behavior if that code is part of the supported import taxonomy.
- [x] Preserve `IMPORT_CRYPTO_VERIFY_FAILED` for tampered signature and invalid range proof cases.
- [x] Preserve `IMPORT_STEALTH_INCONSISTENT` for partial stealth payload cases.
- [x] Distinguish malformed JSON from semantically forbidden JSON.
- [x] Reject any parser refactor that downgrades a previously specific import failure into a generic decode failure.

### Legacy Payload Policy

📌 This migration must define the legacy policy explicitly before implementation begins.

📌 The default policy for this pass is strict cutover for human-readable RPC JSON: once the migration lands, new runtime code must emit and accept only DTO JSON for public RPC import and verify flows.

📌 Old fixtures or legacy samples may remain only as test assets if they are intentionally covered by dedicated compatibility tests. They must not silently define the active runtime contract.

📌 If backward compatibility with old raw `AssetWire` JSON samples is required, that requirement must be implemented as an explicit compatibility layer with explicit tests. It must not be preserved accidentally by leaving direct `AssetWire` decode in place.

Checklist:

- [x] Decide strict cutover versus explicit compatibility layer before editing runtime code.
- [x] Default to strict cutover unless a stated compatibility requirement exists.
- [x] If compatibility is required, encode it as a separate tested behavior, not as accidental fallback.
- [x] If compatibility is not required, remove legacy helper usage from active tests and simulator support code.
- [x] Reject any ambiguous “compatible enough” wording that leaves runtime behavior undefined.

### Exact Migration Scope

📌 The migration must touch every path that either serializes internal `AssetWire` directly or accepts human-readable external JSON as if `AssetWire` were the public contract.

📌 Mandatory runtime files to change.

- `crates/z00z_core/src/assets/wire_pkg.rs`
- `crates/z00z_wallets/src/adapters/rpc/methods/tx_impl.rs`
- `crates/z00z_wallets/src/adapters/rpc/methods/asset_impl.rs`

📌 Mandatory wallet tests to change.

- `crates/z00z_wallets/tests/test_direct_tx_receive.rs`
- `crates/z00z_wallets/tests/test_asset_import_security.rs`
- `crates/z00z_wallets/tests/test_asset_replay_protection.rs`
- `crates/z00z_wallets/tests/test_import_error_taxonomy.rs`

📌 Mandatory simulator support and validation files to verify and adjust.

- `crates/z00z_simulator/tests/support/stage4_bob.rs`
- `crates/z00z_simulator/src/scenario_1/stage_3.rs`
- `crates/z00z_simulator/src/scenario_1/stage_3_utils/wallet_flow.rs`
- `crates/z00z_simulator/src/scenario_1/stage_4.rs`
- `crates/z00z_simulator/tests/test_claim_pkg_runtime.rs`
- `crates/z00z_simulator/tests/test_stage4_bob_flow.rs`

📌 Runtime package structs in `tx_verifier.rs` and `claim_tx.rs` are expected to remain structurally stable because they already use `AssetPkgWire`, but they must still be reviewed as part of the regression surface.

Checklist:

- [x] Change all mandatory runtime files listed in this section.
- [x] Update all mandatory tests listed in this section.
- [x] Review every simulator helper listed in this section for raw `AssetWire` JSON usage.
- [x] Verify `tx_verifier.rs` and `claim_tx.rs` remain structurally compatible without unnecessary refactor.
- [x] Reject any “phase 1 only” scope cut that leaves `asset_impl.rs` or security tests untouched.

### Concrete Implementation Plan

📌 The implementation must follow the exact order below. Reordering is not allowed because it increases the chance of partial migration and inconsistent intermediate states.

Checklist:

- [x] Execute the steps in the order defined below.
- [x] Do not start simulator validation before runtime boundaries are fixed.
- [x] Do not update tests before the required runtime decode and encode helpers exist.
- [x] Do not mark the migration complete until the release validation step passes.
- [x] Reject opportunistic refactors that are not required by a later step in this plan.

### Step 1: Freeze the Architectural Role of `AssetPkgWire`

📌 Update comments and docs in `crates/z00z_core/src/assets/wire_pkg.rs` so the type is explicitly declared as the canonical frozen external DTO for tx packages, claim packages, wallet verify payloads, wallet import payloads, and Scenario 1 artifacts.

📌 This step is documentation and invariants only. It must not change runtime behavior yet.

📌 Expected code change shape:

```rust
/// Canonical frozen external DTO for asset transport.
///
/// This type defines the frozen human-readable JSON contract for tx packages,
/// claim packages, wallet verify/import payloads, and Scenario 1 artifacts.
pub struct AssetPkgWire { ... }
```

Checklist:

- [x] Add explicit DTO-role doc comments to `AssetPkgWire`.
- [x] State that `AssetPkgWire` defines the frozen human-readable external JSON contract.
- [x] State that `AssetWire` remains internal.
- [x] Avoid changing any behavior in this step.
- [x] Reject any runtime code edits in this step other than documentation and comments.

### Step 2: Centralize Human-Readable DTO JSON Helpers

📌 The codebase must stop performing ad hoc JSON encode and decode for `AssetPkgWire` at call sites.

📌 `wire_pkg.rs` must expose centralized helper functions for human-readable DTO JSON so that all RPC and artifact boundaries call one shared implementation.

📌 Required helper surface.

```rust
pub fn encode_asset_pkg_json(dto: &AssetPkgWire) -> Result<Vec<u8>, AssetError>;
pub fn decode_asset_pkg_json(bytes: &[u8]) -> Result<AssetPkgWire, AssetError>;
pub fn payload_has_secret_field(bytes: &[u8]) -> Result<bool, AssetError>;
```

📌 The helper surface must stay byte-based so the DTO public API does not need to expose raw `serde_json` value types.

📌 Existing `from_wire`, `to_wire`, `from_asset`, and `to_asset` methods already exist and must be reused rather than reintroduced.

Checklist:

- [x] Add centralized human-readable JSON encode helper.
- [x] Add centralized human-readable JSON decode helper.
- [x] Add centralized forbidden-field inspection helper for `secret`.
- [x] Reuse existing `from_wire`, `to_wire`, `from_asset`, and `to_asset` methods.
- [x] Do not introduce new ad hoc public-boundary JSON calls in this step; replacement of existing boundary call sites remains Step 3.

### Step 3: Replace Outbound Direct `AssetWire` Serialization

📌 Replace direct JSON serialization of `AssetWire` with conversion through `AssetPkgWire` in wallet verify flow and in any simulator helper that emits public asset payloads.

📌 The minimum required runtime change is in `tx_impl.rs`, but support helpers must also stop emitting raw `AssetWire` JSON.

📌 The target shape is:

```rust
fn encode_asset_wire(wire: &z00z_core::assets::AssetWire) -> RpcResult<String> {
    let dto = AssetPkgWire::from_wire(wire);
    let bytes = encode_asset_pkg_json(&dto)?;
    String::from_utf8(bytes)?
}
```

Checklist:

- [x] Replace direct `AssetWire` JSON serialization in `tx_impl.rs`.
- [x] Replace direct `AssetWire` JSON serialization in simulator helpers that feed RPC import.
- [x] Replace direct raw JSON emission in wallet tests where the payload is meant to model the public contract.
- [x] Keep internal typed conversions untouched unless required.
- [x] Reject any remaining human-readable `AssetWire` serializer call in runtime or support helpers.

### Step 4: Replace Inbound Direct `AssetWire` Deserialization

📌 Replace direct JSON deserialization into `AssetWire` in `wallet.asset.import_asset` with a strict DTO decode path.

📌 The import method must parse JSON into `serde_json::Value`, apply the forbidden-secret inspection, decode into `AssetPkgWire`, validate the DTO, convert into internal asset form, and continue with the existing verify path.

📌 The import method must not deserialize human-readable RPC JSON directly into `AssetWire` anymore.

Checklist:

- [x] Parse incoming `asset_data` into a JSON value before DTO decode.
- [x] Inspect the JSON value for the forbidden `secret` field before DTO decode.
- [x] Decode the payload into `AssetPkgWire`.
- [x] Convert the DTO into internal asset form only after DTO decode succeeds.
- [x] Reject any direct `codec.deserialize::<AssetWire>` on public import JSON.

### Step 5: Preserve Security Taxonomy and Reject Codes

📌 The migration must preserve the current import error taxonomy semantics.

📌 The import path must continue to produce specific error codes for malformed JSON, forbidden secret field, cryptographic verification failure, and stealth inconsistency.

📌 The implementation must add or update tests so these mappings remain fixed across the DTO cutover.

Checklist:

- [x] Preserve `IMPORT_SECRET_FIELD_FORBIDDEN` for incoming payloads containing `secret`.
- [x] Preserve `IMPORT_CRYPTO_VERIFY_FAILED` for tampered signature payloads.
- [x] Preserve `IMPORT_CRYPTO_VERIFY_FAILED` for invalid range proof payloads.
- [x] Preserve `IMPORT_STEALTH_INCONSISTENT` for partial stealth payloads.
- [x] Reject any implementation that turns a previously specific failure into generic invalid JSON.

### Step 6: Add Guard Rails Against Reintroduction

📌 Add focused tests that fail if internal `AssetWire` fields leak into external DTO JSON or if DTO JSON no longer round-trips correctly.

📌 The first required assertions are:

- serialized `AssetPkgWire` JSON contains no `secret`
- serialized `AssetPkgWire` JSON contains no `is_frozen`
- serialized `AssetPkgWire` JSON contains no `is_slashed`
- serialized `AssetPkgWire` JSON still round-trips into an `Asset`
- DTO JSON rejects unknown fields by default

Checklist:

- [x] Add a unit test that asserts forbidden fields never appear in DTO JSON.
- [x] Add a unit test that asserts DTO JSON round-trips into a valid `Asset`.
- [x] Add a unit test that asserts unknown fields are rejected for human-readable DTO JSON.
- [x] Add a unit test that preserves current hex encoding expectations.
- [x] Reject any guard-rail suite that tests only absence of fields but not decode behavior.

### Step 7: Align RPC Verify and Import Tests With DTO Reality

📌 Update `crates/z00z_wallets/tests/test_direct_tx_receive.rs` so the test intentionally checks the frozen external DTO contract rather than merely proving that import succeeds with some JSON blob.

📌 Update wallet security, replay, and taxonomy tests so they construct DTO JSON intentionally, except in explicit compatibility tests if legacy support is required.

Checklist:

- [x] Assert that `asset_data` returned by verify is DTO JSON.
- [x] Assert that verify output omits forbidden fields.
- [x] Update import security tests to mutate DTO JSON, not raw `AssetWire` JSON, for contract-relevant cases.
- [x] Update replay protection helpers to send DTO JSON.
- [x] Reject any test suite that still exercises the old contract accidentally instead of deliberately.

### Step 8: Validate Stage 3 and Stage 4 Contracts Stay Compatible

📌 No large simulator refactor is allowed in this DTO pass.

📌 Stage 3 and Stage 4 are expected to remain structurally stable because package payloads already use `AssetPkgWire`, but all ingress and egress helpers must be reviewed to ensure no side path still emits or consumes raw `AssetWire` JSON as the public contract.

```rust
pub struct TxOutputWire {
    pub asset_wire: AssetPkgWire,
}

pub struct ClaimOutputWire {
    pub asset_wire: Option<AssetPkgWire>,
}
```

Checklist:

- [x] Verify that `TxOutputWire` and `ClaimOutputWire` remain DTO-based.
- [x] Review Stage 3 helper flows for import payload construction.
- [x] Review Stage 4 helper flows for verify and import payload construction.
- [x] Make only the smallest helper edits necessary to remove raw `AssetWire` JSON usage.
- [x] Reject any broad orchestration refactor in this step.

### Step 9: Run the Full Regression Matrix in Release Mode

📌 After the runtime and test boundary fixes are complete, run the full required regression matrix in release mode.

📌 Required wallet tests.

```bash
cargo test -p z00z_wallets --test test_direct_tx_receive --release --features test-fast -- --nocapture
cargo test -p z00z_wallets --test test_asset_import_security --release --features test-fast -- --nocapture
cargo test -p z00z_wallets --test test_asset_replay_protection --release --features test-fast -- --nocapture
cargo test -p z00z_wallets --test test_import_error_taxonomy --release --features test-fast -- --nocapture
```

📌 Required simulator tests.

```bash
cargo test -p z00z_simulator --release --features test-fast --features wallet_debug_dump --test test_claim_persist -- --nocapture
cargo test -p z00z_simulator --release --features test-fast --features wallet_debug_dump --test test_claim_post -- --nocapture
cargo test -p z00z_simulator --release --features test-fast --features wallet_debug_dump --test test_claim_pkg_runtime -- --nocapture
cargo test -p z00z_simulator --release --features test-fast --features wallet_debug_dump --test test_stage4_bob_flow -- --nocapture
```

📌 The goal is to confirm that frozen DTO JSON survives verify, import, claim artifacts, replay protections, taxonomy checks, and persisted `.wlt` debug export paths.

Checklist:

- [x] Run every wallet test command listed in this section.
- [x] Run every simulator test command listed in this section.
- [x] Run all commands in release mode exactly as specified.
- [x] Investigate and fix any failure before considering the migration complete.
- [x] Reject a “green enough” outcome where only one happy-path test passes.

### Detailed File-by-File Changes

📌 The file-specific requirements below are mandatory and must be implemented exactly.

Checklist:

- [x] Use the file-specific requirements below as a completion checklist.
- [x] Do not treat any listed file as optional.
- [x] Keep edits focused to the DTO migration and required tests.
- [x] Avoid unrelated refactors in listed files.
- [x] Reject completion claims that do not reference every listed file section.

### `crates/z00z_core/src/assets/wire_pkg.rs`

📌 Planned edits.

- strengthen doc comments to declare DTO role
- add centralized human-readable JSON encode and decode helpers
- add forbidden-secret inspection support
- keep `serde(deny_unknown_fields)` for human-readable JSON
- preserve current hex encoding strategy
- add tests for forbidden-field exclusion, unknown-field rejection, and round-trip behavior

📌 This file is the DTO source of truth.

Checklist:

- [x] Add DTO-role documentation.
- [x] Add centralized JSON helper functions.
- [x] Preserve existing conversion helpers.
- [x] Add DTO-focused tests in this module or its test file.
- [x] Reject any edit that weakens strict human-readable DTO decoding.

### `crates/z00z_wallets/src/adapters/rpc/methods/tx_impl.rs`

📌 Planned edits.

- replace direct `AssetWire` serialization with `AssetPkgWire::from_wire`
- route serialization through centralized DTO JSON helpers
- keep `RuntimeVerifyTxPkgOut.asset_data` as a JSON string, but ensure it is DTO JSON
- keep RPC output behavior stable apart from the contract shape freeze

📌 This file is the highest-risk active outbound leak point.

Checklist:

- [x] Replace direct `AssetWire` encode logic.
- [x] Use centralized DTO helper functions.
- [x] Keep the public RPC response shape stable.
- [x] Assert that produced `asset_data` is DTO JSON in tests.
- [x] Reject any fallback to direct `JsonCodec.serialize(wire)`.

### `crates/z00z_wallets/src/adapters/rpc/methods/asset_impl.rs`

📌 Planned edits.

- replace direct `AssetWire` JSON decode with DTO decode
- add forbidden-secret inspection before strict DTO decode
- preserve import error taxonomy
- convert DTO to internal asset form only after DTO validation

📌 This file is the highest-risk active inbound leak point.

Checklist:

- [x] Remove public-path `AssetWire` JSON decode.
- [x] Add pre-decode forbidden-secret inspection.
- [x] Preserve specific import reject reasons.
- [x] Continue using existing cryptographic verification after DTO conversion.
- [x] Reject any implementation that passes malformed taxonomy tests by accident.

### `crates/z00z_wallets/tests/test_direct_tx_receive.rs`

📌 Planned edits.

- add assertions that `asset_data` is DTO JSON
- add assertions that forbidden internal fields are absent
- keep the existing behavior test intact: verify first, import later, then list and balance checks
- ensure the test no longer models raw `AssetWire` JSON as the intended public contract

📌 This test becomes the primary verify-to-import contract guard.

Checklist:

- [x] Assert DTO JSON shape.
- [x] Assert forbidden field absence.
- [x] Preserve verify then import behavior checks.
- [x] Keep release-mode compatibility.
- [x] Reject any assertion set that ignores the actual `asset_data` content.

### `crates/z00z_wallets/tests/test_asset_import_security.rs`

📌 Planned edits.

- mutate DTO JSON for tampered signature cases
- mutate DTO JSON for invalid range proof cases
- mutate DTO JSON for partial stealth cases
- keep all existing reject code expectations stable

📌 This file is the authoritative guard for import-side security behavior.

Checklist:

- [x] Rewrite contract-facing payload builders to DTO JSON.
- [x] Preserve tampered signature rejection checks.
- [x] Preserve invalid range proof rejection checks.
- [x] Preserve partial stealth rejection checks.
- [x] Reject any rewrite that simplifies away the negative cases.

### `crates/z00z_wallets/tests/test_asset_replay_protection.rs`

📌 Planned edits.

- replace raw `AssetWire` JSON helper emission with DTO JSON emission
- preserve replay semantics and wallet balance assertions
- keep test intent unchanged while updating only the contract carrier

Checklist:

- [x] Replace public payload generation with DTO JSON.
- [x] Preserve replay protection assertions.
- [x] Preserve balance and ownership checks.
- [x] Keep helper naming explicit about DTO payloads.
- [x] Reject any helper that still serializes raw `AssetWire` as the contract.

### `crates/z00z_wallets/tests/test_import_error_taxonomy.rs`

📌 Planned edits.

- preserve the dedicated `IMPORT_SECRET_FIELD_FORBIDDEN` expectation
- update any payload builders that rely on raw `AssetWire` JSON
- confirm malformed JSON, forbidden field, and semantic failures still map to distinct errors

Checklist:

- [x] Keep the dedicated secret-field taxonomy assertion.
- [x] Keep malformed JSON taxonomy assertions.
- [x] Keep semantic verification taxonomy assertions.
- [x] Update helpers to DTO JSON where the active contract is being tested.
- [x] Reject any taxonomy drift introduced by the DTO cutover.

### `crates/z00z_simulator/tests/support/stage4_bob.rs`

📌 Planned edits.

- replace helper emission of raw `AssetWire` JSON with DTO JSON
- keep helper purpose unchanged
- keep Stage 4 Bob-flow test orchestration unchanged

Checklist:

- [x] Replace helper serialization with DTO JSON.
- [x] Preserve helper call signatures unless a rename is required for clarity.
- [x] Keep simulator transport interactions unchanged.
- [x] Verify helper output matches the new frozen contract.
- [x] Reject any silent retention of raw `AssetWire` JSON in support code.

### `crates/z00z_simulator/src/scenario_1/stage_3.rs`

📌 Planned edits in the first pass are expected to be zero or minimal.

📌 Stage 3 already routes claim payload structure through `AssetPkgWire`. Only ingress or egress helper glue may need adjustment if it still assumes raw `AssetWire` JSON externally.

Checklist:

- [x] Verify Stage 3 package generation already uses `AssetPkgWire`.
- [x] Verify Stage 3 import glue does not assume raw `AssetWire` JSON.
- [x] Make only the minimum edits required by DTO boundary changes.
- [x] Preserve Stage 3 behavior and artifact semantics.
- [x] Reject opportunistic Stage 3 refactors.

### `crates/z00z_simulator/src/scenario_1/stage_3_utils/wallet_flow.rs`

📌 Planned edits are expected to be minimal and limited to import payload compatibility with the new DTO-only boundary.

Checklist:

- [x] Review every `wallet.asset.import_asset` call path.
- [x] Ensure payload builders provide DTO JSON only.
- [x] Keep wallet-flow orchestration unchanged.
- [x] Preserve logging and assertions.
- [x] Reject non-boundary refactors in this helper module.

### `crates/z00z_simulator/src/scenario_1/stage_4.rs`

📌 Planned edits in the first pass are expected to be zero or minimal because Stage 4 already constructs `TxOutputWire { asset_wire: AssetPkgWire }`.

📌 The implementation must only verify that no side helper or export path bypasses the DTO contract.

Checklist:

- [x] Verify Stage 4 tx package generation stays DTO-based.
- [x] Verify Stage 4 import hooks consume DTO JSON only.
- [x] Make only minimal compatibility edits.
- [x] Preserve Stage 4 artifact semantics.
- [x] Reject broad Stage 4 restructuring.

### Non-Goals for This Pass

📌 This DTO pass will not do the following.

- redesign `TxPackage` envelope fields
- redesign `ClaimTxPackage` envelope fields
- change chain metadata semantics
- rewrite Stage 3 or Stage 4 orchestration
- introduce a second frozen DTO beside `AssetPkgWire`
- change wallet-local storage schema

📌 These are separate concerns and would create unnecessary churn and review noise.

Checklist:

- [x] Keep the migration scoped to DTO boundary hardening and required tests.
- [x] Reject envelope redesign work in this pass.
- [x] Reject storage schema work in this pass.
- [x] Reject orchestration refactors in this pass.
- [x] Reject creation of any second external DTO type.

### Review Checklist

📌 The implementation is acceptable only if all items below are true.

- no human-readable external JSON is produced directly from `AssetWire`
- no public RPC import path decodes human-readable JSON directly into `AssetWire`
- `AssetPkgWire` remains the only human-readable external asset carrier in tx and claim packages
- forbidden fields never appear in frozen JSON
- import security taxonomy remains specific and stable
- Bob verify and import flow passes
- Stage 3 release tests with `wallet_debug_dump` pass
- Stage 4 tx package flow remains compatible
- wallet security, replay, and taxonomy tests pass in release mode

Checklist:

- [x] Verify every review-checklist bullet with code or test evidence.
- [x] Require explicit evidence for inbound cutover, not only outbound cutover.
- [x] Require explicit evidence for taxonomy preservation.
- [x] Require explicit evidence for simulator compatibility.
- [x] Reject completion if any bullet is satisfied only by assumption.

### Risk Register

📌 Main implementation risks.

- hidden paths may still deserialize raw `AssetWire` JSON from old helpers or fixtures
- helper naming may suggest DTO freeze while one side path still bypasses it
- strict DTO decode may accidentally collapse security taxonomy into generic malformed JSON
- tests may cover verify flow but miss simulator import or replay paths
- legacy fixture ambiguity may keep accidental backward compatibility alive

📌 Required mitigation.

- grep for `JsonCodec.serialize(wire)`, `serde_json::to_string(&wire)`, and public-path `AssetWire` decode
- add negative tests for forbidden field names and unknown fields
- run the full release regression matrix
- document the legacy policy explicitly in code comments and tests

Checklist:

- [x] Search for every raw `AssetWire` JSON boundary before and after edits.
- [x] Add tests that protect taxonomy-sensitive cases.
- [x] Add tests that protect strict unknown-field rejection.
- [x] Run full release validation after code changes.
- [x] Reject any unresolved risk that is merely deferred without a test or explicit non-goal.

### Follow-Up Work After This DTO Pass

📌 Once the frozen DTO boundary is real and fully validated, the next reviewable follow-up can be one of these:

- freeze the tx and claim package envelope spec in code comments and tests
- add a dedicated external DTO module with versioned naming if Scenario 2 truly needs divergence
- add explicit compatibility fixtures for old package samples if backward compatibility is a real product requirement

📌 None of these follow-ups are allowed to block this migration.

Checklist:

- [ ] Finish this migration before opening any follow-up track.
- [ ] Keep follow-up work separated from the DTO cutover patch.
- [ ] Promote compatibility fixtures only if a real requirement exists.
- [ ] Add versioned DTO naming only if a real divergence appears.
- [ ] Reject speculative future-proofing in the current patch.

### Final Implementation Statement

📌 The implementation will not invent a brand new DTO first.

📌 The implementation will formalize the already existing `AssetPkgWire` as the frozen external DTO, centralize DTO JSON encode and decode, cut over both outbound and inbound public boundaries, preserve import security taxonomy, update the full regression matrix, and validate the live claim and debug-export paths in release mode.

📌 Any implementation that leaves either direct `AssetWire` human-readable serialization or direct `AssetWire` human-readable deserialization on a public boundary is incomplete and must be rejected.

Checklist:

- [x] Complete outbound cutover.
- [x] Complete inbound cutover.
- [x] Preserve security taxonomy.
- [x] Update the full regression matrix.
- [x] Reject the migration as incomplete until all four conditions are true.
