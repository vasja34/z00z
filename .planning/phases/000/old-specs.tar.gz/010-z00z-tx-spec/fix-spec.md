# Scenario 1 Fix Spec

📌 Date: 2026-03-09

📌 This document defines the concrete fix plan for Scenario 1 transaction and checkpoint semantics after re-reading [crates/Z00Z-ECC-SPEC_part1.md](/home/vadim/Projects/z00z/crates/Z00Z-ECC-SPEC_part1.md) and reviewing the current code in `z00z_wallets` and `z00z_simulator`.

📌 The goal is to remove ambiguity around input identity, JMT state keys, fee handling, change handling, aggregator behavior, validator behavior, and the temporary Stage 6 simplifications.

📌 This is an implementation document, not a brainstorming note. Every section below describes target behavior, exact code changes, acceptance criteria, and test scope.

## Scope

📌 The plan covers six concrete points:

1. Canonical input and state identity.
2. Meaning of reference-only transaction inputs.
3. Fee as a full `Coin` asset output.
4. Change outputs and output role constraints.
5. Aggregator and validator invariants.
6. Stage 6 alignment, migration, and tests.

📌 The design basis is the ECC spec, especially these constraints:

- 📌 `asset_id` is the JMT key.
- 📌 `serial_id` is part of leaf binding and public consistency checks.
- 📌 `TxPackage` carries input references and full output leaves.
- 📌 `CheckpointProof` deletes input leaves from `prev_root` and inserts new output leaves.
- 📌 `spent_delta` is keyed by consumed `asset_id` values.

## Current Reality

📌 The current code already matches part of the target model:

- 📌 [crates/z00z_wallets/src/core/tx/tx_verifier.rs](/home/vadim/Projects/z00z/crates/z00z_wallets/src/core/tx/tx_verifier.rs) defines `TxInputWire { asset_id_hex, serial_id }` and `TxOutputWire { asset_wire: AssetPkgWire }`.
- 📌 [crates/z00z_simulator/src/scenario_1/stage_4.rs](/home/vadim/Projects/z00z/crates/z00z_simulator/src/scenario_1/stage_4.rs) builds input references from selected input leaves and full output DTO leaves for new assets.
- 📌 [crates/z00z_wallets/src/core/tx/spending.rs](/home/vadim/Projects/z00z/crates/z00z_wallets/src/core/tx/spending.rs) already proves ownership and checks `asset_id` consistency from `s_in`.
- 📌 [crates/z00z_wallets/src/core/tx/witness_gate.rs](/home/vadim/Projects/z00z/crates/z00z_wallets/src/core/tx/witness_gate.rs) already reconstructs spend witnesses from input leaves and receiver secrets.

📌 The current code still deviates from the target model in two important ways:

- 📌 Fee is a scalar metadata field, not a full leaf in transaction outputs.
- 📌 Stage 6 is still a temporary checkpoint simulator and currently does not model the true JMT delete/insert contract from the ECC spec.

📌 The main engineering risk in this document is not backward compatibility but semantic drift: fee, output roles, and checkpoint deltas must all be corrected consistently, otherwise the codebase will keep mixing the old broken arithmetic with the intended ECC state model.

## Schema Correction Rule

### Correction Rule

📌 The changes proposed in this document are a direct correction of the current `regular_tx` semantics.

📌 There is no separate legacy track in this scope. The implementation must fix the existing schema and all codepaths that currently encode the wrong model.

📌 Therefore:

- 📌 keep the transaction family name `regular_tx`
- 📌 remove all planning that relies on parallel old-versus-new schema branches inside the same codepath
- 📌 treat output roles and fee-output semantics as the canonical corrected design

📌 The required repository rule is simpler:

- 📌 no codepath may preserve the old broken assumption `Σinputs = Σoutputs + fee` once fee becomes a real output leaf
- 📌 no verifier path may accept outputs with roles while still using the old arithmetic

Checklist:

- [x] Remove every code path, comment, and helper assumption that treats fee as external to outputs once fee-output support is introduced.
- [x] Keep a single canonical schema name `regular_tx` across builder, verifier, simulator, tests, and docs.
- [x] Prohibit parallel old-schema and corrected-schema execution inside the same runtime path.
- [x] Update all internal design notes and comments so they describe the corrected schema as the only valid schema.
- [x] Add repository-level assertions or tests that fail if output roles are present while old fee arithmetic is still used.

## Phase 0. Local Terminology Freeze

### 0.1 Goal

📌 Before any semantic or wire-format change, the repository MUST freeze the distinction between:

- 📌 `ReceiverCard` as a cryptographic receiving artifact
- 📌 `Recipient` as a transaction-role or business-role term

📌 This phase exists to prevent a bad rename wave before Phase 1 begins.

📌 The repository MUST NOT perform a global rename of `ReceiverCard` to `RecipientCard`.

📌 The repository MUST NOT roll back tx-role naming from `Recipient` to `Receiver`.

📌 Instead, this phase allows only safe local renames in orchestration and verifier-adjacent code where variable names currently blur these two meanings.

Checklist:

- [x] Freeze the rule `ReceiverCard` = crypto receiving object.
- [x] Freeze the rule `Recipient` = tx role / economic receiver.
- [x] Reject any global rename plan that crosses these layer boundaries.
- [x] Require all later phases to preserve this distinction in naming, comments, and tests.

### 0.2 Terms That Must Stay Unchanged

📌 The following names are part of the crypto/address model and MUST remain unchanged in this scope:

- 📌 `ReceiverCard`
- 📌 `ReceiverKeys`
- 📌 `ReceiverSecret`
- 📌 `receiver_scan_leaf`
- 📌 `export_receiver_card`
- 📌 `decode_card_compact`
- 📌 `encode_card_compact`

📌 These names describe the stealth receiving mechanism, not the business role inside one particular transaction.

📌 Renaming them to `Recipient*` would incorrectly imply that the type exists only for one transaction recipient role, while it is actually a reusable receiving credential and decryption route.

Checklist:

- [x] Preserve all crypto/address type names that use `Receiver*` in this phase.
- [x] Preserve card encode/decode and scan API names in this phase.
- [x] Add a note in touched comments that `Receiver*` names belong to the address/stealth layer.
- [x] Forbid alias types such as `type RecipientCard = ReceiverCard` during this migration scope.

### 0.3 Terms That Must Use Recipient

📌 The following meanings belong to the transaction/business layer and MUST use `Recipient` terminology:

- 📌 output role names
- 📌 claim package recipient bindings
- 📌 transaction context fields describing who receives value
- 📌 local planner variables describing who should receive the transfer amount

📌 This means `Recipient`, `Change`, and `Fee` remain the correct role vocabulary for the corrected `regular_tx` model.

📌 It also means names such as `recipient_owner_hex`, `recipient_card_hex`, and `recipient_wallet_id` are semantically correct and should stay aligned with tx context meaning even if the underlying parsed card type is `ReceiverCard`.

Checklist:

- [x] Keep tx role names exactly `Recipient`, `Change`, `Fee`.
- [x] Keep claim and tx context field names in `recipient_*` form where they mean business recipient binding.
- [x] Ensure verifier and simulator comments distinguish parsed `ReceiverCard` from recipient context semantics.
- [x] Remove any new or existing wording that calls tx role `Recipient` by the older generic label `Receiver`.

### 0.4 Allowed Safe Local Renames

📌 This phase permits only local, non-architectural renames in touched code where names are currently ambiguous.

📌 Safe rename examples:

- 📌 local variable `receiver` for the payment counterparty actor → `recipient`
- 📌 local variable `receiver_actor` in Stage 4 flow code → `recipient_actor` when not part of a stable serialized/public schema
- 📌 helper parameter `receiver` meaning tx recipient role → `recipient`
- 📌 comments like `load receiver card for tx recipient` → `load recipient ReceiverCard`

📌 Unsafe renames that are forbidden in this phase:

- 📌 `ReceiverCard` → `RecipientCard`
- 📌 `ReceiverKeys` → `RecipientKeys`
- 📌 `receiver_scan_leaf` → `recipient_scan_leaf`
- 📌 any public RPC, JSON, or persisted field rename that would break compatibility without a dedicated schema phase

Checklist:

- [x] Limit renames to local variables, helper parameter names, and comments that are semantically ambiguous.
- [x] Do not rename public crypto/address types.
- [x] Do not rename public wire names or persisted JSON fields in this phase.
- [x] Record every allowed local rename under the file-specific plan below before editing code.

### 0.5 File-Specific Rename Plan

📌 [crates/z00z_simulator/src/scenario_1/stage_4.rs](/home/vadim/Projects/z00z/crates/z00z_simulator/src/scenario_1/stage_4.rs)

- 📌 Rename local actor/business variables from `receiver` to `recipient` where they represent Bob or the fee recipient as transaction counterparties.
- 📌 Keep `ReceiverCard` type references unchanged.
- 📌 Where a function takes both a tx recipient label and a `ReceiverCard`, ensure the label uses `recipient` and the card variable keeps `*_card` with `ReceiverCard` type.

📌 [crates/z00z_wallets/src/core/tx/claim_tx.rs](/home/vadim/Projects/z00z/crates/z00z_wallets/src/core/tx/claim_tx.rs)

- 📌 Keep `recipient_*` context fields unchanged.
- 📌 Keep `verify_recipient_card` naming unchanged because it verifies the recipient binding carried by tx context.
- 📌 Inside that logic, keep the parsed type name `ReceiverCard` unchanged and document that this is the recipient's receiver card.

📌 [crates/z00z_simulator/src/config.rs](/home/vadim/Projects/z00z/crates/z00z_simulator/src/config.rs) and related stage config helpers

- 📌 Do not rename persisted config fields in this phase unless a compatibility shim is introduced in a later dedicated schema/config phase.
- 📌 If local helper bindings derive from `receiver_actor`, they may be renamed to `recipient_actor` locally after parsing.

Checklist:

- [x] Apply local rename scope to `stage_4.rs` first.
- [x] Keep `claim_tx.rs` field names stable and only clarify comments/locals.
- [x] Keep config schema stable in Phase 0.
- [x] Reject any edit that combines local terminology cleanup with public schema rename.

### 0.6 Gate To Phase 1

📌 Phase 1 may begin only after the terminology boundary is explicit in the spec and reflected in touched code/comments.

📌 The required boundary is:

- 📌 crypto/address layer: `Receiver*`
- 📌 tx/business-role layer: `Recipient` / `Change` / `Fee`

Checklist:

- [x] No Phase 0 change renames `ReceiverCard` or related crypto/address APIs.
- [x] No Phase 0 change reintroduces `Receiver` as the canonical tx output role.
- [x] The file plan explicitly identifies which names are local-only and which are schema/API names.
- [x] Phase 1 implementers can start canonical tx type work without reopening terminology debate.

## Phase 1. Canonical Input Identity

### 1.1 Target Rule

📌 The canonical state identity of an existing asset is `asset_id` only.

📌 `asset_id_hex` is only the portable JSON encoding of the same 32-byte `asset_id`.

📌 `serial_id` is not a second state key and must not be used as a substitute nullifier. It is a public leaf field used for:

- 📌 AEAD associated-data binding.
- 📌 output format/version binding.
- 📌 input-to-leaf consistency checks.
- 📌 digest stability.

Checklist:

- [x] Audit every transaction, simulator, storage, and report type that mentions input identity.
- [x] Replace any wording or code that treats `serial_id` as part of the canonical state key.
- [x] Preserve `serial_id` only where it is needed for leaf binding, public consistency checks, and deterministic serialization.
- [x] Ensure all future checkpoint delete logic keys spends by `asset_id` only.
- [x] Add a documentation note wherever `asset_id_hex` appears that it is the wire encoding of canonical `asset_id`.

### 1.2 Required Code Meaning

📌 A transaction input reference means: “load the leaf stored under `asset_id` in `prev_root`, then prove that this exact leaf has the declared `serial_id` and satisfies the spend proof constraints.”

📌 The pair `(asset_id, serial_id)` is therefore a reference-and-consistency tuple, but not a composite JMT key.

Checklist:

- [x] Add this exact semantic meaning to verifier docs and simulator docs.
- [x] Make the pre-state resolution step explicit in aggregator logic and any future checkpoint APIs.
- [x] Require all spend proof statements to bind to the resolved pre-state leaf, not merely to the input tuple.
- [x] Forbid any helper from constructing a spend/delete key by concatenating `asset_id` and `serial_id`.

### 1.3 Implementation Steps

📌 Keep `TxInputWire` shape in [crates/z00z_wallets/src/core/tx/tx_verifier.rs](/home/vadim/Projects/z00z/crates/z00z_wallets/src/core/tx/tx_verifier.rs) as:

```rust
pub struct TxInputWire {
    pub asset_id_hex: String,
    pub serial_id: u32,
}
```

📌 Add explicit verifier comments and documentation that:

- 📌 `asset_id_hex` encodes the canonical JMT key.
- 📌 `serial_id` must match the leaf loaded from pre-state.
- 📌 duplicate prevention in final checkpoint logic is based on `asset_id`, not `asset_id + serial_id`.

📌 In wallet and simulator code, stop describing `(asset_id_hex, serial_id)` as “identity” without qualification. Use these terms consistently:

- 📌 `state_key`: `asset_id`
- 📌 `input_ref`: `{ asset_id_hex, serial_id }`
- 📌 `leaf_match`: pre-state leaf under `asset_id` has matching `serial_id`

Checklist:

- [x] Update `TxInputWire` comments to define `asset_id_hex` as the JMT key encoding.
- [x] Update wallet and simulator helper names so they distinguish `state_key`, `input_ref`, and `leaf_match`.
- [x] Rename misleading local variables that call `(asset_id_hex, serial_id)` an identity or composite key.
- [x] Add unit tests that fail if duplicate-prevention or spent-set code uses `(asset_id, serial_id)` instead of `asset_id`.
- [x] Re-check docs after code edits to ensure terminology stays consistent.

### 1.4 Acceptance Criteria

📌 No final design document or verifier comment should imply that `serial_id` is part of the JMT key.

📌 No checkpoint logic in the final implementation should use `asset_id:serial_id` as the spent nullifier set.

Checklist:

- [x] Search the repository for statements that describe `serial_id` as part of the state key.
- [x] Remove or rewrite every such statement.
- [x] Search the repository for spent-set code that derives composite string keys from `asset_id` and `serial_id`.
- [x] Replace every composite spent key with canonical `asset_id` handling.
- [x] Add regression tests that verify spent nullifier data contains `asset_id` only.

## Phase 2. Reference-Only Inputs

### 2.1 Meaning

📌 “Reference-only input” does not mean the input asset is absent from state.

📌 It means the `TxPackage` does not inline the full consumed leaf. Instead, it points to a leaf already present in `prev_root`.

📌 The consumed asset still exists in the JMT as a full `OutputLeaf` value containing public leaf fields such as:

- 📌 `asset_id`
- 📌 `serial_id`
- 📌 `r_pub`
- 📌 `owner_tag`
- 📌 `c_amount`
- 📌 `enc_pack`
- 📌 `range_proof`
- 📌 `tag16`

📌 The receiver wallet may be the only actor able to decrypt some semantic content inside `enc_pack`, but aggregator and validator still operate on the full public leaf representation and on membership witnesses.

Checklist:

- [x] Document that reference-only input means reference to an existing JMT leaf, not omission of the leaf from state.
- [x] Keep encrypted leaf payloads in state exactly as public leaf bytes, without requiring receiver secrets for state storage.
- [x] Ensure aggregator and validator code only rely on public leaf bytes and proof witnesses, not on decrypted payload semantics.
- [x] Reject any proposal that tries to inline full consumed leaves into `TxPackage` without a separate explicit protocol change.

### 2.2 Why This Matches the ECC Spec

📌 The ECC spec states that `TxPackage` contains input references and output leaves, while `CheckpointProof` proves membership and correct state transition.

📌 This separation is correct because `TxProof` and `CheckpointProof` solve different problems:

- 📌 `TxProof` proves local validity of spending and output construction.
- 📌 `CheckpointProof` proves that referenced inputs existed in `prev_root` and that delete/insert operations were applied correctly.

Checklist:

- [x] Keep the proof-responsibility split explicit in code comments and design docs.
- [x] Do not move membership validation into the local transaction proof path.
- [x] Do not move spend ownership logic into checkpoint execution code except as proof verification inputs.
- [x] Add tests and docs that show one invalid TxProof case and one invalid membership case as separate failure modes.

### 2.3 Implementation Steps

📌 Keep transaction inputs compact and reference-only.

📌 Do not add full input leaves into `TxPackage`.

📌 Instead, when real checkpoint execution is implemented, require the aggregator pipeline to load each input leaf from state by `asset_id` before batching the transaction into a checkpoint.

📌 Introduce an internal pre-state resolution type in wallet or storage integration code:

```rust
pub struct ResolvedInput {
    pub asset_id: [u8; 32],
    pub serial_id: u32,
    pub leaf: AssetLeaf,
    pub member_wit: MemberWit,
}
```

📌 The above type is internal only. It must not be added to public JSON transaction format.

Checklist:

- [x] Introduce an internal resolved-input representation in storage or checkpoint integration code.
- [x] Ensure it carries resolved leaf bytes and membership witness data.
- [x] Keep `TxPackage` input payloads compact and reference-only.
- [x] Prevent serde exposure of the resolved-input type in public RPC or package serialization.
- [x] Add tests that build a checkpoint from public input references plus pre-state resolution, not from inlined input leaves.

### 2.4 Acceptance Criteria

📌 Public transaction JSON remains portable and compact.

📌 Aggregator and validator codepaths explicitly resolve inputs from pre-state before delete operations.

📌 No codepath assumes that input amount, owner data, or ciphertext are available directly inside `TxInputWire`.

Checklist:

- [x] Verify serialized `TxPackage` size and structure still include only input references and output leaves.
- [x] Verify no public API has grown extra input-leaf fields.
- [x] Verify all checkpoint-preparation code resolves missing leaf fields from pre-state.
- [x] Add tests that fail if any code path reads amount or ciphertext directly from `TxInputWire`.

## Phase 3. Fee As Full Coin Output

### 3.1 Problem

📌 The current model in [crates/z00z_wallets/src/core/tx/tx_verifier.rs](/home/vadim/Projects/z00z/crates/z00z_wallets/src/core/tx/tx_verifier.rs) and [crates/z00z_simulator/src/scenario_1/stage_4.rs](/home/vadim/Projects/z00z/crates/z00z_simulator/src/scenario_1/stage_4.rs) uses:

```rust
pub struct TxWire {
    pub inputs: Vec<TxInputWire>,
    pub outputs: Vec<TxOutputWire>,
    pub fee: u64,
    // ...
}
```

📌 This makes fee part of arithmetic and digest, but not part of state as a normal `Coin` asset.

📌 If fee must be processed structurally like a normal `Coin`, this is incomplete.

Checklist:

- [x] Mark every current fee-related helper that assumes fee is external to outputs.
- [x] Identify all places where fee is added as an extra scalar term in balance checks.
- [x] Identify all places where aggregator/state logic ignores fee as a state object.
- [x] Use this inventory as the mandatory edit set for the implementation phase.

### 3.2 Target Rule

📌 Every fee must correspond to a concrete output leaf owned by a fee receiver.

📌 The transaction must therefore carry both:

- 📌 a scalar `fee` for explicit economics and digest stability,
- 📌 a concrete fee output leaf in `outputs`.

📌 These two representations must be equal by value.

📌 For `Coin` spends, partial consumption of a selected input set is only valid if the full consumed value is redistributed with no silent remainder.

📌 Therefore, when the initiator selects one or more input assets with total value `input_sum`, the transaction MUST satisfy exactly one of these cases:

- 📌 exact spend: `input_sum = recipient_sum + fee_sum` and no change output is present
- 📌 partial spend: `input_sum = recipient_sum + change_sum + fee_sum` and at least one `Change` output is present

📌 No other outcome is allowed. In particular, the model MUST reject any transaction where `input_sum - recipient_sum - fee_sum > 0` but no `Change` output returns the remainder to the initiator.

📌 This means that if an asset with a concrete `serial_id` is selected and only part of its value is directed to the transfer recipient, then the remaining value MUST be re-materialized as one or more `Change` outputs owned by the initiator of the transaction.

📌 This implies a protocol change in the balance equation. Once fee is represented as a real output leaf, the local transaction balance rule MUST stop adding fee on top of all outputs.

📌 Old rule:

$$
\sum inputs = \sum outputs + fee
$$

📌 New corrected rule for `regular_tx`:

$$
\sum inputs = \sum all\_outputs
$$

📌 With a separate metadata equality:

$$
fee = \sum fee\_outputs
$$

📌 Otherwise fee would be counted twice: once as an output leaf and once as an external scalar term.

Checklist:

- [x] Replace the old balance equation everywhere it appears in code, comments, tests, and docs.
- [x] Preserve scalar `fee` only as metadata and cross-check input, never as an extra committed value outside outputs.
- [x] Ensure there is exactly one source of economic truth for consumed value: the output set.
- [x] Add a regression test that demonstrates the old equation overcounts fee once fee is also an output leaf.
- [x] Add a regression test that rejects positive leftover value when no `Change` output exists.

### 3.3 Target Schema

📌 Extend `TxOutputWire` with a role marker:

```rust
#[derive(Debug, Clone, PartialEq, Eq, serde::Serialize, serde::Deserialize)]
#[serde(rename_all = "snake_case")]
pub enum TxOutRole {
    Recipient,
    Change,
    Fee,
}

#[derive(Debug, Clone, PartialEq, serde::Serialize, serde::Deserialize)]
#[serde(deny_unknown_fields)]
pub struct TxOutputWire {
    pub role: TxOutRole,
    pub asset_wire: AssetPkgWire,
}
```

📌 Keep `fee: u64` in `TxWire`.

📌 Define a strict invariant:

$$
fee = \sum output.amount \text{ for all outputs with role = Fee}
$$

Checklist:

- [x] Add `TxOutRole` to the canonical transaction wire types.
- [x] Make `role` mandatory in serialization for every output.
- [x] Ensure only `Fee` outputs contribute to the fee sum invariant.
- [x] Ensure non-`Fee` outputs do not affect declared fee equality.
- [x] Add serialization tests that reject missing or malformed output roles.

### 3.4 Stage 4 Build Changes

📌 Update [crates/z00z_simulator/src/scenario_1/stage_4.rs](/home/vadim/Projects/z00z/crates/z00z_simulator/src/scenario_1/stage_4.rs) so that output construction returns three categories:

- 📌 receiver outputs
- 📌 sender change outputs
- 📌 fee outputs

📌 Replace the current broken arithmetic with the corrected leaf-state equation:

$$
\sum inputs = \sum recipient\_outputs + \sum change\_outputs + \sum fee\_outputs
$$

📌 Keep the scalar cross-check:

$$
fee = \sum fee\_outputs
$$

📌 Add a fee receiver source to Stage 4 config as a receiver card or equivalent canonical recipient description. Do not model this only as raw owner/view fields if the normal output path already consumes receiver cards.

```yaml
transaction:
  fee_sink:
        wallet_id: sequencer
        receiver_card_hex: "..."
```

📌 Stage 4 must build the fee leaf with the same output path already used for ordinary coin outputs.

📌 The fee recipient source is the aggregator receiver card, referred to in this document as `FeeCard`.

📌 `FeeCard` is not a public exception path and not a transparent sink. It is the aggregator's normal stealth receiver card.

📌 `FeeCard` is not a new Rust type, not a new address primitive, and not a separate cryptographic object that should live beside `ReceiverCard`.

📌 In implementation terms, `FeeCard` means the aggregator's exported `ReceiverCard` used in the fee-sink role.

📌 The long-lived owner of `FeeCard` is the aggregator wallet/key domain. Stage 4 configuration carries only the canonical public receiver-card representation needed to build the fee output, for example `receiver_card_hex`.

📌 Therefore the fee output MUST be built exactly like any other `Coin` output leaf:

- 📌 using the aggregator `FeeCard` as the receiver card input
- 📌 producing a normal stealth output with `r_pub`, `owner_tag`, `enc_pack`, `tag16`, and commitment fields
- 📌 ensuring that only the holder of the matching aggregator secrets can decrypt and spend it

📌 Aggregator-side ownership of the fee is therefore enforced by the same cryptographic mechanism as every other shielded output. The system MUST NOT introduce a transparent or publicly claimable fee object.

Checklist:

- [x] Extend Stage 4 configuration with a canonical fee recipient source using receiver-card semantics.
- [x] Update output planning so recipient, change, and fee outputs are produced in one deterministic pass.
- [x] Ensure the fee leaf uses the same cryptographic output construction path as all other coin outputs.
- [x] Ensure output ordering is deterministic and specified explicitly.
- [x] Update Stage 4 artifacts and reports to include fee outputs instead of treating fee as invisible.
- [x] Ensure `FeeCard` is treated as the aggregator receiver card and not as a transparent special-case sink.
- [x] Ensure no implementation introduces a separate `FeeCard` base type or separate address primitive.
- [x] Add tests proving the fee output is only decryptable by the aggregator wallet that owns `FeeCard`.

### 3.4.1 Fee Build Algorithm

📌 Fee output creation introduces a circular planning risk if fee estimation depends on output count and range-proof footprint while the presence of a fee leaf also changes output count.

📌 The implementation MUST therefore use a fixed planning algorithm instead of ad-hoc retries.

📌 Required algorithm:

1. 📌 Decide the semantic output set first: recipient outputs, change outputs, and exactly one fee output when `fee_policy != zero`.
2. 📌 Compute fee units from final input count and final output count, including the fee output itself.
3. 📌 Materialize the fee leaf with that computed amount.
4. 📌 Recompute recipient and change values from `input_sum - fee`.
5. 📌 Build the final outputs once from the settled values.
6. 📌 Re-run balance and digest checks as a final assertion, not as a search loop.

📌 Step 4 is normative: if `recipient_sum < input_sum - fee`, the difference MUST become `change_sum` for the initiator and MUST be emitted as one or more `Change` outputs. Silent burn of the residual value is forbidden.

📌 This is safe because current fee estimation depends on structural size, not on the numerical amount carried by the fee output.

Checklist:

- [x] Freeze the fee planning algorithm exactly as the six listed steps.
- [x] Forbid fallback search loops or output-count retries once fee-output support is implemented.
- [x] Confirm by code inspection that fee estimation depends only on structural characteristics.
- [x] Add a test proving that changing fee amount alone does not change fee units.
- [x] Add a test proving that adding a fee output changes fee units only through structure, not value.
- [x] Add a test proving partial spend creates mandatory `Change` output when `recipient_sum < input_sum - fee`.
- [x] Add a test proving fee output is built using aggregator `FeeCard` and normal stealth output construction.

### 3.5 Verifier Changes

📌 Update [crates/z00z_wallets/src/core/tx/tx_verifier.rs](/home/vadim/Projects/z00z/crates/z00z_wallets/src/core/tx/tx_verifier.rs) to enforce:

- 📌 at least one `Fee` output when `fee > 0`
- 📌 zero `Fee` outputs when `fee == 0`
- 📌 all `Fee` outputs have `AssetClass::Coin`
- 📌 fee receiver constraints, if configured by chain rules
- 📌 `declared_fee == sum(fee outputs)`

📌 Package-level verifier logic MUST NOT pretend it can derive full input-value conservation from `TxInputWire` alone. When inputs remain reference-only, the corrected balance equation is enforced through the spend/balance proof statement and, where available, through pre-state-resolved validation paths.

📌 Update fee formula helpers so that corrected `regular_tx` arithmetic uses all output commitments and separately checks role-based fee equality.

📌 Update the spend/balance proof APIs in [crates/z00z_wallets/src/core/tx/spending.rs](/home/vadim/Projects/z00z/crates/z00z_wallets/src/core/tx/spending.rs) and [crates/z00z_wallets/src/core/tx/witness_gate.rs](/home/vadim/Projects/z00z/crates/z00z_wallets/src/core/tx/witness_gate.rs) so the proof statement stays internally coherent with the new equation.

Checklist:

- [x] Update verifier structure checks to require role-bearing outputs.
- [x] Update fee validation to compare declared fee with the sum of `Fee` outputs only.
- [x] Update balance validation so all outputs, including fee outputs, are inside the commitment equation.
- [x] Ensure package-level verification does not claim direct input-sum knowledge unless inputs have been explicitly resolved from pre-state.
- [x] Update witness and spend proof statement builders to match the corrected arithmetic exactly.
- [x] Add failing tests for missing fee outputs, extra fee outputs, wrong fee role class, and incorrect declared fee.

### 3.6 Acceptance Criteria

📌 Aggregator inserts fee leaf into state exactly like any other output.

📌 Validator does not special-case fee in JMT updates.

📌 User-visible transaction package clearly shows who receives the fee asset.

Checklist:

- [x] Verify that fee outputs are stored and serialized exactly like ordinary outputs.
- [x] Verify that fee outputs appear in reports, debug dumps, and package JSON.
- [x] Verify that verifier and checkpoint logic never special-case fee during JMT insert operations.
- [x] Verify that displayed fee recipient data matches the configured fee sink.

## Phase 4. Change Outputs And Roles

### 4.1 Target Rule

📌 Change is not metadata.

📌 Change is a normal asset output owned by the sender and must remain in the same `outputs` list as every other created asset.

📌 The only missing piece is explicit role labeling so downstream code can distinguish semantic purpose without guessing from receiver name.

📌 For coin transfers, change is mandatory whenever the selected input value exceeds the sum directed to `Recipient` outputs plus `Fee` outputs.

📌 In the Alice example, if Alice selects an input asset with a specific `serial_id` and sends only part of its value to Bob, then the remaining value MUST go back to Alice as one or more `Change` outputs. That remainder cannot be dropped and cannot be implicitly merged into fee.

Checklist:

- [x] Keep change as a normal output leaf in all transaction, report, and checkpoint structures.
- [x] Remove all logic that infers change purely from recipient naming or actor identity.
- [x] Introduce explicit role metadata wherever output purpose is consumed downstream.
- [x] Add tests proving that sender-owned outputs can be distinguished as `Change` without receiver-name heuristics.
- [x] Add tests proving partial send by Alice to Bob yields explicit Alice-owned `Change` outputs for the residual value.

### 4.2 Output Roles

📌 The system must distinguish these output roles:

- 📌 `Recipient`: ordinary transfer output to the intended transfer recipient.
- 📌 `Change`: sender-owned return output.
- 📌 `Fee`: protocol or sequencer fee output.

📌 Role must be explicit in the transaction package, but role must not change the leaf cryptography. The leaf is still just a normal asset leaf.

📌 Output role is transaction-layer metadata. It MUST affect package digest and verifier policy, but it MUST NOT be treated as part of the canonical JMT leaf value unless the ECC spec is explicitly updated to do so.

Checklist:

- [x] Define the exact allowed role set as `Recipient`, `Change`, and `Fee` only.
- [x] Ensure role participates in transaction serialization and digest framing.
- [x] Ensure role does not alter canonical leaf bytes inserted into JMT.
- [x] Reject any role outside the allowed set at decode time.
- [x] Add tests that prove two otherwise identical transactions with different roles have different digests.

### 4.3 Implementation Steps

📌 Extend output creation helpers in [crates/z00z_simulator/src/scenario_1/stage_4.rs](/home/vadim/Projects/z00z/crates/z00z_simulator/src/scenario_1/stage_4.rs) and related `stage_4_utils` to preserve the role alongside the built output bundle.

📌 Update reporting so pending and confirmed rows can show one of:

- 📌 `pending_receive`
- 📌 `pending_change`
- 📌 `pending_fee`

📌 Update spreadsheet and markdown reports to include `output_role`.

Checklist:

- [x] Extend output bundle builders to carry role metadata end-to-end.
- [x] Extend pending and confirmed lifecycle rows with explicit output role.
- [x] Update markdown and spreadsheet export schemas to include output role columns.
- [x] Update all report diff builders so they compare roles explicitly where relevant.
- [x] Add simulator tests that assert fee, change, and recipient outputs are rendered distinctly in generated artifacts.

### 4.4 Acceptance Criteria

📌 No codepath infers change by “receiver == alice”.

📌 No codepath infers fee by “missing from outputs”.

📌 Output role remains semantic metadata only and does not change leaf encoding or digest framing order beyond normal serialization.

Checklist:

- [x] Verify there are no remaining receiver-name heuristics for change or fee detection.
- [x] Verify output role is visible in package and reports but absent from canonical leaf state value.
- [x] Verify serialization order of outputs stays deterministic after role addition.
- [x] Add regression tests for unchanged leaf cryptography under different roles.

## Phase 5. Aggregator And Validator Invariants

### 5.1 Aggregator Pre-State Invariant

📌 For every `TxInputWire`, before batching, the aggregator must resolve `asset_id_hex` into the actual leaf stored in `prev_root`.

📌 The aggregator must reject the transaction if any of the following fail:

- 📌 `asset_id_hex` is malformed.
- 📌 no leaf exists under `asset_id` in `prev_root`.
- 📌 resolved leaf `serial_id` differs from input `serial_id`.
- 📌 membership witness is invalid for `prev_root`.
- 📌 the asset is already present in the checkpoint-local spent set.

📌 The aggregator must also reject the transaction if the resolved leaf bytes are inconsistent with the local transaction proof statement, for example if the proof refers to a different commitment or ownership tag than the leaf loaded from state.

Checklist:

- [x] Implement a mandatory input-resolution phase before checkpoint batching.
- [x] Validate existence, membership, and `serial_id` consistency for every input.
- [x] Bind the resolved leaf bytes to the local proof statement and reject mismatches.
- [x] Track checkpoint-local spent assets by canonical `asset_id` only.
- [x] Add negative tests for missing input leaf, bad membership witness, bad `serial_id`, and proof/leaf mismatch.

### 5.2 Aggregator Execution Invariant

📌 For each accepted transaction, the aggregator must apply exactly these logical operations:

```mermaid
flowchart TD
    A[Read TxPackage] --> B[Verify TxProof]
    B --> C[Resolve each input by asset_id in prev_root]
    C --> D[Check leaf serial_id matches input serial_id]
    D --> E[Check checkpoint-local no double spend]
    E --> F[Delete consumed asset_id keys from JMT]
    F --> G[Insert all output leaves]
    G --> H[Build spent_delta and created_delta]
    H --> I[Produce CheckpointProof]
```

📌 `spent_delta` must contain consumed `asset_id` values only.

📌 `created_delta` must contain canonical `(asset_id, leaf_hash)` pairs.

Checklist:

- [x] Implement the aggregator execution order exactly as shown in the diagram.
- [x] Ensure deletes happen over consumed `asset_id` keys only.
- [x] Ensure inserts include recipient, change, and fee outputs without exceptions.
- [x] Build `spent_delta` and `created_delta` from the executed state transition, not from ad-hoc guesses.
- [x] Add tests that verify identical batches always produce identical delta ordering and checkpoint inputs.

### 5.3 Validator Invariant

📌 The validator must not trust aggregator summaries alone.

📌 The validator must verify, via `CheckpointProof`, that:

- 📌 every deleted `asset_id` had a valid membership path in `prev_root`
- 📌 every inserted leaf hash matches the published output leaf bytes
- 📌 the root transition is exactly the result of delete-then-insert over the batch
- 📌 aggregated local transaction proofs are valid

📌 In a proof-driven implementation, validator correctness comes from proof verification over public inputs, not from re-hashing ad-hoc delta lists. A local re-apply mode may exist for testing and debugging, but it is not the source of consensus truth.

Checklist:

- [x] Define the exact public inputs consumed by validator-side checkpoint verification.
- [x] Ensure validator checks membership, inserts, deletes, and root transition through proof verification or equivalent state-application verification.
- [x] Keep local re-apply logic behind test or debug boundaries only.
- [x] Add tests that distinguish consensus validation from local debug re-application.
- [x] Document that delta lists are audit artifacts, not consensus roots by themselves.

### 5.4 Required Internal Types

📌 Introduce or reserve internal types similar to:

```rust
pub struct SpentEnt {
    pub asset_id: [u8; 32],
}

pub struct MadeEnt {
    pub asset_id: [u8; 32],
    pub leaf_hash: [u8; 32],
}
```

📌 These are checkpoint internals. They are not a replacement for transaction outputs.

Checklist:

- [x] Introduce typed spent and created entry structs in checkpoint code.
- [x] Remove any flat alternating string representation of created deltas from target checkpoint code.
- [x] Keep transaction output DTOs separate from checkpoint-internal delta records.
- [x] Ensure all typed checkpoint internals serialize deterministically.

### 5.5 Acceptance Criteria

📌 The final checkpoint pipeline never uses `asset_id:serial_id` as the spent set key.

📌 The final checkpoint pipeline always compares input `serial_id` against the resolved pre-state leaf.

📌 The final checkpoint pipeline inserts fee leaves as ordinary outputs.

Checklist:

- [x] Verify spent sets are keyed by `asset_id` only.
- [x] Verify resolved leaf `serial_id` is checked before delete.
- [x] Verify fee outputs enter created deltas and JMT inserts identically to ordinary outputs.
- [x] Verify no checkpoint code path uses composite string keys as final state identity.

## Phase 6. Stage 6 Alignment And Migration

### 6.1 Current Status

📌 [crates/z00z_simulator/src/scenario_1/stage_6.rs](/home/vadim/Projects/z00z/crates/z00z_simulator/src/scenario_1/stage_6.rs) is still a placeholder checkpoint simulator.

📌 The recent local fix changed temporary spent tracking to `asset_id_hex:serial_id` only to avoid false conflicts inside that placeholder model.

📌 That temporary behavior must not be treated as the final ECC design.

Checklist:

- [x] Mark current Stage 6 behavior explicitly as placeholder in code comments and documentation.
- [x] Prevent anyone from reusing placeholder spent-key logic as final checkpoint logic.
- [x] Keep temporary fixes only as local simulator guards until canonical checkpoint code replaces them.

### 6.2 Final Target For Stage 6

📌 Replace placeholder fragment generation with real checkpoint input/output semantics derived from Stage 4 transaction packages.

📌 Refactor `FragIn` to model canonical delete intent:

```rust
struct FragIn {
    asset_id_hex: String,
    serial_id: u32,
    prev_root_hex: String,
    leaf_hash_hex: String,
    member_ok: bool,
}
```

📌 The checkpoint spent set must use `asset_id_hex` only.

📌 `serial_id` remains in `FragIn` to ensure the input reference matches the resolved leaf.

📌 `leaf_hash_hex` or equivalent resolved-leaf commitment must be available to make the placeholder checkpoint logic reflect actual JMT delete behavior more closely.

Checklist:

- [x] Define the target Stage 6 input and output records in terms of real checkpoint semantics.
- [x] Carry `asset_id_hex` as delete key, `serial_id` as consistency field, and leaf hash as proof/state linkage material.
- [x] Remove any implication that `serial_id` participates in canonical spend nullification.
- [x] Ensure Stage 6 target flow consumes Stage 4 transaction artifacts rather than synthetic assumptions wherever possible.

### 6.3 Required Refactor Steps

📌 Step 6.3.1: Rename placeholder helpers to make their status explicit.

- 📌 `build_frag` -> `build_demo_frag`
- 📌 `build_cp` -> `build_demo_cp` or replace fully once real checkpoint code exists

📌 Step 6.3.2: Split placeholder code from target checkpoint model.

- 📌 Keep the current demo path if needed for scenario output generation.
- 📌 Add a separate target path that uses resolved pre-state leaves and canonical deltas.

📌 Step 6.3.3: Update delta types.

- 📌 `spent_delta: Vec<String>` becomes list of `asset_id_hex`
- 📌 `created_delta` becomes structured pairs, not flat alternating strings

📌 Step 6.3.4: Stop using delta hashing as a substitute for state transition.

- 📌 Stop hashing ambiguous flat string arrays.
- 📌 Compute `new_root` from actual JMT delete/insert application or from the proof system public outputs.
- 📌 If a checkpoint digest still includes deltas for auditability, hash canonical typed records in stable order, but do not confuse that digest with the state root.

Checklist:

- [x] Rename placeholder helpers so their non-final status is explicit.
- [x] Split demo checkpoint flow from target checkpoint flow into separate helpers or modules.
- [x] Replace flat delta collections with typed spent and created entries.
- [x] Route `new_root` computation through actual JMT application or proof outputs only.
- [x] Keep any checkpoint digest based on deltas clearly separate from state-root semantics.

### 6.4 Suggested Data Types

```rust
#[derive(Debug, Clone, Serialize, Deserialize)]
struct MadeEnt {
    asset_id_hex: String,
    leaf_hash_hex: String,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
struct Checkpoint {
    prev_root_hex: String,
    new_root_hex: String,
    spent_delta: Vec<String>,
    created_delta: Vec<MadeEnt>,
    fragment_ids: Vec<String>,
}
```

Checklist:

- [x] Implement typed checkpoint delta structs exactly or with stricter equivalents.
- [x] Ensure `spent_delta` contains canonical `asset_id_hex` strings only.
- [x] Ensure `created_delta` contains typed `(asset_id_hex, leaf_hash_hex)` pairs only.
- [x] Ensure checkpoint serialization stays deterministic and human-auditable.
- [x] Add serde tests for stable round-trip encoding of the target checkpoint types.

### 6.5 Test Matrix

📌 Add or update the following tests:

- 📌 `same_asset_id_same_serial_is_double_spend`
- 📌 `same_asset_id_different_serial_rejected_if_leaf_serial_mismatch`
- 📌 `spent_delta_contains_asset_id_only`
- 📌 `created_delta_contains_typed_pairs`
- 📌 `fee_output_inserted_into_created_delta`
- 📌 `declared_fee_equals_sum_fee_outputs`
- 📌 `role_annotated_outputs_use_corrected_balance_rule`
- 📌 `sum_inputs_equals_sum_all_outputs_when_fee_is_output`
- 📌 `change_output_kept_as_normal_leaf`
- 📌 `checkpoint_rejects_missing_input_leaf`
- 📌 `checkpoint_rejects_bad_member_wit`

Checklist:

- [x] Convert every listed test name into a concrete test case before implementation is considered complete.
- [x] Add both unit-level and scenario-level coverage for each listed case.
- [x] Ensure tests cover builder, verifier, simulator artifacts, and checkpoint logic where applicable.
- [x] Ensure at least one end-to-end scenario test proves fee, change, and recipient outputs all survive into state correctly.
- [x] Fail the implementation if any listed test remains missing.

### 6.6 Acceptance Criteria

📌 Stage 6 documentation and code no longer imply that composite `(asset_id, serial_id)` is the state delete key.

📌 Stage 6 can still keep a demo mode, but the target mode must follow ECC-spec semantics exactly.

Checklist:

- [x] Verify Stage 6 docs no longer describe composite spend keys as canonical.
- [x] Verify target Stage 6 uses `asset_id` delete semantics and typed created entries.
- [x] Verify demo mode and target mode are clearly separated and cannot be confused.
- [x] Verify all Stage 6 acceptance conditions are covered by automated tests before sign-off.

## File Plan

📌 The following files are expected to change during implementation:

- 📌 [crates/z00z_wallets/src/core/tx/tx_verifier.rs](/home/vadim/Projects/z00z/crates/z00z_wallets/src/core/tx/tx_verifier.rs)
- 📌 [crates/z00z_wallets/src/core/tx/lifecycle.rs](/home/vadim/Projects/z00z/crates/z00z_wallets/src/core/tx/lifecycle.rs)
- 📌 [crates/z00z_wallets/src/core/tx/witness_gate.rs](/home/vadim/Projects/z00z/crates/z00z_wallets/src/core/tx/witness_gate.rs)
- 📌 [crates/z00z_simulator/src/scenario_1/stage_4.rs](/home/vadim/Projects/z00z/crates/z00z_simulator/src/scenario_1/stage_4.rs)
- 📌 [crates/z00z_simulator/src/scenario_1/stage_4_utils/reports_diff.rs](/home/vadim/Projects/z00z/crates/z00z_simulator/src/scenario_1/stage_4_utils/reports_diff.rs)
- 📌 [crates/z00z_simulator/src/scenario_1/stage_6.rs](/home/vadim/Projects/z00z/crates/z00z_simulator/src/scenario_1/stage_6.rs)
- 📌 storage-facing checkpoint code once JMT integration is connected

## Implementation Order

📌 The checklists above are normative, but they are not allowed to be implemented in arbitrary order.

📌 The implementation MUST follow the phase order below. A later phase MUST NOT begin until every gate in the previous phase is satisfied.

📌 If a phase reveals a contradiction with an earlier phase, the developer MUST stop, update this spec first, and only then continue implementation.

```mermaid
flowchart TD
    P0[Phase 0: Freeze Terms] --> P1[Phase 1: Canonical Tx Types]
    P1 --> P2[Phase 2: Verifier Semantics]
    P2 --> P3[Phase 3: Stage 4 Builder]
    P3 --> P4[Phase 4: Proof Statement]
    P4 --> P5[Phase 5: Lifecycle And Reports]
    P5 --> P6[Phase 6: Checkpoint Internals]
    P6 --> P7[Phase 7: Stage 6 Target Flow]
    P7 --> P8[Phase 8: End-to-End Gates]
```

### Phase 0. Freeze Terms And Remove Ambiguity

📌 Goal: eliminate semantic ambiguity before any code behavior changes.

Files:

- 📌 [crates/z00z_simulator/src/scenario_1/fix-spec.md](/home/vadim/Projects/z00z/crates/z00z_simulator/src/scenario_1/fix-spec.md)
- 📌 [crates/z00z_wallets/src/core/tx/tx_verifier.rs](/home/vadim/Projects/z00z/crates/z00z_wallets/src/core/tx/tx_verifier.rs)
- 📌 [crates/z00z_simulator/src/scenario_1/stage_6.rs](/home/vadim/Projects/z00z/crates/z00z_simulator/src/scenario_1/stage_6.rs)

Dependencies:

- 📌 None. This is the entry phase.

Mandatory tasks:

- [x] Freeze terminology in docs and code comments: `state_key`, `input_ref`, `leaf_match`, `spent_delta`, `created_delta`.
- [x] Remove any wording that treats `(asset_id, serial_id)` as canonical state identity.
- [x] Mark current Stage 6 spent-key behavior as placeholder only.
- [x] Mark fee-as-scalar-only behavior as incorrect pending correction.

Gate to Phase 1:

- [x] No repository text describing `serial_id` as part of the JMT key remains in touched files.
- [x] No touched file claims fee is outside the output set in the corrected model.

### Phase 1. Canonical Tx Types

📌 Goal: define the corrected transaction wire types before any algorithmic changes.

Files:

- 📌 [crates/z00z_wallets/src/core/tx/tx_verifier.rs](/home/vadim/Projects/z00z/crates/z00z_wallets/src/core/tx/tx_verifier.rs)
- 📌 any `mod.rs` re-export files that surface these types

Dependencies:

- 📌 Phase 0 complete.

Mandatory tasks:

- [x] Add `TxOutRole` to canonical tx wire definitions.
- [x] Use exact role names: `Recipient`, `Change`, `Fee`.
- [x] Make `role` mandatory for every serialized `TxOutputWire`.
- [x] Preserve `TxInputWire { asset_id_hex, serial_id }` unchanged except for clarified comments.
- [x] Keep `fee: u64` as metadata field in `TxWire`.

Gate to Phase 2:

- [x] Canonical tx types compile.
- [x] Serialization tests exist for `TxOutRole` and `TxOutputWire`.
- [x] Missing-role and malformed-role decode failures are covered by tests.

### Phase 2. Verifier Semantics

📌 Goal: make verifier logic match the corrected schema before builder changes start producing new payloads.

Files:

- 📌 [crates/z00z_wallets/src/core/tx/tx_verifier.rs](/home/vadim/Projects/z00z/crates/z00z_wallets/src/core/tx/tx_verifier.rs)

Dependencies:

- 📌 Phase 1 complete.

Mandatory tasks:

- [x] Replace old fee arithmetic with corrected arithmetic: `sum(inputs) == sum(all outputs)` at the semantic level of the proof statement and resolved-value model.
- [x] Enforce `declared_fee == sum(Fee outputs)`.
- [x] Enforce `Fee` outputs use `AssetClass::Coin` only.
- [x] Enforce `fee == 0` implies no `Fee` outputs.
- [x] Enforce `fee > 0` implies at least one `Fee` output.
- [x] Keep input duplicate checks as transaction-level hygiene, but do not let them redefine checkpoint nullifier semantics.
- [x] Keep package-level verifier behavior honest: structure and fee-role checks are local, while full balance conservation requires proof validation or resolved-input validation.

Gate to Phase 3:

- [x] All verifier unit tests pass.
- [x] New negative tests for malformed fee-role semantics pass.
- [x] No verifier path still computes success under the old `sum(outputs) + fee` rule.

### Phase 3. Stage 4 Builder

📌 Goal: make transaction construction produce the corrected output set and corrected fee behavior.

Files:

- 📌 [crates/z00z_simulator/src/scenario_1/stage_4.rs](/home/vadim/Projects/z00z/crates/z00z_simulator/src/scenario_1/stage_4.rs)
- 📌 Stage 4 helper modules that construct output bundles

Dependencies:

- 📌 Phase 2 complete.

Mandatory tasks:

- [x] Introduce fee recipient configuration through canonical receiver-card semantics.
- [x] Build output bundles with explicit roles: `Recipient`, `Change`, `Fee`.
- [x] Implement the fixed fee planning algorithm from this spec without ad-hoc retry search.
- [x] Ensure fee output is materialized as a normal coin leaf.
- [x] Ensure output ordering is deterministic and documented.
- [x] Ensure emitted transaction JSON includes role-bearing outputs.

Gate to Phase 4:

- [x] Stage 4 compiles and produces role-bearing outputs.
- [x] Stage 4 tests for fee, change, and recipient outputs pass.
- [x] Generated transaction packages satisfy updated verifier rules.

### Phase 4. Proof Statement

📌 Goal: align witness generation and spend/balance proof statements with the corrected output semantics.

Files:

- 📌 [crates/z00z_wallets/src/core/tx/spending.rs](/home/vadim/Projects/z00z/crates/z00z_wallets/src/core/tx/spending.rs)
- 📌 [crates/z00z_wallets/src/core/tx/witness_gate.rs](/home/vadim/Projects/z00z/crates/z00z_wallets/src/core/tx/witness_gate.rs)

Dependencies:

- 📌 Phase 3 complete.

Mandatory tasks:

- [x] Update commitment-balance statements so all created outputs, including fee outputs, are inside the output commitment set.
- [x] Keep `asset_id` spend binding unchanged and canonical.
- [x] Ensure witness construction still derives input secrets from resolved input leaves only.
- [x] Ensure no proof code special-cases fee as an out-of-band commitment once fee output exists.
- [x] Re-run spend-rule logic against the corrected Stage 4 transaction shape.

Gate to Phase 5:

- [x] Proof-related unit tests pass.
- [x] No proof helper expects fee to be outside the output commitment set.
- [x] Stage 4 end-to-end flow still passes witness and self-decrypt gates.

### Phase 5. Lifecycle And Reports

📌 Goal: make all downstream artifacts represent output purpose explicitly and correctly.

Files:

- 📌 [crates/z00z_wallets/src/core/tx/lifecycle.rs](/home/vadim/Projects/z00z/crates/z00z_wallets/src/core/tx/lifecycle.rs)
- 📌 [crates/z00z_simulator/src/scenario_1/stage_4_utils/reports_diff.rs](/home/vadim/Projects/z00z/crates/z00z_simulator/src/scenario_1/stage_4_utils/reports_diff.rs)
- 📌 other Stage 4 report/export helpers

Dependencies:

- 📌 Phase 4 complete.

Mandatory tasks:

- [x] Extend lifecycle rows with explicit output role.
- [x] Distinguish `Recipient`, `Change`, and `Fee` in markdown, spreadsheet, and JSON artifacts.
- [x] Remove receiver-name heuristics for determining change.
- [x] Remove “missing from outputs” heuristics for determining fee.
- [x] Keep canonical leaf/state representation unchanged while enriching reports with role metadata.

Gate to Phase 6:

- [x] All report generators compile.
- [x] Snapshot and report tests pass with explicit output roles.
- [x] Generated artifacts clearly show fee recipient and change outputs.

### Phase 6. Checkpoint Internals

📌 Goal: define target checkpoint data structures before rewiring Stage 6 logic.

Files:

- 📌 [crates/z00z_simulator/src/scenario_1/stage_6.rs](/home/vadim/Projects/z00z/crates/z00z_simulator/src/scenario_1/stage_6.rs)
- 📌 storage-facing checkpoint code once connected

Dependencies:

- 📌 Phase 5 complete.

Mandatory tasks:

- [x] Replace flat created-delta strings with typed `(asset_id, leaf_hash)` entries.
- [x] Keep spent-delta keyed by canonical `asset_id` only.
- [x] Introduce target checkpoint internal structs for spent and created entries.
- [x] Separate checkpoint digest material from actual state-root semantics.
- [x] Document that typed deltas are audit artifacts derived from executed state transition.

Gate to Phase 7:

- [x] Checkpoint internals serialize deterministically.
- [x] Tests exist for typed delta round-trip behavior.
- [x] No target checkpoint structure uses composite spend keys.

### Phase 7. Stage 6 Target Flow

📌 Goal: replace placeholder Stage 6 behavior with target checkpoint semantics while preserving optional demo mode only if clearly isolated.

Files:

- 📌 [crates/z00z_simulator/src/scenario_1/stage_6.rs](/home/vadim/Projects/z00z/crates/z00z_simulator/src/scenario_1/stage_6.rs)

Dependencies:

- 📌 Phase 6 complete.

Mandatory tasks:

- [x] Split demo helpers from target helpers if both modes remain.
- [x] Resolve inputs by canonical `asset_id` semantics.
- [x] Check `serial_id` against resolved leaf as consistency field only.
- [x] Build spent and created deltas from actual target transition semantics.
- [x] Compute `new_root` from state application or proof outputs, not from delta hashing shortcuts.
- [x] Ensure fee outputs and change outputs enter created deltas and inserts exactly like ordinary outputs.

Gate to Phase 8:

- [x] Stage 6 target tests pass.
- [x] Demo mode, if retained, is clearly separated and impossible to confuse with target mode.
- [x] No Stage 6 path claims composite spend keys are canonical.

### Phase 8. End-To-End Gates

📌 Goal: prove that the corrected model works consistently across builder, verifier, simulator, and checkpoint flow.

Files:

- 📌 all touched files from Phases 1 through 7

Dependencies:

- 📌 Phases 0 through 7 complete.

Mandatory tasks:

- [x] Implement every test listed in the `6.5 Test Matrix` section.
- [x] Re-run Stage 4 focused tests.
- [x] Re-run wallet transaction receive/import tests affected by output-role and fee changes.
- [x] Re-run Stage 6 target tests.
- [x] Re-run any end-to-end Scenario 1 pipeline test that emits transaction packages, reports, and checkpoint artifacts.
- [x] Re-read touched docs and code comments for semantic drift before sign-off.

Final release gate:

- [x] No touched code path still assumes fee is external to outputs.
- [x] No touched code path still treats `(asset_id, serial_id)` as canonical state identity.
- [x] Transaction packages, reports, and checkpoint artifacts all reflect the same corrected model.
- [x] All targeted tests pass without TODO exemptions.

## Non-Goals

📌 This fix spec does not require full on-chain consensus integration.

📌 This fix spec does not require changing the cryptographic meaning of `asset_id`, `serial_id`, `enc_pack`, `owner_tag`, or `range_proof`.

📌 This fix spec does not require embedding receiver secrets or decrypted payloads into state.

## Final Design Summary

📌 Final model in one sentence: transaction inputs are references to existing JMT leaves keyed by `asset_id`, `serial_id` is a public consistency field, every created value including fee and change must appear as a normal output leaf, and checkpoint logic deletes consumed `asset_id` keys then inserts all created leaves.

```mermaid
flowchart LR
    IN[Tx inputs: asset_id + serial_id] --> RES[Resolve input leaves from prev_root]
    RES --> DEL[Delete consumed asset_id keys]
    OUT[Tx outputs: recipient + change + fee leaves] --> INS[Insert output leaves]
    DEL --> ROOT[Compute new root]
    INS --> ROOT
    ROOT --> CP[CheckpointProof]
```
