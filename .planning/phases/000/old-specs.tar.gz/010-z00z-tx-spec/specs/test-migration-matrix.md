# Scenario 1 Test Migration Matrix

<!-- markdownlint-disable MD060 -->

| test_file | crate_now | class | target_after_split | status | note |
|---|---|---|---|---|---|
| test_tx_balance.rs | z00z_wallets | core-domain | z00z_wallets/tests | completed | migrated from simulator to wallet core tests |
| test_tx_fee.rs | z00z_wallets | core-domain | z00z_wallets/tests | completed | migrated from simulator to wallet core tests |
| test_tx_pass.rs | z00z_wallets | core-domain | z00z_wallets/tests | completed | migrated from simulator to wallet core tests |
| test_tx_poison.rs | z00z_wallets | core-domain | z00z_wallets/tests | completed | migrated from simulator to wallet core tests |
| test_tx_pedersen.rs | z00z_wallets | core-domain | z00z_wallets/tests | completed | migrated from simulator to wallet core tests |
| test_tx_serial.rs | z00z_wallets | core-domain | z00z_wallets/tests | completed | migrated from simulator to wallet core tests |
| test_tx_parity.rs | z00z_wallets | core-domain | z00z_wallets/tests | completed | migrated from simulator to wallet core tests |
| test_tx_drift.rs | z00z_wallets | core-domain | z00z_wallets/tests | completed | migrated from simulator to wallet core tests |
| test_tx_prefilter.rs | z00z_wallets | core-domain | z00z_wallets/tests | completed | migrated from simulator to wallet core tests |
| test_tx_roundtrip.rs | z00z_wallets | core-domain | z00z_wallets/tests | completed | migrated from simulator to wallet core tests |
| test_tx_spent_gate.rs | z00z_wallets | core-domain | z00z_wallets/tests | completed | migrated from simulator to wallet core tests |
| test_tx_tamper.rs | z00z_wallets | core-domain | z00z_wallets/tests | completed | migrated from simulator to wallet core tests |
| test_tx_interop.rs | z00z_wallets | core-domain | z00z_wallets/tests | completed | migrated from simulator to wallet core tests |
| test_tx_wrong_root.rs | z00z_wallets | core-domain | z00z_wallets/tests | completed | migrated from simulator to wallet core tests |
| test_tx_assetpack.rs | z00z_wallets | core-domain | z00z_wallets/tests | completed | migrated from simulator to wallet core tests |
| test_tx_stealth_flow.rs | z00z_wallets | core-domain | z00z_wallets/tests | completed | migrated from simulator to wallet core tests |
| test_claim_crypto.rs | z00z_simulator | scenario-orchestration | z00z_simulator/tests | completed | full Stage-3 run with output artifact and crypto continuity checks |
| test_claim_integration.rs | z00z_simulator | scenario-orchestration | z00z_simulator/tests | completed | assertions depend on stage runner/config/output artifacts |
| test_claim_resume.rs | split | mixed | split: wallets+simulator | completed | core assertions moved to `z00z_wallets/tests/test_claim_resume_core.rs`; simulator keeps orchestration test |
| test_claim_persist.rs | z00z_simulator | scenario-orchestration | z00z_simulator/tests | completed | persistence and debug-dump checks are stage artifact and runtime wiring dependent |
| test_claim_snapshot.rs | split | mixed | split: wallets+simulator | completed | core snapshot invariants moved to `z00z_wallets/tests/test_claim_snapshot_core.rs`; simulator keeps run-level artifact check |
| test_claim_post.rs | z00z_simulator | scenario-orchestration | z00z_simulator/tests | completed | orchestration-only artifact checks remain in simulator |

## Assertion Classification (2026-03-06)

| test_file | assertion_scope | classification | target_after_split | note |
|---|---|---|---|---|
| test_tx_balance.rs | all assertions | core-domain | z00z_wallets/tests | tx balance invariants only |
| test_tx_fee.rs | all assertions | core-domain | z00z_wallets/tests | fee/opening invariants only |
| test_tx_pass.rs | all assertions | core-domain | z00z_wallets/tests | pure tx validation paths |
| test_tx_poison.rs | all assertions | core-domain | z00z_wallets/tests | malformed core payload rejection |
| test_tx_pedersen.rs | all assertions | core-domain | z00z_wallets/tests | pedersen commitment checks |
| test_tx_serial.rs | all assertions | core-domain | z00z_wallets/tests | serial rule checks |
| test_tx_parity.rs | all assertions | core-domain | z00z_wallets/tests | parity vectors against core logic |
| test_tx_drift.rs | all assertions | core-domain | z00z_wallets/tests | drift/invariant checks |
| test_tx_prefilter.rs | all assertions | core-domain | z00z_wallets/tests | prefilter gate invariants |
| test_tx_roundtrip.rs | all assertions | core-domain | z00z_wallets/tests | wire roundtrip invariants |
| test_tx_spent_gate.rs | all assertions | core-domain | z00z_wallets/tests | spent witness gate logic |
| test_tx_tamper.rs | all assertions | core-domain | z00z_wallets/tests | anti-tamper invariants |
| test_tx_interop.rs | all assertions | core-domain | z00z_wallets/tests | tx wire compatibility parsing |
| test_tx_wrong_root.rs | all assertions | core-domain | z00z_wallets/tests | root-binding invariant |
| test_tx_assetpack.rs | all assertions | core-domain | z00z_wallets/tests | asset pack decrypt/parse checks |
| test_tx_stealth_flow.rs | all assertions | core-domain | z00z_wallets/tests | stealth output invariants |
| test_claim_crypto.rs | `stage3_crypto_ok` data assertions and proof checks | scenario-orchestration | z00z_simulator/tests | requires scenario runner and Stage-3 output artifacts |
| test_claim_integration.rs | `stage3_claimed_nonces_unique`, `stage3_non_void_amounts_positive`, `neg_tampered_*` | scenario-orchestration | z00z_simulator/tests | coupled to stage runner, debug export payloads, and scenario output files |
| test_claim_integration.rs | `stage3_bins_empty_after_consume`, `stage3_double_claim_rejected`, `stage3_claim_event_valid`, `stage3_snapshot_counts_consistent`, `stage3_snapshot_vs_json_balance`, `stage3_import_stats_no_rejections`, `stage3_resume_artifacts_written`, `stage3_class_split_correct` | scenario-orchestration | z00z_simulator/tests | run-level file artifacts and stage orchestration checks |
| test_claim_resume.rs | `test_resume_idempotent`, `test_resume_no_bypass_verify` | core-domain | z00z_wallets/tests | merge/verify semantics independent of scenario IO |
| test_claim_resume.rs | `test_resume_no_double_count` | scenario-orchestration | z00z_simulator/tests | uses simulator stage rehydrate + registry side effect wiring |
| test_claim_persist.rs | row/set parity checks and snapshot stat equalities | scenario-orchestration | z00z_simulator/tests | computed from scenario run artifacts and stage snapshot files |
| test_claim_persist.rs | artifact existence/path checks and env failure orchestration assertions | scenario-orchestration | z00z_simulator/tests | validates scenario outputs and failpoint wiring |
| test_claim_snapshot.rs | `test_snapshot_reconciliation_ok`, `test_snapshot_reconciliation_count_mismatch`, `test_snapshot_no_write` | core-domain | z00z_wallets/tests | pure snapshot reconciliation/write contract |
| test_claim_snapshot.rs | `test_snapshot_reconciliation_run` | scenario-orchestration | z00z_simulator/tests | full run + snapshot artifact loading |
| test_claim_post.rs | wallet payload file discovery and post-claim artifact checks | scenario-orchestration | z00z_simulator/tests | artifact-level orchestration validation only |
