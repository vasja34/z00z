# Claim-Spec-2: Full Asset Leaf in ClaimTxPackage

**Date:** 2026-03-07  
**Status:** Implemented and verified  
**Supersedes:** claim-tx-spec-1.md (ClaimOutputWire minimal intent)

---

## 🎯 Problem

📌 `claim_pkg_prepared.json` (v1 format) stored only a *claim-intent envelope*:

```
ClaimOutputWire { asset_id_hex, amount, asset_class, owner_binding_hex, nonce_hex }
```

This is insufficient for:

- ❌ Publishing asset to JMT (needs `r_pub`, `owner_tag`, `enc_pack`, `c_amount`, `range_proof`, `tag16`, `serial_id`)
- ❌ Restoring asset in wallet (needs full `AssetWire` for `wallet.asset.import_asset`)
- ❌ Stealth scanning by recipient (needs `r_pub + owner_tag + enc_pack`)

📌 `tx_alice_to_bob_pkg.json` (Stage 4 output) already solves this by embedding a full `AssetWire` inside each `TxOutputWire.leaf`.

---

## ✅ Solution: Embed Full AssetWire as `asset_wire` in ClaimOutputWire and emit canonical claim packages

### ClaimOutputWire

```rust
pub struct ClaimOutputWire {
    // --- original claim-intent fields (unchanged) ---
    pub asset_id_hex: String,
    pub amount: u64,
    pub asset_class: String, // actual class from leaf.definition.class
    pub owner_binding_hex: String,
    pub nonce_hex: String,

    // --- NEW: full stealth asset wire (mirrors TxOutputWire.leaf) ---
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub asset_wire: Option<AssetWire>,
}
```

  📌 `ClaimTxPackage.version = 1` is canonical, and every output MUST carry valid `asset_wire: AssetWire`.

### AssetWire fields required for JMT publish (AssetLeaf)

| AssetWire field | JMT AssetLeaf field | Required |
|---|---|---|
| `definition.id` | `asset_id` | ✅ |
| `serial_id` | `serial_id` | ✅ |
| `r_pub` | `r_pub` | ✅ |
| `owner_tag` | `owner_tag` | ✅ |
| `commitment` | `c_amount` | ✅ |
| `enc_pack` | `enc_pack` | ✅ |
| `range_proof` | `range_proof` | ✅ |
| `tag16` | `tag16` | ✅ |

### AssetWire fields required for wallet import (`wallet.asset.import_asset`)

| Field | Notes |
|---|---|
| `definition` | Full `AssetDefinition` with `id`, `class`, `symbol` |
| `serial_id` | Asset sequence number |
| `amount` | Base units |
| `commitment` | Pedersen commitment bytes |
| `range_proof` | Bulletproofs+ range proof |
| `nonce` | Asset nonce |
| `r_pub` | Sender ephemeral pubkey (32 bytes) |
| `owner_tag` | Stealth owner tag (32 bytes) |
| `enc_pack` | Encrypted payload `{version, ciphertext, tag}` |
| `tag16` | Quick scan tag |
| `secret` | MUST be `null` on import |

### Verifier guarantees implemented in code

📌 `ClaimTxVerifierImpl` treats `asset_wire` as the canonical portable output carrier and rejects the package unless every output carries a full valid `asset_wire`.

- ✅ `created_outputs[i].asset_wire` is mandatory
- ✅ `asset_wire.secret` MUST be `null`
- ✅ `asset_wire.definition.id == asset_id_hex`
- ✅ `asset_wire.amount == amount`
- ✅ `asset_wire.definition.class == asset_class`
- ✅ `owner_binding_hex == tx.recipient_owner_hex`
- ✅ `nonce_hex == derive_output_nonce(claim_id, output_index)`
- ✅ `asset_wire_to_leaf(asset_wire)` succeeds for JMT-ready conversion
- ✅ `asset_wire.to_asset()` and `verify_complete()` succeed for wallet-import readiness

---

## 📐 Data Flow

```
Stage 3: run_core()
  ├── For each (actor, asset):
  │     ├── to_claim_wire(asset, actor.keys, actor.card, claim_id)
  │     │     └── builds full AssetWire with r_pub, owner_tag, enc_pack,
  │     │         commitment, range_proof, tag16, serial_id
  │     └── build_claim_package(..., asset_wire = Some(wire))
  │           └── ClaimOutputWire { ..original 5 fields.., asset_wire: Some(AssetWire) }
  │
  └── Writes Vec<ClaimTxPackage(version = 1)> → tx_claim_pkg.json

Stage 4: run_core()
  ├── load_claim_pkgs("tx_claim_pkg.json")
  └── (unchanged: continues building full TxPackage from wallet RPC)

JMT publish (future):
  ├── Read tx_claim_pkg.json
  ├── For each pkg.tx.created_outputs[i].asset_wire:
  │     └── AssetLeaf::from_wire(asset_wire) → insert into JMT

Wallet restore (future):
  ├── Read tx_claim_pkg.json
  ├── For each pkg.tx.created_outputs[i].asset_wire:
  │     └── wallet.asset.import_asset(asset_wire_json) → wallet DB
```

---

## 🔒 Canonical Contract

- `ClaimOutputWire.asset_wire` is the canonical serialized field name for portable claim outputs
- `ClaimTxVerifierImpl` requires `asset_wire` on canonical claim packages
- `Stage 4 claim_pkg_consumer::load_claim_pkgs()` still supports both old hex-row format and `Vec<ClaimTxPackage>` array format
- `Stage 4 claim_pkg_consumer::verify_claim_pkgs()` enforces `asset_wire` integrity before JMT publish

---

## 📄 Output File

| Old name | New name |
|---|---|
| `outputs/claim/claim_pkg_prepared.json` | `outputs/claim/tx_claim_pkg.json` |

📌 Rename rationale: naming now mirrors `tx_alice_to_bob_pkg.json` (Stage 4 output), signalling that both files are wallet-importable tx packages.
