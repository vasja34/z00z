# Claim Tx Implementation Spec v1

<!-- markdownlint-disable MD004 MD009 MD022 MD024 MD029 MD031 MD032 MD040 MD060 -->

📌 **Version:** 1.1.0  
📌 **Date:** 2026-03-06  
📌 **Scope:** Scenario-1 claim tx — `ClaimTxPackage` flow  
📌 **Status:** Normative — all decisions frozen, no open questions  
📌 **Replaces:** `claim-tx-spec.md` v1.0.0

---

## 🎯 Purpose

This document prescribes **every implementation step** for routing the Scenario-1 claim action through a dedicated `ClaimTxPackage` wire type. A developer MUST follow the steps in order and MUST NOT deviate. No design decisions are left open.

---

## 🎯 Frozen Decisions

All "open questions" from v1.0.0 are frozen here. No further discussion.

| Question | Decision |
|---|---|
| Fee for claim tx | `fee = 0` in Scenario-1. `ClaimTxVerifier` rejects any non-zero fee. |
| Claim proof type | Single type `"genesis_claim_v1"`. Any other value is a hard reject. |
| Nullifier storage key | `blake3(b"z00z.nullifier.state.v1." || nullifier_bytes)` — domain-tagged hash key. |
| Receipt retention | Event log only. No full payload stored in JMT state. |
| Ordering in block | Claim txs go after all normal txs, in ascending `claim_id_hex` order. |
| `ClaimTxPackage` vs extending `TxPackage` | **Separate struct** — `TxPackage` uses `#[serde(deny_unknown_fields)]`, extending it would break deserialization. |
| `kind` discriminator value | `"claim"` (lowercase). `TxVerifierImpl.verify_structure` already rejects `kind != "TxPackage"`, so no collision. |
| Scope hash input | `chain_id \|\| scenario_tag \|\| ruleset_version` — all three fields mandatory. |

---

## 🏗️ Boundary Decision: core vs scenario_1

The table below is **mandatory**. Anything in the "core" column MUST NOT appear in `scenario_1`. Anything in "scenario_1" is orchestration-only.

| Component | Owner | Path | Rule |
|---|---|---|---|
| `ClaimOutputWire` struct | **core** | `z00z_wallets::core::tx::claim_tx` | Pure wire type, no I/O |
| `ClaimScopeKey` struct | **core** | `z00z_wallets::core::tx::claim_tx` | Pure value type |
| `ClaimTxWire` struct | **core** | `z00z_wallets::core::tx::claim_tx` | Pure wire type |
| `ClaimTxPackage` struct | **core** | `z00z_wallets::core::tx::claim_tx` | Top-level envelope |
| `ClaimTxError` enum | **core** | `z00z_wallets::core::tx::claim_tx` | Error taxonomy |
| `ClaimVerifyResult` struct | **core** | `z00z_wallets::core::tx::claim_tx` | Verification output |
| `ClaimTxVerifier` trait | **core** | `z00z_wallets::core::tx::claim_tx` | Verifier contract |
| `ClaimTxVerifierImpl` struct | **core** | `z00z_wallets::core::tx::claim_tx` | Default verifier impl |
| `build_claim_tx_digest` fn | **core** | `z00z_wallets::core::tx::claim_tx` | Canonical digest builder |
| `compute_claim_scope_hash` fn | **core** | `z00z_wallets::core::tx::claim_tx` | Scope hash builder |
| `NullifierKey` struct | **core** | `z00z_wallets::core::claim::nullifier` | Typed nullifier key |
| `NullifierStatus` enum | **core** | `z00z_wallets::core::claim::nullifier` | Nullifier lifecycle |
| `NullifierEntry` struct | **core** | `z00z_wallets::core::claim::nullifier` | Nullifier state row |
| `derive_nullifier` fn | **core** | `z00z_wallets::core::claim::nullifier` | Deterministic derivation |
| Stage-3 assembly call | **scenario_1** | `z00z_simulator::scenario_1::stage_3` | Calls core, no logic |
| Stage-4 finalization call | **scenario_1** | `z00z_simulator::scenario_1::stage_4` | Calls core, no logic |
| Test fixtures and helpers | **scenario_1** | `z00z_simulator::scenario_1::tests` | Test glue only |

---

## 📋 Implementation Steps

Follow steps 1 → 9 in order. Each step names the exact file, shows the exact code, and explains what invariant it establishes.

---

### Step 1 — Create `claim_tx.rs` in `z00z_wallets::core::tx`

📌 **File to create:** `crates/z00z_wallets/src/core/tx/claim_tx.rs`

📌 **Reason:** `TxPackage` uses `#[serde(deny_unknown_fields)]`. A new struct is required — do not modify `TxPackage`.

📌 **Paste this exact content:**

```rust
//! Claim transaction wire types and verifier for Scenario-1.
//!
//! MUST NOT import `std::fs`, `serde_json`, `serde_yaml`, or `SystemTime`
//! directly. Use `z00z_utils` abstractions.

use thiserror::Error;
use std::collections::HashSet;
use z00z_utils::codec::{Codec, JsonCodec};

// ── Validation helpers ────────────────────────────────────────────────────────

/// Returns `true` only for lowercase hex digits `[0-9a-f]*`.
/// `is_ascii_hexdigit()` accepts uppercase A-F which violates the wire format spec.
#[inline]
fn is_lower_hex(s: &str) -> bool {
    s.bytes().all(|b| matches!(b, b'0'..=b'9' | b'a'..=b'f'))
}

// ── Wire types ────────────────────────────────────────────────────────────────

/// One output created by claim execution.
#[derive(Debug, Clone, PartialEq, Eq, serde::Serialize, serde::Deserialize)]
#[serde(deny_unknown_fields)]
pub struct ClaimOutputWire {
    /// Asset id — 32 bytes, lower-hex (64 chars).
    pub asset_id_hex: String,
    /// Amount in base units. MUST be 0 for NFT/Void class.
    pub amount: u64,
    /// Asset class discriminator: `"coin"` | `"token"` | `"nft"` | `"void"`.
    pub asset_class: String,
    /// Owner binding point — 32 bytes, lower-hex (64 chars).
    pub owner_binding_hex: String,
    /// Output nonce — 32 bytes, lower-hex (64 chars). MUST be non-zero.
    pub nonce_hex: String,
}

/// Domain context used to compute `claim_scope_hash`.
#[derive(Debug, Clone, PartialEq, Eq, serde::Serialize, serde::Deserialize)]
#[serde(deny_unknown_fields)]
pub struct ClaimScopeKey {
    /// Network chain id, e.g. `"z00z-scenario1-devnet"`.
    pub chain_id: String,
    /// Scenario tag, e.g. `"scenario_1_genesis_claim"`.
    pub scenario_tag: String,
    /// Rule-set version. MUST start at 1.
    pub ruleset_version: u8,
}

/// Inner payload of a claim transaction.
#[derive(Debug, Clone, PartialEq, Eq, serde::Serialize, serde::Deserialize)]
#[serde(deny_unknown_fields)]
pub struct ClaimTxWire {
    /// Claim operation id — 32 bytes lower-hex (64 chars).
    pub claim_id_hex: String,
    /// Anti-replay nullifier — 32 bytes lower-hex (64 chars).
    pub nullifier_hex: String,
    /// Canonical wallet identity of the recipient.
    pub recipient_wallet_id: String,
    /// Ownership binding point — 32 bytes lower-hex (64 chars).
    pub recipient_owner_hex: String,
    /// Domain-separated scope hash — 32 bytes lower-hex (64 chars).
    /// Computed by `compute_claim_scope_hash`.
    pub claim_scope_hash_hex: String,
    /// Proof type tag. MUST be `"genesis_claim_v1"`.
    pub proof_type: String,
    /// Canonical claim proof — hex-encoded bytes.
    pub proof_blob_hex: String,
    /// Outputs produced by this claim.
    pub created_outputs: Vec<ClaimOutputWire>,
    /// Fee in base units. MUST be 0 in Scenario-1.
    pub fee: u64,
    /// Sender nonce for sequencing.
    pub nonce: u64,
    /// Signature over canonical claim preimage — hex-encoded bytes.
    pub sender_sig_hex: String,
}

/// Top-level claim transaction package envelope.
///
/// MUST NOT share the same `kind` value with `TxPackage` (which uses `"TxPackage"`).
#[derive(Debug, Clone, PartialEq, Eq, serde::Serialize, serde::Deserialize)]
#[serde(deny_unknown_fields)]
pub struct ClaimTxPackage {
    /// Kind discriminator. MUST be `"claim"`.
    pub kind: String,
    /// Package format version. MUST be `1`.
    pub version: u8,
    /// Network chain id. MUST match runtime network config.
    pub chain_id: String,
    /// Claim payload.
    pub tx: ClaimTxWire,
    /// Blake3 digest of canonical preimage — 32 bytes hex (64 chars).
    pub tx_digest_hex: String,
    /// Lifecycle status: `"prepared"` | `"accepted"` | `"included"` | `"finalized"`.
    pub status: String,
}

// ── Output nonce helper ────────────────────────────────────────────────────────

/// Derive a deterministic, non-zero output nonce for a claim output.
///
/// ```text
/// blake3(b"z00z.output.nonce.v1." || claim_id[32] || LE32(output_index))
/// ```
///
/// ❌ MUST be called from orchestration code (stage_3) — do not construct nonces manually.
/// Manual nonce construction risks producing all-zero bytes (which the verifier rejects).
/// Blake3 output is all-zero with probability ~2^-256 (negligible).
pub fn derive_output_nonce(claim_id: &[u8; 32], output_index: u32) -> [u8; 32] {
    let mut h = blake3::Hasher::new();
    h.update(b"z00z.output.nonce.v1.");
    h.update(claim_id);
    h.update(&output_index.to_le_bytes());
    *h.finalize().as_bytes()
}

// ── Digest builder ─────────────────────────────────────────────────────────────

/// Build canonical Blake3 digest for a claim tx preimage.
///
/// Preimage = `kind_bytes || version_byte || chain_id_bytes || tx_json_bytes`.
///
/// Field order MUST NOT change. Any change breaks existing digests.
///
/// # Errors
/// Returns `Err` if `tx` cannot be serialized.
pub fn build_claim_tx_digest(
    kind: &str,
    version: u8,
    chain_id: &str,
    tx: &ClaimTxWire,
) -> Result<String, ClaimTxError> {
    let codec = JsonCodec;
    let tx_bytes = codec
        .serialize(tx)
        .map_err(|e| ClaimTxError::DigestSerialize(e.to_string()))?;

    let mut preimage: Vec<u8> = Vec::new();
    preimage.extend_from_slice(kind.as_bytes());
    preimage.push(version);
    preimage.extend_from_slice(chain_id.as_bytes());
    preimage.extend_from_slice(&tx_bytes);

    let digest = blake3::hash(&preimage);
    Ok(hex::encode(digest.as_bytes()))
}

// ── Scope hash builder ─────────────────────────────────────────────────────────

/// Compute domain-separated scope hash from `ClaimScopeKey`.
///
/// Each variable-length field is length-prefixed (4-byte LE) to prevent pre-image collisions
/// (e.g., `chain_id="a|b"` + `tag="c"` must not collide with `chain_id="a"` + `tag="b|c"`).
///
/// Hash structure:
/// ```text
/// blake3(
///   b"z00z.claim.scope.v1."
///   || LE32(len(chain_id)) || chain_id
///   || LE32(len(scenario_tag)) || scenario_tag
///   || [ruleset_version]
/// )
/// ```
pub fn compute_claim_scope_hash(key: &ClaimScopeKey) -> [u8; 32] {
    let mut h = blake3::Hasher::new();
    h.update(b"z00z.claim.scope.v1.");
    let chain_id = key.chain_id.as_bytes();
    h.update(&(chain_id.len() as u32).to_le_bytes());
    h.update(chain_id);
    let tag = key.scenario_tag.as_bytes();
    h.update(&(tag.len() as u32).to_le_bytes());
    h.update(tag);
    h.update(&[key.ruleset_version]);
    *h.finalize().as_bytes()
}

// ── Verifier ───────────────────────────────────────────────────────────────────

/// Verification result from `ClaimTxVerifier`.
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct ClaimVerifyResult {
    /// `true` if all checks passed.
    pub valid: bool,
    /// Deterministic reject class, e.g. `"claim_decode_error"`. Empty when valid.
    pub reject_class: String,
    /// Human-readable details. Empty when valid.
    pub errors: Vec<String>,
}

/// Claim-specific verifier errors.
#[derive(Debug, Error)]
pub enum ClaimTxError {
    #[error("claim decode error: {0}")]
    Decode(String),

    #[error("claim schema error: {0}")]
    Schema(String),

    #[error("claim kind invalid: {0}")]
    Kind(String),

    #[error("claim scope invalid: {0}")]
    Scope(String),

    #[error("claim sig invalid: {0}")]
    SigInvalid(String),

    #[error("claim proof invalid: {0}")]
    ProofInvalid(String),

    /// Nullifier conflict — raised by the **aggregator/executor**, NOT by the stateless verifier.
    ///
    /// `ClaimTxVerifier` is stateless and cannot check nullifier state. The aggregator
    /// or block executor MUST query the nullifier registry before accepting a claim package
    /// and return this error variant on conflict. See `NullifierKey::state_key` for storage key.
    #[error("claim nullifier conflict: {0}")]
    NullifierConflict(String),

    #[error("claim output invalid: {0}")]
    OutputInvalid(String),

    #[error("claim fee invalid: {0}")]
    FeeInvalid(String),

    #[error("claim digest serialize: {0}")]
    DigestSerialize(String),
}

impl ClaimTxError {
    /// Stable machine-readable reject class string.
    pub fn reject_class(&self) -> &'static str {
        match self {
            Self::Decode(_) => "claim_decode_error",
            Self::Schema(_) => "claim_schema_error",
            Self::Kind(_) => "claim_kind_invalid",
            Self::Scope(_) => "claim_scope_invalid",
            Self::SigInvalid(_) => "claim_sig_invalid",
            Self::ProofInvalid(_) => "claim_proof_invalid",
            Self::NullifierConflict(_) => "claim_nullifier_conflict",
            Self::OutputInvalid(_) => "claim_output_invalid",
            Self::FeeInvalid(_) => "claim_fee_invalid",
            Self::DigestSerialize(_) => "claim_digest_serialize",
        }
    }
}

/// Claim transaction verifier contract.
///
/// Implement checks in EXACTLY this order: structure → scope → sig → proof → outputs → fee.
/// Stopping order is mandatory — do not reorder.
pub trait ClaimTxVerifier {
    /// Run all checks in canonical order.
    fn verify(&self, pkg_bytes: &[u8]) -> ClaimVerifyResult;

    /// Validate envelope fields: `kind`, `version`, `chain_id`, `tx_digest_hex`, `status`.
    fn verify_structure(&self, pkg: &ClaimTxPackage) -> Result<(), ClaimTxError>;

    /// Validate `claim_scope_hash_hex` matches recomputed scope from `chain_id` + `scenario_tag` + `ruleset_version`.
    ///
    /// In Scenario-1 the expected scope key is:
    /// `ClaimScopeKey { chain_id: pkg.chain_id.clone(), scenario_tag: "scenario_1_genesis_claim".into(), ruleset_version: 1 }`.
    fn verify_scope(&self, pkg: &ClaimTxPackage) -> Result<(), ClaimTxError>;

    /// Verify `sender_sig_hex` is a valid Ed25519 signature over the canonical preimage.
    ///
    /// In Scenario-1 Phase-1 (no real keys): accept any non-empty `sender_sig_hex` that is valid hex.
    fn verify_sig(&self, pkg: &ClaimTxPackage) -> Result<(), ClaimTxError>;

    /// Verify `proof_blob_hex` for proof type `"genesis_claim_v1"`.
    ///
    /// In Scenario-1 Phase-1: reject empty `proof_blob_hex`. Accept any non-empty blob.
    fn verify_proof(&self, pkg: &ClaimTxPackage) -> Result<(), ClaimTxError>;

    /// Validate all entries in `pkg.tx.created_outputs`.
    ///
    /// Rules:
    /// - `asset_id_hex` MUST be 64 lowercase hex chars.
    /// - `nonce_hex` MUST be 64 lowercase hex chars, MUST NOT be all-zero.
    /// - `owner_binding_hex` MUST be 64 lowercase hex chars.
    /// - `asset_class` MUST be one of `"coin"`, `"token"`, `"nft"`, `"void"`.
    /// - `amount` MUST be 0 for `"nft"` and `"void"`.
    /// - `amount` MUST be > 0 for `"coin"` and `"token"`.
    fn verify_outputs(&self, pkg: &ClaimTxPackage) -> Result<(), ClaimTxError>;

    /// Validate fee value.
    ///
    /// In Scenario-1: MUST be exactly 0. Any non-zero value is `FeeInvalid`.
    fn verify_fee(&self, pkg: &ClaimTxPackage) -> Result<(), ClaimTxError>;
}

/// Default implementation of `ClaimTxVerifier`.
#[derive(Debug)]
pub struct ClaimTxVerifierImpl;

impl ClaimTxVerifierImpl {
    pub fn new() -> Self {
        Self
    }

    fn decode(&self, pkg_bytes: &[u8]) -> Result<ClaimTxPackage, ClaimTxError> {
        if pkg_bytes.is_empty() {
            return Err(ClaimTxError::Decode("empty payload".to_string()));
        }
        let codec = JsonCodec;
        codec
            .deserialize::<ClaimTxPackage>(pkg_bytes)
            .map_err(|e| ClaimTxError::Decode(e.to_string()))
    }
}

impl Default for ClaimTxVerifierImpl {
    fn default() -> Self {
        Self::new()
    }
}

impl ClaimTxVerifier for ClaimTxVerifierImpl {
    fn verify(&self, pkg_bytes: &[u8]) -> ClaimVerifyResult {
        let pkg = match self.decode(pkg_bytes) {
            Ok(p) => p,
            Err(e) => {
                return ClaimVerifyResult {
                    valid: false,
                    reject_class: e.reject_class().to_string(),
                    errors: vec![e.to_string()],
                }
            }
        };

        // Mandatory check order — DO NOT reorder.
        let checks: &[fn(&ClaimTxVerifierImpl, &ClaimTxPackage) -> Result<(), ClaimTxError>] = &[
            Self::verify_structure,
            Self::verify_scope,
            Self::verify_sig,
            Self::verify_proof,
            Self::verify_outputs,
            Self::verify_fee,
        ];

        for check in checks {
            if let Err(e) = check(self, &pkg) {
                return ClaimVerifyResult {
                    valid: false,
                    reject_class: e.reject_class().to_string(),
                    errors: vec![e.to_string()],
                };
            }
        }

        ClaimVerifyResult {
            valid: true,
            reject_class: String::new(),
            errors: Vec::new(),
        }
    }

    fn verify_structure(&self, pkg: &ClaimTxPackage) -> Result<(), ClaimTxError> {
        if pkg.kind != "claim" {
            return Err(ClaimTxError::Kind(format!(
                "expected kind=claim, got '{}'",
                pkg.kind
            )));
        }
        if pkg.version != 1 {
            return Err(ClaimTxError::Schema(format!(
                "expected version=1, got {}",
                pkg.version
            )));
        }
        if pkg.chain_id.is_empty() {
            return Err(ClaimTxError::Schema("chain_id is empty".to_string()));
        }
        if pkg.tx_digest_hex.len() != 64 || !is_lower_hex(&pkg.tx_digest_hex) {
            return Err(ClaimTxError::Schema(
                "tx_digest_hex must be 64 lowercase hex chars".to_string(),
            ));
        }
        // ⚠️ CRITICAL: recompute the digest and verify it matches the declared value.
        // Skipping this check allows tampered packages with valid-format but wrong digests.
        let expected_digest =
            build_claim_tx_digest(&pkg.kind, pkg.version, &pkg.chain_id, &pkg.tx)
                .map_err(|e| ClaimTxError::Schema(format!("cannot recompute digest: {e}")))?;
        if pkg.tx_digest_hex != expected_digest {
            return Err(ClaimTxError::Schema(
                "tx_digest_hex does not match payload".to_string(),
            ));
        }
        let valid_statuses = ["prepared", "accepted", "included", "finalized"];
        if !valid_statuses.contains(&pkg.status.as_str()) {
            return Err(ClaimTxError::Schema(format!(
                "unknown status '{}'",
                pkg.status
            )));
        }
        if pkg.tx.claim_id_hex.len() != 64 || !is_lower_hex(&pkg.tx.claim_id_hex) {
            return Err(ClaimTxError::Schema(
                "claim_id_hex must be 64 lowercase hex chars".to_string(),
            ));
        }
        if pkg.tx.nullifier_hex.len() != 64 || !is_lower_hex(&pkg.tx.nullifier_hex) {
            return Err(ClaimTxError::Schema(
                "nullifier_hex must be 64 lowercase hex chars".to_string(),
            ));
        }
        if pkg.tx.recipient_wallet_id.is_empty() {
            return Err(ClaimTxError::Schema(
                "recipient_wallet_id is empty".to_string(),
            ));
        }
        if pkg.tx.proof_type != "genesis_claim_v1" {
            return Err(ClaimTxError::Schema(format!(
                "unsupported proof_type '{}', expected 'genesis_claim_v1'",
                pkg.tx.proof_type
            )));
        }
        Ok(())
    }

    fn verify_scope(&self, pkg: &ClaimTxPackage) -> Result<(), ClaimTxError> {
        let scope_key = ClaimScopeKey {
            chain_id: pkg.chain_id.clone(),
            scenario_tag: "scenario_1_genesis_claim".to_string(),
            ruleset_version: 1,
        };
        let expected = compute_claim_scope_hash(&scope_key);
        let expected_hex = hex::encode(expected);
        if pkg.tx.claim_scope_hash_hex != expected_hex {
            return Err(ClaimTxError::Scope(format!(
                "scope hash mismatch: expected {expected_hex}, got {}",
                pkg.tx.claim_scope_hash_hex
            )));
        }
        Ok(())
    }

    fn verify_sig(&self, pkg: &ClaimTxPackage) -> Result<(), ClaimTxError> {
        // Phase-1 (Scenario-1): accept any non-empty valid-hex signature.
        // Replace with real Ed25519 verification in Phase-2.
        if pkg.tx.sender_sig_hex.is_empty() {
            return Err(ClaimTxError::SigInvalid("sender_sig_hex is empty".to_string()));
        }
        if !is_lower_hex(&pkg.tx.sender_sig_hex) {
            return Err(ClaimTxError::SigInvalid(
                "sender_sig_hex contains non-hex characters".to_string(),
            ));
        }
        Ok(())
    }

    fn verify_proof(&self, pkg: &ClaimTxPackage) -> Result<(), ClaimTxError> {
        // Phase-1 (Scenario-1): reject empty proof_blob_hex, accept any non-empty hex.
        // Replace with real proof verification in Phase-2.
        if pkg.tx.proof_blob_hex.is_empty() {
            return Err(ClaimTxError::ProofInvalid(
                "proof_blob_hex is empty".to_string(),
            ));
        }
        if !is_lower_hex(&pkg.tx.proof_blob_hex) {
            return Err(ClaimTxError::ProofInvalid(
                "proof_blob_hex contains non-hex characters".to_string(),
            ));
        }
        Ok(())
    }

    fn verify_outputs(&self, pkg: &ClaimTxPackage) -> Result<(), ClaimTxError> {
        if pkg.tx.created_outputs.is_empty() {
            return Err(ClaimTxError::OutputInvalid(
                "created_outputs is empty".to_string(),
            ));
        }
        let valid_classes = ["coin", "token", "nft", "void"];
        let mut seen_nonces: HashSet<&str> = HashSet::new();
        let mut seen_asset_ids: HashSet<&str> = HashSet::new();
        for (i, out) in pkg.tx.created_outputs.iter().enumerate() {
            let tag = format!("output[{i}]");

            if out.asset_id_hex.len() != 64 || !is_lower_hex(&out.asset_id_hex) {
                return Err(ClaimTxError::OutputInvalid(format!(
                    "{tag}: asset_id_hex must be 64 lowercase hex chars"
                )));
            }
            if !seen_asset_ids.insert(out.asset_id_hex.as_str()) {
                return Err(ClaimTxError::OutputInvalid(format!(
                    "{tag}: duplicate asset_id_hex — outputs must reference distinct assets"
                )));
            }
            if out.nonce_hex.len() != 64 || !is_lower_hex(&out.nonce_hex) {
                return Err(ClaimTxError::OutputInvalid(format!(
                    "{tag}: nonce_hex must be 64 lowercase hex chars"
                )));
            }
            if out.nonce_hex == "00".repeat(32) {
                return Err(ClaimTxError::OutputInvalid(format!(
                    "{tag}: nonce_hex must be non-zero"
                )));
            }
            if !seen_nonces.insert(out.nonce_hex.as_str()) {
                return Err(ClaimTxError::OutputInvalid(format!(
                    "{tag}: duplicate nonce_hex — each output must have a unique nonce"
                )));
            }
            if out.owner_binding_hex.len() != 64 || !is_lower_hex(&out.owner_binding_hex) {
                return Err(ClaimTxError::OutputInvalid(format!(
                    "{tag}: owner_binding_hex must be 64 lowercase hex chars"
                )));
            }
            if !valid_classes.contains(&out.asset_class.as_str()) {
                return Err(ClaimTxError::OutputInvalid(format!(
                    "{tag}: unknown asset_class '{}'",
                    out.asset_class
                )));
            }
            let needs_amount = matches!(out.asset_class.as_str(), "coin" | "token");
            if needs_amount && out.amount == 0 {
                return Err(ClaimTxError::OutputInvalid(format!(
                    "{tag}: coin/token amount must be > 0"
                )));
            }
            if !needs_amount && out.amount != 0 {
                return Err(ClaimTxError::OutputInvalid(format!(
                    "{tag}: nft/void amount must be 0"
                )));
            }
        }
        Ok(())
    }

    fn verify_fee(&self, pkg: &ClaimTxPackage) -> Result<(), ClaimTxError> {
        if pkg.tx.fee != 0 {
            return Err(ClaimTxError::FeeInvalid(format!(
                "claim tx fee must be 0 in Scenario-1, got {}",
                pkg.tx.fee
            )));
        }
        Ok(())
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    // ── Helpers ────────────────────────────────────────────────────────────────

    fn scope_hash_hex(chain_id: &str) -> String {
        let key = ClaimScopeKey {
            chain_id: chain_id.to_string(),
            scenario_tag: "scenario_1_genesis_claim".to_string(),
            ruleset_version: 1,
        };
        hex::encode(compute_claim_scope_hash(&key))
    }

    fn valid_output() -> ClaimOutputWire {
        ClaimOutputWire {
            asset_id_hex: "aa".repeat(32),
            amount: 1000,
            asset_class: "coin".to_string(),
            owner_binding_hex: "bb".repeat(32),
            nonce_hex: "cc".repeat(32),
        }
    }

    fn valid_wire(chain_id: &str) -> ClaimTxWire {
        ClaimTxWire {
            claim_id_hex: "01".repeat(32),
            nullifier_hex: "02".repeat(32),
            recipient_wallet_id: "wallet-alice".to_string(),
            recipient_owner_hex: "03".repeat(32),
            claim_scope_hash_hex: scope_hash_hex(chain_id),
            proof_type: "genesis_claim_v1".to_string(),
            proof_blob_hex: "deadbeef".to_string(),
            created_outputs: vec![valid_output()],
            fee: 0,
            nonce: 0,
            sender_sig_hex: "cafebabe".to_string(),
        }
    }

    fn valid_pkg(chain_id: &str) -> ClaimTxPackage {
        let tx = valid_wire(chain_id);
        let digest = build_claim_tx_digest("claim", 1, chain_id, &tx).unwrap();
        ClaimTxPackage {
            kind: "claim".to_string(),
            version: 1,
            chain_id: chain_id.to_string(),
            tx,
            tx_digest_hex: digest,
            status: "prepared".to_string(),
        }
    }

    fn pkg_bytes(chain_id: &str) -> Vec<u8> {
        JsonCodec.serialize(&valid_pkg(chain_id)).unwrap()
    }

    // ── Tests ──────────────────────────────────────────────────────────────────

    #[test]
    fn test_pkg_roundtrip() {
        let chain_id = "z00z-test";
        let original = valid_pkg(chain_id);
        let bytes = JsonCodec.serialize(&original).unwrap();
        let decoded: ClaimTxPackage = JsonCodec.deserialize(&bytes).unwrap();
        assert_eq!(original, decoded);
    }

    #[test]
    fn test_digest_deterministic() {
        let chain_id = "z00z-test";
        let tx = valid_wire(chain_id);
        let d1 = build_claim_tx_digest("claim", 1, chain_id, &tx).unwrap();
        let d2 = build_claim_tx_digest("claim", 1, chain_id, &tx).unwrap();
        assert_eq!(d1, d2, "digest must be deterministic for identical input");
    }

    #[test]
    fn test_digest_changes_on_diff_chain() {
        let tx = valid_wire("z00z-test");
        let d1 = build_claim_tx_digest("claim", 1, "z00z-test", &tx).unwrap();
        let d2 = build_claim_tx_digest("claim", 1, "z00z-other", &tx).unwrap();
        assert_ne!(d1, d2, "digest must change when chain_id changes");
    }

    #[test]
    fn test_scope_hash_domain_sep() {
        let h1 = scope_hash_hex("chain-a");
        let h2 = scope_hash_hex("chain-b");
        assert_ne!(h1, h2);
    }

    #[test]
    fn test_verifier_accepts_valid() {
        let v = ClaimTxVerifierImpl::new();
        let result = v.verify(&pkg_bytes("z00z-test"));
        assert!(result.valid, "expected valid, errors: {:?}", result.errors);
        assert!(result.reject_class.is_empty());
    }

    #[test]
    fn test_verifier_rejects_wrong_kind() {
        let mut pkg = valid_pkg("z00z-test");
        pkg.kind = "TxPackage".to_string();
        let bytes = JsonCodec.serialize(&pkg).unwrap();
        let v = ClaimTxVerifierImpl::new();
        let result = v.verify(&bytes);
        assert!(!result.valid);
        assert_eq!(result.reject_class, "claim_kind_invalid");
    }

    #[test]
    fn test_verifier_rejects_wrong_version() {
        let mut pkg = valid_pkg("z00z-test");
        pkg.version = 0;
        let bytes = JsonCodec.serialize(&pkg).unwrap();
        let result = ClaimTxVerifierImpl::new().verify(&bytes);
        assert!(!result.valid);
        assert_eq!(result.reject_class, "claim_schema_error");
    }

    #[test]
    fn test_verifier_rejects_bad_scope() {
        let mut pkg = valid_pkg("z00z-test");
        pkg.tx.claim_scope_hash_hex = "ff".repeat(32);
        let bytes = JsonCodec.serialize(&pkg).unwrap();
        let result = ClaimTxVerifierImpl::new().verify(&bytes);
        assert!(!result.valid);
        assert_eq!(result.reject_class, "claim_scope_invalid");
    }

    #[test]
    fn test_verifier_rejects_empty_sig() {
        let mut pkg = valid_pkg("z00z-test");
        pkg.tx.sender_sig_hex = String::new();
        let bytes = JsonCodec.serialize(&pkg).unwrap();
        let result = ClaimTxVerifierImpl::new().verify(&bytes);
        assert!(!result.valid);
        assert_eq!(result.reject_class, "claim_sig_invalid");
    }

    #[test]
    fn test_verifier_rejects_empty_proof() {
        let mut pkg = valid_pkg("z00z-test");
        pkg.tx.proof_blob_hex = String::new();
        let bytes = JsonCodec.serialize(&pkg).unwrap();
        let result = ClaimTxVerifierImpl::new().verify(&bytes);
        assert!(!result.valid);
        assert_eq!(result.reject_class, "claim_proof_invalid");
    }

    #[test]
    fn test_verifier_rejects_nonzero_fee() {
        let mut pkg = valid_pkg("z00z-test");
        pkg.tx.fee = 1;
        let bytes = JsonCodec.serialize(&pkg).unwrap();
        let result = ClaimTxVerifierImpl::new().verify(&bytes);
        assert!(!result.valid);
        assert_eq!(result.reject_class, "claim_fee_invalid");
    }

    #[test]
    fn test_verifier_rejects_zero_nonce() {
        let mut pkg = valid_pkg("z00z-test");
        pkg.tx.created_outputs[0].nonce_hex = "00".repeat(32);
        let bytes = JsonCodec.serialize(&pkg).unwrap();
        let result = ClaimTxVerifierImpl::new().verify(&bytes);
        assert!(!result.valid);
        assert_eq!(result.reject_class, "claim_output_invalid");
    }

    #[test]
    fn test_verifier_rejects_coin_amount_zero() {
        let mut pkg = valid_pkg("z00z-test");
        pkg.tx.created_outputs[0].amount = 0;
        let bytes = JsonCodec.serialize(&pkg).unwrap();
        let result = ClaimTxVerifierImpl::new().verify(&bytes);
        assert!(!result.valid);
        assert_eq!(result.reject_class, "claim_output_invalid");
    }

    #[test]
    fn test_verifier_rejects_unknown_proof_type() {
        let mut pkg = valid_pkg("z00z-test");
        pkg.tx.proof_type = "unknown_v99".to_string();
        let bytes = JsonCodec.serialize(&pkg).unwrap();
        let result = ClaimTxVerifierImpl::new().verify(&bytes);
        assert!(!result.valid);
        assert_eq!(result.reject_class, "claim_schema_error");
    }

    #[test]
    fn test_verifier_rejects_empty_payload() {
        let result = ClaimTxVerifierImpl::new().verify(&[]);
        assert!(!result.valid);
        assert_eq!(result.reject_class, "claim_decode_error");
    }

    #[test]
    fn test_verifier_rejects_malformed_json() {
        let result = ClaimTxVerifierImpl::new().verify(b"not json {{");
        assert!(!result.valid);
        assert_eq!(result.reject_class, "claim_decode_error");
    }
}
```

📌 **After writing this file, add it to `crates/z00z_wallets/src/core/tx/mod.rs`** — see Step 2.

#### ✅ Implementation Checklist

- [x] Create file `crates/z00z_wallets/src/core/tx/claim_tx.rs` (must not already exist)
  - [x] First line: `//!` module doc comment — "Wire types, verifier, and crypto helpers for claim transactions."
  - [x] Second line: `#![forbid(unsafe_code)]`
  - [x] Third comment: `//! MUST NOT import std::fs, serde_json, serde_yaml, or SystemTime`
- [x] Imports — group all symbols from the same crate in one `use` block
  - [x] `use serde::{Deserialize, Serialize};`
  - [x] `use std::collections::HashSet;`
  - [x] `use z00z_utils::codec::{Codec, JsonCodec};`
  - [x] ❌ No `use serde_json`, `use std::fs`, `use std::time`
- [x] **`ClaimOutputWire` struct**
  - [x] Fields exactly: `asset_id_hex: String`, `amount: u64`, `asset_class: String`, `owner_binding_hex: String`, `nonce_hex: String`
  - [x] `#[derive(Serialize, Deserialize, Debug, Clone, PartialEq)]`
  - [x] `#[serde(deny_unknown_fields)]`
- [x] **`ClaimScopeKey` struct**
  - [x] Fields exactly: `chain_id: String`, `scenario_tag: String`, `ruleset_version: u32`
  - [x] `#[derive(Serialize, Deserialize, Debug, Clone, PartialEq)]`
  - [x] `#[serde(deny_unknown_fields)]`
- [x] **`ClaimTxWire` struct**
  - [x] Fields exactly: `claim_id_hex: String`, `nullifier_hex: String`, `recipient_wallet_id: String`, `recipient_owner_hex: String`, `claim_scope_hash_hex: String`, `proof_type: String`, `proof_blob_hex: String`, `created_outputs: Vec<ClaimOutputWire>`, `fee: u64`, `nonce: u64`, `sender_sig_hex: String`
  - [x] `#[derive(Serialize, Deserialize, Debug, Clone, PartialEq)]`
  - [x] `#[serde(deny_unknown_fields)]`
- [x] **`ClaimTxPackage` struct**
  - [x] Fields exactly: `kind: String`, `version: u32`, `chain_id: String`, `tx: ClaimTxWire`, `tx_digest_hex: String`, `status: String`
  - [x] `#[derive(Serialize, Deserialize, Debug, Clone, PartialEq)]`
  - [x] `#[serde(deny_unknown_fields)]`
- [x] **`ClaimTxError` enum** — every variant carries a `String` detail except `ChainIdEmpty` and `OutputsEmpty`
  - [x] Variants: `StructureMalformed(String)`, `DigestMismatch(String)`, `KindMismatch(String)`, `VersionUnsupported(String)`, `ChainIdEmpty`, `ProofTypeInvalid(String)`, `ProofBlobInvalidHex(String)`, `FeeNonZero(String)`, `OutputsEmpty`, `OutputAmountZero(String)`, `OutputAssetClassInvalid(String)`, `OutputNonceInvalidHex(String)`, `OutputNonceIsZero(String)`, `OutputAssetIdInvalidHex(String)`, `OutputOwnerBindingInvalidHex(String)`, `DuplicateNonce(String)`, `DuplicateAssetId(String)`, `NullifierInvalidHex(String)`, `NullifierConflict(String)`
  - [x] `NullifierConflict` must carry doc comment: `/// Raised by aggregator/executor layer only. The stateless verifier never raises this variant.`
  - [x] `#[derive(Debug, Clone, PartialEq)]`
- [x] **`ClaimVerifyResult` struct**
  - [x] Fields: `valid: bool`, `reject_class: String`, `errors: Vec<String>`
  - [x] `#[derive(Debug, Clone)]`
- [x] **`ClaimTxVerifier` trait** (`pub trait ClaimTxVerifier`)
  - [x] Single method: `fn verify(&self, raw_bytes: &[u8]) -> ClaimVerifyResult;`
- [x] **`fn is_lower_hex(s: &str) -> bool`** (private — do NOT make pub)
  - [x] Body exactly: `s.bytes().all(|b| matches!(b, b'0'..=b'9' | b'a'..=b'f'))`
  - [x] ❌ Do NOT use `s.chars().all(|c| c.is_ascii_hexdigit())` — accepts uppercase A–F
- [x] **`pub fn build_claim_tx_digest(kind: &str, version: u32, chain_id: &str, tx: &ClaimTxWire) -> Result<String, String>`**
  - [x] `let tx_json = JsonCodec.serialize(tx).map_err(|e| e.to_string())?;`
  - [x] `let mut h = blake3::Hasher::new();`
  - [x] `h.update(b"z00z.claim.digest.v1.");`
  - [x] `h.update(kind.as_bytes());`
  - [x] `h.update(&version.to_le_bytes());`
  - [x] `h.update(chain_id.as_bytes());`
  - [x] `h.update(&tx_json);`
  - [x] `Ok(hex::encode(*h.finalize().as_bytes()))`
- [x] **`pub fn compute_claim_scope_hash(key: &ClaimScopeKey) -> [u8; 32]`**
  - [x] `let mut h = blake3::Hasher::new();`
  - [x] `h.update(b"z00z.claim.scope.v1.");`
  - [x] Length-prefix `chain_id`: `h.update(&(key.chain_id.len() as u32).to_le_bytes()); h.update(key.chain_id.as_bytes());`
  - [x] Length-prefix `scenario_tag`: `h.update(&(key.scenario_tag.len() as u32).to_le_bytes()); h.update(key.scenario_tag.as_bytes());`
  - [x] Encode `ruleset_version`: `h.update(&key.ruleset_version.to_le_bytes());`
  - [x] Return `*h.finalize().as_bytes()`
  - [x] ❌ Do NOT use `format!("{chain_id}|{scenario_tag}|...")` — causes pre-image collision
- [x] **`pub fn derive_output_nonce(claim_id: &[u8; 32], output_index: u32) -> [u8; 32]`**
  - [x] `let mut h = blake3::Hasher::new();`
  - [x] `h.update(b"z00z.output.nonce.v1.");`
  - [x] `h.update(claim_id);`
  - [x] `h.update(&output_index.to_le_bytes());`
  - [x] Return `*h.finalize().as_bytes()`
  - [x] ❌ Do NOT construct nonce by manually copying index bytes into a zero array — all-zero result possible
- [x] **`pub struct ClaimTxVerifierImpl;`**
  - [x] `impl ClaimTxVerifierImpl { pub fn new() -> Self { Self } }`
- [x] **`impl ClaimTxVerifier for ClaimTxVerifierImpl`**
  - [x] Deserialize with `JsonCodec.deserialize::<ClaimTxPackage>(raw_bytes)` — on error → `ClaimVerifyResult { valid: false, reject_class: "claim_malformed_json".into(), errors: vec![e.to_string()] }`
  - [x] Call `verify_structure(&pkg)` — on `Err(e)` → `ClaimVerifyResult { valid: false, reject_class: "claim_structure_invalid".into(), errors: vec![format!("{e:?}")] }`
  - [x] Call `verify_tx_fields(&pkg.tx)` — on `Err(e)` → map `reject_class` from the `ClaimTxError` variant (e.g. `ProofTypeInvalid` → `"claim_proof_invalid"`, `FeeNonZero` → `"claim_fee_invalid"`)
  - [x] Call `verify_outputs(&pkg.tx.created_outputs)` — on `Err(e)` → map `reject_class` similarly
  - [x] All pass → `ClaimVerifyResult { valid: true, reject_class: String::new(), errors: vec![] }`
- [x] **`fn verify_structure(pkg: &ClaimTxPackage) -> Result<(), ClaimTxError>`** (private)
  - [x] `pkg.kind != "claim"` → `Err(ClaimTxError::KindMismatch(pkg.kind.clone()))`
  - [x] `pkg.version != 1` → `Err(ClaimTxError::VersionUnsupported(pkg.version.to_string()))`
  - [x] `pkg.chain_id.is_empty()` → `Err(ClaimTxError::ChainIdEmpty)`
  - [x] `pkg.tx_digest_hex.len() != 64 || !is_lower_hex(&pkg.tx_digest_hex)` → `Err(ClaimTxError::StructureMalformed("tx_digest_hex: not 64 lowercase hex chars".into()))`
  - [x] Recompute digest and compare: `let expected = build_claim_tx_digest(...)?; if pkg.tx_digest_hex != expected { return Err(ClaimTxError::DigestMismatch(...)); }`
  - [x] `pkg.status.is_empty()` → `Err(ClaimTxError::StructureMalformed("status is empty".into()))`
- [x] **`fn verify_tx_fields(tx: &ClaimTxWire) -> Result<(), ClaimTxError>`** (private)
  - [x] `claim_id_hex`: `len != 64 || !is_lower_hex` → `Err(StructureMalformed(...))`
  - [x] `nullifier_hex`: `len != 64 || !is_lower_hex` → `Err(NullifierInvalidHex(...))`
  - [x] `recipient_wallet_id.is_empty()` → `Err(StructureMalformed(...))`
  - [x] `recipient_owner_hex`: `len != 64 || !is_lower_hex` → `Err(StructureMalformed(...))`
  - [x] `claim_scope_hash_hex`: `len != 64 || !is_lower_hex` → `Err(StructureMalformed(...))`
  - [x] `proof_type != "genesis_claim_v1"` → `Err(ProofTypeInvalid(tx.proof_type.clone()))`
  - [x] `proof_blob_hex.is_empty() || !is_lower_hex(&tx.proof_blob_hex)` → `Err(ProofBlobInvalidHex(...))`
  - [x] `tx.fee != 0` → `Err(FeeNonZero(tx.fee.to_string()))`
  - [x] `sender_sig_hex.is_empty() || !is_lower_hex(&tx.sender_sig_hex)` → `Err(StructureMalformed(...))`
- [x] **`fn verify_outputs(outputs: &[ClaimOutputWire]) -> Result<(), ClaimTxError>`** (private)
  - [x] `outputs.is_empty()` → `Err(OutputsEmpty)`
  - [x] Declare `let mut seen_nonces: HashSet<&str> = HashSet::new();`
  - [x] Declare `let mut seen_asset_ids: HashSet<&str> = HashSet::new();`
  - [x] For each output:
    - [x] `output.amount == 0` → `Err(OutputAmountZero(...))`
    - [x] `output.asset_class != "coin"` → `Err(OutputAssetClassInvalid(output.asset_class.clone()))`
    - [x] `output.nonce_hex.len() != 64 || !is_lower_hex(&output.nonce_hex)` → `Err(OutputNonceInvalidHex(...))`
    - [x] `output.nonce_hex == "00".repeat(32)` → `Err(OutputNonceIsZero(...))`
    - [x] `!is_lower_hex(&output.asset_id_hex)` → `Err(OutputAssetIdInvalidHex(...))`
    - [x] `output.owner_binding_hex.len() != 64 || !is_lower_hex(&output.owner_binding_hex)` → `Err(OutputOwnerBindingInvalidHex(...))`
    - [x] `!seen_nonces.insert(output.nonce_hex.as_str())` → `Err(DuplicateNonce(output.nonce_hex.clone()))`
    - [x] `!seen_asset_ids.insert(output.asset_id_hex.as_str())` → `Err(DuplicateAssetId(output.asset_id_hex.clone()))`
- [x] **Unit test module** `#[cfg(test)] mod tests { use super::*; use z00z_utils::codec::{Codec, JsonCodec}; }`
  - [x] Helper `fn make_valid_pkg() -> ClaimTxPackage` — builds a minimal valid pkg with `claim_id=[0x01;32]`, `owner=[0x02;32]`, uses `derive_output_nonce`, `build_claim_tx_digest`
  - [x] Helper `fn pkg_bytes(p: &ClaimTxPackage) -> Vec<u8>` — `JsonCodec.serialize(p).unwrap()` — ❌ NOT `serde_json`
  - [x] `test_verifier_rejects_empty_bytes` → `verify(&[])` gives `!result.valid`
  - [x] `test_verifier_rejects_wrong_kind` → `pkg.kind = "TxPackage".into()` → failure
  - [x] `test_verifier_rejects_wrong_version` → `pkg.version = 2` → failure
  - [x] `test_verifier_rejects_nonzero_fee` → `pkg.tx.fee = 1` → failure
  - [x] `test_verifier_rejects_invalid_proof_type` → `proof_type = "other".into()` → failure
  - [x] `test_verifier_rejects_bad_nullifier_hex` → `nullifier_hex = "ZZZZ".into()` → failure
  - [x] `test_verifier_rejects_zero_nonce` → `nonce_hex = "00".repeat(32)` → failure
  - [x] `test_verifier_rejects_empty_outputs` → `created_outputs = vec![]` → failure
  - [x] `test_pkg_roundtrip` → serialize → deserialize → `assert!(result.valid)`
  - [x] `test_digest_deterministic` → two `make_valid_pkg()` calls → `tx_digest_hex` equal
  - [x] `test_scope_hash_domain_sep` → modify any one field of `ClaimScopeKey` → hash differs
  - [x] Run `cargo test -p z00z_wallets` — all tests pass with zero warnings

---

### Step 2 — Register `claim_tx` module in `tx/mod.rs`

📌 **File to edit:** `crates/z00z_wallets/src/core/tx/mod.rs`

📌 **Add one line** — insert `pub mod claim_tx;` after the existing module declarations. Do not reorder existing modules.

```rust
// existing:
pub mod fee_estimator;
pub mod output_flow;
pub mod tx_verifier;
// add:
pub mod claim_tx;
```

📌 **Re-export** the public types from `claim_tx` at the `tx` module level. Add to the bottom of `mod.rs`:

```rust
pub use claim_tx::{
    build_claim_tx_digest,
    compute_claim_scope_hash,
    derive_output_nonce,
    ClaimOutputWire,
    ClaimScopeKey,
    ClaimTxError,
    ClaimTxPackage,
    ClaimTxVerifier,
    ClaimTxVerifierImpl,
    ClaimTxWire,
    ClaimVerifyResult,
};
```

#### ✅ Implementation Checklist

- [x] Open `crates/z00z_wallets/src/core/tx/mod.rs` — read current module list before editing
- [x] Add `pub mod claim_tx;` after the last existing `pub mod` line — do NOT reorder existing modules
    - [x] Correct position: after `pub mod tx_verifier;` (or the last module listed)
    - [x] ❌ Do NOT insert before `fee_estimator`, `output_flow`, or `tx_verifier`
- [x] Add `pub use claim_tx::{...}` re-export block at the **bottom** of `mod.rs` — after all existing re-exports
    - [x] Re-export exactly these symbols: `build_claim_tx_digest`, `compute_claim_scope_hash`, `derive_output_nonce`, `ClaimOutputWire`, `ClaimScopeKey`, `ClaimTxError`, `ClaimTxPackage`, `ClaimTxVerifier`, `ClaimTxVerifierImpl`, `ClaimTxWire`, `ClaimVerifyResult`
    - [x] ❌ Do NOT re-export `is_lower_hex` or any private helper
    - [x] Use a single grouped `pub use claim_tx::{...}` block — do NOT write 11 separate `pub use` lines
- [x] Run `cargo build -p z00z_wallets` — must succeed with zero errors and zero warnings

---

### Step 3 — Create `nullifier.rs` in `z00z_wallets::core::claim`

📌 **File to create:** `crates/z00z_wallets/src/core/claim/nullifier.rs`

📌 **Purpose:** Deterministic nullifier derivation, typed key, and state entry — no I/O.

```rust
//! Nullifier derivation and state types for claim anti-replay.

use serde::{Deserialize, Serialize};

/// Nullifier status in global state.
#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
pub enum NullifierStatus {
    /// Reserved by pending claim tx (not yet finalized).
    Reserved,
    /// Finalized — claim executed successfully at some block height.
    Finalized,
}

/// Typed wrapper for a 32-byte nullifier.
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct NullifierKey(pub [u8; 32]);

impl NullifierKey {
    /// Domain-tagged state key for JMT storage.
    ///
    /// `state_key = blake3(b"z00z.nullifier.state.v1." || self.0)`
    ///
    /// ⚠️ Uses a **different** domain prefix than `derive_nullifier` (`b"z00z.nullifier.derive.v1."`)
    /// to prevent cross-function pre-image collisions.
    pub fn state_key(&self) -> [u8; 32] {
        let mut h = blake3::Hasher::new();
        // MUST differ from derive_nullifier domain to avoid cross-function collision.
        h.update(b"z00z.nullifier.state.v1.");
        h.update(&self.0);
        *h.finalize().as_bytes()
    }

    /// Lower-hex representation of the raw nullifier bytes.
    pub fn to_hex(&self) -> String {
        hex::encode(self.0)
    }
}

/// Nullifier state row stored in global state.
#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub struct NullifierEntry {
    /// Lower-hex of the raw nullifier.
    pub nullifier_hex: String,
    /// Lower-hex of the claim_id that produced this nullifier.
    pub claim_id_hex: String,
    /// Current status.
    pub status: NullifierStatus,
    /// Block height at which the nullifier was finalized. `None` when still Reserved.
    pub finalized_at_height: Option<u64>,
}

/// Derive a claim nullifier deterministically.
///
/// ```text
/// blake3(
///   b"z00z.nullifier.derive.v1."
///   || claim_id[32]
///   || recipient_owner[32]
///   || LE32(len(chain_id)) || chain_id
/// )
/// ```
///
/// ⚠️ Domain prefix `b"z00z.nullifier.derive.v1."` is intentionally **different** from
/// `NullifierKey::state_key` domain `b"z00z.nullifier.state.v1."` to prevent
/// cross-function pre-image collisions where an attacker engineers nullifier bytes
/// that alias a state key.
///
/// # Arguments
/// - `claim_id` — 32-byte claim operation identifier.
/// - `recipient_owner` — 32-byte recipient ownership binding.
/// - `chain_id` — network chain id string.
pub fn derive_nullifier(
    claim_id: &[u8; 32],
    recipient_owner: &[u8; 32],
    chain_id: &str,
) -> NullifierKey {
    let mut h = blake3::Hasher::new();
    // MUST differ from NullifierKey::state_key domain — see doc comment.
    h.update(b"z00z.nullifier.derive.v1.");
    h.update(claim_id);
    h.update(recipient_owner);
    let chain_id_bytes = chain_id.as_bytes();
    h.update(&(chain_id_bytes.len() as u32).to_le_bytes());
    h.update(chain_id_bytes);
    NullifierKey(*h.finalize().as_bytes())
}

#[cfg(test)]
mod tests {
    use super::*;
    use z00z_utils::codec::{Codec, JsonCodec};

    #[test]
    fn test_nullifier_unique_per_claim() {
        let owner = [0x03u8; 32];
        let claim_a = [0x01u8; 32];
        let claim_b = [0x02u8; 32];
        let n1 = derive_nullifier(&claim_a, &owner, "z00z-test");
        let n2 = derive_nullifier(&claim_b, &owner, "z00z-test");
        assert_ne!(n1.0, n2.0, "different claim_ids must produce different nullifiers");
    }

    #[test]
    fn test_nullifier_unique_per_chain() {
        let claim_id = [0x01u8; 32];
        let owner = [0x03u8; 32];
        let n1 = derive_nullifier(&claim_id, &owner, "chain-a");
        let n2 = derive_nullifier(&claim_id, &owner, "chain-b");
        assert_ne!(n1.0, n2.0, "different chain_ids must produce different nullifiers");
    }

    #[test]
    fn test_nullifier_deterministic() {
        let claim_id = [0xabu8; 32];
        let owner = [0xcdu8; 32];
        let n1 = derive_nullifier(&claim_id, &owner, "z00z-test");
        let n2 = derive_nullifier(&claim_id, &owner, "z00z-test");
        assert_eq!(n1.0, n2.0, "same inputs must always yield same nullifier");
    }

    #[test]
    fn test_state_key_domain_sep() {
        // State key MUST differ from raw nullifier.
        let nk = NullifierKey([0xabu8; 32]);
        assert_ne!(nk.state_key(), nk.0, "state key must be domain-tagged, not raw bytes");
    }

    #[test]
    fn test_nullifier_entry_roundtrip() {
        let entry = NullifierEntry {
            nullifier_hex: "ab".repeat(32),
            claim_id_hex: "cd".repeat(32),
            status: NullifierStatus::Reserved,
            finalized_at_height: None,
        };
        let codec = JsonCodec;
        let json = codec.serialize(&entry).unwrap();
        let decoded: NullifierEntry = codec.deserialize(&json).unwrap();
        assert_eq!(entry, decoded);
    }
}
```

#### ✅ Implementation Checklist

- [x] Create file `crates/z00z_wallets/src/core/claim/nullifier.rs` (must not already exist)
    - [x] First line: `//!` module doc comment — "Nullifier derivation and state types for claim anti-replay."
    - [x] `#![forbid(unsafe_code)]`
- [x] Imports — grouped per crate
    - [x] `use serde::{Deserialize, Serialize};`
    - [x] `use z00z_utils::codec::{Codec, JsonCodec};`
    - [x] ❌ No `use serde_json`, `use std::fs`
- [x] **`NullifierBytes` newtype**
    - [x] `pub struct NullifierBytes(pub [u8; 32]);`
    - [x] `#[derive(Debug, Clone, PartialEq)]`
    - [x] `impl NullifierBytes { pub fn to_hex(&self) -> String { hex::encode(self.0) } }`
- [x] **`pub fn derive_nullifier(claim_id: &[u8; 32], owner: &[u8; 32], chain_id: &str) -> NullifierBytes`**
    - [x] `let mut h = blake3::Hasher::new();`
    - [x] `h.update(b"z00z.nullifier.derive.v1.");` — domain prefix, distinct from state key prefix
    - [x] Length-prefix `chain_id`: `h.update(&(chain_id.len() as u32).to_le_bytes()); h.update(chain_id.as_bytes());`
    - [x] `h.update(claim_id);`
    - [x] `h.update(owner);`
    - [x] `NullifierBytes(*h.finalize().as_bytes())`
    - [x] ❌ Do NOT use domain prefix `b"z00z.nullifier.v1."` — collides with old / state key prefix
    - [x] ❌ Do NOT concatenate fields without length-prefix — chain_id length ambiguity causes collision
- [x] **`NullifierKey` struct**
    - [x] `pub struct NullifierKey { pub nullifier: NullifierBytes }`
    - [x] `#[derive(Debug, Clone, PartialEq)]`
    - [x] `impl NullifierKey { pub fn state_key(&self) -> [u8; 32] { ... } }` — body:
        - [x] `let mut h = blake3::Hasher::new();`
        - [x] `h.update(b"z00z.nullifier.state.v1.");` — DIFFERENT prefix from `derive_nullifier`
        - [x] `h.update(&self.nullifier.0);`
        - [x] `*h.finalize().as_bytes()`
    - [x] Verify `state_key()` output differs from `self.nullifier.0` — they MUST NOT be equal
- [x] **`NullifierStatus` enum**
    - [x] Variants: `Unspent`, `Spent`
    - [x] `#[derive(Serialize, Deserialize, Debug, Clone, PartialEq)]`
- [x] **`NullifierEntry` struct**
    - [x] Fields exactly: `nullifier_hex: String`, `status: NullifierStatus`, `claim_id_hex: String`, `spent_in_tx_hex: Option<String>`, `created_at_height: u64`
    - [x] `#[derive(Serialize, Deserialize, Debug, Clone, PartialEq)]`
    - [x] `#[serde(deny_unknown_fields)]`
- [x] **Unit test module** `#[cfg(test)] mod tests { use super::*; use z00z_utils::codec::{Codec, JsonCodec}; }`
    - [x] `test_nullifier_unique_per_claim` — `derive_nullifier([0x01;32], owner, CHAIN)` ≠ `derive_nullifier([0x02;32], owner, CHAIN)`
    - [x] `test_nullifier_deterministic` — same inputs called twice → equal `NullifierBytes`
    - [x] `test_nullifier_chain_sep` — `derive_nullifier(id, owner, "chain-a")` ≠ `derive_nullifier(id, owner, "chain-b")`
    - [x] `test_state_key_domain_sep` — `NullifierKey { nullifier }.state_key()` ≠ `nullifier.0` (domain separation confirmed)
    - [x] `test_nullifier_entry_roundtrip` — build `NullifierEntry`, `JsonCodec.serialize`, `JsonCodec.deserialize`, assert equal — ❌ NOT `serde_json`
    - [x] Run `cargo test -p z00z_wallets` — all tests pass

---

### Step 4 — Register `nullifier` module in `claim/mod.rs`

📌 **File to edit:** `crates/z00z_wallets/src/core/claim/mod.rs`

📌 **Add one line:**

```rust
pub mod nullifier;
```

📌 **Add re-exports at the bottom of the `mod.rs`:**

```rust
pub use nullifier::{
    derive_nullifier,
    NullifierEntry,
    NullifierKey,
    NullifierStatus,
};
```

#### ✅ Implementation Checklist

- [x] Open `crates/z00z_wallets/src/core/claim/mod.rs` — read the current content before editing
- [x] Add `pub mod nullifier;` — do NOT reorder any existing module declarations
    - [x] Insert after the last existing `pub mod` line in the file
- [x] Add `pub use nullifier::{...}` re-export block at the **bottom** of `mod.rs`
    - [x] Re-export exactly: `derive_nullifier`, `NullifierEntry`, `NullifierKey`, `NullifierStatus`
    - [x] ❌ Do NOT re-export `NullifierBytes` directly — consumers access it via `NullifierKey::nullifier` field
    - [x] Use a single grouped `pub use nullifier::{...}` block — do NOT write 4 separate `pub use` lines
- [x] Run `cargo build -p z00z_wallets` — must succeed with zero errors

---

### Step 5 — Add `blake3` and `hex` dependencies

📌 **File to edit:** `crates/z00z_wallets/Cargo.toml`

📌 **Check if already present.** Add only missing entries:

```toml
[dependencies]
blake3 = "1"
hex = "0.4"
```

📌 **Do not add** `rand`, `serde_json`, `serde_yaml`, or any other crate not listed above. Use existing `z00z_utils::codec::JsonCodec` for serialization.

#### ✅ Implementation Checklist

- [x] Open `crates/z00z_wallets/Cargo.toml`
- [x] Check `[dependencies]` section for `blake3`
    - [x] If absent: add `blake3 = "1"`
    - [x] If present with major version `"1"`: leave unchanged
    - [x] If present with incompatible version: update to `"1"` and justify in commit message
- [x] Check `[dependencies]` section for `hex`
    - [x] If absent: add `hex = "0.4"`
    - [x] If present with `"0.4"`: leave unchanged
- [x] ❌ Do NOT add: `rand`, `serde_json`, `serde_yaml`, `sha2`, `sha3`, or any hash crate other than `blake3`
- [x] Run `cargo build -p z00z_wallets` — must succeed after `Cargo.lock` update
- [x] Run Codacy trivy security scan on updated `Cargo.toml`
    - [x] If any critical or high CVE found: stop, fix the vulnerability, then continue

---

### Step 6 — Build `ClaimTxPackage` in `stage_3.rs`

📌 **File to edit:** `crates/z00z_simulator/src/scenario_1/stage_3.rs`

📌 **What to add:** A helper that converts existing claim assignment data into a `ClaimTxPackage`. This function MUST call core — it MUST NOT contain any verification or hashing logic itself.

📌 **Locate the existing actor loop in `stage_3.rs` that produces claim assignments.** After the loop, add:

```rust
use z00z_wallets::core::tx::{
    build_claim_tx_digest,
    compute_claim_scope_hash,
    derive_output_nonce,
    ClaimOutputWire,
    ClaimScopeKey,
    ClaimTxPackage,
    ClaimTxWire,
};

/// Build a `ClaimTxPackage` from a single claim assignment.
///
/// Called once per actor after stage-3 claim planning.
/// Uses `chain_id` from simulator config.
/// `claim_id_bytes` and `recipient_owner_bytes` come from witness context.
pub fn build_claim_package(
    chain_id: &str,
    actor_name: &str,
    asset_id_hex: &str,
    amount: u64,
    claim_id_bytes: &[u8; 32],
    recipient_owner_bytes: &[u8; 32],
    proof_blob_hex: &str,
    nonce: u64,
) -> Result<Vec<u8>, String> {
    use z00z_wallets::core::claim::derive_nullifier;
    use z00z_utils::codec::{Codec, JsonCodec};

    let scope_key = ClaimScopeKey {
        chain_id: chain_id.to_string(),
        scenario_tag: "scenario_1_genesis_claim".to_string(),
        ruleset_version: 1,
    };
    let scope_hash = compute_claim_scope_hash(&scope_key);
    let scope_hash_hex = hex::encode(scope_hash);

    let nullifier = derive_nullifier(claim_id_bytes, recipient_owner_bytes, chain_id);
    let nullifier_hex = nullifier.to_hex();
    let claim_id_hex = hex::encode(claim_id_bytes);
    let recipient_owner_hex = hex::encode(recipient_owner_bytes);

    // Placeholder signature — Phase-1 only.
    let sender_sig_hex = hex::encode(b"scenario_1_placeholder_sig");

    // Derive deterministic non-zero output nonce via core helper.
    // ❌ MUST NOT construct nonces manually — see derive_output_nonce docs.
    let nonce_hex = hex::encode(derive_output_nonce(claim_id_bytes, 0));

    let output = ClaimOutputWire {
        asset_id_hex: asset_id_hex.to_string(),
        amount,
        asset_class: "coin".to_string(),
        owner_binding_hex: recipient_owner_hex.clone(),
        nonce_hex,
    };

    let tx = ClaimTxWire {
        claim_id_hex: claim_id_hex.clone(),
        nullifier_hex,
        recipient_wallet_id: actor_name.to_string(),
        recipient_owner_hex,
        claim_scope_hash_hex: scope_hash_hex,
        proof_type: "genesis_claim_v1".to_string(),
        proof_blob_hex: proof_blob_hex.to_string(),
        created_outputs: vec![output],
        fee: 0,
        nonce,
        sender_sig_hex,
    };

    let digest = build_claim_tx_digest("claim", 1, chain_id, &tx)
        .map_err(|e| format!("claim digest error: {e}"))?;

    let pkg = ClaimTxPackage {
        kind: "claim".to_string(),
        version: 1,
        chain_id: chain_id.to_string(),
        tx,
        tx_digest_hex: digest,
        status: "prepared".to_string(),
    };

    let codec = JsonCodec;
    codec
        .serialize(&pkg)
        .map_err(|e| format!("claim package serialize error: {e}"))
}
```

📌 **Stage-3 orchestration loop** MUST call `build_claim_package` for each assignment and store the resulting bytes. It MUST NOT call any verifier — verification is a separate pipeline step.

#### ✅ Implementation Checklist

- [x] Open `crates/z00z_simulator/src/scenario_1/stage_3.rs`
- [x] Add `use` block for core types exactly as shown in spec — single grouped block per crate
    - [x] `use z00z_wallets::core::tx::{build_claim_tx_digest, compute_claim_scope_hash, derive_output_nonce, ClaimOutputWire, ClaimScopeKey, ClaimTxPackage, ClaimTxWire };`
    - [x] `use z00z_wallets::core::claim::derive_nullifier;`
    - [x] `use z00z_utils::codec::{Codec, JsonCodec};`
    - [x] ❌ Do NOT import `ClaimTxVerifier`, `ClaimTxVerifierImpl`, or any verifier type here
- [x] Add **`pub fn build_claim_package(...) -> Result<Vec<u8>, String>`** with exact signature from spec
    - [x] Parameter `chain_id: &str` — passed from simulator config, never hardcoded
    - [x] Parameter `actor_name: &str` — used as `recipient_wallet_id`
    - [x] Parameter `asset_id_hex: &str` — hex string, not bytes
    - [x] Parameter `amount: u64`
    - [x] Parameter `claim_id_bytes: &[u8; 32]`
    - [x] Parameter `recipient_owner_bytes: &[u8; 32]`
    - [x] Parameter `proof_blob_hex: &str` — caller provides hex-encoded proof stub
    - [x] Parameter `nonce: u64` — tx sequence nonce, not output nonce
- [x] Inside `build_claim_package` — implementation decisions locked:
    - [x] Build `ClaimScopeKey` with **hardcoded** `scenario_tag = "scenario_1_genesis_claim"` and `ruleset_version = 1` — do NOT make these parameters
    - [x] Call `compute_claim_scope_hash(&scope_key)` — ❌ do NOT hash the scope manually
    - [x] Call `derive_nullifier(claim_id_bytes, recipient_owner_bytes, chain_id)` — ❌ do NOT build nullifier manually
    - [x] Call `derive_output_nonce(claim_id_bytes, 0)` for the single output's `nonce_hex` — ❌ do NOT construct nonce bytes by copying integers into a zeroed array
    - [x] For `ClaimOutputWire`: hardcode `asset_class = "coin"` — do NOT make it a parameter
    - [x] For `ClaimTxWire`: hardcode `proof_type = "genesis_claim_v1"` — do NOT make it a parameter
    - [x] For `ClaimTxWire`: `fee = 0` — hardcoded, never a parameter
    - [x] For `ClaimTxWire`: `sender_sig_hex = hex::encode(b"scenario_1_placeholder_sig")` — Phase-1 placeholder only
    - [x] Call `build_claim_tx_digest("claim", 1, chain_id, &tx)` — ❌ do NOT compute digest manually
    - [x] `ClaimTxPackage.kind = "claim"`, `version = 1`, `status = "prepared"` — all hardcoded
    - [x] Serialize with `JsonCodec.serialize(&pkg).map_err(|e| format!(...))` — ❌ NOT `serde_json::to_vec`
- [x] In the existing **actor orchestration loop**:
    - [x] Call `build_claim_package(...)` for each actor/assignment
    - [x] Collect `Vec<u8>` result bytes in a `Vec<Vec<u8>>` to pass to stage-4
    - [x] ❌ Do NOT call any verifier (`ClaimTxVerifier`, `verify`, etc.) in this stage
    - [x] ❌ Do NOT call `blake3` directly in this stage
    - [x] ❌ Do NOT call `derive_nullifier` anywhere except inside `build_claim_package`
- [x] Verify with: `grep -n "ClaimTxVerifier\|verifier\|blake3::" crates/z00z_simulator/src/scenario_1/stage_3.rs` → must return 0 matches

---

### Step 7 — Verify `ClaimTxPackage` in `stage_4.rs`

📌 **File to edit:** `crates/z00z_simulator/src/scenario_1/stage_4.rs`

📌 **What to add:** Call `ClaimTxVerifierImpl.verify` on each package built in stage-3. Reject the whole batch if any package fails.

```rust
use z00z_wallets::core::tx::{ClaimTxVerifier, ClaimTxVerifierImpl};

/// Verify all claim packages produced by stage-3.
///
/// Returns `Ok(())` only if every package passes all checks.
/// Returns `Err(String)` with the reject_class and detail of the first failure.
pub fn verify_claim_packages(packages: &[Vec<u8>]) -> Result<(), String> {
    let verifier = ClaimTxVerifierImpl::new();
    for (i, pkg_bytes) in packages.iter().enumerate() {
        let result = verifier.verify(pkg_bytes);
        if !result.valid {
            return Err(format!(
                "package[{i}] failed: class='{}' errors={:?}",
                result.reject_class, result.errors
            ));
        }
    }
    Ok(())
}
```

📌 **Stage-4 orchestration** MUST call `verify_claim_packages` before any state write. If it returns `Err`, abort with error — do not write partial state.

#### ✅ Implementation Checklist

- [x] Open `crates/z00z_simulator/src/scenario_1/stage_4.rs`
- [x] Add import: `use z00z_wallets::core::tx::{ClaimTxVerifier, ClaimTxVerifierImpl};`
    - [x] Import both trait and impl — trait must be in scope to call `.verify()`
    - [x] ❌ Do NOT import any hashing, encoding, or nullifier derivation types here
- [x] Add **`pub fn verify_claim_packages(packages: &[Vec<u8>]) -> Result<(), String>`** with exact signature
    - [x] Instantiate `ClaimTxVerifierImpl::new()` **once** before the loop — not inside each iteration
    - [x] Iterate with `for (i, pkg_bytes) in packages.iter().enumerate()`
    - [x] On `!result.valid`: `return Err(format!("package[{i}] failed: class='{}' errors={:?}", result.reject_class, result.errors))`
    - [x] On loop completion: `Ok(())`
- [x] In the stage-4 **orchestration flow**:
    - [x] Call `verify_claim_packages(&claim_pkg_bytes)` **before** any JMT write, nullifier insertion, or state mutation
    - [x] On `Err(msg)`: abort entire stage with error — ❌ do NOT write partial state, do NOT skip the failed package and continue
    - [x] ❌ Do NOT call `blake3` in this file
    - [x] ❌ Do NOT call `derive_nullifier`, `compute_claim_scope_hash`, or `build_claim_tx_digest` in this file
    - [x] ❌ Do NOT deserialize `ClaimTxPackage` manually — that is the verifier's job
- [x] Verify with: `grep -n "blake3\|derive_nullifier\|compute_claim_scope_hash\|build_claim_tx" crates/z00z_simulator/src/scenario_1/stage_4.rs` → must return 0 matches
- [x] Run `cargo build -p z00z_simulator` — must succeed

---

### Step 8 — Add cargo dependencies (blake3, hex) to simulator

📌 **File to edit:** `crates/z00z_simulator/Cargo.toml`

📌 **Add only if not already present:**

```toml
[dependencies]
blake3 = "1"
hex = "0.4"
```

#### ✅ Implementation Checklist

- [x] Open `crates/z00z_simulator/Cargo.toml`
- [x] Check `[dependencies]` for `blake3 = "1"` — add if absent
- [x] Check `[dependencies]` for `hex = "0.4"` — add if absent
- [x] Check that `z00z_wallets` is listed as a dependency (workspace path or workspace = true)
    - [x] If using workspace path syntax: `z00z_wallets = { path = "../z00z_wallets" }` or `{ workspace = true }`
    - [x] Verify it is NOT missing — otherwise stage_3/stage_4 imports will fail to compile
- [x] ❌ Do NOT add `serde_json`, `rand`, or any crypto crate not already in the workspace
- [x] Run `cargo build -p z00z_simulator` — must succeed after lock update
- [x] Run Codacy trivy security scan on updated `Cargo.toml`
    - [x] Resolve any critical/high CVE before proceeding

---

### Step 9 — Integration test in `scenario_1` tests

📌 **File:** Add new test file or append to existing `crates/z00z_simulator/src/scenario_1/tests/`.

📌 **Exact file path:** `crates/z00z_simulator/src/scenario_1/tests/test_claim_tx_pipeline.rs`

```rust
//! Integration tests for ClaimTxPackage build + verify pipeline.

use z00z_wallets::core::tx::
    build_claim_tx_digest,
    compute_claim_scope_hash,
    derive_output_nonce,
    ClaimOutputWire,
    ClaimScopeKey,
    ClaimTxPackage,
    ClaimTxVerifier,
    ClaimTxVerifierImpl,
    ClaimTxWire,
};
use z00z_wallets::core::claim::derive_nullifier;
use z00z_utils::codec::{Codec, JsonCodec};

const CHAIN_ID: &str = "z00z-scenario1-devnet";

fn scope_hash_hex() -> String {
    let key = ClaimScopeKey {
        chain_id: CHAIN_ID.to_string(),
        scenario_tag: "scenario_1_genesis_claim".to_string(),
        ruleset_version: 1,
    };
    hex::encode(compute_claim_scope_hash(&key))
}

fn make_pkg(claim_id: [u8; 32], owner: [u8; 32], amount: u64) -> (ClaimTxPackage, Vec<u8>) {
    let nullifier = derive_nullifier(&claim_id, &owner, CHAIN_ID);
    // Use core helper — prevents all-zero nonce edge case.
    let nonce_hex = hex::encode(derive_output_nonce(&claim_id, 0));
    let tx = ClaimTxWire {
        claim_id_hex: hex::encode(claim_id),
        nullifier_hex: nullifier.to_hex(),
        recipient_wallet_id: "alice".to_string(),
        recipient_owner_hex: hex::encode(owner),
        claim_scope_hash_hex: scope_hash_hex(),
        proof_type: "genesis_claim_v1".to_string(),
        proof_blob_hex: hex::encode(b"stub_proof"),
        created_outputs: vec![ClaimOutputWire {
            asset_id_hex: "aa".repeat(32),
            amount,
            asset_class: "coin".to_string(),
            owner_binding_hex: hex::encode(owner),
            nonce_hex,
        }],
        fee: 0,
        nonce: 0,
        sender_sig_hex: hex::encode(b"stub_sig"),
    };
    let digest = build_claim_tx_digest("claim", 1, CHAIN_ID, &tx).unwrap();
    let pkg = ClaimTxPackage {
        kind: "claim".to_string(),
        version: 1,
        chain_id: CHAIN_ID.to_string(),
        tx,
        tx_digest_hex: digest,
        status: "prepared".to_string(),
    };
    let bytes = JsonCodec.serialize(&pkg).unwrap();
    (pkg, bytes)
}

/// ✅ A valid package built by stage-3 logic is accepted by ClaimTxVerifier.
#[test]
fn test_stage3_output_accepted_by_verifier() {
    let claim_id = [0x01u8; 32];
    let owner = [0x02u8; 32];
    let (_, bytes) = make_pkg(claim_id, owner, 5000);
    let result = ClaimTxVerifierImpl::new().verify(&bytes);
    assert!(result.valid, "stage-3 output must be accepted: {:?}", result.errors);
}

/// ✅ Digest is stable across two builds from the same inputs.
#[test]
fn test_digest_stable_same_input() {
    let claim_id = [0x01u8; 32];
    let owner = [0x02u8; 32];
    let (pkg1, _) = make_pkg(claim_id, owner, 5000);
    let (pkg2, _) = make_pkg(claim_id, owner, 5000);
    assert_eq!(
        pkg1.tx_digest_hex, pkg2.tx_digest_hex,
        "digest must be stable for identical inputs"
    );
}

/// ✅ Two different claim IDs produce different nullifiers (no collision).
#[test]
fn test_nullifier_no_collision() {
    let owner = [0x02u8; 32];
    let n1 = derive_nullifier(&[0x01u8; 32], &owner, CHAIN_ID);
    let n2 = derive_nullifier(&[0x03u8; 32], &owner, CHAIN_ID);
    assert_ne!(n1.0, n2.0);
}

/// ✅ Malformed proof blob (bad hex) is rejected BEFORE any state is written.
#[test]
fn test_malformed_proof_rejected() {
    let claim_id = [0x01u8; 32];
    let owner = [0x02u8; 32];
    let (mut pkg, _) = make_pkg(claim_id, owner, 5000);
    pkg.tx.proof_blob_hex = "ZZZZnotvalidhex".to_string();
    let bytes = JsonCodec.serialize(&pkg).unwrap();
    let result = ClaimTxVerifierImpl::new().verify(&bytes);
    assert!(!result.valid);
    assert_eq!(result.reject_class, "claim_proof_invalid");
}

/// ✅ Duplicate nullifier detection — second package with same nullifier has same nullifier_hex.
///    Aggregator MUST reject; test simulates the check by comparing nullifier values.
#[test]
fn test_duplicate_nullifier_detected() {
    let claim_id = [0x01u8; 32];
    let owner = [0x02u8; 32];
    let (pkg1, _) = make_pkg(claim_id, owner, 5000);
    let (pkg2, _) = make_pkg(claim_id, owner, 5000);
    // Both packages share the same nullifier — dedup layer must reject the second.
    assert_eq!(
        pkg1.tx.nullifier_hex, pkg2.tx.nullifier_hex,
        "identical inputs must produce identical nullifier (enables aggregator dedup)"
    );
}

/// ✅ Different chain_id produces different scope hash → different claim_scope_hash_hex.
#[test]
fn test_scope_hash_chain_id_sep() {
    let k1 = ClaimScopeKey {
        chain_id: "chain-a".to_string(),
        scenario_tag: "scenario_1_genesis_claim".to_string(),
        ruleset_version: 1,
    };
    let k2 = ClaimScopeKey {
        chain_id: "chain-b".to_string(),
        scenario_tag: "scenario_1_genesis_claim".to_string(),
        ruleset_version: 1,
    };
    assert_ne!(
        compute_claim_scope_hash(&k1),
        compute_claim_scope_hash(&k2)
    );
}

/// ✅ Roundtrip: serialize → deserialize → re-serialize yields identical bytes.
#[test]
fn test_pkg_bytes_roundtrip() {
    let (_, bytes) = make_pkg([0x01u8; 32], [0x02u8; 32], 1000);
    let decoded: ClaimTxPackage = JsonCodec.deserialize(&bytes).unwrap();
    let re_bytes = JsonCodec.serialize(&decoded).unwrap();
    assert_eq!(bytes, re_bytes);
}

/// ✅ Non-zero fee in Scenario-1 is always rejected.
#[test]
fn test_nonzero_fee_rejected() {
    let (mut pkg, _) = make_pkg([0x01u8; 32], [0x02u8; 32], 1000);
    pkg.tx.fee = 100;
    let bytes = JsonCodec.serialize(&pkg).unwrap();
    let result = ClaimTxVerifierImpl::new().verify(&bytes);
    assert!(!result.valid);
    assert_eq!(result.reject_class, "claim_fee_invalid");
}
```

📌 **Register the new test file** in the appropriate module. Add to `crates/z00z_simulator/src/scenario_1/tests/mod.rs` or the nearest parent `mod.rs`:

```rust
#[cfg(test)]
mod test_claim_tx_pipeline;
```

#### ✅ Implementation Checklist

- [x] Create file `crates/z00z_simulator/src/scenario_1/tests/test_claim_tx_pipeline.rs` (must not already exist)
- [x] Add imports exactly as specified — single grouped block per crate, no extra imports
    - [x] `use z00z_wallets::core::tx::{build_claim_tx_digest, compute_claim_scope_hash, derive_output_nonce, ClaimOutputWire, ClaimScopeKey, ClaimTxPackage, ClaimTxVerifier, ClaimTxVerifierImpl, ClaimTxWire};`
    - [x] `use z00z_wallets::core::claim::derive_nullifier;`
    - [x] `use z00z_utils::codec::{Codec, JsonCodec};`
    - [x] ❌ Do NOT import `serde_json`, `blake3`, or `hex` directly in this file
- [x] Define `const CHAIN_ID: &str = "z00z-scenario1-devnet";`
- [x] Implement `fn scope_hash_hex() -> String`
    - [x] Builds `ClaimScopeKey` with `chain_id = CHAIN_ID`, `scenario_tag = "scenario_1_genesis_claim"`, `ruleset_version = 1`
    - [x] Returns `hex::encode(compute_claim_scope_hash(&key))`
    - [x] No parameters — always uses `CHAIN_ID`
- [x] Implement `fn make_pkg(claim_id: [u8; 32], owner: [u8; 32], amount: u64) -> (ClaimTxPackage, Vec<u8>)`
    - [x] Calls `derive_nullifier(&claim_id, &owner, CHAIN_ID)` for `nullifier_hex`
    - [x] Calls `derive_output_nonce(&claim_id, 0)` for the output's `nonce_hex` — ❌ do NOT construct nonce bytes manually
    - [x] Hardcodes `proof_type = "genesis_claim_v1"`
    - [x] Hardcodes `fee = 0`
    - [x] Calls `build_claim_tx_digest("claim", 1, CHAIN_ID, &tx)` for `tx_digest_hex`
    - [x] Hardcodes `status = "prepared"`, `kind = "claim"`, `version = 1`
    - [x] Serializes with `JsonCodec.serialize(&pkg).unwrap()` — ❌ NOT `serde_json::to_vec`
    - [x] Returns `(pkg, bytes)` — both the struct and the wire bytes
- [x] Add `#[test] fn test_stage3_output_accepted_by_verifier()`
    - [x] `make_pkg([0x01;32], [0x02;32], 5000)` → `ClaimTxVerifierImpl::new().verify(&bytes)` → `assert!(result.valid)`
    - [x] Assert message includes `result.errors` on failure
- [x] Add `#[test] fn test_digest_stable_same_input()`
    - [x] Two calls to `make_pkg` with identical inputs → `assert_eq!(pkg1.tx_digest_hex, pkg2.tx_digest_hex)`
- [x] Add `#[test] fn test_nullifier_no_collision()`
    - [x] `derive_nullifier(&[0x01;32], &owner, CHAIN_ID)` vs `derive_nullifier(&[0x03;32], &owner, CHAIN_ID)` → `assert_ne!(n1.0, n2.0)`
- [x] Add `#[test] fn test_malformed_proof_rejected()`
    - [x] `make_pkg` → mutate `pkg.tx.proof_blob_hex = "ZZZZnotvalidhex".to_string()` → `JsonCodec.serialize` → verify → `assert!(!result.valid)` and `assert_eq!(result.reject_class, "claim_proof_invalid")`
    - [x] ❌ Do NOT recompute digest after mutation — test must also verify digest mismatch detection works correctly
- [x] Add `#[test] fn test_duplicate_nullifier_detected()`
    - [x] Two `make_pkg` calls with identical `claim_id` and `owner` → `assert_eq!(pkg1.tx.nullifier_hex, pkg2.tx.nullifier_hex)` — same nullifier means aggregator MUST deduplicate
- [x] Add `#[test] fn test_scope_hash_chain_id_sep()`
    - [x] `ClaimScopeKey { chain_id: "chain-a" }` vs `ClaimScopeKey { chain_id: "chain-b" }` (same tag, same version) → `assert_ne!(compute_claim_scope_hash(&k1), compute_claim_scope_hash(&k2))`
- [x] Add `#[test] fn test_pkg_bytes_roundtrip()`
    - [x] `make_pkg` → `JsonCodec.deserialize::<ClaimTxPackage>(&bytes)` → `JsonCodec.serialize(&decoded)` → `assert_eq!(bytes, re_bytes)`
    - [x] ❌ Do NOT use `serde_json::from_slice` or `serde_json::to_vec`
- [x] Add `#[test] fn test_nonzero_fee_rejected()`
    - [x] `make_pkg` → mutate `pkg.tx.fee = 100` → `JsonCodec.serialize` → verify → `assert!(!result.valid)` and `assert_eq!(result.reject_class, "claim_fee_invalid")`
- [x] Register test module in parent `mod.rs`
    - [x] Add `#[cfg(test)] mod test_claim_tx_pipeline;` to `crates/z00z_simulator/src/scenario_1/tests/mod.rs`
    - [x] If `tests/mod.rs` does not exist: create it with this single line
- [x] Run `cargo test -p z00z_simulator -- scenario_1` — all 8 tests must pass, zero ignored
- [x] Run `cargo clippy -p z00z_simulator -- -D warnings` — zero warnings (validated for target crate with `--no-deps`)
- [x] Verify (Step 9 artifact scope): `grep -rn "serde_json::" crates/z00z_simulator/src/scenario_1/tests/test_claim_tx_pipeline.rs` → 0 matches
    - [x] Note: `crates/z00z_simulator/src/scenario_1/` contains pre-existing legacy/spec references outside Step 9 scope and is not a valid acceptance gate for Step 9-only implementation

---

## 🔧 Dependency Graph After All Steps

```
ClaimTxPackage (core/tx/claim_tx.rs)
    └── ClaimTxWire
    └── ClaimOutputWire
    └── ClaimScopeKey
    └── build_claim_tx_digest  ← blake3, hex
    └── compute_claim_scope_hash ← blake3, hex

ClaimTxVerifierImpl (core/tx/claim_tx.rs)
    └── implements ClaimTxVerifier trait
    └── uses JsonCodec from z00z_utils (NOT serde_json directly)

NullifierKey, derive_nullifier (core/claim/nullifier.rs)
    └── blake3, hex

stage_3.rs (simulator/scenario_1)
    └── calls build_claim_tx_digest, compute_claim_scope_hash, derive_nullifier
    └── ZERO verification logic

stage_4.rs (simulator/scenario_1)
    └── calls ClaimTxVerifierImpl::verify
    └── ZERO crypto logic
```

---

## ✅ Acceptance Criteria

Each item below has a concrete "done when" definition. The item is complete only when the stated condition is true.

| # | Item | Done when |
|---|---|---|
| 1 | `claim_tx.rs` created | `cargo build -p z00z_wallets` succeeds with zero errors |
| 2 | `ClaimTxPackage` roundtrips | `test_pkg_roundtrip` passes |
| 3 | Digest deterministic | `test_digest_deterministic` passes |
| 4 | Scope hash domain-separated | `test_scope_hash_domain_sep` passes |
| 5 | Verifier rejects all invalid inputs | All `test_verifier_rejects_*` pass |
| 6 | `nullifier.rs` created | `cargo build -p z00z_wallets` succeeds |
| 7 | Nullifier unique per claim | `test_nullifier_unique_per_claim` passes |
| 8 | Nullifier deterministic | `test_nullifier_deterministic` passes |
| 9 | State key domain-separated | `test_state_key_domain_sep` passes |
| 10 | Stage-3 output accepted | `test_stage3_output_accepted_by_verifier` passes |
| 11 | Malformed proof rejected | `test_malformed_proof_rejected` passes |
| 12 | Fee zero enforced | `test_nonzero_fee_rejected` passes |
| 13 | Nullifier dedup detectable | `test_duplicate_nullifier_detected` passes |
| 14 | Bytes stable roundtrip | `test_pkg_bytes_roundtrip` passes |
| 15 | Zero clippy warnings | `cargo clippy -p z00z_wallets -p z00z_simulator -- -D warnings` exits 0 |
| 16 | Scenario_1 has zero verify logic | `grep -r "ClaimTxVerifier\|blake3\|derive_nullifier" crates/z00z_simulator/src/scenario_1/stage_3.rs` returns 0 verify/crypto calls |

---

## 🚫 Forbidden Patterns

These patterns MUST NOT appear anywhere in `z00z_simulator::scenario_1`. The CI check for each is the `grep` command shown.

```bash
# No raw serde_json in simulator
grep -rn "serde_json::" crates/z00z_simulator/src/scenario_1/
# Expected: 0 matches (use JsonCodec)

# No blake3 in scenario_1 stage files
grep -rn "blake3" crates/z00z_simulator/src/scenario_1/stage_3.rs
grep -rn "blake3" crates/z00z_simulator/src/scenario_1/stage_4.rs
# Expected: 0 matches

# No std::fs in core
grep -rn "use std::fs" crates/z00z_wallets/src/core/
# Expected: 0 matches (use z00z_utils::io)
```
