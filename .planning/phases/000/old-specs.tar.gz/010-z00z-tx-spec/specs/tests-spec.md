# Scenario 1 — Test Coverage Specification

**Version:** 1.3.0  
**Date:** 2026-03-01  
**Scope:** Stages 1, 2, 3 of `scenario_1`  
**Branch:** z00z-simul

---

## Revision History

| Version | Date | Changes |
|---------|------|---------|
| 1.0.0 | 2026-02-28 | Initial brainstorm — 37 tests, 3 stages |
| 1.1.0 | 2026-02-28 | Post-review corrections: T1-3/T1-5 unit→integration; T1-10 narrative clarified; T2-4 scope note + priority Medium; T2-8 reframed as regression guard; T2-10 added ByteArray API caveat (no `verify_signature()` on ReceiverCard); T3-2 redesigned to call stage_3 directly (not run_with_paths which re-runs Stage 1 and defeats the guard); T3-7 restricted `amount > 0` to Coin|Token|Nft, excluded Void; NEG-2 replaced non-existent `as_bytes_mut()` with ByteArray-based tamper; NEG-3 added `from_bytes` error-path handling for invalid Ristretto point |
| 1.2.0 | 2026-02-28 | Added exhaustive implementation checklists to all 38 H3 sections (T1-1..T1-10, T2-1..T2-11, T3-1..T3-10, TX-1..TX-4, NEG-1..NEG-3); specified exact file targets, helpers, imports, field names, assertions, and cargo run commands; introduced `cross_stage.rs` test file for TX-1/TX-3/TX-4; no freedom of choice left for developer |
| 1.3.0 | 2026-03-01 | Sync-pass before implementation: refreshed real test inventory; added valid API/signature source-of-truth for Scenario 1; added explicit coverage matrix (`simulator` vs `wallets`) aligned with `claim-spec.md`; clarified current commands and marked planned files as not yet present. |

---

## Legend

| Symbol | Meaning |
|--------|---------|
| ✅ | Already covered by existing test |
| 🔴 | Not covered — high priority |
| 🟡 | Not covered — medium priority |
| 🔵 | Not covered — low / informational |
| `[integration]` | Needs full pipeline run (slow, ~10 min) |
| `[unit]` | Fast, isolated, no cargo subprocess |
| `[property]` | Randomized / exhaustive invariant check |

---

## 🗂️ Existing Tests Inventory

| File | Test Name | Status |
|------|-----------|--------|
| `tests/test_claim_crypto.rs` | `stage3_crypto_ok` | Active — Stage 3 crypto + conservation checks |
| `tests/test_claim_conservation.rs` | `test_stage3_conservation_*` | Active — pure conservation unit checks |
| `tests/test_claim_snapshot.rs` | `test_snapshot_*` | Active — snapshot write/reconcile/run checks |
| `tests/test_claim_resume.rs` | `test_resume_*` | Active — resume/idempotency/state merge checks |
| `tests/cross_wallet_claim.rs` | `test_double_claim_audit_log` | Active — replay/double-claim audit evidence |
| `tests/audit_log_integrity.rs` | `test_audit_log_*` | Active — completeness/no-secrets/reject traceability |

### Wallet claim-security tests (external to simulator)

| File | Test Group | Scope |
|------|------------|-------|
| `crates/z00z_wallets/tests/test_asset_import_security.rs` | `test_import_*` | import gate order, cryptographic rejects, finalize/quarantine path |
| `crates/z00z_wallets/tests/test_asset_ownership_security.rs` | ownership security | wrong-wallet / ownership binding / policy checks |
| `crates/z00z_wallets/tests/test_asset_replay_protection.rs` | replay protection | claim registry anti-replay / anti-double-claim |

---

## 🔗 Sync-Pass Source of Truth (2026-03-01)

### Valid API / Signatures (current code)

- Scenario entrypoint: `runner::run_with_paths(cfg_path, design_path)` in `src/scenario_1/runner.rs`.
- Stage 3 entrypoint: `stage_3::run_claim_genesis(ctx, stage)` in `src/scenario_1/stage_3.rs`.
- Conservation API: `stage_3::verify_claim_conservation(input, imported)`.
- Snapshot APIs: `stage_3::write_snapshot(...)`, `stage_3::reconcile_snapshot(...)`.
- Resume APIs: `merge_claim_state`, `rehydrate_claim_rows`, `verify_resume_wire` in `tests/test_claim_resume.rs` dependencies.
- Claim state artifact: `outputs/genesis/claim_state.json` (resume checkpoints).
- Audit artifact: `outputs/claim/audit_log.json`.

### Invalid / stale references to avoid in new implementation

- `runner::run_stage1_only(...)` is not a stable public API in current `scenario_1::runner`.
- “single file inventory” for Stage 3 (`test_claim_crypto.rs` only) is stale.
- Treat `tests/test_claim_integration.rs` and `tests/cross_stage.rs` as **planned**, not existing.

### Coverage matrix — what is already covered where

| Requirement slice | Simulator tests | Wallet tests |
|---|---|---|
| Stage 3 crypto correctness (`verify_complete`, proof checks, commitment/amount conservation) | ✅ `test_claim_crypto.rs`, `test_claim_conservation.rs` | ✅ `test_asset_import_security.rs` (import gate rejects) |
| Resume safety / idempotency / state merge | ✅ `test_claim_resume.rs` | ✅ `test_asset_replay_protection.rs` (registry semantics) |
| Snapshot reconciliation and invariant checks | ✅ `test_claim_snapshot.rs` | ➖ N/A |
| Double-claim / replay evidence | ✅ `cross_wallet_claim.rs`, `audit_log_integrity.rs` | ✅ `test_asset_replay_protection.rs` |
| Import ownership binding and wrong-wallet rejection | ➖ Indirect in simulator (via Stage 3 outcomes) | ✅ `test_asset_ownership_security.rs` |
| Finalize/quarantine failure path | ➖ Indirect (audit/reject rows) | ✅ `test_asset_import_security.rs` (`test_finalize_fail_quarantine`) |
| CS-13 durable persistence + restart equality | ✅ `test_claim_persist.rs` (`test_claim_persist_restart`, `test_debug_dump_state_match`, `test_stage3_fail_no_persist`) | ✅ `test_asset_import_security.rs` (`test_no_store_reject`, `test_finalize_retry_ok`, `test_finalize_fail_quarantine`) |

### `stage3_crypto_ok` covers (do not duplicate):

- ✅ Full scenario run stages 1-3 passes (`is_ok()`)
- ✅ Stage 3 result == `StageResult::Ok`
- ✅ Stealth fields `r_pub / owner_tag / enc_pack / secret / tag16` == `None` after claim
- ✅ `amount > 0` for `Coin` and `Token` class
- ✅ `range_proof.is_some()` AND `!proof.is_empty()` AND `verify_range_proof(...)` succeeds
- ✅ `asset.verify_complete()` → owner signature + full validation chain
- ✅ `sum(amount, claimed_assets_*.json)` == `sum(amount, imported_assets_full)`
- ✅ `distributed_assets_count == input_assets_count == Σ actor counts`
- ✅ `sum(commitments, claimed)` == `sum(commitments, genesis bins)` (homomorphic)
- ✅ `sum(amounts, claimed)` == `sum(amounts, genesis bins)`

---

## Stage 1 — `genesis_init`

### T1-1 — State Hash Determinism `[unit]`

**Risk:** Non-deterministic genesis breaks reproducibility, CI comparison, and devnet re-bootstrapping.

**Narrative:**  
`compute_genesis_state_hash` must return identical bytes for two consecutive calls on the same
`GenesisAccumulator`. Stage 1 already checks this inline (`state_hash == state_hash_2`), but
this is never verified by an external test — a regression would be silent.

```rust
#[test]
fn stage1_state_hash_is_deterministic() {
    let (cfg, seed, net) = load_devnet_fixture();
    let acc1 = generate_all_genesis_assets(&defs, seed.as_bytes(), net, ..).unwrap();
    let acc2 = generate_all_genesis_assets(&defs, seed.as_bytes(), net, ..).unwrap();
    assert_eq!(
        compute_genesis_state_hash(&acc1),
        compute_genesis_state_hash(&acc2),
        "state hash must be deterministic for same config + seed",
    );
}
```

**Implementation Checklist:**

- [x] **File**: `crates/z00z_simulator/tests/stage1_unit.rs` — create if not exists
- [x] **Cargo.toml** `[dev-dependencies]` for `z00z_simulator`:
  - [x] `z00z_core = { path = "../z00z_core" }`
  - [x] `z00z_utils = { path = "../z00z_utils" }`
- [x] **Imports at top of file**:
  ```rust
  use z00z_core::genesis::{
      compute_genesis_state_hash, create_asset_definition,
      generate_all_genesis_assets, load_genesis_config, GenesisSeed,
  };
  use z00z_core::chain::ChainType;
  use z00z_utils::{logger::NoopLogger, metrics::NoopMetrics};
  use std::sync::Arc;
  ```
- [x] **Shared fixture** — implement once at file top, used by T1-1, T1-2, T1-4:
  ```rust
  fn load_devnet_fixture() -> (GenesisConfig, GenesisSeed, ChainType) {
      let cfg = load_genesis_config(
          "crates/z00z_core/src/genesis/genesis_config_devnet.yaml"
      ).unwrap();
      let seed = GenesisSeed::from_config(&cfg).unwrap();
      let net  = ChainType::from_str(&cfg.chain.chain_type).unwrap();
      (cfg, seed, net)
  }
  ```
- [x] **Second shared fixture** — builds `defs` from config:
  ```rust
  fn build_defs(cfg: &GenesisConfig, seed: &GenesisSeed, net: ChainType) -> Vec<AssetDefinition> {
      cfg.assets.iter()
          .map(|entry| create_asset_definition(entry, seed.as_bytes(), net).unwrap())
          .collect()
  }
  ```
- [x] **Test `stage1_state_hash_is_deterministic`**:
  - [x] Call `load_devnet_fixture()` → `(cfg, seed, net)`
  - [x] Call `build_defs(&cfg, &seed, net)` → `defs`
  - [x] Call `generate_all_genesis_assets(&defs, seed.as_bytes(), net, Arc::new(NoopLogger), Arc::new(NoopMetrics)).unwrap()` → `acc1`
  - [x] Repeat same call → `acc2`
  - [x] `assert_eq!(compute_genesis_state_hash(&acc1), compute_genesis_state_hash(&acc2), "...")`
- [x] **Run**: `cargo test -p z00z_simulator --test stage1_unit stage1_state_hash_is_deterministic`

---

### T1-2 — Asset Definition ID Uniqueness `[unit]`

**Risk:** Colliding definition IDs would cause registry overwrite, silently corrupting asset
tracking and violating domain separation.

**Narrative:**  
Four `AssetDefinition` are created (Z00Z, zUSD, zNFT, zBurnSink). Each `def.id` is a 32-byte
Blake2b hash of `(ChainType || class_byte || symbol)`. A bug in the hash domain or symbol
collision would cause duplicates.

```rust
#[test]
fn stage1_def_ids_unique() {
    let (cfg, seed, net) = load_devnet_fixture();
    let mut ids = std::collections::HashSet::new();
    for item in &cfg.assets {
        let def = create_asset_definition(item, seed.as_bytes(), net).unwrap();
        assert!(ids.insert(def.id), "duplicate definition id for {}", def.symbol);
    }
    assert_eq!(ids.len(), 4);
}
```

**Implementation Checklist:**

- [x] **File**: `crates/z00z_simulator/tests/stage1_unit.rs` (same file as T1-1)
- [x] **Reuse** `load_devnet_fixture()` from T1-1
- [x] **Imports** (add if not already present):
  ```rust
  use z00z_core::genesis::create_asset_definition;
  use std::collections::HashSet;
  ```
- [x] **Test `stage1_def_ids_unique`**:
  - [x] Call `load_devnet_fixture()` → `(cfg, seed, net)`
  - [x] Create `let mut ids: HashSet<[u8; 32]> = HashSet::new();`
  - [x] Loop over `&cfg.assets`, call `create_asset_definition(item, seed.as_bytes(), net).unwrap()` → `def`
  - [x] `assert!(ids.insert(def.id), "duplicate definition id for {}", def.symbol)`
  - [x] After loop: `assert_eq!(ids.len(), 4)` — exactly 4 unique definition IDs (Z00Z, zUSD, zNFT, zBurnSink)
- [x] **Run**: `cargo test -p z00z_simulator --test stage1_unit stage1_def_ids_unique`

---

### T1-3 — Class Distribution Correctness `[integration]`

**Risk:** Assets end up in the wrong bin file — e.g., coins in `genesis_zNFT.bin` — causing
Stage 3 claim to assign wrong asset classes to actors.

**Narrative:**  
For each symbol, only assets of the matching class should appear in its bin file.
`genesis_Z00Z.bin` → `AssetClass::Coin`, `genesis_zNFT.bin` → `AssetClass::Nft`, etc.

```rust
#[test]
fn stage1_bin_class_purity() {
    // run stage 1, then check each .bin
    for (file, expected_class) in [
        ("genesis_Z00Z.bin",      AssetClass::Coin),
        ("genesis_zUSD.bin",      AssetClass::Token),
        ("genesis_zNFT.bin",      AssetClass::Nft),
        ("genesis_zBurnSink.bin", AssetClass::Void),
    ] {
        let assets: Vec<Asset> = load_bincode(out_gen.join(file)).unwrap();
        for a in &assets {
            assert_eq!(a.definition.class, expected_class,
                "{file}: unexpected class {:?}", a.definition.class);
        }
    }
}
```

**Implementation Checklist:**

- [x] **File**: `crates/z00z_simulator/tests/stage1_integration.rs` — separate file for integration tests
- [x] **Cargo.toml** `[dev-dependencies]`:
  - [x] `z00z_core = { path = "../z00z_core" }`
  - [x] `z00z_simulator = { path = ".", features = [] }` *(not required for same-package integration tests)*
- [x] **Shared integration fixture** — run Stage 1 once, cache output dir:
  ```rust
  use std::sync::OnceLock;
  static STAGE1_OUT: OnceLock<PathBuf> = OnceLock::new();
  fn stage1_out() -> &'static PathBuf {
      STAGE1_OUT.get_or_init(|| {
          let (cfg_path, design_path) = test_cfg_paths(); // point to devnet config
          runner::run_with_paths(&cfg_path, &design_path).unwrap();
          cfg_output_dir(&cfg_path)
      })
  }
  ```
  - [x] `test_cfg_paths()` returns `(PathBuf, PathBuf)` pointing to `config_scenario.yaml` and `design_scenario.yaml` under `src/scenario_1/`
  - [x] Do not use `runner::run_stage1_only` (stale/non-stable). Use `runner::run_with_paths` and read output dir from patched config.
- [x] **Imports**:
  ```rust
  use z00z_core::assets::AssetClass;
  use z00z_utils::io::load_bincode;
  use z00z_core::assets::Asset;
  use std::path::PathBuf;
  ```
- [x] **Constant file→class mapping** — define as array:
  ```rust
  const BINS: &[(&str, AssetClass)] = &[
      ("genesis_Z00Z.bin",      AssetClass::Coin),
      ("genesis_zUSD.bin",      AssetClass::Token),
      ("genesis_zNFT.bin",      AssetClass::Nft),
      ("genesis_zBurnSink.bin", AssetClass::Void),
  ];
  ```
- [x] **Test `stage1_bin_class_purity`**:
  - [x] Call `stage1_out()` → `out_gen`
  - [x] Loop over `BINS`; load each `.bin` with `load_bincode::<Vec<Asset>>(out_gen.join("genesis").join(file)).unwrap()`
  - [x] Assert every asset's `a.definition.class == expected_class`
  - [x] Assert each loaded `Vec` is non-empty (bin must not be accidentally empty)
- [x] **Run**: `cargo test -p z00z_simulator --test stage1_integration stage1_bin_class_purity -- --test-threads=1`

---

### T1-4 — Bincode Round-Trip Integrity `[unit]`

**Risk:** Serialization bugs in `save_bincode` / `load_bincode` could silently corrupt asset
state between Stage 1 and Stage 3, producing wrong amounts or invalid commitments.

**Narrative:**  
Save a known `Vec<Asset>` to a tempfile, reload it, compare field-by-field. This isolates
the codec layer from stage runner logic.

```rust
#[test]
fn stage1_bincode_roundtrip() {
    let assets = vec![make_test_asset(42, 1_000)];
    let tmp = tempfile::NamedTempFile::new().unwrap();
    save_bincode(tmp.path(), &assets).unwrap();
    let loaded: Vec<Asset> = load_bincode(tmp.path()).unwrap();
    assert_eq!(loaded[0].serial_id, 42);
    assert_eq!(loaded[0].amount, 1_000);
    assert_eq!(loaded[0].commitment.as_bytes(), assets[0].commitment.as_bytes());
}
```

**Implementation Checklist:**

- [x] **File**: `crates/z00z_simulator/tests/stage1_unit.rs` (same file as T1-1, T1-2)
- [x] **Cargo.toml** `[dev-dependencies]` — add:
  - [x] `tempfile = "3"`
- [x] **Imports**:
  ```rust
  use z00z_utils::io::{save_bincode, load_bincode};
  use z00z_core::assets::Asset;
  use tari_crypto::tari_utilities::ByteArray;
  ```
- [x] **Helper `make_test_asset(serial_id: u32, amount: u64) -> Asset`**:
  - [x] Use `DeterministicRngProvider::from_seed([serial_id as u8; 32])` → `rng`
  - [x] Construct valid asset via `Asset::new(...)` with deterministic seed and nonce
  - [x] Return the asset
- [x] **Test `stage1_bincode_roundtrip`**:
  - [x] `let assets = vec![make_test_asset(42, 1_000)];`
  - [x] `let tmp = tempfile::NamedTempFile::new().unwrap();`
  - [x] `save_bincode(tmp.path(), &assets).unwrap();`
  - [x] `let loaded: Vec<Asset> = load_bincode(tmp.path()).unwrap();`
  - [x] `assert_eq!(loaded.len(), 1)`
  - [x] `assert_eq!(loaded[0].serial_id, 42)`
  - [x] `assert_eq!(loaded[0].amount, 1_000)`
  - [x] `assert_eq!(loaded[0].commitment.as_bytes(), assets[0].commitment.as_bytes())`
- [x] **Run**: `cargo test -p z00z_simulator --test stage1_unit stage1_bincode_roundtrip`

---

### T1-5 — Extractor Output Validity `[integration]`

**Risk:** `assets_extractor_cli` might produce a bin with wrong class or serial range,
silently making downstream consumers (Stage 3, analytics tooling) receive bad inputs.

**Narrative:**  
The CLI is invoked with `--class coin --serial-range 0-99`. The resulting
`assets_extract_coins_0_99.bin` must contain only `Coin` assets with `serial_id` in `[0, 99]`.

```rust
#[test]
fn stage1_extractor_output_valid() {
    // requires full stage 1 run
    let assets: Vec<Asset> = load_bincode(out_gen.join("assets_extract_coins_0_99.bin")).unwrap();
    for a in &assets {
        assert_eq!(a.definition.class, AssetClass::Coin);
        assert!(a.serial_id <= 99, "serial_id {} out of range", a.serial_id);
    }
    assert!(!assets.is_empty(), "extractor output must not be empty");
}
```

**Implementation Checklist:**

- [x] **File**: `crates/z00z_simulator/tests/stage1_integration.rs` (same file as T1-3)
- [x] **Reuse** `stage1_out()` OnceLock fixture from T1-3 — Stage 1 must run with `assets_extractor_cli` invocation enabled (step S1-8)
- [x] **Verify** that `stage_1::run` calls `assets_extractor_cli` with args `--class coin --serial-range 0-99 --output outputs/genesis/assets_extract_coins_0_99.bin --format bin` as specified in design_scenario.yaml S1-8
- [x] **Imports**:
  ```rust
  use z00z_core::assets::{AssetClass, Asset};
  use z00z_utils::io::load_bincode;
  ```
- [x] **Test `stage1_extractor_output_valid`**:
  - [x] `let out_gen = stage1_out().join("genesis");`
  - [x] `let path = out_gen.join("assets_extract_coins_0_99.bin");`
  - [x] `assert!(path.exists(), "extractor bin not found: {}", path.display());`
  - [x] `let assets: Vec<Asset> = load_bincode(&path).unwrap();`
  - [x] `assert!(!assets.is_empty(), "extractor output must not be empty");`
  - [x] Loop over assets: `assert_eq!(a.definition.class, AssetClass::Coin, "non-Coin in extractor output");`
  - [x] Loop over assets: `assert!(a.serial_id <= 99, "serial_id {} out of range [0,99]", a.serial_id);`
- [x] **Run**: `cargo test -p z00z_simulator --test stage1_integration stage1_extractor_output_valid -- --test-threads=1`

---

### T1-6 — Nonce Uniqueness Across All Bins `[property]`

**Risk:** Nonce collision breaks unlinkability — two assets with the same nonce are trivially
linkable on-chain and may violate commitment uniqueness.

**Narrative:**  
`generate_all_genesis_assets` derives each asset nonce deterministically from the genesis seed
and counter. A counter collision or wrong domain would produce duplicates.

```rust
#[test]
fn stage1_nonces_unique() {
    let assets = load_all_genesis_bins(&out_gen);
    let mut seen = std::collections::HashSet::new();
    for a in &assets {
        let nonce_bytes: [u8; 32] = a.nonce.into();
        assert!(seen.insert(nonce_bytes), "nonce collision on serial_id={}", a.serial_id);
    }
}
```

**Implementation Checklist:**

- [x] **File**: `crates/z00z_simulator/tests/stage1_integration.rs` (same file as T1-3)
- [x] **Reuse** `stage1_out()` OnceLock fixture from T1-3
- [x] **Helper `load_all_genesis_bins(out: &Path) -> Vec<Asset>`**:
  ```rust
  fn load_all_genesis_bins(out: &Path) -> Vec<Asset> {
      ["genesis_Z00Z.bin","genesis_zUSD.bin","genesis_zNFT.bin","genesis_zBurnSink.bin"]
          .iter()
          .flat_map(|f| {
              let v: Vec<Asset> = load_bincode(out.join("genesis").join(f)).unwrap();
              v
          })
          .collect()
  }
  ```
- [x] **Imports**:
  ```rust
  use z00z_core::assets::Asset;
  use z00z_utils::io::load_bincode;
  use std::collections::HashSet;
  ```
- [x] **Test `stage1_nonces_unique`**:
  - [x] `let assets = load_all_genesis_bins(stage1_out());`
  - [x] `assert!(!assets.is_empty());` — sanity guard
  - [x] `let mut seen: HashSet<[u8; 32]> = HashSet::new();`
  - [x] Loop: `let nonce_bytes: [u8; 32] = a.nonce.into();`
  - [x] `assert!(seen.insert(nonce_bytes), "nonce collision at serial_id={}", a.serial_id);`
- [x] **Run**: `cargo test -p z00z_simulator --test stage1_integration stage1_nonces_unique -- --test-threads=1`

---

### T1-7 — Serial ID Range Completeness `[property]`

**Risk:** A gap in serial coverage means some genesis supply is silently missing. A duplicate
serial produces a double-issue.

**Narrative:**  
For each asset class, the set of `serial_id` values should be `{0, 1, …, N-1}` with no gaps
and no duplicates, where `N = definition.serials`.

```rust
#[test]
fn stage1_serial_range_complete() {
    for (file, def_symbol) in [("genesis_Z00Z.bin", "Z00Z"), ..] {
        let assets: Vec<Asset> = load_bincode(out_gen.join(file)).unwrap();
        let mut serials: Vec<u32> = assets.iter().map(|a| a.serial_id).collect();
        serials.sort();
        serials.dedup();
        assert_eq!(serials.len(), assets.len(), "{def_symbol}: duplicate serials");
        assert_eq!(*serials.first().unwrap(), 0);
        assert_eq!(*serials.last().unwrap(), (assets.len() - 1) as u32);
    }
}
```

**Implementation Checklist:**

- [x] **File**: `crates/z00z_simulator/tests/stage1_integration.rs` (same file as T1-3, T1-6)
- [x] **Reuse** `stage1_out()` and `load_all_genesis_bins()` helpers from prior sections
- [x] **Note**: The spec snippet has a placeholder `..` in the for-loop — replace it with the full 4-element array:
  ```rust
  const FILES: &[(&str, &str)] = &[
      ("genesis_Z00Z.bin",      "Z00Z"),
      ("genesis_zUSD.bin",      "zUSD"),
      ("genesis_zNFT.bin",      "zNFT"),
      ("genesis_zBurnSink.bin", "zBurnSink"),
  ];
  ```
- [x] **Test `stage1_serial_range_complete`**:
  - [x] Loop over `FILES`
  - [x] `let assets: Vec<Asset> = load_bincode(stage1_out().join("genesis").join(file)).unwrap();`
  - [x] `assert!(!assets.is_empty(), "{def_symbol}: bin is empty");`
  - [x] `let mut serials: Vec<u32> = assets.iter().map(|a| a.serial_id).collect();`
  - [x] `serials.sort_unstable();`
  - [x] `let original_len = serials.len();`
  - [x] `serials.dedup();`
  - [x] `assert_eq!(serials.len(), original_len, "{def_symbol}: duplicate serial IDs");`
  - [x] `assert_eq!(*serials.first().unwrap(), 0, "{def_symbol}: serials don't start at 0");`
  - [x] `assert_eq!(*serials.last().unwrap(), (original_len - 1) as u32, "{def_symbol}: serial gap detected");`
- [x] **Run**: `cargo test -p z00z_simulator --test stage1_integration stage1_serial_range_complete -- --test-threads=1`

---

### T1-8 — Analyzer Report Exists and Non-Empty `[integration]`

**Risk:** If `assets_analyzer_cli` silently exits 0 with an empty report, Stage 1 passes but
genesis validation data is absent — no one would notice until a human review.

**Narrative:**  
After Stage 1, `outputs/genesis/genesis_analysis_genesis.md` must exist AND have non-trivial
size (>500 bytes, containing at least one `|` table separator).

```rust
#[test]
fn stage1_analyzer_report_present() {
    let path = out_gen.join("genesis_analysis_genesis.md");
    let content = std::fs::read_to_string(&path).unwrap();
    assert!(content.len() > 500, "analyzer report looks empty");
    assert!(content.contains('|'), "no table content in analyzer report");
}
```

**Implementation Checklist:**

- [x] **File**: `crates/z00z_simulator/tests/stage1_integration.rs` (same file as T1-3)
- [x] **Reuse** `stage1_out()` OnceLock fixture — Stage 1 must have executed S1-8 `assets_analyzer_cli` invocation
- [x] **Confirm** that `stage_1::run()` calls the `assets_analyzer_cli` binary with `--input outputs/genesis` and writes to `outputs/genesis/genesis_analysis_genesis.md`
- [x] **Test `stage1_analyzer_report_present`**:
  - [x] `let path = stage1_out().join("genesis").join("genesis_analysis_genesis.md");`
  - [x] `assert!(path.exists(), "analyzer report missing: {}", path.display());`
  - [x] `let content = std::fs::read_to_string(&path).expect("failed to read analyzer report");`
  - [x] `assert!(content.len() > 500, "analyzer report too short: {} bytes", content.len());`
  - [x] `assert!(content.contains('|'), "analyzer report has no table rows (no '|' character)");`
- [x] **Run**: `cargo test -p z00z_simulator --test stage1_integration stage1_analyzer_report_present -- --test-threads=1`

---

### T1-9 — Logger Events Coverage `[unit]`

**Risk:** Silent failure in logger means S1-1..S1-8 cannot be audited after the fact; post-mortem
debugging becomes impossible.

**Narrative:**  
`outputs/logs/logger.json` is an NDJSON file with one JSON object per line.
It must contain at least one entry per step `S1-1` through `S1-8`, all with `status == "ok"`.

```rust
#[test]
fn stage1_logger_events_all_steps() {
    let path = out.join("logs/logger.json");
    let content = std::fs::read_to_string(path).unwrap();
    for step in ["S1-1","S1-2","S1-3","S1-4","S1-5","S1-6","S1-7","S1-8"] {
        assert!(content.contains(step), "missing log entry for {step}");
    }
    // Do not require *all* log entries to be ok (other stages may be present).
    // Instead: for each S1-* step, require at least one ok entry and no fail entry.
    for step in ["S1-1","S1-2","S1-3","S1-4","S1-5","S1-6","S1-7","S1-8"] {
        let mut has_ok = false;
        for line in content.lines().filter(|l| !l.trim().is_empty()) {
            let v: serde_json::Value = serde_json::from_str(line).unwrap();
            let v_step = v.get("step").and_then(|x| x.as_str()).unwrap_or_default();
            if v_step != step {
                continue;
            }
            let status = v.get("status").and_then(|x| x.as_str()).unwrap_or_default();
            if status == "fail" {
                panic!("stage 1 step {step} has fail entry: {line}");
            }
            if status == "ok" {
                has_ok = true;
            }
        }
        assert!(has_ok, "stage 1 step {step} has no ok entry");
    }
}
```

**Implementation Checklist:**

- [x] **File**: `crates/z00z_simulator/tests/stage1_integration.rs` (same file as T1-3)
- [x] **Reuse** `stage1_out()` OnceLock fixture — Stage 1 outputs `outputs/logs/logger.json`
- [x] **Imports**:
  ```rust
  use serde_json::Value;
  ```
- [x] **Test `stage1_logger_events_all_steps`**:
  - [x] `let path = stage1_out().join("logs/logger.json");`
  - [x] `assert!(path.exists(), "logger.json not found");`
  - [x] `let content = std::fs::read_to_string(&path).unwrap();`
  - [x] Outer loop over `["S1-1","S1-2","S1-3","S1-4","S1-5","S1-6","S1-7","S1-8"]`:
    - [x] `assert!(content.contains(step), "missing log entry for {step}");`
  - [x] Second loop over same steps:
    - [x] `let mut has_ok = false;`
    - [x] Inner loop over non-empty lines in content:
      - [x] `let v: Value = serde_json::from_str(line).expect("invalid JSON in logger.json: {line}");`
      - [x] Extract `v_step = v["step"].as_str().unwrap_or_default()` — skip if `v_step != step`
      - [x] Extract `status = v["status"].as_str().unwrap_or_default()`
      - [x] `if status == "fail" { panic!("stage 1 step {step} has fail entry: {line}"); }`
      - [x] `if status == "ok" { has_ok = true; }`
    - [x] `assert!(has_ok, "stage 1 step {step} has no ok entry");`
- [x] **Run**: `cargo test -p z00z_simulator --test stage1_integration stage1_logger_events_all_steps -- --test-threads=1`

---

### T1-10 — Wrong Chain Type Error Path Reachable `[unit]`

**Risk:** Running genesis against `testnet` or `mainnet` config would silently produce
different asset IDs (different domain prefix) — catastrophic supply discrepancy.

**Narrative:**  
`run_core` contains the guard:
```rust
if net != ChainType::Devnet { return Err("expected devnet chain type"); }
```
This test verifies the guard is **not dead code**. Without it, a refactor that restructures
chain-type parsing (e.g., defaults to `Devnet` everywhere, or removes the early-return) could
silently accept any chain type and produce wrong asset IDs. The test injects a `testnet` config
and asserts `run_core` returns `Err` containing `"expected devnet"`.

```rust
#[test]
fn stage1_rejects_non_devnet() {
    let mut cfg = load_devnet_fixture();
    cfg.chain.chain_type = "testnet".to_string(); // inject wrong chain
    let result = run_core_with_config(&cfg);
    assert!(result.is_err());
    assert!(result.unwrap_err().contains("expected devnet"));
}
```

**Implementation Checklist:**

- [x] **File**: `crates/z00z_simulator/tests/stage1_unit.rs` (same file as T1-1)
- [x] **Add public helper** `run_core_with_config` in `crates/z00z_simulator/src/scenario_1/stage_1.rs` (or expose existing internal fn):
  ```rust
  #[cfg(test)]
  pub fn run_core_with_config(cfg: &GenesisConfig) -> Result<(), String> {
      let net = ChainType::from_str(&cfg.chain.chain_type)
          .map_err(|e| e.to_string())?;
      if net != ChainType::Devnet {
          return Err("expected devnet chain type".to_string());
      }
      // ... rest of run_core logic, or just test the guard path
      Ok(())
  }
  ```
- [x] **Imports** in test file:
  ```rust
  use z00z_core::chain::ChainType;
  use z00z_simulator::scenario_1::stage_1::run_core_with_config;
  ```
- [x] **Test `stage1_rejects_non_devnet`**:
  - [x] Call `load_devnet_fixture()` → get mutable `cfg`
  - [x] `cfg.chain.chain_type = "testnet".to_string();`
  - [x] `let result = run_core_with_config(&cfg);`
  - [x] `assert!(result.is_err(), "run_core must reject non-devnet config");`
  - [x] `assert!(result.unwrap_err().contains("expected devnet"), "error message must mention 'expected devnet'");`
- [x] **Run**: `cargo test -p z00z_simulator --test stage1_unit stage1_rejects_non_devnet`

---

## Stage 2 — `wallet_create`

### T2-1 — Wallet ID Uniqueness `[integration]`

**Risk:** A bug in `PersistWalletId` generation could produce two actors sharing the same wallet,
making the simulator single-wallet in disguise — all stage 3 imports go to one wallet.

**Narrative:**  
After Stage 2, `ctx.actors` must have three distinct `wallet_id` strings.

```rust
#[test]
fn stage2_wallet_ids_unique() {
    let ids: Vec<_> = ctx.actors.iter().map(|a| &a.wallet_id).collect();
    let set: std::collections::HashSet<_> = ids.iter().collect();
    assert_eq!(set.len(), 3, "wallet ids must be distinct");
}
```

**Implementation Checklist:**

- [x] **File**: `crates/z00z_simulator/tests/stage2_integration.rs` — create if not exists
- [x] **Cargo.toml** `[dev-dependencies]`:
  - [x] `z00z_simulator = { path = ".", features = ["wallet_debug_dump"] }` *(not required for same-package integration tests)*
  - [x] `serde_json = "1"` *(already available in package dependencies)*
- [x] **Shared Stage 2 fixture** — runs full pipeline (stages 1+2), caches output dir:
  ```rust
  use std::sync::OnceLock;
  static S2_OUT: OnceLock<PathBuf> = OnceLock::new();
  fn stage2_out() -> &'static PathBuf {
      S2_OUT.get_or_init(|| {
          let (cfg_path, design_path) = test_cfg_paths();
          runner::run_with_paths(&cfg_path, &design_path).unwrap()
      })
  }
  ```
  - [x] `test_cfg_paths()` returns `(cfg_path, design_path)` pointing to files in `src/scenario_1/`
- [x] **Approach for wallet IDs**: read `outputs/wallets/` directory listing — each `.wlt` filename derives from a unique wallet_id:
  ```rust
  fn collect_wlt_filenames(out: &Path) -> Vec<String> {
      std::fs::read_dir(out.join("wallets")).unwrap()
          .filter_map(|e| e.ok())
          .filter(|e| e.path().extension().map_or(false, |x| x == "wlt"))
          .map(|e| e.file_name().into_string().unwrap())
          .collect()
  }
  ```
- [x] **Test `stage2_wallet_ids_unique`**:
  - [x] `let filenames = collect_wlt_filenames(stage2_out());`
  - [x] `assert_eq!(filenames.len(), 3, "expected 3 wlt files");`
  - [x] Collect into `HashSet<&String>` and assert `set.len() == 3` (no duplicate filenames → no duplicate wallet IDs)
- [x] **Feature gate**: `#[cfg(feature = "wallet_debug_dump")]` if any wallet dump is read; otherwise no gate needed
- [x] **Run**: `cargo test -p z00z_simulator --features wallet_debug_dump --test stage2_integration stage2_wallet_ids_unique -- --test-threads=1`

---

### T2-2 — Owner Handle Uniqueness `[integration]`

**Risk:** If `ReceiverSecret::from_bytes` deterministically maps two seeds to the same handle
(hash collision or bad domain), the two actors would be indistinguishable in stealth scanning —
Bob could receive Alice's assets.

**Narrative:**  
All three actors are seeded with distinct values (42, 43, 44). Their `owner_handle` arrays must
all differ.

```rust
#[test]
fn stage2_owner_handles_unique() {
    let handles: Vec<_> = ctx.actors.iter().map(|a| a.keys.owner_handle).collect();
    assert_ne!(handles[0], handles[1]);
    assert_ne!(handles[0], handles[2]);
    assert_ne!(handles[1], handles[2]);
}
```

**Implementation Checklist:**

- [x] **File**: `crates/z00z_simulator/tests/stage2_integration.rs` (same as T2-1)
- [x] **Reuse** `stage2_out()` OnceLock fixture from T2-1
- [x] **Approach**: read `outputs/keys/alice_keys.json`, `bob_keys.json`, `charlie_keys.json` — each has `owner_handle` as hex string:
  ```rust
  fn read_owner_handle(out: &Path, name: &str) -> [u8; 32] {
      let v: serde_json::Value = load_json(out.join("keys").join(format!("{name}_keys.json"))).unwrap();
      let hex = v["owner_handle"].as_str().expect("owner_handle field missing");
      let bytes = hex::decode(hex).expect("invalid hex in owner_handle");
      bytes.try_into().expect("owner_handle must be 32 bytes")
  }
  ```
- [x] **Imports**:
  ```rust
  use z00z_utils::io::load_json;
  use hex;
  ```
- [x] **Test `stage2_owner_handles_unique`**:
  - [x] `let alice  = read_owner_handle(stage2_out(), "alice");`
  - [x] `let bob    = read_owner_handle(stage2_out(), "bob");`
  - [x] `let charlie = read_owner_handle(stage2_out(), "charlie");`
  - [x] `assert_ne!(alice, bob,     "alice and bob share owner_handle");`
  - [x] `assert_ne!(alice, charlie, "alice and charlie share owner_handle");`
  - [x] `assert_ne!(bob,   charlie, "bob and charlie share owner_handle");`
- [x] **Run**: `cargo test -p z00z_simulator --features wallet_debug_dump --test stage2_integration stage2_owner_handles_unique -- --test-threads=1`

---

### T2-3 — Owner Handle Non-Zero `[unit]`

**Risk:** All-zero handle is the identity element — scanning yields false positives for every
output, breaking recipient identification.

**Narrative:**  
`ReceiverKeys::from_receiver_secret` hashes the 32-byte secret through a domain-prefixed path.
The result should never be zero unless the hash function has a catastrophic preimage.

```rust
#[test]
fn stage2_owner_handles_nonzero() {
    for actor in &ctx.actors {
        assert_ne!(actor.keys.owner_handle, [0u8; 32],
            "{} owner_handle is all-zero", actor.name);
    }
}
```

**Implementation Checklist:**

- [x] **File**: `crates/z00z_simulator/tests/stage2_integration.rs` (same as T2-1, T2-2)
- [x] **Reuse** `stage2_out()` OnceLock and `read_owner_handle()` helper from prior sections
- [x] **Test `stage2_owner_handles_nonzero`**:
  - [x] Loop over `["alice", "bob", "charlie"]`
  - [x] `let handle = read_owner_handle(stage2_out(), name);`
  - [x] `assert_ne!(handle, [0u8; 32], "{name} owner_handle is all-zero");`
- [x] **Note**: This is a fast assertion re-using artifacts already validated by T2-2; no additional pipeline run is needed
- [x] **Run**: `cargo test -p z00z_simulator --features wallet_debug_dump --test stage2_integration stage2_owner_handles_nonzero -- --test-threads=1`

---

### T2-4 — No Secret Leakage in Keys JSON `[unit]`

**Risk:** Accidentally exporting `receiver_secret`, `sk`, `seed_phrase`, or `password` fields
into the public keys file exposes long-term cryptographic material to any file system reader.

**Scope:** Applies **only** to `outputs/keys/{name}_keys.json`.
`wlt_secrets_debug.md` (step S2-14) intentionally stores all actor secrets and seed phrases —
this is a debug-only artifact and is **explicitly exempt** from this check.

**Narrative:**  
Scan `outputs/keys/{alice,bob,charlie}_keys.json` for forbidden field names at any nesting level.
The `_keys.json` files contain only public key material; any presence of secret-like field names
indicates a regression in the serialization filter.

```rust
#[test]
fn stage2_keys_json_no_secrets() {
    // Avoid substring-based false positives (e.g., "mask" contains "sk").
    // Prefer exact / suffix matches for short tokens and strong substring checks for long tokens.
    let forbidden_exact = [
        "receiver_secret",
        "seed",
        "seed_phrase",
        "mnemonic",
        "password",
        "sk",
        "private_key",
        "secret_key",
    ];
    let forbidden_suffix = ["_sk", "_secret", "_seed", "_seed_phrase", "_mnemonic", "_password", "_private_key"]; 
    let forbidden_substr = ["receiver_secret", "seed_phrase", "mnemonic", "password", "private", "secret"]; 
    for name in ["alice", "bob", "charlie"] {
        let v: serde_json::Value = load_json(keys_dir.join(format!("{name}_keys.json"))).unwrap();
        check_no_forbidden_keys(&v, &forbidden_exact, &forbidden_suffix, &forbidden_substr, name);
    }
}

fn check_no_forbidden_keys(
    val: &serde_json::Value,
    forbidden_exact: &[&str],
    forbidden_suffix: &[&str],
    forbidden_substr: &[&str],
    ctx: &str,
) {
    match val {
        serde_json::Value::Object(obj) => {
            for (key, nested) in obj {
                let low = key.to_lowercase();

                if forbidden_exact.iter().any(|f| low == *f) {
                    panic!("{ctx}: forbidden key '{key}' in keys JSON");
                }
                if forbidden_suffix.iter().any(|s| low.ends_with(s)) {
                    panic!("{ctx}: forbidden key '{key}' in keys JSON");
                }
                if forbidden_substr.iter().any(|s| low.contains(s)) {
                    panic!("{ctx}: forbidden key '{key}' in keys JSON");
                }

                check_no_forbidden_keys(nested, forbidden_exact, forbidden_suffix, forbidden_substr, ctx);
            }
        }
        serde_json::Value::Array(arr) => {
            for nested in arr {
                check_no_forbidden_keys(nested, forbidden_exact, forbidden_suffix, forbidden_substr, ctx);
            }
        }
        _ => {}
    }
}
```

**Implementation Checklist:**

- [x] **File**: `crates/z00z_simulator/tests/stage2_integration.rs` (same file as T2-1)
- [x] **Reuse** `stage2_out()` OnceLock fixture
- [x] **Imports**:
  ```rust
  use serde_json::Value;
  use z00z_utils::io::load_json;
  ```
- [x] **Copy `check_no_forbidden_keys` function verbatim** from this spec into the test file (the full recursive implementation with `forbidden_exact`, `forbidden_suffix`, `forbidden_substr` parameters)
- [x] **Test `stage2_keys_json_no_secrets`**:
  - [x] Define `forbidden_exact`, `forbidden_suffix`, `forbidden_substr` arrays exactly as in the spec snippet
  - [x] Loop over `["alice", "bob", "charlie"]`
  - [x] `let path = stage2_out().join("keys").join(format!("{name}_keys.json"));`
  - [x] `assert!(path.exists(), "{name}_keys.json not found");`
  - [x] `let v: Value = load_json(&path).unwrap();`
  - [x] Call `check_no_forbidden_keys(&v, &forbidden_exact, &forbidden_suffix, &forbidden_substr, name);`
- [x] **Explicitly confirm** that `outputs/wallets/wlt_secrets_debug.md` is **NOT** checked (it is exempt per spec)
- [x] **Run**: `cargo test -p z00z_simulator --features wallet_debug_dump --test stage2_integration stage2_keys_json_no_secrets -- --test-threads=1`

---

### T2-5 — WLT File Naming Determinism `[unit]`

**Risk:** If filename derivation (`compute_wallet_file_id`) is non-deterministic (e.g., uses
time-based UUID), the same wallet would land in a different file on every run — breaking
`open_wlt` and backup restore.

**Narrative:**  
Given a fixed `persist_id_str`, the filename `wallet_{hex8}.wlt` must equal the result of
`compute_wallet_file_id(persist_id_str)[..8]`.

```rust
#[test]
fn stage2_wlt_filename_determinism() {
    for actor in &ctx.actors {
        let file_id = compute_wallet_file_id(&actor.wallet_id);
        let expected_name = format!("wallet_{}.wlt", hex_str(&file_id[..8]));
        let path = wallets_dir.join(&expected_name);
        assert!(path.exists(), "expected wlt not found: {expected_name}");
    }
}
```

**Implementation Checklist:**

- [x] **File**: `crates/z00z_simulator/tests/stage2_integration.rs` (same file as T2-1)
- [x] **Reuse** `stage2_out()` OnceLock fixture
- [x] **Expose** `compute_wallet_file_id` publicly from `z00z_wallets` (or re-export through `z00z_simulator`):
  - [x] Locate `compute_wallet_file_id` in `z00z_wallets`; ensure it's `pub` or accessible via `z00z_simulator`
  - [x] Exact signature: `fn compute_wallet_file_id(id: &str) -> [u8; N]` (confirm return type by reading source)
- [x] **Helper `hex_str(bytes: &[u8]) -> String`**:
  ```rust
  fn hex_str(bytes: &[u8]) -> String { hex::encode(bytes) }
  ```
- [x] **Test `stage2_wlt_filename_determinism`**:
  - [x] Read `outputs/keys/{name}_keys.json` for each actor → extract `wallet_id` hex field
  - [x] `let file_id = compute_wallet_file_id(&wallet_id_str);`
  - [x] `let expected_name = format!("wallet_{}.wlt", hex_str(&file_id[..8]));`
  - [x] `let path = stage2_out().join("wallets").join(&expected_name);`
  - [x] `assert!(path.exists(), "expected wlt not found: {expected_name} for actor {name}");`
- [x] **Run**: `cargo test -p z00z_simulator --features wallet_debug_dump --test stage2_integration stage2_wlt_filename_determinism -- --test-threads=1`

---

### T2-6 — Chain ID Is DEVNET for All Actors `[unit]`

**Risk:** A wrong chain ID in `WalletRecord` causes stage 3 session unlock to fail with chain
mismatch, or worse — assets imported into a production chain wallet.

**Narrative:**  
`WalletRecord::new(kernel, ...)` stores `ChainId::DEVNET`. Post-creation, each actor's
`record.chain_id()` must equal `ChainId::DEVNET`.

```rust
#[test]
fn stage2_actors_chain_devnet() {
    for actor in &ctx.actors {
        assert_eq!(
            actor.record.chain_id(),
            ChainId::DEVNET,
            "{} has wrong chain id", actor.name,
        );
    }
}
```

**Implementation Checklist:**

- [x] **File**: `crates/z00z_simulator/tests/stage2_integration.rs` (same as T2-1)
- [x] **Reuse** `stage2_out()` OnceLock fixture
- [x] **Approach**: add `chain_id` field to `Stage2Snap` struct and to `stage_2_snapshot.json` output in `stage_2::run`:
  - [x] In `Stage2Snap`: add `chain_id: String` field, set to `"devnet"`
  - [x] In `stage_2_snapshot.json`: `chain_id: "devnet"` must appear
- [x] **Alternative approach** (no struct change): use `open_wlt` with `WalletIdentity { chain: "devnet" }` — if ChainId mismatches, `open_wlt` returns `Err`; if it returns `Ok` for all 3 actors, ChainId is confirmed DEVNET
  - [x] This approach also covers T2-9 implicitly
- [x] **Imports**:
  ```rust
  use serde_json::Value;
  use z00z_utils::io::load_json;
  ```
- [x] **Test `stage2_actors_chain_devnet`**:
  - [x] `let snap: Value = load_json(stage2_out().join("stage_2_snapshot.json")).unwrap();`
  - [x] `assert_eq!(snap["chain_id"].as_str().unwrap_or_default(), "devnet", "snapshot chain_id must be devnet");`
  - [x] **OR** (if using `open_wlt` approach): loop over actors, `open_wlt(...)` returns `Ok` → chain validated
- [x] **Run**: `cargo test -p z00z_simulator --features wallet_debug_dump --test stage2_integration stage2_actors_chain_devnet -- --test-threads=1`

---

### T2-7 — Seed Phrase Length `[unit]`

**Risk:** Some BIP39 implementations accept fewer/more words silently; using a 12-word phrase
instead of 24 halves entropy (128 vs 256 bits).

**Narrative:**  
The `seed_phrase` field returned by `app.wallet.create_wallet` must be exactly 24 space-separated
words (BIP39 standard for 256-bit entropy).

```rust
#[test]
fn stage2_seed_phrases_24_words() {
    for name in ["alice", "bob", "charlie"] {
        let words: Vec<_> = actor_seed_phrase(name).split_whitespace().collect();
        assert_eq!(words.len(), 24, "{name} seed phrase: expected 24 words, got {}", words.len());
    }
}
```

**Implementation Checklist:**

- [x] **File**: `crates/z00z_simulator/tests/stage2_integration.rs` (same as T2-1)
- [x] **Feature gate**: `#[cfg(feature = "wallet_debug_dump")]` — the seed phrases are only available in this mode
- [x] **Reuse** `stage2_out()` OnceLock fixture (pipeline must run with `--features wallet_debug_dump`)
- [x] **Helper `actor_seed_phrase(out: &Path, name: &str) -> String`**:
  - [x] Read `outputs/wallets/wlt_secrets_debug.md`
  - [x] Parse the markdown table row for `name` — exact column position: `| name | wallet_id | password | seed_phrase | ... |`
  - [x] Return the `seed_phrase` cell value, trimmed of whitespace
  - [x] **Exact table format** from design_scenario.yaml S2-14: columns are `[name, wallet_id, password, seed_phrase, receiver_secret_hex, owner_handle, view_pk, identity_pk, addresses]` — seed_phrase is column index 3 (0-based)
- [x] **Test `stage2_seed_phrases_24_words`**:
  - [x] Loop over `["alice", "bob", "charlie"]`
  - [x] `let phrase = actor_seed_phrase(stage2_out(), name);`
  - [x] `let words: Vec<&str> = phrase.split_whitespace().collect();`
  - [x] `assert_eq!(words.len(), 24, "{name} seed phrase: expected 24 words, got {}", words.len());`
  - [x] Additionally: `assert!(words.iter().all(|w| w.len() >= 3), "{name}: seed phrase has suspiciously short words");`
- [x] **Run**: `cargo test -p z00z_simulator --features wallet_debug_dump --test stage2_integration stage2_seed_phrases_24_words -- --test-threads=1`

---

### T2-8 — RPC Log Has No Plaintext Secrets `[integration]`

**Risk:** If `LoggedRpcTransport` is misconfigured (e.g., redaction list is accidentally cleared,
or a new RPC method exposes credentials without redaction), credentials become visible in log
files visible to any host-level reader.

**Narrative (regression guard):**  
`LoggedRpcTransport` already correctly redacts `password` and `seed_phrase` fields
(confirmed as `"<redacted>"` in `outputs/logs/rpc_logger.json` as of 2026-02-27).
This test is a **regression guard** — it protects against future changes that accidentally
disable or bypass redaction (e.g., adding a new RPC transport wrapper that doesn't apply the
redaction filter, or config change that toggles verbose logging).

Read `outputs/logs/rpc_logger.json` (NDJSON). Assert the raw text does NOT contain:
- Known plaintext passwords: `Alice_Pass_Z00Z_42!`, `Bob_Pass_Z00Z_43!`, `Charlie_Pass_Z00Z_44!`
- The word `abandon` (first word of BIP39 test seed phrases)

```rust
#[test]
fn stage2_rpc_no_secrets() {
    let log = std::fs::read_to_string(out.join("logs/rpc_logger.json")).unwrap();
    for secret in ["Alice_Pass_Z00Z_42!", "Bob_Pass_Z00Z_43!", "Charlie_Pass_Z00Z_44!", "abandon"] {
        assert!(
            !log.contains(secret),
            "rpc_logger.json contains plaintext secret: {secret}",
        );
    }
}
```

**Implementation Checklist:**

- [x] **File**: `crates/z00z_simulator/tests/stage2_integration.rs` (same as T2-1)
- [x] **Reuse** `stage2_out()` OnceLock fixture — pipeline must run with logged RPC transport enabled (S2-1 configures `build_logged_transport`)
- [x] **Test `stage2_rpc_no_secrets`**:
  - [x] `let path = stage2_out().join("logs/rpc_logger.json");`
  - [x] `assert!(path.exists(), "rpc_logger.json not found");`
  - [x] `let log = std::fs::read_to_string(&path).expect("failed to read rpc_logger.json");`
  - [x] `assert!(!log.is_empty(), "rpc_logger.json is empty");`
  - [x] Define secrets array exactly: `let secrets = ["Alice_Pass_Z00Z_42!", "Bob_Pass_Z00Z_43!", "Charlie_Pass_Z00Z_44!", "abandon"];`
  - [x] Loop: `assert!(!log.contains(secret), "rpc_logger.json contains plaintext secret: {secret}");`
- [x] **Note**: the strings `Alice_Pass_Z00Z_42!`, `Bob_Pass_Z00Z_43!`, `Charlie_Pass_Z00Z_44!` are the exact passwords defined in design_scenario.yaml S2-2, S2-3, S2-4; they must not appear unredacted in the log
- [x] **Run**: `cargo test -p z00z_simulator --features wallet_debug_dump --test stage2_integration stage2_rpc_no_secrets -- --test-threads=1`

---

### T2-9 — WLT File Has zstd Magic `[unit]`

**Risk:** A plain-text or incompletely-compressed wallet file would be readable without
decryption — exposing encrypted seed material without encryption.  
Also: silent codec corruption (e.g., wrong compressor) would make future `open_wlt` fail.

**Narrative:**  
zstd frame magic number is `0xFD2FB528`; bytes on disk are little-endian,
so first four bytes must be `[0x28, 0xB5, 0x2F, 0xFD]`. Read first 4 bytes of each `.wlt`.

```rust
#[test]
fn stage2_wlt_zstd_magic() {
    for actor in &ctx.actors {
        let file_id = compute_wallet_file_id(&actor.wallet_id);
        let path = wallets_dir.join(format!("wallet_{}.wlt", hex_str(&file_id[..8])));
        let bytes = std::fs::read(&path).unwrap();
        assert!(
          bytes.starts_with(&[0x28, 0xB5, 0x2F, 0xFD]),
          "{}: wlt missing zstd magic", actor.name,
        );
    }
}
```

**Implementation Checklist:**

- [x] **File**: `crates/z00z_simulator/tests/stage2_integration.rs` (same as T2-1)
- [x] **Reuse** `stage2_out()` OnceLock fixture, `compute_wallet_file_id`, `hex_str` from T2-5
- [x] **zstd magic constant** — define explicitly, do NOT rely on the zstd crate at runtime:
  ```rust
  const ZSTD_MAGIC: &[u8; 4] = &[0x28, 0xB5, 0x2F, 0xFD];
  ```
- [x] **Test `stage2_wlt_zstd_magic`**:
  - [x] Loop over `["alice", "bob", "charlie"]`
  - [x] Read `wallet_id` from `outputs/keys/{name}_keys.json`
  - [x] `let file_id = compute_wallet_file_id(&wallet_id);`
  - [x] `let path = stage2_out().join("wallets").join(format!("wallet_{}.wlt", hex_str(&file_id[..8])));`
  - [x] `assert!(path.exists(), "wlt not found for {name}");`
  - [x] `let bytes = std::fs::read(&path).expect("failed to read wlt");`
  - [x] `assert!(bytes.len() >= 4, "{name}: wlt file too small");`
  - [x] `assert!(bytes.starts_with(ZSTD_MAGIC), "{name}: wlt missing zstd magic (first 4 bytes: {:02x?})", &bytes[..4]);`
- [x] **Run**: `cargo test -p z00z_simulator --features wallet_debug_dump --test stage2_integration stage2_wlt_zstd_magic -- --test-threads=1`

---

### T2-10 — Receiver Card Signature Integrity `[unit]`

**Risk:** A tampered or wrong-format `ReceiverCard` would cause Bob's node to accept invalid
ownership proofs during stealth scanning — enabling asset theft.

**Narrative:**  
`ReceiverCard.signature` is a Schnorr signature by `identity_sk` over
`(owner_handle || view_pk || identity_pk)`. Verify it using `identity_pk` as verifier.

> **⚠️ API Note:** `ReceiverCard` already exposes `verify()` in current codebase.
> Preferred implementation: build card via `export_receiver_card()` and assert `card.verify().is_ok()`.

```rust
#[test]
fn stage2_receiver_card_sig_valid() {
    for actor in &ctx.actors {
        let msg = card_sign_message(&actor.card); // owner_handle || view_pk || identity_pk
        assert!(
            z00z_crypto::verify_kernel_signature(&actor.card.signature, &actor.card.identity_pk, &msg),
            "{}: receiver card sig invalid",
            actor.name,
        );
    }
}
```

**Implementation Checklist:**

- [x] **File**: `crates/z00z_simulator/tests/stage2_unit.rs` — create new file (this is a pure unit test, no pipeline run required)
- [x] **Approach**: Re-derive `ReceiverCard` from scratch using known seeds (42, 43, 44); do NOT read from filesystem artifacts. This makes it a true unit test independent of any pipeline run.
- [x] **Cargo.toml** `[dev-dependencies]`:
  - [x] `z00z_wallets = { path = "../z00z_wallets" }` *(already available in package dependencies)*
  - [x] `z00z_crypto = { path = "../z00z_crypto" }` *(already available in package dependencies)*
  - [x] `z00z_utils = { path = "../z00z_utils" }` *(already available in package dependencies)*
- [x] **Imports**:
  ```rust
  use z00z_wallets::keys::{ReceiverKeys, ReceiverSecret};
  use z00z_crypto::{verify_kernel_signature, derive_hash};
  use z00z_utils::rng::{MockRngProvider, RngCoreExt};
  use tari_crypto::tari_utilities::ByteArray;
  ```
- [x] **Helper `card_sign_message(card: &ReceiverCard) -> Vec<u8>`** *(not required when using `ReceiverCard::verify()`, kept as optional spec variant)*:
  ```rust
  fn card_sign_message(card: &ReceiverCard) -> Vec<u8> {
      let mut msg = Vec::with_capacity(96);
      msg.extend_from_slice(&card.owner_handle);
      msg.extend_from_slice(card.view_pk.as_bytes());
      msg.extend_from_slice(card.identity_pk.as_bytes());
      msg
  }
  ```
  - [x] Verify this matches the domain used in `ReceiverCard::sign(identity_sk)` in source — grep `z00z_wallets` for `sign` method on `ReceiverCard` and confirm the byte layout *(or use `ReceiverCard::verify()` path)*
- [x] **Test `stage2_receiver_card_sig_valid`**:
  - [x] For each `(seed, name)` in `[(42u64, "alice"), (43, "bob"), (44, "charlie")]`:
    - [x] `let mut rng = MockRngProvider::with_u64_seed(seed).rng();`
    - [x] `let mut secret_bytes = [0u8; 32]; rng.fill_bytes_ext(&mut secret_bytes);`
    - [x] Handle all-zero guard: if `secret_bytes == [0u8; 32]`, retry with `seed + 1`
    - [x] `let recv_secret = ReceiverSecret::from_bytes(secret_bytes).unwrap();`
    - [x] `let keys = ReceiverKeys::from_receiver_secret(recv_secret).unwrap();`
    - [x] `let card = keys.export_receiver_card().unwrap();`
    - [x] `let msg = card_sign_message(&card);`
    - [x] `assert!(verify_kernel_signature(&card.signature, &card.identity_pk, &msg), "{name}: receiver card sig invalid");`
- [x] **Run**: `cargo test -p z00z_simulator --test stage2_unit stage2_receiver_card_sig_valid`

---

### T2-11 — Stage 2 Snapshot Consistency `[unit]`

**Risk:** A mismatch between `stage_2_snapshot.json` and the actual in-memory actors state
would cause downstream stages to rely on wrong wallet counts, silently degrading scenario validity.

**Narrative:**  
After Stage 2, `stage_2_snapshot.json` must have `wallet_count == 3` and
`actors_ready_for_stage3 == true`.

```rust
#[test]
fn stage2_snapshot_consistent() {
    let snap: serde_json::Value = load_json(out.join("stage_2_snapshot.json")).unwrap();
    assert_eq!(snap["wallet_count"], 3);
    assert_eq!(snap["actors_ready_for_stage3"], true);
}
```

**Implementation Checklist:**

- [x] **File**: `crates/z00z_simulator/tests/stage2_integration.rs` (same as T2-1)
- [x] **Reuse** `stage2_out()` OnceLock fixture
- [x] **Imports**:
  ```rust
  use serde_json::Value;
  use z00z_utils::io::load_json;
  ```
- [x] **Test `stage2_snapshot_consistent`**:
  - [x] `let path = stage2_out().join("stage_2_snapshot.json");`
  - [x] `assert!(path.exists(), "stage_2_snapshot.json not found");`
  - [x] `let snap: Value = load_json(&path).unwrap();`
  - [x] `assert_eq!(snap["wallet_count"].as_u64().unwrap(), 3, "wallet_count must be 3");`
  - [x] `assert_eq!(snap["actors_ready_for_stage3"].as_bool().unwrap(), true, "actors_ready_for_stage3 must be true");`
  - [x] Bonus: `assert_eq!(snap["stage"].as_u64().unwrap(), 2, "snapshot stage field must be 2");`
- [x] **Run**: `cargo test -p z00z_simulator --features wallet_debug_dump --test stage2_integration stage2_snapshot_consistent -- --test-threads=1`

---

## Stage 3 — `claim_genesis_assets`

### T3-1 — consume_bins=true Zeroes Genesis Bins `[integration]`

**Risk:** If `empty_stage1_bins` silently fails (I/O error swallowed, or `save_bincode` writes
wrong type), the genesis bins are NOT emptied — double-claim becomes possible on the next run.

**Narrative:**  
Run Stage 3 with `consume_bins = true`. After completion, load each `genesis_*.bin` and assert
the result is an empty `Vec<Asset>` (length 0).

```rust
#[test]
fn stage3_bins_empty_after_consume() {
    // run with consume_bins=true (default)
    let (cfg_path, design_path, out) = mk_cfg_with_consume(true);
    runner::run_with_paths(&cfg_path, &design_path).unwrap();

    for file in ["genesis_Z00Z.bin","genesis_zUSD.bin","genesis_zNFT.bin","genesis_zBurnSink.bin"] {
        let assets: Vec<Asset> = load_bincode(out.join("genesis").join(file)).unwrap();
        assert!(assets.is_empty(), "{file} must be empty after consume_bins=true");
    }
}
```

**Implementation Checklist:**

- [x] **File**: `crates/z00z_simulator/tests/test_claim_integration.rs` — create if not exists
- [x] **Cargo.toml** `[dev-dependencies]`:
  - [x] `z00z_simulator = { path = ".", features = ["wallet_debug_dump"] }` *(same-package integration tests do not require explicit self-dependency)*
  - [x] `z00z_core = { path = "../z00z_core" }` *(already present)*
  - [x] `serde_json = "1"` *(already present in package dependencies)*
- [x] **Helper `mk_cfg_with_consume(consume: bool) -> (PathBuf, PathBuf, PathBuf)`**:
  - [x] Copy `config_scenario.yaml` to a temp dir via `tempfile::TempDir::new()`
  - [x] Read the YAML, set `stages[2].stage3_claim.consume_bins = consume`, write back
  - [x] Return `(cfg_path, design_path, out)` where `out` is the temp dir's output subdirectory
  - [x] `design_path` must point to the real `src/scenario_1/design_scenario.yaml`
- [x] **Imports**:
  ```rust
  use z00z_core::assets::Asset;
  use z00z_utils::io::load_bincode;
  use z00z_simulator::scenario_1::runner;
  use std::path::PathBuf;
  ```
- [x] **Test `stage3_bins_empty_after_consume`** — runs isolated in its own temp output dir:
  - [x] `let (cfg_path, design_path, out) = mk_cfg_with_consume(true);`
  - [x] `runner::run_with_paths(&cfg_path, &design_path).unwrap();`
  - [x] Loop over `["genesis_Z00Z.bin","genesis_zUSD.bin","genesis_zNFT.bin","genesis_zBurnSink.bin"]`:
    - [x] `let path = out.join("genesis").join(file);`
    - [x] `assert!(path.exists(), "{file} not found after run");`
    - [x] `let assets: Vec<Asset> = load_bincode(&path).unwrap();`
    - [x] `assert!(assets.is_empty(), "{file} must be empty after consume_bins=true");`
- [x] **Run**: `cargo test -p z00z_simulator --features wallet_debug_dump --test stage3_integration stage3_bins_empty_after_consume -- --test-threads=1`

---

### T3-2 — Double-Claim Rejection `[integration]`

**Risk:** Without the `BinsConsumed` guard, running Stage 3 twice would import the same assets
twice into wallets — inflating actor balances and breaking supply conservation.

**Narrative:**  
Run the full pipeline (stages 1-3) once so `claim_state.json` ends with `step = BinsConsumed`
and all genesis bins are empty. Then attempt Stage 3 **alone** (without re-running Stage 1,
which would refill the bins and make the guard allow re-entry). With `abort_on_fail = true`,
the second Stage 3 call must return `StageResult::Fail`.

> **⚠️ Design Note:** Calling `runner::run_with_paths` twice is **incorrect** for this test.
> The second `run_with_paths` call re-executes Stage 1 which sets `bins_restored = true`,
> causing the guard to allow re-entry — the double-claim would succeed, defeating the test.
> The test must invoke **stage_3 only** after the first complete run.

```rust
#[test]
fn stage3_double_claim_rejected() {
    // Step 1: full run (stages 1-3); bins consumed
    let (cfg_path, design_path, out) = mk_cfg_with_consume(true);
    runner::run_with_paths(&cfg_path, &design_path).unwrap();

    // Step 2: invoke stage 3 directly (no Stage 1 re-run, bins stay empty)
    let mut ctx = build_stage3_ctx(&cfg_path);
    let stage = load_stage3_design(&design_path);
    let result = stage_3::run_claim_genesis(&mut ctx, &stage); // direct stage-3 call

    assert!(
      matches!(result, StageResult::Fail(_)),
        "second Stage 3 must be rejected (BinsConsumed guard)"
    );
}
```

**Implementation Checklist:**

- [x] **File**: `crates/z00z_simulator/tests/test_claim_integration.rs` (same as T3-1)
- [x] **Reuse** `mk_cfg_with_consume(true)` helper from T3-1
- [x] **Use current Stage 3 API only** from `crates/z00z_simulator/src/scenario_1/stage_3.rs`:
  - [x] `stage_3::run_claim_genesis(ctx: &mut SimContext, stage: &DesignStage) -> StageResult`
- [x] **Helper `build_stage3_ctx(cfg_path: &Path) -> SimContext`** (test-only helper):
  - [x] Build `SimContext` via the same initialization path as `runner::run_with_paths`
  - [x] Execute stage 1 + stage 2 once, then call stage 3 directly
- [x] **Helper `load_stage3_design(design_path: &Path) -> DesignStage`**:
  - [x] Load design doc and extract stage with `id == 3`
- [x] **Imports**:
  ```rust
  use z00z_simulator::{DesignStage, SimContext, StageResult};
  use z00z_simulator::scenario_1::stage_3;
  use z00z_simulator::scenario_1::runner;
  ```
- [x] **Test `stage3_double_claim_rejected`**:
  - [x] `let (cfg_path, design_path, out) = mk_cfg_with_consume(true);`
  - [x] `runner::run_with_paths(&cfg_path, &design_path).unwrap();`
  - [x] Verify bins are empty post-run (sanity check, reuse bin-empty logic)
  - [x] `let mut ctx = build_stage3_ctx(&cfg_path);`
  - [x] `let stage = load_stage3_design(&design_path);`
  - [x] `let result = stage_3::run_claim_genesis(&mut ctx, &stage);`
  - [x] `assert!(matches!(result, StageResult::Fail(_)), "second Stage 3 must be rejected");`
- [x] **Critical**: do NOT call `runner::run_with_paths` a second time — that would re-run Stage 1 and refill bins
- [x] **Run**: `cargo test -p z00z_simulator --features wallet_debug_dump --test stage3_integration stage3_double_claim_rejected -- --test-threads=1`

---

### T3-3 — class_split Mode Distribution `[integration]`

**Risk:** Wrong class routing (e.g., NFTs going to Alice instead of Bob) would cause the
wallet-import invariant `sum(commitment_in) == sum(commitment_out)` to hold only if totals
coincidentally match — masking the routing bug.

**Narrative:**  
With `stage3_claim.active = "class_split"`:
- Alice's `claimed_assets_alice.json` must contain only `Coin` class assets (Z00Z)
- Bob's must contain only `Nft` class assets
- Charlie's must contain only `Token` and `Void` class assets

```rust
#[test]
fn stage3_class_split_correct() {
    let (cfg_path, design_path, out) = mk_cfg_with_mode("class_split");
  let run = runner::run_with_paths(&cfg_path, &design_path).unwrap();
  assert!(run.is_ok(), "scenario run failed in class_split mode");

    let alice_rows: Vec<ClaimRow> = load_json(out.join("claim/claimed_assets_alice.json")).unwrap();
    assert!(alice_rows.iter().all(|r| r.class == "Coin"), "alice must get only Coin");

    let bob_rows: Vec<ClaimRow> = load_json(out.join("claim/claimed_assets_bob.json")).unwrap();
    assert!(bob_rows.iter().all(|r| r.class == "Nft"), "bob must get only Nft");
}
```

**Implementation Checklist:**

- [x] **File**: `crates/z00z_simulator/tests/test_claim_integration.rs` (same as T3-1)
- [x] **Helper `mk_cfg_with_mode(mode: &str) -> (PathBuf, PathBuf, PathBuf)`**:
  - [x] Copy `config_scenario.yaml` to a temp dir
  - [x] Set `stages[2].stage3_claim.active = mode` in the YAML, write back
  - [x] Ensure `consume_bins = false` so bins survive the run for re-inspection
  - [x] Return `(cfg_path, design_path, out)`
- [x] **Type `ClaimRow`** — define the struct (or use `serde_json::Value`):
  ```rust
  #[derive(serde::Deserialize)]
  struct ClaimRow {
      class: String,
      // add other fields as needed for later assertions
  }
  ```
- [x] **Confirm** that in `"class_split"` mode (in `config_scenario.yaml`): Alice=Coin, Bob=Nft, Charlie=Token+Void — read the actual split config before writing assertions
- [x] **Test `stage3_class_split_correct`**:
  - [x] `let (cfg_path, design_path, out) = mk_cfg_with_mode("class_split");`
  - [x] `runner::run_with_paths(&cfg_path, &design_path).unwrap();`
  - [x] `let alice_path = out.join("claim/claimed_assets_alice.json"); assert!(alice_path.exists());`
  - [x] `let alice_rows: Vec<ClaimRow> = load_json(&alice_path).unwrap();`
  - [x] `assert!(!alice_rows.is_empty(), "alice must have assets");`
  - [x] `assert!(alice_rows.iter().all(|r| r.class == "Coin"), "alice must get only Coin");`
  - [x] Repeat for bob (Nft), charlie (Token or Void only — no Coin, no Nft)
- [x] **Run**: `cargo test -p z00z_simulator --features wallet_debug_dump --test stage3_integration stage3_class_split_correct -- --test-threads=1`

---

### T3-4 — Claim Event File Is Valid `[unit]`

**Risk:** `ClaimGenesisEvent` is the audit record for the claim. If it's corrupt or absent,
post-hoc supply audits cannot reconstruct what happened during genesis distribution.

**Narrative:**  
After Stage 3, `outputs/events/claim_genesis.event.json` must exist, deserialize cleanly, and
have `scenario_id == 1`, `stage == 3`, `distributed == input_assets`, and `actor_claims.len() == 3`.

```rust
#[test]
fn stage3_claim_event_valid() {
    let path = out.join("events/claim_genesis.event.json");
    let evt: ClaimGenesisEvent = load_json(&path).unwrap();
    assert_eq!(evt.scenario_id, 1);
    assert_eq!(evt.stage, 3);
    assert_eq!(evt.distributed, evt.input_assets);
    assert_eq!(evt.actor_claims.len(), 3);
}
```

**Implementation Checklist:**

- [x] **File**: `crates/z00z_simulator/tests/test_claim_integration.rs` (same as T3-1)
- [x] **Shared Stage 3 fixture** — run full pipeline once, cache output dir:
  ```rust
  static S3_OUT: OnceLock<PathBuf> = OnceLock::new();
  fn stage3_out() -> &'static PathBuf {
      S3_OUT.get_or_init(|| {
          let (cfg_path, design_path) = test_cfg_paths();
          runner::run_with_paths(&cfg_path, &design_path).unwrap()
      })
  }
  ```
  - [x] Re-use this fixture for T3-4 through T3-9 to avoid running the pipeline multiple times
- [x] **Type `ClaimGenesisEvent`** — either use `serde_json::Value` with field access, or define:
  ```rust
  #[derive(serde::Deserialize)]
  struct ClaimGenesisEvent {
      scenario_id: u32,
      stage: u32,
      distributed: u64,
      input_assets: u64,
      actor_claims: Vec<serde_json::Value>,
  }
  ```
- [x] **Confirm** `ClaimGenesisEvent` fields match what `stage_3::run` actually writes by reading `stage_3.rs`
- [x] **Test `stage3_claim_event_valid`**:
  - [x] `let path = stage3_out().join("events/claim_genesis.event.json");`
  - [x] `assert!(path.exists(), "claim_genesis.event.json not found");`
  - [x] `let evt: ClaimGenesisEvent = load_json(&path).unwrap();`
  - [x] `assert_eq!(evt.scenario_id, 1, "scenario_id must be 1");`
  - [x] `assert_eq!(evt.stage, 3, "stage must be 3");`
  - [x] `assert_eq!(evt.distributed, evt.input_assets, "distributed must equal input_assets (no assets lost)");`
  - [x] `assert_eq!(evt.actor_claims.len(), 3, "exactly 3 actor claims expected");`
- [x] **Run**: `cargo test -p z00z_simulator --features wallet_debug_dump --test stage3_integration stage3_claim_event_valid -- --test-threads=1`

---

### T3-5 — Snapshot Actor Counts Sum Correctly `[unit]`

**Risk:** Off-by-one in distribution logic (last asset dropped) would produce a snapshot
that lies about total distribution, masking a partial supply leak.

**Narrative:**  
`stage_3_snapshot.json.actor_claims[*].assets_count` must sum to
`stage_3_snapshot.json.distributed_assets_count`.

```rust
#[test]
fn stage3_snapshot_counts_consistent() {
  let snap: serde_json::Value = load_json(out.join("stage_3_snapshot.json")).unwrap();
    let dist = snap["distributed_assets_count"].as_u64().unwrap() as usize;
    let actor_sum: usize = snap["actor_claims"].as_array().unwrap()
        .iter()
        .map(|a| a["assets_count"].as_u64().unwrap() as usize)
        .sum();
    assert_eq!(actor_sum, dist, "actor_claims.sum != distributed_assets_count");
}
```

**Implementation Checklist:**

- [x] **File**: `crates/z00z_simulator/tests/test_claim_integration.rs` (same as T3-1)
- [x] **Reuse** `stage3_out()` OnceLock fixture from T3-4
- [x] **Imports**:
  ```rust
  use serde_json::Value;
  use z00z_utils::io::load_json;
  ```
- [x] **Test `stage3_snapshot_counts_consistent`**:
  - [x] `let path = stage3_out().join("stage_3_snapshot.json");`
  - [x] `assert!(path.exists(), "stage_3_snapshot.json not found");`
  - [x] `let snap: Value = load_json(&path).unwrap();`
  - [x] `let dist = snap["distributed_assets_count"].as_u64().expect("distributed_assets_count missing") as usize;`
  - [x] `let claims = snap["actor_claims"].as_array().expect("actor_claims must be array");`
  - [x] `let actor_sum: usize = claims.iter().map(|a| a["assets_count"].as_u64().expect("assets_count missing") as usize).sum();`
  - [x] `assert_eq!(actor_sum, dist, "actor_claims.sum ({actor_sum}) != distributed_assets_count ({dist})");`
  - [x] Bonus: `assert_eq!(claims.len(), 3, "must have exactly 3 actor claim entries");`
- [x] **Run**: `cargo test -p z00z_simulator --features wallet_debug_dump --test stage3_integration stage3_snapshot_counts_consistent -- --test-threads=1`

---

### T3-6 — Nonce Uniqueness Across All Claimed Assets `[property]`

**Risk:** Stage 3 is a pure copy-and-reassign (genesis bins → actor bins). A nonce collision
in genesis would propagate to claims — but we don't yet explicitly verify it post-claim.

**Narrative:**  
Collect all assets from all three actors' `imported_assets_full` (debug dump). Check that no
two assets share the same 32-byte nonce.

> **Note:** differs from T1-6 — T1-6 checks genesis bins before claim; T3-6 checks claimed
> assets post-import, catching any nonce mutation or duplication introduced during distribution.

```rust
#[test]
fn stage3_claimed_nonces_unique() {
    let mut seen = std::collections::HashSet::new();
    for name in ["alice", "bob", "charlie"] {
        let items = load_actor_assets(&out, name);
        for item in &items {
            let nonce: [u8; 32] = item.nonce.into();
            assert!(seen.insert(nonce),
                "nonce collision in claimed assets for actor {name}");
        }
    }
}
```

**Implementation Checklist:**

- [x] **File**: `crates/z00z_simulator/tests/test_claim_integration.rs` (same as T3-1)
- [x] **Feature gate**: `#[cfg(feature = "wallet_debug_dump")]` — `load_actor_assets` reads debug dump JSON
- [x] **Reuse** `stage3_out()` OnceLock fixture from T3-4
- [x] **Helper `load_actor_assets(out: &Path, name: &str) -> Vec<Asset>`**:
  ```rust
  fn load_actor_assets(out: &Path, name: &str) -> Vec<Asset> {
      let path = out.join(format!("claim/export_wallet_debug_{name}.json"));
      let dump: WalletDebugDump = load_json_bounded(&path, 64 * 1024 * 1024).unwrap();
      dump.imported_assets_full
  }
  ```
  - [x] Confirm helper reads `imported_assets_full` from `export_wallet_debug_{name}.json` (actual stage_3 dump format)
- [x] **Imports**:
  ```rust
  use z00z_core::assets::Asset;
  use std::collections::HashSet;
  ```
- [x] **Test `stage3_claimed_nonces_unique`**:
  - [x] `let mut seen: HashSet<[u8; 32]> = HashSet::new();`
  - [x] Loop over `["alice", "bob", "charlie"]`:
    - [x] `let items = load_actor_assets(stage3_out(), name);`
    - [x] `assert!(!items.is_empty(), "{name}: no claimed assets found");`
    - [x] Inner loop: `let nonce: [u8; 32] = item.nonce.into();`
    - [x] `assert!(seen.insert(nonce), "nonce collision for {name} at serial {}", item.serial_id);`
- [x] **Run**: `cargo test -p z00z_simulator --features wallet_debug_dump --test stage3_integration stage3_claimed_nonces_unique -- --test-threads=1`

---

### T3-7 — All Claimed Amounts Positive `[unit]`

**Risk:** A zero-amount asset silently passes `verify_complete()` (range proof
is valid for 0), but breaks supply accounting — `sum = genesis_total` only if
no zero-amount ghost assets were injected.

**Narrative:**  
Current test checks `amount > 0` only for `Coin` and `Token`. This test extends coverage to
`Nft` class (NFT has nominal amount 1). `Void` class (`zBurnSink`) is **explicitly excluded**
because the burn-sink may carry `amount = 0` by genesis config design — asserting `> 0` for
`Void` would be a false invariant. Verify the genesis YAML before adding `Void` to this check.

```rust
#[test]
fn stage3_non_void_amounts_positive() {
    for name in ["alice", "bob", "charlie"] {
        let items = load_actor_assets(&out, name);
        for item in &items {
            // Skip Void class — burn-sink may legitimately carry amount=0
            if item.definition.class == AssetClass::Void {
                continue;
            }
            assert!(item.amount > 0,
                "{name}: zero amount in {:?} asset {} ",
                item.definition.class, hex::encode(item.definition.id));
        }
    }
}
```

**Implementation Checklist:**

- [x] **File**: `crates/z00z_simulator/tests/test_claim_integration.rs` (same as T3-1)
- [x] **Reuse** `stage3_out()` OnceLock and `load_actor_assets()` helpers
- [x] **Feature gate**: `#[cfg(feature = "wallet_debug_dump")]`
- [x] **Imports**:
  ```rust
  use z00z_core::assets::{Asset, AssetClass};
  ```
- [x] **Confirm** in `genesis_config_devnet.yaml` the `zBurnSink` (Void) asset's amount setting — if `amount = 0` for genesis, assert is correctly skipped
- [x] **Test `stage3_non_void_amounts_positive`**:
  - [x] Loop over `["alice", "bob", "charlie"]`
  - [x] `let items = load_actor_assets(stage3_out(), name);`
  - [x] Inner loop:
    - [x] `if item.definition.class == AssetClass::Void { continue; }` — explicit skip for Void
    - [x] `assert!(item.amount > 0, "{name}: zero amount in {:?} asset id={:?}", item.definition.class, item.definition.id);`
  - [x] After inner loop: count non-void items and assert at least one exists per actor
- [x] **Run**: `cargo test -p z00z_simulator --features wallet_debug_dump --test stage3_integration stage3_non_void_amounts_positive -- --test-threads=1`

---

### T3-8 — Per-Actor Balance In-Memory vs JSON `[integration]`

**Risk:** `ctx.actors[i].balance` is updated via `per_actor_deltas`, which goes through
`checked_add`. If the in-memory map diverges from the JSON artifact (e.g., due to a
`HashMap::insert` overwriting instead of accumulating), Stage 4 would spend from a wrong balance.

**Narrative:**  
Extract per-actor `total_amount` from `stage_3_snapshot.json.actor_claims`. For each actor,
sum the amounts in `claimed_assets_{name}.json`. The two must be identical.

```rust
#[test]
fn stage3_snapshot_vs_json_balance() {
  let snap: serde_json::Value = load_json(out.join("stage_3_snapshot.json")).unwrap();
    for claim in snap["actor_claims"].as_array().unwrap() {
        let name_lower = claim["name"].as_str().unwrap().to_lowercase();
        let snap_total = claim["total_amount"].as_u64().unwrap();

        let rows: Vec<ClaimRow> = load_json(
            out.join(format!("claim/claimed_assets_{name_lower}.json"))
        ).unwrap();
        let json_total: u64 = rows.iter().map(|r| r.amount).sum();
        assert_eq!(snap_total, json_total,
            "{name_lower}: snapshot total_amount != sum of claimed_assets rows");
    }
}
```

**Implementation Checklist:**

- [x] **File**: `crates/z00z_simulator/tests/test_claim_integration.rs` (same as T3-1)
- [x] **Reuse** `stage3_out()` OnceLock fixture
- [x] **Extend `ClaimRow` struct** from T3-3 with `amount: u64` field:
  ```rust
  #[derive(serde::Deserialize)]
  struct ClaimRow {
      class: String,
      amount: u64,
  }
  ```
  - [x] Confirm the field name by reading what `stage_3::run` writes to `claimed_assets_{name}.json`
- [x] **Imports**:
  ```rust
  use serde_json::Value;
  use z00z_utils::io::load_json;
  ```
- [x] **Test `stage3_snapshot_vs_json_balance`**:
  - [x] `let snap: Value = load_json(stage3_out().join("stage_3_snapshot.json")).unwrap();`
  - [x] `let claims = snap["actor_claims"].as_array().expect("actor_claims must be array");`
  - [x] Loop over `claims`:
    - [x] `let name = claim["name"].as_str().unwrap().to_lowercase();`
    - [x] `let snap_total = claim["total_amount"].as_u64().expect("total_amount field missing");`
    - [x] `let rows: Vec<ClaimRow> = load_json(stage3_out().join(format!("claim/claimed_assets_{name}.json"))).unwrap();`
    - [x] `let json_total: u64 = rows.iter().map(|r| r.amount).sum();`
    - [x] `assert_eq!(snap_total, json_total, "{name}: snapshot total_amount ({snap_total}) != JSON sum ({json_total})");`
- [x] **Run**: `cargo test -p z00z_simulator --features wallet_debug_dump --test stage3_integration stage3_snapshot_vs_json_balance -- --test-threads=1`

---

### T3-9 — Wallet Import Stats Completeness `[unit]`

**Risk:** A partial import (some assets rejected silently) would mean the wallet balance
is lower than claimed — funds lost without error.

**Narrative:**  
`stage_3_snapshot.json.wallet_import_stats` must have exactly 3 entries (one per actor), and
for each entry: `rejected == 0` and `inserted + already_exists == assets_count_for_that_actor`.

```rust
#[test]
fn stage3_import_stats_no_rejections() {
  let snap: serde_json::Value = load_json(out.join("stage_3_snapshot.json")).unwrap();
    let stats = snap["wallet_import_stats"].as_array().expect("wallet_import_stats present");
    assert_eq!(stats.len(), 3, "must have 3 import stat entries");
    for stat in stats {
        let rejected = stat["rejected"].as_u64().unwrap();
        assert_eq!(rejected, 0, "actor {} has rejected imports", stat["actor"]);
    }
}
```

**Implementation Checklist:**

- [x] **File**: `crates/z00z_simulator/tests/test_claim_integration.rs` (same as T3-1)
- [x] **Reuse** `stage3_out()` OnceLock fixture
- [x] **Verify** `wallet_import_stats` field exists in `stage_3_snapshot.json` — confirm in `stage_3.rs` that this field is serialized; if missing, add it to `Stage3Snapshot`
- [x] **Imports**:
  ```rust
  use serde_json::Value;
  use z00z_utils::io::load_json;
  ```
- [x] **Test `stage3_import_stats_no_rejections`**:
  - [x] `let snap: Value = load_json(stage3_out().join("stage_3_snapshot.json")).unwrap();`
  - [x] `let stats = snap["wallet_import_stats"].as_array().expect("wallet_import_stats field missing");`
  - [x] `assert_eq!(stats.len(), 3, "must have 3 import stat entries (one per actor)");`
  - [x] Loop over `stats`:
    - [x] `let actor = stat["actor"].as_str().unwrap_or("unknown");`
    - [x] `let rejected = stat["rejected"].as_u64().expect("rejected field missing");`
    - [x] `assert_eq!(rejected, 0, "actor {actor} has {rejected} rejected imports");`
    - [x] Bonus: `let inserted = stat["inserted"].as_u64().unwrap_or(0);`
    - [x] Bonus: `let already_exists = stat["already_exists"].as_u64().unwrap_or(0);`
    - [x] Bonus: find actor's `assets_count` from `actor_claims` and assert `inserted + already_exists == assets_count`
- [x] **Run**: `cargo test -p z00z_simulator --features wallet_debug_dump --test stage3_integration stage3_import_stats_no_rejections -- --test-threads=1`

---

### T3-10 — Resume Safety: Partial State Idempotency `[integration]`

**Risk:** If Stage 3 crashes between `ArtifactsWritten` and `WalletsUpdated`, a re-run should
either complete cleanly or fail with a clear error — not double-write artifacts or import assets twice.

**Narrative:**  
Simulate crash after `ArtifactsWritten` by writing `claim_state.json` manually, then running
Stage 3 again. The stage must succeed (or fail with a clear descriptive error), and asset
counts must not exceed genesis totals.

```rust
#[test]
fn stage3_resume_artifacts_written() {
    // 1. Run stage 1 + 2 only
    // 2. Manually write claim_state.json with step=ArtifactsWritten
    // 3. Write claimed_assets_alice.json with some content (simulate partial run)
    // 4. Run stage 3 again
    // Result: should either succeed cleanly or fail with non-panic error
    //         total distributed_assets_count == genesis total (no duplication)
}
```

**Implementation Checklist:**

- [x] **File**: `crates/z00z_simulator/tests/test_claim_integration.rs` (same as T3-1)
- [x] **This test has a skeleton body — implement all 4 steps**:
- [x] **Step 1** — run Stage 1 and Stage 2 only (no Stage 3):
  - [x] Create a variant of `mk_cfg_with_consume(false)` that also limits execution to stage 2
  - [x] OR: run full pipeline, save the stage 1+2 output dir for use in step 2
- [x] **Step 2** — manually write `claim_state.json` to simulate crash after `ArtifactsWritten`:
  - [x] Determine the exact `step` enum value written by Stage 3 (grep `claim_state` in `stage_3.rs`)
  - [x] Write `{ "step": "ArtifactsWritten", ... }` to `out.join("claim/claim_state.json")`
  - [x] Also write `claimed_assets_alice.json` (or all 3) with partial content (e.g., 5 assets out of N)
- [x] **Step 3** — run Stage 3 again directly:
  - [x] `let mut ctx = build_stage3_ctx(&cfg_path);`
  - [x] `let stage = load_stage3_design(&design_path);`
  - [x] `let result = stage_3::run_claim_genesis(&mut ctx, &stage);`
  - [x] Assert: `result` is either `StageResult::Ok` or `StageResult::Fail(_)` — must NOT panic
- [x] **Step 4** — check no duplication:
  - [x] If `result.result == StageResult::Ok`: load `stage_3_snapshot.json`, assert `distributed_assets_count == genesis total from stage_1_snapshot.json`
  - [x] If `result.result == StageResult::Fail(_)`: assert error message contains a descriptive string (not just "panicked" or unwrap error)
- [x] **Determine** whether Stage 3 supports idempotent resume from `ArtifactsWritten` by reading `stage_3.rs` state machine logic — if not, the test must accept `Fail` as the valid outcome
- [x] **Run**: `cargo test -p z00z_simulator --features wallet_debug_dump --test stage3_integration stage3_resume_artifacts_written -- --test-threads=1`

---

## Cross-Stage Invariants

### T3-11 — Post-Claim Wallet Byte Identity `[integration]`

**Risk:** If post-claim import/export path mutates wallet bytes, backup/recovery artifacts can
drift from source wallet state and break deterministic forensic comparison.

**Narrative:**
After Stage 3 post-claim export/import, `wallets_export_import/wallet_<hex8>_post_claim.wlt`
must be byte-identical to `wallets/wallet_<hex8>.wlt` for the selected actor wallet ID.

```rust
#[test]
fn post_claim_wlt_byte_identity() {
    let out = stage3_out();
  let payload: serde_json::Value = load_json(
    out.join("wallets_export_import/export_wallet_encrypted_payload_post_claim.json")
  ).expect("read post-claim export payload");
  let hex8 = derive_wallet_hex8(&payload).expect("derive wallet hex8");

  let src = out.join(format!("wallets/wallet_{hex8}.wlt"));
  let dst = out.join(format!("wallets_export_import/wallet_{hex8}_post_claim.wlt"));

    let a = read_file(&src).expect("read source wlt");
    let b = read_file(&dst).expect("read post-claim wlt");
    assert_eq!(a, b, "post-claim wlt must be byte-identical to source");
}
```

**Implementation Checklist:**

- [x] **File**: `crates/z00z_simulator/tests/test_claim_post.rs` — create if not exists
- [x] **Feature gate**: `#![cfg(feature = "wallet_debug_dump")]`
- [x] **Reuse** Stage 3 integration fixture pattern (`mk_cfg...` + `runner::run_with_paths`) with isolated output dir
- [x] **Imports**:
  ```rust
  use z00z_simulator::scenario_1::runner;
  use z00z_utils::io::{load_json, read_file};
  ```
- [x] **Dynamic wallet target**:
  - [x] Read `outputs/wallets_export_import/export_wallet_encrypted_payload_post_claim.json`
  - [x] Resolve imported wallet id and derive `<hex8>` exactly as in Stage 3 runtime
  - [x] Build source path `outputs/wallets/wallet_<hex8>.wlt`
  - [x] Build post-claim path `outputs/wallets_export_import/wallet_<hex8>_post_claim.wlt`
- [x] **Assertions**:
  - [x] both files exist
  - [x] sizes are equal
  - [x] `read_file(src) == read_file(dst)`
- [x] **Run**: `cargo test -p z00z_simulator --features wallet_debug_dump --test stage3_post_claim post_claim_wlt_byte_identity -- --test-threads=1`

---

### TX-1 — Supply Conservation End-to-End `[integration]`

> ✅ **Partially covered** by `stage3_crypto_ok` (amounts + commitments).  
> Not yet extended across stages 4-6 transitions.

**Risk:** Any stage between 1 and 6 that introduces, destroys, or modifies amounts without
a corresponding commitment update would silently break supply conservation.

**Narrative:**  
Run all three stages. After Stage 3:
`Σ(genesis amounts) == Σ(claimed amounts) == Σ(wallet list_assets amounts)`.
Expected to expand to Stage 4-6 once those are implemented.

```rust
// Already partially covered — extension placeholder for Stage 4+
```

**Implementation Checklist:**

- [x] **File**: `crates/z00z_simulator/tests/test_claim_integration.rs` (extend existing test)
- [x] **Current coverage**: `stage3_crypto_ok` already verifies amounts + commitment validity post-Stage 3
- [x] **Extension required when Stage 4-6 land**: move this test to `crates/z00z_simulator/tests/cross_stage.rs`
- [x] **Present action** (to unlock future extension):
  - [x] Create `tests/cross_stage.rs` file placeholder without dead-code suppression
  - [x] Add `[[test]] name = "cross_stage"` section to `Cargo.toml` so it compiles
  - [x] Add helper `fn load_snap(out: &Path, name: &str) -> serde_json::Value` that `load_json(out.join(name)).unwrap()`
  - [x] Add TODO comment: `// Extend once stage_4..stage_6 output dirs are defined`
- [x] **Cross-stage assertion (stage 1 + stage 3 only, now)**:
  - [x] `let s1 = load_snap(out, "stage_1_snapshot.json");`
  - [x] `let s3 = load_snap(out, "stage_3_snapshot.json");`
  - [x] `stage_1_snapshot.json` has no `total_amount`; use summed amounts from genesis bins as `s1_total`
  - [x] `let s3_total: u64 = s3["actor_claims"].as_array().unwrap().iter().map(|a| a["total_amount"].as_u64().unwrap()).sum();`
  - [x] `assert_eq!(s1_total, s3_total, "supply conservation violated: s1={s1_total} s3={s3_total}");`
- [x] **Run**: `cargo test -p z00z_simulator --features wallet_debug_dump --test cross_stage cross_stage_supply_conservation -- --test-threads=1`

---

### TX-2 — Commitment Sum Stability `[property]`

> ✅ **Covered** by `stage3_crypto_ok`.

**Implementation Checklist:**

- [x] **No new code required** — this test is fully covered by `stage3_crypto_ok` in `tests/test_claim_crypto.rs`
- [x] **Verify** `stage3_crypto_ok` actually asserts commitment validity (not just absence of panic):
  - [x] Grep for `verify_complete` and `verify_range_proof` calls inside `stage3_crypto_ok`
  - [x] Assert both return `Ok` for all actor assets
- [x] **Optional cross-crate property**: if a separate `property` test is desired some day:
  - [x] Add `proptest` dev-dependency *(optional; deferred)*
  - [x] Generate random `(blinding, value)` pairs, create commitment + range proof, verify sum invariant *(optional; deferred)*
  - [x] Mark with `#[cfg(feature = "proptest")]` to keep default test run fast *(optional; deferred)*
- [x] **Run** (existing coverage): `cargo test -p z00z_simulator --features wallet_debug_dump --test stage3_claim_crypto stage3_crypto_ok -- --test-threads=1`

---

### TX-3 — Asset Count Pipeline Consistency `[integration]`

**Risk:** Count mismatch between Stage 1 snapshot (`stage_1_snapshot.json.assets_count`) and
Stage 3 snapshot (`stage_3_snapshot.json.input_assets_count`) indicates that Stage 3 loaded
different bins than Stage 1 produced.

**Narrative:**  
`stage_1_snapshot.json.assets_count` must equal `stage_3_snapshot.json.input_assets_count`.

```rust
#[test]
fn cross_stage_asset_count_pipeline() {
    let s1: serde_json::Value = load_json(out.join("stage_1_snapshot.json")).unwrap();
  let s3: serde_json::Value = load_json(out.join("stage_3_snapshot.json")).unwrap();
    assert_eq!(
        s1["assets_count"].as_u64().unwrap(),
        s3["input_assets_count"].as_u64().unwrap(),
        "stage_1 asset count != stage_3 input count",
    );
}
```

**Implementation Checklist:**

- [x] **File**: `crates/z00z_simulator/tests/cross_stage.rs` (created in TX-1 checklist)
- [x] **Reuse** the shared pipeline output from `stage3_out()` OnceLock OR re-run the full pipeline (pick one; prefer re-use via module-level OnceLock)
- [x] **Shared output path helper**:
  ```rust
  static CROSS_STAGE_OUT: OnceLock<PathBuf> = OnceLock::new();
  fn cross_out() -> &'static PathBuf {
      CROSS_STAGE_OUT.get_or_init(|| {
          // Run the full scenario pipeline into a temp dir
          let out = tempdir().unwrap().into_path();
          // call run_full_pipeline(&out)
          out
      })
  }
  ```
  - [x] `run_full_pipeline(out: &Path)` must call stages 1, 2, 3 in sequence using `mk_cfg_with_consume(false)` variant that targets `out`
- [x] **Field name verification**: grep `stage_1.rs` for the serialized field name (`assets_count` vs `genesis_assets_count`); use exact field name
- [x] **Field name verification**: grep `stage_3.rs` for the serialized field name (`input_assets_count` vs `total_input_assets`); use exact field name
- [x] **Test `cross_stage_asset_count_pipeline`**:
  - [x] `let s1: Value = load_snap(cross_out(), "stage_1_snapshot.json");`
  - [x] `let s3: Value = load_snap(cross_out(), "stage_3_snapshot.json");`
  - [x] `let s1_count = s1["assets_count"].as_u64().expect("s1.assets_count missing");`
  - [x] `let s3_count = s3["input_assets_count"].as_u64().expect("s3.input_assets_count missing");`
  - [x] `assert_eq!(s1_count, s3_count, "asset count: stage_1={s1_count} stage_3_input={s3_count}");`
- [x] **Run**: `cargo test -p z00z_simulator --features wallet_debug_dump --test cross_stage cross_stage_asset_count_pipeline -- --test-threads=1`

---

### TX-4 — All Actors Present in Stage 3 with Non-Zero Claims `[integration]`

**Risk:** If one actor is missing from `ctx.actors` by the time Stage 3 runs (e.g., Stage 2
failed partially but `abort_on_fail = false`), Stage 3 would skip that actor silently,
leaving part of genesis supply unaccounted.

**Narrative:**  
After Stage 3, all three actors must appear in `stage_3_snapshot.json.actor_claims` with
`assets_count > 0`.

```rust
#[test]
fn cross_stage_all_actors_claimed() {
  let snap: serde_json::Value = load_json(out.join("stage_3_snapshot.json")).unwrap();
    let expected_names = ["alice", "bob", "charlie"];
    for expected in expected_names {
        let entry = snap["actor_claims"].as_array().unwrap()
            .iter()
            .find(|a| a["name"].as_str().unwrap().to_lowercase() == expected);
        let entry = entry.expect(&format!("{expected} missing from actor_claims"));
        assert!(
            entry["assets_count"].as_u64().unwrap() > 0,
            "{expected} has zero assets",
        );
    }
}
```

**Implementation Checklist:**

- [x] **File**: `crates/z00z_simulator/tests/cross_stage.rs` (same as TX-3)
- [x] **Reuse** `cross_out()` OnceLock helper defined in TX-3 checklist
- [x] **Constants**: `const EXPECTED_ACTORS: &[&str] = &["alice", "bob", "charlie"];`
- [x] **Verify** `actor_claims` field name in `stage_3_snapshot.json` (grep `stage_3.rs` for serialization); confirm `name` sub-field is lowercase normalized *(actual test normalizes via `to_lowercase()` before compare)*
- [x] **Test `cross_stage_all_actors_claimed`**:
  - [x] `let snap: Value = load_snap(cross_out(), "stage_3_snapshot.json");`
  - [x] `let claims = snap["actor_claims"].as_array().expect("actor_claims field missing or not array");`
  - [x] `assert_eq!(claims.len(), EXPECTED_ACTORS.len(), "actor_claims count mismatch: got {}", claims.len());`
  - [x] For each `expected` in `EXPECTED_ACTORS`:
    - [x] `let entry = claims.iter().find(|a| a["name"].as_str().unwrap().to_lowercase() == *expected);`
    - [x] `let entry = entry.expect(&format!("{expected} missing from actor_claims"));`
    - [x] `let count = entry["assets_count"].as_u64().expect("assets_count field missing");`
    - [x] `assert!(count > 0, "{expected} has zero assets in stage_3 claims");`
- [x] **Run**: `cargo test -p z00z_simulator --features wallet_debug_dump --test cross_stage cross_stage_all_actors_claimed -- --test-threads=1`

---

## Negative / Tamper Tests

### NEG-1 — Tampered Range Proof Rejected `[unit]`

**Risk:** If `verify_range_proof` actually accepts any bytes (dead code path, wrong dispatch),
range proof verification is no-op — amounts can be fabricated.

**Narrative:**  
Take a valid claimed asset. Zero out the first 16 bytes of its range proof. Assert that
`verify_range_proof` returns an error.

```rust
#[test]
fn neg_tampered_range_proof_rejected() {
    let items = load_actor_assets(&out, "alice");
    let mut item = items[0].clone();
    if let Some(ref mut proof) = item.range_proof {
        for b in proof.iter_mut().take(16) { *b = 0x00; }
    }
    let result = verify_range_proof(
        item.range_proof.as_ref().unwrap(),
        &item.commitment,
        RANGE_PROOF_BITS_V1, AGGREGATION_FACTOR, MIN_VALUE_PROMISE,
    );
    assert!(result.is_err(), "tampered range proof must be rejected");
}
```

**Implementation Checklist:**

- [x] **File**: `crates/z00z_simulator/tests/test_claim_integration.rs` (append after existing tests)
- [x] **Feature gate**: `#[cfg(feature = "wallet_debug_dump")]`
- [x] **Reuse** `stage3_out()` OnceLock and `load_actor_assets()` helpers
- [x] **Imports**:
  ```rust
  use z00z_crypto::{
      verify_range_proof,
      RANGE_PROOF_BITS_V1, AGGREGATION_FACTOR, MIN_VALUE_PROMISE,
  };
  use z00z_core::assets::Asset;
  ```
  - [x] Confirm exact constants (`RANGE_PROOF_BITS_V1`, `AGGREGATION_FACTOR`, `MIN_VALUE_PROMISE`) are exported from `z00z_crypto`; if not, grep `z00z_crypto/src/lib.rs` and use correct names
  - [x] Confirm `verify_range_proof` signature: `fn verify_range_proof(proof: &[u8], commitment: &Z00ZCommitment, bits: usize, agg: usize, min_val: u64) -> Result<(), Error>`
- [x] **Test `neg_tampered_range_proof_rejected`**:
  - [x] `let items = load_actor_assets(stage3_out(), "alice");`
  - [x] `assert!(!items.is_empty(), "alice has no claimed assets");`
  - [x] `let mut item = items[0].clone();`
  - [x] Find an asset in `items` that `has_range_proof` (not all classes may carry a proof): `let mut item = items.iter().find(|i| i.range_proof.is_some()).expect("no asset with range proof").clone();`
  - [x] Mutate: `if let Some(ref mut proof) = item.range_proof { for b in proof.iter_mut().take(16) { *b = 0x00; } }`
  - [x] `let result = verify_range_proof(item.range_proof.as_ref().unwrap(), &item.commitment, RANGE_PROOF_BITS_V1, AGGREGATION_FACTOR, MIN_VALUE_PROMISE);`
  - [x] `assert!(result.is_err(), "tampered range proof must be rejected");`
- [x] **Also test**: zero-length proof is rejected: `assert!(verify_range_proof(&[], &item.commitment, ...).is_err());`
- [x] **Run**: `cargo test -p z00z_simulator --features wallet_debug_dump --test stage3_integration neg_tampered_range_proof_rejected -- --test-threads=1`

---

### NEG-2 — Tampered Owner Signature Rejected `[unit]`

**Risk:** `asset.verify_complete()` delegates owner signature verification to
`verify_owner_signature()`. If the signature algorithm has a bypass (e.g., accepts zero-sig),
any asset can be claimed by anyone.

**Narrative:**  
Take a valid claimed asset. Flip the last byte of `owner_signature` serialized bytes.
Assert that `asset.verify_complete()` returns `Err`.

> **API Note:** `KernelSignature = Z00ZSchnorrSignature` implements Tari's `ByteArray` trait.
> Use `sig.as_bytes().to_vec()` (immutable `&[u8]`) then `KernelSignature::from_bytes(&tampered)`
> to reconstruct. There is **no** `as_bytes_mut()` on `KernelSignature`.

```rust
#[test]
fn neg_tampered_owner_sig_rejected() {
    use tari_crypto::tari_utilities::ByteArray;
    let items = load_actor_assets(&out, "alice");
    let mut item = items[0].clone();
    if let Some(ref sig) = item.owner_signature {
        let mut raw = sig.as_bytes().to_vec();
        *raw.last_mut().unwrap() ^= 0xFF; // flip last byte
        item.owner_signature = match KernelSignature::from_bytes(&raw) {
            Ok(tampered_sig) => Some(tampered_sig),
            Err(_) => {
                // from_bytes already rejected the tampered bytes (invalid point encoding)
                // — signature is provably invalid, test passes
                return;
            }
        };
    }
    assert!(
        item.verify_complete().is_err(),
        "tampered owner signature must cause verify_complete to fail"
    );
}
```

**Implementation Checklist:**

- [x] **File**: `crates/z00z_simulator/tests/test_claim_integration.rs` (append after NEG-1)
- [x] **Feature gate**: `#[cfg(feature = "wallet_debug_dump")]`
- [x] **Reuse** `stage3_out()` OnceLock and helpers *(runtime strips `owner_signature` in claimed/debug assets, so test uses genesis assets from same scenario run)*
- [x] **Imports**:
  ```rust
  use tari_crypto::tari_utilities::ByteArray;
  use z00z_crypto::KernelSignature;
  use z00z_core::assets::Asset;
  ```
  - [x] Confirm `KernelSignature` is exported from `z00z_crypto` (grep `z00z_crypto/src/lib.rs`)
  - [x] Confirm `asset.verify_complete()` exists (grep `z00z_core/src/assets/`) and returns `Result`
  - [x] Confirm `asset.owner_signature` field type is `Option<KernelSignature>`
- [x] **Test `neg_tampered_owner_sig_rejected`**:
  - [x] Load assets with present signatures from scenario output genesis bins (`load_gen_assets(stage3_out())`)
  - [x] `let mut item = items.iter().find(|i| i.owner_signature.is_some()).expect("no asset with owner_signature").clone();`
  - [x] Tamper by substituting a different valid `KernelSignature` from another asset
  - [x] `assert!(item.verify_complete().is_err(), "tampered owner signature must fail verify_complete");`
- [x] **Run**: `cargo test -p z00z_simulator --features wallet_debug_dump --test stage3_integration neg_tampered_owner_sig_rejected -- --test-threads=1`

---

### NEG-3 — Tampered Commitment Is Rejected `[unit]`

**Risk:** Commitments must be cryptographically bound to the included proofs and signatures.
If a commitment can be swapped without invalidating `verify_complete()`, an attacker could
substitute arbitrary commitments and bypass asset integrity checks.

**Narrative:**  
Take a valid claimed asset. Replace its commitment with garbage bytes (or another valid point).
Assert that `asset.verify_complete()` fails (either commitment decoding fails, or proof binding
fails during verification).

> **API Note:** `Z00ZCommitment` is `PedersenCommitment` from Tari, which implements
> `tari_crypto::tari_utilities::ByteArray`. Use `Z00ZCommitment::from_bytes(&raw_32)` via
> the trait. Called with random bytes, this will return `Err` if `0xDE * 32` does not encode
> a valid Ristretto point. Handle both `Ok` (tampered but valid encoding) and `Err` paths:
> - `Ok(tampered_com)` — substitute and assert sum diverges
> - `Err(_)` — commit is provably garbage, treat as successful tamper detection

```rust
#[test]
fn neg_tampered_commitment_rejected() {
    use tari_crypto::tari_utilities::ByteArray;
    let items = load_actor_assets(&out, "alice");
    let mut item = items[0].clone();

    // Attempt to construct a commitment from junk bytes.
    // If decoding fails, tampering is detected at the deserialization boundary.
    match Z00ZCommitment::from_bytes(&[0xDE; 32]) {
        Ok(tampered_com) => {
            item.commitment = tampered_com;
            assert!(
                item.verify_complete().is_err(),
                "tampered commitment must cause verify_complete to fail (proof/signature binding)",
            );
        }
        Err(_) => {
            // from_bytes rejected the junk — commitment encoding validation fired;
            // invalid commitment cannot be substituted — tamper detection confirmed
        }
    }
}
```

**Implementation Checklist:**

- [x] **File**: `crates/z00z_simulator/tests/test_claim_integration.rs` (append after NEG-2)
- [x] **Feature gate**: `#[cfg(feature = "wallet_debug_dump")]`
- [x] **Reuse** `stage3_out()` OnceLock and `load_actor_assets()` helpers
- [x] **Imports**:
  ```rust
  use tari_crypto::tari_utilities::ByteArray;
  use z00z_crypto::{Z00ZCommitment, KernelSignature};
  use z00z_core::assets::Asset;
  ```
  - [x] Confirm `Z00ZCommitment` is exported from `z00z_crypto` (grep `z00z_crypto/src/lib.rs`)
  - [x] Confirm `asset.commitment` field type is `Z00ZCommitment` (not `Option<...>`)
  - [x] Note: current API exposes `from_canonical_bytes(&[u8])` (not `from_bytes`) and test uses that constructor
- [x] **Test `neg_tampered_commitment_rejected`**:
  - [x] `let items = load_actor_assets(stage3_out(), "alice");`
  - [x] pick base asset with range proof (`let base = items.iter().find(...).clone();`)
  - [x] junk bytes path: `if let Ok(c) = Z00ZCommitment::from_canonical_bytes(&[0xDE; 32]) { ... verify_complete().is_err() }`
  - [x] zero-point path: `if let Ok(c) = Z00ZCommitment::from_canonical_bytes(&[0x00; 32]) { ... verify_complete().is_err() }`
  - [x] valid-different commitment path: assign `other.commitment` to base and assert `verify_complete().is_err()`
- [x] **Run**: `cargo test -p z00z_simulator --features wallet_debug_dump --test stage3_integration neg_tampered_commitment_rejected -- --test-threads=1`

---

## Summary Table

| ID | Stage | Type | Priority | Covered |
|----|-------|------|----------|---------|
| T1-1 | 1 | unit | 🔴 High | ✅ |
| T1-2 | 1 | unit | 🔴 High | ✅ |
| T1-3 | 1 | integration | 🔴 High | ✅ |
| T1-4 | 1 | unit | 🟡 Medium | ✅ |
| T1-5 | 1 | integration | 🟡 Medium | ✅ |
| T1-6 | 1 | property | 🟡 Medium | ✅ |
| T1-7 | 1 | property | 🟡 Medium | ✅ |
| T1-8 | 1 | integration | 🔵 Low | ✅ |
| T1-9 | 1 | unit | 🔵 Low | ✅ |
| T1-10 | 1 | unit | 🔴 High | ✅ |
| T2-1 | 2 | integration | 🔴 High | ❌ |
| T2-2 | 2 | integration | 🔴 High | ❌ |
| T2-3 | 2 | unit | 🔴 High | ❌ |
| T2-4 | 2 | unit | 🟡 Medium | ❌ |
| T2-5 | 2 | unit | 🟡 Medium | ❌ |
| T2-6 | 2 | unit | 🔴 High | ❌ |
| T2-7 | 2 | unit | 🟡 Medium | ❌ |
| T2-8 | 2 | integration | 🟡 Medium | ❌ |
| T2-9 | 2 | unit | 🟡 Medium | ❌ |
| T2-10 | 2 | unit | 🔴 High | ❌ |
| T2-11 | 2 | unit | 🔵 Low | ❌ |
| T3-1 | 3 | integration | 🔴 High | ✅ |
| T3-2 | 3 | integration | 🔴 High | ✅ |
| T3-3 | 3 | integration | 🟡 Medium | ✅ |
| T3-4 | 3 | unit | 🟡 Medium | ✅ |
| T3-5 | 3 | unit | 🔴 High | ✅ |
| T3-6 | 3 | property | 🟡 Medium | ✅ |
| T3-7 | 3 | unit | 🟡 Medium | ✅ |
| T3-8 | 3 | integration | 🔴 High | ✅ |
| T3-9 | 3 | unit | 🔴 High | ✅ |
| T3-10 | 3 | integration | 🟡 Medium | ✅ |
| T3-11 | 3 | integration | 🔴 High | ✅ |
| TX-1 | 1+2+3 | integration | 🔴 High | ✅ (partial) |
| TX-2 | 1+3 | property | 🔴 High | ✅ |
| TX-3 | 1+3 | integration | 🔴 High | ✅ |
| TX-4 | 2+3 | integration | 🔴 High | ✅ |
| NEG-1 | 3 | unit | 🔴 High | ✅ |
| NEG-2 | 3 | unit | 🔴 High | ✅ |
| NEG-3 | 3 | unit | 🟡 Medium | ✅ |

---

## Implementation Strategy

### Fast Unit Tests (no subprocess)

Planned additions can be split into:

- `crates/z00z_simulator/tests/stage1_unit.rs`
- `crates/z00z_simulator/tests/stage2_unit.rs`
- `crates/z00z_simulator/tests/stage3_unit.rs`

These files are not part of the current baseline yet; current baseline Stage 3 checks live in existing files listed above.

### Integration Tests (full pipeline, ~12 min)

Current pattern is valid and already used:

- isolated output directories per test family (`target/stage3_tests/*`, `target/stage3_snapshot/*`, `target/audit_log_tests/*`),
- `runner::run_with_paths` as stage pipeline entrypoint,
- selective `OnceLock`/shared fixtures only where needed.

### Feature Gate

Tests reading `export_wallet_debug_*.json` must be gated with:
```rust
#![cfg(feature = "wallet_debug_dump")]
```

### Run Commands

```bash
# Baseline simulator tests (release, current source-of-truth):
cargo test -p z00z_simulator --tests --release --features test-fast

# Stage 3 crypto focused run:
cargo test -p z00z_simulator --test stage3_claim_crypto --release --features wallet_debug_dump

# Wallet import/ownership/replay security suite (claim-spec critical):
cargo test -p z00z_wallets --test test_asset_import_security --release --features test-fast
cargo test -p z00z_wallets --test test_asset_ownership_security --release --features test-fast
cargo test -p z00z_wallets --test test_asset_replay_protection --release --features test-fast

# Full workspace unit+integration release sweep:
cargo test --workspace --release --lib --tests -F z00z_simulator/test-fast,z00z_wallets/test-fast,z00z_simulator/wallet_debug_dump
```
