# Scenario 1 Claim Security Specification

📌 **Version:** 2.0.0  
📌 **Date:** 2026-02-28  
📌 **Scope:** Stage 3 claim path (`wallet_only_intermediate`) in Scenario 1  
📌 **Status:** Normative (`MUST` level)

---

## Purpose

🎯 This document defines mandatory claim-time security controls for assets imported into wallets during Scenario 1 Stage 3.

🎯 All requirements in this document are strict and non-optional for live/realtime processing.

🎯 The text is intentionally implementation-oriented so each `###` section can be extended with an explicit implementation checklist.

---

## Current Reference Points

📌 The current import entrypoint is `wallet.asset.import_asset` implemented in `crates/z00z_wallets/src/adapters/rpc/methods/asset_impl.rs`.

📌 The current stage runner path is `run_claim_genesis` in `crates/z00z_simulator/src/scenario_1/stage_3.rs`.

📌 Asset structural and cryptographic primitives live in `crates/z00z_core/src/assets/assets.rs` and `crates/z00z_core/src/assets/wire.rs`.

📌 This spec defines required additions/changes to close ownership, anti-double-claim, and cryptographic enforcement gaps.

---

## Normative Rules

📌 `MUST` means mandatory for release.

📌 `MUST NOT` means forbidden behavior.

📌 `FAIL-CLOSED` means on any validation ambiguity/error, processing must reject asset import.

📌 `Realtime` means enforced in live import/receive flow, not only in tests.

---

## Scenario 1 Stage 3 — Fixed Design Decisions

🎯 This spec intentionally **selects** one concrete implementation route to avoid ambiguous security behavior.

✅ **Fixed choices (normative for Scenario 1 Stage 3):**
- Transparent ownership policy is **Policy A (keyring membership)** (CS-2).
- `wallet_id ↔ identity_pk` binding is **Authenticated wallet registry mapping** (CS-5).
- `GlobalClaimRegistry` is owned and executed **inside the wallet RPC trust boundary** (`AssetRpcImpl::import_asset`) (CS-1/CS-5).

🚫 **Forbidden (legacy / removed options):**
- Stage 3 MUST NOT pre-reserve claims.
- Stage 3 MUST NOT sign claim receipts.
- Deterministic `wallet_id = H(identity_pk)` binding is NOT used in Scenario 1 Stage 3.

✅ **Additional fixed rule (normative):**
- Global double-claim protection MUST use a **two-phase** API (`reserve` + `finalize`). Single-phase `try_claim()` is NOT used in Scenario 1 Stage 3.

---

## Mandatory Requirements

### CS-1 — Full Crypto Validation on Import

🎯 **Goal:** Every imported asset must pass full cryptographic validation before storage.

📌 **Target functions:**
- `AssetRpcImpl::import_asset`
- `AssetWire::to_asset`
- `Asset::verify_complete`

✅ **MUST rules:**
- `import_asset` MUST call `asset.verify_complete()` before any storage insert.
- Validation MUST include:
	- range proof verification (when applicable per `Asset::verify_complete()` semantics), and
	- owner signature verification when required by the ownership mode/policy (see CS-2) or when `owner_signature` is present.
- Validation errors MUST be returned as explicit RPC reject (not silently downgraded).
- Import flow MUST be fail-closed if verification cannot be completed.

⚠️ **Critical note (current code reality):**

📌 Today `Asset::verify_complete()` delegates to `Asset::validate()` and (in non-test builds) `validate_amount()` (range proof verification).

📌 `Asset::validate()` verifies the owner signature only when `owner_signature` is present. Therefore, `verify_complete()` does **NOT** guarantee that an owner signature exists.

🎯 This spec therefore defines additional mandatory import-time checks for signature presence based on asset type in CS-2.

📌 **Mandatory gate ordering (normative):**

🎯 The import acceptance gate MUST run in the exact order below, and MUST fail-closed at the first failure:

📌 `wire_decode → structural_validate → verify_complete → ownership_check → sign_claim_receipt → claim_registry_reserve → storage_put → claim_registry_finalize → audit_log`

📌 This ordering is critical because:
- `verify_complete` prevents cryptographically-invalid assets from ever reaching wallet-owned logic.
- `ownership_check` prevents importing foreign-but-valid assets.
- `claim_registry_reserve/finalize` prevents cross-wallet double-claim even when assets are otherwise valid.

📌 **Reservation semantics (normative, fixed):**

🎯 `claim_registry_reserve` MUST be reversible and MUST NOT permanently lock an asset if downstream steps fail.

✅ For Scenario 1 Stage 3, the reservation + finalize sequence MUST be executed inside the wallet RPC import handler (`AssetRpcImpl::import_asset`).

🚫 Stage 3 MUST NOT reserve claims before RPC.

📌 **Registry API requirement (normative):**

🎯 The global claim registry MUST expose a two-phase API (or equivalent transactional behavior):
- `reserve(asset_id, wallet_id, claim_receipt)` (reversible)
- `finalize(asset_id)` (irreversible)
- `release(asset_id)` (undo reserve on failure)

🎯 A single-phase `try_claim()` API is only acceptable if it is used strictly as **finalize** after all failure points are eliminated (i.e., no downstream operations can fail).

📌 **Correct import flow (normative, simplest and safest):**

🎯 Stage 3 MUST call RPC `import_asset(wire)` and MUST NOT perform any claim reservation or receipt signing.

🎯 Wallet RPC `import_asset` MUST execute strictly in this order:

📌 `wire_decode`

📌 `structural_validate`

📌 `verify_complete`

📌 `ownership_check`

📌 build `ClaimReceipt` and sign it (`sign_claim_receipt`)

📌 `claim_registry_reserve(asset_id, wallet_id, receipt)`

📌 `storage_put`

📌 `claim_registry_finalize`

📌 `audit_log`

🎯 On `storage_put == Ok` + `claim_registry_finalize != Ok` ⇒ quarantine (as defined below), and MUST NOT release reservation.

📌 **Finalize failure handling (TOCTOU hardening) — normative:**

🎯 If `storage_put` succeeds but `claim_registry_finalize` fails, the system MUST ensure that the asset cannot be double-claimed or spent under an ambiguous global-claim state.

✅ Mandatory behavior:
- The Stage 3 run MUST return a hard failure (no “StageResult::Ok” / no success snapshot) when any `finalize` fails.
- The reservation MUST NOT be released in this failure mode (releasing would re-open a double-claim window).
- The claim registry MUST be able to retry `finalize` idempotently (repeatable without changing the intended winner).

✅ Mandatory wallet behavior (quarantine):
- The wallet MUST mark such an imported asset as `quarantined_unfinalized` (or equivalent state) until finalize succeeds.
- Quarantined assets MUST NOT be spendable and MUST NOT be counted as available balance.
- On resume, the wallet/stage MUST retry finalize for all quarantined assets before declaring Stage 3 success.

📏 Invariant (safety): `storage_put == Ok && finalize != Ok => asset_not_spendable && other_wallet_cannot_claim`.

🚫 **MUST NOT:**
- MUST NOT treat `AssetWire::to_asset()` + `validate()` as sufficient for live acceptance.
- MUST NOT insert into cache/storage before `verify_complete()` succeeds.

📏 **Invariant:** `accepted_asset => verify_complete == Ok(())`.

🧪 **Acceptance evidence:** Tampered signature, commitment, or range proof is rejected at import time.

**Implementation Checklist:**
- [x] **CS-1.1** In `crates/z00z_wallets/src/adapters/rpc/methods/asset_impl.rs` at `import_asset()` (~line 788): after `wire.to_asset()` succeeds, add call `asset.verify_complete().map_err(|e| ImportError::CryptoVerifyFailed(e))?`.
- [x] **CS-1.2** In `crates/z00z_core/src/assets/wire.rs` at `AssetWire::to_asset()` (~line 397): document explicitly that this function only validates structural wire format; it does NOT replace `verify_complete()`.
- [x] **CS-1.3** In `crates/z00z_core/src/assets/assets.rs`: confirm `Asset::verify_complete()` (~line 1652) calls both `validate()` and `validate_amount()` (range proof) and is not gated behind a debug flag.
- [x] **CS-1.4** Add positive path test: valid asset passes import without error.
- [x] **CS-1.5** Add negative test `test_import_tampered_sig`: flip one byte in `owner_signature` field → import MUST reject with `CryptoVerifyFailed`.
- [x] **CS-1.6** Add negative test `test_import_tampered_commitment`: replace commitment bytes → import MUST reject.
- [x] **CS-1.7** Add negative test `test_import_invalid_range_proof`: supply malformed range proof → import MUST reject.
- [x] **CS-1.8** Tests live in `crates/z00z_simulator/tests/` or `crates/z00z_wallets/tests/`; run with `cargo test -p z00z_wallets --test test_asset_import_security`.
- [x] **CS-1.9** No feature flag may gate `verify_complete()` off in release builds.
- [x] **CS-1.10** In `crates/z00z_wallets/src/adapters/rpc/methods/asset_impl.rs`: enforce the gate order as written above; specifically: `verify_complete()` MUST run before ownership binding (CS-2) and before claim registry (CS-5).
- [x] **CS-1.11** Update negative tests to avoid false positives caused by `#[cfg(not(test))]` gates:
	- unit tests MUST directly call `asset.verify_range_proof()` (or `asset.validate_amount()`) and assert failure
	- integration tests against RPC MUST be executed in a configuration where the live import path performs the same checks as release (no hidden “test disables verification” behavior)
- [x] **CS-1.12** Add failure-injection integration test `test_finalize_fail_quarantine`: simulate `storage_put == Ok` then force `claim_registry_finalize` to fail; assert:
	- Stage 3 returns an error (no success snapshot)
	- reservation is NOT released
	- asset is present in wallet storage but flagged as quarantined/unfinalized
	- asset is not spendable / not in available balance

---

### CS-2 — Ownership Binding to Wallet Identity

🎯 **Goal:** Wallet must import only assets provably belonging to that wallet.

📌 **Target functions:**
- `AssetRpcImpl::import_asset`
- wallet ownership verification helper (new)
- session wallet context resolution

✅ **MUST rules:**
- Import must derive expected wallet ownership identity from active session wallet context.
- Asset ownership proof MUST be matched against wallet identity (owner handle and/or equivalent canonical owner binding).
- If ownership proof does not match active wallet, import MUST be rejected.
- Ownership verification MUST run for each asset independently.

📌 **Ownership proof sources (normative):**

🎯 Ownership binding MUST be performed using wallet-owned key material, not caller-provided metadata.

📌 **Transparent assets (owner signature mode):**
- If `asset.is_transparent()` then `asset.owner_pub` MUST be `Some`.
- Wallet MUST reject import unless the wallet can prove it controls the secret key corresponding to `asset.owner_pub` under a wallet-defined transparent-ownership policy.
- For transparent imports, `asset.owner_signature` MUST be `Some` and MUST be verified as valid.

📌 **Transparent ownership policy (normative, fixed for Scenario 1 Stage 3):**

🎯 Scenario 1 Stage 3 MUST use **Policy A (keyring membership)**.

✅ **Policy A (keyring membership):**
- Wallet maintains an allowlist/set of wallet-owned transparent owner public keys (e.g., derived spend keys up to configured gap limits).
- Import MUST accept only if `asset.owner_pub ∈ wallet_owner_pubkey_set`.

🚫 **Policy B (proof-of-control challenge) is legacy for Scenario 1 Stage 3 and MUST NOT be active in this build.**

🚫 Forbidden:
- MUST NOT compare to a single fixed wallet-wide public key unless the protocol explicitly defines that transparent assets are issued to a fixed identity key (this would be a privacy regression and MUST be explicitly justified).

📌 **Stealth assets (receiver scan mode):**
- If `asset.is_stealth()` then ownership MUST be proven by decrypting/verifying the stealth payload under wallet view keys.
- Wallet MUST reject import unless it can reproduce the decryption/opening check used by scanning primitives.

📌 **Signature requirement clarification (normative):**

🎯 Stealth assets MUST be accepted/rejected based on the stealth ownership predicate (decrypt + commitment opening verification).

🎯 A stealth asset MAY carry `owner_signature`; if present, it MUST be verified (fail-closed on invalid signature).

🎯 Transparent assets MUST always require a valid `owner_signature` (no signature-less transparent imports).

📌 **Single source of truth for transparent policy (normative):**

🎯 The build MUST guarantee that exactly one transparent policy is active.

✅ Recommended implementation shape:

```rust
#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub enum OwnershipPolicy {
	Keyring,
}

pub const TRANSPARENT_OWNERSHIP_POLICY: OwnershipPolicy = OwnershipPolicy::Keyring;
```

✅ Recommended build-time mutex using features:

```toml
# crates/z00z_wallets/Cargo.toml
[features]
default = ["ownership_policy_keyring"]

ownership_policy_keyring = []
ownership_policy_challenge = []
```

```rust
// crates/z00z_wallets/src/lib.rs (or a small module imported from lib.rs)
#[cfg(all(feature = "ownership_policy_keyring", feature = "ownership_policy_challenge"))]
compile_error!("Enable exactly one: ownership_policy_keyring OR ownership_policy_challenge");

#[cfg(not(any(feature = "ownership_policy_keyring", feature = "ownership_policy_challenge")))]
compile_error!("Enable exactly one: ownership_policy_keyring OR ownership_policy_challenge");
```

📌 **Reference primitives already present (MUST reuse):**
- `crates/z00z_wallets/src/core/address/leaf_scan.rs` (`receiver_scan_leaf`) performs the tag16 prefilter, decrypts the pack, and calls `verify_commitment_opening`.
- `crates/z00z_wallets/src/core/address/stealth_scanner.rs` contains scan primitives and data structures for stealth outputs.

🚫 **MUST NOT:**
- MUST NOT allow a validly signed asset to be imported by an unrelated wallet.
- MUST NOT rely on caller-provided wallet metadata without cryptographic binding.

📏 **Invariant:** `wallet_id != owner_of_asset => import_rejected`.

🧪 **Acceptance evidence:** Import attempt by wrong wallet fails deterministically with explicit reason.

**Implementation Checklist:**
- [x] **CS-2.1** In `crates/z00z_wallets/src/adapters/rpc/methods/asset_impl.rs` at `import_asset()`: after session validation, extract active wallet key context needed for ownership verification:
	- transparent: wallet-owned public key set (Policy A)
	- stealth: wallet `ReceiverKeys` (or view key material) required for decrypt/opening
- [x] **CS-2.2** Create helper module `crates/z00z_wallets/src/adapters/rpc/methods/ownership_check.rs` exposing:
	- `check_transparent_ownership(asset: &Asset, ctx: &WalletOwnershipCtx) -> Result<(), ImportError>`
	- `check_stealth_ownership(asset: &Asset, keys: &ReceiverKeys) -> Result<(), ImportError>`
- [x] **CS-2.3** `check_transparent_ownership` MUST enforce:
	- `asset.owner_pub.is_some()` AND `asset.owner_signature.is_some()`
	- `asset.verify_owner_signature()` succeeds
	- plus Policy A acceptance (keyring membership)
- [x] **CS-2.4** Call both `check_*_ownership` and `asset.verify_complete()` in `import_asset()` before `storage.put()`.
- [x] **CS-2.5** Add stealth ownership path: create helper `check_stealth_ownership(asset: &Asset, receiver_keys: &ReceiverKeys) -> Result<(), ImportError>` in `crates/z00z_wallets/src/core/address/` (recommended: `claim_ownership.rs`) that reuses `receiver_scan_leaf`-equivalent logic to prove wallet can decrypt and pass `verify_commitment_opening`.
- [x] **CS-2.6** In `import_asset()`: route ownership check by `asset.payment_type()`:
	- transparent → enforce Policy A (keyring membership)
	- stealth → run stealth decrypt/opening check using wallet `ReceiverKeys`
- [x] **CS-2.7** Add positive path test: wallet imports its own asset.
- [x] **CS-2.8** Add negative test `test_import_wrong_wallet`: sign asset for wallet A, attempt import to wallet B → MUST reject with `OwnerMismatch`.
- [x] **CS-2.9** Add negative test `test_import_no_owner_field`: asset missing `owner_pub`/`owner_tag` → MUST reject (not silently accept).
- [x] **CS-2.10** Tests run with `cargo test -p z00z_wallets --test test_asset_ownership_security`.
- [x] **CS-2.11** Ownership check MUST execute for every individual asset, not once per batch.
- [x] **CS-2.12** Add stealth negative test `test_import_stealth_not_mine`: craft a stealth asset addressed to wallet A, attempt import to wallet B → MUST reject deterministically (not "MaybeMine").
- [x] **CS-2.13** Add stealth positive test `test_import_stealth_mine`: craft a stealth asset addressed to wallet A, import to wallet A → MUST accept.
- [x] **CS-2.14** Add transparent negative test `test_import_transparent_unsigned_rejected`: a transparent asset with `owner_pub=Some` and `owner_signature=None` MUST be rejected.
- [x] **CS-2.15** Add transparent negative test `test_import_transparent_bad_sig_rejected`: flip one byte in signature → MUST reject.
- [x] **CS-2.16** Policy mutex CI-guard: The chosen transparent ownership policy (A or B) MUST be the only active code path at build time. Add a compile-time or test-time assertion that only one policy branch is reachable:
	- Required: use a single `TRANSPARENT_OWNERSHIP_POLICY` constant and route all checks through it.
	- Required: add feature mutex `compile_error!` guards so both policies cannot be enabled simultaneously.
	- Add test `test_policy_mutex`: assert the disabled policy returns `PolicyDisabled`.
	- Add CI lint step: confirm no code path executes both policy implementations in one build.

---

### CS-3 — Stealth Field Consistency Enforcement

🎯 **Goal:** Stealth fields must be structurally complete and self-consistent.

📌 **Target functions:**
- `Asset::validate_stealth_consistency`
- import path pre-accept checks

✅ **MUST rules:**
- If any of `r_pub`, `owner_tag`, `enc_pack` is present, all required stealth fields MUST satisfy consistency policy.
- `tag16` presence MUST obey stealth consistency constraints.
- `secret` handling MUST comply with explicit policy (allowed/forbidden) for imported artifacts.

🚫 **MUST NOT:**
- MUST NOT accept partial stealth payloads.
- MUST NOT accept stealth metadata that cannot be verified against ownership context.

📏 **Invariant:** `stealth_partial == true => reject`.

🧪 **Acceptance evidence:** Any malformed stealth tuple is rejected before storage.

**Implementation Checklist:**
- [x] **CS-3.1** In `crates/z00z_core/src/assets/assets.rs`: locate or add `validate_stealth_consistency()` method on `Asset`; it must verify: if any of (`r_pub`, `owner_tag`, `enc_pack`) is `Some`, all three must be `Some`; `tag16` presence must match policy for import context.
- [x] **CS-3.2** Call `validate_stealth_consistency()` inside `Asset::validate()` (~line 1175) or explicitly in `import_asset()` after `to_asset()`.
- [x] **CS-3.3** For imported artifacts, define and document explicit policy for `secret` field: MUST be `None` on imported wire (sender secrets must not travel with claimable asset).
- [x] **CS-3.4** Add rejection gate in `AssetWire::to_asset()` or `import_asset()`: if `secret` is `Some` on incoming wire, return `ImportError::SecretFieldForbidden`.
- [x] **CS-3.5** Add negative test `test_import_partial_stealth`: supply asset with `r_pub = Some`, `owner_tag = None` → MUST reject with stealth consistency error.
- [x] **CS-3.6** Add negative test `test_import_secret_present`: supply wire with non-None `secret` → MUST reject with `SecretFieldForbidden`.
- [x] **CS-3.7** Add positive test: non-stealth asset (all stealth fields `None`) imports cleanly.
- [x] **CS-3.8** Tests run with `cargo test -p z00z_core --test stealth_consistency` or in existing asset validation test suite.
- [x] **CS-3.9** Document policy in code comment at `validate_stealth_consistency()` declaration.

---

### CS-4 — Duplicate and Replay Protection (Per Wallet)

🎯 **Goal:** Prevent duplicate imports and idempotency abuse for one wallet.

📌 **Target functions:**
- `AssetStorageImpl::put`
- `AssetRpcImpl::import_asset`

✅ **MUST rules:**
- Storage MUST enforce uniqueness by canonical asset identity.
- Duplicate import in same wallet MUST return deterministic `already_exists` semantics.
- Duplicate path MUST NOT mutate balances, snapshots, or counters as new insert.

🚫 **MUST NOT:**
- MUST NOT count duplicate as a successful fresh claim.
- MUST NOT allow duplicate to modify asset state.

📏 **Invariant:** `same_wallet + same_asset_id => at_most_one_insert`.

🧪 **Acceptance evidence:** repeated identical import yields `already_exists` and zero new insertion.

**Implementation Checklist:**
- [x] **CS-4.1** Confirm `AssetStorageImpl::put()` in `crates/z00z_wallets/src/core/storage/asset_storage_impl.rs` (~line 72) already returns `AlreadyExists` on duplicate by canonical `asset_id` hex key — this is the existing mechanism.
- [x] **CS-4.2** Confirm that `import_asset()` in `asset_impl.rs` (~line 821) handles `AlreadyExists` by returning `ImportResponse { is_inserted: false, asset_already_exists: true }` and does NOT modify balance, counters, or snapshots.
- [x] **CS-4.3** Confirm no code path after `AlreadyExists` fires that updates any aggregate state (search for any write after the `AlreadyExists` arm in `import_asset`).
- [x] **CS-4.4** Add test `test_duplicate_import_idempotent`: import same asset twice to same wallet → second response has `asset_already_exists=true`, balance unchanged.
- [x] **CS-4.5** Add test `test_replay_no_balance`: call import N times, assert final wallet balance equals single-import balance.
- [x] **CS-4.6** Add test `test_replay_no_snapshot`: snapshot written after first import equals snapshot after N re-imports.
- [x] **CS-4.7** Tests run with `cargo test -p z00z_wallets --test test_asset_replay_protection`.

---

### CS-5 — Double-Claim Prevention (Cross Wallet)

🎯 **Goal:** One claimable asset instance must not be claimed by multiple wallets.

📌 **Target functions/components:**
- global claim registry (new)
- `stage_3` claim dispatch path
- wallet import gate

✅ **MUST rules:**
- System MUST maintain globally unique claim state for claimable asset identity.
- Claim assignment MUST atomically reserve asset for one wallet before import.
- Second claim attempt for same asset identity MUST be rejected as conflict.
- Conflict rejection MUST be deterministic and auditable.

✅ **MUST rules (finalize failure):**
- Finalize failure handling MUST follow CS-1 “Finalize failure handling (TOCTOU hardening)”.

📌 **Wallet binding artifact (normative): Claim Receipt**

🎯 Cross-wallet protection MUST be backed by a wallet-signed claim receipt so that claim assignment is cryptographically attributable to a specific wallet.

📌 **Minimal claim receipt format (ClaimReceipt):**

📌 Fields (serialized bytes, signature excluded):
- `schema_version: u8` = `1`
- `asset_id: [u8; 32]` (canonical `asset.asset_id()`)
- `wallet_id: bytes` (canonical wallet id bytes derived from authenticated session wallet context; length-prefixed as `u16_le || bytes`)
- `claim_scope_hash: [u8; 32]` (domain-separated hash binding to Scenario/Stage and chain identity)
- `identity_pk: [u8; 32]` (wallet identity public key used for receipt verification)

📌 **Canonical byte encoding (MUST):**

🎯 `asset_id` MUST be the raw `[u8; 32]` returned by `asset.asset_id()`.

🎯 `wallet_id` MUST be derived from the authenticated session wallet context inside the wallet RPC handler.

🚫 `wallet_id` MUST NOT be accepted from caller-provided request fields.

🎯 `identity_pk` MUST be the canonical compressed byte encoding used by `verify_identity()` (the same bytes the verifier consumes).

📌 Signature:
- `wallet_claim_sig: KernelSignature` created by signing the serialized fields (including `identity_pk`) under a dedicated domain/context label.

📌 Signing key (MUST):
- Use wallet **identity secret key** derived from receiver secret key material.
- Implementation MUST use existing primitives in `crates/z00z_wallets/src/core/key/stealth_keys.rs`: `sign_identity()` and `verify_identity()`.

📌 Verification key (MUST):
- Global claim registry MUST verify receipts using `identity_pk` and MUST store `identity_pk` alongside `wallet_id`.
- A claim MUST be treated as unauthenticated if `identity_pk` is missing.

📌 **wallet_id ↔ identity_pk binding (MUST):**

🎯 For Scenario 1 Stage 3, the system MUST use **Authenticated wallet registry mapping**:
- The wallet MUST persist a trusted mapping `wallet_id → identity_pk` created at wallet initialization.
- Claim registry MUST reject any receipt where `receipt.identity_pk != expected_identity_pk(wallet_id)`.

🚫 Deterministic binding `wallet_id = H(identity_pk)` MUST NOT be used in Scenario 1 Stage 3.

📌 Context label (MUST):
- `b"z00z.wallet.claim_receipt.v1"` (domain separation so claim receipts cannot be replayed as other signatures).

📌 **Canonical receipt message encoding (MUST):**

🎯 Implementations MUST use the exact same encoding for signing and verification.

✅ Recommended encoding:
- Build `message_bytes = schema_version || asset_id || wallet_id_len || wallet_id_bytes || claim_scope_hash || identity_pk`.
- Call `sign_identity(identity_sk, &message_bytes, b"z00z.wallet.claim_receipt.v1")`.
- Verify with `verify_identity(identity_pk, &message_bytes, b"z00z.wallet.claim_receipt.v1", signature)`.

🚫 **MUST NOT:**
- MUST NOT rely only on per-wallet duplicate checks to prevent global double-claim.

📏 **Invariant:** `asset_identity` can transition `unclaimed -> claimed(wallet_x)` exactly once.

🧪 **Acceptance evidence:** same asset import to wallet A then wallet B results in B rejection.

**Implementation Checklist:**
- [x] **CS-5.1** Create `crates/z00z_wallets/src/core/storage/claim_registry.rs` implementing `GlobalClaimRegistry` with a two-phase API:
	- `reserve(asset_id, wallet_id, receipt) -> Result<Reservation, ClaimConflict>`
	- `finalize(reservation) -> Result<(), ClaimFinalizeError>`
	- `release(reservation) -> ()` (best-effort)
- [x] **CS-5.1a** Minimal interface (recommended shape) and crate placement:
	- Define the **trait + types** in `z00z_wallets` (because `import_asset` is the security gate and owns receipt signing).
	- Implement persistence either in `z00z_wallets` initially or behind a thin adapter to `z00z_storage` later.

```rust
pub struct ClaimReservation {
	pub asset_id: [u8; 32],
	pub wallet_id: String,
}

#[derive(Debug)]
pub struct ClaimConflict {
	pub claimed_by: String,
}

pub trait GlobalClaimRegistry: Send + Sync {
	fn reserve(
		&self,
		asset_id: [u8; 32],
		wallet_id: &str,
		receipt: &ClaimReceipt,
		receipt_sig: &KernelSignature,
	) -> Result<ClaimReservation, ClaimConflict>;

	fn finalize(&self, reservation: &ClaimReservation) -> Result<(), ClaimFinalizeError>;

	fn release(&self, reservation: &ClaimReservation);
}
```
- [x] **CS-5.2** `reserve` MUST be linearizable (first caller wins). Conflicts MUST return `ClaimConflict { already_claimed_by: wallet_id }`.
- [x] **CS-5.3** The wallet import RPC MUST drive reserve/finalize as part of the CS-1 gate ordering.
- [x] **CS-5.4** Stage 3 MUST NOT pre-reserve; it MUST call RPC `import_asset(wire)` and rely on the wallet RPC to execute reserve/finalize.
- [x] **CS-5.4a** Receipt signing authority (MUST): **only the wallet RPC handler** (`import_asset`) is permitted to call `sign_claim_receipt()`. Stage 3 orchestrator MUST NOT sign receipts on behalf of any wallet. Enforcement: `sign_claim_receipt()` MUST be called exclusively from within the wallet's trust boundary (inside `AssetRpcImpl::import_asset` or an authenticated wallet method it calls). Add CI lint: `grep -rn "sign_claim_receipt" crates/z00z_simulator/` MUST return 0 matches.
- [x] **CS-5.5** Choose explicit conflict semantics: first-claimant wins, no silent downgrades.
- [x] **CS-5.6** Create `crates/z00z_wallets/src/core/claim/claim_receipt.rs` defining `ClaimReceipt` (fields above) and `fn sign_claim_receipt(keys: &ReceiverKeys, receipt: &ClaimReceipt) -> Result<KernelSignature, WalletError>`.
- [x] **CS-5.7** Implement `claim_scope_hash` inside wallet code (not Stage 3) from stable components controlled by the wallet runtime: `{scenario_id="scenario_1", stage="stage_3", chain_identity}`; hash MUST be domain-separated.
	- The hash MUST NOT include per-run values that Stage 3 can influence.
- [x] **CS-5.8** Claim registry MUST store `{asset_id -> (wallet_id, identity_pk, claim_receipt_sig, claim_scope_hash)}` as the canonical claim record.
- [x] **CS-5.9** Add unit test `test_claim_receipt_sign_verify`: sign receipt with wallet A identity key; verify succeeds for A and fails for B.
- [x] **CS-5.10** Add integration test `test_double_claim_receipt`: A claims asset (receipt stored) then B attempts claim → MUST reject with `ClaimConflict`, and the stored record MUST include A's signature.
- [x] **CS-5.10a** Extend the claim record to store `identity_pk` and assert receipt verification uses `verify_identity()` with domain context `b"z00z.wallet.claim_receipt.v1"`.
- [x] **CS-5.11** Add positive test `test_single_claim_succeeds`: one wallet claims an asset → success.
- [x] **CS-5.12** Add negative test `test_cross_wallet_double_claim`: wallet A claims asset → wallet B attempts same asset identity → MUST reject with `ClaimConflict`.
- [x] **CS-5.13** Add test `test_double_claim_audit_log`: both claim attempts appear in audit log with distinct outcome codes.
- [x] **CS-5.14** Tests run with `cargo test -p z00z_simulator --test cross_wallet_claim`.
- [x] **CS-5.15** Registry MUST persist across resume (see CS-10); document restart/recovery semantics.

---

### CS-6 — Realtime Amount and Commitment Conservation

🎯 **Goal:** Enforce amount and commitment conservation during live claim processing.

📌 **Target functions/components:**
- `run_claim_genesis` post-distribution gate
- live verification module for sums (new or integrated)

✅ **MUST rules:**
- Before final stage success, system MUST verify sum(amount) conservation across input and assigned/imported sets.
- Before final stage success, system MUST verify homomorphic commitment sum conservation (`ΣC_in == ΣC_out`) for claim scope.
- Stage completion MUST fail if any conservation check fails.

🚫 **MUST NOT:**
- MUST NOT keep these checks only in test files.
- MUST NOT emit StageResult::Ok when conservation checks fail or are skipped.

📏 **Invariant:** `stage3_ok => amounts_conserved && commitments_conserved`.

🧪 **Acceptance evidence:** injected mismatch triggers deterministic stage failure.

**Implementation Checklist:**
- [x] **CS-6.1** Move or replicate the conservation check logic from `crates/z00z_simulator/tests/test_claim_crypto.rs` (~lines 155-184) into a new function `verify_claim_conservation(input: &[Asset], imported: &[Asset]) -> Result<(), ConservationError>` inside `crates/z00z_simulator/src/scenario_1/stage_3.rs` or a new module `conservation.rs`.
- [x] **CS-6.2** `verify_claim_conservation` MUST assert: `sum(input.amount) == sum(imported.amount)` and `sum(input.commitment) == sum(imported.commitment)` (homomorphic Pedersen sum via `z00z_crypto` algebra).
- [x] **CS-6.3** Call `verify_claim_conservation()` in `run_claim_genesis()` after all imports are completed and before emitting `StageResult::Ok`.
- [x] **CS-6.4** If conservation fails, return `StageError::ConservationViolation` — this is a hard stage failure.
- [x] **CS-6.5** Remove the `#![cfg(feature = "wallet_debug_dump")]` gate from the conservation assertions if they remain in tests, OR ensure the runtime copy is unconditionally compiled.
- [x] **CS-6.6** Add runtime test `test_stage3_conservation_ok`: normal run passes conservation check.
- [x] **CS-6.7** Add runtime test `test_stage3_conservation_fail_amount`: inject one extra unit into an imported amount → stage MUST fail with `ConservationViolation`.
- [x] **CS-6.8** Add runtime test `test_stage3_conservation_fail_commitment`: mutate one commitment → stage MUST fail.
- [x] **CS-6.9** Tests run with `cargo test -p z00z_simulator --test stage3_conservation` (no special feature flag required).

---

### CS-7 — Signature Domain and Message Integrity

🎯 **Goal:** Owner signatures must remain bound to canonical asset message.

📌 **Target functions:**
- `Asset::to_owner_message`
- `Asset::verify_owner_signature`

✅ **MUST rules:**
- Signature verification MUST use canonical message layout exactly.
- Any mutation in signed fields MUST invalidate signature.
- Domain separation for owner signatures MUST remain enforced.

🚫 **MUST NOT:**
- MUST NOT accept alternate field ordering or partial signed payloads.
- MUST NOT allow fallback verification modes.

📏 **Invariant:** `mutate_signed_field => verify_owner_signature == Err`.

🧪 **Acceptance evidence:** tampering with amount/nonce/commitment/range-proof fails verification.

**Implementation Checklist:**
- [x] **CS-7.1** Audit `Asset::to_owner_message()` in `crates/z00z_core/src/assets/assets.rs` (~line 1397): confirm the canonical message concatenates exactly: `definition_id || serial_id || amount_bytes || commitment_bytes || nonce || lock_height || range_proof_bytes || flags`.
- [x] **CS-7.2** If any field is missing from `to_owner_message()`, add it and update all callers/tests.
- [x] **CS-7.3** In `Asset::verify_owner_signature()` (~line 1584): confirm it calls `to_owner_message()` for the message, not a cached or partial version.
- [x] **CS-7.4** Confirm domain separation: if `hash_domain!` macro or equivalent is used, document which domain label is bound to owner signatures; this label MUST differ from any other signature domain in the codebase.
- [x] **CS-7.5** Add tamper test `test_sig_tamper_amount`: change `amount` after signing → `verify_owner_signature` MUST return `Err`.
- [x] **CS-7.6** Add tamper test `test_sig_tamper_nonce`: change `nonce` → MUST fail.
- [x] **CS-7.7** Add tamper test `test_sig_tamper_commitment`: change commitment bytes → MUST fail.
- [x] **CS-7.8** Add tamper test `test_sig_tamper_range_proof`: change range proof bytes → MUST fail.
- [x] **CS-7.9** Add tamper test `test_sig_tamper_lock_height`: change `lock_height` → MUST fail.
- [x] **CS-7.10** Tests run with `cargo test -p z00z_core --test asset_signature_domain`.

---

### CS-8 — Strict Error Taxonomy and RPC Mapping

🎯 **Goal:** Rejection reasons must be explicit, stable, and machine-parseable.

📌 **Target functions/components:**
- `AssetRpcImpl::import_asset`
- RPC error mapping layer

✅ **MUST rules:**
- Ownership mismatch, crypto invalidity, duplicate, and conflict MUST map to distinct error codes/messages.
- Error messages MUST be deterministic and non-ambiguous.
- Security-sensitive reject paths MUST be logged with structured fields.

🚫 **MUST NOT:**
- MUST NOT collapse all failures into generic `invalid asset`.

📏 **Invariant:** each reject class has unique code + stable text key.

🧪 **Acceptance evidence:** integration tests assert exact error code/message class per failure type.

**Implementation Checklist:**
- [x] **CS-8.1** Define `ImportRejectReason` enum in `crates/z00z_wallets/src/adapters/rpc/methods/asset_impl.rs` or a new file `import_errors.rs` with variants: `CryptoVerifyFailed`, `OwnerMismatch`, `StealthInconsistent`, `SecretFieldForbidden`, `AlreadyExists`, `ClaimConflict`, `ConservationViolation`, `SessionInvalid`.
- [x] **CS-8.2** Each variant MUST map to a distinct, stable RPC status code string (e.g., `"IMPORT_CRYPTO_VERIFY_FAILED"`) documented in the enum.
- [x] **CS-8.3** Replace all generic error returns in `import_asset()` with `ImportRejectReason` variants.
- [x] **CS-8.4** Add structured logging in each rejection arm: `tracing::warn!(reason = %code, asset_id = %id, wallet = %wid, "import rejected")`.
- [x] **CS-8.5** Add integration test `test_error_codes_distinct`: call import with each failure condition in turn; assert response codes are non-empty and distinct per condition.
- [x] **CS-8.6** Add test `test_error_no_generic_collapse`: ensure no two distinct failure types produce the same error code.
- [x] **CS-8.7** Tests run with `cargo test -p z00z_wallets --test test_import_error_taxonomy`.
- [x] **CS-8.8** Document the error taxonomy table in a `/// # Errors` section of `import_asset()` doc comment.

---

### CS-9 — Stage 3 Snapshot Integrity Rules

🎯 **Goal:** Snapshot outputs must be cryptographically and numerically coherent with runtime actions.

📌 **Target artifacts:**
- `outputs/claim/stage_3_snapshot.json`
- per-actor claim files

✅ **MUST rules:**
- `input_assets_count` MUST equal loaded input count.
- `distributed_assets_count` MUST equal sum of per-actor assigned assets.
- `wallet_import_stats` MUST reconcile with actor claim counts.
- Snapshot write MUST happen only after all mandatory checks pass.

🚫 **MUST NOT:**
- MUST NOT persist success snapshot when import/check stages partially failed.

📏 **Invariant:** snapshot is a post-verified state, never pre-verified state.

🧪 **Acceptance evidence:** reconciliation tests pass for all actors and totals.

**Implementation Checklist:**
- [x] **CS-9.1** In `crates/z00z_simulator/src/scenario_1/stage_3.rs`, at snapshot construction (~line 487), add a `reconcile_snapshot(snapshot: &Stage3Snapshot) -> Result<(), SnapshotError>` call before writing to disk.
- [x] **CS-9.2** `reconcile_snapshot` MUST assert: `snapshot.input_assets_count == sum_of_loaded_inputs`, `snapshot.distributed_assets_count == sum_of_per_actor_assignments`, `snapshot.wallet_import_stats.total_inserted + snapshot.wallet_import_stats.total_already_exists == snapshot.distributed_assets_count`.
- [x] **CS-9.3** If any reconciliation assertion fails, return `SnapshotError::Mismatch` — do NOT write the snapshot file.
- [x] **CS-9.4** Snapshot file MUST be written atomically (temp file + rename) to prevent partial state; use `z00z_utils::io::write_file` per ONE_SOURCE_OF_TRUTH principle.
- [x] **CS-9.5** Add test `test_snapshot_reconciliation_ok`: normal stage 3 run produces reconciled snapshot.
- [x] **CS-9.6** Add test `test_snapshot_reconciliation_count_mismatch`: inject discrepancy in distributed count → snapshot write MUST fail with `SnapshotError::Mismatch`.
- [x] **CS-9.7** Add test `test_snapshot_no_write`: abort stage at midpoint; snapshot file MUST NOT exist.
- [x] **CS-9.8** Tests run with `cargo test -p z00z_simulator --test stage3_snapshot`.

---

### CS-10 — Resume/Idempotency Safety

🎯 **Goal:** Recovery from partial state must not allow duplication or bypass verification.

📌 **Target functions/components:**
- `claim_state.json` handling in stage 3
- resume branch logic

✅ **MUST rules:**
- Resume path MUST re-run mandatory ownership+crypto checks for pending imports.
- Resume path MUST be idempotent regarding already imported assets.
- State transitions MUST be monotonic and validated.

🚫 **MUST NOT:**
- MUST NOT treat resumed artifacts as trusted without verification.

📏 **Invariant:** any number of safe retries yields same final state as single successful run.

🧪 **Acceptance evidence:** crash simulation at intermediate step does not create duplicates and does not skip checks.

**Implementation Checklist:**
- [x] **CS-10.1** In `crates/z00z_simulator/src/scenario_1/stage_3.rs`, at claim state load branch: when resuming from existing `claim_state.json`, MUST re-run `verify_complete()` + ownership binding for every asset still pending import (not yet in `already_claimed` set).
- [x] **CS-10.2** Already-inserted assets (present in per-wallet storage) MUST be detected via `AlreadyExists` path — they MUST NOT be re-processed as fresh claims.
- [x] **CS-10.3** State transitions in `claim_state.json` MUST be monotonic: `pending → claimed` is irreversible; MUST NOT regress to `pending` on resume.
- [x] **CS-10.4** `GlobalClaimRegistry` (CS-5) MUST be rehydrated from `claim_state.json` on resume so cross-wallet protection remains active.
- [x] **CS-10.5** Add test `test_resume_idempotent`: simulate abort after 50% imports, resume, verify final state equals single-run result.
- [x] **CS-10.6** Add test `test_resume_no_bypass_verify`: resume path with a tampered-asset in pending set → MUST reject (not skip verify because it was "already seen").
- [x] **CS-10.7** Add test `test_resume_no_double_count`: resume after partial run; total inserted count == expected single-run count.
- [x] **CS-10.8** Tests run with `cargo test -p z00z_simulator --test stage3_resume`.

---

### CS-11 — Runtime Enforcement (Not Test-Only)

🎯 **Goal:** Security controls must execute in production code paths.

📌 **Target areas:**
- wallet RPC import path
- stage 3 runtime path
- optional local verifier path if used

✅ **MUST rules:**
- Critical checks MUST be located in runtime functions, not only in tests.
- Build mode MUST NOT disable core safety checks in release.
- Any placeholder verifier/stub in live path MUST be replaced before release gating.

🚫 **MUST NOT:**
- MUST NOT rely on `tests/test_claim_crypto.rs` as sole enforcement mechanism.

📏 **Invariant:** release runtime independently guarantees claim correctness.

🧪 **Acceptance evidence:** runtime integration tests fail when checks are intentionally bypassed.

**Implementation Checklist:**
- [x] **CS-11.1** In `crates/z00z_wallets/src/core/tx/tx_verifier.rs`: replace stub implementations (`Ok(false)` / `"not implemented Phase 1"`) with real cryptographic delegations to `z00z_core` or `z00z_crypto`.
- [x] **CS-11.2** In `crates/z00z_wallets/src/core/wallet/wallet.rs` (~line 719): replace the labeled "Phase 1 structural stub" `import_asset` with a real implementation that delegates to `AssetStorageImpl` and runs the full gate chain (CS-1 through CS-9).
- [x] **CS-11.3** In `crates/z00z_wallets/src/services/wallet_service.rs` (~line 711): replace `reachability_wallet.import_asset` stub delegation with real processing.
- [x] **CS-11.4** In `crates/z00z_simulator/src/scenario_1/stage_2.rs` (~line 1161): inject `asset_storage` into runtime transport for the asset RPC handler so it has access to storage-backed import path.
- [x] **CS-11.5** Add CI lint step: `grep -rn "not implemented Phase 1" crates/ | grep -v "#\[cfg(test)\]"` MUST return 0 matches before release gating.
- [x] **CS-11.6** Add CI lint step: `grep -rn "Phase 1 structural stub" crates/ --include="*.rs"` MUST return 0 matches.
- [x] **CS-11.7** Add runtime integration test `test_live_path_verify_complete`: configure full transport, import valid asset, confirm `verify_complete` was called (use tracing/log capture or test-observable hook).
- [x] **CS-11.8** Add runtime test `test_live_path_stub_removed`: mock a crypto failure; confirm the rejection propagates to the RPC response (not silently swallowed by a stub `Ok(false)`).
- [x] **CS-11.9** Tests run with `cargo test -p z00z_wallets --test test_live_path_enforcement`.

---

### CS-12 — Security Logging and Auditability

🎯 **Goal:** Every accepted/rejected claim action must be auditable.

📌 **Target components:**
- stage logger
- rpc logger
- claim event emitter

✅ **MUST rules:**
- Log record MUST include wallet id, asset identity, action, and result class.
- Reject log MUST include reject reason class and deterministic code.
- Event emission MUST happen after state is validated.

🚫 **MUST NOT:**
- MUST NOT log raw secrets, seed phrases, or private keys.

📏 **Invariant:** forensic reconstruction of claim decisions is possible from logs/events.

🧪 **Acceptance evidence:** audit test parses logs and reconstructs all claim outcomes.

**Implementation Checklist:**
- [x] **CS-12.1** In `import_asset()` in `asset_impl.rs`: add `tracing::info!` on successful import with structured fields: `wallet_id`, `asset_id`, `action = "import_accepted"`, `is_new = true/false`.
- [x] **CS-12.2** In each rejection arm of `import_asset()`: add `tracing::warn!` with fields: `wallet_id`, `asset_id`, `action = "import_rejected"`, `reason = %ImportRejectReason::variant_name()`.
- [x] **CS-12.3** In `run_claim_genesis()` in `stage_3.rs`: emit structured log per actor after all imports: `actor_id`, `claimed_count`, `skipped_count`, `conflict_count`.
- [x] **CS-12.4** MUST NOT log: raw secret bytes, private keys, seed phrases, or blinding factors. Add `// SECURITY: never log secret fields` comment near all log statements touching `Asset` fields.
- [x] **CS-12.5** After stage 3 completes: write machine-parseable `outputs/claim/audit_log.jsonl` containing one JSON line per claim decision with `{timestamp, wallet_id, asset_id, action, reason_code}`.
- [x] **CS-12.6** Add test `test_audit_log_complete`: run stage 3, parse `audit_log.jsonl`, assert one entry per asset with deterministic action code.
- [x] **CS-12.7** Add test `test_audit_log_no_secrets`: assert no log line contains private key or secret field patterns (regex scan).
- [x] **CS-12.8** Add test `test_audit_log_reject_traceable`: inject a reject condition, parse log, confirm reject reason code is present.
- [x] **CS-12.9** Tests run with `cargo test -p z00z_simulator --test audit_log_integrity`.
- [x] **CS-12.10** `audit_log.jsonl` write MUST use `z00z_utils::io::write_file` per ONE_SOURCE_OF_TRUTH principle.

---

### CS-13 — Wallet Persistence Consistency After Claim

🎯 **Goal:** Claimed assets accepted in Stage 3 MUST be persisted into wallet on-disk state, not only runtime memory/cache.

📌 **Problem statement (current contradiction):**

📌 Stage 3 currently shows successful import outcomes and large `export_wallet_debug_*.json`, while `.wlt` files remain size-stable.

📌 This creates an ambiguous state where claim results can appear successful in runtime/audit artifacts but are not guaranteed to survive restart in wallet persistence.

📌 File size deltas (for `.wlt` or any storage file) are **not** a valid correctness proof; only restart-stable semantic checks are valid.

✅ **MUST rules:**
- Accepted claim import (`IMPORT_ACCEPTED_NEW`) MUST update wallet persistent state for that wallet id before Stage 3 success is returned.
- Persistence target MUST be wallet-bound and durable across process restart.
- Persistence backend for claim acceptance MUST be a single release-runtime source of truth (no dual-path accept semantics).
- For Scenario 1 Stage 3, persistence behavior MUST be observable from wallet-owned durable artifacts under `outputs/wallets/` (directly in `.wlt` or a formally specified wallet persistence object with stable ownership and lifecycle).
- `export_wallet_debug_*.json` MUST be derived from persisted wallet state, not from ad-hoc in-memory enrichment that can diverge from durable state.
- Stage 3 success criteria MUST include persistence verification for each actor wallet.

📌 **Atomicity and ordering (normative):**

🎯 Claim acceptance MUST preserve global-claim and wallet-persistence consistency under crash/failure.

✅ Required ordering inside import runtime:
- `verify_complete` → `ownership_check` → `claim_registry_reserve` → `durable_storage_put` → `claim_registry_finalize`.

✅ On `durable_storage_put == Ok` and `finalize != Ok`:
- asset MUST remain non-spendable (quarantine),
- reservation MUST NOT be released,
- finalize retry MUST be idempotent.

✅ On `durable_storage_put != Ok`:
- import MUST fail closed,
- reservation MUST be released,
- no success status may be returned.

🚫 **MUST NOT:**
- MUST NOT treat runtime-only cache (`asset_list_cache`, in-memory storage, transient transport state) as sufficient evidence of wallet import success.
- MUST NOT report Stage 3 `Ok` when claim acceptance is not durable in wallet persistence.
- MUST NOT rely on `.wlt` file size increase as acceptance criterion.
- MUST NOT build security assertions from debug-only dumps.

📏 **Invariant:** `stage3_success => restart_safe_wallet_claim_state`.

🧪 **Acceptance evidence:** after Stage 3 success and process restart, wallet queries return the same claimed assets without re-import.

📌 **Required proof set (normative):**
- cold-restart verification for each actor wallet,
- persistence-vs-runtime equality check on asset ids/counts/class totals,
- deterministic failure evidence when durable put/finalize contract is broken.

**Implementation Checklist:**
- [x] **CS-13.1** In `crates/z00z_wallets/src/adapters/rpc/methods/asset_impl.rs`: document and enforce a single durable persistence path used by `import_asset` in release runtime.
- [x] **CS-13.2** In `crates/z00z_simulator/src/scenario_1/stage_2.rs` transport wiring: replace transient/in-memory-only asset persistence for Stage 3 with restart-durable wallet-bound persistence.
- [x] **CS-13.3** In `crates/z00z_simulator/src/scenario_1/stage_3.rs`: remove acceptance dependence on in-memory-only enrichment (`imported_assets_full` injection) as a source of truth.
- [x] **CS-13.4** Add integration test `test_claim_persist_survives_restart`:
	- run Stage 1-3,
	- recreate wallet RPC/runtime,
	- verify actor wallets still expose claimed assets,
	- verify no re-import required.
- [x] **CS-13.5** Add integration test `test_debug_dump_matches_persisted_wallet_state`: compare debug export with freshly loaded persisted wallet state.
- [x] **CS-13.6** Add explicit persistence evidence in `stage_3_snapshot.json` (e.g., `wallet_persist_ok: true` per actor or equivalent deterministic marker).
- [x] **CS-13.7** Add negative test `test_stage3_fail_if_persist_not_durable`: simulate persistence failure after acceptance; Stage 3 MUST fail closed.
- [x] **CS-13.8** Add deterministic restart test `test_claim_restart_state_equal`: compare pre-restart and post-restart wallet asset sets (`asset_id`, `class`, `amount`) for each actor.
- [x] **CS-13.9** Add contract test `test_finalize_after_durable_put_quarantine`: force finalize failure after durable put; assert quarantine/non-spendable + idempotent retry path.
- [x] **CS-13.10** Add contract test `test_no_success_on_runtime_only_cache`: force durable backend unavailable while cache path exists; import MUST reject and Stage 3 MUST fail.
- [x] **CS-13.11** Add CI guard: reject release if any Stage 3 success path executes with `asset_storage == None` in runtime transport wiring.
- [x] **CS-13.12** Add spec note in `tests-spec.md` coverage matrix linking CS-13 checks to both simulator and wallet suites.

---

## Release Gate (Hard Blockers)

🚨 Release is blocked unless all conditions below are true:

- [x] `import_asset` enforces `verify_complete()`.
- [x] Ownership binding check to session wallet is enforced.
- [x] Cross-wallet double-claim prevention exists and is tested.
- [x] Realtime amount + commitment conservation is enforced in stage runtime.
- [x] Resume path is idempotent and does not bypass checks.
- [x] Error taxonomy is explicit and test-locked.
- [x] Security checks run in release runtime, not only tests.
- [x] **Claimed assets are durably persisted in wallet on-disk state and survive restart; runtime-only cache is not used as acceptance source-of-truth** (CS-13).
- [x] **Transparent ownership policy is explicitly chosen (A or B), documented in code at the import gate, and CI-locked so both policy paths cannot be simultaneously active** (CS-2.16).
- [x] **Receipt signing is performed exclusively inside the wallet RPC trust boundary; Stage 3 orchestrator contains zero calls to `sign_claim_receipt()`; CI lint confirms this** (CS-5.4a).

---

## Audit Gap Index

📌 Individual gaps identified by code-level audit (2026-02-28) and their CS-* mapping:

| Gap | Severity | Location | Addressed by |
|-----|----------|----------|--------------|
| G1: `import_asset` skips `verify_complete()` | CRITICAL | `asset_impl.rs:788`, `wire.rs:397` | CS-1 |
| G2: No wallet ownership binding on import | CRITICAL | `asset_impl.rs:788` | CS-2 |
| G3: No cross-wallet double-claim registry | CRITICAL | no global registry exists | CS-5 |
| G4: `LocalVerifierImpl` all stubs | HIGH | `local_verifier.rs:113-136` | CS-11 |
| G5: Conservation check only in test file | HIGH | `test_claim_crypto.rs:155-184` | CS-6 |
| G6: `wallet.import_asset` is labeled stub | HIGH | `wallet.rs:719`, `wallet_service.rs:711` | CS-11 |
| G7: `asset_storage` not injected in simulator transport | MEDIUM | `stage_2.rs:1161` | CS-11 |
| G8: Stealth consistency policy unenforced in import | MEDIUM | import gate | CS-3 |
| G9: Claim success may rely on runtime-only state while `.wlt` remains unchanged | HIGH | stage3 import/persist path | CS-13 |



```mermaid
flowchart TD
  A[AssetWire decode] --> B[AssetWire to_asset]
  B --> C[validate_stealth_consistency]
  C --> D[verify_complete]
  D --> E[ownership_check]
  E --> F[storage_put]
  C -->|partial stealth or tag16/secret policy fail| R[Reject import]
  D -->|crypto fail| R
```

