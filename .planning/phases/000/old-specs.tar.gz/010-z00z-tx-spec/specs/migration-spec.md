# Scenario 1 Core Migration Plan

<!-- markdownlint-disable MD024 MD032 -->

📌 Date: 2026-03-06

🎯 Goal: keep `crates/z00z_simulator` as orchestration-only code and move reusable business logic to `crates/z00z_wallets/src/core`.

📌 Scope reviewed:
- `crates/z00z_simulator/src/scenario_1/stage_1.rs`
- `crates/z00z_simulator/src/scenario_1/stage_2.rs`
- `crates/z00z_simulator/src/scenario_1/stage_3.rs`
- `crates/z00z_simulator/src/scenario_1/stage_4.rs`
- `crates/z00z_simulator/tests/*`
- `crates/z00z_wallets/src/core/*`

## Current Boundary Status

✅ Already in core (good):
- `tx/multi_io.rs` (`pick_in_rows`, `out_split`, `pick_out_serials`) moved from Stage-4 planning.
- `tx/*` verifier/assembler/balance primitives.
- claim registry and claim receipt primitives in `core/storage/claim_registry.rs` and `core/claim/claim_receipt.rs`.

⚠️ Still simulator-heavy but should be core-capable:
- Stage-3 claim state lifecycle and merge semantics.
- Stage-3 asset distribution algorithms (`class_split`, `coin_sets`, `uniform_all`).
- Stage-3 wire-building and import decision mapping.
- Stage-3 conservation + resume verification helpers.
- Stage-4 cryptographic output bundle builder and self-decrypt validator.
- Stage-4 pending/confirmed lifecycle projection builders.

### Mandatory Implementation Checklist

- [x] Create ADR `docs/reports/s1-core-boundary-adr.md` with frozen boundary table (`owner_crate`, `module`, `public_api`, `forbidden_callers`).
- [x] Add explicit ownership table rows for all Stage-3 and Stage-4 function groups listed above.
- [x] For every boundary row, record source file and exact target module path.
- [x] Add hard rule: simulator may only orchestrate IO/RPC/log formatting and must not contain reusable domain math/crypto/state logic.
- [x] Add `grep`-based denylist checks to CI script for simulator forbidden patterns (state machine transitions, tx witness gate implementation, claim distribution internals).
- [x] Add `grep`-based allowlist checks to ensure simulator calls into `z00z_wallets::core::*` for migrated domains.
- [x] Define merge blocker: PR fails if any new domain-level function is added to `scenario_1/stage_*.rs` without ADR update.

## Claim Assets: Core vs Simulation

✅ Conclusion: claim flow is only partially core right now.

📌 Core part that already exists and is called from `scenario_1`:
- Dedup/finalization registry (`claim_registry`).
- Claim receipt signing/verification domain primitives (`core/claim`).
- Stealth and cryptographic building blocks from `z00z_wallets/core` and `z00z_crypto`.

⚠️ Missing core extraction (currently in simulator):
- `ClaimStateFile` checkpoint state machine and merge policy.
- Claim import loop semantics (accepted/already_exists/rejected mapping).
- Distribution mode engine and replay/resume behavior contract.
- Restart persistence verification pipeline and conservation gate orchestration.

🎯 Required target architecture:
- `scenario_1/stage_3.rs` should call a core claim service (single entrypoint).
- core claim service should return typed reports/events and leave only IO wiring in simulator.

### Mandatory Implementation Checklist

- [x] Define `ClaimServiceRequest` and `ClaimServiceResponse` in `crates/z00z_wallets/src/core/claim/service.rs`.
- [x] Define mandatory response fields: `assignments`, `decisions`, `next_state`, `snapshot_counters`, `audit_events`.
- [x] Define stable enum for import outcomes with no free-form status strings.
- [x] Define canonical state machine enum for claim lifecycle with explicit transition table.
- [x] Freeze resume contract: `claim_state.json` fields, semantics, and backward-compat behavior.
- [x] Add golden fixtures for old and new `claim_state.json` and verify forward load compatibility.
- [x] Add deterministic replay test proving same input assets + config produce identical assignment and decision outputs.
- [x] Ban simulator-side interpretation of wallet import statuses; simulator may only forward typed core decisions.

## Migration Candidates (Code)

📌 Candidate A: Stage-3 claim state engine.
- Source now: `stage_3.rs` functions `read_claim_state`, `write_claim_state`, `merge_state`, `step_rank`, `has_claim_row`, `add_claim_row`, `rehydrate_rows`, `verify_resume_wire`.
- Target: `crates/z00z_wallets/src/core/claim/state_machine.rs`.
- Why: deterministic claim lifecycle and resume consistency are reusable wallet-domain logic.

📌 Candidate B: Stage-3 distribution engine.
- Source now: `assign_class_split`, `assign_coin_sets`, `assign_uniform_all`, `shuffle_assets`, `rand_idx`, `count_assigned`.
- Target: `crates/z00z_wallets/src/core/claim/distribution.rs`.
- Why: policy engine independent of simulator runtime and useful for wallet/app claim pipelines.

📌 Candidate C: Stage-3 import decision mapper.
- Source now: logic in `import_claim_to_wallets` for interpreting RPC responses into domain statuses and audit codes.
- Target: `crates/z00z_wallets/src/core/claim/import_model.rs` + `claim/service.rs`.
- Why: business rules for import status should be stable and testable outside simulator orchestration.

📌 Candidate D: Stage-3 conservation and snapshot reconciliation.
- Source now: `verify_claim_conservation`, `sum_amount`, `sum_commit`, `reconcile_snapshot`.
- Target: `crates/z00z_wallets/src/core/claim/conservation.rs`.
- Why: invariant logic is pure domain logic.

📌 Candidate E: Stage-4 output crypto pipeline.
- Source now: `create_output_bundle`, `verify_self_decrypt`, `compute_tx_digest_from_wire`, `derive_tx_output_nonce`, `verify_plaintext_balance_with_fee`, `verify_commitment_balance_gate`, `derive_fee_commitment`, `verify_spend_witness_gate`, `resolve_input_secret`, `asset_wire_to_leaf`.
- Target: `crates/z00z_wallets/src/core/tx/output_flow.rs` and `tx/witness_gate.rs`.
- Why: cryptographic tx construction and verification must live in core and be reused by non-simulator flows.

📌 Candidate F: Stage-4 lifecycle projection helpers.
- Source now: `build_pending_rows`, `build_confirm_rows`, `validate_confirm_rows`.
- Target: `crates/z00z_wallets/src/core/tx/lifecycle.rs`.
- Why: status transition model is domain-level and testable without simulator.

### Mandatory Implementation Checklist

- [x] Migrate Candidate A exactly to `core/claim/state_machine.rs` and keep function-level parity tests for every moved function.
- [x] Migrate Candidate B exactly to `core/claim/distribution.rs` and enforce deterministic RNG injection through trait/provider.
- [x] Migrate Candidate C exactly to `core/claim/import_model.rs` and `core/claim/service.rs` with typed decision enums.
- [x] Migrate Candidate D exactly to `core/claim/conservation.rs` and preserve overflow-safe arithmetic checks.
- [x] Migrate Candidate E exactly to `core/tx/output_flow.rs` and `core/tx/witness_gate.rs`.
- [x] Migrate Candidate F exactly to `core/tx/lifecycle.rs` and preserve validation invariants.
- [x] Keep simulator calls direct to core APIs after migration.
- [x] Do not introduce wrapper layers between simulator and core APIs.

## Keep in Simulator (Do Not Migrate)

✅ Keep in simulator-only:
- Path remapping to scenario output directories.
- Markdown/XLSX reporting (`write_wallet_report_md`, `write_wallet_report_xlsx`).
- Scenario actor discovery and password mapping glue.
- Stage log formatting and stage-step coverage logging.
- Scenario config parsing wrappers tightly coupled to `ScenarioCfg` shape.

### Mandatory Implementation Checklist

- [x] Keep report writers (`*.md`, `*.xlsx`) in simulator only; forbid moving them into `z00z_wallets`.
- [x] Keep actor/password discovery and scenario-specific identity mapping in simulator only.
- [x] Keep path remap and output directory wiring in simulator only.
- [x] Add `pub(crate)` visibility to simulator-only helpers so they cannot be imported cross-crate.
- [x] Add explicit comments in each simulator-only helper: `SIMULATOR-ONLY: DO NOT MOVE TO CORE`.
- [x] Add a CI grep guard blocking `z00z_wallets` from importing scenario output/report modules.

## Test Migration Plan

📌 Tests in `crates/z00z_simulator/tests` that validate core behavior and should be migrated to `z00z_wallets` after code move:
- `test_tx_balance.rs`
- `test_tx_fee.rs`
- `test_tx_pass.rs`
- `test_tx_poison.rs`
- `test_tx_pedersen.rs`
- `test_tx_serial.rs`
- `test_tx_parity.rs`
- `test_tx_drift.rs`
- `test_tx_prefilter.rs`
- `test_tx_roundtrip.rs`
- `test_tx_spent_gate.rs`
- `test_tx_tamper.rs`
- `test_tx_interop.rs`
- `test_tx_wrong_root.rs`
- `test_tx_assetpack.rs`
- `test_tx_stealth_flow.rs`

📌 Tests that are mixed orchestration + core and should be split:
- `test_claim_crypto.rs`
- `test_claim_integration.rs`
- `test_claim_resume.rs`
- `test_claim_persist.rs`
- `test_claim_snapshot.rs`
- `test_claim_post.rs`

🎯 Split rule:
- Move pure domain assertions to `crates/z00z_wallets/tests/*`.
- Keep scenario wiring assertions in `crates/z00z_simulator/tests/*`.

### Mandatory Implementation Checklist

- [x] Build test inventory matrix file `crates/z00z_simulator/src/scenario_1/specs/test-migration-matrix.md` with one row per listed test.
- [x] Classify each assertion in each test as `core-domain` or `scenario-orchestration`; no mixed assertion blocks allowed.
- [x] Split mixed tests into two physical files: one in `z00z_wallets/tests`, one in `z00z_simulator/tests`.
- [x] Replace filesystem-heavy fixtures in core tests with deterministic in-memory fixtures whenever possible.
- [x] Keep only smoke/e2e orchestration checks in simulator tests.
- [x] Add strict naming rule: core tests must not reference scenario stage labels in filename.
- [x] Add command gates to CI: run migrated core tests first, then simulator orchestration tests.

## Detailed Execution Plan

📌 Phase 1: Define core claim module contract.
- Add `core/claim/service.rs` with typed request/response structs.
- Add `core/claim/state_machine.rs` for checkpoint transitions.
- Add `core/claim/distribution.rs` for mode-based assignment.
- Add `core/claim/conservation.rs` for invariant checks.
- Add `core/claim/import_model.rs` for import decision statuses.

📌 Phase 2: Move pure functions from `stage_3.rs`.
- Port selected functions to new core modules with typed errors.
- Replace ad-hoc `String` errors with domain enums in core.
- Keep simulator orchestration-only context mapping at stage boundary; do not add API wrapper layers.

📌 Phase 3: Introduce Stage-3 core entrypoint.
- Create one core entry function that consumes input assets and returns:
  - per-actor assignments,
  - import decisions,
  - updated claim state,
  - snapshot-ready counters.
- Scenario layer only performs IO and RPC calls using returned plan.

📌 Phase 4: Extract Stage-4 crypto flow.
- Move output creation + self-decrypt + witness gate into `core/tx` modules.
- Expose one `prepare_tx_plan(...)` function returning tx wire + diagnostics.
- Keep simulator responsible for RPC unlock/import/lock orchestration.

📌 Phase 5: Move core tests.
- Relocate pure tx/claim cryptographic tests to `z00z_wallets/tests`.
- Replace simulator config/file dependencies with deterministic fixtures.
- Keep only scenario smoke/e2e tests in simulator.

📌 Phase 6: Enforce boundary.
- Add CI grep checks in simulator crate to forbid direct implementation of:
  - claim state machine,
  - cryptographic witness gate logic,
  - tx lifecycle transition model.
- Allow only calls into `z00z_wallets::core::*`.

### Mandatory Implementation Checklist

- [x] Phase 1 completion gate: all claim module contracts compile and are documented with examples.
- [x] Phase 2 completion gate: moved Stage-3 pure functions have no behavior drift in parity tests.
- [x] Phase 3 completion gate: Stage-3 runner has one core entrypoint call and no duplicate business logic.
- [x] Phase 4 completion gate: Stage-4 crypto flow is executed through core API only.
- [x] Phase 5 completion gate: migrated tests pass under `--release --all-features`.
- [x] Phase 6 completion gate: CI denylist/allowlist checks are enabled and required for merge.
- [x] Add explicit rollback plan per phase (single commit revert path + data compatibility note).
- [x] Block phase advancement until previous phase checklist is fully checked.

## Acceptance Checklist

✅ Claim assets core status accepted when all are true:
- Stage-3 calls a core claim service instead of implementing claim engine inline.
- Stage-4 cryptographic tx pipeline executes through core APIs.
- Simulator tests contain only orchestration/e2e behavior.
- Core tests cover claim and tx invariants with deterministic fixtures.
- No simulator module owns reusable domain rules.

### Mandatory Implementation Checklist

- [x] Add acceptance test `claim_service_single_entrypoint` proving Stage-3 uses only core claim entry API.
- [x] Add acceptance test `tx_prepare_core_only` proving Stage-4 logic path uses core API and not local implementation.
- [x] Add acceptance grep check: no migrated function names remain implemented in simulator source.
- [x] Add acceptance check for deterministic outputs across two consecutive runs with identical seeds/config.
- [x] Add acceptance check that simulator tests assert orchestration artifacts only.
- [x] Require all acceptance checks to pass on CI before merge.

## Risk Controls

⚠️ Risk: migration can break resume compatibility (`claim_state.json`).
- Control: keep backward-compatible serde schema and add snapshot migration tests.

⚠️ Risk: behavior drift in import status mapping.
- Control: golden tests for reason-code transitions and replay semantics.

⚠️ Risk: fee/balance invariant regression during Stage-4 extraction.
- Control: retain existing Stage-4 parity tests and mirror them in core test suite before deleting simulator duplicates.

### Mandatory Implementation Checklist

- [x] Add dedicated compatibility test suite for legacy `claim_state.json` payloads.
- [x] Add golden-file tests for import decision reason-code mapping.
- [x] Add transaction invariant differential tests: old simulator path vs new core path outputs must match.
- [x] Add panic-safety tests for overflow and malformed wire payloads in migrated core modules.
- [x] Add canary release command set and require green status before removing simulator duplicates.
- [x] Define incident rollback procedure document with owner, trigger conditions, and exact rollback commands.

## Immediate Next Steps

🎯 Step 1: finalize Stage-3 single-entrypoint call path in simulator with no residual duplicated business logic.
🎯 Step 2: add acceptance checks (`claim_service_single_entrypoint`, `tx_prepare_core_only`) and wire them into CI gates.
🎯 Step 3: add CI command gates so migrated wallet-core tests run before simulator orchestration tests.
🎯 Step 4: run full `scenario_1` regression and archive artifact paths after gate wiring.

### Mandatory Implementation Checklist

- [x] Execute Step 1 in a dedicated commit with tests for transition legality and resume merge semantics.
- [x] Execute Step 2 in a dedicated commit with deterministic split coverage for mixed claim tests.
- [x] Execute Step 3 in a dedicated commit with wallet-core tx tests for balance/fee/pass invariants.
- [x] Execute Step 4 in a dedicated commit with acceptance tests and no simulator/core wrapper aliases.
- [x] After each step, run: `cargo fmt`, `cargo clippy --all-targets --all-features`, `cargo test --workspace --release --all-features`.
- [x] After each step, update migration matrix status and mark moved assertions.
- [x] After all four steps, run full scenario regression for `scenario_1` and archive report artifact paths.
