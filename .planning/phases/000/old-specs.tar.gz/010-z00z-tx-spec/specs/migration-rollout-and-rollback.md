# Scenario 1 Migration Rollout and Rollback

<!-- markdownlint-disable MD024 MD032 MD060 -->

📌 Date: 2026-03-06

📌 Owner: `@z00z-simul-maintainers`

📌 Scope: close-out controls for Scenario 1 core-boundary migration.

## Phase Rollback Plan

🎯 Rule: each migration phase must be reversible by a single commit revert plus deterministic validation run.

### Phase 1

📌 Scope: claim module contracts in `z00z_wallets::core::claim::*`.

✅ Revert command:

```bash
git revert --no-edit <phase1_commit_sha>
```

✅ Compatibility note:
- keep `ClaimStateFile` serde-compatible fields.
- do not remove `#[serde(default)]` from `claimed_rows`.

### Phase 2

📌 Scope: Stage-3 pure function migration.

✅ Revert command:

```bash
git revert --no-edit <phase2_commit_sha>
```

✅ Compatibility note:
- preserve `ClaimLifeStep` ordering.
- preserve deterministic distribution behavior for fixed `rng_seed`.

### Phase 3

📌 Scope: Stage-3 single-entrypoint orchestration path.

✅ Revert command:

```bash
git revert --no-edit <phase3_commit_sha>
```

✅ Compatibility note:
- keep `run_claim_genesis` ABI stable.
- keep `claim_state.json` loading backward compatible.

### Phase 4

📌 Scope: Stage-4 tx flow extraction to `core::tx`.

✅ Revert command:

```bash
git revert --no-edit <phase4_commit_sha>
```

✅ Compatibility note:
- keep `TxPackage` wire schema stable.
- keep fee and witness gate invariants unchanged.

### Phase 5

📌 Scope: test migration into `z00z_wallets/tests`.

✅ Revert command:

```bash
git revert --no-edit <phase5_commit_sha>
```

✅ Compatibility note:
- simulator test suite must remain orchestration-only.

### Phase 6

📌 Scope: CI denylist/allowlist and acceptance guards.

✅ Revert command:

```bash
git revert --no-edit <phase6_commit_sha>
```

✅ Compatibility note:
- never disable boundary guards without replacing them by stricter equivalent checks.

## Phase Advancement Gate

🎯 A phase MUST NOT start until previous phase completion gate is green.

✅ Enforced process:
1. complete phase work;
2. run canary command set;
3. update migration matrix and migration spec;
4. only then begin next phase.

## Canary Release Command Set

🎯 Canary gate is mandatory before removing simulator duplicates.

✅ Run in order:

```bash
bash scripts/verify_compliance.sh
cargo test -p z00z_wallets --release --all-features \
  --test test_claim_state_compat \
  --test test_claim_state_core \
  --test test_claim_resume_core \
  --test test_claim_snapshot_core \
  --test test_claim_import_reason_codes \
  --test test_claim_core_safety
cargo test -p z00z_simulator --release --all-features \
  --test test_claim_acceptance \
  --test test_tx_handoff_integration \
  --test test_scenario1_unified_gate
```

✅ Green criteria:
- all commands exit `0`;
- no boundary compliance violations;
- acceptance checks pass.

## Incident Rollback Procedure

🎯 Trigger conditions:
- claim replay conflict behavior regression;
- Stage-3 deterministic output drift;
- Stage-4 tx invariant break;
- CI guard bypass detected.

✅ Immediate actions:
1. freeze merges to `z00z-simul`.
2. capture failing command output and failing artifact paths.
3. execute phase-specific `git revert` command.
4. rerun canary command set.
5. publish incident note with root cause and preventive action.

✅ Required incident note fields:
- owner;
- trigger condition;
- reverted commit;
- validation commands and results;
- follow-up ticket.

## Scenario Regression Artifact Archive

🎯 After full scenario regression, archive these paths as evidence:

📌 `outputs/stage_1_snapshot.json`

📌 `outputs/stage_2_snapshot.json`

📌 `outputs/stage_3_snapshot.json`

📌 `outputs/stage_4_snapshot.json`

📌 `outputs/transactions/tx_alice_to_bob_pkg.json`

📌 `outputs/transactions/wallets_state_before.json`

📌 `outputs/transactions/wallets_state_after.json`

📌 `outputs/transactions/wallets_state_diff.json`

📌 `outputs/logs/logger.json`
