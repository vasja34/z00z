<!-- markdownlint-disable MD032 -->

# Stage-4 E2E Working Matrix (Scenario 1)

📌 **Document status:** Working, code-aligned execution guide for the current branch.

📌 **Goal:** Keep Stage-4 implementation, tests, and evidence aligned with the code that actually exists today.

📌 **Primary runtime sources:** `src/scenario_1/stage_4.rs`, `src/scenario_1/design_scenario.yaml`, `src/config.rs`, and `src/scenario_1/config_scenario.yaml`.

📌 **Primary evidence sources:** `tests/test_tx_handoff_integration.rs`, `tests/test_pipeline_genesis_tx.rs`, and `tests/test_claim_pkg_runtime.rs`.

📌 **Primary external spec:** `specs/010-z00z-tx-spec/stage_4_spec-1.md` remains useful, but this file follows the branch implementation first when the spec and code diverge.

📌 **Scope:** Stage 4 `tx_prepare` in Scenario 1, including prerequisite claim-package validation, sender RPC selection, tx construction, cryptographic gates, sender persistence, Bob-side import/decrypt checks, and Stage-4 report artifacts.

📌 **Non-goal:** This file does not pretend that every historical `AG-*` governance/process gate is already implemented as executable runtime coverage.

## 1. Critical Corrections Applied

🚨 The previous revision overstated Stage-4 proof scope. It mixed implemented runtime gates with aspirational process checks such as semantic-diff audits and static hardcode scans.

🚨 The previous revision treated Stage 4 as purely wallet-RPC driven and effectively ignored the verified claim-package prerequisite. The current code calls `load_claim_pkgs()` before any Stage-4 state write, so the document must reflect that dependency.

🚨 The previous revision treated `AG-6` and `AG-7` as mandatory E2E pass/fail gates. In practice they are review and tooling activities, not current runtime evidence gates.

🚨 The previous revision ignored `S4-C1`, the confirmed-lifecycle overlay artifact step that is produced by the current implementation and should not be silently dropped from the evidence model.

🚨 The previous revision used "full implemented Stage-4 functionality" language too aggressively. This revision separates what is already evidenced from what is still backlog.

## 2. Current Stage-4 Contract

📌 The current Stage-4 runtime executes the following concrete contract in `stage_4.rs`.

| Area | Current implementation status | Evidence anchor |
| --- | --- | --- |
| Config loading | Implemented through `stage4_tx_prepare` and validated before run | `stage_4.rs`, `config.rs` |
| Claim package prerequisite | Implemented via `load_claim_pkgs(outputs/claim/tx_claim_pkg.json)` | `stage_4.rs`, `claim_pkg_consumer.rs` |
| Sender input source | Implemented through sender `.wlt` RPC unlock/list/lock flow | `stage_4.rs` |
| Distinct serial selection | Implemented and config-driven via `input_assets_selection` | `config.rs`, `stage_4.rs` |
| Transaction split modes | Implemented for `fraction` and `amount` | `stage_4.rs` |
| Output crypto self-check | Implemented via `core_verify_self_decrypt` | `stage_4.rs` |
| Fee-inclusive balance gates | Implemented for plaintext and commitment paths | `stage_4.rs` |
| Spend witness gate | Implemented via `verify_spend_witness_gate` | `stage_4.rs` |
| Canonical tx package write + verify | Implemented before persistence | `stage_4.rs`, `test_tx_handoff_integration.rs` |
| Sender wallet persistence | Implemented with before/after/diff/report artifacts | `stage_4.rs` |
| Bob import/decrypt path | Implemented inside Stage 4 and separately evidenced by runtime claim import test | `stage_4.rs`, `test_claim_pkg_runtime.rs` |
| Snapshot and logger | Implemented for `S4-1..S4-13` plus `S4-C1` | `stage_4.rs` |

## 3. Working Traceability Map

📌 The code emits and/or covers these Stage-4 step identifiers today.

| Step ID | Meaning in current code |
| --- | --- |
| S4-1 | Prepare directories and initialize Stage-4 run context |
| S4-2 | Load sender inputs from wallet RPC and persist selected input dump |
| S4-3 | Load Alice/Bob receiver cards from configured key files |
| S4-4 | Build outputs from selected inputs and configured split mode |
| S4-5 | Run self-decrypt and leaf-integrity checks on outputs |
| S4-6 | Serialize, verify, and write `tx_alice_to_bob_pkg.json` |
| S4-7 | Persist sender wallet state |
| S4-8 | Run Bob upload/import/decrypt checks |
| S4-9 | Verify fee-inclusive balance gates |
| S4-10 | Verify spend witness gate |
| S4-11 | Write `stage_4_snapshot.json` |
| S4-12 | Write wallet-state evidence artifacts |
| S4-13 | Flush logs and finalize successful completion |
| S4-C1 | Build pending/confirmed lifecycle overlays |

📌 Any new E2E scenario added to this file must map to one or more rows from the table above.

## 4. Executable Working Scenarios

### S4-WORK-01 — Config and Path Contract

🔑 **What it covers:** `stage4_tx_prepare` loading, validation, and path resolution.

📥 **Input under test:** A valid or intentionally malformed `stage4_tx_prepare` section and its `paths` subtree.

🧠 **Core claim:** Stage 4 must be operationally controlled by config. If config is wrong, the run must stop early and loudly instead of silently falling back to hidden defaults.

✅ **What a pass proves:** A caller can change Stage-4 behavior and output topology through config alone, and the runtime is not secretly coupled to hardcoded path assumptions.

❌ **What a fail means:** Either Stage 4 is not truly config-driven, or its validation boundary is too weak and allows ambiguous runtime behavior.

⚙️ **Current source:** `stage_4.rs`, `config.rs`, `config_scenario.yaml`.

✅ **Current evidence:** Tests override Stage-4 config values and path roots in integration runs, including `tests/test_stage4_cfg_paths.rs` coverage for both `outputs/...`-prefixed and short relative path overrides.

📦 **Required artifacts:** `tx_alice_to_bob_pkg.json`, `stage_4_snapshot.json`, logger file, RPC log, wallet-state JSON reports.

**Checklist:**
- [x] Valid config produces all configured Stage-4 artifacts.
- [x] Invalid `transaction.mode` fails closed.
- [x] Missing mandatory RPC method name fails closed.
- [x] Path overrides do not leak artifacts into default locations.

### S4-WORK-02 — Claim Package Prerequisite Gate

🔑 **What it covers:** Stage 4 must verify `outputs/claim/tx_claim_pkg.json` before any state mutation.

📥 **Input under test:** The Stage-3 claim package artifact consumed by Stage 4 as a prerequisite file.

🧠 **Core claim:** Stage 4 is not allowed to continue into tx preparation if the upstream claim package file is missing, malformed, or cryptographically invalid.

✅ **What a pass proves:** Cross-stage integrity is enforced at the boundary, and Stage 4 will not build new wallet state on top of unverified claim artifacts.

❌ **What a fail means:** The pipeline allows stateful behavior to proceed after upstream corruption, which is a structural integrity bug rather than just a missing validation detail.

⚙️ **Current source:** `stage_4.rs`, `claim_pkg_consumer.rs`.

✅ **Current evidence:** `load_claim_pkgs()` is called at the start of Stage 4, `claim_pkg_consumer` rejects malformed or unverifiable rows, and `tests/test_stage4_claim_gate.rs` covers missing, malformed, and verifier-invalid prerequisite failures together with absence of Stage-4 state/report artifacts.

⚠️ **Pitfall:** This file is a prerequisite gate, not the sender coin-selection source.

**Checklist:**
- [x] Missing claim package file fails the Stage-4 run.
- [x] Invalid claim package bytes fail before tx artifact write.
- [x] No partial Stage-4 wallet-state artifacts are written on claim-package failure.
- [x] Failure message includes claim-package context, not a later Stage-4 generic error.

### S4-WORK-03 — Sender RPC Input Selection and Distinct Serials

🔑 **What it covers:** Inputs come from sender wallet RPC and must satisfy distinct `serial_id` constraints.

📥 **Input under test:** Sender wallet `.wlt` state as observed through configured RPC methods, plus the Stage-4 distinct-serial selection policy.

🧠 **Core claim:** Stage 4 must choose spendable inputs from the live wallet view, not from side files, and it must enforce the anti-concentration selection policy described by `distinct_serial_ids_min/target/max`.

✅ **What a pass proves:** The runtime is using the real wallet domain as source of truth and is applying deterministic safety rules to the chosen input set.

❌ **What a fail means:** Either the runtime is sourcing inputs from the wrong place, or it can silently degrade the distinct-serial policy and build a tx from an unsafe input distribution.

⚙️ **Current source:** `stage_4.rs`, `config.rs`.

✅ **Current evidence:** `tests/test_stage4_selection.rs` proves sender-specific unlock/list/lock RPC flow, class/symbol-constrained selection, and fail-before-write behavior when the filtered sender pool cannot satisfy the configured target; `stage_4.rs` unit tests prove the distinct-serial selector fails closed instead of degrading to a weaker fallback.

**Checklist:**
- [x] Sender unlock/list/lock sequence is present in RPC log.
- [x] Selection respects `distinct_serial_ids_min`, `target`, and `max`.
- [x] Insufficient distinct serials fail closed.
- [x] Selected rows match configured `transaction.class` and `transaction.symbol`.
- [x] Failure occurs before `tx_alice_to_bob_pkg.json` write when the distinct-serial target cannot be satisfied.

### S4-WORK-04 — Split Modes and Amount Safety

🔑 **What it covers:** `fraction` and `amount` modes, fee-aware arithmetic, and zero-send rejection.

📥 **Input under test:** `transaction.mode`, `transaction.fraction`, `transaction.amount`, and the selected input sum after fee handling.

🧠 **Core claim:** Stage 4 must produce economically coherent outputs for both split modes, and it must reject impossible or degenerate requests before any artifact is persisted.

✅ **What a pass proves:** The transaction planner respects user intent while still preserving minimal economic sanity such as positive send value and bounded spend amount.

❌ **What a fail means:** Stage 4 may produce semantically wrong transfers, accept nonsense config, or compute outputs against the wrong spendable base.

⚙️ **Current source:** `split_amount_cfg()` and downstream output build logic in `stage_4.rs`.

✅ **Current evidence:** `stage_4.rs` unit tests now prove exact guard strings for bad `mode`, missing/invalid `fraction`, and missing/invalid `amount`; `tests/test_stage4_split.rs` proves that `amount` is revalidated after fee subtraction and that tiny-fraction requests fail at the dedicated zero-send guard before any Stage-4 write.

**Checklist:**
- [x] `mode=fraction` requires `fraction in (0, 1]`.
- [x] `mode=amount` requires positive amount not exceeding spendable input.
- [x] Fee subtraction happens before final send/change split is accepted.
- [x] Zero send amount is rejected.
- [x] Error strings match the actual guards in `stage_4.rs`, not imagined spec wording.

### S4-WORK-05 — Output Crypto Integrity

🔑 **What it covers:** Sender-side self-decrypt, tag binding, plaintext decode, commitment opening, and range proof checks.

📥 **Input under test:** The freshly built `OutputBundle` items before they are turned into the persisted tx wire artifact.

🧠 **Core claim:** Stage 4 must prove to itself that every output it is about to serialize is internally coherent and decryptable by the intended wallet-side logic.

✅ **What a pass proves:** The tx builder is not merely serializing bytes that look plausible; it is emitting outputs that satisfy the wallet-side cryptographic consistency checks expected by downstream consumers.

❌ **What a fail means:** Stage 4 can leak malformed stealth outputs into the package layer, which would make later verification, receiver import, or persistence behavior unreliable.

⚙️ **Current source:** `core_verify_self_decrypt()` path in `stage_4.rs`.

✅ **Current evidence:** `stage_4.rs` unit tests prove canonical self-decrypt success plus explicit tag, plaintext semantic, commitment, and range-proof rejection branches; `tests/test_stage4_output_crypto.rs` uses a controlled Stage-4 tamper seam to prove a malformed output aborts before `tx_alice_to_bob_pkg.json` and post-state artifacts are written.

**Checklist:**
- [x] Every produced output passes self-decrypt verification.
- [x] Tag and plaintext semantic checks are enforced.
- [x] Commitment opening and range proof checks are enforced.
- [x] Any tampered output must abort before tx package write.

### S4-WORK-06 — Fee-Inclusive Balance and Spend Witness Gates

🔑 **What it covers:** Plaintext balance, commitment balance, and spend witness enforcement.

📥 **Input under test:** The selected sender inputs, generated outputs, computed fee, and witness material attached to the spend path.

🧠 **Core claim:** Stage 4 must reject any transaction candidate that is economically unbalanced or not authorized by the witness gate, even if the surrounding structure looks valid.

✅ **What a pass proves:** The branch runtime enforces the minimum economic and authorization gates required before a `TxPackage` can be treated as meaningful.

❌ **What a fail means:** Stage 4 may be able to construct packages that look syntactically fine but violate conservation or spending-rights assumptions.

⚙️ **Current source:** `core_plain_balance()`, `verify_commitment_balance_gate()`, and `verify_spend_witness_gate()` in `stage_4.rs`.

✅ **Current evidence:** `stage_4.rs` unit tests execute `verify_commitment_balance_gate()` and `verify_spend_witness_gate()` directly on canonical and fail branches, `tests/test_stage4_gates.rs` proves the persisted plaintext equation plus `S4-9` / `S4-10` runtime ordering before `S4-6` package persistence, and `tests/test_stage4_tamper.rs` adds explicit fail-closed output and witness tamper coverage.

⚠️ **Pitfall:** Do not describe this as an external proof system audit. The current evidence is runtime gate enforcement in the branch implementation.

**Checklist:**
- [x] Plaintext fee-inclusive balance gate passes canonical run.
- [x] Commitment fee-inclusive balance gate passes canonical run.
- [x] Spend witness gate passes canonical run.
- [x] Negative output and witness tamper cases fail before snapshot persistence.
- [x] Any future tamper test must fail before snapshot persistence and must not silently downgrade to a verifier-only warning.

### S4-WORK-07 — Canonical `TxPackage` Artifact

🔑 **What it covers:** Final package schema, canonical digest field, and wallet verifier acceptance.

📥 **Input under test:** The serialized `tx_alice_to_bob_pkg.json` produced by Stage 4.

🧠 **Core claim:** Stage 4 must emit an artifact that is not just present on disk, but structurally canonical and accepted by the wallet-side verifier stack.

✅ **What a pass proves:** Downstream consumers can treat the Stage-4 package as a legitimate transaction artifact rather than as a simulator-only intermediate blob.

❌ **What a fail means:** The pipeline can complete while writing a package that is unusable, unverifiable, or non-canonical for the wallet/runtime boundary.

⚙️ **Current source:** `stage_4.rs`, `tests/test_tx_handoff_integration.rs`.

✅ **Current evidence:** `test_stage4_structure()` checks canonical `TxPackage.kind`, `version`, `status`, non-empty `tx_digest_hex`, runs the wallet verifier against the actual serialized `tx_alice_to_bob_pkg.json`, and proves empty-output rejection through the verifier error path.

**Checklist:**
- [x] `kind == TxPackage`.
- [x] `version == 1`.
- [x] `status == prepared`.
- [x] `tx_digest_hex` is present and non-empty.
- [x] Empty-output tamper case is rejected by verifier.

### S4-WORK-08 — Sender Persistence and Wallet-State Reports

🔑 **What it covers:** Sender-side state mutation and report generation.

📥 **Input under test:** The sender wallet before/after state around a successful Stage-4 run, plus the generated state overlays and reports.

🧠 **Core claim:** Stage 4 must do more than compute a package; it must leave the sender wallet and the generated evidence files in a state that reflects the new pending/confirmed lifecycle correctly.

✅ **What a pass proves:** The run changes observable wallet state in a way that survives re-open and is captured in the JSON/MD/XLSX evidence outputs.

❌ **What a fail means:** The simulator is only producing artifacts without persisting the wallet-side consequences, or it is persisting them without generating auditable evidence.

⚙️ **Current source:** `stage_4.rs`, `tests/test_stage4_wallet_persist.rs`, `tests/test_pipeline_genesis_tx.rs`.

✅ **Current evidence:** `wallets_state_before.json`, `wallets_state_after.json`, `wallets_state_diff.json`, `wallets_state_report.md`, `wallets_state_report.xlsx`, `wallets_pending.json`, and `wallets_confirmed.json`. `tests/test_stage4_wallet_persist.rs` now verifies that the generated XLSX workbook matches the authoritative JSON overlays for row counts, serial distributions, and amount totals instead of only checking that the file is non-empty.

**Checklist:**
- [x] Before/after/diff reports are generated.
- [x] Pending and confirmed overlays are generated.
- [x] Selected serials are represented in Bob pending rows.
- [x] Sender state mutation survives wallet re-open in integration flow.

### S4-WORK-09 — Bob Import and Receiver Decryptability

🔑 **What it covers:** Bob unlock/import/lock flow and Bob ownership/decrypt checks.

📥 **Input under test:** The Stage-4 outputs intended for Bob and the receiver-side wallet RPC/import path.

🧠 **Core claim:** Stage 4 is not complete unless the receiver can actually ingest and recognize the outputs it produces.

✅ **What a pass proves:** The producer side and receiver side agree on the output encoding and ownership semantics, at least for the current runtime boundary.

❌ **What a fail means:** Stage 4 can create outputs that look valid to the sender side but are not consumable by the receiver wallet, which breaks the end-to-end transfer story.

⚙️ **Current source:** `run_bob_checks()` path in `stage_4.rs`, plus `tests/test_claim_pkg_runtime.rs` for direct runtime import of verified leaf wires.

✅ **Current evidence:** Stage-4 code executes the Bob import path, and runtime import is independently proven for verified claim leaf wires.

⚠️ **Pitfall:** The dedicated claim runtime test proves the import RPC path directly, but it is not by itself a full Stage-4 tx-package test.

**Checklist:**
- [x] Bob RPC import succeeds for Stage-4 outputs.
- [x] Bob ownership/decrypt checks pass for Bob outputs.
- [x] Alice change output is not misclassified as Bob-owned.
- [x] Bob wallet is locked after checks.

### S4-WORK-10 — Cross-Stage Continuity

🔑 **What it covers:** Stage-4 output consistency within the Scenario-1 pipeline.

📥 **Input under test:** The full Scenario-1 run from upstream stages into Stage-4 outputs and lifecycle overlays.

🧠 **Core claim:** Stage 4 must fit into the surrounding scenario as a compatible consumer and producer, not just pass in isolation.

✅ **What a pass proves:** The artifacts generated by Stage 4 line up with upstream state and preserve the expected serial/ownership continuity across the pipeline.

❌ **What a fail means:** Even if Stage 4 passes its local checks, it may still be semantically disconnected from the rest of the scenario and therefore unsafe to rely on in end-to-end runs.

⚙️ **Current source:** `tests/test_pipeline_genesis_tx.rs`.

✅ **Current evidence:** `s4_tx_pkg_ok()` and `s4_bob_pending_ok()` in `tests/test_pipeline_genesis_tx.rs`.

**Checklist:**
- [x] `stage_4_snapshot.json` matches stage number and success status.
- [x] `tx_alice_to_bob_pkg.json` has valid kind, version, status, fee, and outputs.
- [x] Bob pending rows cover the serials selected from sender input.
- [x] No cross-stage schema mismatch is observed.

## 5. Current Test-to-Scenario Mapping

📌 These tests are the strongest branch-local evidence today.

| Test file | Current strongest coverage |
| --- | --- |
| `tests/test_stage4_claim_gate.rs::stage4_rejects_missing_claim_pkg` | `S4-WORK-02` fail-closed missing prerequisite |
| `tests/test_stage4_claim_gate.rs::stage4_rejects_bad_claim_pkg` | `S4-WORK-02` fail-closed malformed prerequisite |
| `tests/test_stage4_selection.rs::stage4_rejects_low_serial_pool` | negative branch of `S4-WORK-03` |
| `tests/test_stage4_cfg_guards.rs::stage4_rejects_bad_mode` | negative branch of `S4-WORK-01` |
| `tests/test_stage4_cfg_guards.rs::stage4_rejects_bad_fraction` | negative branch of `S4-WORK-04` |
| `tests/test_stage4_tamper.rs::stage4_rejects_tampered_output` | negative branch of `S4-WORK-06` |
| `tests/test_stage4_tamper.rs::stage4_rejects_bad_witness` | witness rejection branch of `S4-WORK-06` |
| `tests/test_stage4_digest.rs::stage4_digest_stable_with_seed` | deterministic replay evidence for `S4-WORK-07` |
| `tests/test_tx_handoff_integration.rs::test_stage4_structure` | `S4-WORK-07`, part of `S4-WORK-06` |
| `tests/test_stage4_wallet_persist.rs::test_stage4_wallet_persistence` | `S4-WORK-08`, including XLSX-to-JSON artifact consistency |
| `tests/test_stage4_bob_flow.rs::test_stage4_bob_flow` | `S4-WORK-09` |
| `tests/test_pipeline_genesis_tx.rs::s4_tx_pkg_ok` | `S4-WORK-10`, part of `S4-WORK-07` |
| `tests/test_pipeline_genesis_tx.rs::s4_bob_pending_ok` | `S4-WORK-03`, `S4-WORK-08`, `S4-WORK-10` |
| `tests/test_claim_pkg_runtime.rs::test_tx_claim_pkg_import_e2e` | prerequisite runtime import path relevant to `S4-WORK-02` and `S4-WORK-09` |

## 6. Closed Work Packages

📌 These work packages are now closed with executable tests. Keep the section as an audit trail that links each former backlog item to the concrete evidence that closed it.

### WP-1 — Claim Package Fail-Closed Test

🎯 **Goal:** Close `S4-WORK-02` with direct executable evidence.

📁 **Implemented file:** `tests/test_stage4_claim_gate.rs`

🧪 **Recommended test names:**
- `stage4_rejects_missing_claim_pkg`
- `stage4_rejects_bad_claim_pkg`

✅ **Current evidence:** `stage4_rejects_missing_claim_pkg()`, `stage4_rejects_bad_claim_pkg()`, and `stage4_bad_pkg_fails()` in `tests/test_stage4_claim_gate.rs`.

⚙️ **Setup pattern:**
- Start from the same Scenario-1 config loading pattern used in existing integration tests.
- Force Stage 4 to run with a controlled output root.
- For the missing-file case, ensure `outputs/claim/tx_claim_pkg.json` is absent.
- For the malformed-file case, write invalid JSON or structurally invalid claim package bytes into `tx_claim_pkg.json`.

✅ **Required assertions:**
- [x] Stage result is `Fail`.
- [x] Error text contains claim-package load/verify context.
- [x] `transactions/tx_alice_to_bob_pkg.json` does not exist.
- [x] `stage_4_snapshot.json` does not exist.
- [x] `transactions/wallets_state_after.json` does not exist.
- [x] `transactions/wallets_state_diff.json` does not exist.
- [x] `transactions/wallets_pending.json` does not exist.
- [x] `transactions/wallets_confirmed.json` does not exist.

⚠️ **Pitfall:** Do not assert on a fully stable full-string error message if the lower-level decoder text is noisy. Assert on a stable substring such as `claim package`, `claim pkg`, `decode failed`, or `failed:`.

### WP-2 — Distinct Serial Fail-Closed Test

🎯 **Goal:** Close the negative branch of `S4-WORK-03`.

📁 **Implemented file:** `tests/test_stage4_selection.rs`

🧪 **Recommended test name:**
- `stage4_rejects_low_serial_pool`

✅ **Current evidence:** `stage4_rejects_low_serial_pool()` in `tests/test_stage4_selection.rs`.

⚙️ **Setup pattern:**
- Reuse Scenario-1 config bootstrapping.
- Constrain sender-side spendable assets so the pool has fewer distinct serial IDs than `distinct_serial_ids_min` or `distinct_serial_ids_target`.
- Keep all unrelated Stage-4 config valid so the failure source is unambiguous.

✅ **Required assertions:**
- [x] Stage result is `Fail`.
- [x] Error occurs before tx package persistence.
- [x] `wallets_selected_inputs.json` is absent or empty when selection never completes.
- [x] No pending/confirmed artifacts are produced.

⚠️ **Pitfall:** The failure may surface from the selection helper rather than from the later `selected serial pool is empty` guard. The test must accept the earliest correct fail-closed boundary.

### WP-3 — Invalid Mode and Amount Boundaries

🎯 **Goal:** Close the negative branches of `S4-WORK-01` and `S4-WORK-04`.

📁 **Implemented file:** `tests/test_stage4_cfg_guards.rs`

🧪 **Recommended test names:**
- `stage4_rejects_bad_mode`
- `stage4_rejects_missing_fraction`
- `stage4_rejects_bad_fraction`
- `stage4_rejects_missing_amount`
- `stage4_rejects_zero_amount`
- `stage4_rejects_big_amount`

✅ **Current evidence:** `stage4_valid_cfg_ok()` plus all six recommended reject tests in `tests/test_stage4_cfg_guards.rs`.

✅ **Required assertions:**
- [x] Each invalid config produces `StageResult::Fail`.
- [x] The error substring matches the current guard in `stage_4.rs`.
- [x] No tx package or snapshot is written.
- [x] Canonical valid config still passes in the same test module.

⚠️ **Pitfall:** There are both config-validation errors and runtime split errors in `stage_4.rs`. The checklist must distinguish which branch is being exercised.

### WP-4 — Output or Witness Tamper Test

🎯 **Goal:** Convert `S4-WORK-06` from code-path assurance to executable adversarial evidence.

📁 **Implemented file:** `tests/test_stage4_tamper.rs`

🧪 **Recommended test names:**
- `stage4_rejects_tampered_output`
- `stage4_rejects_bad_witness`

✅ **Current evidence:** `stage4_tamper_ok()`, `stage4_rejects_tampered_output()`, and `stage4_rejects_bad_witness()` in `tests/test_stage4_tamper.rs`.

⚙️ **Implementation note:**
- Prefer the smallest controlled tamper point possible.
- If direct end-to-end tamper before `run_core()` is awkward, extract or expose a narrower helper boundary first instead of building a fragile black-box hack.

✅ **Required assertions:**
- [x] Canonical control case passes.
- [x] Tampered case fails at the intended gate.
- [x] Snapshot and post-state artifacts are not written for the tampered case.
- [x] Failure reason maps to output integrity, balance, or witness gate rather than an unrelated downstream verifier error.

### WP-5 — Digest Replay Test

🎯 **Goal:** Close the evidence gap called out in `S4-WORK-07` and backlog section.

📁 **Implemented file:** `tests/test_stage4_digest.rs`

🧪 **Recommended test name:**
- `stage4_digest_stable_with_seed`

✅ **Current evidence:** `stage4_digest_stable_with_seed()` in `tests/test_stage4_digest.rs`.

⚙️ **Setup pattern:**
- Enable deterministic seed selection through existing simulation config.
- Re-run the same Stage-4 preparation with identical selected inputs and identical RNG seed.
- Compare canonical `tx_digest_hex` values from the produced package or snapshot.

✅ **Required assertions:**
- [x] Same deterministic run yields the same digest.
- [x] One semantic input change yields a different digest.
- [x] The test documents which parts of the pipeline must remain fixed for the claim to be valid.

## 7. Artifact Absence Matrix for Fail-Closed Tests

📌 Every negative Stage-4 test should assert not only the failure, but also the absence of artifacts that would imply partial state mutation.

| Artifact | Missing claim pkg | Bad selection | Bad mode/amount | Tampered output/witness |
| --- | --- | --- | --- | --- |
| `transactions/tx_alice_to_bob_pkg.json` | MUST be absent | MUST be absent | MUST be absent | MUST be absent |
| `stage_4_snapshot.json` | MUST be absent | MUST be absent | MUST be absent | MUST be absent |
| `transactions/wallets_state_after.json` | MUST be absent | MUST be absent | MUST be absent | MUST be absent |
| `transactions/wallets_state_diff.json` | MUST be absent | MUST be absent | MUST be absent | MUST be absent |
| `transactions/wallets_pending.json` | MUST be absent | MUST be absent | MUST be absent | MUST be absent |
| `transactions/wallets_confirmed.json` | MUST be absent | MUST be absent | MUST be absent | MUST be absent |

📌 `wallets_state_before.json` may or may not exist depending on where the failure occurs. Negative tests MUST document the expected boundary rather than blindly asserting one behavior for all cases.

## 8. Known Gaps and Backlog

✅ The former executable backlog from Section 6 is now closed by `tests/test_stage4_claim_gate.rs`, `tests/test_stage4_tamper.rs`, and `tests/test_stage4_digest.rs`.

⚠️ Static review tasks such as "search for forbidden hardcoded constants" and semantic diff tasks such as "spec/design/code sync audit" should be tracked as review backlog, not mislabeled as runtime E2E PASS criteria.

⚠️ Some integration tests skip in debug builds, so release-style CI evidence remains more authoritative for full Stage-4 claims.

## 9. Implementation Order for New Work

🎯 If the goal is to continue Stage-4 hardening safely, use this order.

1. Re-run the strongest Stage-4 integration evidence in release-style CI, because some integration tests intentionally skip debug builds.
2. Keep spec, design, and code synchronized whenever a Stage-4 gate, artifact, or test boundary changes.
3. Track static review tasks such as forbidden-constant scans separately from executable E2E acceptance.

📌 Any new work package is complete only when the new test exists, passes, and updates the corresponding `S4-WORK-*` checklist from review intent to executable evidence.

## 10. Definition of Done per Work Package

✅ Test file exists under `crates/z00z_simulator/tests/`.

✅ Test name is specific to the boundary it proves.

✅ Positive control exists when the negative assertion would otherwise be ambiguous.

✅ Failure assertions check both error class/substrings and artifact absence.

✅ The test does not rely on undocumented global state or pre-existing output directories.

✅ The scenario is mapped back to at least one `S4-WORK-*` row in this document.

## 11. Exit Criteria for This Branch

✅ Stage 4 is "working" when `S4-WORK-01..10` are either directly covered by tests or proven by mandatory runtime gates with artifact evidence.

✅ Stage 4 is "ready for further implementation" when new work extends the scenarios in Section 7 instead of reintroducing spec-only placeholders.

✅ Stage 4 is **not** allowed to claim "fully proven against every historical AG gate" while Section 8 still contains unresolved review or release-evidence backlog.
