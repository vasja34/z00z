# Scenario 1 Claim Transaction Specification (TxKind::Claim)

<!-- markdownlint-disable MD004 MD009 MD022 MD024 MD029 MD031 MD032 MD040 MD060 -->

📌 **Version:** 1.0.0  
📌 **Date:** 2026-03-06  
📌 **Scope:** Scenario 1 claim path, block inclusion path, JMT state transition path  
📌 **Status:** Draft normative (`MUST` level for target implementation)

## Purpose

🎯 This document defines the target transaction model where claim action is represented as a standard transaction variant: `TxKind::Claim`.

🎯 The goal is to route claim through the same aggregator and validator pipeline used by standard transactions, so claim data is included in blocks and applied to JMT state deterministically.

🎯 This spec is derived from the style and control model used in:
- `crates/z00z_simulator/src/scenario_1/specs/addresses_spec.md`
- `crates/z00z_simulator/src/scenario_1/specs/claim-spec.md`

## Design Decision

✅ **Chosen variant:** Extend standard transaction structure with `TxKind::Claim`.

📌 Rationale:
- One mempool and one block inclusion pipeline.
- One verification lifecycle for aggregator and validator.
- No separate claim-only execution path.
- Deterministic state transition compatible with JMT update flow.

🚫 Not chosen in this spec:
- Separate top-level `ClaimPackage` protocol outside standard transaction envelope.

## Normative Terms

📌 `MUST` means required behavior.

📌 `MUST NOT` means forbidden behavior.

📌 `FAIL-CLOSED` means reject on any ambiguity or validation error.

📌 `Deterministic` means same input bytes and same pre-state always produce the same result and the same post-state root.

## Transaction Envelope

🎯 Claim transaction MUST use the existing transaction envelope with a kind discriminator.

### Required Top-Level Fields

📌 `kind` MUST be `"claim"`.

📌 `version` MUST be explicit and part of signed bytes.

📌 `chain_id` MUST be explicit and part of signed bytes.

📌 `tx_digest_hex` MUST commit to canonical bytes of the claim payload.

📌 `status` follows standard tx lifecycle (`prepared`, `accepted`, `included`, `finalized`) according to existing pipeline semantics.

## Claim Payload (TxKind::Claim)

🎯 `TxKind::Claim` payload MUST carry all data needed for independent validation by aggregator and validator.

### Canonical Payload Fields

📌 `claim_id: [u8; 32]`
- Unique claim operation identifier.
- MUST be deterministic from canonical claim witness context.

📌 `nullifier: [u8; 32]`
- Global anti-replay and anti-double-claim key.
- MUST be unique in global state.

📌 `recipient_wallet_id: String`
- Wallet target identity for claim result ownership.
- MUST be canonical session-linked identity format.

📌 `recipient_owner_handle: [u8; 32]`
- Ownership binding value used by ownership checks.

📌 `claim_scope_hash: [u8; 32]`
- Domain-separated scope binding (`chain_id`, scenario context, rule-set version).

📌 `proof_blob: Vec<u8>`
- Canonical serialized claim proof.
- MUST include all inputs needed for deterministic verification.

📌 `proof_type: String`
- Claim proof type identifier.
- MUST be versioned and validated against network config allowlist.

📌 `created_outputs: Vec<ClaimOutputWire>`
- Outputs created by claim execution.
- MUST map to canonical output structure used in tx pipeline.

📌 `fee: u64`
- Fee amount for claim tx.
- May be zero if chain policy allows zero-fee claim.

📌 `nonce: u64`
- Sender-side sequencing value, if required by account or replay policy.

📌 `sender_sig: Vec<u8>`
- Signature over canonical claim tx signing preimage.

### ClaimOutputWire

📌 `asset_id: [u8; 32]`

📌 `amount: u64`

📌 `asset_class: String`

📌 `owner_binding` fields (transparent or stealth-compatible) MUST follow existing asset ownership rules.

📌 Output serialization MUST remain compatible with standard tx output verifier path.

## Canonical Serialization and Signing

🎯 Claim tx signing MUST use canonical bytes with stable field order and explicit length-prefix rules.

### Signing Preimage

📌 Preimage MUST include:
- `kind`
- `version`
- `chain_id`
- full canonical `claim_payload`

📌 Preimage MUST NOT include transport-only wrappers.

📌 `tx_digest_hex` MUST equal hash of canonical preimage bytes.

📌 Signature verification MUST be FAIL-CLOSED.

## Validation Pipeline

🎯 Aggregator and validator MUST execute the same logical checks in the same order.

### Mandatory Check Order

📌 `decode -> schema_validate -> kind_validate -> signature_validate -> proof_validate -> nullifier_check -> output_validate -> fee_policy_check -> state_transition_simulate`

### Rule Details

📌 `decode`
- Reject malformed bytes.

📌 `schema_validate`
- Reject missing mandatory fields.

📌 `kind_validate`
- Must be `TxKind::Claim`.

📌 `signature_validate`
- Verify `sender_sig` against canonical preimage.

📌 `proof_validate`
- Verify `proof_blob` using `proof_type` verifier.
- Verify proof is bound to `claim_scope_hash`, `chain_id`, and recipient binding.

📌 `nullifier_check`
- Reject if `nullifier` already finalized or reserved by conflicting tx.

📌 `output_validate`
- Validate each output using existing tx output invariants.
- Reject invalid ownership or malformed asset fields.

📌 `fee_policy_check`
- Enforce chain fee policy for claim kind.

📌 `state_transition_simulate`
- Deterministically compute expected deltas and resulting root candidate.

## Mempool and Aggregator Rules

🎯 Aggregator MUST treat claim tx as a first-class tx kind, not as side-channel metadata.

📌 Mempool dedup key MUST include `tx_digest_hex` and `nullifier`.

📌 Aggregator MUST reject new claim tx if nullifier conflicts with an already accepted claim tx.

📌 Aggregator MAY keep only one claim per nullifier in mempool.

📌 Aggregator MUST pass claim tx to block builder in canonical tx ordering policy.

## Block Inclusion Rules

🎯 Block body MUST include claim tx in the same transaction list as other kinds.

📌 Claim tx inclusion MUST produce deterministic execution receipt.

📌 Receipt MUST include:
- `tx_digest_hex`
- `claim_id`
- `nullifier`
- `result_code`
- `spent_delta_count`
- `created_delta_count`

📌 Block validation MUST replay claim execution deterministically.

## JMT State Transition Rules

🎯 Claim tx execution MUST produce state deltas compatible with standard JMT update path.

### Required Delta Model

📌 `spent_delta`
- For claim kind, at minimum includes nullifier consumption marker.
- Optional: consumed claim-right leaf if represented explicitly in state.

📌 `created_delta`
- All newly created assets or balance leaves from claim outputs.

📌 `meta_delta`
- Claim execution metadata (receipt index, audit code, claim status).

### JMT Commit Requirements

📌 Claim execution MUST write nullifier-used marker atomically with created outputs.

📌 If any part fails, whole claim execution MUST rollback (no partial state write).

📌 Post-state root MUST be deterministic across all validators.

## Security Requirements

🎯 Security requirements from claim and address specs apply directly to `TxKind::Claim`.

📌 MUST enforce global anti-double-claim by nullifier.

📌 MUST enforce wallet ownership binding for created outputs.

📌 MUST enforce chain and domain separation (`chain_id`, `claim_scope_hash`, kind tag).

📌 MUST reject replay across chain or version domains.

📌 MUST reject non-canonical encodings.

📌 MUST reject claim tx with unverifiable proof, even if signature is valid.

## Backward Compatibility

📌 Existing non-claim tx kinds MUST remain unchanged.

📌 Existing tx parser MUST be forward-compatible with unknown kinds by explicit error code (`unsupported_kind`).

📌 Claim tx version upgrades MUST be explicit (`version`) and must preserve old verifier route while supported.

## Observability and Audit

🎯 Claim execution must be auditable without leaking private payloads.

📌 Logs MUST include:
- `tx_digest_hex`
- `claim_id`
- `nullifier` (or hashed display variant if policy requires)
- `result_code`

📌 Logs MUST NOT include:
- raw secrets
- private keys
- unredacted sensitive proof internals unless explicitly debug-gated in non-production mode

## Error Model

📌 Required deterministic reject classes:
- `claim_decode_error`
- `claim_schema_error`
- `claim_sig_invalid`
- `claim_proof_invalid`
- `claim_nullifier_conflict`
- `claim_output_invalid`
- `claim_fee_invalid`
- `claim_state_conflict`

📌 Same invalid tx bytes MUST map to same reject class across aggregator and validator.

## Acceptance Criteria

🎯 `TxKind::Claim` integration is accepted only when all checks below are green.

### Mandatory Implementation Checklist

- [ ] Add claim tx wire structs under existing tx model with explicit `kind = claim` discriminator.
- [ ] Add canonical serializer/deserializer with deterministic ordering and strict decode checks.
- [ ] Add claim signature verify path integrated into standard tx verifier.
- [ ] Add claim proof verification adapter with explicit `proof_type` allowlist.
- [ ] Add nullifier conflict checks in mempool and block execution path.
- [ ] Add block executor support to emit `spent_delta` and `created_delta` for claim kind.
- [ ] Add atomic JMT update for nullifier marker and created outputs.
- [ ] Add receipt schema for claim execution result.
- [ ] Add integration test: claim tx accepted by aggregator and included by validator into block.
- [ ] Add integration test: duplicate nullifier claim is rejected deterministically.
- [ ] Add integration test: same claim tx on same pre-state yields identical post-state root in two consecutive runs.
- [ ] Add integration test: malformed claim proof fails before state write.

## Open Questions (To Freeze Before Code)

📌 Fee policy:
- Zero fee allowed for claim tx, or normal fee schedule mandatory?

📌 Claim proof type roadmap:
- Single proof type in v1, or versioned multi-type allowlist?

📌 Nullifier storage key shape:
- Raw nullifier bytes, or domain-tagged hash key in state tree?

📌 Receipt retention policy:
- Full receipt payload in state, or event log only?

📌 Ordering policy:
- Should claim tx ordering be identical to normal tx ordering, or have explicit priority class?

## Migration Note for Scenario 1

📌 Existing Stage 3 claim orchestration in simulator should become producer of `TxKind::Claim` packages.

📌 Aggregator and validator should consume claim through the unified tx pipeline only.

📌 Simulator should remain orchestration-only and MUST NOT reimplement claim verifier or state transition logic.
