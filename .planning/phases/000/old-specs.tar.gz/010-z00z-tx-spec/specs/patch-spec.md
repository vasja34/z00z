# Stage 3 Wallet-Native Patch Spec

📌 **Version:** 0.4.0  
📌 **Date:** 2026-03-01  
📌 **Owner Branch:** `z00z-simul`  
📌 **Scope:** Scenario 1 Stage 3 claim persistence, wallet ownership, restart consistency, and exports

## Objective

🎯 Stage 3 claim MUST persist accepted assets in wallet-native state (`.wlt` lifecycle), so wallet is the single source of truth for future transaction preparation.

## Critical Findings from Review

⚠️ `v0.1.0` was directionally correct but underspecified for implementation safety.  
⚠️ It did not define file-level touchpoints, rollback strategy, or measurable evidence for each checklist item.  
⚠️ It did not explicitly block dual-path persistence (wallet + sidecar), which is a CS-13 violation risk.  
⚠️ It did not pin deterministic behavior constraints for actor-parallel execution and audit ordering.
⚠️ It had one path ambiguity for export artifacts (`outputs/claim/wallets_export_import/*` vs `outputs/wallets_export_import/*`).
⚠️ Current wallet `.wlt` snapshot schema (`WalletPersistenceState`) does not carry claimed assets, so direct sidecar removal is unsafe until wallet-native asset snapshot fields and restore logic are implemented.

## Hard Constraints

✅ Keep claim security order unchanged: `verify_complete -> ownership_check -> reserve -> durable_put -> finalize`.  
✅ Keep fail-closed behavior on persistence failure.  
✅ Keep global claim-registry semantics and quarantine contract unchanged.  
✅ Keep RPC logs unified in `outputs/logs/rpc_logger.json` only.  
🚫 Do NOT keep any sidecar durable claim storage path in Stage 3 runtime.
🚫 Do NOT introduce temporary parallel persistence (sidecar + wallet-native) in release runtime.

## Prerequisite Gate (A0) — Wallet Schema Readiness

🎯 Before Section A can remove sidecar runtime, wallet-native `.wlt` persistence MUST be able to store and restore claimed assets.

📌 `crates/z00z_wallets/src/core/wallet/snapshot.rs`

- [x] Add claimed-asset payload field(s) to `WalletPersistenceState` (or explicit equivalent) with versioned migration path.
- [x] Extend checksum coverage to include claimed-asset payload.

📌 `crates/z00z_wallets/src/services/wallet_service.rs`

- [x] Include claimed assets in `create_snapshot()`.
- [x] Restore claimed assets in `restore_snapshot()`.

📌 `crates/z00z_wallets/src/adapters/rpc/methods/asset_impl.rs`

- [x] Route `import_asset` durable path to wallet-native snapshot state (via wallet service) instead of external sidecar DB.

✅ **A0 exit criteria:** restart after process kill returns the same canonical asset set `(asset_id, class, amount)` from wallet-native source with no sidecar files involved.

## File-Level Change Plan

📌 `crates/z00z_wallets/src/adapters/rpc/methods/asset_impl.rs`  

- [x] Route claim import durable put to wallet-native persistence backend used by `.wlt` (after A0 readiness).  
- [x] Remove/forbid sidecar-only acceptance path.  
- [x] Keep explicit reject reason codes and fail-closed mapping.

📌 `crates/z00z_simulator/src/scenario_1/stage_2.rs`  

- [x] Remove Stage 3 dependency on `wallet_assets.db` path wiring.  
- [x] Keep transport wiring with unified `rpc_logger.json`.

📌 `crates/z00z_simulator/src/scenario_1/stage_3.rs`  

- [x] Remove sidecar assumptions from import/restart verification.  
- [x] Verify restart state from wallet-native source only.  
- [x] Keep `stage_3_snapshot.json` persistence evidence deterministic.

📌 `crates/z00z_simulator/tests/test_claim_persist.rs`  

- [x] Assert persistence evidence is wallet-native, not sidecar-file-backed.  
- [x] Keep set-equality verification on `(asset_id, class, amount)`.  
- [x] Keep negative fail-closed test on forced persistence failure.

📌 `crates/z00z_simulator/tests/audit_log_integrity.rs` and `crates/z00z_simulator/tests/cross_wallet_claim.rs`  

- [x] Ensure no regression in audit completeness/replay protection after migration.

## Checklist A — Persistence Model Compliance (CS-13 Core)

- [x] `IMPORT_ACCEPTED_NEW` is impossible without wallet-native durable write success.
- [x] Stage 3 success is impossible if wallet-native persistence evidence fails after restart.
- [x] No runtime creation/use of `wallet_assets.db` or `wallet_assets.wallets` remains in Stage 3 path.
- [x] No dual persistence semantics exist in release runtime.
- [x] Wallet snapshot payload and restore path include claimed assets (A0 complete).
- [x] Checklist A revalidated on release checks (`--release --features test-fast --features wallet_debug_dump`).

## Checklist B — Contract Correctness and Crash Semantics

- [x] Preserve order: verify -> ownership -> reserve -> durable_put -> finalize.
- [x] On `durable_put == Ok && finalize != Ok`: keep quarantine and pending reservation.
- [x] On `durable_put != Ok`: release reservation and return reject (no success status).
- [x] Finalize retry remains idempotent and test-covered.
- [x] Checklist B revalidated on release checks (`--release --features test-fast --features wallet_debug_dump`).
- [x] `durable_put != Ok` release path is explicitly test-covered (`test_put_fail_release`).

## Checklist C — Concurrency Policy

- [x] Keep sequential import inside one wallet actor to preserve deterministic claim order.
- [x] Optional parallelism only across independent actors (`alice|bob|charlie`).
- [x] If actor-parallel mode is enabled, merge audit rows in deterministic order (`actor_name`, then local sequence).
- [x] Claim registry invariants remain valid under actor-parallel mode.
- [x] Checklist C revalidated on release checks (`--release --features test-fast --features wallet_debug_dump`).
- [x] Deterministic wallet-block audit ordering is test-covered (`test_audit_order_by_wallet`).

## Checklist D — Artifacts and Export Integrity

- [x] Keep Stage 3 claim artifacts under `outputs/claim/*` (snapshot in outputs root).
- [x] Ensure debug exports are derived from persisted wallet state only.
- [x] Keep `wlt_map.md` synchronized with current wallet file mapping.
- [x] Ensure `outputs/claim/export_wallet_debug_{actor}.json` shows full wallet+assets export parity.
- [x] Revalidated debug dump merge path: wallet fields are preserved and `imported_assets_*` fields are appended.
- [x] Revalidated large debug dumps via bounded loader path (64 MiB) for Stage 3 export/tests.
- [x] Revalidated fail-closed behavior: non-object debug export shape now aborts merge with explicit error.
- [x] Revalidated D1 contract with explicit required-artifacts assertions in `stage3_persist` release tests.

## Checklist D1 — File Placement Contract (REMOVE / CREATE / KEEP)

📌 **REMOVE (must not exist after clean Stage 3 run):**

- [x] `outputs/wallets/wallet_assets.db`
- [x] `outputs/wallets/wallet_assets.wallets/`
- [x] Any sidecar wallet-asset JSON files under `wallet_assets.wallets/*`

📌 **CREATE (must exist):**

- [x] `outputs/claim/claimed_assets_alice.json`
- [x] `outputs/claim/claimed_assets_bob.json`
- [x] `outputs/claim/claimed_assets_charlie.json`
- [x] `outputs/stage_3_snapshot.json`
- [x] `outputs/claim/audit_log.json`
- [x] `outputs/events/claim_genesis.event.json`
- [x] `outputs/logs/rpc_logger.json`
- [x] `outputs/wallets/wallet_*.wlt`
- [x] `outputs/wallets/wlt_map.md`
- [x] `outputs/wallets_export_import/export_wallet_encrypted_payload.json`

📌 **KEEP (must remain wallet source-of-truth):**

- [x] `outputs/wallets/wallet_*.wlt`
- [x] `outputs/wallets/wlt_map.md`
- [x] `outputs/claim/export_wallet_debug_{alice,bob,charlie}.json`

📌 **Path consistency rule:**

- [x] No duplicate artifact families in two roots (e.g., same export semantics in both `outputs/claim/*` and `outputs/wallets/*` unless explicitly versioned and documented).

## Checklist E — Logging Compliance

- [x] `outputs/logs/rpc_stage3_claim.json` is never created.
- [x] `outputs/logs/rpc_stage3_restart_check.json` is never created.
- [x] All RPC records are in `outputs/logs/rpc_logger.json`.

## Checklist E1 — Log Correctness Gate

- [x] `rpc_logger.json` contains Stage 2 + Stage 3 RPC calls.
- [x] `rpc_logger.json` has no plaintext passwords or seed phrases.
- [x] Stage 3 does not emit per-step standalone RPC log files.
- [x] Log format is machine-parseable (each line valid JSON record or valid structured JSON container, per logger contract).

## Checklist F — Cryptographic Correctness Guardrails

- [x] Migration must not weaken `verify_complete` semantics.
- [x] Migration must not alter ownership checks (`owner_tag` / wallet binding).
- [x] Migration must not alter replay protection and claim scope behavior.
- [x] Migration must keep conservation checks and reject taxonomy intact.

## Checklist F1 — Wallet Asset Cryptography Validation

- [x] For each actor wallet, reloaded assets after restart pass wallet-side verification path used in import/list operations.
- [x] Equality gate uses canonical set compare: `(asset_id, class, amount)` pre-restart vs post-restart.
- [x] Range-proof and ownership validation behavior is unchanged relative to baseline (`verify_complete` contract preserved).
- [x] Replay and wrong-owner reject behavior remains green in release tests.

## Checklist G — Test Matrix (Release)

- [x] `cargo test -p z00z_wallets --release --features test-fast --test test_asset_import_security`
- [x] `cargo test -p z00z_wallets --release --features test-fast --test test_asset_ownership_security`
- [x] `cargo test -p z00z_wallets --release --features test-fast --test test_asset_replay_protection`
- [x] `cargo test -p z00z_simulator --release --features test-fast --features wallet_debug_dump --test stage3_persist`
- [x] `cargo test -p z00z_simulator --release --features test-fast --features wallet_debug_dump --test audit_log_integrity`
- [x] `cargo test -p z00z_simulator --release --features test-fast --features wallet_debug_dump --test stage3_claim_crypto --test cross_wallet_claim`
- [x] `cargo run --release -p z00z_simulator --bin scenario_1 --features wallet_debug_dump`

## Checklist H — Acceptance Evidence

- [x] Evidence file set captured: `stage_3_snapshot.json`, `audit_log.json`, `rpc_logger.json`, wallet debug exports.
- [x] Restart comparison proves equality of accepted vs reloaded sets for each actor wallet.
- [x] Sidecar files are absent after clean run.
- [x] All above checks pass on same branch without PR flow.

## Checklist H1 — End-of-Run Validation Gate (Hard Stop)

🎯 Stage is accepted only if **all** conditions below pass at end:

- [x] **File cleanup check:** no sidecar persistence files/directories remain.
- [x] **File creation check:** all mandatory Stage 3 artifacts exist in expected paths.
- [x] **Log check:** only `rpc_logger.json` is used for RPC logs.
- [x] **Sum check:** `sum(amount)` across claimed actor artifacts equals imported/reloaded wallet sums.
- [x] **Crypto check:** wallet-reloaded claimed assets satisfy import-time cryptographic validity expectations and ownership/replay protections.
- [x] **Wallet source check:** wallet-reloaded claimed assets come from `.wlt` snapshot-backed state, not sidecar DB/files.
- [x] **Release check:** full release matrix in Checklist G passes without bypass.

## Checklist I — Executable Verification Script (Mandatory)

📌 Run these checks after final Stage 3 release run:

- [x] **No sidecar files:**  
  `test ! -e crates/z00z_simulator/src/scenario_1/outputs/wallets/wallet_assets.db`  
  `test ! -d crates/z00z_simulator/src/scenario_1/outputs/wallets/wallet_assets.wallets`

- [x] **Required artifacts exist:**  
  `test -f crates/z00z_simulator/src/scenario_1/outputs/stage_3_snapshot.json`  
  `test -f crates/z00z_simulator/src/scenario_1/outputs/claim/audit_log.json`  
  `test -f crates/z00z_simulator/src/scenario_1/outputs/events/claim_genesis.event.json`  
  `test -f crates/z00z_simulator/src/scenario_1/outputs/logs/rpc_logger.json`

- [x] **No forbidden rpc logs:**  
  `test ! -f crates/z00z_simulator/src/scenario_1/outputs/logs/rpc_stage3_claim.json`  
  `test ! -f crates/z00z_simulator/src/scenario_1/outputs/logs/rpc_stage3_restart_check.json`

- [x] **Amount sums converge (claim rows):**  
  `python3 - <<'PY'\nimport json, pathlib\nclaim=pathlib.Path('crates/z00z_simulator/src/scenario_1/outputs/claim')\nfiles=[claim/'claimed_assets_alice.json', claim/'claimed_assets_bob.json', claim/'claimed_assets_charlie.json']\nrows=[]\nfor p in files:\n    rows.extend(json.loads(p.read_text()))\ns=sum(int(r['amount']) for r in rows)\nsnap=json.loads(pathlib.Path('crates/z00z_simulator/src/scenario_1/outputs/stage_3_snapshot.json').read_text())\ns2=sum(int(a['total_amount']) for a in snap['actor_claims'])\nassert s==s2, (s,s2)\nprint('SUM_OK', s)\nPY`

- [x] **Cryptographic behavior validated by release tests:**  
  `cargo test -p z00z_wallets --release --features test-fast --test test_asset_import_security --test test_asset_ownership_security --test test_asset_replay_protection`  
  `cargo test -p z00z_simulator --release --features test-fast --features wallet_debug_dump --test stage3_claim_crypto --test stage3_persist --test audit_log_integrity --test cross_wallet_claim`

## Risks and Mitigations

⚠️ **Risk:** Hidden dependency on sidecar path in tests.  
✅ **Mitigation:** Replace assertions with wallet-native evidence checks and remove sidecar references.

⚠️ **Risk:** Non-deterministic order under parallel actor import.  
✅ **Mitigation:** Keep per-wallet sequential processing and deterministic audit merge strategy.

⚠️ **Risk:** Debug export divergence from persisted state.  
✅ **Mitigation:** Build debug export only from post-restart persisted reads.

## Execution Mode

🔑 Apply patches in small steps (A->H).  
🔑 After each modified file, run Codacy analysis and fix findings immediately.  
🔑 After each checklist block, run the minimal relevant release test set before moving forward.
