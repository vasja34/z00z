# Z00Z TX RFC: Module Target Map and Migration Plan

📌 **Version:** 1.2.0
📌 **Date:** 2026-03-03
📌 **Status:** Draft for implementation on branch `z00z-simul`
📌 **Scope:** `crates/z00z_wallets/src/core/tx/*` and spec sync for Stage 4 Phase 1

## 1. Purpose

🎯 This RFC defines the target module map for wallet TX internals and the migration sequence `M1 -> M5`.

🎯 This RFC requires migration without breaking current public API imports from `z00z_wallets::core::tx`.

### 1.1 Section Checklist

- [x] Purpose and scope are clear and non-ambiguous for implementers.
- [x] Public API non-break requirement is explicitly acknowledged for this run.
- [x] Branch scope is confirmed (`z00z-simul`).

## 2. Goals and Non-Goals

✅ **Goals:**
- converge TX internals by responsibility,
- remove module overlap from `mod.rs`,
- lock a Phase 1 `TxPackage`/`TxWire` contract,
- prepare clean Phase 2 extension points.

🚫 **Non-Goals:**
- no consensus-circuit implementation in this RFC,
- no public API break in current crate users,
- no Stage 5 protocol expansion.

### 2.1 Section Checklist

- [x] Goal list is accepted as the implementation target.
- [x] Non-goals are confirmed to avoid scope creep.
- [x] Any extra request outside this section is explicitly tracked as out-of-scope.

## 3. Target Module Map

📌 `asset_selector.rs` stays separate (selection cohesion is valid).

📌 `balance.rs` is the only balance algebra module:
- `balance_blindings`,
- `verify_blind_balance`,
- `verify_tx_balance`.

📌 `builder.rs` acts as output builder:
- `build_output_leaf`,
- `build_output_with_blind`,
- `sender_create_output_for` (moved from `mod.rs`).

📌 Identity/correlation API is unified at `tx/mod.rs` facade surface:
- PayRef API (`generate_payref`, parse/format/verify),
- TxId API (`Z00ZTxId`, `generate_mac_key`).

📌 `tx_assembler.rs` remains orchestration-only:
- no embedded algebra,
- delegates balance checks to `balance`,
- delegates fee checks to `fee_estimator`,
- delegates semantic checks to `tx_verifier`.

📌 `tx_verifier.rs` validates `TxPackage`/`TxWire` payloads:
- structure checks,
- signature checks,
- range proof checks,
- package-level validation hooks.

📌 `fee_estimator.rs` uses `tx_weight` model:
- Phase 1 static-rate mode,
- Phase 2 network-rate mode (cache + TTL).

📌 `mod.rs` is facade-only:
- module declarations,
- re-exports,
- compatibility aliases,
- no business logic bodies.

### 3.1 Section Checklist

- [x] `asset_selector.rs` remains separate.
- [x] `balance.rs` is the single balance algebra location.
- [x] `builder.rs` owns output-builder responsibilities.
- [x] `tx/mod.rs` facade exposes unified PayRef/TxId API.
- [x] `tx_assembler.rs` is orchestration-only.
- [x] `tx_verifier.rs` verifies `TxPackage/TxWire` scope.
- [x] `fee_estimator.rs` follows tx-weight and phase split.
- [x] `mod.rs` has no business logic bodies.

## 4. Phase 1 Contract: TxWire and TxPackage

📌 `TxWire` (Phase 1) contains:
- `inputs: Vec<TxInputWire>`,
- `outputs: Vec<TxOutputWire>`,
- `fee: u64`.

📌 `TxPackage` (Phase 1) contains:
- `kind: "TxPackage"`,
- `version: u8` (must be non-zero),
- `tx: TxWire`,
- `tx_digest_hex: String` (64 hex chars),
- `status: String`.

✅ This contract is JSON-serializable and is sufficient for Stage 4 tx_prepare artifacts.

### 4.1 Section Checklist

- [x] `TxWire` fields are implemented exactly as documented.
- [x] `TxPackage` fields are implemented exactly as documented.
- [x] `kind = "TxPackage"` and non-zero `version` are enforced.
- [x] `tx_digest_hex` uses 64 hex chars.
- [x] Serialization format is stable for Stage 4 artifacts.

## 5. Public API Compatibility Rules

✅ Existing external imports from `z00z_wallets::core::tx` must continue to compile.

✅ Legacy names are allowed as aliases during migration:
- `LocalVerifier*` aliases to `TxVerifier*`,
- `output_builder` alias over `builder`,
- PayRef/TxId old symbols still re-exported through facade.

🚫 Do not remove aliases before the final API freeze review.

### 5.1 Section Checklist

- [x] Existing imports from `z00z_wallets::core::tx` compile unchanged.
- [x] Compatibility aliases remain available during migration.
- [x] Any planned alias removal is deferred until freeze review.

## 6. Precedence and Freeze Gate (safe `2-1-3`)

✅ This RFC is `DRAFT` until contract freeze in `z00z-tx-spec.md`.

✅ Conflict resolution precedence is mandatory:
- `z00z-tx-spec.md` (protocol/source-of-truth) **wins** over this RFC,
- this RFC must be updated to match frozen `z00z-tx-spec.md` before Stage 4 gate execution.

✅ Safe execution order `2-1-3` is explicitly allowed only with this gate:
1. Draft migration map in this RFC (`2`),
2. Freeze signatures/contracts in `z00z-tx-spec.md` (`1`),
3. Fast RFC re-sync to frozen contract (no semantic drift),
4. Stage 4 execution against `stage_4_spec-1.md` gates (`3`).

🚫 Starting M1..M5 implementation before contract freeze is forbidden.

### 6.1 Section Checklist

- [x] Gate G1: `z00z-tx-spec.md` contract freeze is confirmed.
- [x] Gate G2: RFC and `z00z-tx-spec.md` are synced with no semantic drift.
- [x] Gate G3: Stage 4 gate references updated contracts only.
- [x] Gate G4: Regression matrix is green.

## 7. Migration by Commits (M1 -> M5)

### M1 — Balance Convergence

✅ Add `balance.rs` and merge blinding + commitment balance helpers.

✅ Remove standalone `blinding.rs` and `balance_check.rs`.

✅ Keep facade exports stable from `mod.rs`.

#### M1 Checklist

- [x] M1.1 Create/confirm `tx/balance.rs` module.
- [x] M1.2 Ensure `balance_blindings()` exists and is unit-tested.
- [x] M1.3 Ensure `verify_blind_balance()` exists and is unit-tested.
- [x] M1.4 Ensure `verify_tx_balance()` exists and is unit-tested.
- [x] M1.5 Remove standalone overlap modules (`blinding.rs`, `balance_check.rs`).
- [x] M1.6 Confirm `mod.rs` re-exports balance symbols from one place only.
- [x] M1.7 Confirm no imports reference removed balance modules.
- [x] M1.8 Capture evidence: test names + paths for balance tests.

### M2 — Builder and Facade Cleanup

✅ Move `sender_create_output_for` into `builder.rs`.

✅ Convert `mod.rs` into facade-only file.

✅ Keep backward-compatible symbol re-exports.

#### M2 Checklist

- [x] M2.1 Move/keep `sender_create_output_for()` under `tx/builder.rs`.
- [x] M2.2 Confirm `sender_create_output_for(card, amount, serial_id)` signature is stable.
- [x] M2.3 Remove non-facade business logic bodies from `tx/mod.rs`.
- [x] M2.4 Keep `mod.rs` as declaration + re-export facade only.
- [x] M2.5 Add/keep compatibility alias `output_builder` (or equivalent) until API freeze review.
- [x] M2.6 Verify external imports from `z00z_wallets::core::tx` still compile.
- [x] M2.7 Capture evidence: compile/test output + touched file list.

### M3 — Identity Convergence

✅ Keep unified identity facade via `tx/mod.rs` re-exports.

✅ Route PayRef + TxId exports through unified surface.

✅ Keep old symbol paths available via facade re-exports.

#### M3 Checklist

- [x] M3.1 Keep unified identity facade via `tx/mod.rs`.
- [x] M3.2 Re-export PayRef API from unified facade.
- [x] M3.3 Re-export TxId API from unified facade.
- [x] M3.4 Keep old symbols reachable via facade re-exports.
- [x] M3.5 Verify docs/examples do not point to removed import paths.
- [x] M3.6 Capture evidence: symbol map old->new.

### M4 — Verifier Scope Upgrade

✅ Add `tx_verifier.rs` and verify `TxPackage/TxWire` instead of raw asset payload-only path.

✅ Keep compatibility aliases from `LocalVerifier*` to `TxVerifier*`.

✅ Update spec wording and scope references.

#### M4 Checklist

- [x] M4.1 Add/keep `tx_verifier.rs`.
- [x] M4.2 Verify `TxPackage`/`TxWire` structure checks are implemented.
- [x] M4.3 Verify signature checks run on package outputs.
- [x] M4.4 Verify range proof checks run on package outputs.
- [x] M4.5 Ensure balance verification scope is package-level.
- [x] M4.6 Keep compatibility aliases (`LocalVerifier*` -> `TxVerifier*`).
- [x] M4.7 Update `z00z-tx-spec.md` wording to `TxVerifierImpl` scope.
- [x] M4.8 Capture evidence: verifier tests + package fixture sample.

### M5 — Fee and Orchestration Alignment

✅ Update fee estimator to `tx_weight` model with static/network split.

✅ Keep `tx_assembler.rs` orchestration-only and delegate math/verification.

✅ Update `z00z-tx-spec.md` signatures and module map to current code.

#### M5 Checklist

- [x] M5.1 Implement/keep `TxWeight` model in fee estimator.
- [x] M5.2 Ensure `estimate(tx_bytes)` maps to weight model.
- [x] M5.3 Keep Phase 1 static-rate mode constructor/path.
- [x] M5.4 Add/keep Phase 2 network-rate mode with TTL cache.
- [x] M5.5 Ensure `tx_assembler.rs` delegates to `balance`, `fee_estimator`, and verifier pipeline.
- [x] M5.6 Ensure assembler has no duplicated balance algebra logic.
- [x] M5.7 Update `z00z-tx-spec.md` fee API semantics to current implementation.
- [x] M5.8 Capture evidence: fee tests + assembler delegation tests.

## 8. Acceptance Checklist

- [x] `cargo test -p z00z_wallets --release --features test-fast`
- [x] Stage 4 simulator tests still pass with requested feature set
- [x] `mod.rs` contains no standalone TX logic functions
- [x] `TxPackage`/`TxWire` contract is documented in spec and code
- [x] No unresolved references to removed modules (`blinding.rs`, `balance_check.rs`)

### 8.1 Release Gate Checklist

- [x] A1 `cargo test -p z00z_wallets --release --features test-fast`.
- [x] A2 Stage 4 target test matrix green.
- [x] A3 Codacy scan clean for every modified file.
- [x] A4 `mod.rs` facade-only rule verified.
- [x] A5 `z00z-tx-spec.md` and this RFC synchronized at end of run.
- [x] A6 Changelog/version update completed by version manager workflow.

## 9. Rollback Policy

📌 If any migration step breaks external imports, rollback only that commit and keep alias layer in place.

📌 If verifier migration causes runtime rejection spikes, keep parser strictness and disable only non-critical checks behind feature-gated compatibility mode.

### 9.1 Section Checklist

- [x] Rollback trigger conditions are clearly identified.
- [x] Rollback granularity is commit-level (not broad revert).
- [x] Compatibility aliases remain available after rollback.

## 10. Documentation Sync Requirements

✅ `specs/010-z00z-tx-spec/z00z-tx-spec.md` must stay aligned with:
- builder signature (`sender_create_output_for(card, amount, serial_id)`),
- verifier scope (`TxVerifierImpl` + `TxPackage/TxWire`),
- fee API behavior (`tx_weight` semantics).

✅ This RFC is normative for refactor sequencing, while `z00z-tx-spec.md` remains normative for protocol contract semantics.

### 10.1 Section Checklist

- [x] Builder signature in docs matches real API.
- [x] Verifier scope in docs matches real API.
- [x] Fee model semantics in docs match implementation.

### 10.2 Evidence Block Template (fill per run)

- [x] Run date: 2026-03-03
- [x] Branch: `z00z-simul`
- [x] Completed milestones: M1 / M2 / M3 / M4 / M5
- [x] Key files changed: `crates/z00z_wallets/src/core/tx/{balance.rs,tx_verifier.rs,fee_estimator.rs,tx_assembler.rs,tx_id.rs}`, `specs/010-z00z-tx-spec/z00z-tx-rfc.md`
- [x] Tests executed: package tests for verifier/fee/assembler + workspace release matrix with `z00z_simulator/test-fast,z00z_wallets/test-fast,z00z_simulator/wallet_debug_dump`
- [x] Codacy result summary: clean on all edited files in this run
- [x] Remaining blockers: none

