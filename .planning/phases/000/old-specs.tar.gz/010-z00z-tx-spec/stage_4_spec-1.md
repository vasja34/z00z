# Scenario 1 Stage 4 Tx-Prepare Spec (v1)

📌 **Version:** 1.2.2  
📌 **Date:** 2026-03-05  
📌 **Scope:** Scenario 1 Stage 4 (`tx_prepare`) in simulator runtime  
📌 **Status:** Normative (`MUST` level) for Phase 1, with explicit Phase 2 backlog

---

## Purpose

🎯 This document defines the implementation contract for Stage 4 so it is executable, auditable, and aligned with current code.

🎯 This document is written in the same practical spec style used by Scenario 1 specs (claim/security style): fixed rules first, implementation checklists second.

🎯 Stage 4 MUST produce a canonical `TxPackage` payload compatible with wallet tx verifier structures, not simulator-only placeholder artifacts.

🎯 All Stage 4 runtime parameters MUST be read from `crates/z00z_simulator/src/scenario_1/config_scenario.yaml` (`stage4_tx_prepare` section). Hardcoded stage parameters are forbidden.

🎯 This file is intended to supersede `specs/010-z00z-tx-spec/stage_4_spec.md` after the deletion gate in this document is satisfied.

---

## Current Reference Points

📌 Stage runtime: `crates/z00z_simulator/src/scenario_1/stage_4.rs`

📌 Scenario step contract: `crates/z00z_simulator/src/scenario_1/design_scenario.yaml` (stage 4)

📌 Canonical tx structures and verifier:
- `crates/z00z_wallets/src/core/tx/tx_verifier.rs`
- `crates/z00z_wallets/src/core/tx/tx_assembler.rs`

📌 Output builder and stealth path:
- `crates/z00z_wallets/src/core/tx/builder.rs`
- `crates/z00z_wallets/src/core/stealth/*`

📌 Wire and asset conversions:
- `crates/z00z_core/src/assets/wire.rs`
- `crates/z00z_core/src/assets/assets.rs`

---

## Normative Rules

📌 `MUST` means mandatory for Stage 4 acceptance.

📌 `MUST NOT` means forbidden behavior.

📌 `FAIL-CLOSED` means any validation/parsing/verifier ambiguity causes Stage 4 failure.

📌 `Phase 1` means wallet-consistent prepare flow and local verifier compatibility.

📌 `Phase 2` means consensus-oriented proof/state convergence beyond this stage.

📌 `Supersede` means this document becomes the single Stage 4 implementation source for Scenario 1.

---

## Stage 4 Fixed Decisions

🎯 Stage 4 SHALL emit canonical `TxPackage` JSON with this top-level shape:
- `kind`
- `version`
- `tx`
- `tx_digest_hex`
- `status`

🎯 `tx` SHALL include:
- `inputs: Vec<TxInputWire>`
- `outputs: Vec<TxOutputWire>`
- `fee: u64`

🎯 Stage 4 SHALL compute fee using `TxAssemblerImpl::calc_fee_for_wires`.

🎯 Stage 4 SHALL gate final artifact through `TxVerifierImpl::verify` before writing output.

🎯 Stage 4 SHALL parse `asset_id_hex` in fail-closed mode (no fallback digest placeholders).

🎯 Stage 4 SHALL preserve asset class, commitment (`c_amount`), and range proof from the built output leaf when mapping outputs to `TxOutputWire`.

🎯 Stage 4 input selection SHALL be sourced from sender `.wlt` via RPC (`wallet.asset.list_assets`), not from side JSON claim files.

🎯 Stage 4 input set SHALL be assembled from different `serial_id` values.

🎯 Default target is `3` distinct `serial_id`, configurable up to `10` maximum via `config_scenario.yaml::stage4_tx_prepare.selection`.

🎯 Split rule SHALL be config-driven and default to `send_value = total_input_amount / 10`, `change_value = total_input_amount - send_value`.

🎯 Stage 4 SHALL execute prepare flow through JSON-RPC events (`app -> wallets`) and log all RPC events.

🎯 Stage 4 SHALL include receiver-side (Bob) package upload/import validation and receiver decryptability verification for Bob-owned output.

🎯 Stage 4 SHALL include cryptographic balance proof gate (`Sigma inputs = Sigma outputs + fee`) and SpendWitness gate for each input.

🎯 All Stage 4 balance checks (plaintext and commitment-domain) SHALL include `fee` explicitly; checks that ignore `fee` are invalid.

🚫 Stage 4 MUST NOT write `prepared_placeholder` status.

🚫 Stage 4 MUST NOT bypass verifier gate when package serialization succeeds.

🚫 Stage 4 MUST NOT silently normalize malformed `asset_id_hex` values.

🚫 Stage 4 MUST NOT force all outputs to `AssetClass::Coin` during wire mapping.

🚫 Stage 4 MUST NOT use dev-fixture commitment or range proof when the actual output leaf (`out.leaf.c_amount`, `out.leaf.range_proof`) provides valid crypto material.

🚫 Stage 4 MUST NOT use serial remap like `serial_id = ((idx % 99) + 1)`.

🚫 Stage 4 MUST NOT use `outputs/claim/claimed_assets_alice.json` as transaction input source.

🚫 Stage 4 MUST NOT persist wallet-state-critical operations in side JSON files instead of `.wlt`.

🚫 Stage 4 MUST NOT claim consensus-equivalent proof/state semantics in Phase 1.

---

## Stage 4 Step Contract (S4-1..S4-13)

```mermaid
flowchart TD
	A[S4-1 Prepare dirs] --> B[S4-2 Sender unlock + list assets]
	B --> C[S4-3 Load receiver cards]
	C --> D[S4-4 Build outputs]
	D --> E[S4-5 Self-decrypt checks]
	E --> F[S4-6 Build canonical TxPackage]
	F --> G[S4-7 Verifier gate + write artifacts]
	G --> H[S4-8 Sender wallet persistence]
	H --> I[S4-9 Bob import + decrypt checks]
	I --> J[S4-10 Balance gates with fee]
	J --> K[S4-11 SpendWitness gate]
	K --> L[S4-12 Audit continuity rows]
	L --> M[S4-13 Flush logs + Ok]
```

### S4-1 Prepare output directories

📌 Create `outputs/`, `outputs/logs/`, `outputs/transactions/`.

**Implementation Checklist:**
- [x] Ensure all three directories are created before any artifact write.
- [x] Emit structured log row for S4-1.

### S4-2 Load sender spendable inputs from `.wlt` via RPC

📌 Unlock sender wallet and read spendable assets from `.wlt` over JSON-RPC.

📌 Build multi-input set from distinct `serial_id` values according to config (`default=3`, `max=10`).

**Implementation Checklist:**
- [x] Read RPC method names and filters from `config_scenario.yaml::stage4_tx_prepare`.
- [x] Call `wallet.session.unlock_wallet` for sender wallet id.
- [x] Call `wallet.asset.list_assets` and select spendable native coin input (`amount > min`, config-driven policy).
- [x] Select multiple spendable coin inputs with different `serial_id`.
- [x] Target distinct `serial_id` count defaults to `3`.
- [x] Distinct `serial_id` target MUST NOT exceed configured max (`10`).
- [x] Reject when distinct-serial input target cannot be satisfied.
- [x] Lock wallet session on both success and failure paths.
- [x] Emit structured log row for S4-2.

### S4-3 Load receiver data for output encryption

📌 Load receiver public card data from configured source and validate material for stealth output build.

**Implementation Checklist:**
- [x] Resolve receiver card source path from `config_scenario.yaml`.
- [x] Parse all required fields fail-closed.
- [x] Reject malformed 32-byte hex material.
- [x] Emit structured log row for S4-3.

### S4-4 Build outputs

📌 Build one Bob output and optional Alice change output using Stage 4 split rule from configuration.

📌 Default split rule: `send_value = total_input_amount / 10` (integer division); `change_value = total_input_amount - send_value` (remainder). Change output is omitted when `change_value == 0`.

**Implementation Checklist:**
- [x] Produce at least one output.
- [x] Build change output only when `change_value > 0`.
- [x] Both outputs carry the same `AssetClass` (the class of the selected sender wallet input).
- [x] `serial_id` for each output is inherited from the selected input set by explicit policy (no synthetic remap).
- [x] The policy for binding output `serial_id` to selected inputs MUST be deterministic and logged.
- [x] Input aggregation uses multi-input set selected in S4-2.
- [x] Emit structured log row for S4-4.

### S4-5 Self-decrypt and consistency checks

📌 For each produced output, verify decrypt/tag/commitment/range-proof consistency **on the `OutputBundle.leaf` data, before wire materialization**.

**Implementation Checklist:**
- [x] Verify `tag16` against recomputed value.
- [x] Decrypt `enc_pack` and decode `AssetPackPlain`.
- [x] Verify `value`, `s_out`, commitment opening.
- [x] Verify range proof for output commitment.
- [x] Note: these checks validate the data that will be transferred into the wire in S4-6; S4-6 then copies `c_amount` and `range_proof` from the same leaf into the wire.
- [x] Emit structured log row for S4-5.

### S4-6 Build canonical tx package

📌 Convert to canonical tx structures and build `TxPackage`.

**Implementation Checklist:**
- [x] Parse `asset_id_hex` to `[u8; 32]` fail-closed.
- [x] Parse selected input `class` to `AssetClass` fail-closed.
- [x] Build `tx.inputs` from the selected multi-input set (distinct `serial_id`).
- [x] Map outputs to `TxOutputWire` payloads.
- [x] Preserve class from selected input row in each mapped output wire.
- [x] Compute fee via `calc_fee_for_wires`.
- [x] Compute `tx_digest_hex` deterministically from canonical wire data in `TxPackage.tx` (`inputs`, `outputs`, `fee`) after wire materialization.
- [x] Set `kind = "TxPackage"` and populate nested `tx {inputs, outputs, fee}`.
- [x] Set `status = "prepared"`.
- [x] Output wire `serial_id` is sourced from sender input/output derivation policy; remap formulas are forbidden.
- [x] Override output wire `commitment` from `out.leaf.c_amount` so that `enc_pack` and commitment are cryptographically consistent.
- [x] Override output wire `range_proof` from `out.leaf.range_proof` so that the range proof is valid for the actual commitment.
- [x] Clear `owner_signature` on the wire asset: the dev-fixture signature is over the original fixture commitment and would fail verification after the commitment override.
- [x] Emit structured log row for S4-6.

### S4-7 Verifier gate + artifact write

📌 Serialize package, run `TxVerifierImpl::verify`, write artifact only when valid.

**Implementation Checklist:**
- [x] Reject on verifier error.
- [x] Reject when `valid == false`.
- [x] Write configured tx package path only after successful gate.
- [x] Write `outputs/stage_4_snapshot.json` with digest and output count.
- [x] Emit structured log row for S4-7.

### S4-8 Sender wallet state persistence (`.wlt`)

📌 Reflect spend/update operations in sender `.wlt` via RPC events (no side-state JSON).

**Implementation Checklist:**
- [x] Mark consumed input and change/new outputs in sender wallet domain.
- [x] Persist state changes through wallet RPC/service that writes `.wlt`.
- [x] Emit structured log row for S4-8.

### S4-9 Bob upload + verify + decrypt path

📌 Receiver wallet MUST upload/import Bob output wire artifacts derived from Stage 4 tx package and verify decryptability of Bob output.

**Implementation Checklist:**
- [x] Unlock Bob wallet via RPC.
- [x] Upload/import Bob output wire artifact(s) through configured RPC method.
- [x] Validate Bob ownership check success.
- [x] Validate Bob can decrypt own output payload.
- [x] Lock Bob wallet session.
- [x] Emit structured log row for S4-9.

### S4-10 Cryptographic balance proof gate

📌 Stage 4 MUST include proof/check that plaintext arithmetic and commitment arithmetic both include fee:
- Plaintext gate: `sum(inputs.amount) = sum(outputs.amount) + fee`.
- Commitment gate: `C_in_sum - C_out_sum = C_fee`.

📌 Here `C_fee` is the commitment difference term used by the verifier path; this spec does not require exposing fee blinding material in package JSON.

**Implementation Checklist:**
- [x] Run plaintext arithmetic gate with `fee` included.
- [x] Run commitment-domain gate with `fee` term (`C_fee`).
- [x] Fail closed on any mismatch.
- [x] Emit structured log row for S4-10.

### S4-11 SpendWitness gate

📌 Every input MUST carry SpendWitness and pass witness verification as proof of spending right.

**Implementation Checklist:**
- [x] Build/attach SpendWitness per input.
- [x] Verify SpendWitness before final package write.
- [x] Fail closed on missing/invalid witness.
- [x] Emit structured log row for S4-11.

### S4-12 Audit continuity rows

📌 Ensure every declared Stage 4 step ID has a log row.

**Implementation Checklist:**
- [x] Mark uncovered declared steps with `step_covered` row.
- [x] Keep row format machine-parseable.

### S4-13 Completion

📌 Flush logs and finish with `StageResult::Ok` only if all checks pass.

**Implementation Checklist:**
- [x] Persist `outputs/logs/logger.json`.
- [x] Return fail status on any previous gate failure.

---

## RPC-JSON Event Schema (Mandatory)

📌 Stage 4 transaction preparation MUST use JSON-RPC wallet events and MUST log request/response metadata.

📌 Method names MUST be sourced from `config_scenario.yaml::stage4_tx_prepare.rpc`.

**Required Event Flow:**
- Sender unlock: `wallet.session.unlock_wallet`
- Sender list assets: `wallet.asset.list_assets`
- Receiver unlock: `wallet.session.unlock_wallet`
- Receiver import output wire: `wallet.asset.import_asset`
- Sender/receiver lock: `wallet.session.lock_wallet`

**Request examples (shape):**

```json
{"method":"wallet.session.unlock_wallet","params":{"wallet_id":"...","password":"..."}}
```

```json
{"method":"wallet.asset.list_assets","params":{"wallet_id":"...","limit":50,"cursor":null,"filter":{"asset_class":null,"min_balance":null}}}
```

```json
{"method":"wallet.asset.import_asset","params":{"session":{"wallet_id":"...","token":"..."},"asset_data":"{...AssetWire JSON...}"}}
```

```json
{"method":"wallet.session.lock_wallet","params":{"wallet_id":"..."}}
```

📌 Stage 4 output package MUST be compatible with `tx_verifier` schema (`deny_unknown_fields`).

📌 Required top-level fields:
- `kind == "TxPackage"`
- `version > 0`
- `tx_digest_hex` is 64 hex chars
- `status` non-empty

📌 Required `tx` fields:
- `inputs` non-empty
- `outputs` non-empty
- `fee` equals verifier expected fee formula

📌 Input uniqueness rule:
- `(asset_id, serial_id)` pairs in `tx.inputs` MUST be unique.

📌 Fee coverage rule (current verifier contract):
- declared `fee` MUST be covered by native coin outputs.

📌 Fee-inclusive arithmetic rule (Stage 4 contract):
- `sum(inputs.amount) MUST equal sum(outputs.amount) + fee`.
- Any equality check omitting `fee` is a Stage 4 violation.

📌 Output sanity rules:
- output nonces MUST be non-zero and unique
- coin/token outputs MUST have positive amount
- nft/void outputs MUST have zero amount

---

## Mandatory Acceptance Gates

### AG-1 Structure gate

🎯 `TxVerifierImpl::verify_structure` passes on Stage 4 artifact.

### AG-2 Balance gate

🎯 `TxVerifierImpl::verify_balance` passes (`declared fee` and output conditions).

🎯 Stage 4 plaintext arithmetic gate passes: `sum(inputs.amount) = sum(outputs.amount) + fee`.

🎯 Stage 4 commitment gate passes: `C_in_sum - C_out_sum = C_fee`.

### AG-3 Signature/range gate

🎯 `TxVerifierImpl::verify` returns `valid == true`.

### AG-3.1 Digest gate

🎯 `tx_digest_hex` MUST be 64 lowercase hex characters and deterministic for identical canonical `TxPackage.tx` wire payload.

🎯 Digest input domain MUST be exactly the serialized canonical `tx` wire object (`inputs`, `outputs`, `fee`) that is persisted in package JSON.

### AG-4 Runtime evidence gate

🎯 Files exist and are non-empty:
- `crates/z00z_simulator/src/scenario_1/outputs/transactions/tx_alice_to_bob_pkg.json`
- `crates/z00z_simulator/src/scenario_1/outputs/stage_4_snapshot.json`
- `crates/z00z_simulator/src/scenario_1/outputs/logs/logger.json`

### AG-5 Cross-stage gate

🎯 `cross_stage_stage4_tx_package_created` validates canonical package fields (`kind`, `tx.outputs`, `tx.fee`, `status`, `tx_digest_hex`).

### AG-6 Design contract sync gate

🎯 Stage 4 block in `crates/z00z_simulator/src/scenario_1/design_scenario.yaml` MUST match this document semantics for S4-1..S4-13.

🎯 Any mismatch between this spec and design YAML MUST block declaring Stage 4 spec readiness.

### AG-7 Config source-of-truth gate

🎯 Stage 4 parameters are read from `crates/z00z_simulator/src/scenario_1/config_scenario.yaml::stage4_tx_prepare`.

🎯 No Stage 4 parameter used by runtime may remain hardcoded outside config.

### AG-8 Distinct serial-id gate

🎯 Stage 4 selected input set contains distinct `serial_id` values.

🎯 Default distinct count is `3`; configured target MUST be `<= 10`.

🎯 Stage 4 fails closed when distinct-serial requirement is not satisfiable.

---

## Executable Verification Commands

📌 Run after scenario execution:

```bash
test -f crates/z00z_simulator/src/scenario_1/outputs/transactions/tx_alice_to_bob_pkg.json
test -f crates/z00z_simulator/src/scenario_1/outputs/stage_4_snapshot.json
test -f crates/z00z_simulator/src/scenario_1/outputs/logs/logger.json
```

```bash
python3 - <<'PY'
import json, pathlib
pkg = pathlib.Path("crates/z00z_simulator/src/scenario_1/outputs/transactions/tx_alice_to_bob_pkg.json")
s = json.loads(pkg.read_text())
assert s.get("kind") == "TxPackage"
assert isinstance(s.get("version"), int) and s["version"] > 0
assert isinstance(s.get("tx_digest_hex"), str) and len(s["tx_digest_hex"]) == 64
assert isinstance(s.get("status"), str) and s["status"] == "prepared"
tx = s.get("tx")
assert isinstance(tx, dict)
assert isinstance(tx.get("inputs"), list) and len(tx["inputs"]) > 0
assert isinstance(tx.get("outputs"), list) and len(tx["outputs"]) > 0
assert isinstance(tx.get("fee"), int) and tx["fee"] > 0
print("S4_CANONICAL_OK", len(tx["outputs"]))
PY
```

```bash
cargo test -p z00z_simulator --release --features test-fast --test cross_stage -- --exact cross_stage_stage4_tx_package_created
```

```bash
cargo test -p z00z_wallets --release --features test-fast --test test_spec_terms_guard
```

---

## Known Phase 1 Limitations (Explicit)

⚠️ SpendWitness gate in Phase 1 may be implemented as interface/constraint checks without a full production proving pipeline.

⚠️ Any temporary compatibility layer MUST be explicitly feature-flagged and MUST NOT change normative requirements above.

📌 These limitations are acceptable for Phase 1 only and MUST remain explicitly documented.

---

## Phase 2 Backlog (Not Blocking Phase 1)

⚠️ Finalize canonical `WalletAssetRow -> SpendInputRef + SpendWitness` conversion layer.

⚠️ Non-stub `TxAssemblerImpl::assemble/sum_inputs/sum_outputs/verify_balance`.

⚠️ Domain convergence tasks for wallet-private vs consensus tags/signatures.

⚠️ Complete full checkpoint/state update proof path alignment with consensus domain.

⚠️ Add nullifier-based double-spend prevention and enforce it in verifier gate.

---

## Definition of Done (Stage 4 Phase 1)

✅ Stage 4 outputs canonical `TxPackage` JSON accepted by tx verifier.

✅ Stage 4 fails closed on malformed input/package data.

✅ Stage 4 computes and includes deterministic digest + declared fee.

✅ Stage 4 enforces fee-inclusive balance consistency in both plaintext and commitment domains.

✅ Stage 4 snapshot/log artifacts are generated and auditable.

✅ Stage 4 verifies Bob import/upload path and Bob decryptability for Bob-owned outputs.

✅ Cross-stage test validates canonical Stage 4 artifact contract.

✅ Stage 4 spec, `design_scenario.yaml`, and `config_scenario.yaml` are synchronized.

---

## Supersession and Deletion Gate

🎯 `specs/010-z00z-tx-spec/stage_4_spec.md` MAY be deleted only when all checks below are true:

- [x] This document (`stage_4_spec-1.md`) is adopted as single Stage 4 source in Scenario 1 work items.
- [x] AG-1..AG-8 (including AG-3.1) pass on current branch.
- [x] `design_scenario.yaml` Stage 4 semantics match this document (no placeholder wording/shape).
- [x] No implementation task references remain that point exclusively to old `stage_4_spec.md`.
- [x] Team confirms Phase 1 limitations remain explicitly tracked here.

📌 Deletion decision for current revision: **CONDITIONAL** (allowed only after gate completion).
