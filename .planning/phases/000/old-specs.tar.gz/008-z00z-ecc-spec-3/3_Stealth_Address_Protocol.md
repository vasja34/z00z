# 3. Stealth Address Protocol

## 3.1 Receiver Key Material

**Purpose:** Derive all wallet keys from a single master secret (`receiver_secret`) for secure stealth address operations.

**Foundation:** All receiver keys are deterministically derived from `receiver_secret`, ensuring reproducibility while maintaining ownership protection.

### 3.1.1 Receiver Secret (receiver_secret)

**Definition:** Long-lived 32-byte secret, the root of all receiver key material. MUST NEVER be published or transmitted.

**Role:** Even if ECC becomes weak, ownership protection relies on `receiver_secret` as hash preimage (proof-of-knowledge).

```rust
/// Master secret for receiver wallet
#[derive(Zeroize, ZeroizeOnDrop)]
pub struct ReceiverSecret([u8; 32]);
```

#### 3.1.1.1 Generation

**MUST:**

- Use cryptographically secure random number generator (CSPRNG)
- Verify source entropy meets 256-bit security
- Generate on trusted device (not in untrusted environment)

```rust
use rand_core::{OsRng, RngCore};

pub fn generate_receiver_secret() -> Result<ReceiverSecret, Error> {
    let mut bytes = [0u8; 32];
    OsRng.fill_bytes(&mut bytes);
    
    // Optional: Additional entropy mixing
    let mixed = mix_with_user_entropy(&bytes)?;
    
    Ok(ReceiverSecret(mixed))
}
```

**Entropy Sources (Platform-Specific):**

- Linux: `/dev/urandom` (post-boot)
- Windows: `BCryptGenRandom`
- Mobile: Platform crypto APIs + sensor data mixing
- Hardware: TRNG if available

**MUST NOT:**

- Use predictable seeds
- Generate in VM without proper RNG initialization
- Generate in untrusted execution environments

#### 3.1.1.2 Storage

**Security Requirements:**

```yaml
SecureStorage(MUST):
  at_rest_encryption: AES-256-GCM or XChaCha20-Poly1305
  key_derivation: PBKDF2/Argon2 from user password
  key_isolation: Separate storage key != receiver_secret
  file_permissions: 0600 (user-only read/write)
  
  optional_hardening:
    - OS keystore integration (macOS Keychain, Windows DPAPI, Linux Secret Service)
    - Hardware security module (HSM) for high-value wallets
    - Multi-signature quorum (threshold schemes)
```

**Storage Format:**

```rust
#[derive(Serialize, Deserialize)]
pub struct EncryptedWalletData {
    pub version: u8,
    pub salt: [u8; 16],
    pub nonce: [u8; 24],
    pub encrypted_receiver_secret: Vec<u8>,  // receiver_secret + MAC
    pub metadata: WalletMetadata,
}

impl EncryptedWalletData {
    pub fn store(
        &self,
        receiver_secret: &ReceiverSecret,
        password: &[u8],
    ) -> Result<(), Error> {
        let key = derive_storage_key(password, &self.salt)?;
        let cipher = XChaCha20Poly1305::new(&key.into());
        
        let encrypted = cipher.encrypt(
            &self.nonce.into(),
            receiver_secret.0.as_slice(),
        )?;
        
        // Write to secure location
        secure_write(&encrypted, WalletPath::default())?;
        
        Ok(())
    }
    
    pub fn load(password: &[u8]) -> Result<ReceiverSecret, Error> {
        let data = secure_read(WalletPath::default())?;
        let key = derive_storage_key(password, &data.salt)?;
        let cipher = XChaCha20Poly1305::new(&key.into());
        
        let decrypted = cipher.decrypt(
            &data.nonce.into(),
            data.encrypted_receiver_secret.as_slice(),
        ).map_err(|_| Error::DecryptionFailed)?;
        
        let mut secret = [0u8; 32];
        secret.copy_from_slice(&decrypted[..32]);
        
        Ok(ReceiverSecret(secret))
    }
}

fn derive_storage_key(password: &[u8], salt: &[u8; 16]) -> Result<[u8; 32], Error> {
    use argon2::{Argon2, ParamsBuilder};
    
    let params = ParamsBuilder::new()
        .m_cost(65536)      // 64 MB memory
        .t_cost(3)          // 3 iterations
        .p_cost(4)          // 4 parallelism
        .build()?;
    
    let mut output = [0u8; 32];
    Argon2::new()
        .hash_password_into(password, salt, &mut output)?;
    
    Ok(output)
}
```

**Backup & Recovery:**

```yaml
BackupStrategies:
  mnemonic_phrase:
    - BIP-39 24-word encoding of receiver_secret
    - MUST display only once during generation
    - MUST verify user wrote down before continuing
    
  encrypted_backup:
    - Export encrypted wallet file with strong passphrase
    - Store on separate physical medium
    
  social_recovery:
    - Shamir Secret Sharing (threshold m-of-n)
    - Distribute shares to trusted contacts
    - Reconstruct via secure ceremony
```

#### 3.1.1.3 Derivation Hierarchy

**Optional:** Hierarchical Deterministic (HD) wallet integration for multiple sub-wallets.

```rust
/// HD derivation path: m / purpose' / coin_type' / account' / change / address_index
pub struct DerivationPath {
    pub purpose: u32,      // 44' (BIP-44)
    pub coin_type: u32,    // Z00Z coin type (e.g., 9000')
    pub account: u32,      // Account index
    pub change: u32,       // 0 = external, 1 = internal
    pub index: u32,        // Address index
}

impl ReceiverSecret {
    /// Derive sub-wallet receiver_secret from HD path
    pub fn derive_child(&self, path: &DerivationPath) -> ReceiverSecret {
        let path_bytes = path.to_canonical_encoding();
        let child_bytes = poseidon2_hash(
            b"Z00Z/HD_DERIVE",
            &[&self.0, &path_bytes]
        );
        
        ReceiverSecret(child_bytes)
    }
}
```

**Use Cases:**

- Separate wallets for different purposes (personal, business, cold storage)
- Account-based privacy (different receiver_secret per context)
- Key rotation without losing historical access

### 3.1.2 Owner Handle (owner_handle)

**Definition:** Public off-chain identifier derived from `receiver_secret`. Does NOT grant spending rights.

**Purpose:** Stable wallet identifier for:

- UX display (username-like)
- Ownership tag derivation
- ReceiverCard indexing

#### 3.1.2.1 Derivation

```rust
/// owner_handle = H_zk("Z00Z/RID" || receiver_secret)
pub fn derive_owner_handle(receiver_secret: &ReceiverSecret) -> [u8; 32] {
    poseidon2_hash(b"Z00Z/RID", &[&receiver_secret.0])
}
```

**Properties:**

- Deterministic: Same receiver_secret → same owner_handle
- One-way: Cannot reverse to get receiver_secret
- Collision-resistant: 256-bit output space
- ZK-friendly: Uses Poseidon2 (provable in OWF)

#### 3.1.2.2 Properties

**What owner_handle IS:**

- ✅ Public identifier (can be shared)
- ✅ Binding anchor for ownership tag
- ✅ Directory index key
- ✅ UX display (formatted as Z00Z address)

**What owner_handle IS NOT:**

- ❌ NOT a spending key
- ❌ NOT sufficient for decryption
- ❌ NOT a stable on-chain identifier (not in leaves)

**Leakage Tolerance:**

```yaml
OwnerHandleLeakage(Analysis):
  if_leaked_alone:
    - Cannot spend coins (need receiver_secret)
    - Cannot decrypt enc_pack (need view_sk derived from receiver_secret)
    - Cannot forge ownership proofs
  
  if_leaked_with_view_pk:
    - Can attempt targeted DoS (if tag16 depends on owner_handle only)
    - Mitigation: Derive tag16 from req_id (see §3.7)
  
  recommended_privacy:
    - Treat owner_handle as "public username"
    - Do not publish unless necessary for payment requests
    - Use separate owner_handle per context if needed (HD derivation)
```

#### 3.1.2.3 Usage

**ReceiverCard Indexing:**

```rust
pub struct ReceiverCard {
    pub owner_handle: [u8; 32],
    pub view_pk: RistrettoPoint,
    pub identity_pk: RistrettoPoint,
    pub metadata: Option<CardMetadata>,
}
```

**Address Formatting (UX):**

```rust
/// Format owner_handle as user-facing Z00Z address
pub fn format_address(owner_handle: &[u8; 32]) -> String {
    // Bech32-like encoding with checksum
    let hrp = "z00z";
    let data = owner_handle;
    
    bech32::encode(hrp, data.to_vec(), bech32::Variant::Bech32m)
        .expect("valid encoding")
    
    // Example output: "z00z1qpzry9x8gf2tvdw0s3jn54khce6mua7l..."
}

pub fn parse_address(address: &str) -> Result<[u8; 32], Error> {
    let (hrp, data, _variant) = bech32::decode(address)?;
    
    if hrp != "z00z" {
        return Err(Error::InvalidAddressPrefix);
    }
    
    if data.len() != 32 {
        return Err(Error::InvalidAddressLength);
    }
    
    let mut owner_handle = [0u8; 32];
    owner_handle.copy_from_slice(&data);
    
    Ok(owner_handle)
}
```

**Ownership Verification:**

```rust
/// Prove knowledge of receiver_secret for given owner_handle
pub fn prove_ownership(
    receiver_secret: &ReceiverSecret,
    challenge: &[u8; 32],
) -> OwnershipProof {
    let owner_handle = derive_owner_handle(receiver_secret);
    let signature = schnorr_sign(receiver_secret, challenge);
    
    OwnershipProof { owner_handle, signature }
}
```

### 3.1.3 View Keys (view_sk / view_pk)

**Purpose:** Elliptic curve Diffie-Hellman (ECDH) keys for stealth address operations. Enable output scanning without exposing spending keys.

**Design:** Derived deterministically from receiver_secret, enabling wallet recovery from seed.

#### 3.1.3.1 View Secret Key Derivation

```rust
/// view_sk = H2Scalar_zk("Z00Z/VIEW" || receiver_secret)
pub fn derive_view_secret_key(
    receiver_secret: &ReceiverSecret,
) -> Scalar {
    let hash = poseidon2_hash(b"Z00Z/VIEW", &[&receiver_secret.0]);
    bytes_to_scalar_reduce(&hash)
}
```

**Properties:**

- Deterministic derivation from receiver_secret
- 252-bit scalar in Ristretto255 field
- ZK-friendly hash (Poseidon2)
- Used in OWF constraints

**Security:**

```yaml
ViewSecretKeySecurity:
  secrecy_requirement: MUST remain private (like receiver_secret)
  usage_isolation: Used ONLY for ECDH (not signing)
  leakage_impact: 
    - Can decrypt all incoming outputs
    - Cannot spend (spending requires receiver_secret)
  
  constant_time: MUST use constant-time scalar operations
```

#### 3.1.3.2 View Public Key Derivation

```rust
use curve25519_dalek::ristretto::{RistrettoPoint, RISTRETTO_BASEPOINT_POINT};
use curve25519_dalek::constants::RISTRETTO_BASEPOINT_TABLE;

/// view_pk = view_sk * G
pub fn derive_view_public_key(view_sk: &Scalar) -> RistrettoPoint {
    &RISTRETTO_BASEPOINT_TABLE * view_sk
}
```

**Encoding:**

```rust
/// Canonical compressed Ristretto encoding (32 bytes)
pub fn encode_view_pk(view_pk: &RistrettoPoint) -> [u8; 32] {
    view_pk.compress().to_bytes()
}

/// Decode with validation (MUST NOT be identity)
pub fn decode_view_pk(bytes: &[u8; 32]) -> Result<RistrettoPoint, Error> {
    let compressed = CompressedRistretto::from_slice(bytes);
    let point = compressed.decompress()
        .ok_or(Error::InvalidRistrettoPoint)?;
    
    // MUST reject identity point
    if point == RistrettoPoint::identity() {
        return Err(Error::IdentityPointRejected);
    }
    
    Ok(point)
}
```

**Usage in ReceiverCard:**

```rust
pub struct ReceiverCard {
    pub owner_handle: [u8; 32],
    pub view_pk: [u8; 32],  // Compressed Ristretto point
    // ...
}
```

#### 3.1.3.3 View Key Rotation

**Optional:** Rotate view keys without changing owner_handle (for forward secrecy or compromise recovery).

```rust
pub struct ViewKeyVersion {
    pub version: u32,
    pub valid_from: u64,      // Unix timestamp
    pub valid_until: Option<u64>,
}

/// Derive versioned view key
pub fn derive_view_key_versioned(
    receiver_secret: &ReceiverSecret,
    version: u32,
) -> (Scalar, RistrettoPoint) {
    let version_bytes = version.to_le_bytes();
    let hash = poseidon2_hash(
        b"Z00Z/VIEW_V",
        &[&receiver_secret.0, &version_bytes]
    );
    
    let view_sk = bytes_to_scalar_reduce(&hash);
    let view_pk = derive_view_public_key(&view_sk);
    
    (view_sk, view_pk)
}
```

**Rotation Protocol:**

1. Receiver generates new view key version
2. Publishes new ReceiverCard with updated view_pk
3. Maintains active set of view keys for scanning
4. Scans outputs with all active view keys
5. Deprecates old keys after rotation period

**Tradeoffs:**

```yaml
ViewKeyRotation:
  benefits:
    - Forward secrecy: Past outputs unaffected by future compromise
    - Key compromise recovery: Isolate damage to specific period
    - Privacy reset: Break linkability across rotation boundaries
  
  costs:
    - Must scan with multiple keys (performance impact)
    - Sender must use current ReceiverCard
    - owner_tag/tag16 change (if bound to view_pk, see §3.6)
```

### 3.1.4 Identity Keys (identity_sk / identity_pk)

**Purpose:** Sign PaymentRequest and ReceiverCard for authenticity. Separate from spending and view keys.

**Rationale:** Signing keys can be rotated or compromised without affecting coin ownership or scanning.

#### 3.1.4.1 Identity Key Generation

**Option A (Recommended): Derive from receiver_secret**

```rust
/// identity_sk = H2Scalar_zk("Z00Z/IDENTITY" || receiver_secret || version)
pub fn derive_identity_secret_key(
    receiver_secret: &ReceiverSecret,
    version: u32,
) -> Scalar {
    let version_bytes = version.to_le_bytes();
    let hash = poseidon2_hash(
        b"Z00Z/IDENTITY",
        &[&receiver_secret.0, &version_bytes]
    );
    
    bytes_to_scalar_reduce(&hash)
}

pub fn derive_identity_public_key(identity_sk: &Scalar) -> RistrettoPoint {
    &RISTRETTO_BASEPOINT_TABLE * identity_sk
}
```

**Option B: Independent Generation (Advanced)**

```rust
/// Generate separate identity key (not derived from receiver_secret)
pub fn generate_identity_keypair() -> (Scalar, RistrettoPoint) {
    let mut rng = OsRng;
    let identity_sk = Scalar::random(&mut rng);
    let identity_pk = &RISTRETTO_BASEPOINT_TABLE * &identity_sk;
    
    (identity_sk, identity_pk)
}
```

**Storage:**

- Store identity_sk separately (can be on less secure device for convenience)
- Backup identity_sk if using Option B
- Version identity keys for rotation

#### 3.1.4.2 Identity Signatures

**Schnorr Signatures (Ristretto255):**

```rust
use schnorrkel::{Keypair, PublicKey, Signature, signing_context};

pub fn sign_identity(
    identity_sk: &Scalar,
    message: &[u8],
    context: &[u8],
) -> Result<[u8; 64], Error> {
    // Convert to schnorrkel format
    let secret = schnorrkel::SecretKey::from_bytes(&identity_sk.to_bytes())?;
    let public = schnorrkel::PublicKey::from_secret(&secret);
    let keypair = Keypair { secret, public };
    
    let ctx = signing_context(context);
    let signature = keypair.sign(ctx.bytes(message));
    
    Ok(signature.to_bytes())
}

pub fn verify_identity(
    identity_pk: &RistrettoPoint,
    message: &[u8],
    context: &[u8],
    signature: &[u8; 64],
) -> Result<(), Error> {
    let public = PublicKey::from_bytes(&identity_pk.compress().to_bytes())?;
    let sig = Signature::from_bytes(signature)?;
    
    let ctx = signing_context(context);
    public.verify(ctx.bytes(message), &sig)
        .map_err(|_| Error::SignatureVerificationFailed)
}
```

**Usage in ReceiverCard:**

```rust
pub struct ReceiverCard {
    pub owner_handle: [u8; 32],
    pub view_pk: [u8; 32],
    pub identity_pk: [u8; 32],
    pub valid_from: u64,
    pub signature: [u8; 64],  // Sign(identity_sk, canonical_encoding(fields))
}

impl ReceiverCard {
    pub fn sign(&mut self, identity_sk: &Scalar) -> Result<(), Error> {
        let msg = self.canonical_encoding_unsigned();
        self.signature = sign_identity(identity_sk, &msg, b"Z00Z/CARD_v1")?;
        Ok(())
    }
    
    pub fn verify(&self) -> Result<(), Error> {
        let msg = self.canonical_encoding_unsigned();
        let identity_pk = decode_view_pk(&self.identity_pk)?;
        
        verify_identity(&identity_pk, &msg, b"Z00Z/CARD_v1", &self.signature)
    }
}
```

### 3.1.5 Key Material API

**Unified Interface:**

```rust
pub struct ReceiverKeys {
    pub receiver_secret: ReceiverSecret,
    pub owner_handle: [u8; 32],
    pub view_sk: Scalar,
    pub view_pk: RistrettoPoint,
    pub identity_sk: Scalar,
    pub identity_pk: RistrettoPoint,
}

impl ReceiverKeys {
    /// Derive all keys from receiver_secret
    pub fn from_receiver_secret(receiver_secret: ReceiverSecret) -> Self {
        let owner_handle = derive_owner_handle(&receiver_secret);
        let view_sk = derive_view_secret_key(&receiver_secret);
        let view_pk = derive_view_public_key(&view_sk);
        let identity_sk = derive_identity_secret_key(&receiver_secret, 0);
        let identity_pk = derive_identity_public_key(&identity_sk);
        
        Self {
            receiver_secret,
            owner_handle,
            view_sk,
            view_pk,
            identity_sk,
            identity_pk,
        }
    }
    
    /// Export ReceiverCard for distribution
    pub fn export_receiver_card(&self) -> ReceiverCard {
        ReceiverCard {
            owner_handle: self.owner_handle,
            view_pk: self.view_pk.compress().to_bytes(),
            identity_pk: self.identity_pk.compress().to_bytes(),
            metadata: None,
        }
    }
}
```

#### 3.1.5.1 Key Derivation Trait

```rust
pub trait DeriveReceiverKeys {
    fn derive_owner_handle(&self) -> [u8; 32];
    fn derive_view_keys(&self) -> (Scalar, RistrettoPoint);
    fn derive_identity_keys(&self, version: u32) -> (Scalar, RistrettoPoint);
}

impl DeriveReceiverKeys for ReceiverSecret {
    fn derive_owner_handle(&self) -> [u8; 32] {
        derive_owner_handle(self)
    }
    
    fn derive_view_keys(&self) -> (Scalar, RistrettoPoint) {
        let sk = derive_view_secret_key(self);
        let pk = derive_view_public_key(&sk);
        (sk, pk)
    }
    
    fn derive_identity_keys(&self, version: u32) -> (Scalar, RistrettoPoint) {
        let sk = derive_identity_secret_key(self, version);
        let pk = derive_identity_public_key(&sk);
        (sk, pk)
    }
}
```

#### 3.1.5.2 Key Storage Trait

```rust
pub trait SecureKeyStore {
    fn store_receiver_secret(&mut self, secret: &ReceiverSecret, password: &[u8]) -> Result<(), Error>;
    fn load_receiver_secret(&self, password: &[u8]) -> Result<ReceiverSecret, Error>;
    fn export_encrypted_backup(&self, password: &[u8]) -> Result<Vec<u8>, Error>;
    fn import_encrypted_backup(backup: &[u8], password: &[u8]) -> Result<Self, Error> where Self: Sized;
}

pub struct FileKeyStore {
    wallet_path: PathBuf,
}

impl SecureKeyStore for FileKeyStore {
    fn store_receiver_secret(
        &mut self,
        secret: &ReceiverSecret,
        password: &[u8],
    ) -> Result<(), Error> {
        let salt = rand::random::<[u8; 16]>();
        let nonce = rand::random::<[u8; 24]>();
        
        let data = EncryptedWalletData {
            version: 1,
            salt,
            nonce,
            encrypted_receiver_secret: vec![],
            metadata: WalletMetadata::default(),
        };
        
        data.store(secret, password)
    }
    
    fn load_receiver_secret(&self, password: &[u8]) -> Result<ReceiverSecret, Error> {
        EncryptedWalletData::load(password)
    }
    
    // ... backup/import implementations
}
```

**Testing:**

```rust
#[cfg(test)]
mod tests {
    use super::*;
    
    #[test]
    fn test_key_derivation_deterministic() {
        let secret = ReceiverSecret([0x42; 32]);
        
        let keys1 = ReceiverKeys::from_receiver_secret(secret.clone());
        let keys2 = ReceiverKeys::from_receiver_secret(secret.clone());
        
        assert_eq!(keys1.owner_handle, keys2.owner_handle);
        assert_eq!(keys1.view_sk, keys2.view_sk);
        assert_eq!(keys1.identity_sk, keys2.identity_sk);
    }
    
    #[test]
    fn test_view_pk_encoding_roundtrip() {
        let secret = ReceiverSecret([0x42; 32]);
        let view_sk = derive_view_secret_key(&secret);
        let view_pk = derive_view_public_key(&view_sk);
        
        let encoded = encode_view_pk(&view_pk);
        let decoded = decode_view_pk(&encoded).unwrap();
        
        assert_eq!(view_pk, decoded);
    }
    
    #[test]
    fn test_identity_signature() {
        let secret = ReceiverSecret([0x42; 32]);
        let identity_sk = derive_identity_secret_key(&secret, 0);
        let identity_pk = derive_identity_public_key(&identity_sk);
        
        let message = b"test message";
        let sig = sign_identity(&identity_sk, message, b"TEST").unwrap();
        
        verify_identity(&identity_pk, message, b"TEST", &sig).unwrap();
    }
}
```

## 3.2 ReceiverCard

**Purpose:** Published receiver metadata enabling one-shot payments without handshake. Offline "business card" containing public key material.

**Critical Security Boundary:** ReceiverCard published to directory/relay is visible to aggregators in notary model. Design assumes privacy from state observers, not from payment routing.

### 3.2.1 ReceiverCard Structure

**Definition:** Receiver publishes eternal, offline card. Senders use this to create outputs.

```rust
#[derive(Clone, Debug, Serialize, Deserialize)]
pub struct ReceiverCard {
    pub version: u8,
    pub owner_handle: [u8; 32],
    pub view_pk: [u8; 32],           // Compressed Ristretto point
    pub identity_pk: [u8; 32],       // For signature verification
    pub card_id: Option<[u8; 16]>,   // UX label / checksum
    pub metadata: Option<CardMetadata>,
    pub signature: [u8; 64],         // Sign(identity_sk, canonical_encoding(fields))
}

#[derive(Clone, Debug, Serialize, Deserialize)]
pub struct CardMetadata {
    pub created_at: u64,             // Unix timestamp
    pub display_name: Option<String>,
    pub valid_until: Option<u64>,
    pub contact: Option<String>,     // Email/handle for out-of-band contact
}
```

#### 3.2.1.1 Fields

**owner_handle (32 bytes):**

- Derived: `H_zk("Z00Z/RID" || receiver_secret)`
- Purpose: Stable wallet identifier
- Public: Can be shared (does not grant spending)
- UX: Formatted as bech32 Z00Z address

**view_pk (32 bytes):**

- Derived: `view_pk = view_sk * G` where `view_sk = H2Scalar_zk("Z00Z/VIEW" || receiver_secret)`
- Encoding: Compressed Ristretto point (canonical 32 bytes)
- Purpose: ECDH public key for stealth address construction
- MUST: NOT be identity point

**identity_pk (32 bytes):**

- Purpose: Verify ReceiverCard signature (authenticity/integrity)
- Can be: Derived from receiver_secret OR independently generated
- Usage: Long-term identity binding (can remain pseudonymous)

**card_id (optional 16 bytes):**

- Purpose: UX label, checksum, or short identifier
- Derivation: `Trunc16(H_zk("Z00Z/CARDID" || owner_handle || created_at))`
- Not cryptographically critical

**metadata (optional):**

- Display name, creation timestamp, validity period
- Contact info for out-of-band communication
- NOT signed separately (included in canonical encoding)

**signature (64 bytes):**

- Schnorr signature over canonical encoding
- Context: `"Z00Z/CARD_v1"`
- Prevents directory from forging or silently modifying cards

#### 3.2.1.2 Serialization

**Canonical Encoding (MUST):**

```rust
impl ReceiverCard {
    /// Canonical encoding for signature (unsigned fields only)
    pub fn canonical_encoding_unsigned(&self) -> Vec<u8> {
        let mut buf = Vec::new();
        
        buf.push(self.version);
        buf.extend_from_slice(&self.owner_handle);
        buf.extend_from_slice(&self.view_pk);
        buf.extend_from_slice(&self.identity_pk);
        
        if let Some(cid) = self.card_id {
            buf.push(1);  // presence flag
            buf.extend_from_slice(&cid);
        } else {
            buf.push(0);
        }
        
        if let Some(ref meta) = self.metadata {
            buf.push(1);
            buf.extend_from_slice(&meta.canonical_encoding());
        } else {
            buf.push(0);
        }
        
        buf
    }
    
    /// Full encoding (including signature)
    pub fn canonical_encoding(&self) -> Vec<u8> {
        let mut buf = self.canonical_encoding_unsigned();
        buf.extend_from_slice(&self.signature);
        buf
    }
    
    /// Sign the card
    pub fn sign(&mut self, identity_sk: &Scalar) -> Result<(), Error> {
        let msg = self.canonical_encoding_unsigned();
        self.signature = sign_identity(identity_sk, &msg, b"Z00Z/CARD_v1")?;
        Ok(())
    }
    
    /// Verify card signature
    pub fn verify(&self) -> Result<(), Error> {
        let msg = self.canonical_encoding_unsigned();
        let identity_pk = decode_view_pk(&self.identity_pk)?;
        
        verify_identity(&identity_pk, &msg, b"Z00Z/CARD_v1", &self.signature)
    }
}
```

**Wire Format (for QR codes / URLs):**

```rust
/// Base64url encoding for compact transmission
pub fn encode_card_compact(card: &ReceiverCard) -> String {
    let canonical = card.canonical_encoding();
    base64::encode_config(&canonical, base64::URL_SAFE_NO_PAD)
}

pub fn decode_card_compact(encoded: &str) -> Result<ReceiverCard, Error> {
    let bytes = base64::decode_config(encoded, base64::URL_SAFE_NO_PAD)?;
    ReceiverCard::from_canonical_encoding(&bytes)
}
```

### 3.2.2 ReceiverCard Trust Model

**Problem:** Malicious directory can substitute `view_pk` while keeping `owner_handle`, causing outputs to be unspendable by intended receiver.

**Solution:** Three variants of trust models, each with different security/complexity tradeoffs.

#### 3.2.2.1 Variant 1: Identity Pinning / TOFU (Recommended)

**Trust-On-First-Use (TOFU) + Local Pinning:**

```yaml
ReceiverCardTOFU(Recommended):
  first_use:
    - Verify identity_signature on ReceiverCard
    - Store (owner_handle → view_pk, identity_pk, directory_id) locally
    - Trust this binding going forward
  
  subsequent_use:
    - If same owner_handle but different view_pk → WARNING
    - Require explicit user confirmation for rotation
    - Log event for audit
  
  security_properties:
    - Directory cannot silently substitute view_pk after first use
    - User controls trust decisions
    - Compatible with view key rotation (with UX confirmation)
```

**Implementation:**

```rust
pub struct PinnedReceiverCards {
    pins: HashMap<[u8; 32], PinEntry>,  // owner_handle → pin
}

pub struct PinEntry {
    pub view_pk: [u8; 32],
    pub identity_pk: [u8; 32],
    pub directory_id: Option<String>,
    pub first_seen: u64,
    pub trust_level: TrustLevel,
}

pub enum TrustLevel {
    Pinned,         // Verified and pinned
    Tentative,      // First use, not yet confirmed
    Expired,        // Past valid_until
    Revoked,        // User manually revoked
}

impl PinnedReceiverCards {
    pub fn verify_or_pin(
        &mut self,
        card: &ReceiverCard,
        directory_id: Option<&str>,
    ) -> Result<VerifyResult, Error> {
        // Verify signature first
        card.verify()?;
        
        match self.pins.get(&card.owner_handle) {
            None => {
                // First time seeing this owner_handle
                let pin = PinEntry {
                    view_pk: card.view_pk,
                    identity_pk: card.identity_pk,
                    directory_id: directory_id.map(|s| s.to_string()),
                    first_seen: unix_timestamp(),
                    trust_level: TrustLevel::Tentative,
                };
                
                self.pins.insert(card.owner_handle, pin);
                Ok(VerifyResult::NewPin)
            }
            Some(pin) => {
                if pin.view_pk != card.view_pk {
                    // View key rotation detected!
                    return Ok(VerifyResult::ViewKeyChanged {
                        old_pk: pin.view_pk,
                        new_pk: card.view_pk,
                        requires_confirmation: true,
                    });
                }
                
                if pin.identity_pk != card.identity_pk {
                    // Identity key changed (very unusual)
                    return Ok(VerifyResult::IdentityKeyChanged);
                }
                
                Ok(VerifyResult::Verified)
            }
        }
    }
    
    pub fn confirm_rotation(&mut self, owner_handle: &[u8; 32], new_view_pk: &[u8; 32]) {
        if let Some(pin) = self.pins.get_mut(owner_handle) {
            pin.view_pk = *new_view_pk;
            pin.trust_level = TrustLevel::Pinned;
        }
    }
}

pub enum VerifyResult {
    NewPin,
    Verified,
    ViewKeyChanged {
        old_pk: [u8; 32],
        new_pk: [u8; 32],
        requires_confirmation: bool,
    },
    IdentityKeyChanged,
}
```

##### 3.2.2.1.1 Identity Signature

**Purpose:** Bind `(owner_handle, view_pk)` pair cryptographically. Directory cannot forge without identity_sk.

```rust
/// Signature over ReceiverCard fields
/// Context: "Z00Z/CARD_v1"
/// Message: canonical_encoding_unsigned()
pub fn sign_receiver_card(
    card: &mut ReceiverCard,
    identity_sk: &Scalar,
) -> Result<(), Error> {
    card.sign(identity_sk)
}
```

##### 3.2.2.1.2 Pin Storage

**Local Database:**

```rust
// SQLite schema for pin storage
const PIN_SCHEMA: &str = r#"
CREATE TABLE IF NOT EXISTS receiver_pins (
    owner_handle BLOB PRIMARY KEY,
    view_pk BLOB NOT NULL,
    identity_pk BLOB NOT NULL,
    directory_id TEXT,
    first_seen INTEGER NOT NULL,
    trust_level INTEGER NOT NULL,
    notes TEXT
);

CREATE INDEX IF NOT EXISTS idx_trust_level ON receiver_pins(trust_level);
"#;
```

##### 3.2.2.1.3 Rotation Handling

**User Confirmation Flow:**

```rust
pub async fn handle_view_key_rotation(
    ui: &UserInterface,
    result: VerifyResult,
) -> Result<bool, Error> {
    match result {
        VerifyResult::ViewKeyChanged { old_pk, new_pk, .. } => {
            let confirmed = ui.confirm(format!(
                "View key rotation detected for {}.\n\
                 Old: {}\n\
                 New: {}\n\
                 Accept rotation?",
                format_address(&owner_handle),
                hex::encode(old_pk),
                hex::encode(new_pk),
            )).await?;
            
            Ok(confirmed)
        }
        _ => Ok(true),
    }
}
```

#### 3.2.2.2 Variant 2: Derive owner_handle from identity_pk

**Cryptographic Binding:**

```rust
/// Alternative: owner_handle derived from identity_pk instead of receiver_secret
pub fn derive_owner_handle_from_identity(identity_pk: &RistrettoPoint) -> [u8; 32] {
    let pk_bytes = identity_pk.compress().to_bytes();
    poseidon2_hash(b"Z00Z/RID_FROM_ID", &[&pk_bytes])
}
```

**Benefits:**

- `owner_handle` cryptographically bound to `identity_pk`
- Directory cannot change `view_pk` without changing `owner_handle`
- No need for signature verification (binding is implicit)

**Tradeoffs:**

- `owner_handle` changes when identity_pk rotates
- Less flexible for key management
- Breaks address stability on identity rotation

#### 3.2.2.3 Variant 3: Explicit PKI Trust

**Directory as Trusted PKI:**

```yaml
PKI_Trust_Model:
  assumption: "Users trust directory to provide correct (owner_handle, view_pk) binding"
  verification: "Wallet may verify directory's root certificate"
  risk: "Malicious directory can redirect funds (but cannot steal without receiver_secret)"
  mitigation: 
    - Use reputable directories only
    - Implement optional pinning even in PKI mode
    - Monitor for suspicious patterns
```

**Not Recommended** unless operating in controlled enterprise environment with trusted infrastructure.

### 3.2.3 ReceiverCard Distribution

**Methods:**

#### 3.2.3.1 Directory Service

**Centralized/Federated Directory:**

```rust
pub trait DirectoryService {
    async fn publish_card(&self, card: &ReceiverCard) -> Result<(), Error>;
    async fn lookup_card(&self, owner_handle: &[u8; 32]) -> Result<ReceiverCard, Error>;
    async fn update_card(&self, card: &ReceiverCard, auth: &DirectoryAuth) -> Result<(), Error>;
}

pub struct DirectoryAuth {
    pub signature: [u8; 64],  // Prove ownership of identity_sk
    pub timestamp: u64,
}
```

**API Example:**

```http
POST /api/v1/cards
Content-Type: application/json

{
  "card": "<base64_canonical_encoding>",
  "auth": {
    "signature": "<signature_over_card>",
    "timestamp": 1234567890
  }
}

GET /api/v1/cards/{owner_handle}
Accept: application/json

Response:
{
  "card": "<base64_canonical_encoding>",
  "published_at": 1234567890
}
```

#### 3.2.3.2 Direct Exchange

**Out-of-Band Methods:**

1. **QR Code:**

```rust
pub fn generate_qr_code(card: &ReceiverCard) -> Result<QrCode, Error> {
    let compact = encode_card_compact(card);
    let uri = format!("z00z:card?data={}", compact);
    
    QrCode::new(uri.as_bytes())
}
```

2. **NFC Transfer:**

```rust
pub fn nfc_ndef_record(card: &ReceiverCard) -> NdefRecord {
    let canonical = card.canonical_encoding();
    NdefRecord::new_mime("application/z00z-receiver-card", &canonical)
}
```

3. **URL Link:**

```
z00z://card?data=<base64_compact_card>
```

4. **File Export:**

```json
{
  "version": 1,
  "type": "z00z-receiver-card",
  "data": "<base64_canonical_encoding>"
}
```

### 3.2.4 ReceiverCard API

**High-Level Operations:**

```rust
pub trait ReceiverCardOperations {
    fn create(keys: &ReceiverKeys) -> Result<ReceiverCard, Error>;
    fn verify(&self) -> Result<(), Error>;
    fn is_expired(&self) -> bool;
    fn format_address(&self) -> String;
}

impl ReceiverCardOperations for ReceiverCard {
    fn create(keys: &ReceiverKeys) -> Result<ReceiverCard, Error> {
        let mut card = ReceiverCard {
            version: 1,
            owner_handle: keys.owner_handle,
            view_pk: keys.view_pk.compress().to_bytes(),
            identity_pk: keys.identity_pk.compress().to_bytes(),
            card_id: Some(generate_card_id(&keys.owner_handle)),
            metadata: Some(CardMetadata {
                created_at: unix_timestamp(),
                display_name: None,
                valid_until: None,
                contact: None,
            }),
            signature: [0u8; 64],
        };
        
        card.sign(&keys.identity_sk)?;
        
        Ok(card)
    }
    
    fn verify(&self) -> Result<(), Error> {
        ReceiverCard::verify(self)
    }
    
    fn is_expired(&self) -> bool {
        if let Some(ref meta) = self.metadata {
            if let Some(until) = meta.valid_until {
                return unix_timestamp() > until;
            }
        }
        false
    }
    
    fn format_address(&self) -> String {
        format_address(&self.owner_handle)
    }
}
```

#### 3.2.4.1 Validation Trait

```rust
pub trait ValidateReceiverCard {
    fn validate_structure(&self) -> Result<(), ValidationError>;
    fn validate_signature(&self) -> Result<(), ValidationError>;
    fn validate_ecc_points(&self) -> Result<(), ValidationError>;
}

impl ValidateReceiverCard for ReceiverCard {
    fn validate_structure(&self) -> Result<(), ValidationError> {
        // Version check
        if self.version != 1 {
            return Err(ValidationError::UnsupportedVersion(self.version));
        }
        
        // Signature length
        if self.signature.len() != 64 {
            return Err(ValidationError::InvalidSignatureLength);
        }
        
        Ok(())
    }
    
    fn validate_signature(&self) -> Result<(), ValidationError> {
        self.verify()
            .map_err(|_| ValidationError::SignatureVerificationFailed)
    }
    
    fn validate_ecc_points(&self) -> Result<(), ValidationError> {
        // Validate view_pk
        let view_pk = decode_view_pk(&self.view_pk)
            .map_err(|_| ValidationError::InvalidViewPublicKey)?;
        
        if view_pk == RistrettoPoint::identity() {
            return Err(ValidationError::IdentityPointRejected);
        }
        
        // Validate identity_pk
        let identity_pk = decode_view_pk(&self.identity_pk)
            .map_err(|_| ValidationError::InvalidIdentityPublicKey)?;
        
        if identity_pk == RistrettoPoint::identity() {
            return Err(ValidationError::IdentityPointRejected);
        }
        
        Ok(())
    }
}

#[derive(Debug, Clone)]
pub enum ValidationError {
    UnsupportedVersion(u8),
    InvalidSignatureLength,
    SignatureVerificationFailed,
    InvalidViewPublicKey,
    InvalidIdentityPublicKey,
    IdentityPointRejected,
}
```

#### 3.2.4.2 Untrusted Input Handling

**MUST: Bounded Parsing (no panic):**

```rust
impl ReceiverCard {
    /// Parse from untrusted bytes (no panic, bounded)
    pub fn from_untrusted_bytes(bytes: &[u8]) -> Result<Self, ParseError> {
        // Length check
        if bytes.len() < MIN_CARD_SIZE || bytes.len() > MAX_CARD_SIZE {
            return Err(ParseError::InvalidLength);
        }
        
        let mut cursor = Cursor::new(bytes);
        
        // Version
        let version = cursor.read_u8()
            .map_err(|_| ParseError::TruncatedData)?;
        
        if version != 1 {
            return Err(ParseError::UnsupportedVersion(version));
        }
        
        // owner_handle (32 bytes fixed)
        let mut owner_handle = [0u8; 32];
        cursor.read_exact(&mut owner_handle)
            .map_err(|_| ParseError::TruncatedData)?;
        
        // view_pk (32 bytes fixed)
        let mut view_pk = [0u8; 32];
        cursor.read_exact(&mut view_pk)
            .map_err(|_| ParseError::TruncatedData)?;
        
        // Validate view_pk immediately
        decode_view_pk(&view_pk)
            .map_err(|_| ParseError::InvalidEccPoint)?;
        
        // ... continue parsing with bounds checks
        
        let card = ReceiverCard {
            version,
            owner_handle,
            view_pk,
            // ...
        };
        
        // Final validation
        card.validate_structure()?;
        card.validate_ecc_points()?;
        
        Ok(card)
    }
}

const MIN_CARD_SIZE: usize = 1 + 32 + 32 + 32 + 64;  // version + handles + sig
const MAX_CARD_SIZE: usize = 4096;  // Prevent memory exhaustion

#[derive(Debug, Clone)]
pub enum ParseError {
    InvalidLength,
    UnsupportedVersion(u8),
    TruncatedData,
    InvalidEccPoint,
}
```

**Testing:**

```rust
#[cfg(test)]
mod tests {
    use super::*;
    
    #[test]
    fn test_receiver_card_create_and_verify() {
        let secret = ReceiverSecret([0x42; 32]);
        let keys = ReceiverKeys::from_receiver_secret(secret);
        
        let card = ReceiverCard::create(&keys).unwrap();
        card.verify().unwrap();
    }
    
    #[test]
    fn test_pin_tofu() {
        let mut pins = PinnedReceiverCards::default();
        let card = create_test_card();
        
        // First use
        let result = pins.verify_or_pin(&card, Some("directory1")).unwrap();
        assert!(matches!(result, VerifyResult::NewPin));
        
        // Second use (should verify)
        let result = pins.verify_or_pin(&card, Some("directory1")).unwrap();
        assert!(matches!(result, VerifyResult::Verified));
    }
    
    #[test]
    fn test_view_key_rotation_detection() {
        let mut pins = PinnedReceiverCards::default();
        let mut card = create_test_card();
        
        // Pin original
        pins.verify_or_pin(&card, None).unwrap();
        
        // Rotate view key
        card.view_pk = [0xFF; 32];
        card.sign(&new_identity_sk()).unwrap();
        
        let result = pins.verify_or_pin(&card, None).unwrap();
        assert!(matches!(result, VerifyResult::ViewKeyChanged { .. }));
    }
    
    #[test]
    fn test_untrusted_parse_bounds() {
        // Too short
        let short = vec![1u8; 10];
        assert!(ReceiverCard::from_untrusted_bytes(&short).is_err());
        
        // Too long
        let long = vec![0u8; 100000];
        assert!(ReceiverCard::from_untrusted_bytes(&long).is_err());
        
        // Invalid ECC point
        let mut invalid = vec![1u8; 200];
        invalid[1..33].fill(0xFF);  // Invalid Ristretto
        assert!(ReceiverCard::from_untrusted_bytes(&invalid).is_err());
    }
}
```

## 3.3 PaymentRequest

**Purpose:** Invoice-based payment flow providing strongest protection against sending to nonexistent/compromised addresses. Recommended for all high-value transactions.

**Security Goals:**

- Prevent "send to nonexistent address" (no such receiver_secret exists)
- Prevent "send to outdated ReceiverCard" (view_pk rotated)
- Prevent directory/relay substitution attacks
- Enable targeted DoS protection via req_id

**Design:** Receiver generates signed, time-limited invoice containing ephemeral request ID. Sender MUST verify signature before creating output.

### 3.3.1 PaymentRequest Structure

**Definition:** Signed invoice proving receiver controls identity_pk and providing current view_pk + ephemeral req_id.

```rust
// TODO: Implement in z00z_wallets::core::payment_request
// ⚠️ CONCEPTUAL - Not yet in codebase
#[derive(Clone, Debug, Serialize, Deserialize)]
pub struct PaymentRequest {
    pub version: u8,
    pub owner_handle: [u8; 32],      // Receiver's stable identifier
    pub identity_pk: [u8; 32],       // For signature verification
    pub view_pk: [u8; 32],           // Current ECDH public key
    pub req_id: [u8; 32],            // Ephemeral one-time secret
    pub chain_id: u32,               // Network identifier
    pub expiry: u64,                 // Unix timestamp
    pub amount: Option<u64>,         // Requested amount (optional)
    pub metadata: Option<RequestMetadata>,
    pub signature: [u8; 64],         // Sign(identity_sk, canonical_encoding)
}

#[derive(Clone, Debug, Serialize, Deserialize)]
pub struct RequestMetadata {
    pub memo: Option<String>,
    pub payment_id: Option<[u8; 16]>,
    pub min_confirmations: Option<u32>,
    pub return_address: Option<String>,  // For refunds
}
```

#### 3.3.1.1 Fields

**owner_handle (32 bytes):**

- Receiver's stable identifier (UX display)
- Derived: `H_zk("Z00Z/RID" || receiver_secret)`
- Purpose: Wallet can verify continuity with pinned identity

**identity_pk (32 bytes):**

- Public key for signature verification
- MUST match pinned identity_pk (TOFU from §3.2.2.1)
- Proves request authenticity

**view_pk (32 bytes):**

- Current ECDH public key (may have rotated since ReceiverCard)
- Sender MUST use THIS view_pk (not cached ReceiverCard)
- Enables view key rotation without breaking payments

**req_id (32 bytes):**

- Ephemeral one-time secret (random per request)
- Purpose:
  - Binds k_dh to specific request (anti-DoS)
  - Enables tag16 uniqueness per invoice
  - Optional: Route key for inbox helpers
- MUST be unpredictable (cryptographically random)
- MUST NOT be reused across requests

```rust
pub fn generate_req_id() -> [u8; 32] {
    let mut bytes = [0u8; 32];
    OsRng.fill_bytes(&mut bytes);
    bytes
}
```

**chain_id (4 bytes):**

- Network identifier (mainnet vs testnets)
- Prevents cross-chain replay
- Example: `0x00000001` = mainnet, `0x00000002` = testnet1

**expiry (8 bytes):**

- Unix timestamp (seconds since epoch)
- Sender MUST reject if `current_time > expiry`
- Typical validity: 15 minutes to 24 hours
- Balance security (short) vs UX (long)

```rust
pub fn is_expired(&self) -> bool {
    unix_timestamp() > self.expiry
}

pub fn remaining_seconds(&self) -> i64 {
    self.expiry as i64 - unix_timestamp() as i64
}
```

**amount (optional 8 bytes):**

- Requested amount in base units
- If `None`: sender chooses amount (donation/tip)
- If `Some(v)`: sender SHOULD pay exactly `v`
- Wallet MAY warn if sender deviates

**metadata (optional):**

- `memo`: Human-readable payment description
- `payment_id`: Merchant order ID / reference
- `min_confirmations`: Required checkpoint depth before delivery
- `return_address`: Refund destination if payment fails

**signature (64 bytes):**

- Schnorr signature over canonical encoding (unsigned fields)
- Context: `"Z00Z/REQv1"`
- Proves: Signer controls identity_sk corresponding to identity_pk

#### 3.3.1.2 Signature

**Canonical Encoding:**

```rust
impl PaymentRequest {
    /// Canonical encoding for signature (unsigned fields only)
    pub fn canonical_encoding_unsigned(&self) -> Vec<u8> {
        let mut buf = Vec::new();
        
        buf.push(self.version);
        buf.extend_from_slice(&self.owner_handle);
        buf.extend_from_slice(&self.identity_pk);
        buf.extend_from_slice(&self.view_pk);
        buf.extend_from_slice(&self.req_id);
        buf.extend_from_slice(&self.chain_id.to_le_bytes());
        buf.extend_from_slice(&self.expiry.to_le_bytes());
        
        // Optional amount
        if let Some(amt) = self.amount {
            buf.push(1);
            buf.extend_from_slice(&amt.to_le_bytes());
        } else {
            buf.push(0);
        }
        
        // Optional metadata
        if let Some(ref meta) = self.metadata {
            buf.push(1);
            buf.extend_from_slice(&meta.canonical_encoding());
        } else {
            buf.push(0);
        }
        
        buf
    }
    
    /// Sign the request
    pub fn sign(&mut self, identity_sk: &Scalar) -> Result<(), Error> {
        let msg = self.canonical_encoding_unsigned();
        self.signature = sign_identity(identity_sk, &msg, b"Z00Z/REQv1")?;
        Ok(())
    }
    
    /// Verify request signature
    pub fn verify(&self) -> Result<(), Error> {
        let msg = self.canonical_encoding_unsigned();
        let identity_pk = decode_view_pk(&self.identity_pk)?;
        
        verify_identity(&identity_pk, &msg, b"Z00Z/REQv1", &self.signature)
    }
}
```

### 3.3.2 PaymentRequest Lifecycle

**Flow:** Receiver generates → distributes → sender validates → sender creates output

#### 3.3.2.1 Generation

**Receiver Wallet:**

```rust
pub fn generate_payment_request(
    keys: &ReceiverKeys,
    amount: Option<u64>,
    expiry_seconds: u64,
    memo: Option<String>,
) -> Result<PaymentRequest, Error> {
    let req_id = generate_req_id();
    let expiry = unix_timestamp() + expiry_seconds;
    
    let metadata = if memo.is_some() {
        Some(RequestMetadata {
            memo,
            payment_id: None,
            min_confirmations: None,
            return_address: None,
        })
    } else {
        None
    };
    
    let mut request = PaymentRequest {
        version: 1,
        owner_handle: keys.owner_handle,
        identity_pk: keys.identity_pk.compress().to_bytes(),
        view_pk: keys.view_pk.compress().to_bytes(),
        req_id,
        chain_id: MAINNET_CHAIN_ID,
        expiry,
        amount,
        metadata,
        signature: [0u8; 64],
    };
    
    request.sign(&keys.identity_sk)?;
    
    Ok(request)
}
```

**Usage:**

```rust
// Merchant invoice
let invoice = generate_payment_request(
    &receiver_keys,
    Some(1_000_000),  // 1 Z00Z
    3600,             // 1 hour expiry
    Some("Order #12345".to_string()),
)?;

// Donation/tip (no fixed amount)
let donation_request = generate_payment_request(
    &receiver_keys,
    None,
    86400,  // 24 hours
    Some("Support our project".to_string()),
)?;
```

#### 3.3.2.2 Distribution

**Methods:**

1. **QR Code (recommended for in-person):**

```rust
pub fn to_qr_code(request: &PaymentRequest) -> Result<QrCode, Error> {
    let canonical = request.canonical_encoding();
    let encoded = base64::encode_config(&canonical, base64::URL_SAFE_NO_PAD);
    let uri = format!("z00z:request?data={}", encoded);
    
    QrCode::new(uri.as_bytes())
}
```

2. **URL Link (for web/messaging):**

```
z00z://request?data=<base64_canonical_encoding>
```

3. **NFC Transfer:**

```rust
pub fn to_nfc_ndef(request: &PaymentRequest) -> NdefRecord {
    let canonical = request.canonical_encoding();
    NdefRecord::new_mime("application/z00z-payment-request", &canonical)
}
```

4. **API Response (merchant server):**

```json
{
  "version": 1,
  "type": "z00z-payment-request",
  "request": "<base64_canonical_encoding>",
  "human_readable": {
    "amount": "1.000000 Z00Z",
    "memo": "Order #12345",
    "expires_at": "2026-01-21T15:30:00Z"
  }
}
```

#### 3.3.2.3 Validation by Sender

**MUST validate BEFORE creating output:**

```rust
pub fn validate_payment_request(
    request: &PaymentRequest,
    pins: &PinnedReceiverCards,
    current_chain_id: u32,
) -> Result<ValidationOutcome, Error> {
    // 1. Structure validation
    if request.version != 1 {
        return Err(Error::UnsupportedRequestVersion(request.version));
    }
    
    // 2. Chain ID check (prevent cross-chain)
    if request.chain_id != current_chain_id {
        return Err(Error::WrongChainId {
            expected: current_chain_id,
            got: request.chain_id,
        });
    }
    
    // 3. Expiry check
    if request.is_expired() {
        return Err(Error::RequestExpired {
            expiry: request.expiry,
            now: unix_timestamp(),
        });
    }
    
    // 4. ECC points validation
    let view_pk = decode_view_pk(&request.view_pk)?;
    if view_pk == RistrettoPoint::identity() {
        return Err(Error::IdentityPointRejected);
    }
    
    let identity_pk = decode_view_pk(&request.identity_pk)?;
    if identity_pk == RistrettoPoint::identity() {
        return Err(Error::IdentityPointRejected);
    }
    
    // 5. Signature verification
    request.verify()?;
    
    // 6. Identity pinning (TOFU) check
    let pin_result = pins.verify_request_identity(
        &request.owner_handle,
        &request.identity_pk,
    )?;
    
    match pin_result {
        PinCheckResult::Verified => Ok(ValidationOutcome::Approved),
        PinCheckResult::NewIdentity => Ok(ValidationOutcome::RequiresUserConfirmation),
        PinCheckResult::IdentityChanged => Ok(ValidationOutcome::IdentityMismatch),
    }
}

pub enum ValidationOutcome {
    Approved,                      // Safe to proceed
    RequiresUserConfirmation,      // First time, ask user
    IdentityMismatch,              // Different identity_pk, warn user
}
```

**Critical Validation Order:**

```yaml
ValidationSequence(MUST):
  1. version_check: Reject unknown versions immediately
  2. chain_id_check: Prevent accidental cross-chain payments
  3. expiry_check: Reject expired requests
  4. ecc_validation: Ensure points are valid (no identity)
  5. signature_check: Cryptographic authenticity
  6. identity_pinning: TOFU verification against pins
  
FailFast(MUST):
  - Any validation failure → MUST reject entire request
  - No partial acceptance
  - Log rejection reason for debugging
```

#### 3.3.2.4 Expiry Handling

**Time-Based Expiration:**

```rust
impl PaymentRequest {
    pub fn check_validity(&self) -> ValidityStatus {
        let now = unix_timestamp();
        let remaining = self.expiry as i64 - now as i64;
        
        if remaining <= 0 {
            ValidityStatus::Expired
        } else if remaining < 60 {
            ValidityStatus::ExpiringSoon(remaining as u64)
        } else {
            ValidityStatus::Valid(remaining as u64)
        }
    }
}

pub enum ValidityStatus {
    Valid(u64),          // Seconds remaining
    ExpiringSoon(u64),   // Less than 1 minute
    Expired,
}
```

**Wallet UX:**

```rust
pub async fn handle_payment_request_expiry(
    ui: &UserInterface,
    request: &PaymentRequest,
) -> Result<bool, Error> {
    match request.check_validity() {
        ValidityStatus::Expired => {
            ui.show_error("Payment request has expired. Please request a new invoice.").await?;
            Ok(false)
        }
        ValidityStatus::ExpiringSoon(secs) => {
            let proceed = ui.confirm(format!(
                "Payment request expires in {} seconds. Proceed quickly?",
                secs
            )).await?;
            Ok(proceed)
        }
        ValidityStatus::Valid(_) => Ok(true),
    }
}
```

### 3.3.3 req_id Usage

**Purpose:** Ephemeral one-time secret enabling anti-DoS and privacy features.

**Key Properties:**

- Unpredictable (cryptographically random)
- Never reused (new req_id per PaymentRequest)
- Binds output to specific invoice
- Prevents targeted tag spam

#### 3.3.3.1 Tag16 Derivation

**With req_id (recommended):**

```rust
/// tag16 depends on req_id → attacker cannot target without knowing active requests
pub fn compute_tag16_with_req(
    k_dh: &[u8; 32],
    req_id: &[u8; 32],
) -> u16 {
    let hash = poseidon2_hash(
        b"Z00Z/TAG16",
        &[k_dh, req_id]
    );
    
    u16::from_le_bytes([hash[0], hash[1]])
}
```

**Security Benefit:**

Attacker knows your `view_pk` (public) and can choose arbitrary `r` to compute `k_dh = r * view_pk`. BUT without your active `req_id` values, attacker cannot generate tag16 values that match your wallet's expected tags.

**Anti-DoS Flow:**

```yaml
AttackerAttempt:
  attacker_knows: [view_pk]
  attacker_chooses: [r_malicious]
  attacker_computes: k_dh_malicious = r_malicious * view_pk
  
  without_req_id_in_tag16:
    tag16 = Trunc16(H(k_dh_malicious))
    result: Can generate spam matching victim's tag space
  
  with_req_id_in_tag16:
    tag16 = Trunc16(H(k_dh_malicious || req_id))
    attacker_problem: Doesn't know victim's req_id
    result: Cannot generate targeted spam
```

#### 3.3.3.2 k_dh Derivation

**Include req_id in symmetric key derivation:**

```rust
/// k_dh with req_id binding (anti-DoS variant)
pub fn derive_k_dh_with_req(
    dh: &RistrettoPoint,
    req_id: &[u8; 32],
) -> [u8; 32] {
    let dh_bytes = dh.compress().to_bytes();
    poseidon2_hash(
        b"Z00Z/DH",
        &[&dh_bytes, req_id]
    )
}
```

**pack_key with req_id:**

```rust
pub fn derive_pack_key_with_req(
    k_dh: &[u8; 32],
    req_id: &[u8; 32],
    asset_id: &[u8; 32],
    serial_id: u32,
) -> [u8; 32] {
    let serial_bytes = serial_id.to_le_bytes();
    poseidon2_hash(
        b"Z00Z/PACKKEY",
        &[k_dh, req_id, asset_id, &serial_bytes]
    )
}
```

#### 3.3.3.3 Anti-DoS Properties

**Targeted Tag Flooding Prevention:**

```yaml
DoSScenario:
  attacker_goal: Force victim wallet to decrypt many false positives
  
  without_req_id:
    attacker_can: Generate arbitrary outputs with victim's tag16
    victim_impact: Must attempt decryption on all matches
    cost: High (CPU/battery drain)
  
  with_req_id:
    attacker_cannot: Generate tag16 matching victim's active requests
    victim_impact: Only decrypts legitimate payments
    cost: Minimal (normal operation)
```

**Additional Wallet Protections (SHOULD):**

```rust
pub struct ScanRateLimiter {
    max_candidates_per_checkpoint: usize,
    max_decrypt_attempts_per_second: usize,
    defer_threshold: usize,
}

impl ScanRateLimiter {
    pub fn check_scan_load(
        &self,
        candidate_count: usize,
    ) -> ScanDecision {
        if candidate_count > self.max_candidates_per_checkpoint {
            ScanDecision::Defer {
                reason: "Too many tag matches, possible DoS",
                retry_after: 60,  // seconds
            }
        } else {
            ScanDecision::Proceed
        }
    }
}
```

### 3.3.4 PaymentRequest API

**High-Level Traits:**

```rust
pub trait PaymentRequestOperations {
    fn generate(
        keys: &ReceiverKeys,
        params: RequestParams,
    ) -> Result<PaymentRequest, Error>;
    
    fn verify(&self) -> Result<(), Error>;
    fn is_expired(&self) -> bool;
    fn encode_qr(&self) -> Result<QrCode, Error>;
}

pub struct RequestParams {
    pub amount: Option<u64>,
    pub expiry_seconds: u64,
    pub memo: Option<String>,
    pub payment_id: Option<[u8; 16]>,
}

impl PaymentRequestOperations for PaymentRequest {
    fn generate(
        keys: &ReceiverKeys,
        params: RequestParams,
    ) -> Result<PaymentRequest, Error> {
        generate_payment_request(
            keys,
            params.amount,
            params.expiry_seconds,
            params.memo,
        )
    }
    
    fn verify(&self) -> Result<(), Error> {
        PaymentRequest::verify(self)
    }
    
    fn is_expired(&self) -> bool {
        PaymentRequest::is_expired(self)
    }
    
    fn encode_qr(&self) -> Result<QrCode, Error> {
        to_qr_code(self)
    }
}
```

#### 3.3.4.1 Request Generation

**Complete Example:**

```rust
pub fn create_invoice_for_merchant(
    keys: &ReceiverKeys,
    order_id: &str,
    amount_units: u64,
) -> Result<PaymentRequest, Error> {
    let payment_id = blake2b_16(order_id.as_bytes());
    
    let params = RequestParams {
        amount: Some(amount_units),
        expiry_seconds: 3600,  // 1 hour
        memo: Some(format!("Order: {}", order_id)),
        payment_id: Some(payment_id),
    };
    
    PaymentRequest::generate(keys, params)
}
```

#### 3.3.4.2 Request Validation

**Complete Validation Pipeline:**

```rust
pub fn validate_and_prepare_payment(
    request: &PaymentRequest,
    pins: &PinnedReceiverCards,
    amount_to_send: u64,
) -> Result<ValidatedRequest, Error> {
    // Validate structure and signatures
    let outcome = validate_payment_request(request, pins, MAINNET_CHAIN_ID)?;
    
    match outcome {
        ValidationOutcome::Approved => {},
        ValidationOutcome::RequiresUserConfirmation => {
            // Handle first-time identity (would need UI interaction)
            return Err(Error::RequiresUserConfirmation);
        }
        ValidationOutcome::IdentityMismatch => {
            return Err(Error::IdentityPinMismatch);
        }
    }
    
    // Validate amount
    if let Some(requested) = request.amount {
        if amount_to_send != requested {
            // Wallet may warn but allow (user discretion)
            log::warn!(
                "Sending {} but request asked for {}",
                amount_to_send,
                requested
            );
        }
    }
    
    Ok(ValidatedRequest {
        view_pk: decode_view_pk(&request.view_pk)?,
        owner_handle: request.owner_handle,
        req_id: request.req_id,
    })
}

pub struct ValidatedRequest {
    pub view_pk: RistrettoPoint,
    pub owner_handle: [u8; 32],
    pub req_id: [u8; 32],
}
```

**Testing:**

```rust
#[cfg(test)]
mod tests {
    use super::*;
    
    #[test]
    fn test_payment_request_roundtrip() {
        let keys = ReceiverKeys::from_receiver_secret(test_secret());
        let params = RequestParams {
            amount: Some(1_000_000),
            expiry_seconds: 3600,
            memo: Some("test".to_string()),
            payment_id: None,
        };
        
        let request = PaymentRequest::generate(&keys, params).unwrap();
        request.verify().unwrap();
        assert!(!request.is_expired());
    }
    
    #[test]
    fn test_request_expiry() {
        let mut request = create_test_request();
        request.expiry = unix_timestamp() - 1;  // Already expired
        
        assert!(request.is_expired());
    }
    
    #[test]
    fn test_tag16_uniqueness_with_req_id() {
        let k_dh = [0x42; 32];
        let req_id1 = [0x01; 32];
        let req_id2 = [0x02; 32];
        
        let tag1 = compute_tag16_with_req(&k_dh, &req_id1);
        let tag2 = compute_tag16_with_req(&k_dh, &req_id2);
        
        assert_ne!(tag1, tag2, "Different req_id should produce different tags");
    }
}

## 3.4 Ephemeral Sender Secret (r)

**Purpose:** One-time secret scalar for each output, enabling ECDH stealth address construction.

**Critical Security (H-3):** MUST use hedged generation to protect against RNG failures. This is NOT optional—RNG failures are real production issues (VM snapshots, mobile entropy bugs, container misconfigurations).

**Design:** Combine CSPRNG with deterministic backup to ensure uniqueness even if RNG fails.

### 3.4.1 Random Generation

**MUST NOT use naive random generation:**

```rust
// ❌ WRONG: Pure RNG (vulnerable to RNG failure)
pub fn generate_r_naive() -> Scalar {
    Scalar::random(&mut OsRng)  // DANGEROUS if RNG fails!
}
```

**Real-world RNG failure scenarios:**

```yaml
RNG_Failures(Production):
  vm_snapshot:
    problem: VM restored from snapshot → RNG state repeats
    impact: Same r used multiple times → linkability + k_dh reuse
  
  mobile_entropy:
    problem: Device low entropy at boot
    impact: Predictable r → output linkability
  
  container_rng:
    problem: Container shares RNG state with parent
    impact: r collision across instances
```

#### 3.4.1.1 Entropy Source

**CSPRNG Requirements:**

```rust
use rand_core::{CryptoRng, RngCore};

/// Obtain random bytes from OS CSPRNG
pub fn get_rng_bytes() -> [u8; 32] {
    let mut bytes = [0u8; 32];
    OsRng.fill_bytes(&mut bytes);
    bytes
}
```

**Platform-Specific:**

- Linux: `/dev/urandom` (ChaCha20-based since kernel 4.8)
- Windows: `BCryptGenRandom` (CNG)
- macOS/iOS: `SecRandomCopyBytes`
- WASM: `crypto.getRandomValues()` (browser)

#### 3.4.1.2 Non-Zero Check

**MUST reject zero scalar:**

```rust
pub fn validate_scalar(r: &Scalar) -> Result<(), Error> {
    if r == &Scalar::ZERO {
        return Err(Error::ZeroScalarRejected);
    }
    Ok(())
}
```

**Why:** `r = 0` → `R = 0*G = identity point` → invalid stealth address, breaks ECDH.

### 3.4.2 Hedged Generation (MUST)

**H-3 Requirement: Hedged randomness combining RNG + deterministic backup**

```rust
/// Hedged ephemeral scalar generation (MUST use this)
pub fn generate_r_hedged(
    sender_secret_salt: &[u8; 32],  // Wallet-specific secret
    tx_digest: &[u8; 32],           // Transaction binding
    out_index: u32,                 // Output index in tx
) -> Scalar {
    // Get RNG bytes
    let rng_bytes = get_rng_bytes();
    
    // Combine with deterministic context
    let index_bytes = out_index.to_le_bytes();
    let hash = poseidon2_hash(
        b"Z00Z/R",
        &[&rng_bytes, sender_secret_salt, tx_digest, &index_bytes]
    );
    
    // Convert to scalar (reduction modulo curve order)
    let r = bytes_to_scalar_reduce(&hash);
    
    // Verify non-zero (statistically impossible to be zero, but check anyway)
    debug_assert!(r != Scalar::ZERO, "Hedged r is zero (astronomically unlikely)");
    
    r
}
```

**Security Properties:**

```yaml
HedgedRandomness(H-3):
  if_rng_good:
    rng_bytes: unpredictable
    result: r is uniformly random (standard security)
  
  if_rng_weak:
    rng_bytes: predictable or repeated
    sender_secret_salt: unique per wallet → ensures uniqueness
    tx_digest: unique per transaction
    out_index: unique per output
    result: r still unique (prevents r reuse attack)
  
  if_sender_secret_salt_leaked:
    rng_bytes: still provides unpredictability
    result: r remains unpredictable (RNG saves us)
  
  critical_property:
    - Uniqueness guaranteed even if RNG completely fails
    - Unpredictability maintained even if deterministic inputs leak
```

**sender_secret_salt Generation:**

```rust
pub struct WalletSeeds {
    pub receiver_secret: ReceiverSecret,
    pub sender_secret_salt: [u8; 32],  // Derived or independent
}

impl WalletSeeds {
    /// Derive sender_secret_salt from receiver_secret (same seed recovery)
    pub fn derive_sender_salt(receiver_secret: &ReceiverSecret) -> [u8; 32] {
        poseidon2_hash(
            b"Z00Z/SENDER_SALT",
            &[&receiver_secret.0]
        )
    }
    
    /// Or generate independently (store separately)
    pub fn generate_independent_sender_salt() -> [u8; 32] {
        let mut salt = [0u8; 32];
        OsRng.fill_bytes(&mut salt);
        salt
    }
}
```

#### 3.4.2.1 Deterministic Backup

**Sender Recovery (if needed):**

If sender needs to prove they created specific output:

```rust
pub fn recover_r(
    sender_secret_salt: &[u8; 32],
    tx_digest: &[u8; 32],
    out_index: u32,
    original_rng_bytes: &[u8; 32],  // If saved
) -> Scalar {
    // Recompute r using original inputs
    let index_bytes = out_index.to_le_bytes();
    let hash = poseidon2_hash(
        b"Z00Z/R",
        &[original_rng_bytes, sender_secret_salt, tx_digest, &index_bytes]
    );
    
    bytes_to_scalar_reduce(&hash)
}
```

**Trade-offs:**

```yaml
SenderRecovery:
  if_store_rng_bytes:
    pros: Can recover exact r (proof of sending)
    cons: Increased storage, privacy leak if stolen
  
  if_not_store:
    pros: No extra storage, better privacy
    cons: Cannot prove sending later (acceptable for most use cases)
  
recommendation: Do NOT store rng_bytes unless legally required
```

### 3.4.3 Ephemeral Public Point (R_pub)

**Derivation:**

```rust
use curve25519_dalek::constants::RISTRETTO_BASEPOINT_TABLE;

/// R_pub = r * G
pub fn compute_r_pub(r: &Scalar) -> RistrettoPoint {
    &RISTRETTO_BASEPOINT_TABLE * r
}
```

**Complete Output Creation:**

```rust
pub fn create_stealth_output(
    sender_wallet: &WalletSeeds,
    receiver_card: &ReceiverCard,
    tx_digest: &[u8; 32],
    out_index: u32,
    amount: u64,
) -> Result<OutputLeaf, Error> {
    // Generate hedged r
    let r = generate_r_hedged(
        &sender_wallet.sender_secret_salt,
        tx_digest,
        out_index,
    );
    
    // Compute R_pub
    let r_pub = compute_r_pub(&r);
    
    // ECDH
    let view_pk = decode_view_pk(&receiver_card.view_pk)?;
    let dh = r * view_pk;  // Shared secret
    
    // Continue with k_dh derivation, encryption, etc.
    // ...
    
    Ok(OutputLeaf {
        r_pub: r_pub.compress().to_bytes(),
        // ... other fields
    })
}
```

#### 3.4.3.1 Encoding

**Canonical Compressed Ristretto:**

```rust
pub fn encode_r_pub(r_pub: &RistrettoPoint) -> [u8; 32] {
    r_pub.compress().to_bytes()
}

pub fn decode_r_pub(bytes: &[u8; 32]) -> Result<RistrettoPoint, Error> {
    let compressed = CompressedRistretto::from_slice(bytes);
    let point = compressed.decompress()
        .ok_or(Error::InvalidRistrettoPoint)?;
    
    // Reject identity (should never happen with proper r generation)
    if point == RistrettoPoint::identity() {
        return Err(Error::IdentityPointRejected);
    }
    
    Ok(point)
}
```

**Properties:**

- **Fixed size:** Always 32 bytes
- **Canonical:** Unique encoding per point
- **Decompression:** Fast, constant-time
- **Validation:** Automatic via Ristretto group check

#### 3.4.3.2 Storage in Leaf

**On-Chain Storage:**

```rust
pub struct AssetLeaf {
    pub asset_id: [u8; 32],
    pub serial_id: u32,
    pub c_amount: [u8; 32],      // Pedersen commitment
    pub r_pub: [u8; 32],         // ← Ephemeral public point (THIS FIELD)
    pub owner_tag: [u8; 32],
    pub enc_pack: Vec<u8>,
    // NOTE: In production, use z00z_crypto::Z00ZRangeProof type alias
    pub range_proof: Vec<u8>,
}
```

**R_pub Usage by Receiver:**

```rust
pub fn scan_output_for_ownership(
    receiver_keys: &ReceiverKeys,
    leaf: &AssetLeaf,
) -> Result<Option<CoinRecord>, Error> {
    // Decode R from leaf
    let r_pub = decode_r_pub(&leaf.r_pub)?;
    
    // Compute shared secret: dh = view_sk * R
    let dh = receiver_keys.view_sk * r_pub;
    
    // Derive k_dh and attempt decryption
    let k_dh = derive_k_dh(&dh, None);  // Or with req_id if using PaymentRequest
    
    // Try to decrypt enc_pack
    let coin_pack = decrypt_coin_pack(k_dh, leaf)?;
    
    // Verify ownership (M1 check)
    let owner_tag_expected = compute_owner_tag(
        &receiver_keys.owner_handle,
        &k_dh,
    );
    
    if owner_tag_expected != leaf.owner_tag {
        return Ok(None);  // Not ours (or decryptable-but-not-spendable)
    }
    
    Ok(Some(coin_pack))
}
```

**Testing:**

```rust
#[cfg(test)]
mod tests {
    use super::*;
    
    #[test]
    fn test_hedged_r_uniqueness() {
        let salt = [0x42; 32];
        let tx_digest = [0xAA; 32];
        
        let r1 = generate_r_hedged(&salt, &tx_digest, 0);
        let r2 = generate_r_hedged(&salt, &tx_digest, 1);
        let r3 = generate_r_hedged(&salt, &tx_digest, 0);  // Same inputs
        
        assert_ne!(r1, r2, "Different output index should give different r");
        assert_eq!(r1, r3, "Same inputs should give same r (deterministic)");
    }
    
    #[test]
    fn test_r_pub_encoding_roundtrip() {
        let r = Scalar::random(&mut OsRng);
        let r_pub = compute_r_pub(&r);
        
        let encoded = encode_r_pub(&r_pub);
        let decoded = decode_r_pub(&encoded).unwrap();
        
        assert_eq!(r_pub, decoded);
    }
    
    #[test]
    fn test_rng_failure_protection() {
        // Simulate complete RNG failure (all zeros)
        let bad_rng_bytes = [0u8; 32];
        let salt = [0x42; 32];
        let tx1 = [0xAA; 32];
        let tx2 = [0xBB; 32];
        
        // Even with bad RNG, different tx_digest → different r
        let r1 = {
            let hash = poseidon2_hash(
                b"Z00Z/R",
                &[&bad_rng_bytes, &salt, &tx1, &0u32.to_le_bytes()]
            );
            bytes_to_scalar_reduce(&hash)
        };
        
        let r2 = {
            let hash = poseidon2_hash(
                b"Z00Z/R",
                &[&bad_rng_bytes, &salt, &tx2, &0u32.to_le_bytes()]
            );
            bytes_to_scalar_reduce(&hash)
        };
        
        assert_ne!(r1, r2, "Hedged r protects against RNG failure");
    }
}

## 3.5 Shared Secret & Key Derivation

**Purpose:** ECDH shared secret enables sender and receiver to derive same symmetric key `k_dh` without communication.

**Foundation:** Classic Diffie-Hellman on Ristretto255 curve. Both parties compute same point, prove equality in OWF.

### 3.5.1 ECDH Shared Secret (dh)

**Sender Computation:**

```rust
/// dh = r * view_pk (sender side)
pub fn compute_dh_sender(
    r: &Scalar,
    view_pk: &RistrettoPoint,
) -> RistrettoPoint {
    r * view_pk
}
```

**Example:**

```rust
// Sender has: r (ephemeral secret), view_pk (from ReceiverCard)
let r = generate_r_hedged(&sender_salt, &tx_digest, out_index);
let view_pk = decode_view_pk(&receiver_card.view_pk)?;
let dh = compute_dh_sender(&r, &view_pk);
```

#### 3.5.1.1 Receiver Computation

**Receiver Computation:**

```rust
/// dh' = view_sk * R_pub (receiver side)
pub fn compute_dh_receiver(
    view_sk: &Scalar,
    r_pub: &RistrettoPoint,
) -> RistrettoPoint {
    view_sk * r_pub
}
```

**Example:**

```rust
// Receiver has: view_sk (derived from receiver_secret), R_pub (from leaf)
let view_sk = derive_view_secret_key(&receiver_secret);
let r_pub = decode_r_pub(&leaf.r_pub)?;
let dh = compute_dh_receiver(&view_sk, &r_pub);
```

**Algebraic Equality:**

```
Sender:   dh = r * view_pk = r * (view_sk * G)
Receiver: dh' = view_sk * R_pub = view_sk * (r * G)

By associativity: r * (view_sk * G) = view_sk * (r * G)
Therefore: dh == dh'
```

#### 3.5.1.2 Equality Proof

**OWF Constraint (in Zero-Knowledge Proof):**

The OWF MUST prove that sender computed `dh` correctly from `r` and `view_pk`:

```rust
// Pseudocode for OWF constraints
pub fn owf_constraints_ecdh(
    witness: &OWFWitness,
    public: &OWFPublic,
) {
    // Public inputs: R_pub, view_pk (from ReceiverCard)
    // Witness: r, dh
    
    // Constraint 1: R_pub == r * G
    constraint_eq(
        public.r_pub,
        scalar_mul(GENERATOR, witness.r)
    );
    
    // Constraint 2: dh == r * view_pk
    constraint_eq(
        witness.dh,
        scalar_mul(public.view_pk, witness.r)
    );
    
    // These constraints prove receiver will compute same dh
    // because: dh' = view_sk * R_pub = view_sk * (r * G) = r * (view_sk * G) = r * view_pk = dh
}
```

**Why This Prevents Burn:**

If sender provides wrong `dh` (not matching `r` and `view_pk`), OWF constraint fails. Network rejects output. Therefore, if output is accepted, receiver WILL compute same `dh` and successfully decrypt.

### 3.5.2 Symmetric Key (k_dh)

**Derivation from ECDH Point:**

```rust
/// k_dh = KDF("Z00Z/DH" || dh_bytes)
pub fn derive_k_dh(dh: &RistrettoPoint) -> [u8; 32] {
    let dh_bytes = dh.compress().to_bytes();
    poseidon2_hash(b"Z00Z/DH", &[&dh_bytes])
}
```

**With req_id (recommended for PaymentRequest):**

```rust
/// k_dh = KDF("Z00Z/DH" || dh_bytes || req_id)
pub fn derive_k_dh_with_req(
    dh: &RistrettoPoint,
    req_id: &[u8; 32],
) -> [u8; 32] {
    let dh_bytes = dh.compress().to_bytes();
    poseidon2_hash(
        b"Z00Z/DH",
        &[&dh_bytes, req_id]
    )
}
```

**Usage in Sender:**

```rust
pub fn sender_derive_keys(
    r: &Scalar,
    view_pk: &RistrettoPoint,
    req_id: Option<&[u8; 32]>,
) -> [u8; 32] {
    let dh = compute_dh_sender(r, view_pk);
    
    match req_id {
        Some(id) => derive_k_dh_with_req(&dh, id),
        None => derive_k_dh(&dh),
    }
}
```

**Usage in Receiver:**

```rust
pub fn receiver_derive_keys(
    view_sk: &Scalar,
    r_pub: &RistrettoPoint,
    req_id: Option<&[u8; 32]>,
) -> [u8; 32] {
    let dh = compute_dh_receiver(view_sk, r_pub);
    
    match req_id {
        Some(id) => derive_k_dh_with_req(&dh, id),
        None => derive_k_dh(&dh),
    }
}
```

#### 3.5.2.1 req_id Binding

**Anti-DoS Protection (see §3.3.3.3):**

Including `req_id` in `k_dh` derivation ensures:

1. **Different k_dh per request:** Same receiver, different invoices → different keys
2. **Tag16 uniqueness:** tag16 depends on k_dh, so attacker cannot target without knowing req_id
3. **Output isolation:** Cannot link outputs from different PaymentRequests

**Trade-offs:**

```yaml
ReqIdBinding:
  with_req_id:
    pros:
      - Anti-DoS via tag16
      - Per-invoice key isolation
      - Better forward secrecy
    cons:
      - Receiver must try all active req_ids when scanning (if not using inbox hints)
      - Slightly more complex
  
  without_req_id:
    pros:
      - Simpler scanning (one k_dh per R_pub)
      - Works without PaymentRequest flow
    cons:
      - Vulnerable to targeted tag spam
      - All outputs to same receiver linkable via tag16
  
recommendation: Use req_id for high-value/merchant flows, optional for peer-to-peer
```

**Hybrid Approach:**

```rust
pub enum KeyDerivationMode {
    WithRequest { req_id: [u8; 32] },  // PaymentRequest flow
    Direct,                             // Direct ReceiverCard payment
}

pub fn derive_k_dh_flexible(
    dh: &RistrettoPoint,
    mode: KeyDerivationMode,
) -> [u8; 32] {
    match mode {
        KeyDerivationMode::WithRequest { req_id } => {
            derive_k_dh_with_req(dh, &req_id)
        }
        KeyDerivationMode::Direct => {
            derive_k_dh(dh)
        }
    }
}
```

#### 3.5.2.2 Additional Context (Optional)

**Extended Key Derivation:**

For future extensions, k_dh can include additional context:

```rust
/// k_dh with extended context
pub fn derive_k_dh_extended(
    dh: &RistrettoPoint,
    context: &KeyDerivationContext,
) -> [u8; 32] {
    let dh_bytes = dh.compress().to_bytes();
    let mut inputs = vec![dh_bytes.as_slice()];
    
    if let Some(req_id) = context.req_id {
        inputs.push(&req_id);
    }
    
    if let Some(owner_handle) = context.owner_handle {
        inputs.push(&owner_handle);
    }
    
    if let Some(nonce) = context.nonce {
        inputs.push(&nonce);
    }
    
    poseidon2_hash(b"Z00Z/DH_EXT", &inputs)
}

pub struct KeyDerivationContext {
    pub req_id: Option<[u8; 32]>,
    pub owner_handle: Option<[u8; 32]>,
    pub nonce: Option<[u8; 32]>,
}
```

**Use Cases:**

- `owner_handle` binding: Strengthen ownership coupling (already done via owner_tag)
- `nonce`: Multi-recipient outputs (advanced)
- Custom application contexts

### 3.5.3 Key Derivation API

**Complete API:**

```rust
pub trait SharedSecretOperations {
    fn compute_sender(
        r: &Scalar,
        view_pk: &RistrettoPoint,
    ) -> RistrettoPoint;
    
    fn compute_receiver(
        view_sk: &Scalar,
        r_pub: &RistrettoPoint,
    ) -> RistrettoPoint;
}

pub trait SymmetricKeyDerivation {
    fn derive_k_dh(dh: &RistrettoPoint) -> [u8; 32];
    fn derive_k_dh_with_req(dh: &RistrettoPoint, req_id: &[u8; 32]) -> [u8; 32];
}

impl SharedSecretOperations for RistrettoPoint {
    fn compute_sender(r: &Scalar, view_pk: &RistrettoPoint) -> RistrettoPoint {
        compute_dh_sender(r, view_pk)
    }
    
    fn compute_receiver(view_sk: &Scalar, r_pub: &RistrettoPoint) -> RistrettoPoint {
        compute_dh_receiver(view_sk, r_pub)
    }
}

impl SymmetricKeyDerivation for RistrettoPoint {
    fn derive_k_dh(dh: &RistrettoPoint) -> [u8; 32] {
        derive_k_dh(dh)
    }
    
    fn derive_k_dh_with_req(dh: &RistrettoPoint, req_id: &[u8; 32]) -> [u8; 32] {
        derive_k_dh_with_req(dh, req_id)
    }
}
```

**End-to-End Example:**

```rust
pub fn create_and_scan_output_example() -> Result<(), Error> {
    // === SENDER SIDE ===
    let sender_salt = [0x42; 32];
    let tx_digest = [0xAA; 32];
    let receiver_card = load_receiver_card()?;
    let req_id = [0x11; 32];  // From PaymentRequest
    
    // Generate ephemeral secret
    let r = generate_r_hedged(&sender_salt, &tx_digest, 0);
    let r_pub = compute_r_pub(&r);
    
    // ECDH
    let view_pk = decode_view_pk(&receiver_card.view_pk)?;
    let dh_sender = RistrettoPoint::compute_sender(&r, &view_pk);
    let k_dh_sender = RistrettoPoint::derive_k_dh_with_req(&dh_sender, &req_id);
    
    // Create output leaf with r_pub, enc_pack, etc.
    // ...
    
    // === RECEIVER SIDE ===
    let receiver_secret = load_receiver_secret()?;
    let view_sk = derive_view_secret_key(&receiver_secret);
    
    // Scan leaf
    let r_pub_from_leaf = decode_r_pub(&leaf.r_pub)?;
    let dh_receiver = RistrettoPoint::compute_receiver(&view_sk, &r_pub_from_leaf);
    let k_dh_receiver = RistrettoPoint::derive_k_dh_with_req(&dh_receiver, &req_id);
    
    // Verify equality
    assert_eq!(k_dh_sender, k_dh_receiver, "Shared keys must match");
    
    Ok(())
}
```

**Testing:**

```rust
#[cfg(test)]
mod tests {
    use super::*;
    
    #[test]
    fn test_ecdh_equality() {
        // Setup
        let receiver_secret = ReceiverSecret([0x42; 32]);
        let view_sk = derive_view_secret_key(&receiver_secret);
        let view_pk = derive_view_public_key(&view_sk);
        
        let r = Scalar::random(&mut OsRng);
        let r_pub = compute_r_pub(&r);
        
        // Sender computes dh
        let dh_sender = compute_dh_sender(&r, &view_pk);
        
        // Receiver computes dh
        let dh_receiver = compute_dh_receiver(&view_sk, &r_pub);
        
        // Must be equal
        assert_eq!(dh_sender, dh_receiver);
    }
    
    #[test]
    fn test_k_dh_derivation() {
        let dh = RistrettoPoint::random(&mut OsRng);
        let req_id = [0x11; 32];
        
        let k1 = derive_k_dh(&dh);
        let k2 = derive_k_dh_with_req(&dh, &req_id);
        
        // Different derivation modes → different keys
        assert_ne!(k1, k2);
    }
    
    #[test]
    fn test_req_id_binding() {
        let dh = RistrettoPoint::random(&mut OsRng);
        let req_id1 = [0x11; 32];
        let req_id2 = [0x22; 32];
        
        let k1 = derive_k_dh_with_req(&dh, &req_id1);
        let k2 = derive_k_dh_with_req(&dh, &req_id2);
        
        // Different req_id → different k_dh
        assert_ne!(k1, k2);
    }
}
```

## 3.6 Owner Tag

**Purpose:** Cryptographic ownership anchor that proves receiver can spend UTXO without revealing receiver identity on-chain. Provides unlinkability on state while enabling efficient ownership verification.

**Critical Security Property (M1):** Owner tag check prevents "decryptable-but-not-spendable" attack where sender uses correct `view_pk` for ECDH but wrong `owner_handle`, causing receiver to decrypt funds they cannot spend.

**Implementation Phase:** Phase 3 (Privacy & Anti-Attack)  
**Dependencies:** §3.1 (Receiver Key Material), §3.5 (Shared Secret), §2.2 (Hash Domains)  
**Base Document Reference:** Z00Z-ECC-StealthAddress-5.md § "Привязка ownership"

---

### 3.6.1 Owner Tag Derivation

**Definition:** Owner tag is a collision-resistant hash binding receiver identity (`owner_handle`) to per-output shared secret (`k_dh`), stored publicly in UTXO leaf but appearing random to observers without knowledge of `k_dh`.

**Canonical Formula:**

```
owner_tag = H_zk("Z00Z/TAG" || owner_handle || k_dh)
```

Where:

- `H_zk` = Poseidon2 hash (consensus-critical, ZK-friendly)
- `"Z00Z/TAG"` = Domain separation prefix (MUST use exact string)
- `owner_handle` = 32 bytes, derived as `H_zk("Z00Z/RID" || receiver_secret)`
- `k_dh` = 32 bytes, symmetric key from ECDH: `KDF("Z00Z/DH" || Encode(dh))`

**Encoding Rules:**

```yaml
OwnerTagEncoding(MUST):
  input_format: "domain || owner_handle || k_dh"
  domain: UTF-8 bytes of "Z00Z/TAG" (8 bytes)
  separator: implicit concatenation (no delimiter bytes)
  owner_handle: 32 bytes raw (no length prefix)
  k_dh: 32 bytes raw (no length prefix)
  output: 32 bytes (Poseidon2 digest)
  
  canonical_serialization:
    - field_order: [domain, owner_handle, k_dh]
    - no_padding: true
    - no_alignment: true
    - deterministic: true
```

**Rust Implementation:**

```rust
use z00z_crypto::hash::{hash_domain, Poseidon2Hash};

pub fn compute_owner_tag(
    owner_handle: &[u8; 32],
    k_dh: &[u8; 32],
) -> [u8; 32] {
    // MUST use H_zk (Poseidon2) for consensus compatibility
    hash_domain!(
        OWNER_TAG,
        owner_handle,
        k_dh
    )
}

// Alternative explicit implementation
pub fn compute_owner_tag_explicit(
    owner_handle: &[u8; 32],
    k_dh: &[u8; 32],
) -> [u8; 32] {
    let mut hasher = Poseidon2Hash::new();
    hasher.update(b"Z00Z/TAG");
    hasher.update(owner_handle);
    hasher.update(k_dh);
    hasher.finalize()
}
```

#### 3.6.1.1 Unlinkability Properties

**Mathematical Guarantee:**

Given two UTXO leaves `L1`, `L2` with owner tags `T1`, `T2`:

```
Observer without k_dh cannot determine if:
  T1 = H("Z00Z/TAG" || owner_handle_A || k_dh_1)
  T2 = H("Z00Z/TAG" || owner_handle_A || k_dh_2)  [same owner]
  
  vs
  
  T1 = H("Z00Z/TAG" || owner_handle_A || k_dh_1)
  T2 = H("Z00Z/TAG" || owner_handle_B || k_dh_3)  [different owners]
```

**Why Unlinkability Holds:**

1. **k_dh is per-output secret:**
   - Sender: `k_dh_i = KDF("Z00Z/DH" || (r_i * view_pk))`
   - Each output uses fresh ephemeral `r_i` → different `dh_i` → different `k_dh_i`
   - Observer sees only `R_i = r_i * G` (cannot compute `r_i` from `R_i`)

2. **owner_handle is hidden:**
   - `owner_handle` never appears in leaf
   - Only way to compute `owner_tag` is knowing both `owner_handle` AND `k_dh`

3. **Collision resistance:**
   - Poseidon2 with 252-bit security
   - Finding `owner_tag` collision computationally infeasible

**Attack Model:**

```yaml
Attacker_Capabilities:
  can_see: [JMT state, all UTXOs, R_pub values, owner_tag values]
  cannot_see: [receiver_secret, view_sk, r (ephemeral), dh, k_dh]
  
  attack_attempts:
    - link_outputs_by_owner_tag: FAIL (each k_dh unique)
    - recover_owner_handle_from_tag: FAIL (preimage resistance)
    - link_to_receiver_card_view_pk: FAIL (no view_pk in leaf)
```

#### 3.6.1.2 Ownership Proof

**Receiver-Side Verification:**

Receiver proves ownership by recomputing expected tag:

```rust
pub fn verify_ownership(
    &self,
    wallet: &Wallet,
    leaf: &AssetLeaf,
) -> Result<bool, Error> {
    // Step 1: Compute dh from leaf's R_pub
    let r_pub = decode_r_pub(&leaf.r_pub)?;
    let dh = self.compute_dh_receiver(&wallet.view_sk, &r_pub)?;
    
    // Step 2: Derive k_dh
    let k_dh = derive_k_dh(&dh);
    
    // Step 3: Compute expected owner_tag
    let owner_tag_expected = compute_owner_tag(
        &wallet.owner_handle,
        &k_dh,
    );
    
    // Step 4: Constant-time comparison (MUST)
    Ok(constant_time_eq(&owner_tag_expected, &leaf.owner_tag))
}
```

**Security Properties:**

1. **Completeness:** Legitimate receiver can always recompute matching tag
2. **Soundness:** Attacker without `receiver_secret` cannot forge valid tag
3. **Privacy:** Verification happens off-chain in wallet

**Sender-Side Construction:**

```rust
pub fn create_owner_tag_sender(
    receiver_card: &ReceiverCard,
    dh: &RistrettoPoint,
) -> [u8; 32] {
    let k_dh = derive_k_dh(dh);
    compute_owner_tag(&receiver_card.owner_handle, &k_dh)
}
```

---

### 3.6.2 Owner Tag Usage

**Lifecycle:** Owner tag appears in three contexts:

1. **Sender construction** - Computed during output creation
2. **On-chain storage** - Included in UTXO leaf (public but unlinkable)
3. **Receiver validation** - M1 check during coin scanning (CRITICAL)

**Storage Location:**

```rust
pub struct AssetLeaf {
    pub asset_id: [u8; 32],
    pub serial_id: u32,
    pub r_pub: [u8; 32],           // Ephemeral public point R
    pub owner_tag: [u8; 32],       // ← OWNER TAG HERE
    pub c_amount: [u8; 32],        // Pedersen commitment
    pub enc_pack: Vec<u8>,         // Encrypted coin data
    pub tag16: Option<u16>,        // Scan accelerator
}
```

#### 3.6.2.1 Expected Tag Computation (M1 Check)

**Critical Requirement (M1):** Receiver MUST validate `owner_tag` matches expected value to prevent decryptable-but-not-spendable attack.

**Attack Scenario Without M1:**

```
1. Sender obtains Alice's view_pk from ReceiverCard
2. Sender computes dh = r * view_pk (correct ECDH)
3. Sender derives k_dh from dh (Alice can decrypt)
4. BUT: Sender embeds Bob's owner_handle in owner_tag
5. Result: Alice decrypts output but CANNOT SPEND (wrong owner_handle)
```

**M1 Check Implementation:**

```rust
pub fn m1_owner_tag_check(
    receiver_keys: &ReceiverKeys,
    leaf: &AssetLeaf,
) -> Result<(), Error> {
    // Step 1: Decode R_pub from leaf (untrusted input)
    let r_pub = RistrettoPoint::from_compressed(&leaf.r_pub)
        .ok_or(Error::InvalidRpub)?;
    
    // Step 2: Validate R_pub is not identity
    if r_pub.is_identity() {
        return Err(Error::EcdhIdentityPoint);
    }
    
    // Step 3: Compute dh = view_sk * R_pub
    let dh = receiver_keys.view_sk * r_pub;
    
    // Step 4: Validate dh is not identity
    if dh.is_identity() {
        return Err(Error::EcdhIdentityResult);
    }
    
    // Step 5: Derive k_dh
    let k_dh = derive_k_dh(&dh);
    
    // Step 6: Compute expected owner_tag
    let owner_tag_expected = compute_owner_tag(
        &receiver_keys.owner_handle,
        &k_dh,
    );
    
    // Step 7: Constant-time comparison (CRITICAL)
    if !constant_time_eq(&owner_tag_expected, &leaf.owner_tag) {
        return Err(Error::OwnerTagMismatch);
    }
    
    Ok(())
}
```

**When To Apply M1 Check:**

```yaml
M1_Application_Points:
  critical(MUST):
    - coin_scanning: before marking output as "mine"
    - coin_reception: before adding to wallet balance
    - coin_validation: before storing coin record
  
  not_required:
    - state_validation: aggregator doesn't know owner_handle
    - proof_verification: OWF checks enc_pack correctness, not ownership
    - tx_broadcasting: sender doesn't have receiver_secret
```

**Flow Diagram:**

```mermaid
sequenceDiagram
    participant S as Sender
    participant L as UTXO Leaf
    participant R as Receiver Wallet
    
    Note over S: Has ReceiverCard:<br/>owner_handle, view_pk
    
    S->>S: r ← hedged_random()
    S->>S: R = r * G
    S->>S: dh = r * view_pk
    S->>S: k_dh = KDF(dh)
    S->>S: owner_tag = H(owner_handle || k_dh)
    
    S->>L: Publish leaf with R, owner_tag
    
    Note over L: On-chain storage<br/>(public but unlinkable)
    
    R->>L: Scan new leaf
    R->>R: dh = view_sk * R
    R->>R: k_dh = KDF(dh)
    R->>R: owner_tag_expected = H(owner_handle || k_dh)
    
    alt owner_tag_expected == leaf.owner_tag
        R->>R: ✅ M1 CHECK PASS<br/>Mark as spendable
    else mismatch
        R->>R: ❌ M1 CHECK FAIL<br/>Reject (not mine / attack)
    end
```

#### 3.6.2.2 Tag Mismatch Handling

**Rejection Policy:**

```rust
#[derive(Debug, Error)]
pub enum OwnerTagError {
    #[error("Owner tag mismatch: expected {expected:?}, got {actual:?}")]
    Mismatch {
        expected: [u8; 32],
        actual: [u8; 32],
        asset_id: [u8; 32],
    },
    
    #[error("Cannot compute owner tag: ECDH failed")]
    EcdhFailure(#[from] EcdhError),
    
    #[error("Invalid R_pub in leaf")]
    InvalidRpub,
}

pub fn handle_tag_mismatch(
    leaf: &AssetLeaf,
    expected: [u8; 32],
) -> ScanResult {
    // DO NOT add to wallet
    // DO NOT show in balance
    // DO log for security monitoring
    
    log::warn!(
        "Owner tag mismatch detected: asset_id={}, expected={}, actual={}",
        hex::encode(&leaf.asset_id),
        hex::encode(&expected),
        hex::encode(&leaf.owner_tag),
    );
    
    // Emit metric for potential attack monitoring
    metrics::increment_counter("wallet.owner_tag_mismatch");
    
    ScanResult::NotMine {
        reason: NotMineReason::OwnerTagMismatch,
        asset_id: leaf.asset_id,
    }
}
```

**UX Implications:**

```yaml
UserExperience:
  on_mismatch:
    - do_not_show_in_incoming_list: true
    - do_not_add_to_balance: true
    - do_not_generate_notification: true
    - log_for_developer_debugging: true
  
  attack_detection:
    - if many_mismatches_for_same_view_pk:
        action: alert_user
        message: "Possible directory attack or card compromise"
    - if sporadic_mismatches:
        action: silent_log
        reason: "Could be scan collision or test transaction"
```

**False Positive Analysis:**

```yaml
MismatchCauses:
  legitimate:
    - wrong_wallet_scanning: user scans with different receiver_secret
    - test_transactions: developer sent to wrong handle
    - wallet_recovery: incomplete key material
  
  attack:
    - directory_substitution(H-1): malicious directory swapped owner_handle
    - phishing(M1): attacker crafted output with wrong ownership
    - confused_deputy: sender used wrong ReceiverCard
  
  system_error:
    - hash_implementation_drift: wallet vs proof hash mismatch (CRITICAL BUG)
    - bit_flip_in_storage: data corruption
```

---

### 3.6.3 Owner Tag API

**High-Level Trait:**

```rust
pub trait OwnerTagOperations {
    /// Compute owner tag from owner_handle and k_dh
    fn compute_tag(owner_handle: &[u8; 32], k_dh: &[u8; 32]) -> [u8; 32];
    
    /// Verify owner tag matches expected (M1 check)
    fn verify_tag(
        receiver_keys: &ReceiverKeys,
        leaf: &AssetLeaf,
    ) -> Result<(), OwnerTagError>;
    
    /// Extract k_dh from leaf using receiver keys
    fn extract_k_dh(
        view_sk: &Scalar,
        r_pub: &RistrettoPoint,
    ) -> Result<[u8; 32], Error>;
}

impl OwnerTagOperations for OwnerTag {
    fn compute_tag(owner_handle: &[u8; 32], k_dh: &[u8; 32]) -> [u8; 32] {
        compute_owner_tag(owner_handle, k_dh)
    }
    
    fn verify_tag(
        receiver_keys: &ReceiverKeys,
        leaf: &AssetLeaf,
    ) -> Result<(), OwnerTagError> {
        m1_owner_tag_check(receiver_keys, leaf)
    }
    
    fn extract_k_dh(
        view_sk: &Scalar,
        r_pub: &RistrettoPoint,
    ) -> Result<[u8; 32], Error> {
        let dh = compute_dh_receiver(view_sk, r_pub)?;
        Ok(derive_k_dh(&dh))
    }
}
```

**Complete Implementation Module:**

```rust
// z00z_crypto/src/owner_tag.rs (NEW)

use curve25519_dalek::ristretto::RistrettoPoint;
use curve25519_dalek::scalar::Scalar;
use subtle::ConstantTimeEq;
use z00z_crypto::hash::hash_domain;
use z00z_crypto::kdf::derive_k_dh;
use z00z_crypto::ecdh::{compute_dh_receiver, validate_ecdh_point};

pub struct OwnerTag;

impl OwnerTag {
    /// Compute owner tag with explicit domain separation
    pub fn compute(owner_handle: &[u8; 32], k_dh: &[u8; 32]) -> [u8; 32] {
        hash_domain!(OWNER_TAG, owner_handle, k_dh)
    }
    
    /// Verify owner tag matches expected value (M1 check)
    pub fn verify(
        owner_handle: &[u8; 32],
        view_sk: &Scalar,
        leaf: &AssetLeaf,
    ) -> Result<bool, Error> {
        // Decode and validate R_pub
        let r_pub = RistrettoPoint::from_compressed(&leaf.r_pub)
            .ok_or(Error::InvalidRpub)?;
        validate_ecdh_point(&r_pub)?;
        
        // Compute dh and k_dh
        let dh = compute_dh_receiver(view_sk, &r_pub)?;
        let k_dh = derive_k_dh(&dh);
        
        // Compute expected tag
        let expected = Self::compute(owner_handle, &k_dh);
        
        // Constant-time comparison
        Ok(expected.ct_eq(&leaf.owner_tag).into())
    }
    
    /// Extract k_dh without verification (for decryption)
    pub fn extract_k_dh(
        view_sk: &Scalar,
        r_pub: &RistrettoPoint,
    ) -> Result<[u8; 32], Error> {
        validate_ecdh_point(r_pub)?;
        let dh = compute_dh_receiver(view_sk, r_pub)?;
        Ok(derive_k_dh(&dh))
    }
}

/// Constant-time equality check (MUST use for owner_tag comparison)
pub fn constant_time_eq(a: &[u8; 32], b: &[u8; 32]) -> bool {
    a.ct_eq(b).into()
}
```

**Integration with Wallet Scanner:**

```rust
// z00z_wallets/src/scanner.rs

pub struct CoinScanner {
    receiver_keys: ReceiverKeys,
}

impl CoinScanner {
    pub fn scan_leaf(&self, leaf: &AssetLeaf) -> ScanResult {
        // Step 1: Try to decrypt enc_pack
        let coin_data = match self.try_decrypt(leaf) {
            Ok(data) => data,
            Err(_) => return ScanResult::NotMine {
                reason: NotMineReason::DecryptFailed,
            },
        };
        
        // Step 2: CRITICAL - M1 owner tag check
        if let Err(e) = OwnerTag::verify(
            &self.receiver_keys.owner_handle,
            &self.receiver_keys.view_sk,
            leaf,
        ) {
            log::warn!("M1 check failed: {:?}", e);
            return ScanResult::NotMine {
                reason: NotMineReason::OwnerTagMismatch,
            };
        }
        
        // Step 3: Validate commitment opens
        self.validate_commitment(&coin_data, leaf)?;
        
        // Step 4: Store coin record
        ScanResult::Mine(coin_data)
    }
}
```

**Testing:**

```rust
#[cfg(test)]
mod tests {
    use super::*;
    use rand_core::OsRng;
    
    #[test]
    fn test_owner_tag_computation() {
        let owner_handle = [0x42; 32];
        let k_dh = [0xAA; 32];
        
        let tag = OwnerTag::compute(&owner_handle, &k_dh);
        
        // Tag should be deterministic
        let tag2 = OwnerTag::compute(&owner_handle, &k_dh);
        assert_eq!(tag, tag2);
        
        // Different k_dh → different tag
        let k_dh2 = [0xBB; 32];
        let tag3 = OwnerTag::compute(&owner_handle, &k_dh2);
        assert_ne!(tag, tag3);
    }
    
    #[test]
    fn test_owner_tag_verification_success() {
        // Setup receiver
        let receiver_secret = ReceiverSecret([0x42; 32]);
        let keys = ReceiverKeys::from_receiver_secret(receiver_secret);
        
        // Sender creates output
        let r = Scalar::random(&mut OsRng);
        let r_pub = &r * &RISTRETTO_BASEPOINT_TABLE;
        let dh = r * keys.view_pk;
        let k_dh = derive_k_dh(&dh);
        let owner_tag = OwnerTag::compute(&keys.owner_handle, &k_dh);
        
        // Create leaf
        let leaf = AssetLeaf {
            r_pub: r_pub.compress().to_bytes(),
            owner_tag,
            ..Default::default()
        };
        
        // Receiver verifies (M1 check)
        assert!(OwnerTag::verify(&keys.owner_handle, &keys.view_sk, &leaf).unwrap());
    }
    
    #[test]
    fn test_owner_tag_verification_failure_wrong_handle() {
        // Setup receiver
        let receiver_secret = ReceiverSecret([0x42; 32]);
        let keys = ReceiverKeys::from_receiver_secret(receiver_secret);
        
        // Attacker uses wrong owner_handle
        let attacker_handle = [0xFF; 32];
        
        // Sender creates output
        let r = Scalar::random(&mut OsRng);
        let r_pub = &r * &RISTRETTO_BASEPOINT_TABLE;
        let dh = r * keys.view_pk;
        let k_dh = derive_k_dh(&dh);
        let owner_tag = OwnerTag::compute(&attacker_handle, &k_dh);  // Wrong!
        
        let leaf = AssetLeaf {
            r_pub: r_pub.compress().to_bytes(),
            owner_tag,
            ..Default::default()
        };
        
        // Receiver verification MUST fail
        assert!(!OwnerTag::verify(&keys.owner_handle, &keys.view_sk, &leaf).unwrap());
    }
    
    #[test]
    fn test_constant_time_comparison() {
        let a = [0x42; 32];
        let b = [0x42; 32];
        let c = [0x43; 32];
        
        assert!(constant_time_eq(&a, &b));
        assert!(!constant_time_eq(&a, &c));
        
        // Should not short-circuit on first byte difference
        let mut d = [0x42; 32];
        d[31] = 0x43;
        assert!(!constant_time_eq(&a, &d));
    }
    
    #[test]
    fn test_invalid_rpub_handling() {
        let receiver_secret = ReceiverSecret([0x42; 32]);
        let keys = ReceiverKeys::from_receiver_secret(receiver_secret);
        
        // Invalid compressed point
        let invalid_leaf = AssetLeaf {
            r_pub: [0xFF; 32],
            owner_tag: [0; 32],
            ..Default::default()
        };
        
        // MUST NOT panic, MUST return error
        let result = OwnerTag::verify(
            &keys.owner_handle,
            &keys.view_sk,
            &invalid_leaf,
        );
        assert!(result.is_err());
    }
    
    #[test]
    fn test_identity_point_rejection() {
        let receiver_secret = ReceiverSecret([0x42; 32]);
        let keys = ReceiverKeys::from_receiver_secret(receiver_secret);
        
        // Identity point (all zeros except last byte)
        let identity_bytes = RistrettoPoint::identity().compress().to_bytes();
        
        let leaf = AssetLeaf {
            r_pub: identity_bytes,
            owner_tag: [0; 32],
            ..Default::default()
        };
        
        // MUST reject identity point
        assert!(OwnerTag::verify(&keys.owner_handle, &keys.view_sk, &leaf).is_err());
    }
}
```

**Golden Test Vectors:**

```rust
#[cfg(test)]
mod golden_tests {
    use super::*;
    
    #[test]
    fn golden_vector_owner_tag_1() {
        // Fixed inputs (hex)
        let owner_handle = hex::decode(
            "1111111111111111111111111111111111111111111111111111111111111111"
        ).unwrap();
        let k_dh = hex::decode(
            "2222222222222222222222222222222222222222222222222222222222222222"
        ).unwrap();
        
        let tag = OwnerTag::compute(
            owner_handle.as_slice().try_into().unwrap(),
            k_dh.as_slice().try_into().unwrap(),
        );
        
        // Expected output (MUST match proof circuit)
        let expected = hex::decode(
            "AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA"
        ).unwrap();
        
        assert_eq!(tag.as_slice(), expected.as_slice(),
            "Owner tag golden vector mismatch - check H_zk implementation");
    }
    
    // TODO: Add 2-3 more golden vectors with different inputs
    // TODO: Sync with proof implementation team
}
```

**Integration Tests:**

```rust
#[cfg(test)]
mod integration_tests {
    use super::*;
    
    #[test]
    fn test_end_to_end_owner_tag_flow() {
        // Phase 1: Receiver generates keys
        let receiver_secret = ReceiverSecret::generate();
        let receiver_keys = ReceiverKeys::from_receiver_secret(receiver_secret);
        let receiver_card = receiver_keys.export_receiver_card();
        
        // Phase 2: Sender creates output
        let (r, r_pub, dh) = create_ecdh_sender(&receiver_keys.view_pk).unwrap();
        let k_dh = derive_k_dh(&dh);
        let owner_tag = OwnerTag::compute(&receiver_card.owner_handle, &k_dh);
        
        let leaf = AssetLeaf {
            asset_id: [0x01; 32],
            serial_id: 1,
            r_pub: r_pub.compress().to_bytes(),
            owner_tag,
            c_amount: [0x02; 32],
            enc_pack: vec![0x03; 100],
            tag16: None,
        };
        
        // Phase 3: Receiver scans and validates
        let is_mine = OwnerTag::verify(
            &receiver_keys.owner_handle,
            &receiver_keys.view_sk,
            &leaf,
        ).unwrap();
        
        assert!(is_mine, "Receiver should validate own output");
    }
    
    #[test]
    fn test_multi_output_unlinkability() {
        // Create 2 outputs for same receiver
        let receiver_secret = ReceiverSecret::generate();
        let keys = ReceiverKeys::from_receiver_secret(receiver_secret);
        
        let (_, _, dh1) = create_ecdh_sender(&keys.view_pk).unwrap();
        let (_, _, dh2) = create_ecdh_sender(&keys.view_pk).unwrap();
        
        let k_dh1 = derive_k_dh(&dh1);
        let k_dh2 = derive_k_dh(&dh2);
        
        let tag1 = OwnerTag::compute(&keys.owner_handle, &k_dh1);
        let tag2 = OwnerTag::compute(&keys.owner_handle, &k_dh2);
        
        // Tags MUST be different (unlinkability)
        assert_ne!(tag1, tag2, "Owner tags must be unlinkable");
    }
}
```

## 3.7 Tag16 (Scan Accelerator)

**Purpose:** Performance optimization hint enabling fast filtering of potentially relevant UTXOs before full decryption attempt. Reduces CPU/battery consumption during wallet scanning.

**Security Model:** Tag16 is a **performance hint ONLY**, NOT a security mechanism. Attackers with knowledge of ReceiverCard can craft false positives. Design assumes wallet can tolerate false positives and relies on M1 check for actual ownership verification.

**Implementation Phase:** Phase 3 (Privacy & Anti-Attack)  
**Dependencies:** §3.5 (Shared Secret), §3.6 (Owner Tag), §4.5 (Leaf AD)  
**Base Document Reference:** Z00Z-ECC-StealthAddress-5.md § "tag16 как ускоритель"

---

### 3.7.1 Tag16 Derivation

**Definition:** 16-bit truncated hash derived from per-leaf binding, serving as probabilistic filter for local wallet scanning. Collisions are expected and tolerated.

**Canonical Formula (Variant A - Recommended):**

```
tag16 = Trunc16(H_zk("Z00Z/TAG16" || k_dh || leaf_ad))
```

**Alternative Formula (Variant B - Request-Bound):**

```
tag16 = Trunc16(H_zk("Z00Z/TAG16" || k_dh || req_id))
```

Where:

- `Trunc16` = Take first 16 bits (2 bytes) of hash output
- `H_zk` = Poseidon2 hash (consensus-critical)
- `k_dh` = 32 bytes, symmetric key from ECDH
- `leaf_ad` = Associated data binding leaf fields (prevents rebinding attacks)
- `req_id` = 32 bytes, ephemeral request identifier from PaymentRequest (optional)

**Encoding Rules:**

```yaml
Tag16Encoding(MUST):
  variant_a(recommended):
    input: "domain || k_dh || leaf_ad"
    domain: "Z00Z/TAG16" (11 bytes UTF-8)
    k_dh: 32 bytes
    leaf_ad: 32 bytes (output of H_zk("Z00Z/LEAFAD" || ...))
    hash_output: 32 bytes (Poseidon2)
    truncation: first 2 bytes (u16 little-endian)
  
  variant_b(request_bound):
    input: "domain || k_dh || req_id"
    req_id: 32 bytes from PaymentRequest
    truncation: first 2 bytes (u16 little-endian)
  
  properties:
    - per_leaf_unique: true (via leaf_ad or req_id)
    - collision_rate: ~1/65536 (acceptable)
    - dos_resistance: NO (attacker with ReceiverCard can craft matches)
```

**Rust Implementation:**

```rust
use z00z_crypto::hash::{hash_domain, Poseidon2Hash};

pub fn compute_tag16(
    k_dh: &[u8; 32],
    leaf_ad: &[u8; 32],
) -> u16 {
    let hash = hash_domain!(TAG16, k_dh, leaf_ad);
    
    // Take first 2 bytes as little-endian u16
    u16::from_le_bytes([hash[0], hash[1]])
}

pub fn compute_tag16_with_req(
    k_dh: &[u8; 32],
    req_id: &[u8; 32],
) -> u16 {
    let mut hasher = Poseidon2Hash::new();
    hasher.update(b"Z00Z/TAG16");
    hasher.update(k_dh);
    hasher.update(req_id);
    let hash = hasher.finalize();
    
    u16::from_le_bytes([hash[0], hash[1]])
}

// Helper for sender (computes leaf_ad inline)
pub fn compute_tag16_sender(
    k_dh: &[u8; 32],
    asset_id: &[u8; 32],
    serial_id: u32,
    r_pub: &[u8; 32],
    owner_tag: &[u8; 32],
    c_amount: &[u8; 32],
) -> u16 {
    // Compute leaf_ad
    let leaf_ad = compute_leaf_ad(asset_id, serial_id, r_pub, owner_tag, c_amount);
    compute_tag16(k_dh, &leaf_ad)
}
```

#### 3.7.1.1 Per-Leaf Derivation

**Critical Property:** tag16 is NOT a stable address identifier. Each output has unique tag16 even for same receiver.

**Why Per-Leaf:**

```yaml
PerLeafReason:
  unlinkability:
    - different k_dh per output: tag16 changes
    - different leaf_ad per output: tag16 changes
    - observer cannot link outputs by tag16
  
  security:
    - prevents tag16 as stable target for spam
    - forces attacker to know current leaf_ad to craft match
    - mitigates (but does not eliminate) targeted DoS
```

**Collision Analysis:**

```
Collision Probability (Birthday Paradox):
- Tag space: 2^16 = 65,536
- For N outputs to same receiver:
  P(collision) ≈ N^2 / (2 * 65536) = N^2 / 131072
  
  N=100:    P ≈ 0.076 (7.6%)
  N=256:    P ≈ 0.5   (50%)
  N=1000:   P ≈ 7.6   (>99.9%)

Design Decision: Collisions are ACCEPTABLE
Reason: tag16 is filter hint, not unique identifier
Wallet MUST try decrypt on all tag16 matches
```

**Mermaid Diagram:**

```mermaid
graph TD
    A[Sender: Create Output] -->|compute| B[k_dh from ECDH]
    B --> C[leaf_ad from output fields]
    C --> D[tag16 = Trunc16 H k_dh leaf_ad]
    
    D --> E[Store in AssetLeaf optional field]
    
    E --> F[Receiver: Scan]
    F --> G[Filter: Does tag16 match my expected?]
    
    G -->|No match| H[Skip Fast]
    G -->|Match| I[Try Decrypt enc_pack]
    
    I -->|Decrypt success| J[M1 owner_tag Check]
    I -->|Decrypt fail| K[False Positive - Collision]
    
    J -->|Pass| L[Coin is Mine]
    J -->|Fail| M[Attack or Error]
    
    style H fill:#90EE90
    style L fill:#90EE90
    style K fill:#FFD700
    style M fill:#FF6347
```

#### 3.7.1.2 Collision Tolerance

**Wallet Behavior on Collision:**

```rust
pub struct Tag16Scanner {
    my_tag16_cache: HashMap<u16, Vec<CachedTagContext>>,
}

impl Tag16Scanner {
    pub fn scan_leaf(&self, leaf: &AssetLeaf) -> ScanDecision {
        match leaf.tag16 {
            None => ScanDecision::TryDecrypt,  // No filter, always try
            Some(tag16) => {
                // Check if tag16 in our expected set
                if self.my_tag16_cache.contains_key(&tag16) {
                    ScanDecision::TryDecrypt  // Potential match
                } else {
                    ScanDecision::Skip  // Definitely not mine
                }
            }
        }
    }
    
    pub fn handle_decrypt_after_tag16_match(&self, result: DecryptResult) {
        match result {
            DecryptResult::Success(coin) => {
                // True positive - coin is ours
                self.store_coin(coin);
            }
            DecryptResult::Failure => {
                // False positive - collision
                // This is EXPECTED and ACCEPTABLE
                metrics::increment_counter("scanner.tag16_false_positive");
            }
        }
    }
}
```

**Performance Trade-offs:**

```yaml
Tag16Performance:
  benefits:
    - skip_rate: ~99.998% for non-matching outputs
    - cpu_savings: avoids ECDH + decrypt for 65535/65536 outputs
    - battery_savings: critical for mobile wallets
    - bandwidth_savings: can request only matching candidates from inbox
  
  costs:
    - false_positive_rate: ~1.5% per 1000 outputs (acceptable)
    - storage_overhead: 2 bytes per leaf
    - cache_memory: ~64KB for 1000 expected tags (negligible)
  
  trade_off_decision: WORTHWHILE
```

---

### 3.7.2 Tag16 Security Model

**Threat Model:** tag16 provides NO cryptographic security. It is a public performance hint.

#### 3.7.2.1 Targeted Spam

**Attack Scenario:**

```yaml
AttackerCapabilities:
  knows:
    - receiver_card(owner_handle, view_pk)
    - tag16_derivation_formula
  
  can_do:
    - choose r values to generate matching tag16
    - create many outputs with same tag16
    - flood wallet with false positives
  
  cannot_do:
    - make wallet accept invalid owner_tag (M1 prevents)
    - decrypt enc_pack without r
    - steal funds without receiver_secret
```

**Attack Construction:**

```rust
// ATTACKER CODE (for demonstration/testing only)
pub fn craft_tag16_collision(
    target_tag16: u16,
    victim_view_pk: &RistrettoPoint,
) -> AssetLeaf {
    loop {
        // Generate random ephemeral r
        let r = Scalar::random(&mut OsRng);
        let r_pub = &r * &RISTRETTO_BASEPOINT_TABLE;
        
        // Compute ECDH
        let dh = r * victim_view_pk;
        let k_dh = derive_k_dh(&dh);
        
        // Compute dummy leaf_ad (can be arbitrary)
        let leaf_ad = [0xFF; 32];  // Simplified
        let tag16 = compute_tag16(&k_dh, &leaf_ad);
        
        if tag16 == target_tag16 {
            // Found collision!
            return AssetLeaf {
                r_pub: r_pub.compress().to_bytes(),
                owner_tag: [0; 32],  // Invalid, but tag16 matches
                tag16: Some(tag16),
                // ... rest of fields
            };
        }
        
        // Average attempts: 65536 for specific tag16
        // Feasible with modern hardware
    }
}
```

**Impact Analysis:**

```yaml
AttackImpact:
  wallet_behavior:
    - sees_matching_tag16: tries decrypt
    - decrypt_fails: skips (false positive)
    - repeats_for_all_spam_outputs
  
  dos_effect:
    - cpu_cost: N_spam * (ECDH + decrypt_attempt)
    - battery_drain: moderate on mobile
    - ux_degradation: slower sync
  
  mitigations:
    - rate_limiting: max decrypt attempts per second
    - background_scan: async processing
    - early_abort: bound decrypt attempts per tag16
    - reputation: track sender behavior (if available)
```

#### 3.7.2.2 Wallet Mitigation

**Defense-in-Depth Strategy:**

```rust
pub struct Tag16DoSMitigation {
    max_decrypt_per_second: usize,
    max_decrypt_per_tag16: usize,
    recent_decrypt_attempts: RateLimiter,
}

impl Tag16DoSMitigation {
    pub fn should_try_decrypt(
        &mut self,
        tag16: u16,
        leaf: &AssetLeaf,
    ) -> bool {
        // Defense 1: Global rate limit
        if !self.recent_decrypt_attempts.check_rate() {
            log::warn!("Global decrypt rate limit exceeded");
            return false;
        }
        
        // Defense 2: Per-tag16 limit (prevents spam on one tag)
        let count = self.get_decrypt_count_for_tag16(tag16);
        if count >= self.max_decrypt_per_tag16 {
            log::warn!("Tag16 {} exceeded max decrypt attempts", tag16);
            return false;
        }
        
        // Defense 3: Prioritize recent checkpoints
        if self.is_old_checkpoint(&leaf) {
            // Defer old leaves to background scan
            return false;
        }
        
        true
    }
    
    pub fn background_scan_strategy(&self) -> ScanStrategy {
        ScanStrategy {
            max_concurrent_decrypts: 4,
            batch_size: 100,
            sleep_between_batches: Duration::from_millis(100),
            prioritize_recent: true,
        }
    }
}
```

**UX Considerations:**

```yaml
UserExperience:
  normal_operation:
    - fast_sync: tag16 filter works, <1% false positives
    - instant_balance: new coins appear quickly
  
  under_attack:
    - slower_sync: rate limiting in effect
    - partial_balance: background scan for full history
    - user_warning: "Scan in progress, balance may be incomplete"
  
  recovery:
    - full_scan_mode: ignore tag16, try all outputs
    - offline_scan: export leaf data, scan on powerful machine
```

---

### 3.7.3 Tag16 API

**High-Level Trait:**

```rust
pub trait Tag16Operations {
    /// Compute tag16 from k_dh and leaf_ad
    fn compute(k_dh: &[u8; 32], leaf_ad: &[u8; 32]) -> u16;
    
    /// Compute tag16 with request binding
    fn compute_with_req(k_dh: &[u8; 32], req_id: &[u8; 32]) -> u16;
    
    /// Build cache of expected tag16 values for wallet
    fn build_cache(
        view_sk: &Scalar,
        recent_outputs: &[AssetLeaf],
    ) -> HashMap<u16, Vec<LeafContext>>;
    
    /// Check if tag16 potentially matches wallet
    fn is_potential_match(tag16: u16, cache: &HashMap<u16, Vec<LeafContext>>) -> bool;
}

impl Tag16Operations for Tag16 {
    fn compute(k_dh: &[u8; 32], leaf_ad: &[u8; 32]) -> u16 {
        compute_tag16(k_dh, leaf_ad)
    }
    
    fn compute_with_req(k_dh: &[u8; 32], req_id: &[u8; 32]) -> u16 {
        compute_tag16_with_req(k_dh, req_id)
    }
    
    fn build_cache(
        view_sk: &Scalar,
        recent_outputs: &[AssetLeaf],
    ) -> HashMap<u16, Vec<LeafContext>> {
        let mut cache = HashMap::new();
        
        for leaf in recent_outputs {
            if let Ok(k_dh) = extract_k_dh(view_sk, &leaf.r_pub) {
                let leaf_ad = compute_leaf_ad_from_leaf(leaf);
                let tag16 = Self::compute(&k_dh, &leaf_ad);
                
                cache.entry(tag16)
                    .or_insert_with(Vec::new)
                    .push(LeafContext {
                        asset_id: leaf.asset_id,
                        k_dh,
                        leaf_ad,
                    });
            }
        }
        
        cache
    }
    
    fn is_potential_match(
        tag16: u16,
        cache: &HashMap<u16, Vec<LeafContext>>,
    ) -> bool {
        cache.contains_key(&tag16)
    }
}
```

**Complete Implementation Module:**

```rust
// z00z_wallets/src/tag16.rs (NEW)

use std::collections::HashMap;
use curve25519_dalek::scalar::Scalar;
use z00z_crypto::hash::hash_domain;
use z00z_crypto::kdf::derive_k_dh;

pub struct Tag16Cache {
    /// Map: tag16 → list of (k_dh, leaf_ad) contexts
    cache: HashMap<u16, Vec<Tag16Context>>,
    /// Statistics
    stats: CacheStats,
}

#[derive(Clone)]
pub struct Tag16Context {
    pub k_dh: [u8; 32],
    pub leaf_ad: [u8; 32],
    pub asset_id: [u8; 32],
}

pub struct CacheStats {
    pub total_tags: usize,
    pub unique_tags: usize,
    pub max_collisions: usize,
    pub avg_collisions: f64,
}

impl Tag16Cache {
    pub fn new() -> Self {
        Self {
            cache: HashMap::new(),
            stats: CacheStats::default(),
        }
    }
    
    pub fn insert(&mut self, tag16: u16, context: Tag16Context) {
        self.cache.entry(tag16)
            .or_insert_with(Vec::new)
            .push(context);
        
        self.update_stats();
    }
    
    pub fn contains(&self, tag16: u16) -> bool {
        self.cache.contains_key(&tag16)
    }
    
    pub fn get_contexts(&self, tag16: u16) -> Option<&Vec<Tag16Context>> {
        self.cache.get(&tag16)
    }
    
    pub fn clear(&mut self) {
        self.cache.clear();
        self.stats = CacheStats::default();
    }
    
    fn update_stats(&mut self) {
        self.stats.total_tags = self.cache.values().map(|v| v.len()).sum();
        self.stats.unique_tags = self.cache.len();
        self.stats.max_collisions = self.cache.values().map(|v| v.len()).max().unwrap_or(0);
        self.stats.avg_collisions = if self.stats.unique_tags > 0 {
            self.stats.total_tags as f64 / self.stats.unique_tags as f64
        } else {
            0.0
        };
    }
    
    pub fn stats(&self) -> &CacheStats {
        &self.stats
    }
}

/// Scanner with tag16 optimization
pub struct OptimizedScanner {
    view_sk: Scalar,
    tag16_cache: Tag16Cache,
    dos_mitigation: Tag16DoSMitigation,
}

impl OptimizedScanner {
    pub fn scan_checkpoint(&mut self, leaves: &[AssetLeaf]) -> Vec<CoinRecord> {
        let mut found_coins = Vec::new();
        
        for leaf in leaves {
            // Phase 1: tag16 filter (if present)
            if let Some(tag16) = leaf.tag16 {
                if !self.tag16_cache.contains(tag16) {
                    // Fast reject: definitely not mine
                    continue;
                }
            }
            
            // Phase 2: DoS mitigation check
            if let Some(tag16) = leaf.tag16 {
                if !self.dos_mitigation.should_try_decrypt(tag16, leaf) {
                    // Rate limit exceeded, defer to background
                    self.defer_to_background(leaf);
                    continue;
                }
            }
            
            // Phase 3: Try decrypt
            if let Ok(coin) = self.try_decrypt_and_verify(leaf) {
                found_coins.push(coin);
            }
        }
        
        found_coins
    }
    
    fn try_decrypt_and_verify(&self, leaf: &AssetLeaf) -> Result<CoinRecord, Error> {
        // Extract k_dh
        let r_pub = decode_r_pub(&leaf.r_pub)?;
        let dh = compute_dh_receiver(&self.view_sk, &r_pub)?;
        let k_dh = derive_k_dh(&dh);
        
        // Decrypt enc_pack
        let coin_data = decrypt_coin_pack(&k_dh, &leaf.enc_pack, &leaf)?;
        
        // CRITICAL: M1 owner tag check
        let owner_tag_expected = compute_owner_tag(&self.owner_handle, &k_dh);
        if !constant_time_eq(&owner_tag_expected, &leaf.owner_tag) {
            return Err(Error::OwnerTagMismatch);
        }
        
        // Validate commitment
        validate_commitment(&coin_data, &leaf.c_amount)?;
        
        Ok(CoinRecord {
            asset_id: leaf.asset_id,
            coin_secret: coin_data.s_out,
            amount: coin_data.v,
            blinding: coin_data.r_out,
        })
    }
}
```

**Testing:**

```rust
#[cfg(test)]
mod tests {
    use super::*;
    
    #[test]
    fn test_tag16_computation() {
        let k_dh = [0x42; 32];
        let leaf_ad = [0xAA; 32];
        
        let tag16 = Tag16::compute(&k_dh, &leaf_ad);
        
        // tag16 should be u16 (0-65535)
        assert!(tag16 <= u16::MAX);
        
        // Deterministic
        let tag16_2 = Tag16::compute(&k_dh, &leaf_ad);
        assert_eq!(tag16, tag16_2);
        
        // Different leaf_ad → likely different tag16
        let leaf_ad_2 = [0xBB; 32];
        let tag16_3 = Tag16::compute(&k_dh, &leaf_ad_2);
        // This may collide, but very unlikely
        if tag16 == tag16_3 {
            println!("Collision detected (expected ~1/65536 probability)");
        }
    }
    
    #[test]
    fn test_tag16_cache_operations() {
        let mut cache = Tag16Cache::new();
        
        let tag16 = 0x1234;
        let context = Tag16Context {
            k_dh: [0x42; 32],
            leaf_ad: [0xAA; 32],
            asset_id: [0x01; 32],
        };
        
        assert!(!cache.contains(tag16));
        
        cache.insert(tag16, context.clone());
        
        assert!(cache.contains(tag16));
        assert_eq!(cache.get_contexts(tag16).unwrap().len(), 1);
    }
    
    #[test]
    fn test_tag16_collision_handling() {
        let mut cache = Tag16Cache::new();
        let tag16 = 0x1234;
        
        // Insert multiple contexts with same tag16 (collision)
        for i in 0..5 {
            let context = Tag16Context {
                k_dh: [i as u8; 32],
                leaf_ad: [i as u8 + 10; 32],
                asset_id: [i as u8 + 20; 32],
            };
            cache.insert(tag16, context);
        }
        
        assert_eq!(cache.get_contexts(tag16).unwrap().len(), 5);
        
        let stats = cache.stats();
        assert_eq!(stats.unique_tags, 1);
        assert_eq!(stats.total_tags, 5);
        assert_eq!(stats.max_collisions, 5);
    }
    
    #[test]
    fn test_tag16_false_positive_rate() {
        // Statistical test: measure collision rate
        let mut tag16_set = std::collections::HashSet::new();
        let n_samples = 1000;
        
        for i in 0..n_samples {
            let k_dh = hash_to_bytes(&format!("kdh_{}", i));
            let leaf_ad = hash_to_bytes(&format!("ad_{}", i));
            let tag16 = Tag16::compute(&k_dh, &leaf_ad);
            tag16_set.insert(tag16);
        }
        
        let unique_count = tag16_set.len();
        let collision_rate = 1.0 - (unique_count as f64 / n_samples as f64);
        
        // For 1000 samples in 65536 space: expect ~0.0076 collision rate
        println!("Collision rate: {:.4}", collision_rate);
        assert!(collision_rate < 0.02, "Unexpectedly high collision rate");
    }
    
    #[test]
    fn test_scanner_with_tag16_filter() {
        let receiver_secret = ReceiverSecret::generate();
        let keys = ReceiverKeys::from_receiver_secret(receiver_secret);
        
        let mut scanner = OptimizedScanner::new(keys.view_sk);
        
        // Create output for this receiver
        let (r, r_pub, dh) = create_ecdh_sender(&keys.view_pk).unwrap();
        let k_dh = derive_k_dh(&dh);
        let leaf_ad = compute_leaf_ad_example();
        let tag16 = Tag16::compute(&k_dh, &leaf_ad);
        
        // Build cache
        scanner.tag16_cache.insert(tag16, Tag16Context {
            k_dh,
            leaf_ad,
            asset_id: [0x01; 32],
        });
        
        // Create leaf with matching tag16
        let leaf_mine = create_test_leaf(r_pub, tag16);
        
        // Create leaf with wrong tag16
        let leaf_not_mine = create_test_leaf(r_pub, tag16 + 1);
        
        // Scanner should skip leaf_not_mine
        assert!(!scanner.tag16_cache.contains(tag16 + 1));
        // Scanner should try leaf_mine
        assert!(scanner.tag16_cache.contains(tag16));
    }
}
```

**Integration Tests:**

```rust
#[cfg(test)]
mod integration_tests {
    use super::*;
    
    #[test]
    fn test_end_to_end_with_tag16() {
        // Setup
        let receiver_secret = ReceiverSecret::generate();
        let keys = ReceiverKeys::from_receiver_secret(receiver_secret);
        let receiver_card = keys.export_receiver_card();
        
        // Sender creates output with tag16
        let (r, r_pub, dh) = create_ecdh_sender(&keys.view_pk).unwrap();
        let k_dh = derive_k_dh(&dh);
        
        let leaf = AssetLeafBuilder::new()
            .asset_id([0x01; 32])
            .serial_id(1)
            .r_pub(r_pub)
            .owner_tag(compute_owner_tag(&receiver_card.owner_handle, &k_dh))
            .build_with_tag16();
        
        // Receiver scans
        let mut scanner = OptimizedScanner::new(keys.view_sk);
        scanner.build_tag16_cache_from_view_key();
        
        let results = scanner.scan_checkpoint(&[leaf]);
        assert_eq!(results.len(), 1, "Should find 1 coin");
    }
    
    #[test]
    fn test_dos_resistance() {
        let receiver_secret = ReceiverSecret::generate();
        let keys = ReceiverKeys::from_receiver_secret(receiver_secret);
        
        let mut scanner = OptimizedScanner::new(keys.view_sk);
        scanner.dos_mitigation.max_decrypt_per_second = 10;
        
        // Create 100 spam outputs with matching tag16
        let spam_tag16 = 0x1234;
        let spam_leaves: Vec<_> = (0..100)
            .map(|_| create_spam_leaf_with_tag16(spam_tag16))
            .collect();
        
        // Scanner should rate-limit
        let start = std::time::Instant::now();
        let results = scanner.scan_checkpoint(&spam_leaves);
        let elapsed = start.elapsed();
        
        // Should take at least 1 second due to rate limiting
        assert!(elapsed.as_secs() >= 1, "Rate limiting not working");
        
        // Should find 0 valid coins (all spam)
        assert_eq!(results.len(), 0);
    }
}
```

**Golden Test Vectors:**

```rust
#[cfg(test)]
mod golden_tests {
    use super::*;
    
    #[test]
    fn golden_vector_tag16_1() {
        let k_dh = hex::decode(
            "1111111111111111111111111111111111111111111111111111111111111111"
        ).unwrap();
        let leaf_ad = hex::decode(
            "2222222222222222222222222222222222222222222222222222222222222222"
        ).unwrap();
        
        let tag16 = Tag16::compute(
            k_dh.as_slice().try_into().unwrap(),
            leaf_ad.as_slice().try_into().unwrap(),
        );
        
        // Expected value (MUST sync with proof implementation)
        let expected: u16 = 0xAAAA;  // TODO: Replace with actual value
        
        assert_eq!(tag16, expected,
            "tag16 golden vector mismatch - check H_zk and truncation");
    }
}
```

**Performance Benchmarks:**

```rust
#[cfg(test)]
mod benches {
    use super::*;
    use criterion::{black_box, Criterion};
    
    pub fn benchmark_tag16_compute(c: &mut Criterion) {
        let k_dh = [0x42; 32];
        let leaf_ad = [0xAA; 32];
        
        c.bench_function("tag16_compute", |b| {
            b.iter(|| {
                Tag16::compute(black_box(&k_dh), black_box(&leaf_ad))
            })
        });
    }
    
    pub fn benchmark_scan_with_tag16_filter(c: &mut Criterion) {
        let receiver_secret = ReceiverSecret::generate();
        let keys = ReceiverKeys::from_receiver_secret(receiver_secret);
        let mut scanner = OptimizedScanner::new(keys.view_sk);
        
        // Create 10000 leaves, 10 are ours
        let mut leaves = Vec::new();
        for i in 0..10000 {
            let is_mine = i % 1000 == 0;
            leaves.push(create_test_leaf_for_bench(is_mine, &keys));
        }
        
        c.bench_function("scan_10k_with_tag16", |b| {
            b.iter(|| {
                scanner.scan_checkpoint(black_box(&leaves))
            })
        });
    }
    
    pub fn benchmark_scan_without_tag16_filter(c: &mut Criterion) {
        // Same as above but with tag16 disabled
        // Expect 100-1000x slower due to full decrypt attempts
    }
}
```

---

### 3.7.4 Tag16 Deployment Considerations

**Optional Field:**

```yaml
Tag16Deployment:
  field_status: OPTIONAL in AssetLeaf
  default_behavior: include unless privacy concern
  
  when_to_omit:
    - high_privacy_mode: user preference
    - small_anonymity_set: fewer than 100 receivers
    - testing_phase: before tag16 cache ready
  
  when_to_include:
    - production_wallets: recommended
    - mobile_clients: STRONGLY recommended (battery)
    - high_throughput: >1000 tx/day per wallet
```

**Migration Strategy:**

```yaml
Tag16Migration:
  phase_1_optional:
    - wallets support tag16 if present
    - wallets scan without tag16 if absent
    - senders may omit tag16
  
  phase_2_adoption:
    - most senders include tag16
    - wallets prioritize tag16-enabled leaves
    - metrics show >50% tag16 usage
  
  phase_3_standard:
    - tag16 becomes de-facto standard
    - wallet UX optimized assuming tag16
    - legacy support for non-tag16 leaves
```

**Privacy vs Performance Trade-off:**

```yaml
PrivacyConsiderations:
  tag16_reveals:
    - nothing_directly: tag16 is random-looking
    - timing_correlation: if inbox uses tag16 routing
    - spam_vector: attackers can craft tag16 matches
  
  mitigations:
    - use_req_id_variant: prevents stable tag16
    - inbox_padding: add dummy messages
    - batched_requests: mix multiple receivers
  
  recommendation:
    - for_most_users: include tag16 (performance benefit >> privacy cost)
    - for_high_privacy: omit tag16, use full scan
    - for_enterprises: include tag16, use private inbox infrastructure
```

---

---

# 