# E2E Test Examples — Cryptographic Foundation (§2)

**Spec source:** `2_Cryptographic_Foundation.md`  
**Date:** 2026-02-19  
**Purpose:** Document the end-to-end tests and examples that fully exercise and prove the correctness of every cryptographic primitive specified in Section 2.

Each section below describes:
- 🎯 **What is tested** — the exact invariant or behaviour being verified
- 🔬 **How it is tested** — the approach (golden vector, property, round-trip, adversarial, integration)
- 💡 **Why it matters** — the security or correctness guarantee it provides

---

## Table of Contents

1. [ECC Primitives (§2.1)](#1-ecc-primitives)
2. [Hash Functions & Domain Separation (§2.2)](#2-hash-functions--domain-separation)
3. [Hash-to-Scalar H2Scalar (§2.2.3)](#3-hash-to-scalar-h2scalar)
4. [Pedersen Commitments (§2.3)](#4-pedersen-commitments)
5. [Range Proofs / Bulletproofs+ (§2.4)](#5-range-proofs--bulletproofs)
6. [ECDH Stealth-Address Protocol (§2.5)](#6-ecdh-stealth-address-protocol)
7. [Key Derivation Functions (§2.6)](#7-key-derivation-functions)
8. [ZkPack_v1 AEAD (§2.7)](#8-zkpack_v1-aead)
9. [Full E2E Stealth-Address Cycle](#9-full-e2e-stealth-address-cycle)
10. [Cross-Implementation Golden Vectors](#10-cross-implementation-golden-vectors)
11. [Adversarial / Attack-Scenario Tests](#11-adversarial--attack-scenario-tests)
12. [Performance Benchmarks As Sanity Tests](#12-performance-benchmarks-as-sanity-tests)

---

## Phase 1. ECC Primitives

### 1.1 Point Encoding Roundtrip

**🎯 Что тестируем:** Любая произвольная точка Ristretto255 сериализуется в ровно 32 байта и десериализуется обратно в ту же точку.

**🔬 Как тестируем:**
```
for each random_point in 1000 random Ristretto points:
    bytes = random_point.compress().to_bytes()   // 32 bytes
    point_back = CompressedRistretto(bytes).decompress()
    assert point_back == Some(random_point)
    assert bytes.len() == 32
```

**💡 Почему важно:** Консенсус требует детерминированного и каноничного кодирования для `R_pub`, `view_pk`, `C_amount`. Различие хотя бы в одном бите означает разные `k_dh` у отправителя и получателя — coin потерян навсегда.

**📋 Чеклист реализации:**
- [x] Создать файл `crates/z00z_crypto/tests/test_ecc_primitives.rs`
- [x] Зарегистрировать в `crates/z00z_crypto/Cargo.toml` секцию `[[test]] name = "test_ecc_primitives" path = "tests/test_ecc_primitives.rs"`
- [x] Добавить в начало файла:
  ```rust
  use curve25519_dalek::ristretto::{RistrettoPoint, CompressedRistretto};
  use curve25519_dalek::scalar::Scalar;
  use curve25519_dalek::constants::RISTRETTO_BASEPOINT_POINT;
  use rand::rngs::OsRng;
  use rand::RngCore;
  ```
- [x] Написать вспомогательную функцию `fn random_ristretto_point() -> RistrettoPoint` — использует `Scalar::random(&mut OsRng)` умножение на `RISTRETTO_BASEPOINT_POINT`
- [x] Написать тест `fn test_point_encoding_roundtrip()` с аннотацией `#[test]`
  - [x] Создать цикл `for _ in 0..1000`
  - [x] В каждой итерации вызвать `random_ristretto_point()`
  - [x] Вызвать `.compress()` → `.to_bytes()` → получить `[u8; 32]`
  - [x] Проверить `bytes.len() == 32`
  - [x] Вызвать `CompressedRistretto(bytes).decompress()` → получить `Option<RistrettoPoint>`
  - [x] Unwrap через `assert!(result.is_some(), "decompress failed")`
  - [x] Проверить `result.unwrap() == original_point`
- [x] Запустить `cargo test -p z00z_crypto test_point_encoding_roundtrip` и убедиться, что тест проходит
- [x] Добавить тест в CI: в `.github/workflows/ci.yml` шаг `cargo test -p z00z_crypto` уже должен его покрывать — убедиться, что `[[test]]` виден

---

### 1.2 Canonical Encoding: Один Маппинг Per Point

**🎯 Что тестируем:** У каждой точки ровно одно 32-байтное представление (канонический признак Ristretto).

**🔬 Как тестируем:**
```
point = random_point()
enc1 = point.compress().to_bytes()   // canonical
enc2 = point.compress().to_bytes()   // same operation
assert enc1 == enc2                  // deterministic

// Отдельно: non-canonical bytes MUST decompress to None
non_canonical_bytes = [0xFF; 32]
assert CompressedRistretto(non_canonical_bytes).decompress() == None
```

**💡 Почему важно:** Без этого свойства узел A и узел B могут получить разные точки из одного поля в транзакции → консенсус-разрыв.

**📋 Чеклист реализации:**
- [x] Использовать тот же файл `crates/z00z_crypto/tests/test_ecc_primitives.rs`
- [x] Написать тест `fn test_canonical_encoding_deterministic()` с аннотацией `#[test]`
  - [x] Сгенерировать `point = random_ristretto_point()`
  - [x] Вызвать `compress().to_bytes()` дважды → `enc1`, `enc2`
  - [x] `assert_eq!(enc1, enc2, "encoding is not deterministic")`
- [x] Написать отдельный тест `fn test_non_canonical_bytes_reject()` с аннотацией `#[test]`
  - [x] Создать `[0xFF_u8; 32]` как `non_canonical: [u8; 32]`
  - [x] Вызвать `CompressedRistretto(non_canonical).decompress()`
  - [x] `assert!(result.is_none(), "non-canonical bytes must not decompress")`
  - [x] Дополнительно проверить несколько известных невалидных значений: `[0x01_u8; 32]`, `[0xFE_u8; 32]`
- [x] Запустить `cargo test -p z00z_crypto test_canonical` и убедиться, что оба теста проходят

---

### 1.3 Identity Point: Reject в Протоколе

**🎯 Что тестируем:** Функции `validate_point`, `validate_receiver_card`, `validate_utxo_leaf` отклоняют точку-идентику (нейтральный элемент, encoded как `[0u8; 32]`).

**🔬 Как тестируем:**
```
identity = RistrettoPoint::identity()
assert identity.compress().to_bytes() == [0u8; 32]

// Validate functions MUST reject
assert validate_point(&identity) == Err(IdentityPointNotAllowed)
assert parse_and_validate_R_pub(&[0u8; 32]) == Err(IdentityPointNotAllowed)

bad_card = ReceiverCard { view_pk: identity, .. }
assert validate_receiver_card(&bad_card) == Err(IdentityPointNotAllowed)

bad_leaf = UtxoLeaf { R_pub: identity, .. }
assert validate_utxo_leaf(&bad_leaf) == Err(IdentityPointNotAllowed)

// Valid non-identity point MUST pass
valid_point = Scalar::random() * G
assert validate_point(&valid_point) == Ok(())
```

**💡 Почему важно:** `view_pk = identity` означает `dh = r * identity = identity` для любого отправителя → все выходы для любого получателя дают одинаковый `k_dh` → тотальная деанонимизация (Attack Scenario 1 в §2.1.3.3).

**📋 Чеклист реализации:**
- [x] Использовать `crates/z00z_crypto/tests/test_ecc_primitives.rs`
- [x] Добавить импорт типа ошибки: `use z00z_crypto::error::CryptoError;` (или как называется enum ошибок — проверить `crates/z00z_crypto/src/error.rs`)
- [x] Убедиться, что в `CryptoError` существует вариант `IdentityPointNotAllowed` — если нет, **сначала добавить его** в `crates/z00z_crypto/src/error.rs`
- [x] Написать тест `fn test_identity_point_rejected_by_validate_point()` — `#[test]`
  - [x] `let identity = RistrettoPoint::identity();`
  - [x] `assert_eq!(identity.compress().to_bytes(), [0u8; 32]);`
  - [x] Вызвать публичную функцию `validate_point(&identity)` из `z00z_crypto`
  - [x] `assert!(matches!(result, Err(CryptoError::IdentityPointNotAllowed)));`
- [x] Проверки `ReceiverCard` и `UtxoLeaf` с identity вынести в `crates/z00z_wallets/tests/test_adversarial.rs` (см. §11.1 и §11.5), чтобы не создавать зависимость `z00z_crypto` → `z00z_wallets`
- [x] Написать тест `fn test_valid_non_identity_point_accepted()` — `#[test]`
  - [x] `let scalar = Scalar::random(&mut OsRng);`
  - [x] `let valid = scalar * RISTRETTO_BASEPOINT_POINT;`
  - [x] `assert!(validate_point(&valid).is_ok());`
- [x] Запустить `cargo test -p z00z_crypto test_identity` — crypto-level тесты должны пройти

---

### 1.4 Zero Scalar: Reject

**🎯 Что тестируем:** Нулевой скаляр `r = 0` для эфемерного ключа отвергается.

**🔬 Как тестируем:**
```
r = Scalar::ZERO
assert generate_ephemeral_r_with_seed([0u8; 32]) != Scalar::ZERO

// If 0 is produced by hedged mechanism, it MUST be re-sampled:
result = sender_derive_dh_with_r(Scalar::ZERO, view_pk)
assert result == Err(ZeroScalarNotAllowed)
```

**💡 Почему важно:** `r = 0 → R_pub = 0 * G = identity` — нарушает правило §1.3; все получатели получают один и тот же DH.

**📋 Чеклист реализации:**
- [x] Использовать `crates/z00z_crypto/tests/test_ecc_primitives.rs`
- [x] Убедиться, что в `CryptoError` существует вариант `ZeroScalarNotAllowed` — если нет, добавить в `crates/z00z_crypto/src/error.rs`
- [x] Написать тест `fn test_zero_scalar_rejected_by_hedged_generation()` — `#[test]`
  - [x] Вызвать `generate_ephemeral_r_with_seed([0u8; 32])` — найти эту функцию в `z00z_crypto::ecdh` или аналогичном модуле
  - [x] `assert_ne!(result, Scalar::ZERO, "hedged_r must never be zero");`
  - [x] Повторить для seed `[0xFF; 32]` и `[0x01; 32]`
- [x] Написать тест `fn test_zero_scalar_rejected_by_sender_derive_dh()` — `#[test]`
  - [x] Получить валидный `view_pk`: `let view_pk = Scalar::random(&mut OsRng) * RISTRETTO_BASEPOINT_POINT;`
  - [x] Найти функцию `sender_derive_dh_with_r(r: Scalar, view_pk: &RistrettoPoint)` в `z00z_crypto::ecdh`
  - [x] Вызвать `sender_derive_dh_with_r(Scalar::ZERO, &view_pk)`
  - [x] `assert!(matches!(result, Err(CryptoError::ZeroScalarNotAllowed)));`
- [x] Запустить `cargo test -p z00z_crypto test_zero_scalar` — оба теста должны пройти

---

### 1.5 Scalar Arithmetic: Корректность Group Laws

**🎯 Что тестируем:** Скалярное умножение дистрибутивно и коммутативно в экспоненте.

**🔬 Как тестируем:**
```
a, b = random scalars, P = random point

// Distributivity: (a + b) * P == a*P + b*P
assert (a + b) * P == a * P + b * P

// Commutativity of scalar in exponent: a * (b * P) == b * (a * P)
assert a * (b * P) == b * (a * P)

// This is the ECDH correctness property (see §2.5.1.3)
r = random, view_sk = random
G = RISTRETTO_BASEPOINT
R_pub = r * G
view_pk = view_sk * G
dh_sender   = r * view_pk        // r * (view_sk * G)
dh_receiver = view_sk * R_pub    // view_sk * (r * G)
assert dh_sender == dh_receiver  // Algebraic identity
```

**💡 Почему важно:** Вся схема stealth-адресов держится на этой алгебраической тождественности. Без теста корректность аппаратно-специфичных оптимизаций не верифицирована.

**📋 Чеклист реализации:**
- [x] Использовать `crates/z00z_crypto/tests/test_ecc_primitives.rs`
- [x] Написать тест `fn test_scalar_mul_distributivity()` — `#[test]`
  - [x] `let a = Scalar::random(&mut OsRng); let b = Scalar::random(&mut OsRng);`
  - [x] `let P = random_ristretto_point();`
  - [x] `assert_eq!((a + b) * P, a * P + b * P);`
- [x] Написать тест `fn test_scalar_mul_commutativity_in_exponent()` — `#[test]`
  - [x] `let a = Scalar::random(&mut OsRng); let b = Scalar::random(&mut OsRng);`
  - [x] `let P = random_ristretto_point();`
  - [x] `assert_eq!(a * (b * P), b * (a * P));`
- [x] Написать тест `fn test_ecdh_algebraic_identity()` — `#[test]` (ключевой тест!)
  - [x] `let r = Scalar::random(&mut OsRng);`
  - [x] `let view_sk = Scalar::random(&mut OsRng);`
  - [x] `let G = RISTRETTO_BASEPOINT_POINT;`
  - [x] `let R_pub = r * G;`
  - [x] `let view_pk = view_sk * G;`
  - [x] `let dh_sender = r * view_pk;`
  - [x] `let dh_receiver = view_sk * R_pub;`
  - [x] `assert_eq!(dh_sender, dh_receiver, "ECDH algebraic identity violated");`
  - [x] Повторить в цикле `for _ in 0..100` с разными случайными ключами
- [x] Запустить все три теста через `cargo test -p z00z_crypto test_scalar`

---

### 1.6 Point Decompression: Graceful Failure на Невалидных Inputs

**🎯 Что тестируем:** `safe_decompress_point` возвращает ошибку (не паникует!) для всех классов невалидных входов.

**🔬 Как тестируем:**
```
// Case 1: Wrong length (16 bytes instead of 32)
assert safe_decompress_point(&[0u8; 16]) == Err(InvalidPointLength)

// Case 2: Too long (64 bytes)
assert safe_decompress_point(&[0u8; 64]) == Err(InvalidPointLength)

// Case 3: High-bit set (non-canonical field element)
non_canonical = [0u8; 32]; non_canonical[31] = 0xFF
assert safe_decompress_point(&non_canonical) == Err(PointDecompressionFailed)

// Case 4: 32 zeros (identity)
assert safe_decompress_point(&[0u8; 32]) == Err(IdentityPointNotAllowed)

// Case 5: Valid random point
valid = random_point().compress().to_bytes()
assert safe_decompress_point(&valid) == Ok(_)

// Case 6: DoS simulation — 100_000 invalid points, wallet must not crash
for _ in 0..100_000:
    result = safe_decompress_point(&random_bytes_32())
    assert result.is_ok() || result.is_err()  // Never panic
```

**💡 Почему важно:** Защита от DoS (Attack 2 в §2.1.3.1). Злоумышленник может спамить невалидными `R_pub` в листьях; `unwrap()` обрушил бы кошелёк.

**📋 Чеклист реализации:**
- [x] Использовать `crates/z00z_crypto/tests/test_ecc_primitives.rs`
- [x] Убедиться, что в публичном API `z00z_crypto` существует функция `safe_decompress_point(bytes: &[u8]) -> Result<RistrettoPoint, CryptoError>`
  - [x] Если не существует — создать в `crates/z00z_crypto/src/ecc.rs` и экспортировать через `lib.rs`
  - [x] Функция должна: (1) проверить `bytes.len() == 32`, иначе `Err(CryptoError::InvalidPointLength)`; (2) вызвать `CompressedRistretto::decompress()`, `None` → `Err(CryptoError::PointDecompressionFailed)`; (3) проверить не-identity, `identity` → `Err(CryptoError::IdentityPointNotAllowed)`
- [x] Убедиться, что в `CryptoError` есть варианты: `InvalidPointLength`, `PointDecompressionFailed`, `IdentityPointNotAllowed`
- [x] Написать тест `fn test_safe_decompress_wrong_length()` — `#[test]`
  - [x] `safe_decompress_point(&[0u8; 16])` → `Err(InvalidPointLength)`
  - [x] `safe_decompress_point(&[0u8; 64])` → `Err(InvalidPointLength)`
  - [x] `safe_decompress_point(&[])` → `Err(InvalidPointLength)`
- [x] Написать тест `fn test_safe_decompress_noncanonical()` — `#[test]`
  - [x] `let mut nc = [0u8; 32]; nc[31] = 0xFF;`
  - [x] `safe_decompress_point(&nc)` → `Err(PointDecompressionFailed)`
- [x] Написать тест `fn test_safe_decompress_identity_rejected()` — `#[test]`
  - [x] `safe_decompress_point(&[0u8; 32])` → `Err(IdentityPointNotAllowed)`
- [x] Написать тест `fn test_safe_decompress_valid_point()` — `#[test]`
  - [x] Сгенерировать валидную точку, сжать, вызвать `safe_decompress_point` → `Ok(...)`
- [x] Написать тест `fn test_safe_decompress_dos_100k_no_panic()` — `#[test]`
  - [x] В цикле `for _ in 0..100_000` генерировать случайные `[u8; 32]`
  - [x] Вызывать `safe_decompress_point(...)` и проверять только `.is_ok() || .is_err()` (не паникует)
  - [x] Использовать `std::panic::catch_unwind` как дополнительную гарантию
- [x] Запустить `cargo test -p z00z_crypto test_safe_decompress`

---

## Phase 2. Hash Functions & Domain Separation

### 2.1 H_zk vs H_wallet: Разные Функции — Разные Результаты

**🎯 Что тестируем:** `poseidon2_hash(domain, data) != blake2b_hash(domain, data)` для одного и того же `(domain, data)`.

**🔬 Как тестируем:**
```
data = [0x42u8; 32]

// Same domain, same data, different hash functions
zk_result     = poseidon2_hash(b"Z00Z/RID", &[&data])   // H_zk
wallet_result = blake2b_hash(b"Z00Z/RID", &[&data])     // H_wallet

assert zk_result != wallet_result
// This proves: using wrong hash → proof verification failure
```

**💡 Почему важно:** Если кошелёк по ошибке использует Blake2b для `owner_handle`, proof circuit (который ожидает Poseidon2) не подтвердит spending constraint — кошелёк не сможет тратить монеты.

**📋 Чеклист реализации:**
- [x] Создать файл `crates/z00z_crypto/tests/test_hash_policy.rs`
- [x] Зарегистрировать в `Cargo.toml` crate `z00z_crypto`: `[[test]] name = "test_hash_policy" path = "tests/test_hash_policy.rs"`
- [x] Добавить импорты:
  ```rust
  use z00z_crypto::hash::{poseidon2_hash, blake2b_hash};
  ```
- [x] Проверить, что обе функции существуют в `crates/z00z_crypto/src/hash.rs` и экспортированы через `lib.rs`
- [x] Написать тест `fn test_hzk_and_hwallet_differ()` — `#[test]`
  - [x] `let data = [0x42u8; 32];`
  - [x] `let zk = poseidon2_hash(b"Z00Z/RID", &[&data]);`
  - [x] `let wallet = blake2b_hash(b"Z00Z/RID", &[&data]);`
  - [x] `assert_ne!(zk, wallet, "H_zk and H_wallet must differ for same input");`
  - [x] Повторить для domainов `"Z00Z/DH"` и `"WALLET/SEED"`
- [x] Запустить `cargo test -p z00z_crypto test_hzk_and_hwallet_differ`

---

### 2.2 Domain Separation: Разные Домены — Разные Хэши

**🎯 Что тестируем:** Каждый из зарегистрированных доменов (§2.2.2) при одинаковых данных даёт уникальный хэш.

**🔬 Как тестируем:**
```
CONSENSUS_DOMAINS = [
  b"Z00Z/RID", b"Z00Z/VIEW", b"Z00Z/IDENTITY", b"Z00Z/DH", b"Z00Z/TAG", b"Z00Z/TAG16",
    b"Z00Z/ASSET", b"Z00Z/LEAFAD", b"Z00Z/LEAFHASH",
    b"Z00Z/PACKKEY", b"Z00Z/PACKNONCE", b"Z00Z/PACKSTR", b"Z00Z/PACKTAG",
    b"Z00Z/XOFBLK", b"Z00Z/TXDIGEST", b"Z00Z/R",
]
WALLET_DOMAINS = [b"WALLET/SEED", b"WALLET/DB_ID", b"WALLET/CACHE"]

data = [0x42u8; 32]
seen = HashSet::new()

for domain in CONSENSUS_DOMAINS + WALLET_DOMAINS:
    h = poseidon2_hash(domain, &[&data])
    assert seen.insert(h), "Domain collision: {}", domain

assert seen.len() == 19
```

**⚠️ Важно:** Так как в §3.2 используется домен `Z00Z/IDENTITY`, он должен входить в общий реестр доменов.

**💡 Почему важно:** Коллизия доменов означает, что ключ одного типа (`view_sk`) может использоваться для другой операции (`pack_key`) → катастрофический сбой всех криптографических гарантий.

**📋 Чеклист реализации:**
- [x] Использовать файл `crates/z00z_crypto/tests/test_hash_policy.rs`
- [x] Найти или создать константу в `z00z_crypto::hash::domains` со списком всех 19 доменов; если список несуществует — создать `pub const ALL_DOMAINS: &[&[u8]] = &[b"Z00Z/RID", b"Z00Z/VIEW", b"Z00Z/IDENTITY", b"Z00Z/DH", b"Z00Z/TAG", b"Z00Z/TAG16", b"Z00Z/ASSET", b"Z00Z/LEAFAD", b"Z00Z/LEAFHASH", b"Z00Z/PACKKEY", b"Z00Z/PACKNONCE", b"Z00Z/PACKSTR", b"Z00Z/PACKTAG", b"Z00Z/XOFBLK", b"Z00Z/TXDIGEST", b"Z00Z/R", b"WALLET/SEED", b"WALLET/DB_ID", b"WALLET/CACHE"];`
- [x] Написать тест `fn test_domain_registry_uniqueness()` — `#[test]`
  - [x] Импортировать `use std::collections::HashSet;`
  - [x] `let data = [0x42u8; 32];`
  - [x] Создать `let mut seen: HashSet<[u8; 32]> = HashSet::new();`
  - [x] Цикл `for domain in ALL_DOMAINS`:
    - [x] Вызвать `poseidon2_hash(domain, &[&data])` → `h: [u8; 32]`
    - [x] `assert!(seen.insert(h), "Domain collision: {:?}", domain);`
  - [x] `assert_eq!(seen.len(), 19, "Not all 19 domains produce distinct hashes");`
- [x] Запустить `cargo test -p z00z_crypto test_domain_registry_uniqueness`

---

### 2.3 H_zk: Детерминированность

**🎯 Что тестируем:** `poseidon2_hash` возвращает одни и те же байты при повторных вызовах.

**🔬 Как тестируем:**
```
for _ in 0..1000:
    data = random_bytes_32()
    h1 = poseidon2_hash(b"Z00Z/RID", &[&data])
    h2 = poseidon2_hash(b"Z00Z/RID", &[&data])
    assert h1 == h2, "Non-deterministic hash output"
```

**💡 Почему важно:** Получатель должен воспроизводить тот же `owner_handle`, `k_dh`, `owner_tag` при каждом сканировании; без детерминированности невозможно найти свои монеты.

**📋 Чеклист реализации:**
- [x] Использовать `crates/z00z_crypto/tests/test_hash_policy.rs`
- [x] Написать тест `fn test_poseidon2_deterministic()` — `#[test]`
  - [x] Импортировать `use rand::rngs::OsRng; use rand::RngCore;`
  - [x] В цикле `for _ in 0..1000`:
    - [x] Сгенерировать `data: [u8; 32]` через `OsRng`
    - [x] `let h1 = poseidon2_hash(b"Z00Z/RID", &[&data]);`
    - [x] `let h2 = poseidon2_hash(b"Z00Z/RID", &[&data]);`
    - [x] `assert_eq!(h1, h2, "non-deterministic Poseidon2 output");`
- [x] Запустить `cargo test -p z00z_crypto test_poseidon2_deterministic`

---

### 2.4 H_zk: Poseidon2 Выдаёт 32 Байта

**🎯 Что тестируем:** Poseidon2 всегда возвращает ровно 32 байта, независимо от длины входа.

**🔬 Как тестируем:**
```
for input_len in [0, 1, 31, 32, 33, 64, 128, 1000]:
    data = vec![0x42u8; input_len]
    h = poseidon2_hash(b"Z00Z/TEST", &[&data])
    assert h.len() == 32
```

**📋 Чеклист реализации:**
- [x] Использовать `crates/z00z_crypto/tests/test_hash_policy.rs`
- [x] Написать тест `fn test_poseidon2_output_len_always_32()` — `#[test]`
  - [x] Создать список `let lens: &[usize] = &[0, 1, 31, 32, 33, 64, 128, 1000];`
  - [x] Цикл `for &len in lens`:
    - [x] `let data = vec![0x42u8; len];`
    - [x] `let h = poseidon2_hash(b"Z00Z/TEST", &[data.as_slice()]);`
    - [x] `assert_eq!(h.len(), 32, "hash length must be 32 for input len={}", len);`
- [x] Запустить `cargo test -p z00z_crypto test_poseidon2_output_len_always_32`

---

### 2.5 Policy Test: Только Poseidon2 Для Консенсусных Доменов

**🎯 Что тестируем:** В кодовой базе ни один `Z00Z/*`-домен не передаётся в `blake2b_hash`.

**🔬 Как тестируем:**
```
// Static analysis / grep test (в CI):
grep -rn "blake2b_hash" crates/ | grep '"Z00Z/'
// Expected: пусто (0 строк)

// Runtime policy check:
CONSENSUS_DOMAINS = ["Z00Z/RID", "Z00Z/VIEW", ..., "Z00Z/TXDIGEST"]
for domain in CONSENSUS_DOMAINS:
    wallet_fn = lookup_hash_function_for_domain(domain)
    assert wallet_fn == HashFunction::Poseidon2,
        "Domain {} uses wrong hash function", domain
```

**💡 Почему важно:** Это «сторожевой» тест. Любой рефакторинг, случайно перенёсший консенсусный домен на Blake2b, сломает тест до попадания в прод.

**📋 Чеклист реализации:**
- [x] Использовать `crates/z00z_crypto/tests/test_hash_policy.rs`
- [x] Создать в `z00z_crypto::hash` публичный enum `HashFunction { Poseidon2, Blake2b }` и публичную функцию `pub fn hash_fn_for_domain(domain: &[u8]) -> HashFunction` — возвращает `Poseidon2` для всех `Z00Z/*`-доменов и `Blake2b` для `WALLET/*`
- [x] Написать тест `fn test_hash_policy_enforcement()` — `#[test]`
  - [x] Создать `const CONSENSUS_DOMAINS: &[&[u8]] = &[b"Z00Z/RID", b"Z00Z/VIEW", b"Z00Z/DH", b"Z00Z/TAG", b"Z00Z/TAG16", b"Z00Z/ASSET", b"Z00Z/LEAFAD", b"Z00Z/LEAFHASH", b"Z00Z/PACKKEY", b"Z00Z/PACKNONCE", b"Z00Z/PACKSTR", b"Z00Z/PACKTAG", b"Z00Z/XOFBLK", b"Z00Z/TXDIGEST", b"Z00Z/R"];`
  - [x] Цикл `for domain in CONSENSUS_DOMAINS`:
    - [x] `let fn_type = hash_fn_for_domain(domain);`
    - [x] `assert!(matches!(fn_type, HashFunction::Poseidon2), "Domain {:?} must use Poseidon2, got Blake2b", domain);`
  - [x] Проверить `WALLET/*` домены → `HashFunction::Blake2b`
- [x] **CI grep-тест:** Добавить в `.github/workflows/ci.yml` шаг `run: grep -rn "blake2b_hash" crates/ | grep '"Z00Z/' | wc -l | xargs -I{} test {} -eq 0` с ошибкой `Blake2b used for consensus domain`
- [x] Запустить `cargo test -p z00z_crypto test_hash_policy_enforcement`

---

## Phase 3. Hash-to-Scalar H2Scalar

### 3.1 H2Scalar: Хэш → Валидный Ненулевой Скаляр

**🎯 Что тестируем:** `h2scalar_zk(domain, data)` возвращает ненулевой скаляр в `[0, ℓ)` для любого входа.

**🔬 Как тестируем:**
```
for _ in 0..10_000:
    data = random_bytes_32()
    scalar = h2scalar_zk(b"Z00Z/VIEW", &[&data])

    assert scalar != Scalar::ZERO

    // Must be canonical
    bytes = scalar.to_bytes()
    assert Scalar::from_canonical_bytes(bytes) == Some(scalar)
```

**💡 Почему важно:** `view_sk = 0 → dh = 0 * R = identity` → все монеты любого получателя становятся публичными.

**📋 Чеклист реализации:**
- [x] Создать файл `crates/z00z_crypto/tests/test_h2scalar.rs`
- [x] Зарегистрировать `[[test]] name = "test_h2scalar" path = "tests/test_h2scalar.rs"` в `Cargo.toml` `z00z_crypto`
- [x] Добавить импорты:
  ```rust
  use z00z_crypto::hash::h2scalar_zk;
  use curve25519_dalek::scalar::Scalar;
  use rand::rngs::OsRng;
  use rand::RngCore;
  ```
- [x] Проверить, что функция `h2scalar_zk(domain: &[u8], inputs: &[&[u8]]) -> Scalar` существует в `z00z_crypto::hash`; если нет — создать: `pub fn h2scalar_zk(domain: &[u8], inputs: &[&[u8]]) -> Scalar { let h = poseidon2_hash(domain, inputs); Scalar::from_bytes_mod_order(h) }`
- [x] Написать тест `fn test_h2scalar_nonzero_canonical()` — `#[test]`
  - [x] В цикле `for _ in 0..10_000`:
    - [x] Сгенерировать `data: [u8; 32]` через `OsRng`
    - [x] `let s = h2scalar_zk(b"Z00Z/VIEW", &[&data]);`
    - [x] `assert_ne!(s, Scalar::ZERO, "h2scalar returned zero scalar");`
    - [x] `let bytes = s.to_bytes();`
    - [x] `assert!(Scalar::from_canonical_bytes(bytes).is_some(), "h2scalar not canonical");`
- [x] Запустить `cargo test -p z00z_crypto test_h2scalar_nonzero_canonical`

---

### 3.2 H2Scalar: Domain Separation

**🎯 Что тестируем:** Разные домены дают независимые ключи.

**🔬 Как тестируем:**
```
receiver_secret = [0x42u8; 32]

view_sk     = h2scalar_zk(b"Z00Z/VIEW",     &[&receiver_secret])
identity_sk = h2scalar_zk(b"Z00Z/IDENTITY", &[&receiver_secret])
r_hedged    = h2scalar_zk(b"Z00Z/R",        &[&receiver_secret])

assert view_sk != identity_sk
assert view_sk != r_hedged
assert identity_sk != r_hedged
```

**📋 Чеклист реализации:**
- [x] Использовать `crates/z00z_crypto/tests/test_h2scalar.rs`
- [x] Написать тест `fn test_h2scalar_domain_separation()` — `#[test]`
  - [x] `let secret = [0x42u8; 32];`
  - [x] `let view_sk = h2scalar_zk(b"Z00Z/VIEW", &[&secret]);`
  - [x] `let ident_sk = h2scalar_zk(b"Z00Z/IDENTITY", &[&secret]);`
  - [x] `let r_scalar = h2scalar_zk(b"Z00Z/R", &[&secret]);`
  - [x] `assert_ne!(view_sk, ident_sk, "VIEW and IDENTITY scalars must differ");`
  - [x] `assert_ne!(view_sk, r_scalar, "VIEW and R scalars must differ");`
  - [x] `assert_ne!(ident_sk, r_scalar, "IDENTITY and R scalars must differ");`
  - [x] Повторить для `secret = [0x00; 32]` и `[0xFF; 32]`
- [x] Запустить `cargo test -p z00z_crypto test_h2scalar_domain_separation`

---

### 3.3 Golden Vector: view_sk для Тестового Вектора «Alice»

**🎯 Что тестируем:** Для фиксированного `receiver_secret = [0x11u8; 32]` значение `view_sk` побитово совпадает с эталоном из референсной реализации.

**🔬 Как тестируем:**
```
receiver_secret = [0x11u8; 32]
expected_view_sk_bytes = KNOWN_VIEW_SK_ALICE_BYTES  // из test_golden_recv_keys.rs

view_sk = h2scalar_zk(b"Z00Z/VIEW", &[&receiver_secret])
assert view_sk.to_bytes() == expected_view_sk_bytes
```

**Векторы для:**
- `receiver_secret = [0x00; 32]` — граничный, нулевой
- `receiver_secret = [0xFF; 32]` — граничный, максимальный
- `receiver_secret = [0x11; 32]` — Alice (стандартный тест)
- `receiver_secret = [0x22; 32]` — Bob

**💡 Почему важно:** Единственный способ убедиться, что wallet-Rust и proof-engine (другой язык/платформа) вычисляют ровно одни и те же производные ключи. Одна несовпадающая цифра — кошелёк не может тратить монеты.

**📋 Чеклист реализации:**
- [x] Использовать `crates/z00z_crypto/tests/test_h2scalar.rs`
- [x] Создать файл `crates/z00z_wallets/tests/test_golden_recv_keys.rs` (здесь хранятся golden vectors с 5 полями)
- [x] **Фаза 1: Вычислить эталонные значения:** Написать `examples/compute_golden.rs` в `z00z_crypto`, который:
  - [x] Вычисляет `h2scalar_zk(b"Z00Z/VIEW", &[&[0x00u8; 32]])`, `[0x11; 32]`, `[0x22; 32]`, `[0xFF; 32]`
  - [x] Выводит hex-строки в stdout через `println!("{}", hex::encode(s.to_bytes()))`
  - [x] Зафиксировать полученные значения в тесте в константах `ALICE_VIEW_SK_BYTES`, `BOB_VIEW_SK_BYTES` и т.д.
- [x] **Фаза 2: Написать тест** `fn test_h2scalar_golden_vectors()` — `#[test]`
  ```rust
  const ALICE_SECRET: [u8; 32] = [0x11; 32];
  const ALICE_VIEW_SK: [u8; 32] = /* hex bytes from Phase 1 */;
  ```
  - [x] `let s = h2scalar_zk(b"Z00Z/VIEW", &[&ALICE_SECRET]);`
  - [x] `assert_eq!(s.to_bytes(), ALICE_VIEW_SK, "Alice view_sk golden mismatch");`
  - [x] Аналогично для `[0x00; 32]`, `[0x22; 32]`, `[0xFF; 32]`
- [x] Запустить `cargo test -p z00z_crypto test_h2scalar_golden`

---

### 3.4 H2Scalar: Статистическая Равномерность (Spot Check)

**🎯 Что тестируем:** 10,000 выходов не сосредоточены в одном диапазоне (нет явного смещения).

**🔬 Как тестируем:**
```
first_bytes = []
for i in 0..10_000:
    scalar = h2scalar_zk(b"Z00Z/TEST", &[&i.to_le_bytes()])
    first_bytes.push(scalar.to_bytes()[0])

// ~uniform over [0, 255]; each bucket count ≈ 10000/256 ≈ 39
histogram = count_by_value(first_bytes)
for (_, count) in histogram:
    assert abs(count - 39) < 20   // 3-sigma tolerance
```

**📋 Чеклист реализации:**
- [x] Использовать `crates/z00z_crypto/tests/test_h2scalar.rs`
- [x] Написать тест `fn test_h2scalar_distribution()` — `#[test]` + `#[ignore]` (медленный, запуск через `cargo test -- --ignored`)
  - [x] `let mut histogram = [0u32; 256];`
  - [x] Цикл `for i in 0u64..10_000`:
    - [x] `let s = h2scalar_zk(b"Z00Z/TEST", &[&i.to_le_bytes()]);`
    - [x] `histogram[s.to_bytes()[0] as usize] += 1;`
  - [x] `let expected: u32 = 10_000 / 256;`
  - [x] `for (bucket, &count) in histogram.iter().enumerate() { assert!((count as i32 - expected as i32).abs() < 20, "bucket {} count {} deviates from expected {}", bucket, count, expected); }`
  - [x] Проверить толеранс: `σ = sqrt(p*(1-p)*N)` где `p=1/256`, `N=10_000` → `σ ≈ 6.2`, `3σ ≈ 18.6` — значение 20 правильно
- [x] Запустить `cargo test -p z00z_crypto test_h2scalar_distribution -- --ignored`

---

## Phase 4. Pedersen Commitments

### 4.1 Commit + Open + Verify Round-Trip

**🎯 Что тестируем:** Открытие (value, blinding) верифицируется для только что созданного commitment.

**🔬 Как тестируем:**
```
for value in [0, 1, 100, 12345, u64::MAX]:
    blinding = Scalar::random()
    C = commit_value(value, &blinding)
    assert verify_opening(&C, value, &blinding) == true

    // Wrong value MUST fail
    assert verify_opening(&C, value + 1, &blinding) == false

    // Wrong blinding MUST fail
    wrong_blinding = Scalar::random()
    assert verify_opening(&C, value, &wrong_blinding) == false
```

**💡 Почему важно:** Базовое свойство корректности. Если `verify_opening` принимает неправильное открытие — блокчейн принял бы фальсифицированный баланс.

**📋 Чеклист реализации:**
- [x] Создать файл `crates/z00z_crypto/tests/test_pedersen.rs`
- [x] Зарегистрировать `[[test]] name = "test_pedersen" path = "tests/test_pedersen.rs"` в `Cargo.toml` `z00z_crypto`
- [x] Добавить импорты:
  ```rust
  use z00z_crypto::commitment::{commit_value, verify_opening};
  use curve25519_dalek::scalar::Scalar;
  use rand::rngs::OsRng;
  ```
- [x] Проверить, что `commit_value(value: u64, blinding: &Scalar) -> RistrettoPoint` и `verify_opening(c: &RistrettoPoint, value: u64, blinding: &Scalar) -> bool` существуют в `z00z_crypto::commitment`
- [x] Написать тест `fn test_pedersen_roundtrip()` — `#[test]`
  - [x] `for value in [0u64, 1, 100, 12345, u64::MAX]`:
    - [x] `let blinding = Scalar::random(&mut OsRng);`
    - [x] `let c = commit_value(value, &blinding);`
    - [x] `assert!(verify_opening(&c, value, &blinding), "correct opening rejected for value={}", value);`
    - [x] `assert!(!verify_opening(&c, value.wrapping_add(1), &blinding), "wrong value accepted");`
    - [x] `let wrong_r = Scalar::random(&mut OsRng);`
    - [x] `assert!(!verify_opening(&c, value, &wrong_r), "wrong blinding accepted");`
- [x] Запустить `cargo test -p z00z_crypto test_pedersen_roundtrip`

---

### 4.2 Гомоморфизм: C(v₁) + C(v₂) = C(v₁ + v₂)

**🎯 Что тестируем:** Pedersen commitments поддерживают гомоморфное сложение — основа balance proofs.

**🔬 Как тестируем:**
```
v1 = 100u64, v2 = 200u64
r1 = Scalar::random(), r2 = Scalar::random()

C1 = commit_value(v1, &r1)
C2 = commit_value(v2, &r2)
C_sum = C1 + C2                          // Точечное сложение

assert verify_opening(&C_sum, v1 + v2, &(r1 + r2)) == true
```

**Пример для balance proof:**
```
// Transaction: input 300 → output1 100 + output2 200
C_in   = commit_value(300, &r_in)
C_out1 = commit_value(100, &r_out1)
C_out2 = commit_value(200, &r_out2)

r_excess = r_in - r_out1 - r_out2
excess   = C_in - C_out1 - C_out2
assert verify_opening(&excess, 0, &r_excess) == true   // balanced
```

**💡 Почему важно:** Без гомоморфного свойства невозможна криптографическая проверка балансов без раскрытия сумм.

**📋 Чеклист реализации:**
- [x] Использовать `crates/z00z_crypto/tests/test_pedersen.rs`
- [x] Написать тест `fn test_pedersen_homomorphism()` — `#[test]`
  - [x] `let (v1, v2) = (100u64, 200u64);`
  - [x] `let r1 = Scalar::random(&mut OsRng); let r2 = Scalar::random(&mut OsRng);`
  - [x] `let c1 = commit_value(v1, &r1); let c2 = commit_value(v2, &r2);`
  - [x] `let c_sum = c1 + c2;`
  - [x] `assert!(verify_opening(&c_sum, v1 + v2, &(r1 + r2)), "homomorphism violated");`
- [x] Написать тест `fn test_pedersen_balance_simulation()` — `#[test]`
  - [x] `let (r_in, r_out1, r_out2) = (Scalar::random(&mut OsRng), Scalar::random(&mut OsRng), Scalar::random(&mut OsRng));`
  - [x] `let (c_in, c_out1, c_out2) = (commit_value(300, &r_in), commit_value(100, &r_out1), commit_value(200, &r_out2));`
  - [x] `let r_excess = r_in - r_out1 - r_out2;`
  - [x] `let c_excess = c_in - c_out1 - c_out2;`
  - [x] `assert!(verify_opening(&c_excess, 0, &r_excess), "balance proof failed");`
- [x] Запустить `cargo test -p z00z_crypto test_pedersen_homomorphism test_pedersen_balance_simulation`

---

### 4.3 Binding: Разные Blindings → Разные Commitments

**🎯 Что тестируем:** Нельзя случайно повторно использовать blinding и получить тот же commitment.

**🔬 Как тестируем:**
```
for _ in 0..10_000:
    v = random_u64()
    r1 = Scalar::random()
    r2 = Scalar::random()
    C1 = commit_value(v, &r1)
    C2 = commit_value(v, &r2)
    assert C1 != C2   // Different blindings → different commitments
```

**📋 Чеклист реализации:**
- [x] Использовать `crates/z00z_crypto/tests/test_pedersen.rs`
- [x] Написать тест `fn test_pedersen_diff_blindings()` — `#[test]`
  - [x] В цикле `for _ in 0..10_000`:
    - [x] `let v = OsRng.next_u64();`
    - [x] `let r1 = Scalar::random(&mut OsRng); let r2 = Scalar::random(&mut OsRng);`
    - [x] `let c1 = commit_value(v, &r1); let c2 = commit_value(v, &r2);`
    - [x] `assert_ne!(c1, c2, "same value different blindings must yield different commitments");`
- [x] Запустить `cargo test -p z00z_crypto test_pedersen_diff_blindings`

---

### 4.4 Generators G и H: Независимость

**🎯 Что тестируем:** H ≠ G, H ≠ identity, H детерминирован.

**🔬 Как тестируем:**
```
H = COMMITMENT_FACTORY.H_base()
G = RISTRETTO_BASEPOINT_POINT

assert H != G
assert !H.is_identity()
H2 = COMMITMENT_FACTORY.H_base()
assert H == H2   // deterministic across calls
```

**📋 Чеклист реализации:**
- [x] Использовать `crates/z00z_crypto/tests/test_pedersen.rs`
- [x] Найти в `z00z_crypto::commitment` способ получения генератора `H` — либо `COMMITMENT_H_BASE: Lazy<RistrettoPoint>`, либо метод `CommitmentFactory::H_base() -> RistrettoPoint`. Если нет — создать `once_cell::sync::Lazy` инициализацию: `static H_BASE: Lazy<RistrettoPoint> = Lazy::new(|| hash_to_ristretto_point(b"Z00Z/H_GENR"));`
- [x] Написать тест `fn test_generators_independence()` — `#[test]`
  - [x] `use curve25519_dalek::constants::RISTRETTO_BASEPOINT_POINT as G;`
  - [x] `let H = *H_BASE; // or CommitmentFactory::H_base()`
  - [x] `assert_ne!(H, G, "H must differ from G");`
  - [x] `assert!(!H.is_identity(), "H must not be identity");`
  - [x] `let H2 = *H_BASE;`
  - [x] `assert_eq!(H, H2, "H must be deterministic across calls");`
- [x] Запустить `cargo test -p z00z_crypto test_generators_independence`

---

## Phase 5. Range Proofs / Bulletproofs+

### 5.1 Generate + Verify: Корректный Диапазон

**🎯 Что тестируем:** Range proof для любого `v ∈ [0, 2^64)` проходит верификацию.

**🔬 Как тестируем:**
```
test_values = [0, 1, 100, 12345, 2^32, u64::MAX - 1, u64::MAX]

for value in test_values:
    blinding = Scalar::random()
    commitment = commit_value(value, &blinding)
    proof = generate_range_proof(value, &blinding).unwrap()
    assert verify_range_proof(&commitment, &proof).unwrap() == true
```

**📋 Чеклист реализации:**
- [x] Создать файл `crates/z00z_crypto/tests/test_bulletproofs.rs`
- [x] Зарегистрировать `[[test]] name = "test_bulletproofs" path = "tests/test_bulletproofs.rs"` в `Cargo.toml` `z00z_crypto`
- [x] Добавить импорты:
  ```rust
  use z00z_crypto::range_proof::{generate_range_proof, verify_range_proof};
  use z00z_crypto::commitment::commit_value;
  use curve25519_dalek::scalar::Scalar;
  use rand::rngs::OsRng;
  ```
- [x] Проверить, что `generate_range_proof(value: u64, blinding: &Scalar) -> Result<Vec<u8>, E>` и `verify_range_proof(commitment: &RistrettoPoint, proof: &[u8]) -> Result<bool, E>` существуют; если нет — создать в `crates/z00z_crypto/src/range_proof.rs` wrapping Tari `BulletproofsPlusService`
- [x] Написать тест `fn test_range_proof_valid_values()` — `#[test]`
  - [x] `for value in [0u64, 1, 100, 12345, u32::MAX as u64, u64::MAX - 1, u64::MAX]`:
    - [x] `let blinding = Scalar::random(&mut OsRng);`
    - [x] `let commitment = commit_value(value, &blinding);`
    - [x] `let proof = generate_range_proof(value, &blinding).expect("proof generation failed");`
    - [x] `let ok = verify_range_proof(&commitment, &proof).expect("verify failed");`
    - [x] `assert!(ok, "valid range proof rejected for value={}", value);`
- [x] Запустить `cargo test -p z00z_crypto test_range_proof_valid_values`

---

### 5.2 Tamper Detection: Неправильный Commitment Отклоняется

**🎯 Что тестируем:** Proof, сгенерированный для одного commitment, не верифицируется с другим.

**🔬 Как тестируем:**
```
value = 1000u64
blinding = Scalar::random()
commitment_real = commit_value(value, &blinding)
proof = generate_range_proof(value, &blinding).unwrap()

// Верный commitment → OK
assert verify_range_proof(&commitment_real, &proof).unwrap() == true

// Подменённый commitment → FAIL
wrong_commitment = commit_value(2000, &Scalar::random())
assert verify_range_proof(&wrong_commitment, &proof).unwrap() == false

// Случайная точка → FAIL
random_commitment = random_ristretto_point()
result = verify_range_proof(&random_commitment, &proof)
assert result.is_err() || result.unwrap() == false
```

**💡 Почему важно:** Без этого злоумышленник мог бы прикрепить корректный proof к commitment другой суммы (inflation attack).

**📋 Чеклист реализации:**
- [x] Использовать `crates/z00z_crypto/tests/test_bulletproofs.rs`
- [x] Написать тест `fn test_range_proof_wrong_commitment_rejected()` — `#[test]`
  - [x] `let value = 1000u64;`
  - [x] `let blinding = Scalar::random(&mut OsRng);`
  - [x] `let commitment_real = commit_value(value, &blinding);`
  - [x] `let proof = generate_range_proof(value, &blinding).unwrap();`
  - [x] Верный commitment: `assert!(verify_range_proof(&commitment_real, &proof).unwrap());`
  - [x] Подменённый commitment — `let wrong = commit_value(2000, &Scalar::random(&mut OsRng));`
  - [x] `assert!(!verify_range_proof(&wrong, &proof).unwrap(), "tampered commitment must fail");`
  - [x] Случайная точка — `let rand_pt = Scalar::random(&mut OsRng) * RISTRETTO_BASEPOINT_POINT;`
  - [x] `let result = verify_range_proof(&rand_pt, &proof); assert!(result.is_err() || !result.unwrap());`
- [x] Запустить `cargo test -p z00z_crypto test_range_proof_wrong_commitment_rejected`

---

### 5.3 Batch Verification

**🎯 Что тестируем:** `verify_range_proofs_batch` верифицирует 100 корректных proofs и детектирует хотя бы один испорченный.

**🔬 Как тестируем:**
```
entries = []
for i in 0..100:
    v = (i + 1) as u64 * 100
    r = Scalar::random()
    entries.push((commit_value(v, &r), generate_range_proof(v, &r).unwrap()))

// All 100 pass
results = verify_range_proofs_batch(&entries).unwrap()
assert results.iter().all(|&ok| ok)

// Corrupt proof #42
entries[42].1[0] ^= 0x01
results_bad = verify_range_proofs_batch(&entries).unwrap()
assert !results_bad[42]
```

**📋 Чеклист реализации:**
- [x] Использовать `crates/z00z_crypto/tests/test_bulletproofs.rs`
- [x] Проверить, что `verify_range_proofs_batch(entries: &[(RistrettoPoint, Vec<u8>)]) -> Result<Vec<bool>, E>` есть в `z00z_crypto::range_proof`
- [x] Написать тест `fn test_batch_verify_100()` — `#[test]`
  - [x] `use z00z_crypto::commitment::commit_value;`
  - [x] `use z00z_crypto::range_proof::{generate_range_proof, verify_range_proofs_batch};`
  - [x] `use curve25519_dalek::ristretto::RistrettoPoint;`
  - [x] `use curve25519_dalek::scalar::Scalar;`
  - [x] `use rand::rngs::OsRng;`
  - [x] `let mut entries: Vec<(RistrettoPoint, Vec<u8>)> = Vec::new();`
  - [x] В цикле `for i in 0..100u64`:
    - [x] `let v = (i + 1) * 100;`
    - [x] `let r = Scalar::random(&mut OsRng);`
    - [x] `let c = commit_value(v, &r);`
    - [x] `let proof = generate_range_proof(v, &r).unwrap();`
    - [x] `entries.push((c, proof));`
  - [x] `let results = verify_range_proofs_batch(&entries).unwrap();`
  - [x] `assert!(results.iter().all(|&ok| ok), "all 100 proofs must pass");`
  - [x] `entries[42].1[0] ^= 0x01;  // corrupt proof #42`
  - [x] `let results_bad = verify_range_proofs_batch(&entries).unwrap();`
  - [x] `assert!(!results_bad[42], "corrupted proof #42 must fail");`
- [x] Запустить `cargo test -p z00z_crypto test_batch_verify_100`

---

### 5.4 Performance Sanity

**🎯 Что тестируем:** Batch verification 100 proofs ≤ 100ms.

**🔬 Как тестируем:**
```
start = Instant::now()
verify_range_proofs_batch(&batch_of_100).unwrap()
assert start.elapsed() < Duration::from_millis(100)
```

**📋 Чеклист реализации:**
- [x] Использовать `crates/z00z_crypto/tests/test_bulletproofs.rs`
- [x] Написать тест `fn test_batch_verify_perf_100ms()` — `#[test]` + `#[ignore]` (медленный тест)
  - [x] `use std::time::Instant;`
  - [x] Построить `batch_of_100` аналогично тесту 5.3 (100 пар commitment + proof)
  - [x] `let start = Instant::now();`
  - [x] `verify_range_proofs_batch(&batch_of_100).expect("batch verify failed");`
  - [x] `let ms = start.elapsed().as_millis();`
  - [x] `assert!(ms < 100, "batch of 100 took {}ms, expected <100ms", ms);`
  - [x] Пометить `#[ignore]` чтобы не блокировать CI на медленных машинах; включить в release-gate через `cargo test -- --ignored`
- [x] Запустить `cargo test -p z00z_crypto test_batch_verify_perf_100ms -- --ignored`

---

## Phase 6. ECDH Stealth-Address Protocol

### 6.1 Shared Secret Equality: dh(sender) == dh(receiver)

**🎯 Что тестируем:** Алгебраическое свойство `r * view_pk == view_sk * R_pub` корректно для любых ключей.

**🔬 Как тестируем:**
```
for _ in 0..1000:
    receiver_secret = random_bytes_32()
    view_sk = h2scalar_zk(b"Z00Z/VIEW", &[&receiver_secret])
    view_pk = &view_sk * G

    sender_result = sender_derive_dh(&view_pk).unwrap()
    dh_sender = sender_result.dh

    dh_receiver = receiver_derive_dh(&view_sk, &sender_result.R_pub).unwrap()

    assert dh_sender == dh_receiver, "ECDH mismatch!"
    assert !dh_sender.is_identity()
```

**💡 Почему важно:** Центральное свойство stealth-протокола. Нарушение — ни один получатель не найдёт свои монеты.

**📋 Чеклист реализации:**
- [x] Создать файл `crates/z00z_wallets/tests/test_ecdh.rs`
- [x] Зарегистрировать `[[test]] name = "test_ecdh" path = "tests/test_ecdh.rs"` в `Cargo.toml` `z00z_wallets`
- [x] Добавить импорты:
  ```rust
  use z00z_crypto::hash::h2scalar_zk;
  use z00z_wallets::ecdh::{sender_derive_dh, receiver_derive_dh};
  use curve25519_dalek::constants::RISTRETTO_BASEPOINT_POINT as G;
  use rand::rngs::OsRng;
  use rand::RngCore;
  ```
- [x] Проверить, что `sender_derive_dh(view_pk: &RistrettoPoint) -> Result<SenderDhResult, E>` и `receiver_derive_dh(view_sk: &Scalar, R_pub: &RistrettoPoint) -> Result<RistrettoPoint, E>` существуют в `z00z_wallets::ecdh`; `SenderDhResult { r: Scalar, R_pub: RistrettoPoint, dh: RistrettoPoint }`
- [x] Написать тест `fn test_ecdh_shared_secret_equality()` — `#[test]`
  - [x] В цикле `for _ in 0..1000`:
    - [x] Сгенерировать `receiver_secret: [u8; 32]` через `OsRng`
    - [x] `let view_sk = h2scalar_zk(b"Z00Z/VIEW", &[&receiver_secret]);`
    - [x] `let view_pk = view_sk * G;`
    - [x] `let sender = sender_derive_dh(&view_pk).unwrap();`
    - [x] `let dh_receiver = receiver_derive_dh(&view_sk, &sender.R_pub).unwrap();`
    - [x] `assert_eq!(sender.dh, dh_receiver, "ECDH mismatch");`
    - [x] `assert!(!sender.dh.is_identity(), "DH result must not be identity");`
- [x] Запустить `cargo test -p z00z_wallets test_ecdh_shared_secret_equality`

---

### 6.2 Different r → Разные DH и R_pub

**🎯 Что тестируем:** Каждый вызов `sender_derive_dh` производит уникальные `r`, `R_pub`, `dh`.

**🔬 Как тестируем:**
```
view_pk = &h2scalar_zk(b"Z00Z/VIEW", &[&[0x42u8; 32]]) * G

seen_r  = HashSet::new()
seen_R  = HashSet::new()
seen_dh = HashSet::new()

for _ in 0..1000:
    result = sender_derive_dh(&view_pk).unwrap()
    assert seen_r.insert(result.r.to_bytes()),  "r repeated!"
    assert seen_R.insert(result.R_pub.compress()), "R_pub repeated!"
    assert seen_dh.insert(result.dh.compress()),   "dh repeated!"
```

**💡 Почему важно:** R_pub публичен в UTXO. Повтор R_pub мгновенно связывает два outputs к одному получателю → нарушение unlinkability.

**📋 Чеклист реализации:**
- [x] Использовать `crates/z00z_wallets/tests/test_ecdh.rs`
- [x] Написать тест `fn test_ecdh_unique_ephemerals()` — `#[test]`
  - [x] `use std::collections::HashSet;`
  - [x] `let view_pk = h2scalar_zk(b"Z00Z/VIEW", &[&[0x42u8; 32]]) * G;`
  - [x] Создать `seen_r`, `seen_R`, `seen_dh`: `HashSet<[u8; 32]>`
  - [x] Цикл `for _ in 0..1000`:
    - [x] `let res = sender_derive_dh(&view_pk).unwrap();`
    - [x] `assert!(seen_r.insert(res.r.to_bytes()), "r repeated!");`
    - [x] `assert!(seen_R.insert(res.R_pub.compress().to_bytes()), "R_pub repeated!");`
    - [x] `assert!(seen_dh.insert(res.dh.compress().to_bytes()), "dh repeated!");`
- [x] Запустить `cargo test -p z00z_wallets test_ecdh_unique_ephemerals`

---

### 6.3 Изоляция Получателей: Carol Не Видит Монету Bob'а

**🎯 Что тестируем:** Третья сторона (Carol) без `view_sk` Боба не может вычислить `k_dh` и owner_tag для монеты Боба.

**🔬 Как тестируем:**
```
bob_secret  = [0x22u8; 32]
carol_secret = [0x33u8; 32]
bob_view_sk   = h2scalar_zk(b"Z00Z/VIEW", &[&bob_secret])
bob_handle    = poseidon2_hash(b"Z00Z/RID", &[&bob_secret])
bob_view_pk   = &bob_view_sk * G

// Sender sends to Bob
sender_result = sender_derive_dh(&bob_view_pk).unwrap()
k_dh_sender   = derive_k_dh(&sender_result.dh)
bob_owner_tag  = poseidon2_hash(b"Z00Z/TAG", &[&bob_handle, &k_dh_sender])

// Carol tries to compute same owner_tag
carol_view_sk = h2scalar_zk(b"Z00Z/VIEW", &[&carol_secret])
carol_handle  = poseidon2_hash(b"Z00Z/RID", &[&carol_secret])
dh_carol      = receiver_derive_dh(&carol_view_sk, &sender_result.R_pub).unwrap()
k_dh_carol    = derive_k_dh(&dh_carol)
carol_guess   = poseidon2_hash(b"Z00Z/TAG", &[&carol_handle, &k_dh_carol])

assert bob_owner_tag != carol_guess, "Privacy violation!"
```

**📋 Чеклист реализации:**
- [x] Использовать `crates/z00z_wallets/tests/test_ecdh.rs`
- [x] Написать тест `fn test_receiver_isolation()` — `#[test]`
  - [x] Импортировать `use z00z_wallets::kdf::derive_k_dh; use z00z_crypto::hash::poseidon2_hash;`
  - [x] Создать Bob и Carol: секреты `[0x22u8; 32]` и `[0x33u8; 32]` соответственно
  - [x] Вычислить `bob_view_sk`, `bob_handle`, `bob_view_pk` через `h2scalar_zk` и `poseidon2_hash`
  - [x] Вызвать `sender_derive_dh(&bob_view_pk).unwrap()` → `sender_res`
  - [x] Вычислить Bob's `k_dh = derive_k_dh(&sender_res.dh)` и `bob_tag = poseidon2_hash(b"Z00Z/TAG", &[&bob_handle, &k_dh])`
  - [x] Вычислить Carol's `carol_view_sk`, `carol_handle`, `carol_dh = receiver_derive_dh(...)`, `carol_k_dh`, `carol_tag`
  - [x] `assert_ne!(bob_tag, carol_tag, "Privacy violation: carol can see bob's coin");`
- [x] Запустить `cargo test -p z00z_wallets test_receiver_isolation`

---

### 6.4 Identity R_pub: Корректное Отклонение

**🎯 Что тестируем:** `receiver_derive_dh` отклоняет `R_pub = identity`.

**🔬 Как тестируем:**
```
view_sk = h2scalar_zk(b"Z00Z/VIEW", &[&[0x42u8; 32]])
identity_R = RistrettoPoint::identity()

assert receiver_derive_dh(&view_sk, &identity_R) == Err(IdentityPoint)
```

**📋 Чеклист реализации:**
- [x] Использовать `crates/z00z_wallets/tests/test_ecdh.rs`
- [x] Проверить, что `receiver_derive_dh` возвращает `Err(WalletError::IdentityPointNotAllowed)` при `R_pub = identity`; если этой проверки нет — добавить: `if R_pub.is_identity() { return Err(WalletError::IdentityPointNotAllowed); }`
- [x] Убедиться, что `WalletError::IdentityPointNotAllowed` есть в `z00z_wallets::error`
- [x] Написать тест `fn test_receiver_rejects_identity_r_pub()` — `#[test]`
  - [x] `let view_sk = h2scalar_zk(b"Z00Z/VIEW", &[&[0x42u8; 32]]);`
  - [x] `let identity_R = RistrettoPoint::identity();`
  - [x] `let result = receiver_derive_dh(&view_sk, &identity_R);`
  - [x] `assert!(result.is_err(), "receiver_derive_dh must reject identity R_pub");`
  - [x] Проверить наличие конкретного варианта ошибки: `assert!(matches!(result, Err(WalletError::IdentityPointNotAllowed)));`
- [x] Запустить `cargo test -p z00z_wallets test_receiver_rejects_identity_r_pub`

---

## Phase 7. Key Derivation Functions

### 7.1 k_dh Determinism

**🎯 Что тестируем:** `derive_k_dh(dh_point)` детерминирован, возвращает 32 байта.

**🔬 Как тестируем:**
```
dh = random_ristretto_point()
k1 = derive_k_dh(&dh)
k2 = derive_k_dh(&dh)
assert k1 == k2
assert k1.len() == 32
```

**📋 Чеклист реализации:**
- [x] Создать файл `crates/z00z_wallets/tests/test_kdf.rs`
- [x] Зарегистрировать `[[test]] name = "test_kdf" path = "tests/test_kdf.rs"` в `crates/z00z_wallets/Cargo.toml`
- [x] Добавить импорты:
  ```rust
  use z00z_wallets::kdf::{derive_k_dh, derive_pack_key, derive_pack_nonce};
  use z00z_crypto::hash::poseidon2_hash;
  use curve25519_dalek::constants::RISTRETTO_BASEPOINT_POINT as G;
  use curve25519_dalek::scalar::Scalar;
  ```
- [x] Проверить, что `derive_k_dh(dh: &RistrettoPoint) -> [u8; 32]` есть в `z00z_wallets::kdf`
- [x] Написать тест `fn test_kdf_k_dh_determinism()` — `#[test]`
  - [x] `let dh_point = Scalar::from_bytes_mod_order([0x42u8; 32]) * G;`
  - [x] `let k1 = derive_k_dh(&dh_point);`
  - [x] `let k2 = derive_k_dh(&dh_point);`
  - [x] `assert_eq!(k1, k2, "derive_k_dh must be deterministic");`
  - [x] `assert_eq!(k1.len(), 32, "k_dh must be 32 bytes");`
  - [x] `assert_ne!(k1, [0u8; 32], "k_dh must not be zero");`
- [x] Запустить `cargo test -p z00z_wallets test_kdf_k_dh_determinism`

---

### 7.2 KDF Chain: k_dh → pack_key → nonce

**🎯 Что тестируем:** Все три ключа в цепочке distincts и детерминированы.

**🔬 Как тестируем:**
```
dh_point  = Scalar::from_bytes_mod_order([0x42; 32]) * G
asset_id  = [0xAA; 32]
serial_id = 42u32
leaf_ad   = [0xBB; 32]
r_pub_b   = [0xCC; 32]

k_dh     = derive_k_dh(&dh_point)
pack_key = derive_pack_key(&k_dh, &asset_id, serial_id)
nonce    = derive_pack_nonce(&leaf_ad, &r_pub_b, &asset_id, serial_id)

assert k_dh != pack_key
assert k_dh != nonce
assert pack_key != nonce

// All deterministic on second call
assert derive_k_dh(&dh_point) == k_dh
assert derive_pack_key(&k_dh, &asset_id, serial_id) == pack_key
```

**📋 Чеклист реализации:**
- [x] Использовать `crates/z00z_wallets/tests/test_kdf.rs`
- [x] Проверить сигнатуры: `derive_pack_key(k_dh: &[u8; 32], asset_id: &[u8; 32], serial_id: u32) -> [u8; 32]` и `derive_pack_nonce(leaf_ad: &[u8; 32], r_pub_b: &[u8; 32], asset_id: &[u8; 32], serial_id: u32) -> [u8; 32]`
- [x] Написать тест `fn test_kdf_chain_distinct()` — `#[test]`
  - [x] `let dh_point = Scalar::from_bytes_mod_order([0x42u8; 32]) * G;`
  - [x] `let asset_id = [0xAAu8; 32]; let serial_id = 42u32;`
  - [x] `let leaf_ad = [0xBBu8; 32]; let r_pub_b = [0xCCu8; 32];`
  - [x] `let k_dh = derive_k_dh(&dh_point);`
  - [x] `let pack_key = derive_pack_key(&k_dh, &asset_id, serial_id);`
  - [x] `let nonce = derive_pack_nonce(&leaf_ad, &r_pub_b, &asset_id, serial_id);`
  - [x] `assert_ne!(k_dh, pack_key, "k_dh and pack_key must differ");`
  - [x] `assert_ne!(k_dh, nonce, "k_dh and nonce must differ");`
  - [x] `assert_ne!(pack_key, nonce, "pack_key and nonce must differ");`
  - [x] `assert_eq!(derive_k_dh(&dh_point), k_dh, "derive_k_dh must be deterministic");`
  - [x] `assert_eq!(derive_pack_key(&k_dh, &asset_id, serial_id), pack_key, "deterministic");`
- [x] Запустить `cargo test -p z00z_wallets test_kdf_chain_distinct`

---

### 7.3 KDF Domain Separation

**🎯 Что тестируем:** Разные домены `"Z00Z/DH"` vs `"Z00Z/PACKKEY"` дают независимые ключи.

**🔬 Как тестируем:**
```
ikm = [0x42; 32]
k_dh_key = poseidon2_hash(b"Z00Z/DH",      &[&ikm])
pack_k   = poseidon2_hash(b"Z00Z/PACKKEY", &[&ikm])
tag_k    = poseidon2_hash(b"Z00Z/TAG",     &[&ikm])

assert k_dh_key != pack_k
assert k_dh_key != tag_k
assert pack_k   != tag_k
```

**📋 Чеклист реализации:**
- [x] Использовать `crates/z00z_wallets/tests/test_kdf.rs`
- [x] Написать тест `fn test_kdf_domain_sep()` — `#[test]`
  - [x] `let ikm = [0x42u8; 32];`
  - [x] `let k_dh_key = poseidon2_hash(b"Z00Z/DH",      &[&ikm[..]]);`
  - [x] `let pack_k   = poseidon2_hash(b"Z00Z/PACKKEY", &[&ikm[..]]);`
  - [x] `let tag_k    = poseidon2_hash(b"Z00Z/TAG",     &[&ikm[..]]);`
  - [x] `assert_ne!(k_dh_key, pack_k,  "Z00Z/DH vs Z00Z/PACKKEY must differ");`
  - [x] `assert_ne!(k_dh_key, tag_k,   "Z00Z/DH vs Z00Z/TAG must differ");`
  - [x] `assert_ne!(pack_k,   tag_k,   "Z00Z/PACKKEY vs Z00Z/TAG must differ");`
  - [x] `assert_ne!(k_dh_key, [0u8; 32], "must not output zero");`
- [x] Запустить `cargo test -p z00z_wallets test_kdf_domain_sep`

---

### 7.4 owner_tag и tag16

**🎯 Что тестируем:** Корректность формул и соответствие golden vector.

**🔬 Как тестируем:**
```
owner_handle = poseidon2_hash(b"Z00Z/RID",   &[&[0x11u8; 32]])
k_dh         = poseidon2_hash(b"Z00Z/DH",   &[&[0x42u8; 32]])
leaf_ad      = poseidon2_hash(b"Z00Z/LEAFAD", &[&[0xBBu8; 32]])

owner_tag = poseidon2_hash(b"Z00Z/TAG", &[&owner_handle, &k_dh])
assert owner_tag != [0u8; 32]

tag16_full = poseidon2_hash(b"Z00Z/TAG16", &[&k_dh, &leaf_ad])
tag16      = u16::from_le_bytes([tag16_full[0], tag16_full[1]])

// Golden vector from test_golden_tag16.rs
assert compute_tag16(&[0x44; 32], &[0x55; 32]) == 0x4de1
```

**📋 Чеклист реализации:**
- [x] Использовать `crates/z00z_wallets/tests/test_kdf.rs`
- [x] Проверить, что `z00z_wallets::kdf` экспортирует `compute_owner_tag(handle: &[u8; 32], k_dh: &[u8; 32]) -> [u8; 32]` и `compute_tag16(k_dh: &[u8; 32], leaf_ad: &[u8; 32]) -> u16`
- [x] Написать тест `fn test_kdf_owner_tag_tag16()` — `#[test]`
  - [x] `let owner_handle = poseidon2_hash(b"Z00Z/RID",    &[&[0x11u8; 32][..]]);`
  - [x] `let k_dh         = poseidon2_hash(b"Z00Z/DH",     &[&[0x42u8; 32][..]]);`
  - [x] `let leaf_ad      = poseidon2_hash(b"Z00Z/LEAFAD", &[&[0xBBu8; 32][..]]);`
  - [x] `let owner_tag = compute_owner_tag(&owner_handle, &k_dh);`
  - [x] `assert_ne!(owner_tag, [0u8; 32], "owner_tag must not be zero");`
  - [x] `let tag16 = compute_tag16(&k_dh, &leaf_ad);`
  - [x] `// Golden vector — значение должно быть зафиксировано после первого запуска`
  - [x] Запустить один раз, записать эталон: `let GOLDEN_TAG16: u16 = <actual_value>;`
  - [x] `assert_eq!(compute_tag16(&[0x44; 32], &[0x55; 32]), GOLDEN_TAG16, "tag16 golden");`
  - [x] `assert_ne!(compute_tag16(&k_dh, &leaf_ad), compute_tag16(&leaf_ad, &k_dh), "order matters");`
- [x] Запустить `cargo test -p z00z_wallets test_kdf_owner_tag_tag16`

---

## Phase 8. ZkPack_v1 AEAD

### 8.1 Encrypt/Decrypt Round-Trip

**🎯 Что тестируем:** Расшифровка возвращает оригинальный plaintext при правильных параметрах.

**🔬 Как тестируем:**
```
k_dh      = [0x42; 32]
leaf_ad   = [0xAA; 32]
r_pub     = [0x01; 32]
asset_id  = [0x02; 32]
serial_id = 1u32
plaintext = b"v=1000|s_out=deadbeef..."

enc = ZkPackV1::encrypt(&k_dh, &leaf_ad, &r_pub, &asset_id, serial_id, plaintext)
assert enc.version == 1
assert enc.ciphertext.len() == plaintext.len()  // length-preserving
assert enc.ciphertext != plaintext               // actually encrypts

dec = ZkPackV1::decrypt(&k_dh, &leaf_ad, &r_pub, &asset_id, serial_id, &enc)
assert dec == Some(plaintext.to_vec())
```

**📋 Чеклист реализации:**
- [x] Создать файл `crates/z00z_wallets/tests/test_zkpack.rs`
- [x] Зарегистрировать `[[test]] name = "test_zkpack" path = "tests/test_zkpack.rs"` в `crates/z00z_wallets/Cargo.toml`
- [x] Добавить импорты:
  ```rust
  use z00z_wallets::zkpack::{ZkPackV1, ZkPackEncrypted};
  ```
- [x] Проверить, что `ZkPackV1::encrypt(k_dh: &[u8; 32], leaf_ad: &[u8; 32], r_pub: &[u8; 32], asset_id: &[u8; 32], serial_id: u32, plaintext: &[u8]) -> ZkPackEncrypted` есть в `z00z_wallets::zkpack`
- [x] Проверить, что `ZkPackV1::decrypt(..., enc: &ZkPackEncrypted) -> Option<Vec<u8>>` есть
- [x] Проверить, что `ZkPackEncrypted` имеет поля `version: u8`, `ciphertext: Vec<u8>`, `tag: [u8; 16]`
- [x] Написать тест `fn test_zkpack_roundtrip()` — `#[test]`
  - [x] `let k_dh = [0x42u8; 32]; let leaf_ad = [0xAAu8; 32]; let r_pub = [0x01u8; 32]; let asset_id = [0x02u8; 32]; let serial_id = 1u32;`
  - [x] `let plaintext = b"v=1000|s_out=deadbeef";`
  - [x] `let enc = ZkPackV1::encrypt(&k_dh, &leaf_ad, &r_pub, &asset_id, serial_id, plaintext);`
  - [x] `assert_eq!(enc.version, 1, "version must be 1");`
  - [x] `assert_eq!(enc.ciphertext.len(), plaintext.len(), "length-preserving");`
  - [x] `assert_ne!(enc.ciphertext.as_slice(), plaintext, "must actually encrypt");`
  - [x] `let dec = ZkPackV1::decrypt(&k_dh, &leaf_ad, &r_pub, &asset_id, serial_id, &enc);`
  - [x] `assert_eq!(dec, Some(plaintext.to_vec()), "decryption roundtrip failed");`
- [x] Запустить `cargo test -p z00z_wallets test_zkpack_roundtrip`

---

### 8.2 Authentication: Любой Неверный Параметр → None

**🎯 Что тестируем:** Любой неверный ключ или контекст приводит к `None` при расшифровке.

**🔬 Как тестируем:**
```
enc = ZkPackV1::encrypt(&k_dh, &leaf_ad, &r_pub, &asset_id, serial_id, b"secret")

// Wrong k_dh
assert ZkPackV1::decrypt(&[0xFF; 32], &leaf_ad, &r_pub, &asset_id, serial_id, &enc) == None

// Wrong leaf_ad (AD mismatch — replay prevention)
assert ZkPackV1::decrypt(&k_dh, &[0xBB; 32], &r_pub, &asset_id, serial_id, &enc) == None

// Wrong r_pub
assert ZkPackV1::decrypt(&k_dh, &leaf_ad, &[0xFF; 32], &asset_id, serial_id, &enc) == None

// Wrong asset_id
assert ZkPackV1::decrypt(&k_dh, &leaf_ad, &r_pub, &[0xFF; 32], serial_id, &enc) == None

// Wrong serial_id
assert ZkPackV1::decrypt(&k_dh, &leaf_ad, &r_pub, &asset_id, serial_id + 1, &enc) == None
```

**💡 Почему важно:** Без корректной аутентификации узел-наблюдатель мог бы тестировать `k_dh` кандидатов.

**📋 Чеклист реализации:**
- [x] Использовать `crates/z00z_wallets/tests/test_zkpack.rs`
- [x] Написать тест `fn test_zkpack_wrong_param_none()` — `#[test]`
  - [x] `let enc = ZkPackV1::encrypt(&[0x42; 32], &[0xAAu8; 32], &[0x01u8; 32], &[0x02u8; 32], 1, b"secret");`
  - [x] `assert_eq!(ZkPackV1::decrypt(&[0xFFu8; 32], &[0xAAu8; 32], &[0x01u8; 32], &[0x02u8; 32], 1, &enc), None, "wrong k_dh must give None");`
  - [x] `assert_eq!(ZkPackV1::decrypt(&[0x42u8; 32], &[0xBBu8; 32], &[0x01u8; 32], &[0x02u8; 32], 1, &enc), None, "wrong leaf_ad must give None");`
  - [x] `assert_eq!(ZkPackV1::decrypt(&[0x42u8; 32], &[0xAAu8; 32], &[0xFFu8; 32], &[0x02u8; 32], 1, &enc), None, "wrong r_pub must give None");`
  - [x] `assert_eq!(ZkPackV1::decrypt(&[0x42u8; 32], &[0xAAu8; 32], &[0x01u8; 32], &[0xFFu8; 32], 1, &enc), None, "wrong asset_id must give None");`
  - [x] `assert_eq!(ZkPackV1::decrypt(&[0x42u8; 32], &[0xAAu8; 32], &[0x01u8; 32], &[0x02u8; 32], 2, &enc), None, "wrong serial_id must give None");`
- [x] Запустить `cargo test -p z00z_wallets test_zkpack_wrong_param_none`

---

### 8.3 AD Binding: Нельзя Перенести enc_pack В Другой Лист

**🎯 Что тестируем:** `enc_pack` привязан к конкретному листу через `leaf_ad`; подстановка в другой лист провалится.

**🔬 Как тестируем:**
```
enc_for_leaf_A = ZkPackV1::encrypt(&k_dh, &leaf_ad_A, &r_pub_A, &asset_id, 0, &plaintext)

// Try to decrypt as if it's leaf B (different serial_id)
result = ZkPackV1::decrypt(&k_dh, &leaf_ad_A, &r_pub_A, &asset_id, 1, &enc_for_leaf_A)
assert result == None   // serial_id binding caught it
```

**📋 Чеклист реализации:**
- [x] Использовать `crates/z00z_wallets/tests/test_zkpack.rs`
- [x] Написать тест `fn test_zkpack_ad_binding()` — `#[test]`
  - [x] `let k_dh = [0x42u8; 32]; let asset_id = [0x02u8; 32]; let r_pub_A = [0x01u8; 32];`
  - [x] `let leaf_ad_A = [0xAAu8; 32]; let plaintext = b"leaf-A payload";`
  - [x] `let enc = ZkPackV1::encrypt(&k_dh, &leaf_ad_A, &r_pub_A, &asset_id, 0, plaintext);`
  - [x] `// Попытка с другим serial_id (добавление в другой лист)`
  - [x] `let result = ZkPackV1::decrypt(&k_dh, &leaf_ad_A, &r_pub_A, &asset_id, 1, &enc);`
  - [x] `assert_eq!(result, None, "serial_id binding must prevent replay");`
  - [x] `// Попытка с другим leaf_ad`
  - [x] `let result2 = ZkPackV1::decrypt(&k_dh, &[0xBBu8; 32], &r_pub_A, &asset_id, 0, &enc);`
  - [x] `assert_eq!(result2, None, "leaf_ad binding must prevent cross-leaf replay");`
  - [x] `// Оригинал должен расшифроваться`
  - [x] `assert_eq!(ZkPackV1::decrypt(&k_dh, &leaf_ad_A, &r_pub_A, &asset_id, 0, &enc), Some(plaintext.to_vec()));`
- [x] Запустить `cargo test -p z00z_wallets test_zkpack_ad_binding`

---

### 8.4 Keystream Детерминированность

**🎯 Что тестируем:** Одни и те же (pack_key, nonce) → одинаковый keystream.

**🔬 Как тестируем:**
```
stream1 = generate_keystream(&pack_key, &nonce, 100)
stream2 = generate_keystream(&pack_key, &nonce, 100)
assert stream1 == stream2
```

**📋 Чеклист реализации:**
- [x] Использовать `crates/z00z_wallets/tests/test_zkpack.rs`
- [x] Проверить, что механизм шифрования ZkPack детерминирован (ChaCha20 / XChaCha20); нет источника случайности в crypto слое
- [x] Написать тест `fn test_zkpack_determinism()` — `#[test]`
  - [x] `let k_dh = [0x42u8; 32]; let leaf_ad = [0xAAu8; 32]; let r_pub = [0x01u8; 32]; let asset_id = [0x02u8; 32];`
  - [x] `let plaintext = b"determinism check";`
  - [x] `let enc1 = ZkPackV1::encrypt(&k_dh, &leaf_ad, &r_pub, &asset_id, 0, plaintext);`
  - [x] `let enc2 = ZkPackV1::encrypt(&k_dh, &leaf_ad, &r_pub, &asset_id, 0, plaintext);`
  - [x] `assert_eq!(enc1.ciphertext, enc2.ciphertext, "same inputs must give same ciphertext");`
  - [x] `assert_eq!(enc1.tag, enc2.tag, "same inputs must give same tag");`
- [x] Запустить `cargo test -p z00z_wallets test_zkpack_determinism`

---

### 8.5 Truncation/Extension Detection

**🎯 Что тестируем:** Усечение или расширение ciphertext определяется тегом.

**🔬 Как тестируем:**
```
enc = ZkPackV1::encrypt(&k_dh, &leaf_ad, &r_pub, &asset_id, 0, b"hello world")

// Truncate last byte
enc_trunc = enc with ciphertext[..len-1]
assert ZkPackV1::decrypt(..., &enc_trunc) == None

// Append byte
enc_ext = enc with ciphertext + [0x00]
assert ZkPackV1::decrypt(..., &enc_ext) == None
```

**📋 Чеклист реализации:**
- [x] Использовать `crates/z00z_wallets/tests/test_zkpack.rs`
- [x] Написать тест `fn test_zkpack_truncation_detection()` — `#[test]`
  - [x] `let k_dh = [0x42u8; 32]; let leaf_ad = [0xAAu8; 32]; let r_pub = [0x01u8; 32]; let asset_id = [0x02u8; 32];`
  - [x] `let mut enc = ZkPackV1::encrypt(&k_dh, &leaf_ad, &r_pub, &asset_id, 0, b"hello world");`
  - [x] Обрезать: `let mut enc_trunc = enc.clone(); enc_trunc.ciphertext.pop();`
  - [x] `assert_eq!(ZkPackV1::decrypt(&k_dh, &leaf_ad, &r_pub, &asset_id, 0, &enc_trunc), None, "truncated ct must fail auth");`
  - [x] Расширить: `let mut enc_ext = enc.clone(); enc_ext.ciphertext.push(0x00);`
  - [x] `assert_eq!(ZkPackV1::decrypt(&k_dh, &leaf_ad, &r_pub, &asset_id, 0, &enc_ext), None, "extended ct must fail auth");`
  - [x] Оригинал расшифровывается: `assert!(ZkPackV1::decrypt(&k_dh, &leaf_ad, &r_pub, &asset_id, 0, &enc).is_some());`
- [x] Запустить `cargo test -p z00z_wallets test_zkpack_truncation_detection`

---

## Phase 9. Full E2E Stealth-Address Cycle

### 9.1 Alice Отправляет Монету Bob'у (Полный Цикл)

**🎯 Что тестируем:** Весь путь: генерация ключей → создание output → сканирование → расшифровка coin pack → верификация commitment.

**🔬 Как тестируем (пошагово):**

```
=== SETUP ===
bob_secret    = [0x22u8; 32]
bob_view_sk   = h2scalar_zk(b"Z00Z/VIEW", &[&bob_secret])
bob_view_pk   = &bob_view_sk * G
bob_handle    = poseidon2_hash(b"Z00Z/RID", &[&bob_secret])
bob_card      = ReceiverCard { owner_handle: bob_handle, view_pk: bob_view_pk }

=== ALICE (SENDER) ===
coin_secret = [0xA5u8; 32]
asset_id  = poseidon2_hash(b"Z00Z/ASSET", &[&coin_secret])
serial_id = 1u32
amount    = 1000u64

// 1. ECDH
sender_result = sender_derive_dh(&bob_card.view_pk).unwrap()
R_pub = sender_result.R_pub
R_pub_bytes = R_pub.compress().to_bytes()
k_dh  = derive_k_dh(&sender_result.dh)

// 2. Pedersen commitment
blinding = Scalar::random()
C_amount = commit_value(amount, &blinding)

// 3. Range proof
range_proof = generate_range_proof(amount, &blinding).unwrap()

// 4. owner_tag (from Bob's perspective)
owner_tag = poseidon2_hash(b"Z00Z/TAG", &[&bob_handle, &k_dh])

// 5. leaf_ad
leaf_fields = { r_pub, asset_id, serial_id, owner_tag, C_amount }
leaf_ad = compute_leaf_ad(&leaf_fields)

// 6. Encrypt coin pack
plaintext_pack = CoinPackPlain { value: amount, blinding, s_out: coin_secret }.to_bytes()
enc_pack = ZkPackV1::encrypt(&k_dh, &leaf_ad, &R_pub_bytes, &asset_id, serial_id, &plaintext_pack)

// 7. Publish UTXO leaf
utxo_leaf = UtxoLeaf { asset_id, serial_id, R_pub, owner_tag, C_amount, enc_pack, range_proof, .. }

=== BLOCKCHAIN (public) ===

=== BOB (RECEIVER) ===

// Step 1: Parse and validate R_pub
R_from_leaf = safe_decompress_point(&utxo_leaf.r_pub).unwrap()

// Step 2: Compute ECDH
dh_bob   = receiver_derive_dh(&bob_view_sk, &R_from_leaf).unwrap()
k_dh_bob = derive_k_dh(&dh_bob)

// Step 3: Compute expected owner_tag
exp_tag = poseidon2_hash(b"Z00Z/TAG", &[&bob_handle, &k_dh_bob])

// Step 4: Check ownership (constant-time)
assert ct_eq(exp_tag, utxo_leaf.owner_tag)   // ← "это мои монеты!"

// Step 5: Decrypt coin pack
leaf_ad_check = compute_leaf_ad(&LeafFields::from_leaf(&utxo_leaf))
dec_bytes = ZkPackV1::decrypt(&k_dh_bob, &leaf_ad_check,
    &utxo_leaf.r_pub, &asset_id, serial_id, &utxo_leaf.enc_pack).unwrap()
decrypted = CoinPackPlain::from_bytes(&dec_bytes).unwrap()

// Step 6: Verify commitment
assert decrypted.value == amount
assert verify_opening(&utxo_leaf.C_amount_point(), decrypted.value, &decrypted.blinding)

// Step 7: Verify range proof (optional, validator role)
assert verify_range_proof(&utxo_leaf.C_amount_point(), &utxo_leaf.range_proof).unwrap()

=== FINAL ASSERTIONS ===
assert k_dh == k_dh_bob                          // ECDH shared secret equal
assert exp_tag == utxo_leaf.owner_tag             // Bob finds his coin
assert decrypted.value == 1000                    // Correct amount
assert verify_opening(..) == true                 // Commitment valid
```

**📋 Чеклист реализации:**
- [x] Создать файл `crates/z00z_wallets/tests/test_e2e_stealth.rs`
- [x] Зарегистрировать `[[test]] name = "test_e2e_stealth" path = "tests/test_e2e_stealth.rs"` в `crates/z00z_wallets/Cargo.toml`
- [x] Добавить импорты:
  ```rust
  use z00z_wallets::{
      ecdh::{sender_derive_dh, receiver_derive_dh},
      kdf::{derive_k_dh, compute_owner_tag, compute_leaf_ad},
      zkpack::ZkPackV1,
      types::{ReceiverCard, UtxoLeaf, CoinPackPlain},
  };
  use z00z_crypto::{
      hash::{h2scalar_zk, poseidon2_hash},
      pedersen::{commit_value, verify_opening},
  };
  use curve25519_dalek::{constants::RISTRETTO_BASEPOINT_POINT as G, scalar::Scalar};
  ```
- [x] Проверить, что `ReceiverCard`, `UtxoLeaf`, `CoinPackPlain` существуют в `z00z_wallets::types`; создать, если отсутствуют
- [x] Написать тест `fn test_alice_sends_coin_to_bob()` — `#[test]`
  - [x] `let bob_secret = [0x22u8; 32];`
  - [x] `let bob_view_sk = h2scalar_zk(b"Z00Z/VIEW", &[&bob_secret[..]]);`
  - [x] `let bob_view_pk = bob_view_sk * G;`
  - [x] `let bob_handle = poseidon2_hash(b"Z00Z/RID", &[&bob_secret[..]]);`
  - [x] `let bob_card = ReceiverCard { owner_handle: bob_handle, view_pk: bob_view_pk };`
  - [x] `let asset_id = [0x02u8; 32]; let serial_id = 1u32; let amount = 1000u64;`
  - [x] `let sender = sender_derive_dh(&bob_card.view_pk).unwrap();`
  - [x] `let k_dh = derive_k_dh(&sender.dh);`
  - [x] `let blinding = Scalar::random(&mut rand::rngs::OsRng);`
  - [x] `let commitment = commit_value(amount, &blinding);`
  - [x] `let owner_tag = compute_owner_tag(&bob_handle, &k_dh);`
  - [x] `let r_pub_bytes = sender.R_pub.compress().to_bytes();`
  - [x] `let leaf_ad = compute_leaf_ad(&r_pub_bytes, &asset_id, serial_id, &owner_tag, &commitment.compress().to_bytes());`
  - [x] `let plaintext = CoinPackPlain { value: amount, blinding: blinding.to_bytes(), s_out: [0xDEu8; 32] }.to_bytes();`
  - [x] `let enc = ZkPackV1::encrypt(&k_dh, &leaf_ad, &r_pub_bytes, &asset_id, serial_id, &plaintext);`
  - [x] `// === BOB SCANS ===`
  - [x] `let dh_bob = receiver_derive_dh(&bob_view_sk, &sender.R_pub).unwrap();`
  - [x] `let k_dh_bob = derive_k_dh(&dh_bob);`
  - [x] `assert_eq!(k_dh, k_dh_bob, "ECDH must agree");`
  - [x] `let exp_tag = compute_owner_tag(&bob_handle, &k_dh_bob);`
  - [x] `assert_eq!(exp_tag, owner_tag, "Bob must find his coin");`
  - [x] `let dec = ZkPackV1::decrypt(&k_dh_bob, &leaf_ad, &r_pub_bytes, &asset_id, serial_id, &enc).unwrap();`
  - [x] `let decrypted = CoinPackPlain::from_bytes(&dec).unwrap();`
  - [x] `assert_eq!(decrypted.value, 1000u64, "Amount must match");`
  - [x] `let recov_blinding = Scalar::from_bytes_mod_order(decrypted.blinding);`
  - [x] `assert!(verify_opening(&commitment, amount, &recov_blinding), "Commitment must verify");`
- [x] Запустить `cargo test -p z00z_wallets test_alice_sends_coin_to_bob`

---

### 9.2 Carol Не Находит Монету Боба

**🎯 Что тестируем:** Посторонний получатель (Carol) не находит coin Bob'а — owner_tag не совпадает, расшифровка невозможна.

**Предусловие:** Используется тот же `utxo_leaf` (включая `R_from_leaf`, `leaf_ad`, `enc_pack`, `asset_id`, `serial_id`) из сценария §9.1.

**🔬 Как тестируем:**
```
carol_secret  = [0x33u8; 32]
carol_view_sk = h2scalar_zk(b"Z00Z/VIEW", &[&carol_secret])
carol_handle  = poseidon2_hash(b"Z00Z/RID", &[&carol_secret])

dh_carol   = receiver_derive_dh(&carol_view_sk, &R_from_leaf).unwrap()
k_dh_carol = derive_k_dh(&dh_carol)
carol_tag  = poseidon2_hash(b"Z00Z/TAG", &[&carol_handle, &k_dh_carol])

// owner_tag НЕ совпадает → Carol skips leaf (fast path)
assert carol_tag != utxo_leaf.owner_tag

// Если Carol всё же пробует расшифровать — провал
result = ZkPackV1::decrypt(&k_dh_carol, &leaf_ad, &R_pub_bytes, &asset_id, serial_id, &enc_pack)
assert result == None
```

**📋 Чеклист реализации:**
- [x] Использовать `crates/z00z_wallets/tests/test_e2e_stealth.rs`
- [x] Написать тест `fn test_carol_cannot_scan_bob_coin()` — `#[test]`
  - [x] Создать Bob точно так же, как в 9.1 (seed `[0x22u8; 32]`)
  - [x] Создать Carol: `let carol_secret = [0x33u8; 32];`
  - [x] `let carol_view_sk = h2scalar_zk(b"Z00Z/VIEW", &[&carol_secret[..]]);`
  - [x] `let carol_handle = poseidon2_hash(b"Z00Z/RID", &[&carol_secret[..]]);`
  - [x] `let dh_carol = receiver_derive_dh(&carol_view_sk, &sender.R_pub).unwrap();`
  - [x] `let k_dh_carol = derive_k_dh(&dh_carol);`
  - [x] `let carol_tag = compute_owner_tag(&carol_handle, &k_dh_carol);`
  - [x] `assert_ne!(carol_tag, owner_tag, "Carol must NOT match Bob's owner_tag");`
  - [x] `let result = ZkPackV1::decrypt(&k_dh_carol, &leaf_ad, &r_pub_bytes, &asset_id, serial_id, &enc);`
  - [x] `assert_eq!(result, None, "Carol must not be able to decrypt Bob's enc_pack");`
- [x] Запустить `cargo test -p z00z_wallets test_carol_cannot_scan_bob_coin`

---

### 9.3 tag16 Scan Accelerator

**🎯 Что тестируем:** tag16 позволяет отфильтровать «не наши» листья без AEAD (fast path).

**🔬 Как тестируем:**
```
// Bob вычисляет tag16 для кандидатного листа
k_dh_candidate = derive_k_dh(receiver_derive_dh(&bob_view_sk, &R_pub).unwrap())
leaf_ad_cand   = compute_leaf_ad(&leaf)
tag16_computed = compute_tag16(&k_dh_candidate, &leaf_ad_cand)
tag16_in_leaf  = leaf.tag16

// Alice's leaf: coincides
assert tag16_computed == tag16_in_leaf

// Carol's tag16: differs (with prob 65535/65536)
carol_k_dh = derive_k_dh(receiver_derive_dh(&carol_view_sk, &R_pub).unwrap())
carol_tag16 = compute_tag16(&carol_k_dh, &leaf_ad_cand)
assert carol_tag16 != tag16_in_leaf
```

**📋 Чеклист реализации:**
- [x] Использовать `crates/z00z_wallets/tests/test_e2e_stealth.rs`
- [x] Проверить, что `UtxoLeaf` содержит поле `tag16: u16`; если нет — добавить
- [x] Написать тест `fn test_tag16_scan_accelerator()` — `#[test]`
  - [x] Создать Bob, enc_pack, leaf_ad аналогично 9.1
  - [x] `use z00z_wallets::kdf::compute_tag16;`
  - [x] `let tag16_in_leaf = compute_tag16(&k_dh, &leaf_ad);`
  - [x] `let dh_bob = receiver_derive_dh(&bob_view_sk, &sender.R_pub).unwrap();`
  - [x] `let k_dh_bob = derive_k_dh(&dh_bob);`
  - [x] `let tag16_computed = compute_tag16(&k_dh_bob, &leaf_ad);`
  - [x] `assert_eq!(tag16_computed, tag16_in_leaf, "Bob's tag16 must match leaf's tag16");`
  - [x] `let carol_secret = [0x33u8; 32];`
  - [x] `let carol_view_sk = h2scalar_zk(b"Z00Z/VIEW", &[&carol_secret[..]]);`
  - [x] `let dh_carol = receiver_derive_dh(&carol_view_sk, &sender.R_pub).unwrap();`
  - [x] `let k_dh_carol = derive_k_dh(&dh_carol);`
  - [x] `let carol_tag16 = compute_tag16(&k_dh_carol, &leaf_ad);`
  - [x] `assert_ne!(carol_tag16, tag16_in_leaf, "Carol's tag16 must differ from Bob's");`
- [x] Запустить `cargo test -p z00z_wallets test_tag16_scan_accelerator`

---

## Phase 10. Cross-Implementation Golden Vectors

### 10.1 owner_handle

**🎯 Что тестируем:** `poseidon2_hash("Z00Z/RID", receiver_secret)` совпадает с эталоном из референсной реализации.

**Реализован в:** `crates/z00z_wallets/tests/test_golden_vectors.rs`

```yaml
golden_owner_handle:
  - receiver_secret: [0x22; 32]
    expected: "7c0d1ac488107362997884980f9153c13d2e4a1ddf3d93305152f7a2aca44ba6"
  - receiver_secret: [0x00; 32]
    expected: "9957ced904cba5278e243af3695159d526216e163a6b3e16aa287cdf11269e27"
  - receiver_secret: [0xff; 32]
    expected: "5d9f289632f14bdd1efb66b85d7ddf0a8f91d8976a66f24aaeb4444b5b68c15b"
```

**📋 Чеклист реализации:**
- [x] Создать файл `crates/z00z_wallets/tests/test_golden_vectors.rs`
- [x] Зарегистрировать `[[test]] name = "test_golden_vectors" path = "tests/test_golden_vectors.rs"` в `crates/z00z_wallets/Cargo.toml`
- [x] **Phase 1 — вычислить эталоны:** запустить временный тест, получить значения, зафиксировать как TBD становятся actual в `yaml`
- [x] Написать тест `fn test_golden_owner_handle()` — `#[test]`
  - [x] `use z00z_crypto::hash::poseidon2_hash;`
  - [x] `let secret_22 = [0x22u8; 32]; let secret_00 = [0x00u8; 32]; let secret_ff = [0xFFu8; 32];`
  - [x] `let handle_22 = poseidon2_hash(b"Z00Z/RID", &[&secret_22[..]]);`
  - [x] `assert_eq!(hex::encode(handle_22), "7c0d1ac488107362997884980f9153c13d2e4a1ddf3d93305152f7a2aca44ba6", "handle[0x22;32]");`
  - [x] `// Phase 1: compute and print TBD values`
  - [x] `let handle_00 = poseidon2_hash(b"Z00Z/RID", &[&secret_00[..]]);`
  - [x] `let handle_ff = poseidon2_hash(b"Z00Z/RID", &[&secret_ff[..]]);`
  - [x] `println!("handle_00: {}", hex::encode(handle_00));`
  - [x] `println!("handle_ff: {}", hex::encode(handle_ff));`
  - [x] `// Phase 2: after printing, replace println with assert_eq!(..., "<actual_hex>")`
- [x] Добавить `hex` в `dev-dependencies` `crates/z00z_wallets/Cargo.toml` (уже присутствует в зависимостях проекта)
- [x] Запустить `cargo test -p z00z_wallets test_golden_owner_handle`

---

### 10.2 ReceiverKeys из receiver_secret

**🎯 Что тестируем:** Все пять производных ключей зафиксированы.

**Реализован в:** `crates/z00z_wallets/tests/test_golden_vectors.rs`

```yaml
golden_receiver_keys:
  input: receiver_secret = [0x11; 32]
  outputs:
    owner_handle: "d03bc96d86b2593f8a7473a7e1d0ebcb5a207bdbc566cf64d333ed147b0255b3"
    view_sk:      "b28d87c27acc31449b917569a49bd59cb542bfce35548606016c275e5f6aa209"
    view_pk:      "78965ad9869d5a7829acc7bae82be7173b389ee625b07931c0d01e8d43087442"
    ident_sk:     "5cc0c4412d54d32e2e70b71db00aacf23f723cbe6d636a4997fb795ec1c8ab03"
    ident_pk:     "4898316206f7f1df7045ab8dda817d677350a02f3f169e6c4b946becccbff155"
```

**📋 Чеклист реализации:**
- [x] Использовать `crates/z00z_wallets/tests/test_golden_vectors.rs`
- [x] Проверить, что `z00z_wallets::keys` экспортирует `ReceiverKeys { owner_handle, view_sk, view_pk, ident_sk, ident_pk }` и `ReceiverKeys::from_secret(secret: &[u8; 32]) -> ReceiverKeys`
- [x] Написать тест `fn test_golden_recv_keys()` — `#[test]`
  - [x] `use z00z_wallets::keys::ReceiverKeys;`
  - [x] `let keys = ReceiverKeys::from_secret(&[0x11u8; 32]);`
  - [x] `assert_eq!(hex::encode(keys.owner_handle), "d03bc96d86b2593f8a7473a7e1d0ebcb5a207bdbc566cf64d333ed147b0255b3");`
  - [x] `assert_eq!(hex::encode(keys.view_sk.to_bytes()), "b28d87c27acc31449b917569a49bd59cb542bfce35548606016c275e5f6aa209");`
  - [x] `assert_eq!(hex::encode(keys.view_pk.compress().to_bytes()), "78965ad9869d5a7829acc7bae82be7173b389ee625b07931c0d01e8d43087442");`
  - [x] `assert_eq!(hex::encode(keys.ident_sk.to_bytes()), "5cc0c4412d54d32e2e70b71db00aacf23f723cbe6d636a4997fb795ec1c8ab03");`
  - [x] `assert_eq!(hex::encode(keys.ident_pk.compress().to_bytes()), "4898316206f7f1df7045ab8dda817d677350a02f3f169e6c4b946becccbff155");`
- [x] Запустить `cargo test -p z00z_wallets test_golden_recv_keys`

---

### 10.3 tag16

**🎯 Что тестируем:** `compute_tag16([0x44; 32], [0x55; 32]) == 0x4de1`.

**Реализован в:** `crates/z00z_wallets/tests/test_golden_vectors.rs`

**📋 Чеклист реализации:**
- [x] Номинально тест находится в `test_golden_tag16.rs`, но можно использовать `test_golden_vectors.rs` для единообразия
- [x] Зарегистрировать `[[test]] name = "test_golden_tag16" path = "tests/test_golden_tag16.rs"` в `Cargo.toml` если выбран отдельный файл (N/A, используется единый `test_golden_vectors.rs`)
- [x] Написать тест `fn test_golden_tag16()` — `#[test]`
  - [x] `use z00z_wallets::kdf::compute_tag16;`
  - [x] `const GOLDEN: u16 = 0x4de1;  // зафиксированное значение`
  - [x] `assert_eq!(compute_tag16(&[0x44u8; 32], &[0x55u8; 32]), GOLDEN, "tag16 golden vector");`
  - [x] `// Verify different inputs give different tag16 (with overwhelming probability)`
  - [x] `assert_ne!(compute_tag16(&[0x44u8; 32], &[0x56u8; 32]), GOLDEN, "changed input must change tag16");`
  - [x] `assert_ne!(compute_tag16(&[0x45u8; 32], &[0x55u8; 32]), GOLDEN, "changed input must change tag16");`
- [x] **Важно:** если фактическое значение `0x4de1` ещё не вычислено — запустить с `println!`, получить actual, зафиксировать
- [x] Запустить `cargo test -p z00z_wallets test_golden_tag16`

---

### 10.4 Full ECDH Cycle (Deterministic)

**🎯 Что тестируем:** Для детерминированных входов весь цикл побитово воспроизводим.

```yaml
golden_ecdh_cycle:
  receiver_secret: [0x22; 32]
  r_via_h2scalar_seed: [0x17; 32]   # r = h2scalar("Z00Z/R", [0x17; 32])
  amount: 1000
  asset_id: [0x02; 32]
  serial_id: 1

  expected:
    view_sk:   "ed2df264f3fcbdbb2ef32255a8fd6002d480e784f320426f965df69025850103"
    R_pub:     "b2e14be12f608311eedc826e2dca6b6af1fed6a39881d9068b315a562800944b"
    k_dh:      "3e67dc5751e32d35ae5317e37a0b3f936e6618fd20d09190c3422b68b91c9132"
    owner_tag: "51f3744da9529704bf5e38fd54216711b28b1cbf4f9bd35195b804f220d27d3a"
    pack_key:  "34e3c3805bf0580c174987bda653d223384180a168aba0cd5e64a2d718ecdcda"
    nonce:     "5c1f53a5ae702ff4ca8f384ed9ad2d80cb2fce89257ef05967a926dc3643d51b"
```

**📋 Чеклист реализации:**
- [x] Использовать `crates/z00z_wallets/tests/test_golden_vectors.rs`
- [x] Написать тест `fn test_golden_ecdh_cycle()` — `#[test]`
  - [x] `use z00z_wallets::ecdh::sender_derive_dh_with_r; // deterministic r from seed`
  - [x] Проверить, что `sender_derive_dh_with_r(view_pk: &RistrettoPoint, r: &Scalar) -> SenderDhResult` есть; если нет — добавить
  - [x] `let recv_secret = [0x22u8; 32];`
  - [x] `let view_sk = h2scalar_zk(b"Z00Z/VIEW", &[&recv_secret[..]]);`
  - [x] `let view_pk = view_sk * G;`
  - [x] `let r = h2scalar_zk(b"Z00Z/R", &[&[0x17u8; 32][..]]);`
  - [x] `let sender = sender_derive_dh_with_r(&view_pk, &r);`
  - [x] `let k_dh = derive_k_dh(&sender.dh);`
  - [x] `let handle = poseidon2_hash(b"Z00Z/RID", &[&recv_secret[..]]);`
  - [x] `let owner_tag = compute_owner_tag(&handle, &k_dh);`
  - [x] `// Phase 1: print all TBD values`
  - [x] `println!("view_sk: {}", hex::encode(view_sk.to_bytes()));`
  - [x] `println!("R_pub: {}", hex::encode(sender.R_pub.compress().to_bytes()));`
  - [x] `println!("k_dh: {}", hex::encode(k_dh));`
  - [x] `println!("owner_tag: {}", hex::encode(owner_tag));`
  - [x] `// Phase 2: зафиксировать и заменить println на assert_eq!`
- [x] Запустить `cargo test -p z00z_wallets test_golden_ecdh_cycle -- --nocapture`

---

## Phase 11. Adversarial / Attack-Scenario Tests

### 11.1 Malicious ReceiverCard с identity view_pk

**🎯 Что тестируем:** Кошелёк отказывается создавать output для ReceiverCard с `view_pk = identity`.

**🔬 Как тестируем:**
```
bad_card = ReceiverCard { owner_handle: [1u8; 32], view_pk: RistrettoPoint::identity() }
result = sender_create_output_for(&bad_card, 1000)
assert result == Err(IdentityPointNotAllowed)
```

**📋 Чеклист реализации:**
- [x] Создать файл `crates/z00z_wallets/tests/test_adversarial.rs`
- [x] Зарегистрировать `[[test]] name = "test_adversarial" path = "tests/test_adversarial.rs"` в `crates/z00z_wallets/Cargo.toml`
- [x] Проверить, что `z00z_wallets::tx::sender_create_output_for(card: &ReceiverCard, amount: u64) -> Result<UtxoLeaf, WalletError>` есть; если нет — добавить
- [x] Проверить, что `WalletError::IdentityPointNotAllowed` есть в `z00z_wallets::error`
- [x] Написать тест `fn test_adv_identity_view_pk()` — `#[test]`
  - [x] `use z00z_wallets::{error::WalletError, tx::sender_create_output_for, types::ReceiverCard};`
  - [x] `use curve25519_dalek::ristretto::RistrettoPoint;`
  - [x] `let bad_card = ReceiverCard { owner_handle: [1u8; 32], view_pk: RistrettoPoint::identity() };`
  - [x] `let result = sender_create_output_for(&bad_card, 1000);`
  - [x] `assert!(matches!(result, Err(WalletError::IdentityPointNotAllowed)), "identity view_pk must be rejected");`
- [x] Запустить `cargo test -p z00z_wallets test_adv_identity_view_pk`

---

### 11.2 Duplicate R_pub Detection (Simulated RNG Failure)

**🎯 Что тестируем:** Hedged generation с одним и тем же seed даёт разные `r` (или система детектирует повтор R_pub).

**🔬 Как тестируем:**
```
// Hedged generation: sender_salt + tx_context → разный r даже при плохом rng
r1 = generate_hedged_r(same_rng_seed, tx_digest_1, index: 0)
r2 = generate_hedged_r(same_rng_seed, tx_digest_1, index: 1)  // different index
assert r1 != r2   // index binding saves uniqueness

// Or: cache detects duplicate R_pub
R_pub1 = &r1 * G
assert cache.check_and_insert(bob_handle, R_pub1) == Ok(())
assert cache.check_and_insert(bob_handle, R_pub1) == Err(DuplicateEphemeralR)
```

**📋 Чеклист реализации:**
- [x] Использовать `crates/z00z_wallets/tests/test_adversarial.rs`
- [x] Проверить, что `z00z_wallets::ecdh::generate_hedged_r(seed: &[u8; 32], tx_digest: &[u8; 32], index: u32) -> Scalar` есть; если нет — добавить
- [x] Проверить, что `z00z_wallets::cache::EphemeralCache` с `check_and_insert(handle: &[u8;32], R_pub: &RistrettoPoint) -> Result<(), WalletError>` есть; если нет — создать
- [x] Проверить наличие `WalletError::DuplicateEphemeralR`
- [x] Написать тест `fn test_adv_dup_rng_failure()` — `#[test]`
  - [x] `use z00z_wallets::ecdh::generate_hedged_r;`
  - [x] `let seed = [0xDEu8; 32]; let tx_digest = [0xADu8; 32];`
  - [x] `let r0 = generate_hedged_r(&seed, &tx_digest, 0);`
  - [x] `let r1 = generate_hedged_r(&seed, &tx_digest, 1);`
  - [x] `assert_ne!(r0, r1, "different index must produce different r");`
  - [x] `let r0b = generate_hedged_r(&seed, &tx_digest, 0);`
  - [x] `assert_eq!(r0, r0b, "same args must be deterministic");`
  - [x] `// Cache dedup test:`
  - [x] `use z00z_wallets::cache::EphemeralCache;`
  - [x] `use curve25519_dalek::constants::RISTRETTO_BASEPOINT_POINT as G;`
  - [x] `let mut cache = EphemeralCache::new();`
  - [x] `let bob_handle = [0x22u8; 32];`
  - [x] `let R_pub1 = r0 * G;`
  - [x] `assert!(cache.check_and_insert(&bob_handle, &R_pub1).is_ok(), "first insert must succeed");`
  - [x] `assert!(matches!(cache.check_and_insert(&bob_handle, &R_pub1), Err(WalletError::DuplicateEphemeralR)), "duplicate must be rejected");`
- [x] Запустить `cargo test -p z00z_wallets test_adv_dup_rng_failure`

---

### 11.3 Tampered UTXO Leaf (Bit Flip)

**🎯 Что тестируем:** Один изменённый бит в любом поле листа — владелец либо не находит монету, либо расшифровка провалится.

**🔬 Как тестируем:**
```
assert decrypt_for_bob(&original_leaf) == Ok(plaintext)

for field in [owner_tag_bit_0, c_amount_bit_7, enc_pack_tag_bit_3, enc_pack_ct_bit_0]:
    tampered = flip_bit(&original_leaf, field)
    result   = decrypt_for_bob(&tampered)
    // owner_tag mismatch → leaf skipped; enc_pack bit → None
    assert result != Ok(plaintext), "Tamper not detected in field: {}", field
```

**📋 Чеклист реализации:**
- [x] Использовать `crates/z00z_wallets/tests/test_adversarial.rs`
- [x] Написать тест `fn test_adv_bit_flip_tamper()` — `#[test]`
  - [x] Создать полный leaf аналогично 9.1 — получить `original_leaf: UtxoLeaf` и `plaintext: Vec<u8>`
  - [x] Написать `fn flip_bit_in_slice(s: &[u8], bit_pos: usize) -> Vec<u8>` — `s[byte][bit]` flip
  - [x] Для каждого значимого поля создать tampered лист, запустить scan:
    - [x] `owner_tag` — flip бит 0: `assert_ne!(scan_result, Ok(Some(plaintext)));`
    - [x] `C_amount_bytes` — flip бит 7: `assert_ne!(scan_result, Ok(Some(plaintext)));`
    - [x] `enc_pack.tag` — flip бит 3: `assert_eq!(scan_result, Ok(None)); // auth fail`
    - [x] `enc_pack.ciphertext` — flip бит 0: `assert_eq!(scan_result, Ok(None)); // auth fail`
  - [x] Оригинал должен давать `Ok(Some(plaintext))`
- [x] Запустить `cargo test -p z00z_wallets test_adv_bit_flip_tamper`

---

### 11.4 Non-Canonical R_pub Encoding

**🎯 Что тестируем:** Ненормальный `R_pub` безопасно пропускается (не паникует).

**🔬 Как тестируем:**
```
bad_leaf = UtxoLeaf { r_pub: [0xFF; 32], .. }
result = receiver_scan_leaf(&bob_view_sk, &bad_leaf)
assert result == Ok(None)   // graceful skip, not crash
```

**📋 Чеклист реализации:**
- [x] Использовать `crates/z00z_wallets/tests/test_adversarial.rs`
- [x] Проверить, что `z00z_wallets::scan::receiver_scan_leaf(view_sk: &Scalar, leaf: &UtxoLeaf) -> Result<Option<CoinPackPlain>, WalletError>` есть; тест проверяет `R_pub` на каноничность
- [x] Написать тест `fn test_adv_noncanon_r_pub()` — `#[test]`
  - [x] `use z00z_wallets::scan::receiver_scan_leaf;`
  - [x] `let view_sk = h2scalar_zk(b"Z00Z/VIEW", &[&[0x22u8; 32][..]]);`
  - [x] `let bad_leaf = UtxoLeaf { r_pub: [0xFFu8; 32], ..UtxoLeaf::default() };`
  - [x] `let result = receiver_scan_leaf(&view_sk, &bad_leaf);`
  - [x] `assert_eq!(result, Ok(None), "non-canonical R_pub must gracefully skip, not panic");`
  - [x] `// Убедиться, что нет panic/unwrap в пути декомпрессии R_pub`
- [x] Запустить `cargo test -p z00z_wallets test_adv_noncanon_r_pub`

---

### 11.5 R_pub = Identity В Листе (Attack 4)

**🎯 Что тестируем:** Кошелёк пропускает лист с `R_pub = identity` без DoS.

**🔬 Как тестируем:**
```
// Simulate attacker flooding 10_000 leaves with identity R_pub
for _ in 0..10_000:
    bad_leaf = UtxoLeaf { r_pub: [0u8; 32], .. }
    result = receiver_scan_leaf(&bob_view_sk, &bad_leaf)
    assert result == Ok(None)   // never Err(EcdhIdentityResult) crash
```

**📋 Чеклист реализации:**
- [x] Использовать `crates/z00z_wallets/tests/test_adversarial.rs`
- [x] Проверить, что `receiver_scan_leaf` первым шагом вызывает `safe_decompress_point(&leaf.r_pub)` и при `is_identity()` возвращает `Ok(None)` — если нет, добавить
- [x] Написать тест `fn test_adv_dos_identity_flood()` — `#[test]`
  - [x] `use z00z_wallets::scan::receiver_scan_leaf;`
  - [x] `let view_sk = h2scalar_zk(b"Z00Z/VIEW", &[&[0x22u8; 32][..]]);`
  - [x] `let identity_leaf = UtxoLeaf { r_pub: [0x00u8; 32], ..UtxoLeaf::default() };`
  - [x] Цикл `for _ in 0..10_000`:
    - [x] `let result = receiver_scan_leaf(&view_sk, &identity_leaf);`
    - [x] `assert_eq!(result, Ok(None), "identity R_pub must never crash or Err");`
  - [x] `// Проверить скорость: 10k листьев < 1 секунды`
  - [x] `use std::time::Instant;`
  - [x] `let start = Instant::now();`
  - [x] `for _ in 0..10_000 { let _ = receiver_scan_leaf(&view_sk, &identity_leaf); }`
  - [x] `assert!(start.elapsed().as_secs() < 1, "identity flood must not cause DoS");`
- [x] Запустить `cargo test -p z00z_wallets test_adv_dos_identity_flood`

  ---

  ## 12. Performance Benchmarks As Sanity Tests

### 12.1 Poseidon2 < 100 μs per Call

```
for _ in 0..10_000:
    poseidon2_hash(b"Z00Z/RID", &[&[0x42u8; 32]])
// avg per call < 100 μs
```

**📋 Чеклист реализации:**
- [x] Создать файл `crates/z00z_crypto/tests/test_perf.rs`
- [x] Зарегистрировать `[[test]] name = "test_perf" path = "tests/test_perf.rs"` в `crates/z00z_crypto/Cargo.toml`
- [x] Написать тест `fn test_perf_poseidon2()` — `#[test] #[ignore]`
  - [x] `use z00z_crypto::hash::poseidon2_hash;`
  - [x] `use std::time::Instant;`
  - [x] `const ITERS: u64 = 10_000;`
  - [x] `let start = Instant::now();`
  - [x] `for _ in 0..ITERS { let _ = poseidon2_hash(b"Z00Z/RID", &[&[0x42u8; 32][..]]); }`
  - [x] `let elapsed = start.elapsed();`
  - [x] `let avg_us = elapsed.as_micros() as u64 / ITERS;`
  - [x] `println!("Poseidon2 avg: {} us", avg_us);`
  - [x] `assert!(avg_us < 100, "Poseidon2 must be < 100 us, got {}", avg_us);`
- [x] Запустить `cargo test -p z00z_crypto test_perf_poseidon2 -- --ignored`

---

### 12.2 ECDH < 200 μs per Call

```
for _ in 0..10_000:
    sender_derive_dh(&view_pk)
// avg < 200 μs
```

**📋 Чеклист реализации:**
- [x] Использовать `crates/z00z_wallets/tests/test_perf_wallets.rs`
- [x] Написать тест `fn test_perf_ecdh()` — `#[test] #[ignore]`
  - [x] `use z00z_wallets::ecdh::sender_derive_dh;`
  - [x] `use z00z_crypto::hash::h2scalar_zk;`
  - [x] `use curve25519_dalek::constants::RISTRETTO_BASEPOINT_POINT as G;`
  - [x] `use std::time::Instant;`
  - [x] `let view_pk = h2scalar_zk(b"Z00Z/VIEW", &[&[0x22u8; 32][..]]) * G;`
  - [x] `const ITERS: u64 = 10_000;`
  - [x] `let start = Instant::now();`
  - [x] `for _ in 0..ITERS { let _ = sender_derive_dh(&view_pk).unwrap(); }`
  - [x] `let avg_us = start.elapsed().as_micros() as u64 / ITERS;`
  - [x] `println!("ECDH avg: {} us", avg_us);`
  - [x] `assert!(avg_us < 200, "ECDH must be < 200 us, got {}", avg_us);`
- [x] Запустить `cargo test -p z00z_wallets test_perf_ecdh -- --ignored`

---

### 12.3 ZkPack Encrypt+Decrypt < 500 μs (64-byte Payload)

```
plaintext = [0x42u8; 64]
for _ in 0..10_000:
    enc = ZkPackV1::encrypt(...)
    ZkPackV1::decrypt(...)
// avg < 500 μs
```

**📋 Чеклист реализации:**
- [x] Использовать `crates/z00z_wallets/tests/test_perf_wallets.rs`
- [x] Написать тест `fn test_perf_zkpack_cycle()` — `#[test] #[ignore]`
  - [x] `use z00z_wallets::zkpack::ZkPackV1;`
  - [x] `use std::time::Instant;`
  - [x] `let k_dh = [0x42u8; 32]; let leaf_ad = [0xAAu8; 32]; let r_pub = [0x01u8; 32]; let asset_id = [0x02u8; 32];`
  - [x] `let plaintext = [0x42u8; 64];`
  - [x] `const ITERS: u64 = 10_000;`
  - [x] `let start = Instant::now();`
  - [x] `for _ in 0..ITERS {`
    - [x] `let enc = ZkPackV1::encrypt(&k_dh, &leaf_ad, &r_pub, &asset_id, 0, &plaintext);`
    - [x] `let _ = ZkPackV1::decrypt(&k_dh, &leaf_ad, &r_pub, &asset_id, 0, &enc);`
  - [x] `}`
  - [x] `let avg_us = start.elapsed().as_micros() as u64 / ITERS;`
  - [x] `println!("ZkPack cycle avg: {} us", avg_us);`
  - [x] `assert!(avg_us < 500, "ZkPack cycle must be < 500 us, got {}", avg_us);`
- [x] Запустить `cargo test -p z00z_wallets test_perf_zkpack_cycle -- --ignored`

---

### 12.4 Scan Throughput ≥ 1000 Leaves/sec

```
leaves = generate_test_leaves(10_000)
start = Instant::now()
for leaf in &leaves:
    receiver_scan_leaf(&view_sk, leaf)
throughput = 10_000.0 / start.elapsed().as_secs_f64()
assert throughput >= 1000.0
// Expected >> 10k/sec (tag16 precheck + identity-skip = fast path for 99.99% leaves)
```

**📋 Чеклист реализации:**
- [x] Использовать `crates/z00z_wallets/tests/test_perf_wallets.rs`
- [x] Проверить, что `receiver_scan_leaf` содержит fast-path: 1) декодировать `R_pub`, если неканон — `Ok(None)`; 2) `tag16` precheck до ECDH
- [x] Написать тест `fn test_perf_scan_throughput()` — `#[test] #[ignore]`
  - [x] `use z00z_wallets::scan::receiver_scan_leaf;`
  - [x] `use z00z_wallets::types::UtxoLeaf;`
  - [x] `use z00z_crypto::hash::h2scalar_zk;`
  - [x] `use std::time::Instant;`
  - [x] `let view_sk = h2scalar_zk(b"Z00Z/VIEW", &[&[0x22u8; 32][..]]);`
  - [x] `const N: usize = 10_000;`
  - [x] `let leaves: Vec<UtxoLeaf> = (0..N).map(|i| UtxoLeaf::dummy_for_scan(i as u32)).collect();`
  - [x] Проверить `UtxoLeaf::dummy_for_scan(index: u32) -> UtxoLeaf` есть; если нет — добавить (leaf с pseudorandom R_pub из index, owner_tag != expected)
  - [x] `let start = Instant::now();`
  - [x] `for leaf in &leaves { let _ = receiver_scan_leaf(&view_sk, leaf); }`
  - [x] `let throughput = N as f64 / start.elapsed().as_secs_f64();`
  - [x] `println!("Scan throughput: {:.0} leaves/sec", throughput);`
  - [x] `assert!(throughput >= 1000.0, "Scan must be >= 1000 leaves/sec, got {:.0}", throughput);`
- [x] Запустить `cargo test -p z00z_wallets test_perf_scan_throughput -- --ignored`

---

## Итоговая Матрица Покрытия

| Раздел Спека | Примитив | Тест(ы) |
|--------------|----------|---------|
| §2.1.2 | Point encoding roundtrip | 1.1, 1.2 |
| §2.1.3 | Identity rejection | 1.3 |
| §2.1.3.1 | Safe decompression (DoS) | 1.6 |
| §2.1.3.2 | Zero scalar rejection | 1.4 |
| §2.1.2.3 | Scalar group laws / ECDH algebra | 1.5 |
| §2.2.1 | H_zk vs H_wallet separation | 2.1 |
| §2.2.2 | Domain registry uniqueness | 2.2 |
| §2.2.1.3 | Hash policy enforcement | 2.5 |
| §2.2.3 | H2Scalar correctness + golden | 3.1–3.4 |
| §2.3.3 | Commit + open + verify | 4.1 |
| §2.3.1 | Homomorphism | 4.2 |
| §2.3.1.1 | Generators independence | 4.4 |
| §2.4.1.1 | Range proof generate/verify | 5.1, 5.2 |
| §2.4.1.2 | Batch verification + perf | 5.3, 5.4 |
| §2.5.1.3 | ECDH shared-secret equality | 6.1 |
| §2.5.1.1 | Sender uniqueness (hedged r) | 6.2 |
| §2.5 | Receiver isolation | 6.3 |
| §2.5.1.2 | Identity R_pub rejection | 6.4 |
| §2.6.1.1 | KDF determinism + chain | 7.1, 7.2 |
| §2.6.1.1 | KDF domain separation | 7.3 |
| §2.2.2 | owner_tag + tag16 | 7.4 |
| §2.7.1.1 | ZkPack round-trip | 8.1 |
| §2.7.3 | Authentication (wrong key) | 8.2 |
| §2.7.1.1.4 | AD binding | 8.3, 8.5 |
| §2.7.1.1.2 | Keystream determinism | 8.4 |
| Full E2E | Complete stealth address cycle | 9.1 |
| Full E2E | Receiver isolation end-to-end | 9.2 |
| Full E2E | tag16 scan accelerator | 9.3 |
| Cross-impl | Golden vectors | §10 |
| Security | Attack scenarios 1–5 | §11 |
| Perf | Benchmarks | §12 |

---

**Document Version:** 1.0  
**Created:** 2026-02-19  
**Based on:** `specs/007-z00z-ecc-spec-2/2_Cryptographic_Foundation.md` v1.0  
**Next:** Реализовать тесты в `crates/z00z_wallets/tests/` и `crates/z00z_crypto/tests/`
