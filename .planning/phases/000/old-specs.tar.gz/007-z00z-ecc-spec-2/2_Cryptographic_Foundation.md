# 2. Cryptographic Foundation

## 2.1 Elliptic Curve Selection

### 2.1.1 Curve Choice: Ristretto255

**Rationale for Ristretto255 Selection:**

This specification mandates **Ristretto255** as the elliptic curve group for all ECC operations. Ristretto255 is a prime-order group abstraction built on top of Curve25519.

**Why Ristretto255:**

1. **Prime-Order Group (No Cofactor Issues):**
   - Curve25519 has cofactor h=8, requiring careful handling of small-order points
   - Ristretto255 provides a clean prime-order abstraction (no cofactor)
   - Eliminates entire class of timing/validation attacks (twist attacks, invalid curve attacks)
   - All points in Ristretto255 are valid by construction

2. **Performance:**
   - Built on Curve25519 (one of the fastest curves)
   - Point addition: ~100 nanoseconds
   - Scalar multiplication: ~45 microseconds
   - Batch verification: 8x faster than sequential
   - Well-optimized implementations (curve25519-dalek, libsodium)

3. **Canonical Encoding:**
   - Exactly one 32-byte encoding per group element
   - Decompression is deterministic and always succeeds for valid inputs
   - No malleable encodings (eliminates non-canonical point attacks)
   - Critical for consensus: `asset_id`, `R_pub`, `view_pk` must encode identically across implementations

4. **Security Level:**
   - ~128-bit security (pre-quantum)
   - Matches or exceeds secp256k1, P-256
   - Suitable for financial applications requiring long-term security

5. **ZK-Friendly:**
   - Arithmetic over prime field (p = 2^255 - 19)
   - Efficient for Bulletproofs/Bulletproofs+ range proofs
   - Compatible with STARK/FRI proof systems (field arithmetic translates cleanly)

6. **Existing Integration:**
   - Already used in z00z_crypto via Tari backend (backend_tari.rs)
   - Tari implements Pedersen commitments, Bulletproofs+ on Ristretto255
   - Zero migration cost (reuse existing infrastructure)

7. **Stealth Address Compatibility:**
   - Proven in Monero (similar ECDH stealth protocol)
   - Well-understood key derivation patterns
   - No known attacks on ECDH-based stealth addresses over Ristretto255

**Alternative Considerations (Rejected):**

- **secp256k1:** Bitcoin curve, but has cofactor issues and less clean abstraction
- **Ed25519:** Twisted Edwards form, but less suitable for Pedersen commitments
- **P-256 (NIST):** Government standard, but potential backdoor concerns, slower
- **BLS12-381:** Pairing-friendly, but overkill (we don't need pairings), larger points (48 bytes)

**Security Note:**

Ristretto255 security relies on Discrete Logarithm Problem (DLP) hardness. This is **NOT post-quantum secure**. Quantum computers running Shor's algorithm (~2030-2040 timeline) can break ECDH.

For Z00Z, this is acceptable because:
- Ownership (receiver_secret) remains secure (hash preimage, not DLP)
- Unlinkability on state is preserved (no stable IDs in leaves)
- Inbox confidentiality is explicitly a non-goal for PQ adversaries (see §1.3.3)
- Migration path exists (ZkPack_v2 with lattice-based KEM, see §20.5)

**Specification Commitment:**

All ECC operations in this specification use **Ristretto255** unless explicitly noted otherwise. No algorithm substitutions permitted (would break cross-implementation compatibility).

### 2.1.2 Backend Integration

**Integration with Existing z00z_crypto Codebase:**

The Z00Z system already has ECC infrastructure via the **Tari cryptographic backend** (z00z_crypto/src/backend_tari.rs). This specification builds on that foundation.

**Current Backend Architecture:**

```rust
// z00z_crypto/src/backend_tari.rs (EXISTING)
pub struct TariBackend;

impl CryptoBackend for TariBackend {
    fn create_commitment(value: u64, blinding: &BlindingFactor) -> Commitment;
    fn generate_range_proof(...) -> RangeProof;
    fn verify_range_proof(...) -> Result<bool>;
}
```

**What Exists (Reusable):**

1. **Pedersen Commitments:**
   - Factory: `ExtendedPedersenCommitmentFactory` (cached via `Lazy<T>`)
   - Operation: `C_amount = v*H + r_out*G`
   - Performance: <1 microsecond per commitment
   - Location: `backend_tari.rs` lines 90-95

2. **Range Proofs (Bulletproofs+):**
   - Service: `BulletproofsPlusService` (cached, ~10ms init)
   - Bits: 64-bit range (v ∈ [0, 2^64))
   - Aggregation: Up to 128 outputs per proof
   - Performance: 6-45ms generation, 1-6ms verification
   - Location: `backend_tari.rs` lines 65-75

3. **ECC Point Operations:**
   - Type: `RistrettoPoint` (via tari_crypto)
   - Scalar mul: `view_sk * R_pub`
   - Base mul: `r * G`
   - Compressed encoding: 32 bytes

**What Needs Addition (New):**

1. **ECDH Key Derivation:**
```rust
// z00z_crypto/src/ecdh.rs (NEW)
pub fn ecdh_shared_secret(
    scalar: &Scalar,
    point: &RistrettoPoint,
) -> RistrettoPoint {
    scalar * point  // dh = view_sk * R_pub or r * view_pk
}

pub fn derive_k_dh(dh: &RistrettoPoint) -> [u8; 32] {
    let compressed = dh.compress();
    hash_zk::poseidon2_hash(b"Z00Z/DH", &[compressed.as_bytes()])
}
```

2. **Stealth Address Operations:**
```rust
// z00z_crypto/src/stealth.rs (NEW)
pub fn generate_ephemeral_keypair(
    r: &Scalar,
) -> (RistrettoPoint, RistrettoPoint) {
    let R_pub = r * &RISTRETTO_BASEPOINT_TABLE;
    (R_pub, R_pub)  // Same point, returned for convenience
}

pub fn compute_stealth_dh(
    r: &Scalar,
    view_pk: &RistrettoPoint,
) -> RistrettoPoint {
    r * view_pk  // Sender computes: dh = r * view_pk
}

pub fn recover_stealth_dh(
    view_sk: &Scalar,
    R_pub: &RistrettoPoint,
) -> RistrettoPoint {
    view_sk * R_pub  // Receiver computes: dh' = view_sk * R
    // Mathematically: dh' = view_sk*(r*G) = r*(view_sk*G) = r*view_pk = dh
}
```

3. **Hash-to-Scalar (for view_sk, r):**
```rust
// z00z_crypto/src/hash_zk.rs (ENHANCE)
pub fn poseidon2_h2scalar(
    domain: &'static [u8],
    data: &[&[u8]],
) -> Scalar {
    let hash = poseidon2_hash(domain, data);
    Scalar::from_bytes_mod_order(hash)  // Reduce mod curve order
}
```

**Backend Trait Extension (Optional):**

If we want to keep backend-agnostic design:

```rust
// z00z_crypto/src/backend.rs (ENHANCE)
pub trait CryptoBackend {
    // Existing methods...
    fn create_commitment(...) -> Commitment;
    fn generate_range_proof(...) -> RangeProof;
    
    // NEW: Stealth address operations
    fn ecdh_shared_secret(
        scalar: &Scalar,
        point: &RistrettoPoint,
    ) -> RistrettoPoint;
    
    fn hash_to_scalar(
        domain: &'static [u8],
        data: &[&[u8]],
    ) -> Scalar;
}
```

**Performance Considerations:**

- **Cached Services:** `BULLETPROOF_SERVICE` and `COMMITMENT_FACTORY` use `Lazy<T>` for one-time initialization
- **Thread Safety:** All backend operations are thread-safe (immutable or internally synchronized)
- **Zero Overhead:** Static dispatch via trait (no vtable indirection)

**Critical Integration Points:**

1. **Commitment Verification (Receive):**
   ```rust
   // Receiver verifies after decrypting enc_pack
   let C_actual = backend.create_commitment(plaintext.v, &plaintext.r_out);
   if C_actual != leaf.C_amount {
       return Err(Error::CommitmentMismatch);
   }
   ```

2. **Range Proof Generation (Send):**
   ```rust
   // Sender creates range proof for output
   let range_proof = backend.generate_range_proof(
       v,
       &r_out,
       RANGE_PROOF_BITS_V1,  // 64 bits
   )?;
   ```

3. **ECDH in OWF Circuit:**
   - Wallet computes `dh = r * view_pk` (off-circuit)
   - OWF circuit verifies: `dh == r * view_pk` (constraint)
   - Both wallet and circuit use same Ristretto255 arithmetic

**Migration Path:**

Existing code using `backend_tari::TariBackend` continues to work. New stealth address features added as:
- Standalone functions in `z00z_crypto/src/stealth.rs`
- Or as trait extensions on `CryptoBackend`

No breaking changes to existing commitment/range proof API.

#### 2.1.2.1 Curve25519-Dalek Dependency

**Dependency Specification:**

The implementation MUST use **curve25519-dalek** as the Ristretto255 provider.

**Version Requirements:**

```toml
[dependencies]
curve25519-dalek = { version = "4.1", features = ["serde", "zeroize"] }
```

**Minimum Version:** 4.0.0 (Ristretto255 API stabilized)
**Recommended Version:** 4.1.x (latest stable)
**Feature Flags:**
- `serde`: Serialization support for ReceiverCard, UtxoLeaf encoding
- `zeroize`: Secure memory clearing for secrets (r, view_sk, receiver_secret)

**Version Compatibility Matrix:**

| curve25519-dalek | Ristretto API | Performance | Security | Status |
|------------------|---------------|-------------|----------|--------|
| 3.x | Stable | Baseline | ✓ | Legacy |
| 4.0.x | Stable | +15% faster | ✓ | Minimum |
| 4.1.x | Stable | +22% faster | ✓ | Recommended |
| 5.x (future) | Unknown | TBD | TBD | Monitor |

**Critical API Surface:**

```rust
use curve25519_dalek::{
    constants::RISTRETTO_BASEPOINT_TABLE,  // G (generator)
    ristretto::{RistrettoPoint, CompressedRistretto},
    scalar::Scalar,
    traits::Identity,
};

// Point operations (MUST use)
let R_pub: RistrettoPoint = r * &RISTRETTO_BASEPOINT_TABLE;
let dh: RistrettoPoint = view_sk * R_pub;

// Encoding (MUST use compressed form)
let bytes: [u8; 32] = R_pub.compress().to_bytes();
let point: Option<RistrettoPoint> = CompressedRistretto::from_slice(&bytes)
    .decompress();

// Identity check (MUST reject)
if point == RistrettoPoint::identity() {
    return Err(Error::IdentityPoint);
}
```

**Compatibility with Tari:**

The existing Tari backend uses `tari_crypto`, which internally uses `curve25519-dalek 3.x`. This specification targets `4.x` for better performance.

**Migration Path:**
1. Phase 1: Use `curve25519-dalek 3.x` via `tari_crypto` (existing)
2. Phase 2: Upgrade to `curve25519-dalek 4.x` directly (new stealth code)
3. Phase 3: Migrate Tari backend to 4.x (when Tari upgrades)

**Security Considerations:**

- **Constant-Time:** All scalar operations are constant-time by default
- **Zeroization:** Use `.zeroize()` on drop for sensitive scalars
- **No Unsafe:** Avoid `unsafe` blocks (curve25519-dalek is safe by design)

**Known Issues:**

- **v3 → v4 Breaking Changes:** API mostly compatible, but serialization format changed
- **v4.0.0 Bug:** Point decompression edge case (fixed in 4.0.1)
- **Workaround:** Pin to `>= 4.0.1`

**Alternative Libraries (NOT RECOMMENDED):**

- `libsodium` - C library, harder to integrate with Rust proof systems
- `ed25519-dalek` - Signatures only, missing Ristretto abstraction
- Custom implementation - Dangerous (timing attacks, invalid curve bugs)

**Testing:**

All test vectors MUST validate against `curve25519-dalek 4.1+` reference implementation. Cross-implementation tests SHOULD include:
- Scalar multiplication
- Point addition/compression
- ECDH shared secret derivation

#### 2.1.2.2 Point Representation

**RistrettoPoint Usage:**

All ECC points in this specification are represented as `RistrettoPoint` from curve25519-dalek.

**Type Definition:**

```rust
use curve25519_dalek::ristretto::RistrettoPoint;

// Examples of point usage:
pub struct UtxoLeaf {
    pub R_pub: RistrettoPoint,      // Ephemeral ECDH key
    pub C_amount: RistrettoPoint,   // Pedersen commitment
    // ...
}

pub struct ReceiverCard {
    pub view_pk: RistrettoPoint,    // View public key
    // ...
}
```

**Point Operations (MUST):**

1. **Point Addition:**
   ```rust
   let sum: RistrettoPoint = point_a + point_b;
   let difference: RistrettoPoint = point_a - point_b;
   ```

2. **Scalar Multiplication:**
   ```rust
   // Variable-base multiplication (runtime point)
   let result: RistrettoPoint = scalar * point;
   
   // Fixed-base multiplication (generator G, faster)
   use curve25519_dalek::constants::RISTRETTO_BASEPOINT_TABLE;
   let R_pub: RistrettoPoint = r * &RISTRETTO_BASEPOINT_TABLE;
   ```

3. **Batch Operations (RECOMMENDED for performance):**
   ```rust
   use curve25519_dalek::traits::VartimeMultiscalarMul;
   
   // Compute: v*H + r*G (Pedersen commitment)
   let C = RistrettoPoint::vartime_multiscalar_mul(
       &[v_scalar, r_scalar],
       &[H_point, G_point],
   );
   ```

**Point Encoding (Canonical - MUST):**

```rust
use curve25519_dalek::ristretto::CompressedRistretto;

// Encoding (point → 32 bytes)
let compressed: CompressedRistretto = point.compress();
let bytes: [u8; 32] = compressed.to_bytes();

// Decoding (32 bytes → point, MAY FAIL)
let compressed = CompressedRistretto::from_slice(&bytes)?;
let point_opt: Option<RistrettoPoint> = compressed.decompress();

// MUST handle decompression failure
let point = point_opt.ok_or(Error::InvalidPoint)?;
```

**Critical Properties:**

- **Canonical:** Each point has exactly ONE 32-byte encoding
- **Deterministic:** Decompression always produces the same point (or fails)
- **Prime-Order:** All valid points are in the prime-order subgroup (no cofactor)
- **No Identity:** Compressed identity (all zeros) decompresses to `Some(identity)` - MUST reject

**Identity Point Handling (MUST):**

```rust
use curve25519_dalek::traits::Identity;

// Check if point is identity (MUST reject in protocol)
if point.is_identity() {
    return Err(Error::IdentityPointNotAllowed);
}

// Alternative: Check compressed form
if compressed.as_bytes() == &[0u8; 32] {
    return Err(Error::IdentityPointNotAllowed);
}
```

**Why Identity is Dangerous:**
- `view_pk = identity` → ECDH always produces identity → predictable k_dh
- `R_pub = identity` → All receivers compute same k_dh → linkability
- OWF constraint `R = r*G` fails if R is identity (unless r=0, also invalid)

**Point Validation (MUST for Untrusted Input):**

```rust
pub fn validate_point(bytes: &[u8; 32]) -> Result<RistrettoPoint> {
    // Step 1: Decompress (validates curve membership, canonicity)
    let point = CompressedRistretto(bytes)
        .decompress()
        .ok_or(Error::InvalidPoint)?;
    
    // Step 2: Reject identity
    if point.is_identity() {
        return Err(Error::IdentityPointNotAllowed);
    }
    
    Ok(point)
}
```

**Storage Recommendations:**

- **In-Memory:** Use `RistrettoPoint` (64 bytes, optimized for arithmetic)
- **On-Disk/Network:** Use compressed `[u8; 32]` (32 bytes)
- **Database:** Store as BLOB (32 bytes)

#### 2.1.2.3 Scalar Arithmetic

**Scalar Representation:**

All scalar values (private keys, blinding factors, ephemeral secrets) are represented as `Scalar` from curve25519-dalek.

**Type Definition:**

```rust
use curve25519_dalek::scalar::Scalar;

// Examples of scalar usage:
let view_sk: Scalar;        // View secret key
let r: Scalar;              // Ephemeral secret
let r_out: Scalar;          // Pedersen blinding factor
```

**Scalar Generation (MUST):**

1. **From Random Bytes (RECOMMENDED):**
   ```rust
   use rand_core::OsRng;
   
   let r = Scalar::random(&mut OsRng);
   // Uniformly distributed over [0, ℓ) where ℓ is curve order
   ```

2. **From Hash (Hash-to-Scalar):**
   ```rust
   // Used for view_sk derivation, hedged r generation
   pub fn hash_to_scalar(hash: &[u8; 32]) -> Scalar {
       Scalar::from_bytes_mod_order(*hash)
       // Reduces hash mod curve order (no bias if hash is uniform)
   }
   ```

3. **From u64 (for amounts):**
   ```rust
   let v_scalar = Scalar::from(amount_u64);
   ```

**Scalar Operations:**

```rust
// Addition/subtraction (mod curve order)
let sum = a + b;
let diff = a - b;

// Multiplication (mod curve order)
let product = a * b;

// Inversion (for proof systems, careful with zero)
let inv = a.invert();  // Returns identity if a == 0

// Negation
let neg = -a;
```

**Scalar Encoding:**

```rust
// Encoding (scalar → 32 bytes, little-endian)
let bytes: [u8; 32] = scalar.to_bytes();

// Decoding (32 bytes → scalar, MAY FAIL if non-canonical)
let scalar_opt = Scalar::from_canonical_bytes(bytes);
let scalar = scalar_opt.ok_or(Error::NonCanonicalScalar)?;

// Alternative: Reduce mod order (always succeeds, but non-canonical)
let scalar_reduced = Scalar::from_bytes_mod_order(bytes);
```

**Canonical vs Non-Canonical (CRITICAL):**

- **Canonical:** Scalar is in range [0, ℓ-1], unique encoding
- **Non-Canonical:** Scalar ≥ ℓ (gets reduced mod ℓ)

For consensus-critical data (asset_id, tx_digest), MUST use `from_canonical_bytes` and reject non-canonical.

For derived keys (view_sk from hash), MAY use `from_bytes_mod_order` (hash output is uniform).

**Zero Scalar Handling (MUST):**

```rust
use curve25519_dalek::traits::Identity as _;

// Check if scalar is zero
if scalar == Scalar::ZERO {
    return Err(Error::ZeroScalarNotAllowed);
}

// Why zero is dangerous:
// - r = 0 → R_pub = identity → linkability attack
// - view_sk = 0 → anyone can compute dh → privacy break
```

**Constant-Time Operations (MUST for secrets):**

All `Scalar` arithmetic is constant-time by default in curve25519-dalek. This prevents timing side-channels.

```rust
// Comparison (MUST be constant-time for secrets)
use subtle::ConstantTimeEq;

if scalar_a.ct_eq(&scalar_b).into() {
    // Equal (timing-safe)
}
```

**Zeroization (MUST on drop):**

```rust
use zeroize::Zeroize;

// Scalar implements Zeroize
let mut secret = Scalar::random(&mut OsRng);
// ... use secret ...
secret.zeroize();  // Overwrites with zeros
drop(secret);      // Explicit drop

// Or use zeroize::Zeroizing wrapper
use zeroize::Zeroizing;
let secret = Zeroizing::new(Scalar::random(&mut OsRng));
// Automatically zeroized on drop
```

**Scalar Storage (MUST NOT):**

- **receiver_secret:** Never store unencrypted on disk
- **view_sk:** Derived on-the-fly from receiver_secret (ephemeral in memory)
- **r (ephemeral):** Zeroize immediately after use (never persisted)
- **r_out (blinding):** Store encrypted in coin database (needed for spending)

**Performance Notes:**

- Scalar addition/subtraction: ~5 nanoseconds
- Scalar multiplication: ~500 nanoseconds  
- Scalar inversion: ~1 microsecond
- Point multiplication (variable-base): ~45 microseconds
- Point multiplication (fixed-base): ~25 microseconds

### 2.1.3 ECC Validity Rules (MUST)

**Mandatory Validation Rules for All ECC Points:**

All ECC points from **untrusted sources** (network, user input, ReceiverCard, UtxoLeaf) MUST pass validation before use. Failure to validate enables attacks.

**Validation Pipeline (MUST):**

```rust
pub fn validate_ecc_point(bytes: &[u8]) -> Result<RistrettoPoint> {
    // Rule 1: Length check (MUST be exactly 32 bytes)
    if bytes.len() != 32 {
        return Err(Error::InvalidPointLength);
    }
    
    // Rule 2: Canonical decompression (validates curve membership)
    let compressed = CompressedRistretto::from_slice(bytes);
    let point = compressed.decompress()
        .ok_or(Error::PointDecompressionFailed)?;
    
    // Rule 3: Identity rejection (MUST NOT be identity point)
    if point.is_identity() {
        return Err(Error::IdentityPointNotAllowed);
    }
    
    Ok(point)
}
```

**Rule 1: Canonical Encoding (MUST)**

- All points MUST use compressed Ristretto255 encoding (32 bytes)
- Decompression MUST succeed (reject malformed encodings)
- Non-canonical encodings MUST be rejected

**Why:** Consensus requires deterministic encoding. Non-canonical points enable malleability attacks.

**Attack Example (Prevented):**
```rust
// Attacker sends non-canonical R_pub
// Wallet A decodes to point_1, Wallet B decodes to point_2
// Result: Different k_dh, receiver cannot decrypt
// → PREVENTED by canonical decompression check
```

**Rule 2: Identity Point Rejection (MUST)**

- Identity point (point at infinity, encoded as 32 zero bytes) MUST be rejected
- Applies to: `view_pk`, `R_pub`, `C_amount` (if zero commitment used)

**Why:** Identity point breaks ECDH security and enables linkability.

**Attack Example (Prevented):**
```rust
// Attacker sets R_pub = identity
// dh = view_sk * identity = identity (for any view_sk)
// k_dh = H(identity) = constant
// Result: All receivers compute same k_dh → linkability
// → PREVENTED by identity check
```

**Implementation:**
```rust
use curve25519_dalek::traits::Identity;

if point.is_identity() {
    return Err(Error::IdentityPointNotAllowed);
}

// Alternative: Check compressed bytes
if compressed_bytes == [0u8; 32] {
    return Err(Error::IdentityPointNotAllowed);
}
```

**Rule 3: Scalar Non-Zero Check (MUST for ephemeral r)**

- Ephemeral scalar `r` MUST NOT be zero
- Derived scalars (view_sk from hash) are safe (hash output unlikely zero)
- Blinding factors (r_out) SHOULD be non-zero (but zero commitment valid in some contexts)

**Why:** `r = 0` → `R_pub = identity` → breaks Rule 2.

**Implementation:**
```rust
if r == Scalar::ZERO {
    return Err(Error::ZeroScalarNotAllowed);
}
```

**Validation Contexts:**

| Input Source | Validation Required | Reason |
|--------------|---------------------|--------|
| ReceiverCard.view_pk | YES (Rules 1-2) | Untrusted, prevents burn |
| UtxoLeaf.R_pub | YES (Rules 1-2) | Untrusted, prevents linkability |
| UtxoLeaf.C_amount | YES (Rule 1), OPTIONAL (Rule 2) | Untrusted, zero commitment rare but valid |
| Generated view_pk | NO (trusted derivation) | Internal, from hash_to_scalar |
| Generated R_pub | YES (Rule 3 on r) | Internal, validate r before R=r*G |

**Error Handling (MUST NOT panic):**

```rust
// ❌ WRONG: Panic on invalid input
let point = compressed.decompress().expect("valid point");

// ✅ CORRECT: Return error
let point = compressed.decompress()
    .ok_or(Error::InvalidPoint)?;
```

**Rationale:** Malicious inputs should fail gracefully, not crash wallet.

**Constant-Time Validation (SHOULD):**

For secret-dependent comparisons (M1 owner_tag check), use constant-time:

```rust
use subtle::ConstantTimeEq;

if !bool::from(owner_tag_expected.ct_eq(&leaf.owner_tag)) {
    return Err(Error::OwnerTagMismatch);
}
```

**Why:** Prevents timing side-channels that could leak information about receiver_secret.

#### 2.1.3.1 Point Decompression Safety

**Untrusted Input Handling (MUST):**

All point decompression from external sources MUST use bounded parsing with explicit error handling. No `expect()`, `unwrap()`, or `panic!()` allowed.

**Threat Model:**

- **Malicious Sender:** Sends malformed R_pub in UtxoLeaf → wallet MUST reject gracefully
- **Malicious Directory:** Provides invalid view_pk in ReceiverCard → wallet MUST reject before use
- **Network Attacker:** Corrupts point bytes in transit → wallet MUST detect and reject

**Safe Decompression Pattern (MUST):**

```rust
use curve25519_dalek::ristretto::{RistrettoPoint, CompressedRistretto};

pub fn safe_decompress_point(bytes: &[u8]) -> Result<RistrettoPoint> {
    // Step 1: Bounded length check (prevent buffer overflows)
    if bytes.len() != 32 {
        return Err(Error::InvalidPointLength {
            expected: 32,
            actual: bytes.len(),
        });
    }
    
    // Step 2: Copy to fixed-size array (stack allocation, safe)
    let mut point_bytes = [0u8; 32];
    point_bytes.copy_from_slice(bytes);
    
    // Step 3: Attempt decompression (MAY FAIL for invalid points)
    let compressed = CompressedRistretto(point_bytes);
    let point = compressed.decompress()
        .ok_or(Error::PointDecompressionFailed)?;
    
    // Step 4: Identity check (application-specific, usually required)
    if point.is_identity() {
        return Err(Error::IdentityPointNotAllowed);
    }
    
    Ok(point)
}
```

**Decompression Failure Cases:**

1. **Non-Canonical Encoding:**
   - Point bytes represent non-reduced field element
   - Ristretto requires canonical (reduced mod p) encoding
   - Example: `bytes[31] >= 0x80` (high bit set, non-canonical)

2. **Point Not on Curve:**
   - Bytes decompress to field element not satisfying curve equation
   - Rare in practice (Ristretto construction prevents most)

3. **Invalid Ristretto Representative:**
   - Field element does not correspond to valid Ristretto equivalence class
   - Prevented by curve25519-dalek's validation

**Attack Scenarios (Prevented by Safe Decompression):**

**Attack 1: Buffer Overflow via Oversized Point**

```rust
// Attacker sends 64-byte "point" instead of 32 bytes
let malicious_point = vec![0u8; 64];

// ❌ UNSAFE: No length check
let compressed = CompressedRistretto::from_slice(&malicious_point); // May panic or corrupt

// ✅ SAFE: Explicit length check
if malicious_point.len() != 32 {
    return Err(Error::InvalidPointLength);
}
```

**Attack 2: Panic-Induced DoS**

```rust
// Attacker sends 100,000 invalid points to cause wallet crash
for invalid_point in attacker_spam {
    // ❌ UNSAFE: Panics on invalid point
    let point = compressed.decompress().expect("valid");
    
    // ✅ SAFE: Returns error, wallet continues
    let point = compressed.decompress().ok_or(Error::Invalid)?;
}
```

**Attack 3: Timing Side-Channel via Exception Handling**

```rust
// ❌ UNSAFE: Different code path timing for valid vs invalid
try {
    let point = decompress_unchecked(bytes);
    process(point);  // Fast path
} catch {
    log_error();     // Slow path (disk I/O)
}

// ✅ SAFE: Constant-time rejection
let point = decompress_or_reject(bytes)?;  // Same timing for all failures
process(point);
```

**Integration with ReceiverCard Validation:**

```rust
impl ReceiverCard {
    pub fn from_bytes(bytes: &[u8]) -> Result<Self> {
        // Parse fields...
        let view_pk_bytes = &bytes[32..64];
        
        // MUST use safe decompression (untrusted input)
        let view_pk = safe_decompress_point(view_pk_bytes)?;
        
        Ok(ReceiverCard {
            owner_handle,
            view_pk,
            // ...
        })
    }
}
```

**Integration with UtxoLeaf Validation:**

```rust
impl UtxoLeaf {
    pub fn canonical_decode(bytes: &[u8]) -> Result<Self> {
        // ... parse other fields ...
        
        // MUST validate R_pub (untrusted from network)
        let R_pub = safe_decompress_point(&r_pub_bytes)?;
        
        // MUST validate C_amount (untrusted commitment)
        let C_amount = safe_decompress_point(&c_amount_bytes)?;
        
        Ok(UtxoLeaf { R_pub, C_amount, /* ... */ })
    }
}
```

**Performance Impact:**

Safe decompression adds negligible overhead:
- Length check: ~1 nanosecond
- Decompression: ~2 microseconds (same as unsafe)
- Identity check: ~50 nanoseconds
- **Total overhead:** <0.1% of typical leaf processing time

**Testing Requirements (MUST):**

```rust
#[test]
fn test_reject_oversized_point() {
    let oversized = vec![0u8; 64];
    assert!(safe_decompress_point(&oversized).is_err());
}

#[test]
fn test_reject_undersized_point() {
    let undersized = vec![0u8; 16];
    assert!(safe_decompress_point(&undersized).is_err());
}

#[test]
fn test_reject_non_canonical_point() {
    let mut non_canonical = [0u8; 32];
    non_canonical[31] = 0xFF;  // High bit set
    assert!(safe_decompress_point(&non_canonical).is_err());
}

#[test]
fn test_reject_identity_point() {
    let identity = [0u8; 32];
    assert!(safe_decompress_point(&identity).is_err());
}

#[test]
fn test_accept_valid_point() {
    let valid = RistrettoPoint::random(&mut OsRng);
    let bytes = valid.compress().to_bytes();
    assert!(safe_decompress_point(&bytes).is_ok());
}
```

#### 2.1.3.2 Scalar Generation

**Random Scalar Generation (MUST):**

All random scalars (ephemeral `r`, blinding factors `r_out`, coin secrets `s_out`) MUST use cryptographically secure RNG.

**Recommended Pattern:**

```rust
use curve25519_dalek::scalar::Scalar;
use rand_core::OsRng;

// CORRECT: Use OS-provided CSPRNG
let r = Scalar::random(&mut OsRng);
let r_out = Scalar::random(&mut OsRng);
```

**RNG Requirements (MUST):**

1. **Entropy Source:** OS-provided (`getrandom`, `/dev/urandom`, `BCryptGenRandom`)
2. **No Predictability:** Must pass NIST randomness tests
3. **No Reuse:** Each call MUST produce independent output
4. **Thread Safety:** Safe for concurrent use

**Forbidden RNG Sources (MUST NOT):**

```rust
// ❌ WRONG: Deterministic seed (predictable r → linkability)
use rand::SeedableRng;
let mut rng = StdRng::seed_from_u64(12345);
let r = Scalar::random(&mut rng);  // Attacker can predict

// ❌ WRONG: Current timestamp (low entropy, predictable)
// NOTE: In production, use z00z_utils::time::TimeProvider for dependency injection
let time_provider = SystemTimeProvider::default();
let seed = time_provider.unix_timestamp();
let r = Scalar::from(seed);  // Attacker can brute-force

// ❌ WRONG: User-provided input (attacker-controlled)
let r = Scalar::from_bytes_mod_order(user_bytes);  // Malicious r
```

**Consequences of Weak RNG:**

- **r predictable** → Attacker computes `k_dh` → Decrypts `enc_pack` → Amount leak
- **r repeats** → Same `R_pub` → Outputs linkable
- **r_out predictable** → Commitment hiding broken → Amount leak

**Hedged Randomness (RECOMMENDED for r):**

Combine RNG output with deterministic secret to protect against RNG failures:

```rust
pub fn generate_hedged_r(
    sender_salt: &[u8; 32],  // Long-lived sender secret
    tx_digest: &[u8; 32],    // Transaction-specific context
    out_index: u32,          // Output index (uniqueness)
) -> Scalar {
    // Fresh randomness from OS
    let mut rng_bytes = [0u8; 32];
    OsRng.fill_bytes(&mut rng_bytes);
    
    // Combine: rng || secret || context || index
    let mut input = Vec::with_capacity(32 + 32 + 32 + 4);
    input.extend_from_slice(&rng_bytes);
    input.extend_from_slice(sender_salt);
    input.extend_from_slice(tx_digest);
    input.extend_from_slice(&out_index.to_le_bytes());
    
    // Hash-to-scalar (domain separated)
    hash_zk::poseidon2_h2scalar(b"Z00Z/R", &[&input])
}
```

**Hedging Properties:**
- If RNG good: Uniformly random `r` (via hash of random input)
- If RNG fails (constant output): `sender_salt || tx_digest || out_index` ensures uniqueness
- If `sender_salt` leaks: RNG randomness still protects unpredictability

> ⚠️ **PRODUCTION CODE ARCHITECTURE NOTE**
> 
> **In production code, use `z00z_utils::rng::RngProvider` abstraction instead of direct `OsRng`:**
> - ✅ `SystemRngProvider` - Production RNG (wraps `OsRng`)
> - ✅ `DeterministicRngProvider` - Testing with reproducible seeds
> - ✅ Enables dependency injection and mocking in tests
> 
> **Example:**
> ```rust
> use z00z_utils::rng::{RngProvider, SystemRngProvider};
> use rand::RngCore;
> 
> let provider = SystemRngProvider::default();
> let mut rng = provider.rng();
> rng.fill_bytes(&mut buffer);
> ```
> 
> **Throughout this SPEC, examples use `OsRng` directly for simplicity.**

**Non-Zero Check (MUST for r):**

```rust
let r = Scalar::random(&mut OsRng);

// Probability of r == 0 is ~1/2^252 (negligible)
// But check defensively:
if r == Scalar::ZERO {
    // Regenerate (or return error if using hedged generation)
    r = Scalar::random(&mut OsRng);
}

assert_ne!(r, Scalar::ZERO, "Ephemeral scalar must be non-zero");
```

**Hash-to-Scalar (for Derived Keys):**

For deterministic key derivation (view_sk, identity_sk), use hash-to-scalar:

```rust
pub fn derive_view_sk(receiver_secret: &[u8; 32]) -> Scalar {
    hash_zk::poseidon2_h2scalar(b"Z00Z/VIEW", &[receiver_secret])
    // Output is uniformly distributed (hash is good PRF)
    // Zero check unnecessary (probability negligible)
}
```

**Blinding Factor Generation:**

```rust
// For Pedersen commitment: C = v*H + r_out*G
let r_out = Scalar::random(&mut OsRng);

// Zero blinding is valid (C = v*H, no hiding)
// But SHOULD use non-zero for privacy:
let r_out = loop {
    let candidate = Scalar::random(&mut OsRng);
    if candidate != Scalar::ZERO {
        break candidate;
    }
};
```

**Testing Scalar Generation:**

```rust
#[test]
fn test_scalars_are_unique() {
    let mut seen = HashSet::new();
    for _ in 0..10000 {
        let r = Scalar::random(&mut OsRng);
        let bytes = r.to_bytes();
        assert!(seen.insert(bytes), "Duplicate scalar generated");
    }
}

#[test]
fn test_scalars_are_non_zero() {
    for _ in 0..10000 {
        let r = Scalar::random(&mut OsRng);
        assert_ne!(r, Scalar::ZERO, "Generated zero scalar");
    }
}
```

#### 2.1.3.3 Identity Point Rejection

**Why Identity Must Be Rejected:**

The identity point (point at infinity, neutral element) is **cryptographically valid** but **protocol-breaking** for stealth addresses.

**Identity Encoding:**

```rust
// Identity point compresses to 32 zero bytes
let identity = RistrettoPoint::identity();
let bytes = identity.compress().to_bytes();
assert_eq!(bytes, [0u8; 32]);
```

**Attack Scenario 1: Universal Linkability**

```rust
// Attacker creates output with R_pub = identity
let malicious_R = RistrettoPoint::identity();

// ALL receivers compute same ECDH shared secret:
let alice_dh = alice_view_sk * malicious_R;  // = identity
let bob_dh = bob_view_sk * malicious_R;      // = identity

// Result: alice_dh == bob_dh == identity
// k_dh = H(identity) is SAME for everyone
// owner_tag, enc_pack keys are UNIVERSAL
// → Massive linkability, potential decryption by anyone monitoring
```

**Attack Scenario 2: Predictable k_dh**

```rust
// Attacker observes R_pub = identity in leaf
// Computes k_dh without knowing ANY receiver keys:
let k_dh_universal = hash_zk::poseidon2_hash(
    b"Z00Z/DH",
    &[RistrettoPoint::identity().compress().as_bytes()]
);

// Attacker can now:
// 1. Compute owner_tag for ANY owner_handle (test all known receivers)
// 2. Attempt decryption of enc_pack (if protocol allows)
// 3. Link all outputs with same R_pub = identity
```

**Attack Scenario 3: Sender Self-Deanonymization**

```rust
// Malicious sender sets view_pk = identity in ReceiverCard
// When honest sender creates output:
let dh = r * identity_view_pk;  // = identity

// Result: Predictable k_dh, leaks sender's outputs
// Malicious directory can recognize "their" ReceiverCard usage
```

**Validation Rule (MUST):**

```rust
pub fn validate_point_not_identity(point: &RistrettoPoint) -> Result<()> {
    if point.is_identity() {
        return Err(Error::IdentityPointNotAllowed);
    }
    Ok(())
}

// Apply to ALL untrusted points:
pub fn validate_receiver_card(card: &ReceiverCard) -> Result<()> {
    validate_point_not_identity(&card.view_pk)?;
    Ok(())
}

pub fn validate_utxo_leaf(leaf: &UtxoLeaf) -> Result<()> {
    validate_point_not_identity(&leaf.R_pub)?;
    // C_amount = identity is rare but valid (zero commitment with r_out=0)
    // MAY skip identity check for commitments in some contexts
    Ok(())
}
```

**When Identity is Valid:**

Identity point is valid (and necessary) in these contexts:
- **Neutral element in sums:** `point + (-point) = identity`
- **Zero commitment:** `C = 0*H + 0*G = identity` (reveals amount is zero)
- **Proof system internals:** Intermediate computations

**But MUST reject for:**
- `view_pk` (ReceiverCard)
- `R_pub` (UtxoLeaf ephemeral key)
- `identity_pk` (if used for signatures)

**Alternative Check (Compressed Form):**

```rust
pub fn is_identity_compressed(bytes: &[u8; 32]) -> bool {
    bytes == &[0u8; 32]
}

// Use before decompression (faster, avoids decompression cost):
if is_identity_compressed(point_bytes) {
    return Err(Error::IdentityPointNotAllowed);
}
let point = safe_decompress_point(point_bytes)?;
```

**Testing Identity Rejection:**

```rust
#[test]
fn test_identity_detection() {
    let identity = RistrettoPoint::identity();
    assert!(identity.is_identity());
    
    let compressed = identity.compress().to_bytes();
    assert_eq!(compressed, [0u8; 32]);
}

#[test]
fn test_reject_identity_in_receiver_card() {
    let bad_card = ReceiverCard {
        owner_handle: [1u8; 32],
        view_pk: RistrettoPoint::identity(),  // Invalid
    };
    
    assert!(validate_receiver_card(&bad_card).is_err());
}

#[test]
fn test_reject_identity_r_pub() {
    let bad_leaf = UtxoLeaf {
        R_pub: RistrettoPoint::identity(),  // Invalid
        // ...
    };
    
    assert!(validate_utxo_leaf(&bad_leaf).is_err());
}

#[test]
fn test_non_identity_points_accepted() {
    let valid_point = Scalar::random(&mut OsRng) * &RISTRETTO_BASEPOINT_TABLE;
    assert!(!valid_point.is_identity());
    assert!(validate_point_not_identity(&valid_point).is_ok());
}
```

**OWF Circuit Enforcement:**

The OWF proof SHOULD include identity check as constraint:

```rust
// Pseudo-constraint in OWF circuit:
// assert!(R_pub != identity)
// Implementation: Check R_pub.compress() != [0; 32]
```

This prevents malicious proofs even if wallet validation bypassed.

## 2.2 Hash Functions & Domain Separation

### 2.2.1 Hash Policy Architecture

**Critical Design Decision:** The system uses **TWO distinct hash functions** with strict separation of concerns.

**H_zk (Consensus Hash) - Poseidon2/Goldilocks:**
- Field-native sponge hash for STARK/FRI proof system
- Used for ALL consensus-critical derivations
- Must be identical in wallet and proof engine

**H_wallet (Wallet Hash) - Blake2b:**
- Fast cryptographic hash for wallet-only operations
- Used for seed derivation, internal DB, local caching
- NOT used for anything verified in proofs

**Violation Consequences:**
- Using H_wallet for consensus fields → **proof verification FAILS** (wallet-proof drift)
- Using H_zk for wallet-only operations → performance penalty but no security issue

**Enforcement Strategy:**
- Separate modules: `hash_zk.rs` (Poseidon2) and `hash_wallet.rs` (Blake2b)
- Type system: `ConsensusHash32` vs `WalletHash32` newtypes
- Compile-time checks where possible
- Runtime domain string prefixes ("Z00Z/*" for consensus)
- Code review: all "H(domain, ...)" calls must be audited

**Hash Policy Table:**

| Operation | Hash Function | Rationale |
|-----------|---------------|----------|
| owner_handle derivation | **H_zk** | Verified in TxProof spend constraints |
| view_sk derivation | **H_zk** | Linked to receiver_secret in proof |
| k_dh from ECDH point | **H_zk** | Used in OWF constraints |
| owner_tag | **H_zk** | Verified in spend, recomputed in receive |
| asset_id | **H_zk** | JMT key, verified in proofs |
| leaf_ad | **H_zk** | AEAD binding, part of OWF |
| pack_key, nonce, tag | **H_zk** | ZkPack_v1 AEAD verified in OWF |
| tx_digest (if in proof) | **H_zk** | Public input to TxProof |
| BIP32/39 seed derivation | **H_wallet** | Wallet-internal, never in proof |
| DB record IDs | **H_wallet** | Wallet-internal |
| Local caches | **H_wallet** | Performance optimization |

**Why This Matters:**

Bitwise hash functions (Blake2b, SHA-2, SHA-3) are **expensive in ZK proofs** because they operate on bits, requiring O(10^6) constraints for a single hash. Field-native hash functions (Poseidon2) operate on field elements directly, requiring O(10^2) constraints.

If we used Blake2b for consensus-critical derivations, either:
1. We'd taint Blake2b constraints into STARK (100x-1000x blowup), OR
2. We'd accept derivations as unconstrained witnesses (massive security hole)

Poseidon2 is designed for exactly this use case: efficient verification in algebraic proof systems.

#### 2.2.1.1 Consensus Hash (H_zk)

**Poseidon2 for ZK-friendly hashing** - Field-native sponge construction over Goldilocks field (p = 2^64 - 2^32 + 1).

##### 2.2.1.1.1 Usage in Proofs (**MUST**)

**MUST use H_zk for:**
- `owner_handle = H_zk("Z00Z/RID" || receiver_secret)`
- `view_sk = H2Scalar_zk("Z00Z/VIEW" || receiver_secret)` (hash-to-scalar using Poseidon2)
- `k_dh = H_zk("Z00Z/DH" || Encode(dh_point))`
- `owner_tag = H_zk("Z00Z/TAG" || owner_handle || k_dh)`
- `asset_id` as the canonical public asset key used in leafs and JMT-facing proofs
- `leaf_ad = H_zk("Z00Z/LEAFAD" || asset_id || serial_id || R || owner_tag || C_amount)`
- `pack_key = H_zk("Z00Z/PACKKEY" || k_dh || asset_id || serial_id)`
- `nonce = H_zk("Z00Z/PACKNONCE" || leaf_ad || R || asset_id || serial_id)`
- `tag = H_zk("Z00Z/PACKTAG" || pack_key || nonce || leaf_ad || ciphertext || len)`
- `tag16 = Trunc16(H_zk("Z00Z/TAG16" || k_dh || leaf_ad))`
- All fields that appear in TxProof or CheckpointProof public inputs

**Rationale:** These operations are verified inside STARK/FRI proofs. Using bitwise hash would cause 100x-1000x constraint blowup.

##### 2.2.1.1.2 Domain Registry for H_zk

See §2.2.2 for complete domain string registry.

#### 2.2.1.2 Wallet Hash (H_wallet)

**Blake2b for wallet operations** - Fast, standard cryptographic hash for non-consensus operations.

##### 2.2.1.2.1 Usage Outside Consensus (**MAY**)

**MAY use H_wallet for:**
- BIP32/BIP39/BIP44 seed derivations (if using HD wallet structure)
- Internal database record IDs (coin_id, tx_id for local tracking)
- Local caches (leaf_hash → "already scanned" flag)
- Wallet-internal key derivation paths
- Audit logs, debug traces (never log secrets!)

**MUST NOT use H_wallet for:**
- Any value that will be verified in TxProof or CheckpointProof
- Any value that is consensus-critical
- Any derivation from receiver_secret that affects on-chain behavior

##### 2.2.1.2.2 When to Use H_wallet (**Decision Tree**)

```
Q: Will this value be verified inside a STARK/FRI proof?
├─ YES → Use H_zk (Poseidon2)
└─ NO
   ├─ Q: Could it indirectly affect consensus (e.g., key derivation)?
   │  ├─ YES → Use H_zk (safer choice)
   │  └─ NO → MAY use H_wallet (Blake2b)
   └─ When in doubt → Use H_zk
```

**Example Edge Cases:**
- `tx_digest` for wallet tracking (no proof) → H_wallet OK
- `tx_digest` as TxProof public input → **MUST** use H_zk
- Ephemeral r derivation via hedging (H-3) → H_zk (affects R_pub in proof)

#### 2.2.1.3 Hash Policy Enforcement (**MUST**)

**Implementation Requirements:**

1. **Module Separation:**
   ```rust
   // z00z_crypto/src/hash_zk.rs
   pub fn poseidon2_hash(domain: &'static [u8], data: &[&[u8]]) -> [u8; 32]
   
   // z00z_crypto/src/hash_wallet.rs  
   pub fn blake2b_hash(domain: &'static [u8], data: &[&[u8]]) -> [u8; 32]
   ```

2. **Type Safety (SHOULD):**
   ```rust
   pub struct ConsensusHash32([u8; 32]);  // H_zk output
   pub struct WalletHash32([u8; 32]);     // H_wallet output
   // Cannot accidentally mix
   ```

3. **Domain Prefix Convention:**
   - Consensus domains: `"Z00Z/*"` (e.g., "Z00Z/RID", "Z00Z/ASSET")
   - Wallet domains: `"WALLET/*"` (e.g., "WALLET/DBID", "WALLET/BIP32")
   - Never use `"Z00Z/*"` with H_wallet

4. **Code Review Checklist:**
   - [ ] All `H("Z00Z/*", ...)` calls use H_zk (Poseidon2)
   - [ ] All proof-verified derivations use H_zk
   - [ ] No H_wallet in `proofs/`, `owf.rs`, `spend.rs` modules
   - [ ] Golden test vectors specify which hash function

5. **Negative Test (MUST):**
   ```rust
   #[test]
   fn test_hash_policy_violation_detection() {
       // This MUST fail (cannot use H_wallet for owner_handle)
       let wrong = blake2b_hash(b"Z00Z/RID", &[receiver_secret]);
       let right = poseidon2_hash(b"Z00Z/RID", &[receiver_secret]);
       assert_ne!(wrong, right); // Different hash functions
       
       // Proof verification would fail if wallet used wrong hash
   }
   ```

6. **Documentation (MUST):**
   - Every hash call MUST have comment: `// H_zk: consensus-critical` or `// H_wallet: local only`
   - API docs MUST specify which hash function
   - Migration guides MUST highlight hash function changes

### 2.2.2 Hash Domain Registry (**MUST**)

**Single Source of Truth for Domain Separation Strings**

All domain strings MUST be registered here. Changes require review. Collision prevention via centralized registry.

#### 2.2.2.1 Core Domains

**Receiver Identity & Keys:**
- **Z00Z/R** - Hedged ephemeral scalar generation: `r = H2Scalar_zk("Z00Z/R" || rng_bytes || sender_secret_salt || tx_digest || out_index)`
- **Z00Z/RID** - Receiver identifier (owner_handle): `owner_handle = H_zk("Z00Z/RID" || receiver_secret)`
- **Z00Z/VIEW** - View key derivation: `view_sk = H2Scalar_zk("Z00Z/VIEW" || receiver_secret)`

**ECDH & Symmetric Keys:**
- **Z00Z/DH** - ECDH to symmetric key: `k_dh = H_zk("Z00Z/DH" || Encode(dh_point))`
- **Z00Z/K_DH** - (Deprecated, use Z00Z/DH) Alternative KDF domain

**Ownership & Tags:**
- **Z00Z/OWNER_TAG** - (Alias for Z00Z/TAG) Owner tag derivation
- **Z00Z/TAG** - Owner tag: `owner_tag = H_zk("Z00Z/TAG" || owner_handle || k_dh)`
- **Z00Z/TAG16** - Scan accelerator: `tag16 = Trunc16(H_zk("Z00Z/TAG16" || k_dh || leaf_ad))`

**Assets & Leaves:**
- **Z00Z/ASSET** - Secret-tag / ownership-side derivation domain used for secret-bound asset tagging; public JMT/state keys remain `asset_id`
- **Z00Z/LEAFAD** - Leaf associated data: `leaf_ad = H_zk("Z00Z/LEAFAD" || asset_id || serial_id || R || owner_tag || C_amount)`
- **Z00Z/LEAFHASH** - Leaf hash for JMT: `leaf_hash = H_zk("Z00Z/LEAFHASH" || canonical_encode(leaf))`

**ZkPack AEAD (Poseidon2-based):**
- **Z00Z/ZKPACK** - ZkPack sponge initialization domain
- **Z00Z/PACKKEY** - Pack encryption key: `pack_key = H_zk("Z00Z/PACKKEY" || k_dh || asset_id || serial_id)`
- **Z00Z/PACKNONCE** - Pack nonce: `nonce = H_zk("Z00Z/PACKNONCE" || leaf_ad || R || asset_id || serial_id)`
- **Z00Z/PACKSTR** - Pack keystream domain for XOF blocks
- **Z00Z/PACKTAG** - Pack authentication tag: `tag = H_zk("Z00Z/PACKTAG" || pack_key || nonce || leaf_ad || ciphertext || len)`
- **Z00Z/XOFBLK** - XOF block generation for stream cipher: `block_i = H_zk("Z00Z/XOFBLK" || stream_domain || key || nonce || counter_i)`
- **Z00Z/PACK_AD** - (Deprecated, use Z00Z/LEAFAD) Alternative AD domain
- **Z00Z/PACK_NONCE** - (Deprecated, use Z00Z/PACKNONCE)

**Transactions & Proofs:**
- **Z00Z/TXDIGEST** - Transaction digest: `tx_digest = H_zk("Z00Z/TXDIGEST" || CanonicalEncode(TxPackage minus proof))`
- **Z00Z/TXPROOF/V1** - TxProof Fiat-Shamir transcript initialization: `Transcript::new(b"Z00Z/TXPROOF/V1")`
- **Z00Z/CHECKPOINT/V1** - CheckpointProof Fiat-Shamir transcript: `Transcript::new(b"Z00Z/CHECKPOINT/V1")`

**Identity & Requests:**
- **Z00Z/REQv1** - PaymentRequest signature: `Sign(identity_sk, H_zk("Z00Z/REQv1" || canonical_fields))`
- **Z00Z/RCARD** - ReceiverCard signature: `Sign(identity_sk, H_wallet("Z00Z/RCARD" || canonical(card)))` (Note: uses H_wallet as this is pre-consensus)

**Reserved / Future:**
- **Z00Z/OWN_HANDLE** - (Alias for Z00Z/RID) For clarity in some contexts

#### 2.2.2.2 Domain Collision Prevention (**MUST**)

**Naming Conventions:**
1. Prefix: Always start with `Z00Z/`
2. Alphanumeric + underscore only: `[A-Z0-9_/]`
3. Hierarchical: Use `/` for sub-domains (e.g., `Z00Z/TXPROOF/V1`)
4. Version suffixes: `/V1`, `/V2` for versioned domains
5. No substring ambiguity: `Z00Z/TAG` and `Z00Z/TAG16` are OK because neither is prefix of other in a way that causes confusion

**Registration Process:**
1. Check this registry for existing domains
2. Propose new domain in design doc / pull request
3. Ensure no collisions or confusing similarity
4. Add to this section with description and formula
5. Add golden test vectors (§2.2.2.3)

**Forbidden:**
- Reusing domain strings for different purposes
- Omitting domain separation (always include domain, never raw hash)
- Using variable-length domains without length prefix

#### 2.2.2.3 Golden Test Vectors (**MUST**)

**Minimum 3 test vectors per domain.** See §14.4 for complete test vector specifications.

**Example vector format:**
```yaml
Z00Z/RID:
  vector_1:
    receiver_secret: 0x0000000000000000000000000000000000000000000000000000000000000000
    expected_owner_handle: 0x... (32 bytes, Poseidon2 output)
  vector_2:
    receiver_secret: 0xFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF
    expected_owner_handle: 0x...
  vector_3:
    receiver_secret: 0x0123456789ABCDEF0123456789ABCDEF0123456789ABCDEF0123456789ABCDEF
    expected_owner_handle: 0x...
```

**Cross-Implementation Validation:**
- Wallet implementation and proof engine MUST produce identical outputs
- Vectors MUST be deterministic and reproducible
- Any drift indicates hash policy violation or implementation bug

**Test Coverage:**
- Edge cases: all-zeros, all-ones, sequential patterns
- Normal cases: random-looking inputs
- Boundary cases: maximum field values (for Poseidon2)

### 2.2.3 Hash-to-Scalar (H2Scalar)

**Canonical Hash-to-Scalar Construction:**

Hash-to-Scalar (H2Scalar) converts a hash output (32 bytes) into a valid scalar for Ristretto255. Used for deriving secret keys from hashes.

**Purpose:**
- Derive `view_sk` from `receiver_secret`
- Generate hedged ephemeral `r` from hash
- Any deterministic scalar derivation from hash output

**Construction (MUST):**

```rust
pub fn h2scalar_zk(domain: &'static [u8], data: &[&[u8]]) -> Scalar {
    // Step 1: Hash to 32 bytes using H_zk (Poseidon2)
    let hash: [u8; 32] = poseidon2_hash(domain, data);
    
    // Step 2: Reduce modulo curve order ℓ
    Scalar::from_bytes_mod_order(hash)
}
```

**Key Properties:**

1. **Uniform Distribution (Statistical):**
   - Hash output is uniform over {0,1}^256
   - Reduction mod ℓ ≈ 2^252.5 introduces negligible bias
   - Bias ≈ 2^(-3.5) ≈ 0.088 → statistically insignificant

2. **Deterministic:**
   - Same input always produces same scalar
   - Critical for key derivation (view_sk must be reproducible)

3. **One-Way:**
   - Cannot reverse: given scalar, cannot find preimage
   - Security based on hash preimage resistance

**Usage Example (view_sk derivation):**

```rust
// Derive view secret key from receiver_secret
pub fn derive_view_sk(receiver_secret: &[u8; 32]) -> Scalar {
    h2scalar_zk(b"Z00Z/VIEW", &[receiver_secret])
}

// Derive view public key
pub fn derive_view_pk(view_sk: &Scalar) -> RistrettoPoint {
    view_sk * &RISTRETTO_BASEPOINT_TABLE
}
```

**Why Not Hash-to-Curve:**

Hash-to-curve (hash → point) is more complex and not needed here:
- We hash to **scalars** (private keys), not points
- Scalars are simpler: just reduce hash mod order
- Hash-to-curve needed for public randomness (not our use case)

#### 2.2.3.1 Field Reduction

**Modular Reduction into Scalar Field:**

Ristretto255 uses Curve25519's scalar field:
- **Order ℓ:** 2^252 + 27742317777372353535851937790883648493 (prime)
- **Bit length:** ~252.5 bits

**Reduction Methods:**

1. **Canonical Reduction (from_canonical_bytes):**
   ```rust
   // Only accepts bytes < ℓ (canonical)
   let scalar_opt = Scalar::from_canonical_bytes(bytes);
   if scalar_opt.is_none() {
       return Err(Error::NonCanonicalScalar);
   }
   ```
   
   **Use when:** Consensus-critical, need exact value validation
   **Example:** Verifying scalar in proof, parsing transaction fields

2. **Modular Reduction (from_bytes_mod_order):**
   ```rust
   // Accepts any 32 bytes, reduces mod ℓ
   let scalar = Scalar::from_bytes_mod_order(bytes);
   // Always succeeds
   ```
   
   **Use when:** Hash output, random generation, key derivation
   **Example:** `view_sk = H2Scalar(receiver_secret)` ← THIS ONE

**Why Modular Reduction is Safe for H2Scalar:**

- Hash output is uniformly random over 2^256
- Curve order ℓ ≈ 2^252.5
- Rejection region: [ℓ, 2^256) ≈ 2^3.5 values
- Bias: Pr[scalar < 2^252.5 - 2^256] ≈ 2^(-3.5) / 2^252.5 → negligible

**Statistical Bias Analysis:**

```
Ideal: Each scalar ∈ [0, ℓ) has probability 1/ℓ
Actual: Some scalars have probability (1 + ε)/ℓ where ε ≈ 2^(-3.5)
Distinguishing advantage: ε / 2 ≈ 2^(-4.5) ≈ 0.044 → undetectable
```

**Implementation:**

```rust
impl Scalar {
    pub fn from_bytes_mod_order(bytes: [u8; 32]) -> Scalar {
        // curve25519-dalek implementation:
        // 1. Interpret bytes as 256-bit little-endian integer
        // 2. Reduce mod ℓ using Barrett reduction
        // 3. Return scalar ∈ [0, ℓ)
    }
}
```

**When NOT to Use Modular Reduction:**

```rust
// ❌ WRONG: User-controlled scalar (enables bias attacks)
let user_scalar = Scalar::from_bytes_mod_order(user_input);
// Attacker can choose inputs to hit specific scalar range

// ✅ CORRECT: Use canonical encoding for untrusted input
let user_scalar = Scalar::from_canonical_bytes(user_input)
    .ok_or(Error::NonCanonicalScalar)?;
```

#### 2.2.3.2 Test Vectors

**H2Scalar Verification Vectors:**

These vectors ensure consistent implementation across wallet and proof systems.

**Test Vector Format:**

```rust
struct H2ScalarTestVector {
    domain: &'static [u8],
    input: &'static [u8],
    expected_scalar_bytes: [u8; 32],  // Little-endian
}
```

**Golden Vectors (MUST):**

```rust
// Vector 1: Zero input
const VECTOR_1: H2ScalarTestVector = H2ScalarTestVector {
    domain: b"Z00Z/VIEW",
    input: &[0u8; 32],
    expected_scalar_bytes: [
        // TBD: Fill with actual Poseidon2 hash output reduced mod ℓ
        // Example placeholder (replace with real computation):
        0x3a, 0x5f, 0x92, 0x1c, /* ... 28 more bytes ... */
    ],
};

// Vector 2: Sequential bytes
const VECTOR_2: H2ScalarTestVector = H2ScalarTestVector {
    domain: b"Z00Z/VIEW",
    input: &[
        0x00, 0x01, 0x02, 0x03, 0x04, 0x05, 0x06, 0x07,
        0x08, 0x09, 0x0a, 0x0b, 0x0c, 0x0d, 0x0e, 0x0f,
        0x10, 0x11, 0x12, 0x13, 0x14, 0x15, 0x16, 0x17,
        0x18, 0x19, 0x1a, 0x1b, 0x1c, 0x1d, 0x1e, 0x1f,
    ],
    expected_scalar_bytes: [
        // TBD: Fill with actual computation
    ],
};

// Vector 3: All-ones input (boundary case)
const VECTOR_3: H2ScalarTestVector = H2ScalarTestVector {
    domain: b"Z00Z/VIEW",
    input: &[0xffu8; 32],
    expected_scalar_bytes: [
        // TBD: Fill with actual computation
    ],
};

// Vector 4: Known receiver_secret (Alice test vector)
const VECTOR_4: H2ScalarTestVector = H2ScalarTestVector {
    domain: b"Z00Z/VIEW",
    input: &[
        // Alice's test receiver_secret from §14.4
        0xa1, 0x1c, 0xe0, /* ... (use golden test vector value) ... */
    ],
    expected_scalar_bytes: [
        // TBD: Compute view_sk for Alice test vector
    ],
};
```

**Test Implementation:**

```rust
#[test]
fn test_h2scalar_golden_vectors() {
    for (i, vector) in [VECTOR_1, VECTOR_2, VECTOR_3, VECTOR_4].iter().enumerate() {
        let scalar = h2scalar_zk(vector.domain, &[vector.input]);
        let actual_bytes = scalar.to_bytes();
        
        assert_eq!(
            actual_bytes,
            vector.expected_scalar_bytes,
            "Vector {} failed: H2Scalar mismatch",
            i + 1
        );
    }
}

#[test]
fn test_h2scalar_deterministic() {
    let input = b"test input";
    let scalar1 = h2scalar_zk(b"Z00Z/TEST", &[input]);
    let scalar2 = h2scalar_zk(b"Z00Z/TEST", &[input]);
    
    assert_eq!(scalar1, scalar2, "H2Scalar must be deterministic");
}

#[test]
fn test_h2scalar_domain_separation() {
    let input = &[0x42u8; 32];
    let scalar1 = h2scalar_zk(b"Z00Z/VIEW", &[input]);
    let scalar2 = h2scalar_zk(b"Z00Z/IDENTITY", &[input]);
    
    assert_ne!(scalar1, scalar2, "Different domains must produce different scalars");
}

#[test]
fn test_h2scalar_never_zero() {
    // Statistical test: very low probability of zero
    let mut found_zero = false;
    for i in 0..10000 {
        let input = i.to_le_bytes();
        let scalar = h2scalar_zk(b"Z00Z/TEST", &[&input]);
        if scalar == Scalar::ZERO {
            found_zero = true;
            break;
        }
    }
    
    // Probability ~1/2^252, should not happen in 10k iterations
    assert!(!found_zero, "Found zero scalar (astronomically unlikely)");
}
```

**Cross-Implementation Validation:**

```rust
#[test]
fn test_h2scalar_matches_proof_gadget() {
    // This test should be run against proof engine output
    // 1. Wallet computes: view_sk = H2Scalar(receiver_secret)
    // 2. Proof gadget computes same derivation
    // 3. Both must produce identical scalar bytes
    
    let receiver_secret = [0x42u8; 32];
    let wallet_view_sk = h2scalar_zk(b"Z00Z/VIEW", &[&receiver_secret]);
    
    // TBD: Compare with proof engine output
    // let proof_view_sk_bytes = proof_engine::derive_view_sk(&receiver_secret);
    // assert_eq!(wallet_view_sk.to_bytes(), proof_view_sk_bytes);
}
```

### 2.2.4 Hash Function Integration

**TBD** - Integration with z00z_crypto::hash module

#### 2.2.4.1 Poseidon2 Implementation (**MUST**)

**Field:** Goldilocks (p = 2^64 - 2^32 + 1 = 18446744069414584321)

**Parameters:**
- **Width (state size):** 12 field elements
- **Rate:** 8 field elements (absorbed per permutation)
- **Capacity:** 4 field elements (security parameter)
- **Rounds:**
  - Full rounds (beginning): 4
  - Partial rounds: 22  
  - Full rounds (end): 4
  - **Total:** 30 rounds

**Security Level:**
- Classical: 128-bit collision/preimage resistance
- Quantum: 64-bit (Grover speedup)

**Reference Implementation:**
- Primary: `plonky2` crate Poseidon2 module
- Alternative: `qp-poseidon-core` (already provides `hash_padded_bytes::<{FIELD_ELEMENT_PREIMAGE_PADDING_LEN}>(&bytes)`)
- Padding constant: `FIELD_ELEMENT_PREIMAGE_PADDING_LEN = 189` field elements

**Canonical Bytes-to-Felts Packing (**MUST**):**

```yaml
BytesToFelts_v1(MUST):
  limb_bits: 32
  limb_endianness: little
  chunking:
    - Split input bytes into 4-byte chunks (u32 LE)
    - Each chunk becomes one Goldilocks field element
    - For 32-byte input: 8 field elements (8 * 4 = 32 bytes)
  variable_length_rule:
    - Absorb (len_u32_le) first, then bytes
  fixed_length_rule:
    - For 32-byte items (hashes/points/secrets): exactly 8 limbs
  domain_separation:
    - Encode domain string length (u16 LE) + domain bytes
    - Then encode each data part with length prefix

Hash32FromSponge_v1(MUST):
  1. Initialize sponge state to zero
  2. Absorb domain separator as bytes (with u16 LE length prefix)
  3. Absorb data parts using BytesToFelts_v1
  4. Apply permutation
  5. Squeeze 32 bytes (canonical encoding from field elements)
```

**Preimage Format Example:**
```
H_zk("Z00Z/RID", receiver_secret):
  Preimage bytes:
    [0x08, 0x00]                    // domain len = 8 (u16 LE)
    [0x5A, 0x30, 0x30, 0x5A, 0x2F, 0x52, 0x49, 0x44]  // "Z00Z/RID"
    [0x20, 0x00, 0x00, 0x00]        // data len = 32 (u32 LE)
    [receiver_secret 32 bytes]       // actual data
  
  Convert to field elements (8 limbs of u32 LE from receiver_secret)
  Apply Poseidon2 permutation
  Squeeze to 32 bytes output
```

**Implementation Notes:**
- Use `qp-poseidon-core::hash_padded_bytes::<189>(&preimage)` for simplicity
- Padding length 189 ensures consistent behavior across implementations
- MUST match proof engine gadget bit-for-bit

**Golden Vectors (**MUST**):**
```yaml
Poseidon2_Goldilocks_test_vectors:
  test_1_empty:
    input: b"" (empty)
    domain: b"Z00Z/TEST"
    expected_output: 0x... (TBD: run reference implementation)
  
  test_2_zeros:
    input: [0x00; 32]
    domain: b"Z00Z/RID"
    expected_output: 0x... (TBD)
  
  test_3_ones:
    input: [0xFF; 32]
    domain: b"Z00Z/RID"
    expected_output: 0x...
  
  test_4_sequential:
    input: 0x0123456789ABCDEF... (32 bytes)
    domain: b"Z00Z/ASSET"
    expected_output: 0x...
```

**Cross-Implementation Consistency (**MUST**):**
- Wallet Rust code and STARK proof gadget MUST produce identical outputs
- Single bit difference indicates implementation drift
- Negative test: Intentionally use wrong padding → MUST detect

#### 2.2.4.2 Blake2b Integration

**Integration with Existing z00z_crypto::hash Module:**

Blake2b is already integrated via the existing `z00z_crypto/src/hash.rs` module using Tari's hashing infrastructure.

**Current Implementation:**

```rust
// z00z_crypto/src/hash.rs (EXISTING)
// NOTE: In production, import through z00z_crypto exports, not directly from tari_crypto
use tari_crypto::hashing::DomainSeparatedHasher;
use blake2::Blake2b;

pub struct Z00zHasher;

impl DomainHasher for Z00zHasher {
    fn hash_domain(domain: &str, data: &[&[u8]]) -> [u8; 32] {
        let mut hasher = Blake2b::<U32>::new();
        hasher.update(domain.as_bytes());
        for chunk in data {
            hasher.update(chunk);
        }
        hasher.finalize().into()
    }
}
```

**Usage for H_wallet (Wallet-Only Operations):**

```rust
// z00z_crypto/src/hash_wallet.rs (NEW - wrapper for clarity)
use crate::hash::Z00zHasher;

pub fn blake2b_hash(domain: &'static [u8], data: &[&[u8]]) -> [u8; 32] {
    let domain_str = std::str::from_utf8(domain)
        .expect("Domain must be valid UTF-8");
    Z00zHasher::hash_domain(domain_str, data)
}

// Convenience wrappers for common wallet operations:

pub fn hash_wallet_seed(seed: &[u8]) -> [u8; 32] {
    blake2b_hash(b"WALLET/SEED", &[seed])
}

pub fn hash_db_record_id(record_type: &str, key: &[u8]) -> [u8; 32] {
    blake2b_hash(
        b"WALLET/DB_ID",
        &[record_type.as_bytes(), key]
    )
}

pub fn hash_cache_key(leaf_hash: &[u8; 32]) -> [u8; 32] {
    blake2b_hash(b"WALLET/CACHE", &[leaf_hash])
}
```

**Domain Conventions for H_wallet:**

Wallet-only domains use `"WALLET/*"` prefix (NOT `"Z00Z/*"`):

```rust
const WALLET_DOMAINS: &[&str] = &[
    "WALLET/SEED",          // BIP39/HD seed derivation
    "WALLET/DB_ID",         // Database record identifiers
    "WALLET/CACHE",         // Scan cache keys
    "WALLET/BIP32",         // BIP32 derivation (if used)
    "WALLET/SESSION",       // Session key derivation
    "WALLET/BACKUP",        // Backup encryption keys
];
```

**Critical Rule (MUST NOT):**

Blake2b MUST NOT be used for any consensus-critical operation:

```rust
// ❌ WRONG: Using Blake2b for consensus field
let owner_handle = blake2b_hash(b"Z00Z/RID", &[receiver_secret]);
// This will FAIL in OWF circuit (expects Poseidon2)

// ✅ CORRECT: Use Poseidon2 for consensus
let owner_handle = poseidon2_hash(b"Z00Z/RID", &[receiver_secret]);
```

**Performance Characteristics:**

- **Throughput:** ~1 GB/s on modern CPUs
- **Latency:** <1 microsecond for 32-byte input
- **Memory:** Minimal (64-byte state)
- **Comparison to Poseidon2:**
  - Blake2b: 10-100x faster for wallet operations
  - Poseidon2: 100-1000x more efficient in ZK circuits

**Use Cases (Wallet-Only):**

1. **Seed Management:**
   ```rust
   // Derive wallet seed from mnemonic (not consensus)
   let mnemonic_bytes = bip39::decode_mnemonic(words)?;
   let wallet_seed = blake2b_hash(b"WALLET/SEED", &[&mnemonic_bytes]);
   ```

2. **Database Indexing:**
   ```rust
   // Generate unique ID for local coin record
   let coin_db_id = blake2b_hash(
       b"WALLET/DB_ID",
       &[b"coin", &asset_id, &serial_id.to_le_bytes()]
   );
   ```

3. **Scan Caching:**
   ```rust
   // Track already-scanned leaves (performance optimization)
   let cache_key = blake2b_hash(b"WALLET/CACHE", &[&leaf_hash]);
   if already_scanned.contains(&cache_key) {
       continue;  // Skip re-processing
   }
   ```

4. **Session Keys (Optional):**
   ```rust
   // Ephemeral session key for UI/API authentication
   let session_key = blake2b_hash(
       b"WALLET/SESSION",
       &[&user_id, &timestamp.to_le_bytes(), &nonce]
   );
   ```

**Migration from Existing Code:**

Existing code using `DomainHasher` can continue as-is. New code SHOULD use explicit `hash_wallet.rs` for clarity:

```rust
// Old style (still works):
// NOTE: In production, use z00z_crypto exports instead of direct tari_crypto imports
use tari_crypto::hashing::DomainSeparatedHasher;
let hash = Blake2b::hash(domain, data);

// New style (preferred for clarity):
use z00z_crypto::hash_wallet;
let hash = hash_wallet::blake2b_hash(domain, data);
```

**Testing:**

```rust
#[test]
fn test_blake2b_produces_32_bytes() {
    let hash = blake2b_hash(b"WALLET/TEST", &[b"data"]);
    assert_eq!(hash.len(), 32);
}

#[test]
fn test_blake2b_deterministic() {
    let hash1 = blake2b_hash(b"WALLET/TEST", &[b"data"]);
    let hash2 = blake2b_hash(b"WALLET/TEST", &[b"data"]);
    assert_eq!(hash1, hash2);
}

#[test]
fn test_blake2b_domain_separation() {
    let hash1 = blake2b_hash(b"WALLET/TEST1", &[b"data"]);
    let hash2 = blake2b_hash(b"WALLET/TEST2", &[b"data"]);
    assert_ne!(hash1, hash2);
}

#[test]
fn test_blake2b_not_used_for_consensus() {
    // Negative test: Ensure consensus domains use Poseidon2
    // This is a policy test, not a runtime check
    
    const CONSENSUS_DOMAINS: &[&[u8]] = &[
        b"Z00Z/RID",
        b"Z00Z/VIEW",
        b"Z00Z/ASSET",
        // ... (all Z00Z/* domains)
    ];
    
    // Verify these domains are NOT in blake2b_hash code paths
    // (Enforced by code review and type system)
}
```

**Type Safety (Recommended):**

To prevent accidental misuse, consider newtypes:

```rust
pub struct ConsensusHash([u8; 32]);  // From Poseidon2 only
pub struct WalletHash([u8; 32]);     // From Blake2b only

impl ConsensusHash {
    pub fn from_poseidon2(bytes: [u8; 32]) -> Self {
        ConsensusHash(bytes)
    }
}

impl WalletHash {
    pub fn from_blake2b(bytes: [u8; 32]) -> Self {
        WalletHash(bytes)
    }
}

// Now mixing is compile error:
fn process_consensus(hash: ConsensusHash) { /* ... */ }
let wallet_hash = WalletHash::from_blake2b(/* ... */);
// process_consensus(wallet_hash);  // ❌ Type error!
```

## 2.3 Pedersen Commitments

**Purpose:** Hide asset values in commitments while enabling range proofs and balance verification.

**Integration:** Leverage existing `backend_tari.rs` Pedersen commitment infrastructure for Z00Z wallet operations.

### 2.3.1 Commitment Scheme

**Pedersen Commitment Construction:**

$$C = vH + rG$$

Where:
- `v`: Value (asset amount) ∈ [0, 2^64)
- `r`: Blinding factor (random scalar)
- `H`: Value base point (Ristretto255)
- `G`: Standard Ristretto basepoint
- `C`: Commitment point (hides `v` with randomness `r`)

**Properties:**

1. **Hiding:** Given `C`, cannot determine `v` without knowing `r` (computational assumption: discrete log)
2. **Binding:** Cannot find `v', r'` such that `C = v'H + r'G` for `v' ≠ v` (except with negligible probability)
3. **Homomorphic:** `C₁ + C₂ = (v₁ + v₂)H + (r₁ + r₂)G` (enables balance proofs)

**Usage in Z00Z Wallet:**

```rust
// Commit to asset value for transaction output
let value: u64 = 1000;  // 1000 units
let blinding = Scalar::random(&mut OsRng);  // Cryptographically random
let commitment = commit_value(value, &blinding);

// commitment is stored in blockchain (value hidden)
// (value, blinding) kept in wallet database (private)
```

**Existing Implementation:**

The `z00z_crypto/src/backend_tari.rs` already provides Pedersen commitments via Tari's `ExtendedPedersenCommitmentFactory`:

```rust
// backend_tari.rs (EXISTING)
// NOTE: Internal z00z_crypto implementation - use PedersenCommitmentFactory from z00z_crypto
use tari_crypto::commitment::ExtendedCommitmentFactory;

pub static COMMITMENT_FACTORY: Lazy<ExtendedPedersenCommitmentFactory> = Lazy::new(|| {
    ExtendedPedersenCommitmentFactory::default()
});

// Usage (EXISTING):
pub fn commit(value: u64, blinding: &Scalar) -> RistrettoPoint {
    COMMITMENT_FACTORY.commit_value(&RistrettoSecretKey::from(*blinding), value)
}
```

#### 2.3.1.1 Generator Points

**Generator Point Selection:**

Pedersen commitments require two independent generator points `G` and `H` such that the discrete logarithm relationship `H = αG` is unknown:

1. **G (Standard Base):**
   - Ristretto255 canonical basepoint
   - `G = CompressedRistretto([0x58, 0x66, ...])` (standard curve25519-dalek constant)
   - Used for blinding factor `r`

2. **H (Value Base):**
   - Generated using hash-to-curve from domain-separated hash
   - Ensures `log_G(H)` is unknown (no trusted setup)
   - Derived deterministically (verifiable by all parties)

**Tari's H Generation (from backend_tari.rs):**

```rust
// Simplified (actual implementation in tari_crypto)
const RISTRETTO_PEDERSEN_H_LABEL: &str = "com.tari.pedersen.h";

fn generate_h() -> RistrettoPoint {
    RistrettoPoint::from_uniform_bytes(
        &blake3::hash(RISTRETTO_PEDERSEN_H_LABEL.as_bytes()).as_bytes()
    )
}
```

**Properties Required (MUST):**

1. **Independence:** No known scalar `α` such that `H = αG`
2. **Determinism:** Same `H` computed by all parties (no setup ceremony)
3. **Verifiability:** Anyone can verify `H` was correctly generated
4. **Non-Zero:** `H ≠ O` (identity point)

**Z00Z Integration:**

The wallet **MUST** use the same `H` generator as the existing backend:

```rust
use z00z_crypto::backend_tari::COMMITMENT_FACTORY;

// This ensures consensus on generator points
let h_generator = COMMITMENT_FACTORY.H_base();
let g_generator = COMMITMENT_FACTORY.G_base();
```

**Testing Generator Points:**

```rust
#[test]
fn test_generators_independent() {
    let g = &RISTRETTO_BASEPOINT_POINT;
    let h = COMMITMENT_FACTORY.H_base();
    
    // H should not be identity
    assert_ne!(h, RistrettoPoint::identity());
    
    // H should not equal G
    assert_ne!(h, *g);
    
    // Cannot test log_G(H) unknown (impossible to verify negative)
    // but deterministic generation ensures this property
}

#[test]
fn test_h_deterministic() {
    // H must be same across all wallet instances
    let h1 = generate_h();  // First computation
    let h2 = generate_h();  // Second computation
    assert_eq!(h1, h2);
}

#[test]
fn test_h_verifiable() {
    // Anyone can recompute H from specification
    let expected_h = RistrettoPoint::from_uniform_bytes(
        blake3::hash(b"com.tari.pedersen.h").as_bytes()
    );
    let actual_h = COMMITMENT_FACTORY.H_base();
    assert_eq!(actual_h, expected_h);
}
```

#### 2.3.1.2 Blinding Factor Generation

**Blinding Factor Requirements:**

The blinding factor `r` MUST be:
1. **Uniformly random** over scalar field [0, ℓ)
2. **Cryptographically unpredictable** (uses CS-RNG)
3. **Never reused** (unique for each commitment)
4. **Securely stored** (enables commitment opening)

**Generation Methods:**

**Method 1: True Randomness (Standard):**

```rust
use rand_core::OsRng;
use curve25519_dalek::scalar::Scalar;

pub fn generate_blinding_factor() -> Scalar {
    Scalar::random(&mut OsRng)
}

// Usage:
let r = generate_blinding_factor();
let commitment = commit_value(value, &r);
```

**Properties:**
- ✅ Cryptographically secure (uses OS entropy)
- ✅ Unpredictable to adversaries
- ✅ Simple implementation
- ❌ Non-deterministic (different each call)

**Method 2: Deterministic Derivation (Backup/Restore):**

For wallet recovery scenarios, may derive `r` from master seed:

```rust
use hkdf::Hkdf;
use sha2::Sha256;

pub fn derive_blinding_factor(
    master_seed: &[u8; 32],
    coin_index: u64,
) -> Scalar {
    let hkdf = Hkdf::<Sha256>::new(None, master_seed);
    let mut okm = [0u8; 32];
    let info = format!("Z00Z-blinding-{}", coin_index);
    hkdf.expand(info.as_bytes(), &mut okm)
        .expect("HKDF expand failed");
    
    Scalar::from_bytes_mod_order(okm)
}
```

**Properties:**
- ✅ Deterministic (enables backup/restore)
- ✅ Still cryptographically random
- ⚠️ **Risk:** Master seed compromise reveals all blinding factors
- **Use case:** HD wallet schemes, backup scenarios

**Recommended Hybrid Approach:**

```rust
pub struct BlindingFactorGenerator {
    master_seed: Option<[u8; 32]>,  // For deterministic mode
}

impl BlindingFactorGenerator {
    pub fn new_random() -> Self {
        Self { master_seed: None }
    }
    
    pub fn new_deterministic(seed: [u8; 32]) -> Self {
        Self { master_seed: Some(seed) }
    }
    
    pub fn generate(&self, coin_index: u64) -> Scalar {
        match self.master_seed {
            None => Scalar::random(&mut OsRng),  // True randomness
            Some(seed) => derive_blinding_factor(&seed, coin_index),  // Deterministic
        }
    }
}

// Default: use true randomness
let generator = BlindingFactorGenerator::new_random();
let r = generator.generate(0);  // index ignored for random mode
```

**Security Requirements (MUST):**

1. **Never Reuse:**
   ```rust
   // ❌ WRONG: Reusing blinding factor
   let r = generate_blinding_factor();
   let c1 = commit_value(100, &r);
   let c2 = commit_value(200, &r);  // INSECURE!
   // Reveals: c2 - c1 = (200 - 100)H = 100H → value difference leaked
   
   // ✅ CORRECT: Fresh blinding factor per commitment
   let r1 = generate_blinding_factor();
   let r2 = generate_blinding_factor();
   let c1 = commit_value(100, &r1);
   let c2 = commit_value(200, &r2);
   ```

2. **Proper RNG:**
   ```rust
   // ❌ WRONG: Weak RNG
   use rand::thread_rng;
   let r = Scalar::random(&mut thread_rng());  // NOT cryptographically secure
   
   // ✅ CORRECT: Use OsRng
   use rand_core::OsRng;
   let r = Scalar::random(&mut OsRng);
   ```

3. **Zeroization:**
   ```rust
   use zeroize::Zeroizing;
   
   fn commit_and_forget(value: u64) -> RistrettoPoint {
       let r = Zeroizing::new(generate_blinding_factor());
       let commitment = commit_value(value, &*r);
       // r is zeroized when dropped
       commitment
   }
   ```

**Testing:**

```rust
#[test]
fn test_blinding_factor_randomness() {
    let r1 = generate_blinding_factor();
    let r2 = generate_blinding_factor();
    
    // Two random scalars should be different (prob ≈ 1)
    assert_ne!(r1, r2);
}

#[test]
fn test_blinding_factor_valid() {
    let r = generate_blinding_factor();
    
    // Should be non-zero (prob 1 - 2^-252)
    assert_ne!(r, Scalar::ZERO);
    
    // Should be in valid range
    let bytes = r.to_bytes();
    assert_eq!(bytes.len(), 32);
}

#[test]
fn test_deterministic_derivation_consistency() {
    let seed = [0x42u8; 32];
    let r1 = derive_blinding_factor(&seed, 0);
    let r2 = derive_blinding_factor(&seed, 0);
    
    assert_eq!(r1, r2, "Deterministic derivation must be consistent");
}

#[test]
fn test_different_indices_different_blindings() {
    let seed = [0x42u8; 32];
    let r1 = derive_blinding_factor(&seed, 0);
    let r2 = derive_blinding_factor(&seed, 1);
    
    assert_ne!(r1, r2, "Different indices must produce different blindings");
}
```

### 2.3.2 Commitment API

**Commitment Interface:**

The wallet MUST provide a clean API for creating and managing Pedersen commitments, wrapping the existing `backend_tari.rs` functionality.

```rust
// z00z_wallets/src/crypto/commitment.rs (NEW)
use z00z_crypto::backend_tari::COMMITMENT_FACTORY;
use curve25519_dalek::{ristretto::RistrettoPoint, scalar::Scalar};
use rand_core::OsRng;

pub struct PedersenCommitment {
    pub commitment: RistrettoPoint,  // C = vH + rG
    pub value: u64,                   // v (kept private in wallet)
    pub blinding: Scalar,             // r (kept private in wallet)
}

impl PedersenCommitment {
    /// Create new commitment with random blinding factor
    pub fn new(value: u64) -> Self {
        let blinding = Scalar::random(&mut OsRng);
        let commitment = COMMITMENT_FACTORY.commit_value(
            &blinding.into(),
            value
        );
        
        Self { commitment, value, blinding }
    }
    
    /// Create commitment with specified blinding factor
    pub fn new_with_blinding(value: u64, blinding: Scalar) -> Self {
        let commitment = COMMITMENT_FACTORY.commit_value(
            &blinding.into(),
            value
        );
        
        Self { commitment, value, blinding }
    }
    
    /// Serialize commitment point (for blockchain storage)
    pub fn to_bytes(&self) -> [u8; 32] {
        self.commitment.compress().to_bytes()
    }
    
    /// Deserialize commitment point
    pub fn from_bytes(bytes: &[u8; 32]) -> Result<RistrettoPoint, Error> {
        CompressedRistretto::from_slice(bytes)
            .decompress()
            .ok_or(Error::InvalidCommitment)
    }
}
```

#### 2.3.2.1 Trait Definition

**PedersenCommit Trait:**

Define a trait for commitment operations to enable testing and alternative implementations:

```rust
pub trait PedersenCommit {
    /// Commit to a value with blinding factor
    fn commit(&self, value: u64, blinding: &Scalar) -> RistrettoPoint;
    
    /// Verify commitment opening
    fn verify_opening(
        &self,
        commitment: &RistrettoPoint,
        value: u64,
        blinding: &Scalar,
    ) -> bool;
    
    /// Get H generator
    fn h_base(&self) -> RistrettoPoint;
    
    /// Get G generator
    fn g_base(&self) -> RistrettoPoint;
}

impl PedersenCommit for ExtendedPedersenCommitmentFactory {
    fn commit(&self, value: u64, blinding: &Scalar) -> RistrettoPoint {
        self.commit_value(&blinding.into(), value)
    }
    
    fn verify_opening(
        &self,
        commitment: &RistrettoPoint,
        value: u64,
        blinding: &Scalar,
    ) -> bool {
        let recomputed = self.commit(value, blinding);
        recomputed == *commitment
    }
    
    fn h_base(&self) -> RistrettoPoint {
        self.H_base().clone()
    }
    
    fn g_base(&self) -> RistrettoPoint {
        &RISTRETTO_BASEPOINT_POINT.clone()
    }
}
```

**Benefits:**
- Mockable for unit tests
- Swappable implementations (e.g., GPU-accelerated)
- Clear contract for commitment operations

#### 2.3.2.2 Implementation

**Integration with Existing types.rs:**

Add commitment types to `z00z_crypto/src/types.rs`:

```rust
// z00z_crypto/src/types.rs (ADDITIONS)

use curve25519_dalek::ristretto::{RistrettoPoint, CompressedRistretto};
use serde::{Serialize, Deserialize};

/// Pedersen commitment (public, stored on-chain)
#[derive(Clone, Copy, Debug, PartialEq, Eq, Serialize, Deserialize)]
pub struct Commitment(pub RistrettoPoint);

impl Commitment {
    pub fn new(point: RistrettoPoint) -> Self {
        Self(point)
    }
    
    pub fn to_bytes(&self) -> [u8; 32] {
        self.0.compress().to_bytes()
    }
    
    pub fn from_bytes(bytes: &[u8; 32]) -> Result<Self, Error> {
        CompressedRistretto::from_slice(bytes)
            .decompress()
            .ok_or(Error::InvalidCommitment)
            .map(Self)
    }
    
    pub fn as_point(&self) -> &RistrettoPoint {
        &self.0
    }
}

/// Commitment opening (private, wallet only)
#[derive(Clone, Debug, Serialize, Deserialize)]
pub struct CommitmentOpening {
    pub value: u64,
    pub blinding: Scalar,
}

impl CommitmentOpening {
    pub fn new(value: u64, blinding: Scalar) -> Self {
        Self { value, blinding }
    }
    
    /// Compute commitment from opening
    pub fn to_commitment(&self) -> Commitment {
        let point = COMMITMENT_FACTORY.commit_value(
            &self.blinding.into(),
            self.value
        );
        Commitment::new(point)
    }
    
    /// Verify opening matches commitment
    pub fn verify(&self, commitment: &Commitment) -> bool {
        self.to_commitment() == *commitment
    }
}
```

**Usage in Wallet:**

```rust
// Create commitment for transaction output
let opening = CommitmentOpening::new(1000, Scalar::random(&mut OsRng));
let commitment = opening.to_commitment();

// Store commitment on blockchain
tx_output.commitment = commitment.to_bytes();

// Store opening in wallet database
wallet_db.store_commitment_opening(coin_id, &opening)?;

// Later: Verify opening still valid
assert!(opening.verify(&commitment));
```

### 2.3.3 Opening & Verification

**Commitment Opening:**

An opening reveals the hidden value `v` and blinding factor `r` for a commitment `C`.

**Verification Algorithm:**

```rust
pub fn verify_opening(
    commitment: &RistrettoPoint,
    value: u64,
    blinding: &Scalar,
) -> bool {
    // Recompute: C' = vH + rG
    let recomputed = COMMITMENT_FACTORY.commit_value(
        &blinding.into(),
        value
    );
    
    // Check: C == C'
    recomputed == *commitment
}
```

**Properties:**

1. **Completeness:** Valid opening always verifies
   ```rust
   let r = Scalar::random(&mut OsRng);
   let c = commit_value(100, &r);
   assert!(verify_opening(&c, 100, &r));  // Always true
   ```

2. **Soundness:** Invalid opening fails with overwhelming probability
   ```rust
   let r = Scalar::random(&mut OsRng);
   let c = commit_value(100, &r);
   let r_fake = Scalar::random(&mut OsRng);
   assert!(!verify_opening(&c, 100, &r_fake));  // False with prob 1 - 2^-252
   ```

3. **Binding:** Cannot find two different valid openings
   - If `verify_opening(C, v1, r1)` and `verify_opening(C, v2, r2)` both true
   - Then `v1 == v2` and `r1 == r2` (except with prob 2^-252)

**Use Cases:**

1. **Transaction Verification:**
   ```rust
   // Receiver verifies sender committed to claimed amount
   let claimed_value = 1000;
   if !verify_opening(&tx_commitment, claimed_value, &revealed_blinding) {
       return Err(Error::InvalidCommitmentOpening);
   }
   ```

2. **Balance Proof:**
   ```rust
   // Prove sum of inputs == sum of outputs
   // Sum of commitments: ΣC_in - ΣC_out
   // Must equal commitment to 0: 0·H + r_excess·G
   
   let excess_blinding = sum_input_blindings - sum_output_blindings;
   let excess_commitment = sum_input_commitments - sum_output_commitments;
   
   // Verify: excess_commitment == 0·H + excess_blinding·G
   assert!(verify_opening(&excess_commitment, 0, &excess_blinding));
   ```

3. **Audit/Recovery:**
   ```rust
   // Wallet audit: Verify all stored openings are valid
   for (coin_id, opening) in wallet_db.list_commitment_openings()? {
       let commitment = blockchain.get_commitment(coin_id)?;
       if !opening.verify(&commitment) {
           warn!("Coin {} has invalid opening!", coin_id);
       }
   }
   ```

**Testing:**

```rust
#[test]
fn test_opening_verification_valid() {
    let value = 12345u64;
    let blinding = Scalar::random(&mut OsRng);
    let commitment = commit_value(value, &blinding);
    
    assert!(verify_opening(&commitment, value, &blinding));
}

#[test]
fn test_opening_verification_wrong_value() {
    let value = 100u64;
    let blinding = Scalar::random(&mut OsRng);
    let commitment = commit_value(value, &blinding);
    
    assert!(!verify_opening(&commitment, 200, &blinding));
}

#[test]
fn test_opening_verification_wrong_blinding() {
    let value = 100u64;
    let blinding = Scalar::random(&mut OsRng);
    let commitment = commit_value(value, &blinding);
    
    let wrong_blinding = Scalar::random(&mut OsRng);
    assert!(!verify_opening(&commitment, value, &wrong_blinding));
}

#[test]
fn test_commitment_homomorphism() {
    let v1 = 100u64;
    let v2 = 200u64;
    let r1 = Scalar::random(&mut OsRng);
    let r2 = Scalar::random(&mut OsRng);
    
    let c1 = commit_value(v1, &r1);
    let c2 = commit_value(v2, &r2);
    
    // C1 + C2 = (v1 + v2)H + (r1 + r2)G
    let c_sum = c1 + c2;
    assert!(verify_opening(&c_sum, v1 + v2, &(r1 + r2)));
}
```

## 2.4 Range Proofs

**Purpose:** Prove value `v` in commitment `C = vH + rG` is in valid range [0, 2^64) without revealing `v`.

**Integration:** Leverage existing `backend_tari.rs` Bulletproofs+ infrastructure.

**Why Needed:**
- Pedersen commitments are homomorphic but allow negative values
- Without range proofs, could create money: `C_out = C_in + (-1000)H` appears balanced but destroys value
- Range proof ensures `v ∈ [0, 2^64)` → prevents inflation/deflation attacks

### 2.4.1 Bulletproofs+ Integration

**Bulletproofs+ Overview:**

- **Type:** Non-interactive zero-knowledge range proof
- **Size:** O(log n) for n-bit range (typically ~700 bytes for 64-bit)
- **Verification:** O(n) group operations (~3ms for 64-bit)
- **Aggregation:** Multiple range proofs can be batched for efficiency
- **No Trusted Setup:** Uses common reference string (CRS) only

**Existing Implementation:**

The `z00z_crypto/src/backend_tari.rs` already provides Bulletproofs+ via `BulletproofsPlusService`:

```rust
// backend_tari.rs (EXISTING)
// NOTE: Internal z00z_crypto implementation - use BulletproofsPlusService from z00z_crypto
use tari_crypto::range_proof::BulletproofsPlusService;

pub static BP_PLUS_SERVICE: Lazy<BulletproofsPlusService> = Lazy::new(|| {
    BulletproofsPlusService::init(64, 1, ExtendedPedersenCommitmentFactory::default())
        .expect("Failed to initialize Bulletproofs+ service")
});

// Lazy initialization saves ~10ms on wallet startup
```

**Parameters:**
- **Bit width:** 64 (supports values [0, 2^64))
- **Aggregation size:** 1 (can be increased for batch proving)
- **Commitment factory:** Shared Pedersen factory (ensures generator consistency)

#### 2.4.1.1 Proof Generation

**Generate Range Proof:**

```rust
use z00z_crypto::backend_tari::BP_PLUS_SERVICE;
// NOTE: In production, use z00z_crypto exports for proof generation
use tari_crypto::range_proof::RangeProofService;

pub fn generate_range_proof(
    value: u64,
    blinding: &Scalar,
) -> Result<Vec<u8>, Error> {
    // 1. Create Pedersen commitment
    let commitment = commit_value(value, blinding);
    
    // 2. Generate Bulletproofs+ proof
    let proof = BP_PLUS_SERVICE
        .construct_proof(&blinding.into(), value)
        .map_err(|e| Error::RangeProofGeneration(e))?;
    
    // 3. Serialize proof
    Ok(proof.to_bytes())
}
```

**Proof Structure:**

```rust
pub struct RangeProof {
    pub commitment: RistrettoPoint,  // C = vH + rG
    pub proof_bytes: Vec<u8>,         // Bulletproofs+ proof (~700 bytes)
}

impl RangeProof {
    pub fn new(value: u64, blinding: Scalar) -> Result<Self, Error> {
        let commitment = commit_value(value, &blinding);
        let proof_bytes = generate_range_proof(value, &blinding)?;
        
        Ok(Self { commitment, proof_bytes })
    }
    
    pub fn size_bytes(&self) -> usize {
        32 + self.proof_bytes.len()  // commitment + proof
    }
}
```

**Performance:**

- **Proving time:** ~5-10ms per 64-bit value on modern CPU
- **Proof size:** ~700 bytes (single value), ~900 bytes (batched 2 values)
- **Memory:** <1 MB temporary allocation

**Example Usage:**

```rust
// Generate range proof for transaction output
let value = 1000u64;
let blinding = Scalar::random(&mut OsRng);

let start = Instant::now();
let range_proof = RangeProof::new(value, blinding)?;
println!("Proof generation: {:?}", start.elapsed());  // ~5-10ms

println!("Proof size: {} bytes", range_proof.size_bytes());  // ~732 bytes

// Store proof with commitment
tx_output.commitment = range_proof.commitment.compress().to_bytes();
tx_output.range_proof = range_proof.proof_bytes;
```

**Aggregated Proofs (Optional Optimization):**

```rust
pub fn generate_aggregated_proof(
    values: &[u64],
    blindings: &[Scalar],
) -> Result<Vec<u8>, Error> {
    assert_eq!(values.len(), blindings.len());
    
    // Bulletproofs+ supports efficient aggregation
    // Proof size: ~700 + 100·(n-1) bytes for n values
    let proof = BP_PLUS_SERVICE
        .construct_proof_batch(
            &blindings.iter().map(|b| b.into()).collect::<Vec<_>>(),
            values,
        )
        .map_err(|e| Error::RangeProofGeneration(e))?;
    
    Ok(proof.to_bytes())
}

// Example: Prove 3 outputs in single proof
let values = vec![100, 200, 300];
let blindings = vec![r1, r2, r3];
let aggregated_proof = generate_aggregated_proof(&values, &blindings)?;
// Size: ~900 bytes vs 3×700 = 2100 bytes (2.3x savings)
```

#### 2.4.1.2 Proof Verification

**Verify Range Proof:**

```rust
pub fn verify_range_proof(
    commitment: &RistrettoPoint,
    proof_bytes: &[u8],
) -> Result<bool, Error> {
    // Deserialize proof
    let proof = BulletproofsPlus::from_bytes(proof_bytes)
        .map_err(|e| Error::InvalidRangeProof(e))?;
    
    // Verify proof
    let result = BP_PLUS_SERVICE
        .verify(&proof, &[commitment.into()])
        .map_err(|e| Error::RangeProofVerification(e))?;
    
    Ok(result)
}
```

**Verifier Implementation:**

```rust
impl RangeProof {
    pub fn verify(&self) -> Result<bool, Error> {
        verify_range_proof(&self.commitment, &self.proof_bytes)
    }
}

// Usage:
let valid = range_proof.verify()?;
if !valid {
    return Err(Error::InvalidRangeProof);
}
```

**Performance:**

- **Verification time:** ~3-5ms per 64-bit proof
- **Memory:** <500 KB temporary allocation
- **Batch verification:** ~10-15ms for batch of 10 proofs (better amortized cost)

**Batch Verification (Optimization):**

```rust
pub fn verify_range_proofs_batch(
    proofs: &[(RistrettoPoint, Vec<u8>)],
) -> Result<Vec<bool>, Error> {
    let commitments: Vec<_> = proofs.iter()
        .map(|(c, _)| c.into())
        .collect();
    
    let bp_proofs: Vec<_> = proofs.iter()
        .map(|(_, p)| BulletproofsPlus::from_bytes(p))
        .collect::<Result<Vec<_>, _>>()?;
    
    // Batch verification is faster than individual
    let results = BP_PLUS_SERVICE
        .verify_batch(&bp_proofs, &commitments)
        .map_err(|e| Error::RangeProofVerification(e))?;
    
    Ok(results)
}

// Verify block of transactions (e.g., 100 outputs)
let proofs: Vec<_> = block_outputs.iter()
    .map(|out| (out.commitment, out.range_proof.clone()))
    .collect();

let start = Instant::now();
let results = verify_range_proofs_batch(&proofs)?;
println!("Verified {} proofs in {:?}", proofs.len(), start.elapsed());
// ~30-50ms for 100 proofs (vs ~300-500ms individual)
```

**Error Handling:**

```rust
#[derive(Debug, thiserror::Error)]
pub enum RangeProofError {
    #[error("Range proof generation failed: {0}")]
    Generation(String),
    
    #[error("Range proof verification failed: {0}")]
    Verification(String),
    
    #[error("Invalid proof format")]
    InvalidFormat,
    
    #[error("Value out of range [0, 2^64)")]
    ValueOutOfRange,
}

// Usage:
let proof = RangeProof::new(value, blinding)
    .map_err(|e| match e {
        Error::ValueOutOfRange => {
            // value >= 2^64 or value < 0
            Error::InvalidValue
        }
        _ => e,
    })?;
```

### 2.4.2 Range Proof API

**High-Level API:**

```rust
// z00z_wallets/src/crypto/range_proof.rs (NEW)
use z00z_crypto::backend_tari::{BP_PLUS_SERVICE, COMMITMENT_FACTORY};

pub trait RangeProofService {
    /// Generate range proof for value
    fn prove(&self, value: u64, blinding: &Scalar) -> Result<Vec<u8>, Error>;
    
    /// Verify range proof for commitment
    fn verify(&self, commitment: &RistrettoPoint, proof: &[u8]) -> Result<bool, Error>;
    
    /// Batch verify multiple proofs
    fn verify_batch(
        &self,
        commitments: &[RistrettoPoint],
        proofs: &[Vec<u8>],
    ) -> Result<Vec<bool>, Error>;
}

/// Default implementation using Bulletproofs+
pub struct BulletproofsRangeProof;

impl RangeProofService for BulletproofsRangeProof {
    fn prove(&self, value: u64, blinding: &Scalar) -> Result<Vec<u8>, Error> {
        let proof = BP_PLUS_SERVICE
            .construct_proof(&blinding.into(), value)?;
        Ok(proof.to_bytes())
    }
    
    fn verify(&self, commitment: &RistrettoPoint, proof: &[u8]) -> Result<bool, Error> {
        let bp_proof = BulletproofsPlus::from_bytes(proof)?;
        BP_PLUS_SERVICE.verify(&bp_proof, &[commitment.into()])
    }
    
    fn verify_batch(
        &self,
        commitments: &[RistrettoPoint],
        proofs: &[Vec<u8>],
    ) -> Result<Vec<bool>, Error> {
        let bp_proofs: Vec<_> = proofs.iter()
            .map(|p| BulletproofsPlus::from_bytes(p))
            .collect::<Result<Vec<_>, _>>()?;
        
        let commitment_refs: Vec<_> = commitments.iter()
            .map(|c| c.into())
            .collect();
        
        BP_PLUS_SERVICE.verify_batch(&bp_proofs, &commitment_refs)
    }
}
```

**Convenience Wrappers:**

```rust
/// Transaction output with range proof
pub struct OutputWithProof {
    pub value: u64,                   // Private (wallet only)
    pub blinding: Scalar,              // Private (wallet only)
    pub commitment: RistrettoPoint,    // Public
    // NOTE: In production, use z00z_crypto::Z00ZRangeProof type alias
    pub range_proof: Vec<u8>,          // Public
}

impl OutputWithProof {
    pub fn new(value: u64) -> Result<Self, Error> {
        let blinding = Scalar::random(&mut OsRng);
        let commitment = commit_value(value, &blinding);
        
        let range_proof_service = BulletproofsRangeProof;
        let range_proof = range_proof_service.prove(value, &blinding)?;
        
        Ok(Self {
            value,
            blinding,
            commitment,
            range_proof,
        })
    }
    
    pub fn verify(&self) -> Result<bool, Error> {
        let range_proof_service = BulletproofsRangeProof;
        range_proof_service.verify(&self.commitment, &self.range_proof)
    }
    
    pub fn to_bytes(&self) -> Vec<u8> {
        let mut bytes = Vec::with_capacity(32 + self.range_proof.len());
        bytes.extend_from_slice(&self.commitment.compress().to_bytes());
        bytes.extend_from_slice(&self.range_proof);
        bytes
    }
}
```

**Testing:**

```rust
#[test]
fn test_range_proof_valid_value() {
    let value = 1000u64;
    let blinding = Scalar::random(&mut OsRng);
    
    let proof_bytes = generate_range_proof(value, &blinding).unwrap();
    let commitment = commit_value(value, &blinding);
    
    assert!(verify_range_proof(&commitment, &proof_bytes).unwrap());
}

#[test]
fn test_range_proof_rejects_tampering() {
    let value = 1000u64;
    let blinding = Scalar::random(&mut OsRng);
    
    let proof_bytes = generate_range_proof(value, &blinding).unwrap();
    
    // Tamper with commitment
    let wrong_commitment = commit_value(2000, &blinding);
    
    assert!(!verify_range_proof(&wrong_commitment, &proof_bytes).unwrap());
}

#[test]
fn test_range_proof_max_value() {
    let value = u64::MAX;  // 2^64 - 1
    let blinding = Scalar::random(&mut OsRng);
    
    let proof = generate_range_proof(value, &blinding).unwrap();
    let commitment = commit_value(value, &blinding);
    
    assert!(verify_range_proof(&commitment, &proof).unwrap());
}

#[test]
fn test_range_proof_zero_value() {
    let value = 0u64;
    let blinding = Scalar::random(&mut OsRng);
    
    let proof = generate_range_proof(value, &blinding).unwrap();
    let commitment = commit_value(value, &blinding);
    
    assert!(verify_range_proof(&commitment, &proof).unwrap());
}

#[test]
fn test_range_proof_deterministic() {
    let value = 1000u64;
    let blinding = Scalar::from_bytes_mod_order([0x42u8; 32]);
    
    let proof1 = generate_range_proof(value, &blinding).unwrap();
    let proof2 = generate_range_proof(value, &blinding).unwrap();
    
    // Bulletproofs+ is deterministic for same inputs
    assert_eq!(proof1, proof2);
}

#[test]
fn test_batch_verification_performance() {
    let count = 100;
    let mut proofs = Vec::with_capacity(count);
    let mut commitments = Vec::with_capacity(count);
    
    // Generate 100 proofs
    for i in 0..count {
        let value = (i + 1) as u64 * 100;
        let blinding = Scalar::random(&mut OsRng);
        let commitment = commit_value(value, &blinding);
        let proof = generate_range_proof(value, &blinding).unwrap();
        
        commitments.push(commitment);
        proofs.push(proof);
    }
    
    // Batch verification
    let start = Instant::now();
    let results = verify_range_proofs_batch(
        &commitments.iter().zip(proofs.iter())
            .map(|(c, p)| (*c, p.clone()))
            .collect::<Vec<_>>()
    ).unwrap();
    let batch_time = start.elapsed();
    
    assert!(results.iter().all(|&r| r), "All proofs should verify");
    println!("Batch verification of {} proofs: {:?}", count, batch_time);
    
    // Should be significantly faster than individual verification
    // Expected: <50ms for batch vs ~300-500ms individual
    assert!(batch_time < Duration::from_millis(100));
}
```

**Integration Notes:**

1. **Transaction Construction:**
   ```rust
   // Creating transaction output
   let output = OutputWithProof::new(amount)?;
   tx.outputs.push(TxOutput {
       commitment: output.commitment.compress().to_bytes(),
       range_proof: output.range_proof,
   });
   
   // Store opening in wallet DB
   wallet_db.store_output_opening(output_id, output.value, output.blinding)?;
   ```

2. **Transaction Validation:**
   ```rust
   // Validator checks all outputs have valid range proofs
   for output in &tx.outputs {
       let commitment = RistrettoPoint::from_bytes(&output.commitment)?;
       if !verify_range_proof(&commitment, &output.range_proof)? {
           return Err(Error::InvalidRangeProof);
       }
   }
   ```

3. **Balance Verification:**
   ```rust
   // Prove transaction is balanced:
   // sum(inputs) - sum(outputs) - fee = 0
   
   let sum_input_values = inputs.iter().map(|i| i.value).sum::<u64>();
   let sum_output_values = outputs.iter().map(|o| o.value).sum::<u64>();
   
   assert_eq!(sum_input_values, sum_output_values + fee);
   
   // Cryptographic balance check (without revealing values):
   let sum_input_commitments: RistrettoPoint = inputs.iter()
       .map(|i| i.commitment)
       .sum();
   let sum_output_commitments: RistrettoPoint = outputs.iter()
       .map(|o| o.commitment)
       .sum();
   let fee_commitment = commit_value(fee, &Scalar::ZERO);  // Fee has no blinding
   
   let balance = sum_input_commitments - sum_output_commitments - fee_commitment;
   // balance should equal r_excess·G (commitment to zero with excess blinding)
   ```

## 2.5 ECDH (Elliptic Curve Diffie-Hellman)

**Purpose:** Enable unlinkable stealth addresses where sender and receiver derive shared secret without interactive protocol.

**Integration:** Core primitive for Z00Z stealth address protocol (ECDH-based, not PQ).

**Design Decision (Non-Goal):**
- This spec uses **classical ECC ECDH**, not post-quantum KEM (ML-KEM/Kyber)
- **Rationale:** PQ inbox confidentiality is explicitly a **non-goal** (see §1.3.3 Trust Assumptions)
- **Threat model:** "Harvest-now, decrypt-later" attacks on inbox content are **accepted risk**
- **What remains protected:** Ownership (requires `receiver_secret` preimage), state unlinkability, transaction validation
- **Why acceptable:** Inbox is helper-only, not consensus-critical; moneta in JMT regardless of inbox

### 2.5.1 ECDH Construction

**Shared Secret Derivation:**

ECDH on Ristretto255 provides unlinkable one-time shared secrets for stealth addresses:

```rust
// Sender (knows r, view_pk):
let dh_sender = r * view_pk;

// Receiver (knows view_sk, R_pub):
let dh_receiver = view_sk * R_pub;

// Property: dh_sender == dh_receiver (if R_pub = r * G)
```

**Key Properties:**

1. **Correctness:** `r * view_pk == view_sk * (r * G)` (bilinearity)
2. **Unlinkability:** Observer cannot link outputs without knowing `r` or `view_sk`
3. **Ephemerality:** Each output uses fresh `r` → unique `dh` → unique derived keys
4. **Non-interactive:** Sender derives `dh` using only receiver's public `view_pk`

**Security Assumption:**

- **Decisional Diffie-Hellman (DDH):** Given `(G, r*G, view_pk, r*view_pk)`, cannot distinguish `r*view_pk` from random point
- **Holds on Ristretto255** (prime-order group)
- **NOT post-quantum secure:** Shor's algorithm breaks DDH (~2030-2040 timeframe)

#### 2.5.1.1 Sender-Side ECDH

**Sender Computation:**

```rust
use curve25519_dalek::{
    ristretto::RistrettoPoint,
    scalar::Scalar,
    constants::RISTRETTO_BASEPOINT_TABLE,
};
use rand_core::OsRng;

pub fn sender_derive_dh(
    receiver_view_pk: &RistrettoPoint,
) -> Result<(Scalar, RistrettoPoint, RistrettoPoint), Error> {
    // Step 1: Generate ephemeral scalar r (MUST be hedged, see §2.5.1.1.1)
    let r = generate_ephemeral_r()?;
    
    // Step 2: Compute public ephemeral point R = r*G
    let R_pub = &r * &RISTRETTO_BASEPOINT_TABLE;
    
    // Step 3: Validate receiver's view_pk (MUST)
    validate_ecdh_point(receiver_view_pk)?;
    
    // Step 4: Compute shared secret dh = r * view_pk
    let dh = r * receiver_view_pk;
    
    // Step 5: Validate dh is not identity (MUST)
    if dh.is_identity() {
        return Err(Error::EcdhIdentityResult);
    }
    
    Ok((r, R_pub, dh))
}
```

**Critical Security Rules (MUST):**

1. **Hedged Randomness (H-3):**
   ```rust
   // ❌ WRONG: Pure RNG (vulnerable to RNG failures)
   let r = Scalar::random(&mut OsRng);
   
   // ✅ CORRECT: Hedged generation
   fn generate_ephemeral_r() -> Result<Scalar, Error> {
       let rng_bytes = {
           let mut buf = [0u8; 32];
           OsRng.fill_bytes(&mut buf);
           buf
       };
       
       let sender_salt = get_sender_secret_salt()?;  // Wallet-specific entropy
       let tx_context = get_tx_context_hash()?;      // Transaction binding
       
       // Combine sources: RNG + wallet salt + context
       let r_preimage = poseidon2_hash(
           b"Z00Z/R",
           &[&rng_bytes, &sender_salt, &tx_context]
       );
       
       Ok(Scalar::from_bytes_mod_order(r_preimage))
   }
   ```
   
   **Why critical:** RNG failures in production are **real** (mobile entropy bugs, VM snapshots, container misconfig). Hedging ensures:
   - If RNG weak → sender_salt saves uniqueness
   - If sender_salt leaks → RNG saves unpredictability

2. **Uniqueness Check (MUST):**
   ```rust
   // Maintain cache of recent R values per receiver
   struct RecentRCache {
       cache: HashMap<OwnerHandle, HashSet<CompressedRistretto>>,
   }
   
   impl RecentRCache {
       fn check_and_insert(&mut self, owner: OwnerHandle, R: CompressedRistretto) -> Result<(), Error> {
           let recent = self.cache.entry(owner).or_insert_with(HashSet::new);
           if recent.contains(&R) {
               return Err(Error::DuplicateEphemeralR);
           }
           recent.insert(R);
           Ok(())
       }
   }
   ```
   
   **Why critical:** R reuse → outputs linkable, k_dh reuse → owner_tag reuse → privacy catastrophe

3. **Point Validation (MUST):**
   ```rust
   fn validate_ecdh_point(point: &RistrettoPoint) -> Result<(), Error> {
       // Ristretto points are always valid if decompressed successfully
       // BUT must check for identity
       if point.is_identity() {
           return Err(Error::IdentityPoint);
       }
       Ok(())
   }
   ```

**Attack Scenarios:**

- **A1: RNG Failure + R Reuse:**
  - Wallet RNG produces same `r` twice for same receiver
  - Result: `R_pub` repeats → outputs trivially linkable
  - `k_dh` repeats → `owner_tag` repeats → all privacy lost
  - **Mitigation:** Hedged generation + uniqueness cache

- **A2: Identity Point Attack:**
  - Malicious receiver publishes `view_pk = O` (identity)
  - Result: `dh = r * O = O` for all `r`
  - All senders use same `k_dh` → mass linkability
  - **Mitigation:** Reject identity in validation

#### 2.5.1.2 Receiver-Side ECDH

**Receiver Computation:**

```rust
pub fn receiver_derive_dh(
    view_sk: &Scalar,
    R_pub: &RistrettoPoint,
) -> Result<RistrettoPoint, Error> {
    // Step 1: Validate R_pub from leaf (untrusted input)
    validate_ecdh_point(R_pub)?;
    
    // Step 2: Compute shared secret dh = view_sk * R_pub
    let dh = view_sk * R_pub;
    
    // Step 3: Validate result is not identity
    if dh.is_identity() {
        return Err(Error::EcdhIdentityResult);
    }
    
    Ok(dh)
}
```

**Key Difference from Sender:**

- **Receiver uses fixed `view_sk`** (derived from `receiver_secret`)
- **R_pub comes from untrusted leaf data** → MUST validate thoroughly
- **No uniqueness check needed** (receiver processes many R_pub values)

**Validation Requirements (MUST):**

```rust
// When scanning leaf from blockchain/state:
pub fn scan_leaf_for_ownership(
    view_sk: &Scalar,
    leaf: &UtxoLeaf,
) -> Result<Option<CoinRecord>, Error> {
    // Step 1: Parse R_pub from leaf (untrusted)
    let R_pub = CompressedRistretto::from_slice(&leaf.r_pub)
        .decompress()
        .ok_or(Error::InvalidRPub)?;  // ✅ Safe: returns None on invalid
    
    // Step 2: Validate before ECDH (MUST)
    if R_pub.is_identity() {
        return Ok(None);  // Not our coin (or attack attempt)
    }
    
    // Step 3: Compute dh
    let dh = receiver_derive_dh(view_sk, &R_pub)?;
    
    // Step 4: Derive k_dh and attempt decryption
    let k_dh = kdf_from_dh(&dh)?;
    
    // ... decrypt enc_pack, verify ownership tag ...
}
```

**Attack Scenarios:**

- **A3: Malformed R_pub (Buffer Overflow Attempt):**
  - Attacker puts invalid bytes in `leaf.r_pub`
  - Goal: Trigger `unwrap()` panic or buffer overflow
  - **Mitigation:** Use `decompress()` which returns `Option`, never `unwrap()`

- **A4: Identity R_pub (Wallet Freeze):**
  - Attacker creates many leaves with `R_pub = O`
  - Wallet computes `dh = view_sk * O = O` for all
  - All decrypt attempts fail, wasting CPU
  - **Mitigation:** Reject identity early, rate-limit scanning

#### 2.5.1.3 Shared Secret Equality

**Correctness Proof:**

Given:
- Sender ephemeral: `r ∈ ℤ_ℓ`
- Sender public: `R_pub = r * G`
- Receiver secret: `view_sk ∈ ℤ_ℓ`
- Receiver public: `view_pk = view_sk * G`

Prove: `dh_sender == dh_receiver`

**Algebraic Derivation:**

```
Sender computes:
  dh_sender = r * view_pk
            = r * (view_sk * G)
            = (r * view_sk) * G      [scalar multiplication associativity]

Receiver computes:
  dh_receiver = view_sk * R_pub
              = view_sk * (r * G)
              = (view_sk * r) * G    [scalar multiplication associativity]

Scalar multiplication is commutative in the exponent:
  r * view_sk == view_sk * r

Therefore:
  dh_sender = (r * view_sk) * G = (view_sk * r) * G = dh_receiver
```

**Implementation Test:**

```rust
#[test]
fn test_ecdh_shared_secret_equality() {
    // Setup receiver keys
    let receiver_secret = [0x42u8; 32];
    let view_sk = view_sk_from_receiver_secret(&receiver_secret);
    let view_pk = view_pk_from_view_sk(&view_sk);
    
    // Sender derives dh
    let (r, R_pub, dh_sender) = sender_derive_dh(&view_pk).unwrap();
    
    // Receiver derives dh
    let dh_receiver = receiver_derive_dh(&view_sk, &R_pub).unwrap();
    
    // Must be equal
    assert_eq!(dh_sender, dh_receiver);
}

#[test]
fn test_ecdh_different_r_different_dh() {
    let receiver_secret = [0x42u8; 32];
    let view_sk = view_sk_from_receiver_secret(&receiver_secret);
    let view_pk = view_pk_from_view_sk(&view_sk);
    
    let (r1, R1, dh1) = sender_derive_dh(&view_pk).unwrap();
    let (r2, R2, dh2) = sender_derive_dh(&view_pk).unwrap();
    
    // Different ephemeral scalars → different shared secrets
    assert_ne!(r1, r2);
    assert_ne!(R1, R2);
    assert_ne!(dh1, dh2);
}
```

### 2.5.2 ECDH API

**High-Level Trait:**

```rust
pub trait EcdhStealth {
    /// Sender: Generate ephemeral keypair and derive shared secret
    fn sender_ecdh(
        &self,
        receiver_view_pk: &RistrettoPoint,
    ) -> Result<EcdhSenderResult, Error>;
    
    /// Receiver: Derive shared secret from ephemeral public key
    fn receiver_ecdh(
        &self,
        view_sk: &Scalar,
        R_pub: &RistrettoPoint,
    ) -> Result<RistrettoPoint, Error>;
    
    /// Validate point before ECDH
    fn validate_point(&self, point: &RistrettoPoint) -> Result<(), Error>;
}

pub struct EcdhSenderResult {
    pub r: Scalar,           // Ephemeral scalar (private)
    pub R_pub: RistrettoPoint,  // Ephemeral public (in leaf)
    pub dh: RistrettoPoint,     // Shared secret
}

impl EcdhStealth for RistrettoEcdh {
    fn sender_ecdh(
        &self,
        receiver_view_pk: &RistrettoPoint,
    ) -> Result<EcdhSenderResult, Error> {
        self.validate_point(receiver_view_pk)?;
        
        let r = generate_ephemeral_r()?;
        let R_pub = &r * &RISTRETTO_BASEPOINT_TABLE;
        let dh = r * receiver_view_pk;
        
        self.validate_point(&dh)?;
        
        Ok(EcdhSenderResult { r, R_pub, dh })
    }
    
    fn receiver_ecdh(
        &self,
        view_sk: &Scalar,
        R_pub: &RistrettoPoint,
    ) -> Result<RistrettoPoint, Error> {
        self.validate_point(R_pub)?;
        
        let dh = view_sk * R_pub;
        
        self.validate_point(&dh)?;
        
        Ok(dh)
    }
    
    fn validate_point(&self, point: &RistrettoPoint) -> Result<(), Error> {
        if point.is_identity() {
            return Err(Error::IdentityPoint);
        }
        Ok(())
    }
}
```

#### 2.5.2.1 Input Validation

**Point Validation Rules (MUST):**

1. **Decompression Safety:**
   ```rust
   // ❌ WRONG: Unsafe decompression
   let point = CompressedRistretto::from_slice(bytes)
       .decompress()
       .expect("Valid point");  // PANIC on invalid input!
   
   // ✅ CORRECT: Safe decompression
   let point = CompressedRistretto::from_slice(bytes)
       .decompress()
       .ok_or(Error::InvalidPoint)?;
   ```

2. **Identity Rejection:**
   ```rust
   pub fn validate_ecdh_input(point: &RistrettoPoint) -> Result<(), Error> {
       if point.is_identity() {
           return Err(Error::IdentityPoint);
       }
       // Ristretto points are always in the prime-order subgroup
       // No additional cofactor checks needed
       Ok(())
   }
   ```

3. **Untrusted Input Handling:**
   ```rust
   pub fn parse_and_validate_R_pub(bytes: &[u8]) -> Result<RistrettoPoint, Error> {
       // Step 1: Check length
       if bytes.len() != 32 {
           return Err(Error::InvalidPointLength);
       }
       
       // Step 2: Safe decompression
       let point = CompressedRistretto::from_slice(bytes)
           .decompress()
           .ok_or(Error::InvalidPointEncoding)?;
       
       // Step 3: Identity check
       if point.is_identity() {
           return Err(Error::IdentityPoint);
       }
       
       Ok(point)
   }
   ```

**Testing:**

```rust
#[test]
fn test_validate_rejects_identity() {
    let identity = RistrettoPoint::identity();
    assert!(validate_ecdh_input(&identity).is_err());
}

#[test]
fn test_validate_accepts_valid_point() {
    let point = &Scalar::random(&mut OsRng) * &RISTRETTO_BASEPOINT_TABLE;
    assert!(validate_ecdh_input(&point).is_ok());
}

#[test]
fn test_parse_rejects_invalid_encoding() {
    let bad_bytes = [0xFFu8; 32];  // Invalid compressed point
    assert!(parse_and_validate_R_pub(&bad_bytes).is_err());
}

#[test]
fn test_parse_rejects_wrong_length() {
    let bad_bytes = [0u8; 16];  // Wrong length
    assert!(parse_and_validate_R_pub(&bad_bytes).is_err());
}
```

#### 2.5.2.2 Output Encoding

**Canonical DH Point Encoding:**

```rust
pub fn encode_dh_point(dh: &RistrettoPoint) -> [u8; 32] {
    dh.compress().to_bytes()
}

pub fn decode_dh_point(bytes: &[u8; 32]) -> Result<RistrettoPoint, Error> {
    CompressedRistretto::from_slice(bytes)
        .decompress()
        .ok_or(Error::InvalidDhPoint)
}
```

**Properties:**

1. **Deterministic:** Same point always encodes to same bytes
2. **Canonical:** Compressed Ristretto encoding (32 bytes)
3. **Unique:** Each point has exactly one valid encoding

**Usage in KDF:**

```rust
pub fn kdf_from_dh(dh: &RistrettoPoint) -> [u8; 32] {
    let dh_bytes = encode_dh_point(dh);
    poseidon2_hash(b"Z00Z/DH", &[&dh_bytes])
}
```

**Testing:**

```rust
#[test]
fn test_dh_encoding_deterministic() {
    let dh = &Scalar::random(&mut OsRng) * &RISTRETTO_BASEPOINT_TABLE;
    let enc1 = encode_dh_point(&dh);
    let enc2 = encode_dh_point(&dh);
    assert_eq!(enc1, enc2);
}

#[test]
fn test_dh_encoding_roundtrip() {
    let dh = &Scalar::random(&mut OsRng) * &RISTRETTO_BASEPOINT_TABLE;
    let bytes = encode_dh_point(&dh);
    let decoded = decode_dh_point(&bytes).unwrap();
    assert_eq!(dh, decoded);
}
```

## 2.6 Key Derivation Functions (KDF)

**Purpose:** Derive cryptographic keys from shared ECDH secrets and other high-entropy sources.

**Integration:** Uses existing `z00z_crypto/src/kdf.rs` module (HKDF-based) for wallet-side operations; H_zk (Poseidon2) for consensus-critical derivations.

### 2.6.1 KDF Construction

**Two-Tier KDF Policy:**

Following the hash policy (§2.2.1), KDF operations split by context:

```yaml
KDF_Policy:
  consensus_kdf: H_zk (Poseidon2-based)
    usage:
      - k_dh derivation from ECDH dh point
      - pack_key for enc_pack encryption
      - owner_tag derivation
      - Any key that appears in OWF constraints
    
  wallet_kdf: HKDF-SHA256 (from z00z_crypto::kdf)
    usage:
      - Master seed derivation
      - BIP32-style key chains (if needed)
      - Session keys, database encryption keys
      - Any wallet-local key (not in proofs)
```

**Design Rationale:**

- **H_zk for consensus:** OWF must prove correct key derivation → needs ZK-friendly hash
- **HKDF for wallet:** Standard, audited, fast for non-proof operations
- **No mixing:** Keys from H_zk KDF MUST NOT be used in wallet-only context (and vice versa)

#### 2.6.1.1 Domain-Separated KDF

**Consensus KDF (H_zk based):**

```rust
/// Derive key from ECDH shared secret (consensus-critical)
pub fn kdf_consensus(
    domain: &'static [u8],
    ikm: &[u8],           // Input keying material
    info: &[&[u8]],       // Context binding
) -> [u8; 32] {
    // Use Poseidon2 for ZK-friendly derivation
    let mut preimage = Vec::new();
    preimage.extend_from_slice(ikm);
    for part in info {
        preimage.extend_from_slice(part);
    }
    
    poseidon2_hash(domain, &[&preimage])
}

// Primary use case: k_dh from ECDH
pub fn derive_k_dh(dh_point: &RistrettoPoint) -> [u8; 32] {
    let dh_bytes = dh_point.compress().to_bytes();
    kdf_consensus(b"Z00Z/DH", &dh_bytes, &[])
}

// Derived keys from k_dh:
pub fn derive_pack_key(
    k_dh: &[u8; 32],
    asset_id: &[u8; 32],
    serial_id: u32,
) -> [u8; 32] {
    kdf_consensus(
        b"Z00Z/PACKKEY",
        k_dh,
        &[asset_id, &serial_id.to_le_bytes()]
    )
}

pub fn derive_pack_nonce(
    leaf_ad: &[u8; 32],
    R_pub: &RistrettoPoint,
    asset_id: &[u8; 32],
    serial_id: u32,
) -> [u8; 32] {
    let r_bytes = R_pub.compress().to_bytes();
    kdf_consensus(
        b"Z00Z/PACKNONCE",
        leaf_ad,
        &[&r_bytes, asset_id, &serial_id.to_le_bytes()]
    )
}
```

**Wallet KDF (HKDF-SHA256):**

```rust
use hkdf::Hkdf;
use sha2::Sha256;

/// Derive wallet-local key (NOT consensus-critical)
pub fn kdf_wallet(
    salt: Option<&[u8]>,
    ikm: &[u8],
    info: &[u8],
    okm_len: usize,
) -> Result<Vec<u8>, Error> {
    let hkdf = Hkdf::<Sha256>::new(salt, ikm);
    let mut okm = vec![0u8; okm_len];
    hkdf.expand(info, &mut okm)
        .map_err(|_| Error::KdfExpansionFailed)?;
    Ok(okm)
}

// Example: Derive wallet master key from mnemonic seed
pub fn derive_wallet_master_key(mnemonic_seed: &[u8; 64]) -> [u8; 32] {
    let mut okm = [0u8; 32];
    let hkdf = Hkdf::<Sha256>::new(Some(b"Z00Z-wallet-v1"), mnemonic_seed);
    hkdf.expand(b"master-key", &mut okm).expect("HKDF expansion");
    okm
}

// Example: Derive database encryption key
pub fn derive_db_encryption_key(master_key: &[u8; 32]) -> [u8; 32] {
    let mut okm = [0u8; 32];
    let hkdf = Hkdf::<Sha256>::new(Some(b"db-salt"), master_key);
    hkdf.expand(b"database-encryption", &mut okm).expect("HKDF expansion");
    okm
}
```

**Domain Separation Rules (MUST):**

1. **All domains MUST be unique** (registered in hash domain registry §2.2.2)
2. **Consensus domains MUST use "Z00Z/*" prefix**
3. **Wallet domains SHOULD use "WALLET/*" or custom prefix**
4. **Never mix H_zk and HKDF outputs** in same context

#### 2.6.1.2 Output Length

**Standard Output: 32 Bytes**

All KDF operations in Z00Z wallet produce **32-byte (256-bit) keys** as standard:

```rust
pub const KDF_OUTPUT_LEN: usize = 32;

pub type SymmetricKey = [u8; 32];
pub type DerivedKey = [u8; 32];
```

**Rationale:**

- **Uniform interface:** All crypto operations (AEAD, commitments, hashes) use 32-byte keys
- **Security margin:** 256 bits provides >>128-bit security (birthday bound ~2^128)
- **Alignment:** Matches hash output size (Poseidon2, Blake2b both produce 32 bytes)
- **Simplicity:** Fixed-size keys avoid length negotiation and padding

**Variable-Length KDF (Wallet Only):**

For wallet-specific needs (e.g., AES-256 + MAC key = 64 bytes):

```rust
pub fn kdf_wallet_variable(
    ikm: &[u8],
    info: &[u8],
    output_len: usize,
) -> Result<Vec<u8>, Error> {
    assert!(output_len <= 255 * 32);  // HKDF limit
    
    let hkdf = Hkdf::<Sha256>::new(None, ikm);
    let mut okm = vec![0u8; output_len];
    hkdf.expand(info, &mut okm)?;
    Ok(okm)
}

// Example: Derive separate encryption + MAC keys
pub fn derive_encrypt_and_mac_keys(master: &[u8; 32]) -> ([u8; 32], [u8; 32]) {
    let combined = kdf_wallet_variable(master, b"enc-mac", 64).unwrap();
    let mut enc_key = [0u8; 32];
    let mut mac_key = [0u8; 32];
    enc_key.copy_from_slice(&combined[0..32]);
    mac_key.copy_from_slice(&combined[32..64]);
    (enc_key, mac_key)
}
```

### 2.6.2 Symmetric Key Derivation

**Primary Use Case: k_dh from ECDH Shared Secret**

The most critical KDF operation in stealth address protocol:

```rust
/// Derive symmetric key from ECDH shared secret
pub fn derive_symmetric_key_from_ecdh(
    dh: &RistrettoPoint,
) -> SymmetricKey {
    // Encode DH point canonically
    let dh_bytes = dh.compress().to_bytes();
    
    // Derive k_dh using consensus KDF (H_zk)
    kdf_consensus(b"Z00Z/DH", &dh_bytes, &[])
}
```

**Complete Derivation Chain:**

```rust
pub struct StealthKeys {
    pub k_dh: SymmetricKey,        // Base key from ECDH
    pub pack_key: SymmetricKey,    // For enc_pack AEAD
    pub owner_tag: [u8; 32],       // Ownership marker
}

impl StealthKeys {
    pub fn derive(
        dh: &RistrettoPoint,
        owner_handle: &[u8; 32],
        asset_id: &[u8; 32],
        serial_id: u32,
    ) -> Self {
        // Step 1: Base key from ECDH
        let k_dh = derive_symmetric_key_from_ecdh(dh);
        
        // Step 2: Pack encryption key (asset-specific)
        let pack_key = derive_pack_key(&k_dh, asset_id, serial_id);
        
        // Step 3: Owner tag (unlinkable identifier)
        let owner_tag = poseidon2_hash(
            b"Z00Z/TAG",
            &[owner_handle, &k_dh]
        );
        
        Self { k_dh, pack_key, owner_tag }
    }
}
```

**Security Properties:**

1. **One-way:** Cannot recover `dh` from `k_dh` (preimage resistance)
2. **Unlinkable:** Different `dh` → different `k_dh` with overwhelming probability
3. **Deterministic:** Same `dh` always produces same `k_dh` (needed for decryption)
4. **Domain-separated:** Different contexts (DH, PACKKEY, TAG) produce independent keys

#### 2.6.2.1 Integration with z00z_crypto::kdf

**Existing Module Usage:**

The `z00z_crypto/src/kdf.rs` provides wallet-side KDF operations:

```rust
// z00z_crypto/src/kdf.rs (EXISTING)
use hkdf::Hkdf;
use sha2::Sha256;

pub fn derive_key(
    salt: &[u8],
    ikm: &[u8],
    info: &[u8],
    len: usize,
) -> Vec<u8> {
    let hkdf = Hkdf::<Sha256>::new(Some(salt), ikm);
    let mut okm = vec![0u8; len];
    hkdf.expand(info, &mut okm).expect("HKDF failed");
    okm
}
```

**Wallet Integration:**

```rust
// z00z_wallets/src/crypto/kdf.rs (NEW - wallet-specific wrappers)
use z00z_crypto::kdf;

/// Derive receiver_secret from mnemonic seed (wallet-only)
pub fn derive_receiver_secret_from_seed(
    mnemonic_seed: &[u8; 64],
    account_index: u32,
) -> [u8; 32] {
    let info = format!("receiver-secret-account-{}", account_index);
    let okm = kdf::derive_key(
        b"Z00Z-receiver-v1",
        mnemonic_seed,
        info.as_bytes(),
        32,
    );
    
    let mut result = [0u8; 32];
    result.copy_from_slice(&okm);
    result
}

/// Derive view_sk from receiver_secret (consensus-critical via H_zk)
pub fn derive_view_sk(receiver_secret: &[u8; 32]) -> Scalar {
    // Use H2Scalar (Poseidon2-based) for consensus derivation
    h2scalar_zk(b"Z00Z/VIEW", &[receiver_secret])
}
```

**Clear Separation:**

```rust
// ✅ CORRECT: Wallet KDF for wallet-only data
let db_key = kdf::derive_key(
    b"db-salt",
    master_seed,
    b"database",
    32,
);

// ✅ CORRECT: Consensus KDF for proof-visible data
let k_dh = kdf_consensus(b"Z00Z/DH", &dh_bytes, &[]);

// ❌ WRONG: Mixing KDF types
let k_dh_wrong = kdf::derive_key(
    b"salt",
    &dh_bytes,
    b"Z00Z/DH",
    32,
);  // Will fail in OWF proof!
```

### 2.6.3 KDF Test Vectors

**Golden Vectors for Consensus KDF:**

```rust
struct KdfTestVector {
    domain: &'static [u8],
    ikm: Vec<u8>,
    info: Vec<Vec<u8>>,
    expected: [u8; 32],
}

const KDF_VECTORS: &[KdfTestVector] = &[
    // Vector 1: k_dh derivation (zero DH point - boundary case)
    KdfTestVector {
        domain: b"Z00Z/DH",
        ikm: vec![0x00; 32],  // Hypothetical DH point encoding
        info: vec![],
        expected: [
            // TBD: Fill with actual Poseidon2("Z00Z/DH", [0x00; 32])
            0x3a, 0x5f, /* ... */
        ],
    },
    
    // Vector 2: pack_key derivation
    KdfTestVector {
        domain: b"Z00Z/PACKKEY",
        ikm: vec![0x42; 32],  // k_dh
        info: vec![
            vec![0xAA; 32],              // asset_id
            vec![0x01, 0x00, 0x00, 0x00], // serial_id = 1 (LE)
        ],
        expected: [
            // TBD: Fill with actual computation
        ],
    },
    
    // Vector 3: Real ECDH example
    KdfTestVector {
        domain: b"Z00Z/DH",
        ikm: {
            // Alice test vector view_sk * Bob ephemeral R
            let view_sk = Scalar::from_bytes_mod_order([0x42; 32]);
            let r = Scalar::from_bytes_mod_order([0x17; 32]);
            let dh = &r * &(&view_sk * &RISTRETTO_BASEPOINT_TABLE);
            dh.compress().to_bytes().to_vec()
        },
        info: vec![],
        expected: [
            // TBD: Compute with reference implementation
        ],
    },
];

#[test]
fn test_kdf_golden_vectors() {
    for (i, vector) in KDF_VECTORS.iter().enumerate() {
        let info_refs: Vec<&[u8]> = vector.info.iter()
            .map(|v| v.as_slice())
            .collect();
        
        let actual = kdf_consensus(
            vector.domain,
            &vector.ikm,
            &info_refs,
        );
        
        assert_eq!(
            actual,
            vector.expected,
            "KDF vector {} failed",
            i + 1
        );
    }
}
```

**Cross-Implementation Validation:**

```rust
#[test]
fn test_kdf_matches_proof_gadget() {
    // This test should run against proof engine
    let dh_bytes = [0x42u8; 32];  // Mock DH point
    
    let wallet_k_dh = kdf_consensus(b"Z00Z/DH", &dh_bytes, &[]);
    
    // TBD: Compare with proof engine KDF output
    // let proof_k_dh = proof_engine::derive_k_dh(&dh_bytes);
    // assert_eq!(wallet_k_dh, proof_k_dh);
}

#[test]
fn test_kdf_deterministic() {
    let ikm = [0x42u8; 32];
    let k1 = kdf_consensus(b"Z00Z/TEST", &ikm, &[]);
    let k2 = kdf_consensus(b"Z00Z/TEST", &ikm, &[]);
    assert_eq!(k1, k2);
}

#[test]
fn test_kdf_domain_separation() {
    let ikm = [0x42u8; 32];
    let k1 = kdf_consensus(b"Z00Z/DH", &ikm, &[]);
    let k2 = kdf_consensus(b"Z00Z/PACKKEY", &ikm, &[]);
    assert_ne!(k1, k2, "Different domains must produce different keys");
}

#[test]
fn test_kdf_info_binding() {
    let ikm = [0x42u8; 32];
    let info1 = [0xAAu8; 32];
    let info2 = [0xBBu8; 32];
    
    let k1 = kdf_consensus(b"Z00Z/TEST", &ikm, &[&info1]);
    let k2 = kdf_consensus(b"Z00Z/TEST", &ikm, &[&info2]);
    
    assert_ne!(k1, k2, "Different info must produce different keys");
}
```

## 2.7 AEAD (Authenticated Encryption with Associated Data)

**Purpose:** Encrypt coin pack data so only the receiver can decrypt, with integrity protection.

**Integration:** Use ZkPack_v1 (Poseidon2-based) for `enc_pack` in UTXO leaves; optionally XChaCha20-Poly1305 for transport encryption.

### 2.7.1 AEAD Scheme Selection

**Two-Tier Policy:**

```yaml
AEAD_Selection:
  consensus_critical: ZkPack_v1 (Poseidon2 stream + MAC)
    - Usage: enc_pack field in UTXO leaf (on-chain state)
    - Proven in OWF constraints
    - ZK-friendly (O(10²) constraints)
    
  transport_only: XChaCha20-Poly1305 (optional)
    - Usage: TxPackage outer encryption (off-chain)
    - NOT proven in ZK
    - Standard IETF AEAD
```

**Why ZkPack_v1 for enc_pack:**

- **Constraint Efficiency:** Poseidon2: ~200 constraints vs ChaCha20: ~500k constraints
- **OWF Integration:** Can prove encryption correctness in output well-formedness proof
- **Field-Native:** Works in Goldilocks field without bit decomposition overhead

**Why NOT ChaCha20/AES for enc_pack:**

- **Infeasible:** ChaCha20-Poly1305 proof would add 500k-2M constraints per output
- **Defeats Purpose:** Negates entire benefit of efficient ZK proofs

#### 2.7.1.1 ZkPack_v1 for Consensus

**ZkPack_v1:** Poseidon2-based AEAD-equivalent providing confidentiality + authenticity.

**Construction:**

```rust
pub struct ZkPackV1;

impl ZkPackV1 {
    /// Derive pack encryption key
    pub fn pack_key(
        k_dh: &[u8; 32],
        asset_id: &[u8; 32],
        serial_id: u32,
    ) -> [u8; 32] {
        poseidon2_hash(
            b\"Z00Z/PACKKEY\",
            &[k_dh, asset_id, &serial_id.to_le_bytes()]
        )
    }
    
    /// Derive nonce (deterministic from leaf)
    pub fn nonce(
        leaf_ad: &[u8; 32],
        r_pub: &[u8; 32],
        asset_id: &[u8; 32],
        serial_id: u32,
    ) -> [u8; 32] {
        poseidon2_hash(
            b\"Z00Z/PACKNONCE\",
            &[leaf_ad, r_pub, asset_id, &serial_id.to_le_bytes()]
        )
    }
    
    /// Generate keystream
    fn keystream(pack_key: &[u8; 32], nonce: &[u8; 32], len: usize) -> Vec<u8> {
        let mut sponge = Poseidon2Sponge::new(b\"Z00Z/PACKSTR\");
        sponge.absorb(pack_key);
        sponge.absorb(nonce);
        sponge.squeeze_bytes(len)
    }
    
    /// Compute MAC tag
    pub fn tag(
        pack_key: &[u8; 32],
        nonce: &[u8; 32],
        leaf_ad: &[u8; 32],
        ciphertext: &[u8],
    ) -> [u8; 32] {
        let len_bytes = (ciphertext.len() as u64).to_le_bytes();
        poseidon2_hash(
            b\"Z00Z/PACKTAG\",
            &[pack_key, nonce, leaf_ad, ciphertext, &len_bytes]
        )
    }
    
    /// Encrypt
    pub fn encrypt(
        k_dh: &[u8; 32],
        leaf_ad: &[u8; 32],
        r_pub: &[u8; 32],
        asset_id: &[u8; 32],
        serial_id: u32,
        plaintext: &[u8],
    ) -> ZkPackCiphertext {
        let pack_key = Self::pack_key(k_dh, asset_id, serial_id);
        let nonce = Self::nonce(leaf_ad, r_pub, asset_id, serial_id);
        let keystream = Self::keystream(&pack_key, &nonce, plaintext.len());
        
        let ciphertext: Vec<u8> = plaintext.iter()
            .zip(keystream.iter())
            .map(|(p, k)| p ^ k)
            .collect();
        
        let tag = Self::tag(&pack_key, &nonce, leaf_ad, &ciphertext);
        
        ZkPackCiphertext { version: 1, tag, ciphertext }
    }
    
    /// Decrypt (returns None if auth fails)
    pub fn decrypt(
        k_dh: &[u8; 32],
        leaf_ad: &[u8; 32],
        r_pub: &[u8; 32],
        asset_id: &[u8; 32],
        serial_id: u32,
        enc: &ZkPackCiphertext,
    ) -> Option<Vec<u8>> {
        if enc.version != 1 { return None; }
        
        let pack_key = Self::pack_key(k_dh, asset_id, serial_id);
        let nonce = Self::nonce(leaf_ad, r_pub, asset_id, serial_id);
        
        // Verify tag FIRST (constant-time)
        let tag_computed = Self::tag(&pack_key, &nonce, leaf_ad, &enc.ciphertext);
        if !constant_time_eq(&tag_computed, &enc.tag) {
            return None;
        }
        
        // Decrypt
        let keystream = Self::keystream(&pack_key, &nonce, enc.ciphertext.len());
        let plaintext: Vec<u8> = enc.ciphertext.iter()
            .zip(keystream.iter())
            .map(|(c, k)| c ^ k)
            .collect();
        
        Some(plaintext)
    }
}

#[derive(Clone, Debug)]
pub struct ZkPackCiphertext {
    pub version: u8,
    pub tag: [u8; 32],
    pub ciphertext: Vec<u8>,
}
```

##### 2.7.1.1.1 Keyed Duplex Sponge

**Poseidon2 Sponge Construction:**

```rust
pub struct Poseidon2Sponge {
    state: [GoldilocksField; 12],  // Width=12: rate=8, capacity=4
    position: usize,
}

impl Poseidon2Sponge {
    pub fn new(domain: &[u8]) -> Self {
        let mut state = [GoldilocksField::ZERO; 12];
        // Initialize with domain
        let domain_felts = bytes_to_felts_padded(domain);
        for (i, felt) in domain_felts.iter().enumerate().take(8) {
            state[i] = *felt;
        }
        Self { state, position: 0 }
    }
    
    pub fn absorb(&mut self, data: &[u8; 32]) {
        let felts = bytes_to_felts(data);
        for (i, felt) in felts.iter().enumerate() {
            self.state[i] ^= *felt;  // XOR into rate
        }
        self.permute();
    }
    
    pub fn squeeze_bytes(&mut self, len: usize) -> Vec<u8> {
        let felts_needed = (len + 3) / 4;
        let mut output = Vec::new();
        
        while output.len() < felts_needed {
            let available = 8 - self.position;
            let to_take = std::cmp::min(available, felts_needed - output.len());
            
            output.extend_from_slice(&self.state[self.position..self.position + to_take]);
            self.position += to_take;
            
            if self.position == 8 {
                self.permute();
                self.position = 0;
            }
        }
        
        let bytes = felts_to_bytes(&output);
        bytes[..len].to_vec()
    }
    
    fn permute(&mut self) {
        poseidon2_permutation(&mut self.state);  // 30 rounds
    }
}
```

##### 2.7.1.1.2 Stream Encryption

**Keystream Generation:**

```
Initialize: sponge = Poseidon2Sponge(\"Z00Z/PACKSTR\")
Absorb: pack_key (32 bytes)
Absorb: nonce (32 bytes)
Squeeze: keystream[0..plaintext_len]

Encrypt: ciphertext[i] = plaintext[i] XOR keystream[i]
Decrypt: plaintext[i] = ciphertext[i] XOR keystream[i]
```

**Properties:**

- **Deterministic:** Same (pack_key, nonce) → same keystream
- **Pseudorandom:** Indistinguishable from random (Poseidon2 security)
- **Length-Preserving:** len(ciphertext) == len(plaintext)

##### 2.7.1.1.3 MAC Generation

**Tag Computation:**

```rust
tag = H_zk(\"Z00Z/PACKTAG\" || pack_key || nonce || leaf_ad || ciphertext || len)
```

**Bindings:**

- `pack_key`: Only correct key produces valid tag
- `nonce`: Tag unique per encryption
- `leaf_ad`: Cannot move ciphertext between outputs
- `ciphertext`: Detects any modification
- `len`: Prevents truncation/extension

##### 2.7.1.1.4 Associated Data Binding

**AD Construction:**

```rust
leaf_ad = H_zk(\"Z00Z/LEAFAD\" || asset_id || serial_id || R || owner_tag || C_amount)
```

**What AD Binds:**

- `asset_id`: Unique output ID → prevents replay
- `R`: ECDH ephemeral key → binds to specific ECDH session
- `owner_tag`: Ownership marker → anti-malleability
- `C_amount`: Commitment → prevents commitment substitution

**Attack Prevention:**

- **Replay:** Different asset_id → different AD → tag fails
- **Cross-Leaf:** Moving enc_pack to another output → AD mismatch
- **Malleability:** Modifying any leaf field → AD changes → tag fails

#### 2.7.1.2 XChaCha20-Poly1305 for Transport

**Usage:** Optional outer encryption for off-chain `TxPackage` submission.

```rust
use chacha20poly1305::{XChaCha20Poly1305, XNonce};

pub fn encrypt_tx_package_transport(
    tx_package: &TxPackage,
    shared_secret: &[u8; 32],
) -> Result<Vec<u8>, Error> {
    let cipher = XChaCha20Poly1305::new(shared_secret.into());
    let nonce = XNonce::from_slice(&random_bytes_24());
    
    let plaintext = bincode::serialize(tx_package)?;
    cipher.encrypt(nonce, plaintext.as_slice())
        .map_err(|_| Error::TransportEncryptionFailed)
}
```

**Why XChaCha20-Poly1305:**

- **Transport-Only:** Not proven in ZK (off-chain)
- **Standard:** IETF RFC 8439, widely audited
- **24-Byte Nonce:** Random nonce generation (no coordination)
- **Performance:** ~1 GB/s on modern CPUs

### 2.7.2 AEAD API

**High-Level Trait:**

```rust
pub trait ConsensusAead {
    fn encrypt(
        &self,
        k_dh: &[u8; 32],
        leaf_ad: &[u8; 32],
        context: &EncryptContext,
        plaintext: &[u8],
    ) -> ZkPackCiphertext;
    
    fn decrypt(
        &self,
        k_dh: &[u8; 32],
        leaf_ad: &[u8; 32],
        context: &EncryptContext,
        ciphertext: &ZkPackCiphertext,
    ) -> Option<Vec<u8>>;
}

pub struct EncryptContext {
    pub r_pub: [u8; 32],
    pub asset_id: [u8; 32],
    pub serial_id: u32,
}
```

#### 2.7.2.1 Encryption Interface

```rust
/// Encrypt coin pack
pub fn encrypt_coin_pack(
    k_dh: &[u8; 32],
    coin_pack: &CoinPackPlain,
    leaf_fields: &LeafFields,
) -> ZkPackCiphertext {
    let plaintext = coin_pack.to_bytes();
    let leaf_ad = compute_leaf_ad(leaf_fields);
    
    ZkPackV1::encrypt(
        k_dh,
        &leaf_ad,
        &leaf_fields.r_pub,
        &leaf_fields.asset_id,
        leaf_fields.serial_id,
        &plaintext,
    )
}
```

#### 2.7.2.2 Decryption Interface

```rust
/// Decrypt coin pack
pub fn decrypt_coin_pack(
    k_dh: &[u8; 32],
    enc_pack: &ZkPackCiphertext,
    leaf_fields: &LeafFields,
) -> Result<CoinPackPlain, Error> {
    let leaf_ad = compute_leaf_ad(leaf_fields);
    
    let plaintext = ZkPackV1::decrypt(
        k_dh,
        &leaf_ad,
        &leaf_fields.r_pub,
        &leaf_fields.asset_id,
        leaf_fields.serial_id,
        enc_pack,
    ).ok_or(Error::DecryptionFailed)?;
    
    CoinPackPlain::from_bytes(&plaintext)
}
```

#### 2.7.2.3 Integration with z00z_crypto::aead

**Existing Module (Wallet-Local):**

```rust
// z00z_crypto/src/aead.rs (EXISTING - XChaCha20-Poly1305 for wallet DB)
pub fn encrypt_wallet_data(
    key: &[u8; 32],
    nonce: &[u8; 24],
    plaintext: &[u8],
    ad: &[u8],
) -> Result<Vec<u8>, Error> {
    // XChaCha20-Poly1305 implementation
}
```

**Clear Separation:**

```rust
// ✅ CORRECT: ZkPack for enc_pack (consensus)
let enc_pack = ZkPackV1::encrypt(&k_dh, &leaf_ad, ...);

// ✅ CORRECT: XChaCha20 for wallet database (local)
let db_encrypted = encrypt_wallet_data(&db_key, &nonce, ...)?;

// ❌ WRONG: XChaCha20 for enc_pack (cannot prove in OWF)
let wrong = encrypt_wallet_data(&k_dh, ...)?;  // FAILS IN PROOF!
```

### 2.7.3 AEAD Security Properties

**IND-CPA (Confidentiality):**

- Ciphertext reveals no information about plaintext
- Keystream is pseudorandom (Poseidon2 security assumption)
- Nonce uniqueness prevents keystream reuse

**INT-CTXT (Authenticity):**

- Cannot forge valid ciphertext without `pack_key`
- Tag binds ciphertext + AD cryptographically
- Constant-time tag comparison prevents timing attacks

**Malleability Resistance:**

- Modifying any ciphertext byte → tag verification fails
- Moving ciphertext between outputs → AD mismatch → tag fails
- Truncating/extending ciphertext → length mismatch → tag fails

**Testing:**

```rust
#[test]
fn test_zkpack_roundtrip() {
    let k_dh = [0x42; 32];
    let leaf_ad = [0xAA; 32];
    let r_pub = [0x01; 32];
    let asset_id = [0x02; 32];
    let serial_id = 1;
    let plaintext = b"test data";
    
    let enc = ZkPackV1::encrypt(&k_dh, &leaf_ad, &r_pub, &asset_id, serial_id, plaintext);
    let dec = ZkPackV1::decrypt(&k_dh, &leaf_ad, &r_pub, &asset_id, serial_id, &enc).unwrap();
    
    assert_eq!(dec, plaintext.to_vec());
}

#[test]
fn test_ad_binding() {
    let k_dh = [0x42; 32];
    let leaf_ad1 = [0xAA; 32];
    let leaf_ad2 = [0xBB; 32];
    let r_pub = [0x01; 32];
    let asset_id = [0x02; 32];
    let serial_id = 1;
    
    let enc = ZkPackV1::encrypt(&k_dh, &leaf_ad1, &r_pub, &asset_id, serial_id, b"test");
    let result = ZkPackV1::decrypt(&k_dh, &leaf_ad2, &r_pub, &asset_id, serial_id, &enc);
    
    assert!(result.is_none(), "AD binding should prevent replay");
}
```

---


---

# 📋 IMPLEMENTATION TASKS

**For detailed implementation checklists and 4-week roadmap, see:**

👉 **[IMPLEMENTATION_CHECKLIST.md](./IMPLEMENTATION_CHECKLIST.md)**

## Quick Summary

**Status:** Section 2 SPEC is ~60% implemented in `z00z_crypto`

**Critical Missing Components (P0 - Blocking):**
1. **hash_zk.rs** - Poseidon2 hash for consensus (5-7 days)
2. **ecdh.rs** - Stealth address ECDH primitives (2-3 days)
3. **zkpack_aead.rs** - Consensus-critical AEAD (7-10 days)
4. **consensus_kdf.rs** - Key derivation functions (1-2 days)

**Total Implementation Time:** 4-5 weeks (1 developer full-time)

**See IMPLEMENTATION_CHECKLIST.md for:**
- ✅ Detailed task breakdowns per module
- ✅ Acceptance criteria for each component
- ✅ 4-week week-by-week roadmap
- ✅ Test requirements and golden vectors
- ✅  Final checklist before declaring "Section 2 Complete"

---

**Document Version:** 1.0  
**Last Updated:** 2026-02-15  
**Source:** Z00Z-ECC-SPEC_part1.md Section 2 (lines 1149-5726)  
**Checklist:** Based on REVIEW-2.md gap analysis
