# Stealth Address Module Improvement Spec

## Mandatory Implementation Context

📌 This spec is not exploratory. It is a mandatory canonical-path cleanup document.

📌 The following requirements are non-optional:

- dead stealth branches must be removed
- experimental stealth branches must be removed from normal production and test paths
- all code must migrate to canonical formula owners
- all tests must migrate to canonical formula owners
- no parallel stealth helper stack may remain as a valid alternative path

📌 The developer must not choose between multiple stealth implementations. This document defines which path is canonical and which paths must be retired.

### Non-Negotiable Rules

📌 Every later section in this document must be read under these non-negotiable constraints.

- [x] Read the full spec before changing any stealth-related file so local cleanup does not violate a later section.
- [ ] Reject any implementation idea that creates a second live owner for an already-assigned stealth formula.
- [ ] Reject any implementation idea that preserves dead or experimental branches as equal alternatives to canonical paths.
- [x] Treat this document as authoritative over older spike phrasing, temporary exploration wording, and convenience wrappers.
- [x] Require every code and test change to point back to one of the owners, phases, or acceptance conditions defined below.

## Critical Audit Corrections

📌 This spec was cross-checked against the current repository state. The audit found one critical constraint that must be explicit before any cleanup starts:

- the repository does not yet have one fully converged stealth derivation surface
- `crates/z00z_crypto/src/ecdh.rs` is canonical for point-based base `derive_k_dh(&Z00ZRistrettoPoint)`
- `crates/z00z_wallets/src/core/stealth/ecdh.rs` is still a live runtime owner for byte-based `compute_dh_sender`, `compute_dh_receiver`, `derive_k_dh_with_req`, `derive_s_out`, and sender/receiver key bundles

📌 Therefore the cleanup must converge by explicit delegation and API shrinkage, not by blindly deleting the wallet ECDH layer first.

📌 A cleanup that forces all runtime code directly onto `z00z_crypto/src/ecdh.rs` today would be logically incomplete, because that file does not currently own request-bound `k_dh`, byte-based sender/receiver bundles, or `s_out`.

### Current Convergence Constraint

📌 The repository is not at final convergence yet, so implementation must separate “current live runtime owner” from “final canonical destination”.

- [x] Audit any planned move out of `crates/z00z_wallets/src/core/stealth/ecdh.rs` against the concrete formulas that file still owns today.
- [ ] Do not delete or bypass byte-oriented runtime helpers until equivalent semantics exist in the surviving canonical owner.
- [ ] When moving any function from the wallet runtime layer, prove that request-bound `k_dh`, `s_out`, and sender/receiver bundle behavior remain unchanged.
- [ ] Keep transitional ownership explicit in code review notes and implementation PR text until the corresponding phase exit criteria are met.
- [ ] Refuse any cleanup that claims “one canonical path already exists” if the actual runtime still depends on transitional owners.

## Canonical Cleanup Policy

📌 The cleanup rule is simple: every stealth formula must have exactly one live owner. Where the repository has not fully converged yet, the spec must say so explicitly and define the migration target.

| Concern | Canonical owner | Mandatory action | Forbidden outcome |
| --- | --- | --- | --- |
| Point-based base `k_dh` derivation from `Z00ZRistrettoPoint` | `crates/z00z_crypto/src/ecdh.rs` | keep this as the only canonical point-based base-`k_dh` formula owner | second point-based base-`k_dh` implementation |
| Wallet byte-based ECDH, request-bound `k_dh`, and `s_out` | `crates/z00z_wallets/src/core/stealth/ecdh.rs` | treat as current runtime owner, freeze API growth, and converge by delegation or extraction in a later cleanup step | deleting this layer before request-bound and byte-oriented runtime semantics have a canonical replacement |
| Owner-tag formula | `crates/z00z_crypto/src/kdf.rs` | delete local re-implementations and use canonical crypto path | wallet-local duplicate owner-tag formula |
| Wallet `tag16` and wallet `leaf_ad` formulas | `crates/z00z_wallets/src/core/stealth/tag.rs` | route wallet output, validation, and scan code through this file only | multiple wallet tag or leaf binding owners |
| Canonical full-leaf ownership detection | `crates/z00z_wallets/src/core/address/leaf_scan.rs` | keep this file as authority and adapt tests accordingly | scanner adapter becoming a second authority |
| Runtime scan orchestration | `crates/z00z_wallets/src/core/address/stealth_scanner.rs` | keep as adapter only | new cryptographic formulas added here |

📌 There is no approved branch where tests keep targeting experimental helper layers after canonical owners are known.

### Formula Ownership Matrix Usage

📌 The ownership matrix above is the first implementation gate for every change.

- [x] Before touching a stealth function, classify it under one of the concerns in the ownership matrix.
- [ ] If a function does not fit an existing concern, stop and document why instead of silently inventing a new owner category.
- [x] Route every refactor through the owner listed in the matrix rather than through whichever module is most convenient locally.
- [x] Eliminate duplicate implementations by delegation or removal; do not keep duplicate code with matching formulas “for readability”.
- [x] Verify that tests import or exercise the same owner that production code is supposed to rely on.

## Mandatory Migration Rule For Code And Tests

📌 Every production call site and every test must be classified into one of these categories:

| Category | Required disposition |
| --- | --- |
| Canonical path already | keep and extend |
| Transitional live runtime owner | freeze feature growth, document as transitional owner, converge intentionally |
| Compatibility shim that only delegates | migrate callers away, then remove |
| Experimental branch with no canonical need | migrate callers away, then remove |
| Duplicate formula implementation | replace with canonical call, then remove |

📌 This means test coverage must move with the formulas. When a branch is non-canonical, its standalone tests must not remain as if that branch were a supported architecture.

📌 The correct outcome is:

- tests verify canonical formulas
- tests verify canonical adapters
- tests verify migration invariants only where a temporary canonical-boundary check still exists

📌 The incorrect outcome is:

- separate test suites protecting dead or experimental stealth branches as first-class APIs
- duplicate golden tests for duplicate implementations
- production and tests disagreeing about which path is canonical

### Classification Procedure

📌 Every code path and every test path must be classified before it is edited.

- [x] Label each touched function or test as canonical, transitional runtime owner, compatibility shim, experimental branch, or duplicate implementation.
- [x] For every transitional path, document the canonical destination that will eventually replace it.
- [ ] Remove or rewrite tests that accidentally promote experimental branches into protocol-defining behavior.
- [ ] Preserve only migration invariants that prove old and new paths remain behaviorally compatible during the transition.
- [ ] Reject any new test that snapshots the behavior of a branch already marked for quarantine or removal.

## Phase 1. Final Canonical Path Contract

📌 This spec must define not only internal formula owners, but also one final developer-facing canonical path for working with stealth addresses after cleanup is complete.

📌 Final steady-state rule:

- application and wallet code must not choose between multiple stealth import routes
- internal formula ownership may stay split across the correct owner files
- public and developer-facing work with stealth addresses must collapse to one documented wallet path

| Concern | Final internal owner | Final developer-facing canonical path | Forbidden public usage |
| --- | --- | --- | --- |
| Point and sender/receiver stealth ECDH operations | one surviving crypto ECDH owner selected by Phase 5 overlap cleanup | `z00z_wallets::core::ecdh` facade | importing both `ecdh` and `ecdh_stealth` as peer public surfaces |
| Wallet KDF and tag helpers | canonical owners in `crates/z00z_crypto/src/kdf.rs` and `crates/z00z_wallets/src/core/stealth/tag.rs` | `z00z_wallets::core::kdf` facade | reaching into mixed internal modules as normal application workflow |
| Full-leaf ownership detection | `crates/z00z_wallets/src/core/address/leaf_scan.rs` | `z00z_wallets::core::scan` facade | treating `stealth_scanner.rs` as a second canonical scan API |

📌 This is the practical meaning of “one canonical path” for stealth-address work in this repository:

- one public wallet ECDH path
- one public wallet KDF path
- one public wallet scan path

📌 Internal owner files can remain separate where the formulas are genuinely different, but developers must not be offered multiple equivalent-looking ways to do the same stealth task.

### Public Path Enforcement

📌 The final public contract must be enforced at the facade level, not only described conceptually.

- [x] Keep `z00z_wallets::core::ecdh` as the only documented public ECDH path for wallet and app code.
- [x] Keep `z00z_wallets::core::kdf` as the only documented public KDF and tag path for wallet and app code.
- [x] Keep `z00z_wallets::core::scan` as the only documented public full-leaf scan path for wallet and app code.
- [x] Remove or quarantine re-exports that make internal `core::stealth::*` modules look like equal public alternatives.
- [x] Audit examples, tests, and documentation snippets so they demonstrate the surviving public path instead of mixed internal imports.

## Canonical Path Diagram

📌 The allowed ownership map is fixed and must not be misread as a single already-converged call chain.

```mermaid
flowchart TD
    A[z00z_crypto::ecdh.rs\npoint-based base k_dh owner]
    B[z00z_wallets::core::stealth::ecdh.rs\nbyte/request runtime owner]
    C[z00z_crypto::kdf.rs\nowner_tag canonical owner]
    D[z00z_wallets::core::stealth::tag.rs\ntag16 and wallet leaf_ad owner]
    E[z00z_wallets::core::address::leaf_scan.rs\nfull-leaf detection authority]
    F[z00z_wallets::core::address::stealth_scanner.rs\nruntime adapter only]

    B --> C
    B --> D
    C --> E
    D --> E
    C --> F
    D --> F

    X1[output.rs local owner_tag duplication] -. delegate .-> C
    X2[flexible and extended k_dh branches] -. quarantine/remove .-> B
    X3[ecdh_stealth.rs overlap] -. audit and converge .-> A
    X4[tests targeting dead branches] -. migrate .-> A
    X5[tests targeting duplicate formulas] -. migrate .-> C
```

📌 Read this diagram as an implementation constraint and ownership map, not as a claim that the repository has already collapsed into one linear stack.

### Diagram Interpretation Rules

📌 The diagram is not decorative. It constrains allowed movement during cleanup.

- [ ] Read solid ownership nodes as current formula owners or runtime authorities that must be respected during cleanup.
- [ ] Read dashed arrows as explicit cleanup actions that still must be executed, not as already-finished work.
- [ ] Do not introduce new nodes or side paths unless the source-of-truth map and phase plan are updated together.
- [ ] Use the diagram to reject any refactor that adds a second public-looking path for ECDH, KDF, tag, or scan work.
- [ ] Re-check the diagram whenever a phase closes so it continues to describe the current intended end state accurately.

## Phase 2. Goal

📌 This document converts the current stealth-address notes into an implementation-ready spec aligned with the existing codebase.

📌 The primary constraint is ONE SOURCE OF TRUTH: do not introduce new cryptographic branches or parallel helper stacks when the current code already has a live owner for the formula.

📌 The goal of this spec is not to redesign the protocol. The goal is to identify:

- what is already canonical
- what is actively used in production paths
- what is compatibility glue
- what looks legacy or excessive and should stop expanding

### Implementation Goal Translation

📌 The goal section must translate directly into implementation behavior.

- [x] Keep the cleanup focused on removing duplication, shrinking surfaces, and clarifying ownership rather than redesigning the stealth protocol.
- [x] Prefer local moves that align existing code with assigned owners over new abstractions or new protocol concepts.
- [x] Record every touched function as canonical, compatibility-only, transitional, or excessive before modifying it.
- [x] Preserve current protocol semantics unless a later section explicitly allows a protocol-level decision.
- [ ] Refuse changes that improve naming but worsen source-of-truth clarity.

## Scope

📌 This spec is based on direct inspection of the current code paths in:

- `crates/z00z_crypto/src`
- `crates/z00z_wallets/src/core/stealth`
- `crates/z00z_wallets/src/core/address`
- `crates/Z00Z-ECC-SPEC_part1.md`

📌 This spec intentionally avoids proposing a greenfield stealth subsystem.

### In-Scope Review Surface

📌 Only the listed code surfaces are in scope for this cleanup plan.

- [ ] Limit direct implementation work to `crates/z00z_crypto/src`, `crates/z00z_wallets/src/core/stealth`, and `crates/z00z_wallets/src/core/address` unless another section explicitly expands scope.
- [ ] Use `crates/Z00Z-ECC-SPEC_part1.md` only as supporting context when code signatures or legacy terminology need clarification.
- [ ] Do not expand the cleanup into unrelated wallet storage, network, claim, or app orchestration layers.
- [ ] Treat simulator, examples, and tests as validation surfaces, not as primary ownership authorities.
- [ ] Reject greenfield stealth rewrites that bypass the current repository structure instead of improving it.

## Inherited Spike Conclusions

📌 This spec absorbs the normative recommendations from the earlier `stealth-todo.md` spike document.

📌 The inherited conclusions are:

1. Do not migrate the full stealth stack to `stealth_address_kit`.
2. Use `stealth_address_kit` only as a reference model for algebraic intent and primitive invariants.
3. Do not treat the external crate as a proof oracle for the full Z00Z ownership, request-binding, tag16, or scan model.
4. Keep protocol-specific layers above the primitive layer instead of force-aligning the whole wallet flow to the external API shape.
5. Consider a narrow internal primitive facade only after the current one-source-of-truth cleanup is complete.

📌 In practice, this means the current spec keeps the useful outputs of the spike and discards only the temporary exploration framing.

### Carried-Forward Constraints

📌 The earlier spike remains relevant only through the conclusions preserved here.

- [ ] Use `stealth_address_kit` as a reference for algebraic intent and invariant design, not as a drop-in implementation target.
- [ ] Keep protocol-specific Z00Z semantics above the primitive layer even when names appear similar to the external crate.
- [ ] Reject any cleanup step that cites the earlier spike as justification for full migration or external parity.
- [ ] Defer any narrow primitive facade discussion until one-source-of-truth cleanup is materially complete.
- [ ] Preserve only the durable conclusions of the earlier spike; ignore temporary estimates and exploratory framing.

## Phase 3. Persistent Outputs From The Earlier Spike

📌 The earlier spike proposed a number of outputs. The durable ones are already carried into this spec in implementation form:

| Earlier spike output | Where it now lives in this spec |
| --- | --- |
| mapping from external primitives to Z00Z surfaces | source-of-truth map, branch inventory, and overlap decisions in this document |
| shortlist of high-risk functions and assumptions | `Critical Audit Corrections`, `Confirmed One-Source-Of-Truth Violations`, and phase ordering |
| recommendation to keep protocol semantics above primitive core | `Final Canonical Path Contract`, ownership policy, and out-of-scope rules |
| recommendation against full migration to `stealth_address_kit` | `Changes Explicitly Out Of Scope` and this inherited conclusions section |
| recommendation to evaluate a narrow primitive facade later | `Decision 4` and deferred cleanup sequencing |

📌 The non-durable parts of the old spike document were planning artifacts such as work estimates and exploratory wording. Those are intentionally not treated as implementation requirements here.

### Durable Spike Outputs

📌 The spike outputs listed here must remain visible somewhere in the current spec or the final code-review notes.

- [ ] Keep a durable mapping between external primitive concepts and current Z00Z surfaces while cleanup is in flight.
- [ ] Preserve the shortlist of high-risk areas as active review targets until the relevant phases close.
- [ ] Keep the anti-migration recommendation against full `stealth_address_kit` replacement visible in the spec.
- [ ] Preserve the recommendation that any future primitive facade is a follow-up, not a precondition for current cleanup.
- [ ] Do not delete inherited spike knowledge unless the same guidance is already captured in the current spec.

## Codebase Reality

📌 The current stealth implementation is split across three layers:

1. `z00z_crypto`: low-level point, ECDH, and KDF primitives.
2. `z00z_wallets::core::stealth`: wallet-facing stealth formulas, output building, tag handling, and validation.
3. `z00z_wallets::core::address`: receiver scanning, request/card orchestration, and wallet runtime adapters.

📌 The important practical fact is that the codebase already has overlapping stealth surfaces. This spec therefore prioritizes consolidation over invention.

### Layer Boundary Rules

📌 The three-layer split is the base architectural constraint for this cleanup.

- [ ] Keep universal curve, point, and low-level KDF primitives in `z00z_crypto`.
- [ ] Keep wallet-specific output, tag, and runtime-facing protocol logic in `z00z_wallets::core::stealth` and `z00z_wallets::core::address` unless a later phase explicitly converges it.
- [ ] Do not move wallet protocol semantics into crypto just to make the file layout look simpler.
- [ ] Do not leave low-level primitive duplication inside wallet modules once a crypto owner exists.
- [ ] Review every move for whether it improves the layer boundary or only relocates ambiguity.

## Phase 4. Stealth Subtree Disposition

📌 The cleanup must classify the current stealth subtree into four implementation buckets:

1. stays in wallets as wallet-facing protocol layer
2. converges into crypto as universal primitive ownership
3. remains temporarily as compatibility shim or facade boundary
4. is removed as legacy or excess surface

📌 This section answers the practical question “what stays where” and must be used before moving code between crates.

### 1. Must Stay In Wallets

📌 The following surfaces remain in wallets because they are wallet-facing protocol logic, not generic cryptographic primitives:

- `crates/z00z_wallets/src/core/stealth/tag.rs`
- `crates/z00z_wallets/src/core/stealth/output.rs`
- `crates/z00z_wallets/src/core/stealth/output_validator.rs`
- wallet facades in `crates/z00z_wallets/src/core/stealth/facade_*.rs`
- canonical receive and scan routing in `crates/z00z_wallets/src/core/address/leaf_scan.rs`
- runtime adapter behavior in `crates/z00z_wallets/src/core/address/stealth_scanner.rs`

📌 These files own wallet-facing protocol semantics such as `tag16`, wallet `leaf_ad`, output construction, validation, and public facade shape.

- [ ] Keep wallet-facing protocol semantics in wallets even when they call crypto-owned primitives internally.
- [ ] Keep output building, output validation, wallet tag semantics, and scan orchestration out of `z00z_crypto`.
- [ ] Preserve wallet facades as the developer-facing path while hiding internal module churn behind them.
- [ ] Do not move wallet protocol glue into crypto just because the underlying helper is cryptographic.
- [ ] Treat this bucket as stable unless a later protocol decision explicitly changes crate boundaries.

### 2. Must Converge Into Crypto

📌 The following surfaces belong in crypto because they are universal primitive owners or should converge there over time:

- point-based base `derive_k_dh` and related shared-point operations in `crates/z00z_crypto/src/ecdh.rs`
- canonical `compute_owner_tag` and other low-level KDF owners in `crates/z00z_crypto/src/kdf.rs`
- any wallet-local primitive logic that proves to be generic and protocol-agnostic during the `ecdh.rs` convergence audit

📌 The move rule is narrow: only generic primitive ownership converges into crypto. Wallet protocol glue does not.

- [ ] Move code into crypto only if it is genuinely generic primitive logic and not wallet protocol behavior.
- [ ] Use the `crates/z00z_wallets/src/core/stealth/ecdh.rs` audit to split generic primitive parts from wallet runtime glue before moving anything.
- [ ] Keep request-bound or output-bound semantics out of crypto until they are proven to be generic primitive concerns.
- [ ] Require tests to prove semantic parity before replacing a wallet-local primitive helper with a crypto-owned equivalent.
- [ ] Refuse any large move into crypto that bundles protocol semantics together with primitive cleanup.

### 3. Direct Canonical Boundaries

📌 Active wallet stealth code must call canonical owners directly. Reordered wrappers and compatibility shims are not allowed in the implementation path.

📌 Public re-export paths may remain only as namespace boundaries when they add no formula logic, no argument reshaping, and no alternate ownership story.

- [x] Remove reordered wrappers and compatibility shims from active wallet stealth code.
- [x] Keep public namespace boundaries logic-free; they must not reshape arguments or own formulas.
- [x] Prefer direct canonical owners in production code and tests.
- [x] Remove any helper that survives only because it used to be a migration convenience.
- [x] Reject helper layers that hide real derivation behavior behind a boundary label.

### 4. Legacy And Excess Surface

📌 The following surfaces are legacy, excess, or overlap candidates and are not part of the target architecture:

- `derive_k_dh_flexible`
- `derive_k_dh_extended`
- `KeyDerivationContext`
- `crypto_traits::{DerivedKeys, SharedSecretOperations, SymmetricKeyDerivation, DefaultSymmetricDerivation}`
- overlapping external stealth-ECDH surface in `crates/z00z_crypto/src/ecdh_stealth.rs`, unless later audit proves a unique compatibility need

📌 This bucket is not allowed to keep public parity with canonical paths.

- [x] Quarantine legacy and excess symbols from public re-exports and developer-facing examples first.
- [x] Audit each remaining internal dependency before removal.
- [x] Delete legacy or excess surface once no active caller and no migration guard still needs it.
- [ ] Treat overlap-only APIs as removal candidates unless a concrete compatibility contract justifies survival.
- [ ] Mark this bucket complete only when these symbols no longer compete with canonical owners or public paths.

## Phase 5. Current Source Of Truth Map

### 1. Point-Based Base `k_dh` In Crypto

📌 `crates/z00z_crypto/src/ecdh.rs` is the active owner for point-based shared-secret handling and base `k_dh` derivation from `Z00ZRistrettoPoint`:

- `generate_ephemeral_keypair`
- `compute_stealth_dh_sender`
- `recover_stealth_dh_receiver`
- point-based `derive_k_dh`

📌 This is the canonical crypto owner for the point-input base formula. It is not yet the only live owner of all wallet runtime stealth derivations.

📌 This means point-based base `k_dh` should not be re-invented again inside wallet modules.

- [ ] Keep point-input base `derive_k_dh` ownership anchored in `crates/z00z_crypto/src/ecdh.rs`.
- [ ] Reject any new wallet-local point-based base `k_dh` implementation.
- [ ] When point-based callers are found outside the crypto owner or its facade, migrate them toward the canonical owner.
- [ ] Preserve existing sender/receiver point invariants while consolidating imports or wrappers.
- [ ] Re-check tests and examples so point-based base derivation is validated against the crypto owner, not against a duplicate helper.

### 2. Wallet Runtime ECDH And Request-Bound `k_dh`

📌 `crates/z00z_wallets/src/core/stealth/ecdh.rs` is still a live runtime owner for byte-oriented stealth derivation helpers:

- `compute_dh_sender`
- `compute_dh_receiver`
- `derive_k_dh`
- `derive_k_dh_with_req`
- `derive_s_out`
- sender and receiver key bundles

📌 Phase 4 removed the experimental branches that previously coexisted in this file, so only the live runtime helpers remain.

📌 Therefore the correct cleanup rule is not “delete wallet ECDH now”. The correct cleanup rule is “freeze this surface, remove duplicate and experimental branches, and only then converge the remaining live formulas to a smaller owner set”.

- [x] Freeze `crates/z00z_wallets/src/core/stealth/ecdh.rs` as a transitional runtime owner rather than expanding its API.
- [x] Separate live runtime requirements from experimental branches inside that file before planning any move into crypto.
- [x] Keep `derive_k_dh_with_req` and `derive_s_out` behavior stable until an explicit canonical replacement exists.
- [x] Quarantine or remove `derive_k_dh_flexible`, `derive_k_dh_extended`, and `KeyDerivationContext` from the public story before deeper convergence work.
- [x] Do not delete this file wholesale while wallet runtime still depends on its byte-oriented semantics.

### 3. Consensus And Wallet KDF Primitives In Crypto

📌 `crates/z00z_crypto/src/kdf.rs` is already the live source of truth for several cryptographic derivations, including:

- `compute_owner_tag`
- `derive_asset_id`
- `derive_leaf_ad`
- `kdf_from_dh`
- pack key and nonce derivations

📌 In particular, `compute_owner_tag` already exists here and should be treated as canonical.

📌 However, `derive_leaf_ad` in crypto is not interchangeable with wallet `compute_leaf_ad` in current runtime flows. The repository contains explicit tests that assert a domain mismatch between the wallet leaf binding and the crypto leaf binding.

📌 Therefore a cleanup must not silently replace wallet `compute_leaf_ad` with crypto `derive_leaf_ad` unless the protocol intentionally changes and vectors are regenerated.

- [x] Keep `compute_owner_tag` ownership in `crates/z00z_crypto/src/kdf.rs` and remove wallet-local duplicates by delegation.
- [ ] Preserve the distinction between crypto `derive_leaf_ad` and wallet `compute_leaf_ad`; do not normalize them into one formula without a protocol decision.
- [ ] Audit pack key and nonce derivations only for ownership clarity, not for unrelated redesign.
- [ ] Require tests to prove that canonical crypto KDF owners still produce the same bytes after any delegation cleanup.
- [ ] Reject any refactor that uses a similar parameter list as evidence that two formulas are interchangeable.

### 4. Wallet Stealth Tag And Output Binding Layer

📌 `crates/z00z_wallets/src/core/stealth/tag.rs` is the live owner of wallet stealth formulas for:

- `compute_tag16`
- `compute_tag16_with_req`
- wallet `compute_leaf_ad`

📌 These formulas are currently used by active wallet output build and scan paths. They should remain in one place until a deliberate protocol-level convergence moves them.

📌 This spec does not recommend moving `tag16` or wallet `leaf_ad` into `z00z_crypto` in the same cleanup phase.

- [x] Keep wallet `compute_tag16`, `compute_tag16_with_req`, and wallet `compute_leaf_ad` owned by `crates/z00z_wallets/src/core/stealth/tag.rs`.
- [x] Route wallet output build, validation, and scan logic through this owner instead of through ad hoc local formulas.
- [ ] Preserve the semantic split between card-bound and request-bound tag modes in all call sites and tests.
- [ ] Do not move wallet `tag16` or wallet `leaf_ad` into crypto during the current cleanup phases.
- [ ] Re-check examples and validators so they reflect the wallet tag owner rather than an older helper path.

### 5. Canonical Receiver Detection Authority

📌 `crates/z00z_wallets/src/core/address/leaf_scan.rs` is already documented in code as the canonical full-leaf detection authority.

📌 `crates/z00z_wallets/src/core/address/stealth_scanner.rs` is the wallet-runtime adapter and must stay an adapter, not become another formula owner.

- [ ] Keep `crates/z00z_wallets/src/core/address/leaf_scan.rs` as the canonical full-leaf ownership authority.
- [ ] Keep `crates/z00z_wallets/src/core/address/stealth_scanner.rs` adapter-only and prevent it from accumulating new formula ownership.
- [ ] Validate that receiver-facing examples, tests, and facades go through `core::scan` when they need canonical full-leaf decisions.
- [ ] Reject any new helper that makes `stealth_scanner.rs` look like a second canonical scan API.
- [ ] Keep shared scan support subordinate to the canonical detection owner rather than the reverse.

## Phase 6. Active Branches That Must Stay

📌 The following derivation branches are actively used in real sender, validator, and scanner paths and should stay:

| Branch | Why it stays | Current live owner |
| --- | --- | --- |
| `derive_k_dh` | base stealth DH key | split today: `z00z_crypto/src/ecdh.rs` for point input and `z00z_wallets/src/core/stealth/ecdh.rs` for byte runtime input |
| `derive_k_dh_with_req` | request-bound stealth key | `z00z_wallets/src/core/stealth/ecdh.rs` |
| `compute_tag16` | card-bound prefilter | `z00z_wallets/src/core/stealth/tag.rs` |
| `compute_tag16_with_req` | request-bound prefilter | `z00z_wallets/src/core/stealth/tag.rs` |
| `derive_s_out` | output secret binding | `z00z_wallets/src/core/stealth/ecdh.rs` |
| `compute_owner_tag` | ownership binding | target owner is `z00z_crypto/src/kdf.rs`, but `output.rs` still contains a duplicate |

📌 These branches are not theoretical. They are used today in:

- `crates/z00z_wallets/src/core/stealth/output.rs`
- `crates/z00z_wallets/src/core/stealth/output_validator.rs`
- `crates/z00z_wallets/src/core/address/stealth_scan_support.rs`

### Required Live Branch Preservation

📌 These branches must stay live until their canonical owners are preserved and their callers remain valid.

- [ ] Preserve base `derive_k_dh` and request-bound `derive_k_dh_with_req` while removing only duplicate or excessive variants.
- [ ] Preserve both supported `tag16` modes and verify that call sites still choose the correct semantic mode.
- [ ] Preserve `derive_s_out` until its owning path is explicitly converged and revalidated.
- [ ] Preserve `compute_owner_tag` semantics while deleting only the duplicate wallet-local implementation.
- [ ] Reject any cleanup that removes a live branch before its dependent runtime and test paths have been migrated.

## Phase 7. Branches That Currently Look Excessive

📌 The following items do not currently appear to be part of the main sender/build/scan runtime path and must not remain as alternative stealth architecture:

- `derive_k_dh_flexible`
- `derive_k_dh_extended`
- `KeyDerivationContext`
- `crypto_traits::{DerivedKeys, SharedSecretOperations, SymmetricKeyDerivation, DefaultSymmetricDerivation}`

📌 Based on current call sites, these items are mostly exercised by local tests or helper abstractions, not by the main stealth address flow.

📌 Therefore the mandatory disposition is:

- do not add any new production call sites
- do not add any new direct tests as if they were first-class APIs
- migrate all reachable code and tests to canonical paths
- keep only temporary shim retention where required for safe migration
- remove them once canonical migration is complete

📌 They are not a valid long-term branch of the stealth design.

### Quarantine And Removal Rules

📌 The excessive branch list is an execution list, not a vague warning.

- [x] Stop exporting or advertising the excessive branches as normal production-facing API.
- [x] Audit whether any internal caller still depends on each excessive branch before removal.
- [x] Rewrite or delete tests that treat these branches as stable protocol surface.
- [x] Keep only the minimum temporary shim coverage needed to protect migration behavior.
- [x] Remove each excessive branch once its remaining call sites and migration guards are gone.

## Phase 8. Confirmed One-Source-Of-Truth Violations

### 1. `compute_owner_tag` Is Duplicated In Wallet Stealth Output

📌 `crates/z00z_wallets/src/core/stealth/output.rs` defines its own `compute_owner_tag` using `OwnerTagDomain` directly.

📌 `crates/z00z_crypto/src/kdf.rs` already defines canonical `compute_owner_tag`.

📌 This is a direct duplication and should be removed by delegation or re-export. No second implementation should remain.

- [x] Replace the local `compute_owner_tag` implementation in `crates/z00z_wallets/src/core/stealth/output.rs` with delegation to the crypto owner.
- [x] Confirm that sender, validator, and receiver owner-tag checks still produce byte-identical results after delegation.
- [x] Remove any test logic that implicitly treats the local output.rs helper as an independent owner.
- [x] Keep the call-site surface stable where possible so this cleanup does not trigger unrelated churn.
- [x] Mark this violation resolved only when one canonical implementation remains in production code.

### 2. Wallet `compute_leaf_ad` Must Stay In Canonical Argument Order

📌 `crates/z00z_wallets/src/core/stealth/tag.rs` owns canonical wallet `compute_leaf_ad(asset_id, serial_id, r_pub, owner_tag, c_amount)`.

📌 Reordered helper shapes are not allowed to survive in the implementation path because they obscure the canonical owner and encourage argument-order drift.

📌 Wallet runtime callers must use `compute_leaf_ad(asset_id, serial_id, r_pub, owner_tag, c_amount)` directly.

- [x] Avoid adding new call sites to any reordered wrapper when the canonical wallet order is available.
- [x] Remove the reordered wrapper once all callers can safely use the canonical wallet `compute_leaf_ad` signature.
- [x] Reject any code review argument that a convenient wrapper should survive next to the canonical owner.

### 3. Wallet `compute_leaf_ad` And Crypto `derive_leaf_ad` Must Not Be Mixed

📌 `crates/z00z_wallets/src/core/stealth/tag.rs::compute_leaf_ad` and `crates/z00z_crypto/src/kdf.rs::derive_leaf_ad` take the same field set, but current repository tests explicitly assert that they produce different outputs.

📌 This is not a cosmetic naming issue. It is a cryptographic boundary.

📌 Therefore the cleanup rule is strict:

- wallet runtime output build, validation, and scan paths must keep using wallet `compute_leaf_ad`
- crypto `derive_leaf_ad` must not be substituted into wallet runtime paths as a drop-in replacement
- any future convergence of these two formulas requires explicit protocol decision, regenerated vectors, and migration review

- [x] Keep wallet runtime output, validation, and scan paths on wallet `compute_leaf_ad` until an explicit protocol migration exists.
- [x] Preserve tests that prove wallet and crypto leaf bindings are different where that distinction protects against accidental substitution.
- [x] Do not refactor by “normalizing” names or parameters if the underlying domains differ.
- [x] Treat any future leaf binding convergence as a separate protocol project with regenerated vectors and acceptance review.
- [x] Reject any cleanup step that silently swaps `derive_leaf_ad` into wallet runtime because the signatures look compatible.

### 4. Crypto Has Two Overlapping Stealth ECDH Surfaces

📌 `crates/z00z_crypto/src/ecdh.rs` and `crates/z00z_crypto/src/ecdh_stealth.rs` overlap in responsibility.

📌 The wallet code currently relies on `z00z_crypto::ecdh` via `facade_ecdh.rs`, while `ecdh_stealth.rs` provides a second bytes-oriented stealth ECDH path with additional result wrappers.

📌 This overlap should be treated as a consolidation target. New wallet code should not deepen dependence on both surfaces.

- [x] Audit external and internal call sites to determine whether `ecdh_stealth.rs` provides any unique contract beyond wrappers and packaging.
- [x] Prefer `crates/z00z_crypto/src/ecdh.rs` as the surviving external stealth-ECDH surface unless evidence requires otherwise.
- [x] Prevent new wallet or test code from deepening dependence on both crypto ECDH surfaces simultaneously.
- [x] If `ecdh_stealth.rs` survives temporarily, document an explicit compatibility-only reason for its existence.
- [x] Mark this overlap resolved only when one crypto-level external stealth-ECDH surface remains canonical.

## Phase 9. Address Layer Observations

### 1. `stealth_scanner` Is Not The Formula Owner

📌 `crates/z00z_wallets/src/core/address/stealth_scanner.rs` correctly behaves as a wallet-runtime adapter.

📌 It should keep using shared helpers and must not absorb new cryptographic formulas.

- [x] Keep `stealth_scanner.rs` focused on runtime orchestration, filtering, and adapter behavior.
- [x] Do not move formula definitions, KDF ownership, or canonical leaf verification rules into this file.
- [x] Audit future additions to ensure they delegate to existing owners instead of re-implementing logic locally.
- [x] Keep public guidance pointing to `core::scan` and canonical detection helpers rather than to this adapter file.
- [x] Re-check scan tests so they do not accidentally canonize adapter behavior as formula ownership.

### 2. `stealth_scan_support` Is The Shared Receiver Runtime Core

📌 `crates/z00z_wallets/src/core/address/stealth_scan_support.rs` currently centralizes shared receiver scan logic across canonical leaf scan and runtime asset scan.

📌 That is acceptable, but no new KDF variants should be introduced there. It should call existing canonical primitives only.

- [x] Keep `stealth_scan_support.rs` as shared runtime glue rather than as a new formula owner.
- [x] Restrict the file to calling canonical `k_dh`, owner-tag, tag, and decrypt primitives.
- [x] Reject any new derivation helper added there unless it is a pure wrapper over an existing owner.
- [x] Review scan support changes for whether they preserve canonical leaf-scan authority.
- [x] Keep request-aware and base scan paths aligned with the same canonical primitive set.

### 3. `stealth_request` And `stealth_card` Are Validation And Routing Layers

📌 `crates/z00z_wallets/src/core/address/stealth_request.rs` and `crates/z00z_wallets/src/core/address/stealth_card.rs` validate public keys, signatures, request metadata, and routing identity.

📌 They are not the place to add new stealth derivation logic.

- [x] Keep request and card modules limited to validation, routing, and metadata interpretation.
- [x] Reject any new `k_dh`, tag, owner-tag, or leaf-binding derivation logic added to these files.
- [x] Make request-aware derivation decisions by passing validated request data into canonical owners rather than deriving locally.
- [x] Keep signature and identity validation separate from formula ownership decisions.
- [x] Re-check any future request/card helper so it does not become stealth logic under a validation name.

### 4. `address_manager` Uses HKDF, But Not For Stealth Output Formulas

📌 `crates/z00z_wallets/src/core/address/address_manager.rs` contains wallet cache MAC HKDF derivation.

📌 This is cryptographic code, but it is not stealth-address derivation logic. It should not be mixed into stealth cleanup decisions.

- [x] Keep `address_manager.rs` out of stealth formula ownership changes unless a later section explicitly expands scope.
- [x] Do not use unrelated HKDF usage in address management as justification for stealth KDF refactors.
- [x] Preserve the separation between wallet cache/security helpers and stealth output derivation logic.
- [x] Mention this file in reviews only when clarifying scope boundaries, not when assigning stealth owners.
- [x] Reject cleanup plans that try to “unify all crypto” by folding unrelated address-manager logic into stealth work.

## Phase 10. Implementation Decisions

### Decision 1. Keep Only Two `k_dh` Modes

📌 The implementation-ready spec keeps only these `k_dh` modes as active protocol modes:

- base: `derive_k_dh`
- request-bound: `derive_k_dh_with_req`

📌 `derive_k_dh_flexible` and `derive_k_dh_extended` are not part of the target architecture.

- [x] Keep only base and request-bound `k_dh` modes in the target architecture and public narrative.
- [x] Quarantine flexible and extended `k_dh` branches immediately at the re-export and documentation level.
- [x] Migrate any remaining callers away from flexible and extended variants before removal.
- [x] Preserve request-bound separation and base-mode determinism while shrinking the surface.
- [x] Reject any proposal that adds a third long-term `k_dh` mode without a separate protocol decision.

### Decision 2. Keep Only Two `tag16` Modes

📌 The implementation-ready spec keeps only these `tag16` modes:

- card-bound: `compute_tag16(k_dh, leaf_ad)`
- request-bound: `compute_tag16_with_req(k_dh, req_id)`

📌 No additional tag flavor should be added.

- [x] Keep only the card-bound and request-bound tag flavors in production and in tests.
- [x] Ensure every tag-producing caller knows which mode it is using and why.
- [x] Prevent helper APIs from blurring card-bound and request-bound semantics behind a generic tag name.
- [x] Remove or quarantine any path that implies a third tag flavor or ambiguous binding context.
- [x] Reject documentation or examples that describe `tag16` as a generic primitive detached from its binding mode.

### Decision 3. Keep Wallet `leaf_ad` In One Place

📌 Wallet `leaf_ad` stays owned by `crates/z00z_wallets/src/core/stealth/tag.rs` for now.

📌 The project should not maintain multiple formula implementations with different ownership claims.

- [x] Keep wallet `compute_leaf_ad` ownership centralized in `crates/z00z_wallets/src/core/stealth/tag.rs`.
- [x] Remove or quarantine compatibility-only wrappers that obscure the canonical argument order.
- [x] Preserve runtime call sites on the wallet owner until a protocol-level convergence decision exists.
- [x] Keep tests aligned to the wallet owner where wallet runtime behavior is under test.
- [x] Reject any refactor that creates a second wallet-local leaf binding implementation for convenience.

### Decision 4. Do Not Introduce A New Primitive Trait Yet

📌 The earlier spike idea about a new narrow primitive facade was useful analytically.

📌 The current codebase does not need another trait layer right now.

📌 The first priority is removal of duplication and surface consolidation, not introducing a third abstraction layer.

- [x] Defer any new primitive trait or facade design until the one-source-of-truth cleanup phases are materially complete.
- [x] Do not use new abstraction layers to avoid making explicit ownership decisions now.
- [x] Revisit narrow primitive facade work only after duplicate owners, excessive branches, and overlap paths are under control.
- [x] Keep current cleanup focused on existing modules, owners, and public surfaces.
- [x] Reject any design proposal that adds a third abstraction layer before current duplication has been removed.

## Phase 11. Required Changes By Phase

📌 This section is the implementation plan. It does not mean the work is already done. It defines the exact order in which the repository should be cleaned without introducing new parallel structures.

| Phase | Objective | Primary files | Required outcome |
| --- | --- | --- | --- |
| 1 | Freeze ownership and stop accidental branch growth | `crates/z00z_crypto/src/ecdh.rs`, `crates/z00z_wallets/src/core/stealth/ecdh.rs`, `crates/z00z_wallets/src/core/stealth/tag.rs`, `crates/z00z_wallets/src/core/address/leaf_scan.rs` | no new helper path is introduced while cleanup is in progress |
| 2 | Remove the first confirmed one-source-of-truth violation | `crates/z00z_wallets/src/core/stealth/output.rs` | duplicate `compute_owner_tag` is gone |
| 3 | Narrow public surface so experimental branches stop looking normal | `crates/z00z_wallets/src/core/stealth/mod.rs` | flexible and extended derivation paths are no longer advertised as standard production API |
| 4 | Quarantine remaining experimental internals | `crates/z00z_wallets/src/core/stealth/ecdh.rs`, `crates/z00z_wallets/src/core/stealth/crypto_traits.rs` | experimental internals are removed unless a real internal seam still requires them |
| 5 | Resolve crypto-level stealth ECDH overlap | `crates/z00z_crypto/src/ecdh.rs`, `crates/z00z_crypto/src/ecdh_stealth.rs` | exactly one canonical external stealth-ECDH surface remains |
| 6 | Finalize one public stealth path | `crates/z00z_wallets/src/core/mod.rs`, `crates/z00z_wallets/src/core/stealth/mod.rs`, docs and tests that demonstrate imports | exactly one documented public path remains for ECDH, KDF/tag, and scan work |

📌 The repository must be cleaned in this order. Do not skip directly to overlap resolution while earlier duplication and surface-advertising problems are still present.

📌 The first mandatory local implementation directives are:

1. remove duplicate `compute_owner_tag` from `crates/z00z_wallets/src/core/stealth/output.rs:71`
2. move the experimental `k_dh` surface into quarantine at the public re-export level in `crates/z00z_wallets/src/core/stealth/mod.rs:59`
3. prepare a separate cleanup plan for convergence between `crates/z00z_crypto/src/ecdh_stealth.rs:36` and `crates/z00z_crypto/src/ecdh.rs:232`

### Step 1. Freeze Formula Ownership

📌 Apply these ownership rules:

- point-based base `k_dh` owner: `z00z_crypto/src/ecdh.rs`
- wallet runtime byte/request `k_dh` and `s_out` owner during migration: `z00z_wallets/src/core/stealth/ecdh.rs`
- canonical owner tag owner: `z00z_crypto/src/kdf.rs`
- wallet `tag16` and wallet `leaf_ad` owner: `z00z_wallets/src/core/stealth/tag.rs`
- canonical full leaf detection owner: `z00z_wallets/src/core/address/leaf_scan.rs`

📌 During this phase, no new stealth helper should be added unless it is a pure wrapper over one of these owners.

📌 Exit criteria for Phase 1:

- ownership rules are written down and not contradicted by later sections
- no section of this spec describes flexible or extended derivation as part of the target architecture
- no future cleanup step is allowed to invent a third owner for `owner_tag`, `tag16`, `leaf_ad`, or full-leaf detection

📌 Phase 1 implementation snapshot for the current codebase:

| Touched surface | Classification | Current owner | Phase 1 rule |
| --- | --- | --- | --- |
| `z00z_crypto::ecdh::derive_k_dh(&Z00ZRistrettoPoint)` | canonical primitive owner | `crates/z00z_crypto/src/ecdh.rs` | keep as the only point-based base-`k_dh` owner |
| `compute_dh_sender`, `compute_dh_receiver`, byte `derive_k_dh`, `derive_k_dh_with_req`, `derive_s_out` | transitional runtime owner | `crates/z00z_wallets/src/core/stealth/ecdh.rs` | freeze ownership and do not add new formula branches here |
| `compute_tag16`, `compute_tag16_with_req`, wallet `compute_leaf_ad` | canonical wallet owner | `crates/z00z_wallets/src/core/stealth/tag.rs` | keep wallet binding semantics here |
| `receiver_scan_leaf`, `receiver_scan_report` | canonical detection authority | `crates/z00z_wallets/src/core/address/leaf_scan.rs` | keep full-leaf ownership decisions here |
| `StealthOutputScanner` | adapter only | `crates/z00z_wallets/src/core/address/stealth_scanner.rs` | keep runtime orchestration delegated to canonical owners |
| `z00z_wallets::core::ecdh` | public compatibility facade | `crates/z00z_wallets/src/core/stealth/facade_ecdh.rs` | keep as the documented wallet/app ECDH entrypoint |

- [x] Freeze formula ownership in code review guidance before modifying implementation files.
- [x] Confirm that no new helper path is being introduced under the cover of “temporary migration support”.
- [x] Map each touched stealth function to its current owner and final destination before writing code.
- [x] Ensure later phase work references this frozen ownership set rather than reopening owner debates.
- [x] Mark Phase 1 complete only when all later changes can proceed without ownership ambiguity.

### Step 2. Remove Local Duplication

📌 Implement these local cleanups:

1. Replace `output.rs::compute_owner_tag` with delegation to the canonical crypto implementation.
2. Remove any reordered `compute_leaf_ad` wrapper once call sites can use the canonical wallet owner safely.
3. Stop re-exporting or advertising flexible and extended `k_dh` derivation as normal production API.
4. Mark `core::stealth::ecdh.rs` as transitional runtime ownership, not as a second permanent architecture.

📌 The first required concrete cleanup is item 1 above: remove the duplicate `compute_owner_tag` from `crates/z00z_wallets/src/core/stealth/output.rs`.

📌 Target code location for this cleanup: `crates/z00z_wallets/src/core/stealth/output.rs:71`.

📌 Exit criteria for Phase 2:

- `crates/z00z_wallets/src/core/stealth/output.rs` no longer owns an independent `compute_owner_tag`
- sender and validator paths still produce the same owner-tag bytes as before
- tests that cover owner-tag logic continue to validate the canonical crypto formula rather than a local duplicate

- [x] Replace the duplicate owner-tag implementation in `output.rs` with delegation to `z00z_crypto/src/kdf.rs`.
- [x] Keep call-site semantics stable so sender, validator, and receiver code are not forced into unrelated churn.
- [x] Re-run owner-tag-focused tests after the delegation change and confirm byte-for-byte parity.
- [x] Remove any documentation or test wording that still presents `output.rs` as an owner-tag owner.
- [x] Close this phase only when one canonical `compute_owner_tag` implementation remains in production code.

### Step 3. Shrink Experimental Surface

📌 Treat the following as legacy or experimental until proven necessary:

- `derive_k_dh_flexible`
- `derive_k_dh_extended`
- `KeyDerivationContext`
- `crypto_traits.rs`

📌 This phase does not require immediate deletion. It requires quarantine:

- no new production usage
- document as non-canonical
- remove from primary implementation narrative

📌 The first required public-surface cleanup in this phase is: narrow `crates/z00z_wallets/src/core/stealth/mod.rs` so that `derive_k_dh_flexible`, `derive_k_dh_extended`, `KeyDerivationContext`, and trait-based experimental helpers no longer look like normal production exports.

📌 Target public re-export location for this cleanup: `crates/z00z_wallets/src/core/stealth/mod.rs:59`.

📌 Exit criteria for Phase 3:

- flexible and extended derivation helpers are not part of the default public story
- imports from `z00z_wallets::core::stealth` no longer suggest those branches are canonical
- tests that still touch experimental internals are clearly transitional and not protocol-defining

- [x] Narrow `crates/z00z_wallets/src/core/stealth/mod.rs` re-exports so experimental branches stop looking public and normal.
- [x] Update examples and tests that currently import experimental helpers through the default public story.
- [x] Keep any remaining experimental coverage clearly labeled as transitional or internal.
- [x] Avoid renaming-only changes that preserve the same public ambiguity under a new symbol name.
- [x] Close this phase only when developers are no longer naturally guided toward experimental branches.

### Step 4. Quarantine Remaining Experimental Internals

📌 After public re-exports are narrowed, the remaining experimental internals must be reviewed locally rather than globally rewritten.

📌 Required actions:

1. Keep `derive_k_dh_flexible`, `derive_k_dh_extended`, and `KeyDerivationContext` only if an internal caller still genuinely needs them.
2. Keep `crypto_traits.rs` only if it still protects a real internal seam; otherwise remove it.
3. Do not add new tests that elevate these branches back into protocol status.

📌 Exit criteria for Phase 4:

- experimental internals are removed or explicitly justified by a real internal seam
- no new production code is routed through them
- the spec narrative no longer depends on them for the normal stealth flow

- [x] Audit internal callers of `derive_k_dh_flexible`, `derive_k_dh_extended`, and `KeyDerivationContext` one by one.
- [x] Keep only the minimal internal remnants that still protect active runtime behavior.
- [x] Mark any surviving experimental internals with a clear transitional purpose and removal trigger.
- [x] Remove or rewrite tests that keep these internals alive without a real runtime consumer.
- [x] Close this phase only when experimental internals no longer influence the documented normal stealth path.

### Step 5. Consolidate Overlapping Crypto ECDH APIs

📌 Decide whether `z00z_crypto/src/ecdh_stealth.rs` remains a supported external helper layer or is folded into the canonical `ecdh.rs` path.

📌 This phase must happen only after call-site audit and tests, because the overlap is real but not all consumers may be visible from wallet-runtime paths alone.

📌 This phase requires a separate cleanup plan that explicitly covers the convergence between the overlapping entrypoints in `crates/z00z_crypto/src/ecdh_stealth.rs` and the canonical base `derive_k_dh` owner inside `crates/z00z_crypto/src/ecdh.rs`.

📌 Target audit anchors for that plan:

- `crates/z00z_crypto/src/ecdh_stealth.rs:36`
- `crates/z00z_crypto/src/ecdh.rs:232`

📌 Decision rule for Phase 5:

- if `ecdh_stealth.rs` provides no unique external contract beyond wrappers and alternate result packaging, `ecdh.rs` should remain the canonical external stealth-ECDH surface
- if `ecdh_stealth.rs` is still required for a stable external API, then `ecdh.rs` and `ecdh_stealth.rs` must have explicit non-overlapping responsibility boundaries documented in code and tests

📌 Current recommendation from code inspection: prefer `crates/z00z_crypto/src/ecdh.rs` as the likely surviving canonical external stealth-ECDH surface, and treat `crates/z00z_crypto/src/ecdh_stealth.rs` as an overlap candidate that must justify its survival.

### Step 5A. Convergence Map Between `ecdh.rs` And `ecdh_stealth.rs`

📌 The overlap audit must distinguish direct formula ownership from bytes-oriented convenience wrappers and packaging helpers.

| Surface in `crates/z00z_crypto/src/ecdh.rs` | Overlapping or related surface in `crates/z00z_crypto/src/ecdh_stealth.rs` | Audit classification | Convergence rule |
| --- | --- | --- | --- |
| `compute_stealth_dh_sender` | `compute_stealth_dh` | direct stealth-ECDH overlap | new code should prefer the `ecdh.rs` point owner |
| `recover_stealth_dh_receiver` | `recover_stealth_dh` | direct stealth-ECDH overlap | new code should prefer the `ecdh.rs` point owner |
| `derive_k_dh` | `EcdhSenderResult::derive` and `EcdhReceiverResult::derive` via `kdf_from_dh` | same derivation chain packaged differently | keep `derive_k_dh` canonical and treat result wrappers as compatibility-only unless a public contract proves otherwise |
| point validation in `validate_stealth_point` | `validate_ecdh_input` and `parse_and_validate_r_pub` | partially overlapping validation role | keep canonical point validation in `ecdh.rs`; retain byte-parse helpers only if a bytes-oriented public contract still needs them |
| raw point output path | `encode_dh_point`, `decode_dh_point`, `EcdhSenderResult`, `EcdhReceiverResult`, `EcdhStealth`, `LeafOwner`, `scan_asset_leaf_owner` | packaging and helper surface, not canonical primitive ownership | justify each survivor as compatibility-only or remove it from the canonical public story |

📌 Current repository audit result:

- no non-test in-repository call sites currently require `crates/z00z_crypto/src/ecdh_stealth.rs` directly
- the overlap is therefore primarily a public-export and compatibility-surface problem, not a proven runtime dependency problem
- the burden of proof is on `ecdh_stealth.rs`, not on `ecdh.rs`

- [x] Treat `compute_stealth_dh_sender`, `recover_stealth_dh_receiver`, and `derive_k_dh` in `ecdh.rs` as the canonical primitive chain during convergence.
- [x] Treat `ecdh_stealth.rs` wrappers and result structs as compatibility-only until a concrete external contract justifies survival.
- [x] Keep byte parsing and validation helpers only if their callers cannot be routed through the surviving canonical public path.
- [x] Do not add new code that depends on `EcdhStealth`, `EcdhSenderResult`, or `EcdhReceiverResult` while Phase 5 is open.
- [x] Resolve Phase 5 only after every surviving `ecdh_stealth.rs` export has an explicit compatibility reason or has been removed from the canonical public story.

📌 Exit criteria for Phase 5:

- exactly one crypto-level external stealth-ECDH surface is documented as canonical
- the surviving surface is the one referenced by future stealth cleanup work
- the non-canonical overlap path is either removed or explicitly documented as a compatibility layer only

📌 Phase 5 decision now in force:

- `crates/z00z_crypto/src/ecdh.rs` is the authoritative crypto-level stealth-ECDH surface for future work
- `crates/z00z_crypto/src/ecdh_stealth.rs` remains only as a hidden compatibility layer for bytes-oriented wrappers and legacy packaging helpers
- root-level `z00z_crypto` re-exports no longer present `ecdh_stealth.rs` as part of the canonical public story

- [x] Compare `crates/z00z_crypto/src/ecdh.rs` and `crates/z00z_crypto/src/ecdh_stealth.rs` function by function and classify overlap versus unique contract.
- [x] Prefer `ecdh.rs` as the surviving canonical external surface unless a concrete compatibility requirement disproves that choice.
- [x] Stop new code from depending on both surfaces during the audit period.
- [x] Document the explicit fate of the non-canonical surface: removal or compatibility-only retention.
- [x] Close this phase only when one crypto-level external stealth-ECDH path is authoritative.

### Step 6. Finalize One Public Stealth Path

📌 After formula-level cleanup is complete, the repository must end with one public path for developers who work with stealth addresses.

📌 Required actions:

1. Treat `z00z_wallets::core::ecdh` as the only documented public ECDH entrypoint for wallet and app code.
2. Treat `z00z_wallets::core::kdf` as the only documented public KDF and tag entrypoint for wallet and app code.
3. Treat `z00z_wallets::core::scan` as the only documented public scan entrypoint for full-leaf ownership checks.
4. Do not document internal `core::stealth::*` implementation modules as parallel public usage paths.

📌 Exit criteria for Phase 6:

- one public ECDH path remains for stealth work
- one public KDF path remains for stealth work
- one public scan path remains for stealth work
- internal modules are implementation detail, not competing public guidance

- [x] Lock public documentation and examples onto `z00z_wallets::core::ecdh`, `z00z_wallets::core::kdf`, and `z00z_wallets::core::scan`.
- [x] Remove or quarantine public re-exports that make internal `core::stealth::*` modules look equally supported.
- [x] Update tests and example code that still demonstrate mixed internal import routes as normal usage.
- [x] Verify that developers can complete common stealth tasks without needing to discover internal modules.
- [x] Close this phase only when one public path remains per stealth task category.

## Changes Explicitly Out Of Scope

📌 This spec does not recommend these actions in the same implementation pass:

- moving wallet `tag16` into `z00z_crypto`
- rewriting request or card wire formats
- redesigning scanner policy
- replacing current stealth protocol with `stealth_address_kit`
- introducing a brand-new stealth abstraction hierarchy

### Forbidden Cleanup Moves

📌 The out-of-scope list is a hard guardrail for implementation planning.

- [ ] Reject cleanup work that rewrites wire formats, scanner policy, or protocol semantics under the name of source-of-truth cleanup.
- [ ] Reject attempts to move wallet `tag16` ownership into crypto during the current phases.
- [ ] Reject complete protocol replacement with `stealth_address_kit`.
- [ ] Reject introduction of a new stealth abstraction hierarchy before current duplication and overlap are removed.
- [ ] Keep implementation discussion focused on the constrained cleanup plan rather than adjacent redesign ideas.

## Acceptance Conditions

📌 The implementation aligned with this spec should satisfy all of the following:

1. There is exactly one canonical `compute_owner_tag` implementation.
2. Production stealth flow uses only base and request-bound `k_dh` derivation.
3. Production stealth flow uses only card-bound and request-bound `tag16` derivation.
4. `leaf_scan` remains the full-leaf detection authority exposed through the `core::scan` facade.
5. `stealth_scanner` remains an adapter.
6. No new stealth formula is introduced in `core/address`.
7. No new overlapping stealth ECDH API is added in `z00z_crypto`.
8. Wallet runtime paths never treat crypto `derive_leaf_ad` as a drop-in replacement for wallet `compute_leaf_ad`.
9. Transitional runtime ownership does not remain the final documented steady state.
10. There is exactly one documented public stealth-address path for ECDH, one for KDF/tag work, and one for full-leaf scan work.

### Final Acceptance Gate

📌 No cleanup is complete until every acceptance condition below is materially true in code, tests, and public usage guidance.

- [x] Verify that one canonical `compute_owner_tag` implementation remains and all duplicate owners are gone.
- [x] Verify that only the allowed `k_dh` and `tag16` modes remain in the production story.
- [x] Verify that `leaf_scan` remains the full-leaf detection authority and `stealth_scanner` remains adapter-only.
- [x] Verify that crypto and wallet `leaf_ad` formulas are not silently conflated.
- [x] Verify that the final public stealth path is singular for ECDH, KDF/tag, and scan work.

## Bottom Line

📌 The current codebase does not need a bigger stealth architecture.

📌 It needs a smaller one:

- one canonical owner per formula
- one canonical public path for each stealth task category
- two real `k_dh` modes
- two real `tag16` modes
- no growth of experimental derivation branches
- no duplication of owner-tag logic

📌 That is the implementation-ready direction consistent with the current repository state.

### Final Architecture Target

📌 This bottom line is the end-state contract, not a slogan.

- [x] End with one canonical owner per formula that still needs a distinct formula owner.
- [x] End with one canonical public path per stealth task category so developers are not forced to choose between parallel routes.
- [x] End with only the two justified `k_dh` modes and two justified `tag16` modes.
- [x] End without duplicate owner-tag logic and without experimental derivation branches presented as normal API.
- [x] Treat the cleanup as complete only when the repository state matches this end-state contract, not merely when a few files are refactored.
