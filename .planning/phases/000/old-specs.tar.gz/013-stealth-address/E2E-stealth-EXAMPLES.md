# E2E Stealth Examples and Integration Test Plan

📌 This document proposes end-to-end integration tests and end-to-end examples for the stealth-address implementation defined by `specs/013-stealth-address/stealth-spec.md`.

📌 The goal is not to add more unit coverage for internal helpers. The goal is to prove that the implemented stealth flow works correctly through the canonical public surfaces, with realistic sender, receiver, wallet, scanner, and simulator interactions.

📌 Every proposed test and example below is designed to validate the current canonical public path:

- `z00z_wallets::core::ecdh`
- `z00z_wallets::core::kdf`
- `z00z_wallets::core::scan`
- stable sender-output facade exported from `z00z_wallets`

📌 This document must stay aligned with the actual stealth cleanup contract. It is not enough for a scenario to be interesting. It must also prove one or more acceptance conditions from `stealth-spec.md`.

## Scope

📌 These proposals target full-flow behavior, not isolated formulas.

📌 Each proposed E2E test or example should prove at least one of the following:

- public-path singularity is preserved
- sender and receiver derive compatible stealth artifacts
- scan and wallet decode behavior stay consistent
- request-bound and non-request-bound paths behave correctly
- tampering is rejected at the correct gate
- non-owners cannot incorrectly classify outputs as owned
- simulator and wallet runtime flows remain aligned with the same canonical formulas
- card-bound and request-bound derivation modes do not get blurred together
- persistence, replay, and resume flows do not silently break stealth ownership semantics

## Current Gaps In The First Draft

📌 The first draft of this document was directionally correct, but not complete enough as an implementation-quality validation plan.

📌 The main gaps were:

- it did not explicitly map proposed scenarios to the spec acceptance gate
- it did not clearly separate card-bound and request-bound `tag16` coverage
- it did not include persistence or resume-oriented E2E coverage
- it did not explicitly document anti-patterns that would create fake confidence
- it did not define the minimum artifact and fixture discipline for repeatable E2E tests

📌 The updated version below closes those gaps.

## E2E Test Design Rules

📌 Every new E2E stealth test should follow these rules.

- Use only canonical public facades or stable public wallet exports in the test body.
- Do not import internal `core::stealth::*` modules as the main test path.
- Build realistic leaf/output data instead of mocking cryptographic fields by hand unless the test explicitly targets tamper rejection.
- Check both positive and negative outcomes in the same scenario when that improves signal.
- Prefer actor-named flows such as Alice, Bob, and Carol so test intent stays readable.
- Validate the exact failure class when the flow is expected to reject malformed or foreign outputs.
- Keep deterministic seeds or fixture builders for any scenario that would otherwise become flaky.
- Require every E2E test file header to name which spec acceptance points it covers.
- Treat persistence, import/export, and simulator replay paths as first-class E2E surfaces, not as optional extras.

## Required Scenario Dimensions

📌 A complete E2E stealth suite should not only vary actors. It must vary semantic modes.

| Dimension | Required values | Why it matters |
| --- | --- | --- |
| `k_dh` mode | base, request-bound | spec keeps exactly two justified modes |
| `tag16` mode | card-bound, request-bound | spec keeps exactly two justified modes |
| ownership verdict | mine, not-mine, invalid | scan authority and validation taxonomy must stay coherent |
| artifact path | direct wallet flow, simulator flow, persisted/reloaded flow | runtime drift often appears across boundaries |
| integrity state | valid, tampered | E2E must prove rejection ordering and not only happy paths |

📌 If an E2E suite covers only the happy-path card-bound flow, it is not sufficient evidence for full stealth-spec compliance.

## Proposed E2E Integration Tests

### Phase 1

### 1. Sender To Receiver Canonical Flow

📌 Purpose: prove the simplest end-to-end stealth path works through the canonical public API.

📌 What to test:

- Alice builds one stealth output for Bob.
- Bob scans the produced leaf through the canonical scan facade.
- Bob successfully decrypts and recovers the expected asset/value.
- Carol scans the same leaf and does not classify it as owned.

📌 What it proves:

- sender-output builder, KDF/tag binding, and full-leaf scan agree on one flow
- the public path is sufficient for normal receiver ownership detection
- ownership is exclusive to the intended receiver

📌 Suggested assertions:

- Bob gets `Mine`.
- Carol gets `NotMine` or equivalent non-owned result.
- recovered `asset_id`, `serial_id`, `value`, and `owner_tag` match expectations.

📌 Implementation checklist:

 [x] Create one dedicated E2E test file for the canonical send-and-scan flow and name it so the file scope is unambiguous.
 [x] Define deterministic fixtures for Alice sender state, Bob receiver card, and Carol foreign receiver card.
 [x] Build the output only through the stable sender-output public facade exported from `z00z_wallets`.
 [x] Forbid direct use of internal `core::stealth::*` imports in this test file.
 [x] Scan the produced output through the canonical `z00z_wallets::core::scan` facade.
 [x] Assert Bob receives the owned verdict and Carol receives a non-owned verdict on the exact same output instance.
 [x] Assert the recovered payload fields include the expected asset identifier, serial, value, and ownership-bound fields.
 [x] Assert the same scenario does not depend on simulator-only helpers, persistence helpers, or test-only backdoors.
 [x] Add a file header comment that explicitly states which stealth-spec acceptance conditions this test covers.
 [x] Mark the scenario done only when the test proves both positive ownership and foreign rejection in one run.

### 2. Request-Bound Payment Flow

📌 Purpose: prove that request-bound stealth output generation is distinct from the base path and still interoperable with canonical scan logic.

📌 What to test:

- Bob publishes a payment request with `req_id`.
- Alice builds a request-bound stealth output using that request.
- Bob opens it successfully with the request-bound derivation path.
- The same output must not open under the plain non-request path.

📌 What it proves:

- the repository still supports exactly the justified request-bound branch
- request binding affects `k_dh` semantics as intended
- the current transitional runtime owner behavior remains live and correct

📌 Suggested assertions:

- request-bound decrypt succeeds
- plain-path decrypt fails
- request mismatch fails deterministically
- request-bound tag mode is not silently substituted with card-bound tag mode

📌 Implementation checklist:

- [x] Create a separate E2E test file for request-bound flow rather than folding it into the base-path happy-path test.
- [x] Build deterministic request fixtures including `req_id`, receiver request metadata, and one sender action bound to that request.
- [x] Generate the output through the supported request-aware public path only.
- [x] Open or validate the output once with the correct request context and once without request context.
- [x] Add a third branch that uses the wrong request identifier and verify it fails deterministically.
- [x] Assert the request-bound success path does not accidentally succeed through the plain base-path derivation route.
- [x] Assert the tag behavior corresponds to request-bound semantics and is not silently interchangeable with card-bound tag behavior.
- [x] Capture the exact failure class or message family for plain-path and wrong-request failure so the test guards semantic drift, not only generic rejection.
- [x] Document in the test header that this file exists to protect the spec rule that only base and request-bound `k_dh` modes survive.
- [x] Mark the scenario done only when success, plain-path failure, and wrong-request failure are all covered in one deterministic test suite.

### Phase 2

### 3. Tag16 Fast-Reject Versus Full Scan Authority

📌 Purpose: prove the runtime scanner remains an adapter and does not override full-leaf authority.

📌 What to test:

- Build a valid output for Bob.
- Run the tag16-prefilter path and the full-leaf scan path.
- Confirm that a matching tag still requires the leaf scan to classify ownership.
- Confirm that a forced tag mismatch rejects early without accidental ownership detection.

📌 What it proves:

- `stealth_scanner` remains an orchestration/prefilter layer
- `leaf_scan` remains the ownership authority
- tag16 is an accelerator, not an ownership proof

📌 Suggested assertions:

- matching tag plus valid leaf yields `Mine`
- mismatched tag rejects earlier than decrypt
- tag match alone never upgrades a foreign output to `Mine`
- card-bound and request-bound tag computations stay distinguishable in call-site behavior

📌 Implementation checklist:

- [x] Create one test focused on card-bound tag flow and one test focused on request-bound tag flow; do not blur them into one generic tag helper test.
- [x] Produce at least one valid output whose tag matches the intended receiver path.
- [x] Produce at least one controlled mismatch where the tag gate should reject before ownership classification proceeds.
- [x] Exercise both the prefilter/orchestration path and the full-leaf authority path on the same artifacts.
- [x] Assert that `leaf_scan` is the final ownership authority even when a prefilter signal matches.
- [x] Assert that a matching tag without valid full-leaf semantics never results in owned classification.
- [x] Assert that request-bound tag mode and card-bound tag mode remain behaviorally distinct at the call-site level.
- [x] Forbid this test from making ownership claims based only on tag equality.
- [x] Record in the test header that the scenario protects the spec requirement that `stealth_scanner` is adapter-only and `leaf_scan` is authoritative.
- [x] Mark the scenario done only when it proves both early reject behavior and final authority behavior.

### 4. Wallet Runtime And Leaf Scan Parity

📌 Purpose: prove that direct wallet output handling and standalone scan helpers produce the same ownership verdict and recovered fields.

📌 What to test:

- Generate a valid stealth output.
- Feed it into wallet runtime handling.
- Feed the same output into direct full-leaf scan.
- Compare ownership verdict, recovered asset payload, and critical decrypted fields.

📌 What it proves:

- wallet runtime and scan facade use the same effective semantics
- no drift exists between integration flow and scan-only flow

📌 Suggested assertions:

- both paths agree on owned/not-owned classification
- both paths agree on recovered plaintext fields

📌 Implementation checklist:

- [x] Build one valid output artifact using the supported public sender path.
- [x] Feed the exact same artifact into the wallet runtime consumption path.
- [x] Feed the exact same artifact into the standalone canonical full-leaf scan path.
- [x] Capture ownership verdict, decrypted payload fields, and any recovered binding fields from both paths.
- [x] Assert both paths agree on owned classification for the valid receiver.
- [x] Add one foreign-receiver branch and assert both paths also agree on non-owned classification.
- [x] Assert the recovered plaintext value, `s_out`, and binding-relevant fields are identical across both paths.
- [x] Ensure the scenario fails if either path starts using a different semantic owner for `leaf_ad`, `tag16`, or decryption.
- [x] Add a direct note in the test header that the goal is parity between integration runtime and canonical scan semantics.
- [x] Mark the scenario done only when owned parity and foreign parity are both verified.

### Phase 3

### 5. Output Self-Validation And Tamper Taxonomy

📌 Purpose: prove that the implemented self-validation path rejects different tamper classes at the correct gate.

📌 What to test:

- Start from one valid output.
- Create variants with independent tampering of:
  - `tag16`
  - `enc_pack`
  - `c_amount`
  - range proof
  - declared value or asset binding
- Run canonical self-validation and receiver scan/decrypt checks.

📌 What it proves:

- integrity gates are ordered coherently
- malformed outputs fail for the real reason, not by accidental downstream fallout
- stealth output validation remains cryptographically meaningful

📌 Suggested assertions:

- tag tamper fails as tag mismatch
- pack tamper fails as decrypt/auth failure
- commitment tamper fails as commitment mismatch
- range-proof tamper fails as range proof failure
- request mismatch does not collapse into a misleading generic ownership success

📌 Implementation checklist:

- [x] Start from one canonical valid output fixture and store it as the only source object for all tamper variants.
- [x] Create independent tamper variants for `tag16`, encrypted payload, commitment, range proof, value binding, and request binding.
- [x] Ensure each tamper variant mutates exactly one semantic layer at a time.
- [x] Run canonical self-validation on every variant before running any wallet-level ownership flow that could hide the first failure class.
- [x] Record the expected rejection class for each tamper variant before writing assertions.
- [x] Assert each variant fails at the intended gate instead of merely failing somewhere downstream.
- [x] Add at least one check that verifies a request mismatch never degrades into a false owned result.
- [x] Keep the baseline valid artifact in the same suite and assert it still passes, so the test does not become a pure rejection harness.
- [x] Document the taxonomy table or mapping in the file header or adjacent test comments so the rejection contract stays explicit.
- [x] Mark the scenario done only when every tamper class maps to one stable rejection reason and the valid baseline still passes.

### 6. Foreign Output Isolation Test

📌 Purpose: prove that multiple receiver wallets can scan a mixed set of outputs without cross-ownership leakage.

📌 What to test:

- Generate a batch of outputs for Bob, Carol, and Dave.
- Each actor scans the full shared set.
- Every actor should recover only their own outputs.
- No actor should get false positives from another actor’s outputs.

📌 What it proves:

- ownership detection is stable in mixed-wallet datasets
- `owner_tag`, `k_dh`, and decrypt path do not leak ownership across receivers
- batch scanning remains correct under realistic multi-actor conditions

📌 Suggested assertions:

- each actor finds exactly the outputs addressed to them
- total recovered count equals total produced owned outputs
- no duplicate ownership claims occur across actors

📌 Implementation checklist:

- [x] Define deterministic fixtures for at least three receivers with distinct cards and keys.
- [x] Generate a mixed batch where each receiver has at least one owned output and at least one foreign output in the shared dataset.
- [x] Randomize or deliberately interleave batch order so the test does not rely on grouped outputs by owner.
- [x] Run the same batch through each receiver wallet or scan context independently.
- [x] Capture the exact set of owned serials or asset identifiers recovered by each actor.
- [x] Assert each actor recovers only the outputs addressed to that actor and no others.
- [x] Assert no output is simultaneously classified as owned by two different receivers.
- [x] Assert the aggregate owned counts across all actors equal the total intended output count.
- [x] Add one intentionally foreign-only actor to prove the zero-owned path is also correct.
- [x] Mark the scenario done only when mixed-batch exclusivity and count conservation are both proven.

### 7. Public Path Enforcement Test

📌 Purpose: prove that supported examples and integration tests use only the intended public stealth surfaces.

📌 What to test:

- Grep-style or compile-time policy test over examples and integration tests.
- Ensure public-facing code imports stealth functionality from `z00z_wallets`, `z00z_wallets::core::ecdh`, `z00z_wallets::core::kdf`, or `z00z_wallets::core::scan`.
- Reject direct public usage of internal `z00z_wallets::core::stealth::*` as the main path.

📌 What it proves:

- documentation and examples teach the intended architecture
- the spec public-path contract stays materially true over time

📌 Implementation checklist:

- [x] Define the exact set of directories to police, including public examples, integration tests, and developer-facing docs snippets if they are compiled or grepped in CI.
- [x] Encode an allowlist of supported import surfaces: `z00z_wallets`, `z00z_wallets::core::ecdh`, `z00z_wallets::core::kdf`, and `z00z_wallets::core::scan`.
- [x] Encode a denylist for internal public-story violations such as direct `z00z_wallets::core::stealth::*` imports in public-facing code.
- [x] Exclude legitimate internal implementation files so the test does not generate false positives.
- [x] Make the policy fail loudly with the violating file path and import string.
- [x] Cover both examples and tests so public usage guidance cannot drift in one area while staying clean in another.
- [x] Keep the rule strict enough that a developer cannot satisfy it by adding a second public-looking alias.
- [x] Document the allowed and forbidden paths inside the policy test itself.
- [x] Wire the test or script into the same CI path as the stealth integration suite.
- [x] Mark the scenario done only when a deliberate forbidden import causes a reproducible failure in the policy guard.

### Phase 4

### 8. Simulator And Wallet Flow Consistency Test

📌 Purpose: prove that simulator Stage-3 and Stage-4 stealth flows remain aligned with wallet canonical behavior.

📌 What to test:

- Build simulator outputs through simulator flow.
- Re-scan or validate them through wallet canonical scan/validation paths.
- Confirm simulator-generated outputs satisfy wallet-side decrypt, tag, commitment, and range-proof gates.

📌 What it proves:

- simulator helpers do not drift away from wallet production semantics
- Stage-3 and Stage-4 remain valid consumers of the stealth spec

📌 Implementation checklist:

- [x] Select one simulator-produced stealth artifact path from Stage-3 and one from Stage-4 if they exercise materially different logic.
- [x] Generate artifacts through the simulator code path without rewriting them to wallet-native fixtures by hand.
- [x] Pass the resulting artifacts into wallet canonical scan and validation paths unchanged.
- [x] Assert wallet-side decrypt, tag, commitment, and range-proof checks all succeed for valid simulator artifacts.
- [x] Add at least one negative branch where a tampered simulator artifact is rejected by wallet-side validation.
- [x] Record the exact fields that must round-trip consistently between simulator and wallet layers.
- [x] Ensure the scenario uses canonical wallet facades for the consumer side, not simulator-local helper logic for both producer and verifier.
- [x] Add a test note that this scenario exists to catch semantic drift between subsystem boundaries.
- [x] Keep the fixture deterministic enough that simulator output changes indicate real semantic drift instead of flaky randomness.
- [x] Mark the scenario done only when valid simulator artifacts pass and tampered simulator artifacts fail under wallet verification.

### 9. Persisted Wallet Reload And Re-Scan Flow

📌 Purpose: prove that stealth ownership semantics survive wallet persistence and reload boundaries.

📌 What to test:

- Bob receives one or more valid stealth outputs.
- Bob persists wallet state or the relevant runtime snapshot.
- Bob reloads the wallet or snapshot in a fresh runtime.
- The same outputs are re-scanned or reopened after reload.

📌 What it proves:

- persistence does not lose the material needed for stealth ownership recovery
- receive flow and reload flow stay behaviorally aligned
- the stealth implementation works in a realistic user lifecycle, not only in one in-memory test session

📌 Suggested assertions:

- outputs owned before reload are still owned after reload
- recovered payload fields stay stable across reload
- no foreign output becomes owned after reload

📌 Implementation checklist:

- [x] Define one realistic receive scenario that produces at least one owned output and at least one foreign output before persistence.
- [x] Persist the wallet state, snapshot, or equivalent approved runtime artifact using the normal supported path.
- [x] Tear down the in-memory context completely so reload is not accidentally reading cached state.
- [x] Recreate a fresh runtime and reload only from persisted artifacts.
- [x] Re-scan or reopen the same outputs after reload using the same canonical public surfaces used before reload.
- [x] Assert every output that was owned before persistence is still owned after reload.
- [x] Assert recovered plaintext fields and key binding artifacts are unchanged across reload.
- [x] Assert foreign outputs remain foreign after reload.
- [x] Reject the implementation if the test passes only because the scenario rebuilt keys or ownership context from ad hoc side channels.
- [x] Mark the scenario done only when pre-reload and post-reload ownership parity is explicit and deterministic.

### 10. Replay And Duplicate Delivery Flow

📌 Purpose: prove that repeated delivery of the same stealth artifact does not create inconsistent ownership or acceptance behavior.

📌 What to test:

- Deliver the same valid stealth output more than once.
- Scan it more than once in the same wallet context.
- Scan it again after state refresh or resume.
- Combine duplicate delivery with mixed valid and foreign outputs.

📌 What it proves:

- duplicate observation does not become false ownership inflation
- resume and replay boundaries do not corrupt classification
- stealth ownership remains stable under realistic sync or inbox replay conditions

📌 Suggested assertions:

- repeated valid delivery does not change recovered semantics
- duplicate handling is deterministic
- foreign duplicates remain foreign

📌 Implementation checklist:

- [x] Create one valid owned artifact and one foreign artifact to serve as the duplicate-delivery fixtures.
- [x] Deliver the same valid owned artifact multiple times into the same receiver flow.
- [x] Deliver the same foreign artifact multiple times into the same receiver flow.
- [x] Repeat the scan or intake process after a refresh, resume, or new runtime session if that path exists.
- [x] Assert duplicate valid delivery does not change recovered plaintext semantics or ownership classification.
- [x] Assert duplicate foreign delivery remains foreign on every pass.
- [x] Assert the system does not inflate ownership counts or produce contradictory owned/not-owned outcomes across repeats.
- [x] If deduplication exists, assert it behaves deterministically; if deduplication does not exist, assert repeated classification is still semantically stable.
- [x] Document whether the scenario is protecting replay safety, duplicate inbox handling, or both.
- [x] Mark the scenario done only when same-artifact repetition is proven stable across both owned and foreign cases.

## Proposed E2E Examples

### Phase 5

### 1. Minimal Alice To Bob Stealth Walkthrough

📌 Purpose: the smallest developer-facing example that demonstrates the canonical send-and-scan flow.

📌 It should show:

- create Bob receiver card
- Alice builds stealth output through stable public sender API
- Bob scans via canonical scan facade
- Bob prints recovered ownership result

📌 It serves as:

- the first onboarding example for stealth usage
- the canonical replacement for mixed internal-import examples

📌 Implementation checklist:

- [x] Keep the example file focused on one sender, one receiver, and one output only.
- [x] Use only canonical public imports and the stable sender-output facade.
- [x] Build the receiver card explicitly in the example so the developer can see the minimum required artifact.
- [x] Show exactly one send step, one scan step, and one ownership result step.
- [x] Print or log the minimum high-signal fields needed to understand success.
- [x] Avoid request-binding, persistence, batching, or simulator logic in this example.
- [x] Add comments that explain why the example uses the public path and not internal helper modules.
- [x] Ensure the example is runnable or compile-checked under the repository’s chosen example policy.
- [x] Keep secrets, randomness, and fixture setup deterministic where practical for documentation stability.
- [x] Mark the example done only when it is the canonical shortest path a developer should copy first.

### 2. Invoice Or Payment-Request Example

📌 Purpose: show when and why request-bound stealth output exists.

📌 It should show:

- Bob creates request metadata
- Alice binds output generation to Bob’s request
- Bob verifies the output with request context
- the example explicitly highlights why plain-path opening is not enough

📌 It serves as:

- the canonical request-flow example
- developer guidance for invoice-like integrations

📌 Implementation checklist:

- [x] Start from a receiver-generated request artifact and make that the first visible concept in the example.
- [x] Show the sender binding output generation to the request instead of treating request data as optional decoration.
- [x] Include the receiver-side success path with the correct request context.
- [x] Include one explicit non-success branch showing why plain-path opening is insufficient.
- [x] Use canonical public imports only.
- [x] Keep the example narrative focused on invoice or payment-request semantics, not generic stealth send semantics.
- [x] Print or log the request identifier and the validation outcome so the semantic binding is visible.
- [x] Avoid introducing internal helper paths that would confuse the request-bound public story.
- [x] Ensure the example does not imply that request-bound flow replaces the base flow universally.
- [x] Mark the example done only when a reader can see exactly when to use request-bound flow and how failure looks without it.

### Phase 6

### 3. Multi-Receiver Batch Scan Example

📌 Purpose: show realistic scanning across a mixed stream of outputs.

📌 It should show:

- multiple outputs addressed to different parties
- each wallet scans the same batch
- each wallet extracts only its own outputs

📌 It serves as:

- a realistic indexer or wallet-sync example
- proof that scan classification remains stable in shared datasets

📌 Implementation checklist:

- [x] Define at least three receiver actors and a mixed output set addressed across them.
- [x] Build the batch with interleaved ownership rather than grouping outputs by receiver.
- [x] Show one scan loop per receiver over the exact same shared dataset.
- [x] Collect and display only the outputs classified as owned for each receiver.
- [x] Demonstrate that foreign outputs are ignored rather than causing noisy failures.
- [x] Keep the example on canonical scan surfaces and stable sender-output generation surfaces.
- [x] Print concise per-receiver summaries so the reader can verify exclusivity by inspection.
- [x] Avoid persistence and replay complexity here unless the example would otherwise be too artificial.
- [x] Ensure the example is clearly distinct from the minimal single-output walkthrough.
- [x] Mark the example done only when it reads like a realistic wallet-sync or indexer pattern, not a synthetic unit-test transcript.

### 4. Tamper-Demo Example

📌 Purpose: show why stealth integrity checks are not optional.

📌 It should show:

- one valid output
- one intentionally tampered output
- validation and scan results for both
- clear explanation of which gate rejects the tampered output

📌 It serves as:

- security education
- regression reference for integrity behavior

📌 Implementation checklist:

- [x] Start from one valid baseline output and show it passing first.
- [x] Introduce one or more isolated tamper mutations after the valid baseline is established.
- [x] For each tamper mutation, explain which integrity gate is expected to fail.
- [x] Show the validation result and, if appropriate, the scan/decrypt result for both valid and tampered artifacts.
- [x] Keep the example focused on educational clarity rather than broad taxonomy coverage.
- [x] Use canonical public validation or scan surfaces instead of internal shortcut helpers.
- [x] Avoid mutating multiple semantic layers at once in the same example branch.
- [x] Make the output logs human-readable so a reviewer can see why the failure happened.
- [x] Ensure the example cannot be misread as proving ownership from tag equality alone.
- [x] Mark the example done only when a reader can understand the security value of the integrity gates from one run.

### Phase 7

### 5. Simulator Interop Example

📌 Purpose: show that outputs produced in simulator scenarios are consumable by wallet canonical paths.

📌 It should show:

- simulator creates stealth artifacts
- wallet-side scan/validate path consumes them unchanged
- output metadata and integrity checks remain consistent

📌 It serves as:

- proof of cross-subsystem consistency
- a bridge between protocol demos and application runtime behavior

📌 Implementation checklist:

- [x] Produce artifacts through the simulator path first and make that visible in the example structure.
- [x] Consume those artifacts through wallet canonical scan or validation logic second.
- [x] Show that no artifact translation or semantic rewriting is needed between simulator output and wallet input.
- [x] Print or summarize the fields that prove consistency across the subsystem boundary.
- [x] Include one note explaining why this example exists separately from the pure simulator scenario.
- [x] Use canonical wallet-side public paths for the consumer half of the example.
- [x] Avoid mixing simulator-local verification with wallet-local verification as if they were interchangeable.
- [x] Keep the example narrow enough that the subsystem bridge is the main idea.
- [x] Ensure the example would fail meaningfully if simulator semantics drift from wallet semantics.
- [x] Mark the example done only when it demonstrates real interoperability rather than mere shared types.

### 6. Wallet Reload Example

📌 Purpose: show a user-facing lifecycle where stealth outputs remain usable after save-and-reload.

📌 It should show:

- Bob receives a stealth output
- wallet or snapshot state is persisted
- a fresh runtime reloads the state
- the same output is still recognized and opened correctly

📌 It serves as:

- proof that stealth is not only an in-memory demo
- developer guidance for persistence-aware wallet integrations

📌 Implementation checklist:

- [x] Start from a successful receive flow before any persistence step is introduced.
- [x] Persist wallet or snapshot state using the normal supported persistence path.
- [x] Recreate a fresh runtime process or equivalent fresh context.
- [x] Reload the persisted state without re-deriving hidden ownership from out-of-band fixtures.
- [x] Re-open or re-scan the same stealth output after reload.
- [x] Print or summarize the before/after ownership parity and recovered payload stability.
- [x] Keep the example focused on lifecycle continuity, not on low-level storage internals.
- [x] Use canonical public receive or scan surfaces after reload, the same way a real integration would.
- [x] Explain what would be broken for users if this example stopped working.
- [x] Mark the example done only when a developer can use it as a reference for persistence-aware wallet flows.

## Fixture And Artifact Discipline

📌 E2E stealth scenarios become noisy very quickly if they improvise test data differently in every file.

📌 Each serious E2E test should define or reuse explicit fixtures for:

- actor keys or receiver cards
- deterministic tx/output seeds when reproducibility matters
- expected owned and foreign outputs
- persisted artifacts when reload/resume is under test
- tamper variants when integrity taxonomy is under test

📌 Recommended artifact checks:

- `asset_id`
- `serial_id`
- `r_pub`
- `owner_tag`
- `tag16`
- recovered value
- recovered `s_out`
- commitment and range-proof validation outcome

## Anti-Patterns To Reject

📌 The following E2E patterns should be rejected because they create false confidence.

- an E2E test that imports internal `core::stealth::*` as the main path and still claims to validate the public story
- a test that only checks `tag16` and calls it ownership verification
- a test that proves decrypt success but never checks foreign-output rejection
- a request-flow test that never proves plain-path failure or request mismatch failure
- a simulator test that validates only simulator-local helpers without wallet-side revalidation
- a persistence test that reloads state but never proves ownership parity before and after reload
- a tamper test that only checks `is_err()` and does not verify the rejection class

## Traceability To The Stealth Spec

📌 Every E2E file should state which stealth-spec acceptance points it covers.

| Proposed E2E scenario | Stealth-spec coverage |
| --- | --- |
| Sender To Receiver Canonical Flow | public path, canonical ownership flow, full-leaf authority |
| Request-Bound Payment Flow | exactly two `k_dh` modes, exactly two `tag16` modes, request-bound semantics |
| Tag16 Fast-Reject Versus Full Scan Authority | `leaf_scan` authority, `stealth_scanner` adapter-only rule |
| Wallet Runtime And Leaf Scan Parity | consistency between runtime path and canonical scan path |
| Output Self-Validation And Tamper Taxonomy | integrity gate ordering, cryptographic correctness, failure taxonomy |
| Foreign Output Isolation Test | ownership exclusivity, mixed-batch scan correctness |
| Public Path Enforcement Test | Phase 6 public-path contract, no parallel public import routes |
| Simulator And Wallet Flow Consistency Test | cross-subsystem parity with canonical stealth formulas |
| Persisted Wallet Reload And Re-Scan Flow | runtime lifecycle integrity across persistence boundaries |
| Replay And Duplicate Delivery Flow | deterministic ownership under repeated observation and resume |

## Recommended Execution Order

📌 The following order gives the highest signal early.

1. Sender To Receiver Canonical Flow
2. Foreign Output Isolation Test
3. Request-Bound Payment Flow
4. Tag16 Fast-Reject Versus Full Scan Authority
5. Output Self-Validation And Tamper Taxonomy
6. Wallet Runtime And Leaf Scan Parity
7. Simulator And Wallet Flow Consistency Test
8. Persisted Wallet Reload And Re-Scan Flow
9. Replay And Duplicate Delivery Flow
10. Public Path Enforcement Test

## Acceptance Mapping

📌 A practical E2E stealth suite should be considered strong enough when it proves all of the following.

- canonical public paths are the only demonstrated public routes
- base and request-bound stealth flows both work where intended
- card-bound and request-bound `tag16` flows both work where intended
- receiver ownership detection is correct for owned and foreign outputs
- integrity failures are rejected by the correct gate
- simulator and wallet runtime behavior remain aligned
- persistence and replay boundaries preserve ownership semantics
- examples teach the supported public path rather than internal helper layers

## Bottom Line

📌 The strongest E2E stealth suite for this repository is not a large pile of cryptographic micro-tests.

📌 The strongest suite is a compact but high-signal set of realistic end-to-end flows that prove:

- one canonical public path
- one correct sender-to-receiver ownership flow
- one correct request-bound flow
- one correct card-bound and request-bound tag story
- one correct ownership authority
- one correct tamper-rejection story
- one consistent simulator-to-wallet integration story
- one persistence-and-replay story that does not collapse under realistic runtime use
