# Z00Z Simulator — Full Specification

**Version:** 1.6  
**Date:** 2026-02-26  
**Status:** ✅ Ready for Implementation  
**Scope:** `crates/z00z_simulator/`

---

## 📌 Purpose

The simulator is a **self-contained executable test environment** that runs complete
lifecycle scenarios of the Z00Z protocol — from genesis state creation through wallet
initialization, stealth transactions, and proof verification — without requiring a live network.

**Goals:**
- Validate the full stack: assets → genesis → wallets → stealth → transactions
- Produce inspectable artifacts at every step (JSON, logs, proof bytes)
- Serve as living integration tests and developer onboarding tool
- Run deterministically in CI (mock RNG seed)

---

## 🔢 Serial Model (Banknote → Fragments)

📌 **Invariant:** `serial_id` is a **base serial** that is assigned at asset creation time and **never changes**.

📌 **Fragmentation:** an asset can be split into many fragments (many `AssetLeaf` outputs). **All fragments keep the same `serial_id`**.

📌 **Mixing:** a payment may be implemented as a **bundle of fragments** taken from **multiple** `serial_id` values; fragments are fungible **within the same asset type**, but **`serial_id` remains per-fragment**.

⚠️ **Protocol note (current code):** the existing builder path used in this spec constructs stealth outputs (`AssetLeaf`) but does not yet model a full multi-input transaction graph. The simulator can still validate the banknote/fragments semantics by generating multiple outputs that share the same `serial_id`, and later extending to multi-input/multi-output balance proofs.

---

## 🏗️ Architecture

### 📂 File Structure Convention

**Rule:** shared infrastructure lives in `src/*.rs`; every scenario is self-contained in `src/scenario_N/`.

```
crates/z00z_simulator/
├── Cargo.toml
└── src/
    │
    │   # ── SHARED (all scenarios) ─────────────────────────────────────
    ├── lib.rs              # re-exports: SimContext, SimActor, StageResult, Scenario
    ├── context.rs          # SimContext — shared mutable state across stages
    ├── runner.rs           # ScenarioRunner: load config → iterate stages → collect results
    ├── result.rs           # StageResult { Ok | Warn(String) | Fail(String) }, ScenarioResult
    ├── config.rs           # ScenarioConfig — deserializer for config_scenario.yaml
    ├── design.rs           # DesignStep — deserializer for design_scenario.yaml
    ├── actors.rs           # SimActor — thin sim wrapper (see below)
    │
    │   # ── SCENARIO-SPECIFIC ─────────────────────────────────────────
    ├── scenario_1/
    │   ├── Readme.md               # human description + architecture agreements
    │   ├── config_scenario.yaml    # runtime parameters (amounts, actors, flags)
    │   ├── design_scenario.yaml    # step-by-step breakdown with post-conditions
    │   ├── run_scenario.rs         # entry: load config → run stages in order
    │   ├── stage_1.rs              # genesis_init
    │   ├── stage_2.rs              # wallet_create
    │   ├── stage_3.rs              # confidential_transfer_simple
    │   ├── stage_4.rs              # confidential_transfer_bundle
    │   └── outputs/                # generated at runtime (gitignored)
    │       ├── logs/
    │       ├── wallets/
    │       ├── transactions/
    │       ├── proofs/
    │       ├── stage_N_snapshot.json
    │       └── report.md
    │
    ├── scenario_2/                 # future: next lifecycle scenario
    │   └── ...
    └── main.rs                     # sim_runner binary: --scenario N / --all / --resume-from N
```

> 📌 **Everything in `src/*.rs` is scenario-agnostic.** It knows nothing about amounts, actors,
> or Z00Z protocol specifics. It only knows how to load YAML, dispatch stages, collect results,
> and write artifacts.
>
> 📌 **Everything in `src/scenario_N/*.rs` is concrete.** Each stage function receives
> `&mut SimContext` and returns `StageResult`. All scenario logic, assertions, and
> specific API calls live here.

### Core Types

#### `SimContext` — shared state across all stages

```rust
// src/context.rs  (shared)
pub struct SimContext {
    pub config: ScenarioConfig,              // loaded from config_scenario.yaml
    pub chain_type: ChainType,               // Devnet | Testnet | Mainnet
    pub registry: AssetDefinitionRegistry,   // from genesis
    pub assets: Vec<Asset>,                  // minted assets
    pub actors: Vec<SimActor>,               // Alice, Bob, Carol …
    pub leaves: Vec<AssetLeaf>,              // produced output leaves
    pub block_height: u64,
    pub outputs_dir: PathBuf,
}
```

#### `SimActor` — thin simulator wrapper (NOT a replacement for Wallet)

> ❓ **Why not use `WalletRecord` / `WalletService` from `z00z_wallets` directly?**
>
> `z00z_wallets` contains the full production wallet stack:
> `WalletRecord`, `WalletKernel`, `WalletService<…16 generics…>`, `ReceiverKeys`, `ReceiverCard`.
> The simulator **does** use these types directly — it calls the same APIs as the examples
> (`ReceiverKeys::from_receiver_secret`, `StealthOutputScanner::from_keys`, etc.).
>
> `SimActor` is **not** a wallet replacement. It is a **thin sim-specific envelope** that adds
> exactly two things that do not exist in any real wallet type:
> - `name: String` — for log / report labels ("Alice", "Bob")
> - `balance: HashMap<[u8; 32], u64>` — simulator-visible plaintext ledger for
>   supply conservation assertions. A real wallet does NOT store a plaintext balance;
>   it derives balance by scanning the UTXO set.

```rust
// src/actors.rs  (shared)
pub struct SimActor {
    // display
    pub name: String,

    // wallet identity  ── from z00z_wallets::core::wallet
    pub record: WalletRecord,

    // cryptographic keys  ── from z00z_wallets::core::key
    pub keys: ReceiverKeys,

    // shareable card  ── from z00z_wallets::core::stealth
    pub card: ReceiverCard,

    // ── SIM ONLY: never exists in production wallet ──
    /// Simulator-tracked plaintext balance.  Key = genesis asset_id (from registry).
    /// Updated after each successful scan. Used for supply conservation assertions.
    pub balance: HashMap<[u8; 32], u64>,

    // secret stored only for CI determinism; zeroized on drop
    pub(crate) receiver_secret: Hidden<[u8; 32]>,
}
```

> ⚠️ **Security:** `receiver_secret` MUST be `Hidden<[u8; 32]>` per project rules. Never log or serialize it.
>
> 📌 **Actor construction** (stage_2 or shared helper):
> ```rust
> let secret_bytes = provider.fill_32(); // MockRngProvider or SystemRngProvider
> let recv_secret  = ReceiverSecret::from_bytes(secret_bytes)?;
> let keys         = ReceiverKeys::from_receiver_secret(recv_secret)?;
> let card         = keys.export_receiver_card()?;
> let record       = build_wallet_record(&keys, &chain_id, &name)?;
> SimActor { name, record, keys, card, balance: HashMap::new(),
>            receiver_secret: Hidden::hide(secret_bytes) }
> ```

#### `StageResult` — explicit flow control

```rust
pub enum StageResult {
    Ok,
    Warn(String),    // non-critical — run continues, warning logged
    Fail(String),    // critical — run_scenario aborts unless abort_on_fail=false
}
```

#### `Scenario` trait — uniform runner interface

```rust
pub trait Scenario {
    fn name(&self) -> &str;
    fn config(&self) -> &ScenarioConfig;
    fn run(&self, ctx: &mut SimContext) -> ScenarioResult;
}
```

---

## 🔄 Component Order — Lifecycle

The simulator follows a fixed component order. Each level depends on the previous.

```
Level 0: Cryptographic Foundation         (z00z_crypto)
Level 1: Asset Definitions + Genesis      (z00z_core::genesis, z00z_core::assets)
Level 2: Wallet Creation (keys + storage) (z00z_wallets::core::key, storage)
Level 3: Receiver Keys + Stealth Cards    (z00z_wallets::core::stealth)
Level 4: Transactions (sender → leaf)     (z00z_wallets::core::tx)
Level 5: Receiver Scan + Verification     (z00z_wallets::core::stealth)
Level 6: Proof Validation                 (z00z_crypto::range_proofs)
```

---

## 📋 Scenario 1 — Genesis to Confidential Transfer

### Overview

| Stage | Name | Level | Key Components |
|-------|------|-------|----------------|
| stage_1 | `genesis_init` | 0 + 1 | `run_genesis()`, `AssetDefinitionRegistry`, `ChainType::Devnet` |
| stage_2 | `wallet_create` | 2 + 3 | `ReceiverKeys`, `ReceiverCard`, wallet storage (redb files) |
| stage_3 | `confidential_tx` | 4 + 5 + 6 | `sender_create_output_for()`, receiver scan + `ZkPack::decrypt`, range proof verify |

---

### Stage 1 — Genesis Init

**Purpose:** Initialize the network, generate asset definitions with commitments.

> ⚠️ **Note:** `run_genesis()` does NOT create a blockchain Block. It produces an `AssetDefinitionRegistry` with committed initial asset amounts. No block header, no block hash. "Genesis" here means initial state bootstrap.

**Code reference:** `crates/z00z_core/bin/genesis/assets_generator_cli.rs` → `run_genesis()`

**Input:**
- `config_scenario.yaml`: `network.genesis_config = "genesis_config_devnet.yaml"`, `network.chain = "devnet"`

**Steps:**

```
1. Load genesis config from YAML
   → z00z_core::genesis::genesis_config::load_genesis_config()
   → GenesisConfig { chain_type: Devnet, assets: [...], seed: H256 }

2. Validate genesis seed
   → genesis::validator::validate_genesis_seed()

3. Detect chain type
   → detect_chain_type(&config) → ChainType::Devnet

4. Generate asset definitions (parallel via rayon)
   → For each AssetConfigEntry → derive asset_id via DomainHasher<GenesisAssetIdDomainDevnet>
   → Create AssetDefinition { name, symbol, asset_id, supply, policy_flags, ... }
   → Populate AssetDefinitionRegistry (GLOBAL_ASSET_REGISTRY)

5. Allocate initial asset amounts
   → For each genesis asset → create Asset { definition, amount, blinding, commitment }
   → BlindingFactor drawn from MockRngProvider::with_u64_seed(seed) (mock rng for CI)
   → Commitment: C = amount·G + blinding·H  (Pedersen, via z00z_crypto::create_commitment)

   ⚠️ IMPORTANT: These genesis assets are unowned at this point — they belong to "the protocol".
   Alice's initial balance in SimContext (from config.actors[0].initial_balance) is a SIMULATION
   SHORTCUT: the simulator directly credits Alice's SimActor.balance without building a full
   spending proof. A real implementation would require a genesis coinbase transaction.
   The 'asset_index' field in config selects which genesis asset (by registry index) Alice uses.

6. Compute genesis state hash
   → compute_genesis_state_hash(&assets) → H256

7. Export genesis snapshot to outputs/
   → genesis_snapshot.json (asset definitions + commitments)
   → genesis_state_hash.txt
```

**Crypto used:**
- `z00z_crypto::hash::DomainHasher` — domain-separated hashing for asset_id
- `z00z_crypto::create_commitment` — `C = v·G + r·H` (Pedersen)
- `z00z_utils::rng::MockRngProvider::with_u64_seed()` — reproducible blinding in CI

**Output artifacts:**
```
outputs/
├── logs/stage_1_genesis.log
├── genesis_snapshot.json          # all AssetDefinitions
├── genesis_commitments.json       # (asset_id, c_amount) pairs
├── genesis_state_hash.txt
└── stage_1_snapshot.json          # full SimContext after stage 1
```

**Post-conditions (assertions):**
- Registry contains N assets (from config)
- All commitments are valid (verify_commitment passes)
- genesis_state_hash is deterministic with same seed
- `ctx.registry.len() == config.expected_asset_count`

---

### Stage 2 — Wallet Create

**Purpose:** Create wallets for Alice and Bob per BIP standards; write to disk (redb).

**Code reference:** `crates/z00z_wallets/src/core/`

**Input:**
- `ctx.config.actors: [{name: "Alice", ...}, {name: "Bob", ...}]`
- `use_mock_rng: true` → deterministic secrets for CI

**Steps:**

```
1. For each actor in config.actors:

   a. Generate receiver_secret
      IF use_mock_rng → MockRngProvider::with_u64_seed(actor_index as u64)  // z00z_utils::rng
      ELSE           → SystemRngProvider (OsRng)
      → receiver_secret: [u8; 32]  → immediately wrap as Hidden::hide(receiver_secret)

   b. Derive all receiver keys
      → recv_secret = ReceiverSecret::from_bytes(*receiver_secret.reveal())?
      → ReceiverKeys::from_receiver_secret(recv_secret)?
      ⚠️ NOTE: `ReceiverSecret::from_bytes()` validates non-zero bytes and returns `Result`.
      If deterministic mock bytes end up all-zero, regenerate bytes (or adjust seed) and retry.
         ├── owner_handle = derive_owner_handle(&recv_secret)
         │     → hash_zk::<WalletReceiverIdHashProdDomain>(recv_secret)
         ├── view_sk      = derive_view_secret_key(&recv_secret)
         │     → h2s_zk::<WalletViewKeyHashProdDomain>(recv_secret) → Z00ZScalar
         ├── view_pk      = Z00ZRistrettoPoint::from_secret_key(&view_sk)
         ├── ident_sk     = derive_identity_secret_key(&recv_secret, index=0)
         │     → h2s_zk::<WalletIdentityKeyHashProdDomain>(recv_secret || index_le)
         └── ident_pk     = Z00ZRistrettoPoint::from_secret_key(&ident_sk)

   c. Build ReceiverCard (publicly shareable)
      → ReceiverCard { owner_handle, view_pk }

   d. Create WalletRecord metadata
      → WalletRecord { wallet_id, name, chain_id: Devnet, state: Unlocked, ... }
      → wallet_id derived from DomainHasher<WalletIdDomain>(owner_handle)

   e. Persist wallet to disk
      → WalletStorage::save(record)  (redb file at outputs/wallets/<wallet_id>.redb)
      → SecretStore::save(receiver_secret) (encrypted at rest)

   f. Build SimActor and push to ctx.actors

2. Log all wallet addresses (owner_handle hex, view_pk hex)
```

**Crypto used:**
- `z00z_wallets::core::key::derive_owner_handle` — `hash_zk::<WalletReceiverIdHashProdDomain>`
- `z00z_wallets::core::key::derive_view_secret_key` — `h2s_zk::<WalletViewKeyHashProdDomain>` → `Z00ZScalar`
- `z00z_crypto::Hidden<Z00ZScalar>` — protect secrets in memory
- `z00z_crypto::to_hex` — hex encoding for logging

**Output artifacts:**
```
outputs/
├── logs/stage_2_wallets.log
├── wallets/
│   ├── alice.json          # WalletRecord metadata (NO secrets)
│   ├── alice_keys.json     # PUBLIC keys only (view_pk, ident_pk, owner_handle)
│   ├── bob.json
│   └── bob_keys.json
└── stage_2_snapshot.json   # SimContext after stage 2
```

**Post-conditions (assertions):**
- `ctx.actors.len() == config.actors.len()`
- Alice and Bob have distinct `owner_handle` values
- `view_pk = Z00ZRistrettoPoint::from_secret_key(view_sk)` (round-trip check)
- Wallet files exist on disk
- `WalletStorage::exists(alice_wallet_id) == true`

---

### Stage 3 — Confidential Transfer

**Purpose:** Alice sends tokens to Bob using stealth output. Verify receiver can scan and decrypt.

**Code reference:**
- Builder: `crates/z00z_wallets/src/core/tx/builder.rs:build_output_with_blind()`
- Sender helper (NOT for CI): `crates/z00z_wallets/src/core/tx/mod.rs:sender_create_output_for()` — uses `SystemRngProvider`, not for deterministic CI
- Receiver scan: `crates/z00z_wallets/src/core/stealth/`

**Input:**
- `ctx.actors[0]` = Alice (sender), `ctx.actors[1]` = Bob (receiver)
- `ctx.config.transfer_simple.amount: u64`
- `ctx.config.transfer_simple.serial_id: u32`  — **base serial** (immutable), must be in `[0, 50_000)` for v1 packs

**Steps:**

```
Sender side (Alice → Bob):

1. Alice gets Bob's ReceiverCard { owner_handle, view_pk }

2. Generate ephemeral scalar r
   → r = Z00ZScalar::random(&mut rng)  (or deterministic in CI)
   ⚠️ CI DETERMINISM: For deterministic CI runs, generate `r` from
   `MockRngProvider::with_u64_seed(seed)` and call `build_output_with_blind(...)` directly.
   Do NOT use `sender_create_output_for()` — it always uses `SystemRngProvider` internally.

3. Sender-side ECDH
   → result: SenderDhResult = sender_derive_dh_with_r(&bob.card.view_pk, &r)
      └── result.dh:    Z00ZRistrettoPoint = r * view_pk  (ECDH shared point)
          result.r_pub: Z00ZRistrettoPoint = r * G         (ephemeral public key)
      Validates: view_pk ≠ identity, r ≠ 0  (both checked in facade_ecdh.rs)

4. Derive shared DH key
   → k_dh: [u8; 32] = facade_kdf::derive_k_dh(&result.dh)
      └── internally: ecdh::derive_k_dh(&dh: &Z00ZRistrettoPoint)
          → hash_zk::<KdhDomain>(dh.to_bytes())  (domain: z00z_crypto::domains::KdhDomain)
   → r_pub: [u8; 32] = result.r_pub.to_bytes()

5. Derive s_out
   → hash_zk::<SOutProdDomain>("Z00Z/S_OUT", &[k_dh, r_pub, &serial_id.to_le_bytes()])
      → s_out: [u8; 32]

6. Generate blinding factor
   → blinding: Hidden<Z00ZScalar> = Hidden::hide(Z00ZScalar::random(&mut rng))
   ⚠️ CI DETERMINISM: If you want full determinism, blinding MUST also come from the mock RNG.

7. Build commitment
   → C_amount = create_commitment(amount, blinding.reveal())
      └── C = amount·G + blinding·H  (Pedersen)
   → c_amount: [u8; 32] = commitment.as_bytes()

8. Compute owner_tag
   → compute_owner_tag(&bob.card.owner_handle, &k_dh)
      └── DomainHasher<OwnerTagDomain>(owner_handle || k_dh)

9. Compute per-output asset_id
   → asset_id: [u8; 32] = hash_zk::<AssetIdDomain>("", &[&s_out])
   ⚠️ NOTE: This asset_id is a PER-OUTPUT identifier derived from s_out.
   It is NOT the genesis asset_id from Stage 1's AssetDefinitionRegistry.
   Genesis asset_id identifies the asset TYPE (Z00Z native, ZZT token, etc.).
   Output asset_id identifies a specific unspent Asset leaf (one AssetLeaf = one Asset).
   The link to the genesis asset type is tracked in the simulator via config.transfer.asset_index,
   but is NOT encoded inside AssetLeaf in Phase 1.

10. Compute leaf_ad (authenticated data)
    → compute_leaf_ad(&r_pub, &asset_id, serial_id, &owner_tag, &c_amount)
       └── Domain-hashed concatenation — binds all leaf fields

11. Encrypt AssetPackPlain (72 bytes)
    → payload: [u8; 72] = AssetPackPlain { value: amount, blinding: blinding_bytes, s_out }.to_bytes()
       Format: value[0..8 LE] | blinding[8..40] | s_out[40..72]  (consensus-critical)
    → enc_pack: ZkPackEncrypted = ZkPack::encrypt(&k_dh, &leaf_ad, &r_pub, &asset_id, serial_id, &payload)
       AEAD algorithm: ChaCha20Poly1305 (12-byte nonce, NOT XChaCha20)
       key  = derive_pack_key(k_dh, asset_id, serial_id)       // hash_zk::<PackKeyProdDomain>
       nonce = derive_nonce(leaf_ad, r_pub, asset_id, serial_id) // hash_zk::<PackNonceProdDomain> → first 12 bytes
       aad  = make_aad(leaf_ad, r_pub, asset_id, serial_id)
       Wire profile: 89 bytes total (version:1 | ciphertext:72 | tag:16)

12. Generate range proof
    → create_range_proof(amount, blinding.reveal(), RANGE_PROOF_BITS_V1=64, MIN_VALUE_PROMISE=0)
       └── Bulletproofs+ over Ristretto255 → range_proof: Vec<u8>

13. Compute tag16 (scan prefilter)
    → compute_tag16(&k_dh, &leaf_ad) → u16

14. Assemble AssetLeaf
    → AssetLeaf { asset_id, serial_id, r_pub, owner_tag, c_amount,
                  enc_pack, range_proof, tag16 }

─────────────────────────────────────────────

Receiver side (Bob scans):

15. Bob receives AssetLeaf

16. Bob reconstructs k_dh via receiver ECDH
    → dh: Z00ZRistrettoPoint = receiver_derive_dh(&bob.keys.view_sk, &r_pub_point)
       Signature: receiver_derive_dh(view_sk: &Z00ZScalar, r_pub: &Z00ZRistrettoPoint)
       ⚠️ view_sk is the FIRST argument (differs from sender ECDH!)
       └── dh = view_sk * r_pub  (same shared point as sender's r * view_pk)
    → k_dh: [u8; 32] = facade_kdf::derive_k_dh(&dh)
       where r_pub_point = match Z00ZRistrettoPoint::try_from_bytes(leaf.r_pub) {
            Ok(p) => p,
            Err(_) => skip leaf,
       }
       (If `r_pub_point.is_identity()` → skip leaf)

17. Reconstruct leaf_ad from leaf fields
    → leaf_ad: [u8; 32] = compute_leaf_ad(&leaf.r_pub, &leaf.asset_id, leaf.serial_id,
                                           &leaf.owner_tag, &leaf.c_amount)
    ⚠️ This step is REQUIRED before tag16 check or decrypt — leaf_ad binds all public leaf fields.

18. Prefilter tag16 (fast reject)
    → expected_tag16: u16 = compute_tag16(&k_dh, &leaf_ad)
    → if expected_tag16 != leaf.tag16 → skip leaf (not mine)
    Note: prefilter requires k_dh, so it comes AFTER step 16 not before.

19. Decrypt enc_pack
   → dec_bytes: Vec<u8> = match ZkPack::decrypt(&k_dh, &leaf_ad, &leaf.r_pub,
                              &leaf.asset_id, leaf.serial_id, &leaf.enc_pack) {
         Some(bytes) => bytes,
         None => skip leaf,
      }
      (None = AEAD authentication failure or unsupported ZkPack version)
   → if !AssetPackPlain::is_valid_length(&dec_bytes) → malformed payload → skip leaf
       (AssetPackPlain::SIZE = 72; any other length is a protocol violation)
   → pack: AssetPackPlain = AssetPackPlain::from_bytes(&dec_bytes).unwrap()
    → Recover: pack.value (u64), pack.blinding ([u8; 32]), pack.s_out ([u8; 32])

20. Verify ownership
    → compute_owner_tag(&bob.keys.owner_handle, &k_dh) == leaf.owner_tag  ✓
    If mismatch → not our output (tag16 false positive) → skip
    ⚠️ NOTE: The production fast-scan (`receiver_scan_leaf`) does NOT explicitly check ownership —
    it verifies only commitment opening and returns the pack. Full ownership check is done by
    `stealth_scanner.rs`. The simulator does explicit ownership verification above for completeness.

21. Verify commitment
    → blinding_scalar: Z00ZScalar = Z00ZScalar::try_from_bytes(pack.blinding)?  // returns Result
       (NOT `from_bytes` — actual API is `try_from_bytes` which returns `Result<_, _>`)
    → c_check: Z00ZCommitment = create_commitment(pack.value, &blinding_scalar)?
    → c_check.as_bytes() == leaf.c_amount  ✓
    Alternative (used in `leaf_scan.rs`): `verify_commitment_opening(&commitment, pack.value, &blinding_scalar)`
    where `commitment = Z00ZCommitment::from_canonical_bytes(&leaf.c_amount)`

22. Verify range proof
    → verify_range_proof(&leaf.range_proof, &c_check, RANGE_PROOF_BITS_V1, 1, MIN_VALUE_PROMISE)
    → Must return Ok(())  ✓

23. Update Bob's balance in SimContext
    → bob.balance[genesis_asset_id] += pack.value
    Note: Key is the GENESIS asset_id (from config.transfer.asset_index, looked up in registry),
    NOT the per-output asset_id from leaf.asset_id.

24. (Optional for Scenario 1) Fragmentation bundle
   📌 To model “one banknote → many fragments”, repeat steps 2–14 multiple times while keeping `serial_id` constant.
   📌 To model “mix fragments from many serial_id”, produce a **set of leaves** where each leaf has its own immutable `serial_id`.
   The receiver wallet aggregates the decrypted values across leaves.
```

**Crypto used:**
- `z00z_crypto::create_commitment` — Pedersen `C = v·G + r·H`
- `z00z_crypto::create_range_proof` — Bulletproofs+ 64-bit
- `z00z_crypto::verify_range_proof` — proof verification
- `z00z_wallets::stealth::facade_ecdh` — sender/receiver ECDH
- `z00z_wallets::stealth::facade_kdf` — `k_dh`, `owner_tag`, `leaf_ad`, `tag16`
- `z00z_wallets::stealth::facade_zkpack::ZkPack` — ChaCha20Poly1305 (12-byte nonce) encrypt/decrypt
- `z00z_crypto::Hidden<Z00ZScalar>` — protect blinding factor

**Output artifacts:**
```
outputs/
├── logs/stage_3_transfer.log
├── transactions/
│   └── leaf_alice_to_bob_s1.json  # full AssetLeaf (serialized)
├── proofs/
│   ├── commitment_alice_mint.json  # c_amount hex + amount (for audit)
│   └── range_proof_s1.bin         # raw Bulletproofs+ bytes
├── wallets/
│   ├── alice_after_tx.json        # balance snapshot
│   └── bob_after_tx.json          # balance snapshot (should have +amount)
└── stage_3_snapshot.json          # full SimContext
```

**Post-conditions (assertions):**
- `AssetLeaf::asset_id` is deterministic ONLY if Stage 3 uses deterministic inputs (mock-rng-derived `r` + deterministic blinding)
- `ZkPack::decrypt()` returns `Some(bytes)` (not None)
- `AssetPackPlain::from_bytes(&bytes).value == config.transfer.amount`
- `verify_range_proof()` returns `Ok(())`
- `bob.balance[genesis_asset_id] == config.transfer.amount`
- `leaf.owner_tag == compute_owner_tag(&bob.keys.owner_handle, &k_dh)`
- `leaf.tag16 == compute_tag16(&k_dh, &leaf_ad)`

---

## ⚙️ config_scenario.yaml / design_scenario.yaml

> 📌 The spec describes **general simulator behavior**. Each scenario defines its own
> YAML files. The spec does not duplicate their content.

**Canonical files for Scenario 1:**
- `crates/z00z_simulator/src/scenario_1/config_scenario.yaml`
- `crates/z00z_simulator/src/scenario_1/design_scenario.yaml`

### config_scenario.yaml — top-level keys

`ScenarioConfig` must deserialize the following sections:
- `scenario` — id, name, description
- `network` — chain, genesis_config
- `simulation` — use_mock_rng, mock_rng_seed, abort_on_fail
- `actors[]` — name, role, mock_rng_seed, initial_balance[]
- `genesis_assets[]` — dev_cfg_key, serials, nominal, asset_index
- `transfer_simple` — single transfer: from, to, amount, serial_id, asset_index, tx_hash_seed
- `transfer_bundle` — bundle fragments: from, to, serial_id, fragments[]{amount, tx_hash_seed}
- `outputs` — dir, timestamped, save_snapshots, save_proofs, verbose_logs

### design_scenario.yaml — top-level keys

`DesignStage` / `DesignStep` must deserialize the following:
- `stages[]` — stage id, name, description, rust_entry
- `stages[].steps[]` — id, action, call (Rust pseudocode), note, post_conditions[]

Post-conditions are **string assertions** that the stage runner evaluates after each step.
Unrecognized post-condition strings produce `StageResult::Warn` (not `Fail`) to allow forward compatibility.

---

## ⚠️ Known Blockers (from spec 009)

Before scenario 3 can pass end-to-end, these issues from `specs/009-z00z-ecc-spec-4/4_Asset_Model.md` must be resolved:

| # | Severity | Issue | File | Status |
|---|----------|-------|------|--------|
| 1 | 🚨 BLOCKER | `s_out = [0xABu8; 32]` placeholder | `tx/mod.rs:73` | ✅ **FIXED** — `derive_s_out()` in place |
| 2 | 🚨 BLOCKER | Legacy `build_tx_stealth_output` incompatible with receiver (40-byte payload vs 72-byte `AssetPackPlain`) | `stealth/output.rs:142` | ✅ **RESOLVED** — confirmed working: examples (`stealth_workflow.rs`, `quick_start_stealth.rs`) call `build_tx_stealth_output` and receiver scans successfully with `StealthOutputScanner::scan_leaf`. Current impl produces correct 72-byte `AssetPackPlain`. |
| 3 | ⚠️ GAP | `compute_leaf_ad` parameter order mismatch — `tag.rs` vs `facade_kdf.rs` different argument orders | both | ✅ **FIXED** — warning comment added in `facade_kdf.rs:62` |
| 4 | ⚠️ GAP | `AssetPackPlain::SIZE` constant missing (hardcoded `72` literal) | `assets/leaf.rs` | ✅ **FIXED** — `pub const SIZE: usize = 8 + 32 + 32` already present in `leaf.rs:92` |

---

## 🔐 Cryptographic Summary

| Operation | Curve / Algorithm | z00z_crypto function |
|-----------|-------------------|----------------------|
| Pedersen commitment | Ristretto255, `C = v·G + r·H` | `create_commitment(value, blinding)` |
| Range proof | Bulletproofs+ 64-bit | `create_range_proof(v, r, 64, 0)` |
| Range proof verify | Bulletproofs+ | `verify_range_proof(proof, commitment, 64, 1, 0)` |
| ECDH sender | Ristretto255, `dh = r * view_pk` | `facade_ecdh::sender_derive_dh_with_r(view_pk, r)` → `SenderDhResult` |
| ECDH receiver | Ristretto255, `dh = view_sk * r_pub` | `facade_ecdh::receiver_derive_dh(view_sk, r_pub)` ⚠️ view_sk is FIRST |
| DH key derivation | DomainHasher `KdhDomain` | `facade_kdf::derive_k_dh(dh: &Z00ZRistrettoPoint) → [u8;32]` |
| Asset pack encrypt | ChaCha20Poly1305 (12-byte nonce) | `ZkPack::encrypt(k_dh, leaf_ad, r_pub, asset_id, serial, plaintext)` |
| Asset pack decrypt | ChaCha20Poly1305 | `ZkPack::decrypt(...) → Option<Vec<u8>>` (None = auth failure) |
| s_out derivation | Poseidon2 / hash_zk | `hash_zk::<SOutProdDomain>(...)` |
| Asset ID derivation | hash_zk | `hash_zk::<AssetIdDomain>("", &[s_out])` |
| Owner tag | DomainHasher | `compute_owner_tag(owner_handle, k_dh)` |
| Leaf AD | DomainHasher | `compute_leaf_ad(r_pub, asset_id, serial_id, owner_tag, c_amount)` |
| Tag16 prefilter | DomainHasher → u16 | `compute_tag16(k_dh, leaf_ad)` |

---

## 🧾 Supply & Conservation Checks (Simulator Scope)

📌 **Per-serial supply check (simulator-visible):** because the simulator can decrypt `AssetPackPlain`, it can sum plaintext `value` across all fragments that share the same `serial_id` and assert expected conservation rules for the scenario.

⚠️ **Important:** the *sum of Pedersen commitment points* across fragments is **not** generally invariant under splitting/merging if fresh blindings are chosen.
- Each commitment is $C_i = v_i\cdot G + r_i\cdot H$.
- The point sum is $\sum C_i = (\sum v_i)\cdot G + (\sum r_i)\cdot H$.
- Even if $\sum v_i$ is conserved, $\sum r_i$ changes unless the protocol enforces a balance proof that accounts for blindings (or uses deterministic blinding derivation).

📌 **What the simulator can still verify:**
- For each decrypted fragment, commitment opening matches (`value`, `blinding`) for that leaf.
- Range proof verifies for that commitment.
- Scenario-defined conservation holds at the plaintext level (e.g., receiver total increases by expected amount), and later can be extended to full confidential balance proofs when multi-input/multi-output tx is implemented.

---

## ✅ Implementation Readiness Checklist

### Shared infrastructure (`src/*.rs`) — implement first

| File | Status | Notes |
|------|--------|-------|
| `src/result.rs` | 🔲 | `StageResult`, `ScenarioResult` — trivial enums |
| `src/config.rs` | 🔲 | Deserialize `config_scenario.yaml` → `ScenarioConfig` |
| `src/design.rs` | 🔲 | Deserialize `design_scenario.yaml` → `Vec<DesignStage>` |
| `src/actors.rs` | 🔲 | `SimActor` struct (see definition above) |
| `src/context.rs` | 🔲 | `SimContext` struct |
| `src/runner.rs` | 🔲 | `fn run_scenario(n, ctx) -> ScenarioResult` |
| `src/lib.rs` | 🔲 | Re-exports |
| `src/main.rs` | 🔲 | CLI: `--scenario N`, `--all`, `--resume-from N`, `--check-outputs` |

### Scenario 1 (`src/scenario_1/*.rs`) — implement after shared

| File | Status | Depends on |
|------|--------|------------|
| `run_scenario.rs` | 🔲 | `SimContext`, `ScenarioConfig` |
| `stage_1.rs` | 🔲 | `run_genesis()`, `AssetDefinitionRegistry`, `create_commitment` |
| `stage_2.rs` | 🔲 | `ReceiverKeys`, `ReceiverCard`, `WalletRecord` from `z00z_wallets` |
| `stage_3.rs` | 🔲 | `build_tx_stealth_output`, `StealthOutputScanner`, `verify_range_proof` |
| `stage_4.rs` | 🔲 | Same as stage_3 + bundle + supply conservation assertions |

### All blockers resolved — spec is ready for implementation

| # | Issue | Status |
|---|-------|--------|
| B1 | `s_out` placeholder | ✅ |
| B2 | `build_tx_stealth_output` format mismatch | ✅ |
| B3 | `compute_leaf_ad` argument order | ✅ |
| B4 | `AssetPackPlain::SIZE` constant | ✅ |

---

## 📦 Crate Dependencies

```toml
[dependencies]
z00z_core    = { path = "../z00z_core" }    # AssetDefinitionRegistry, genesis, AssetLeaf
z00z_wallets = { path = "../z00z_wallets" } # ReceiverKeys, ReceiverCard, tx, stealth
z00z_crypto  = { path = "../z00z_crypto" }  # commitments, range proofs, ECDH, ZkPack
z00z_utils   = { path = "../z00z_utils" }   # io, codec, time, rng, logger
serde        = { version = "1", features = ["derive"] }
serde_json   = "1"
serde_yaml   = "0.9"
```

---

## 🧪 CI Usage

```bash
# Run scenario 1 (deterministic, mock rng)
cargo run --release --bin sim_runner -- --scenario 1

# Run all scenarios
cargo run --release --bin sim_runner -- --all

# Resume from stage 2 (skip stage 1 using saved snapshot)
cargo run --release --bin sim_runner -- --scenario 1 --resume-from 2

# Check artifacts only (no run)
cargo run --bin sim_runner -- --scenario 1 --check-outputs
```

---

## 📚 Related Documents

| Document | Location | Relevance |
|----------|----------|-----------|
| Cryptographic Foundation | `specs/007-z00z-ecc-spec-2/2_Cryptographic_Foundation.md` | Ristretto255, Pedersen, Bulletproofs+ |
| Stealth Address Protocol | `specs/008-z00z-ecc-spec-3/3_Stealth_Address_Protocol.md` | ECDH, ReceiverSecret, scan protocol |
| Asset Model | `specs/009-z00z-ecc-spec-4/4_Asset_Model.md` | AssetLeaf, ZkPack, s_out, leaf_ad |
| ECC Spec Part 1 (base) | `crates/Z00Z-ECC-SPEC_part1.md` | Overall system structure |
| Simulator Readme | `crates/z00z_simulator/src/scenario_1/Readme.md` | Architecture agreements |

---

## 

