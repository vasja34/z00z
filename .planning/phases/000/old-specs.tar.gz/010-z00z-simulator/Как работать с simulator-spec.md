Читаю текущее состояние симулятора и spec:  

Ran terminal command:  find /home/vadim/Projects/z00z/crates/z00z_simulator/src -name "*.rs" | grep -v target | sort && echo "---" && cat /home/vadim/Projects/z00z/crates/z00z_simulator/Cargo.toml

Ran terminal command:  cat /home/vadim/Projects/z00z/crates/z00z_simulator/src/lib.rs && echo "===" && cat /home/vadim/Projects/z00z/crates/z00z_simulator/src/scenario_1/run_scenario.rs

Все `.rs` файлы сценария пустые. Теперь понятна картина — нужно объяснить рабочий процесс. Отвечаю на все вопросы.

---

## Как работать с simulator-spec.md

### Что такое spec и для чего он

Spec — это **контракт** между тремя уровнями:

```
simulator-spec.md          ← КОНТРАКТ (что должно быть)
      │
      ├── src/*.rs          ← SHARED инфраструктура (реализует контракт)
      │
      └── scenario_1/
          ├── design_scenario.yaml   ← ЧТО делает сценарий (шаги + assertions)
          ├── config_scenario.yaml   ← С КАКИМИ параметрами
          └── stage_N.rs             ← КАК реализован каждый шаг
```

Ты **не реализуешь сам spec** — ты реализуешь структуры из него, потом пишешь сценарии по паттерну.

---

### Шаг 1 — Реализуй shared инфраструктуру (`src/*.rs`) один раз

Это делается один раз для всех сценариев. Порядок:

**1. `src/result.rs`** — два enum, буквально 15 строк:
```rust
pub enum StageResult { Ok, Warn(String), Fail(String) }
pub struct ScenarioResult { pub passed: bool, pub stages: Vec<StageOutcome> }
```

**2. config.rs** — deserializer для `config_scenario.yaml`. Берёшь структуру из spec-секции "config_scenario.yaml — top-level keys" и пишешь `#[derive(Deserialize)]` над полями 1:1.

**3. `src/actors.rs`** — `SimActor` как в spec. Поля: `name`, `record: WalletRecord`, `keys: ReceiverKeys`, `card: ReceiverCard`, `balance: HashMap<[u8;32], u64>`, `receiver_secret: Hidden<[u8;32]>`.

**4. `src/context.rs`** — `SimContext` как в spec. Поля: config, `chain_type`, `registry`, `actors`, `leaves`, `outputs_dir`.

**5. `src/runner.rs`** — функция `fn run_scenario(stages: Vec<Box<dyn FnMut(&mut SimContext) -> StageResult>>, ctx: &mut SimContext)`.

---

### Шаг 2 — Связь spec ↔ `design_scenario.yaml` ↔ `stage_N.rs`

**Это главное.** Каждый шаг в `design_scenario.yaml` — это один assert в коде:

```
design_scenario.yaml:               stage_3.rs:
─────────────────────               ───────────
- id: "S3-3"               →        let result = scanner.scan_leaf(&leaf);
  action: "Bob scans"               assert!(matches!(result,
  post_conditions:                    ScanResult::Mine { wallet_output }
    - "ScanResult::Mine"               if wallet_output.amount == 250),
    - "amount == 250"                  "S3-3 failed: scan or amount mismatch");
```

`design_scenario.yaml` — это **спецификация в виде данных**. `stage_N.rs` — это **выполняемая реализация**. Они должны соответствовать точка-в-точку. Когда тест падает — смотришь `id:` в YAML, находишь соответствующий assert в `.rs`.

На данном этапе `design_scenario.yaml` используется двумя способами:

1. **Как документация** — разработчик открывает YAML, читает шаги, пишет `stage_N.rs`
2. **Как проверяемый манифест** (будущее) — `runner.rs` парсит `design_scenario.yaml` через `src/design.rs`, сопоставляет `id` шагов с результатами, выводит отчёт "S3-3: ✅ / S3-4: ❌"

---

### Шаг 3 — Разработка конкретного сценария

**Алгоритм для Scenario 1:**

```
1. Открываешь   config_scenario.yaml  — смотришь актёров, суммы, asset_index
2. Открываешь   design_scenario.yaml  — читаешь шаги stage_1..stage_4
3. Для каждого  stage_N.yaml-раздела  — пишешь  src/scenario_1/stage_N.rs

   stage_N.rs получает &mut SimContext и возвращает StageResult.
   Каждый "step" из design_scenario.yaml = один блок кода + assert.

4. Пишешь       run_scenario.rs       — вызывает stage_1..stage_4 по порядку,
                                        останавливается при Fail если abort_on_fail=true
5. cargo run --bin sim_runner -- --scenario 1
```

**Шаблон `stage_N.rs`:**
```rust
// scenario_1/stage_3.rs
pub fn run(ctx: &mut SimContext) -> StageResult {
    let alice = &ctx.actors[0];
    let bob   = &ctx.actors[1];

    // S3-1: build stealth output (spec Stage 3, step 1)
    let out = match build_tx_stealth_output(&bob.card, None, &sender,
                   &tx_hash, serial_id, amount, &asset_id) {
        Ok(o) => o,
        Err(e) => return StageResult::Fail(format!("S3-1: {e}")),
    };

    // S3-3: Bob scans (spec Stage 3, step 3)
    let scanner = StealthOutputScanner::from_keys(&bob.keys);
    match scanner.scan_leaf(&leaf) {
        ScanResult::Mine { wallet_output } if wallet_output.amount == amount => { /* ok */ }
        other => return StageResult::Fail(format!("S3-3: expected Mine(250), got {other:?}")),
    }

    StageResult::Ok
}
```

---

### Шаг 4 — Новый сценарий (Scenario 2, 3, ...)

Алгоритм добавления нового сценария:

```
1. Создать   src/scenario_2/
2. Скопировать шаблон из  src/template/
3. Написать  config_scenario.yaml  — новые параметры (другие суммы, другие актёры)
4. Написать  design_scenario.yaml  — только шаги специфичные для этого сценария
5. Написать  stage_N.rs            — реализация
6. Shared-инфраструктура (SimContext, SimActor, StageResult)  НЕ трогается
```

Shared код переиспользуется, весь специфичный код изолирован в `scenario_N/`.

---

### Итоговая схема зависимостей

```
simulator-spec.md
     │ описывает типы + lifecycle
     ▼
src/context.rs ─── src/actors.rs ─── src/result.rs
     │                                     │
     └──────── src/runner.rs ──────────────┘
                     │
        ┌────────────┴────────────┐
        │                         │
scenario_1/run_scenario.rs   scenario_2/run_scenario.rs
  stage_1.rs  ← design_scenario.yaml (id: S1-1..S1-5)
  stage_2.rs  ← design_scenario.yaml (id: S2-1..S2-4)
  stage_3.rs  ← design_scenario.yaml (id: S3-1..S3-5)
  stage_4.rs  ← design_scenario.yaml (id: S4-1..S4-8)
```

**Практический следующий шаг** — начать с `src/result.rs` + config.rs + `src/context.rs`: это три маленьких файла (~50 строк суммарно), которые разблокируют всё остальное. Начать?