# Z00Z Crypto Backend Trait Specification

**Version:** 1.0  
**Status:** REVIEW  
**Date:** 2025-12-06  
**Scope:** Universal crypto backend for entire Z00Z blockchain  
**Initial Application:** `crates/z00z_core/src/assets/` (Phase 1)  
**Future Scope:** All crates and modules  
**Related Specs:** `tari_ideas1.md`, `assets_spec_release.md`

---

## 1. Executive Summary

### 1.1 Purpose

This specification defines a **universal cryptographic backend abstraction** for the entire Z00Z blockchain, decoupling all modules from direct vendor dependencies. The goal is to:

1. **Isolate vendor dependencies** (Tari) behind trait abstractions across the entire codebase
2. **Enable cryptographic backend substitution** (post-quantum, alternative curves) for all modules
3. **Provide unified crypto API** for assets, transactions, consensus, networking, and all future modules
4. **Maintain backward compatibility** with existing implementations

**CRITICAL:** This is an **API REFACTORING ONLY**. The specification describes a **WRAPPER LAYER** over existing `crates/z00z_core/src/assets/crypto.rs` and `crates/z00z_crypto/` implementations.

**NO CHANGES TO:**
- Cryptographic algorithms (still Bulletproofs+, Pedersen commitments, Ristretto curve)
- Cryptographic libraries (still `tari_crypto`, `tari_bulletproofs_plus`)
- Wire formats or serialization
- Consensus rules
- Proof generation/verification logic

**ONLY CHANGES:**
- API interface (trait-based instead of stateless struct)
- Call sites (functions from `z00z_crypto::` instead of `AssetCrypto::method()`)

**Phase 1 Scope:** Initial implementation in `assets` module as proof-of-concept  
**Future Phases:** Roll out to all other modules (transactions, consensus, networking, storage, etc.)

### 1.2 Scope

**In Scope (Universal Design):**
- **Universal trait definitions** in `z00z_crypto` crate for all blockchain operations
- Generic naming (not tied to assets: `CryptoBackend`, not `AssetCryptoBackend`)
- Tari backend implementation (`TariCryptoBackend`)
- Integration with existing `z00z_crypto` structure:
  - `protocol_types.rs` - type definitions
  - `hash_config.rs` - domain separation
  - New: `backend.rs` - trait definitions
  - New: `backend_tari.rs` - Tari implementation

**Phase 1: Assets Module**
- Apply crypto backend to `crates/z00z_core/src/assets/`
- Unit tests: `crates/z00z_core/tests/assets/`
- Examples: `crates/z00z_core/examples/assets/`
- Benchmarks: `crates/z00z_core/benches/assets/`

**Future Phases: All Modules**
- Transactions module
- Consensus module  
- Networking module
- Storage module
- All other crates

**Out of Scope:**
- Changes to wire format or serialization
- Modifications to consensus rules
- Alternative backend implementations (future work)

### 1.3 Success Criteria

- [ ] Zero breaking changes to public Asset API
- [ ] All existing tests pass without modification
- [ ] <5% performance regression for proof generation/verification
- [ ] Clear migration path documented
- [ ] 100% test coverage for new trait layer

---

## 2. Current State Analysis

### 2.1 Existing Architecture

Current `crates/z00z_core/src/assets/crypto.rs` (538 lines):

```rust
// Direct Tari dependencies
use tari_crypto::commitment::HomomorphicCommitmentFactory;
use tari_crypto::range_proof::RangeProofService;
use tari_crypto::ristretto::bulletproofs_plus::BulletproofsPlusService;
use tari_crypto::ristretto::pedersen::extended_commitment_factory::ExtendedPedersenCommitmentFactory;

// Stateless service with cached Bulletproof+ service
pub struct AssetCrypto;

impl AssetCrypto {
    pub fn create_commitment(amount: u64, blinding: &BlindingFactor) -> Commitment { ... }
    pub fn create_range_proof(amount: u64, blinding: &BlindingFactor) -> Result<RangeProof, CryptoError> { ... }
    pub fn verify_range_proof(proof: &RangeProof, commitment: &Commitment, aggregation: usize) -> Result<(), CryptoError> { ... }
}
```

**Problems:**
1. **Tight coupling:** 20+ direct Tari imports across assets module
2. **Untestable:** Cannot mock crypto for fast unit tests
3. **Inflexible:** Cannot swap Tari for alternative backends
4. **Vendor lock-in:** Asset logic tightly bound to Tari API

### 2.2 Dependency Graph

```text
┌─────────────────────────────────────────┐
│  assets/mod.rs, definition.rs,          │
│  registry.rs, assets.rs, wire.rs        │
│  (HIGH-LEVEL BUSINESS LOGIC)            │
└──────────────┬──────────────────────────┘
               │
               │ Direct imports from Tari
               ▼
┌─────────────────────────────────────────┐
│  tari_crypto::*                         │
│  tari_bulletproofs_plus::*              │
│  tari_ristretto::*                      │
│  (VENDOR CRYPTOGRAPHY)                  │
└─────────────────────────────────────────┘
```

**Goal:** Insert abstraction layer between business logic and vendor crypto.

### 2.3 Reality Check: Existing Codebase Alignment

**CRITICAL:** This specification describes a **WRAPPER LAYER** over existing cryptography.

**What EXISTS in codebase (NO CHANGES):**
```rust
// crates/z00z_crypto/src/protocol_types.rs (EXISTING, UNCHANGED)
pub type Amount = u64;
pub type BlindingFactor = RistrettoSecretKey;
pub type Commitment = PedersenCommitment;
pub type RangeProof = Vec<u8>;
pub type PublicKey = RistrettoPublicKey;
pub type KernelSignature = RistrettoSchnorr;
pub type Nonce = [u8; 32];

pub const RANGE_PROOF_BITS_V1: usize = 64;
pub const AGGREGATION_FACTOR: usize = 1;
pub const MAX_PROOF_SIZE_V1: usize = 10_240;

// crates/z00z_crypto/src/hash_config.rs (EXISTING, UNCHANGED)
pub type Blake2bHasher = Blake2b<U64>;
pub type DomainHasher<D> = DomainSeparatedHasher<Blake2bHasher, D>;

// crates/z00z_core/src/assets/crypto.rs (EXISTING, WILL BE WRAPPED)
pub struct AssetCrypto;  // Stateless service

impl AssetCrypto {
    pub fn create_commitment(amount: u64, blinding: &BlindingFactor) -> Commitment;
    pub fn create_range_proof(amount: u64, blinding: &BlindingFactor) -> Result<RangeProof, AssetError>;
    pub fn verify_range_proof(proof: &RangeProof, commitment: &Commitment, aggregation: usize) -> Result<(), AssetError>;
}

pub fn derive_asset_hash(
    chain_id: [u8; 32],
    version: u32,
    class: AssetClass,
    asset_id: &str,
    domain: &[u8],
) -> [u8; 32];
```

**What this spec ADDS (NEW WRAPPER LAYER):**
```rust
// crates/z00z_crypto/src/lib.rs (PUBLIC API - NO mention of Tari!)
pub use protocol_types::{Amount, BlindingFactor, Commitment, RangeProof, ...};

/// Create Pedersen commitment (backend choice hidden)
pub fn create_commitment(amount: u64, blinding: &BlindingFactor) -> Commitment {
    default_backend().create_commitment(amount, blinding)
}

/// Generate range proof (backend choice hidden)
pub fn create_range_proof(amount: u64, blinding: &BlindingFactor, bits: usize) -> Result<RangeProof, CryptoError> {
    default_backend().create_range_proof(amount, blinding, bits)
}

/// Verify range proof (backend choice hidden)
pub fn verify_range_proof(proof: &RangeProof, commitment: &Commitment, bits: usize, aggregation_factor: usize) -> Result<(), CryptoError> {
    default_backend().verify_range_proof(proof, commitment, bits, aggregation_factor)
}

/// Generic hash derivation (backend choice hidden)
pub fn derive_hash(domain: &[u8], data: &[&[u8]]) -> [u8; 32] {
    default_backend().derive_hash(domain, data)
}

// PRIVATE: Backend selection (NOT exported)
fn default_backend() -> &'static TariCryptoBackend {
    &TARI_BACKEND  // Tari is default, but external code doesn't know
}

static TARI_BACKEND: TariCryptoBackend = TariCryptoBackend;

// ============================================================================
// INTERNAL IMPLEMENTATION (not part of public API)
// ============================================================================

// crates/z00z_crypto/src/backend.rs (PRIVATE trait)
trait CryptoBackend: Send + Sync + 'static {  // NOT pub!
    fn create_commitment(&self, amount: u64, blinding: &BlindingFactor) -> Commitment;
    fn create_range_proof(&self, amount: u64, blinding: &BlindingFactor, bits: usize) -> Result<RangeProof, CryptoError>;
    fn verify_range_proof(&self, proof: &RangeProof, commitment: &Commitment, bits: usize, aggregation_factor: usize) -> Result<(), CryptoError>;
    fn derive_hash(&self, domain: &[u8], data: &[&[u8]]) -> [u8; 32];
}

// crates/z00z_crypto/src/backend_tari.rs (PRIVATE implementation)
struct TariCryptoBackend;  // NOT pub!

impl CryptoBackend for TariCryptoBackend {
    fn create_commitment(&self, amount: u64, blinding: &BlindingFactor) -> Commitment {
        // CALLS EXISTING: AssetCrypto::create_commitment(amount, blinding)
    }
    // ...
}
```

**Key Principles:**
1. **NO cryptographic logic changes** - wrapper delegates to existing `AssetCrypto`
2. **NO new dependencies** - uses existing `tari_crypto`, `tari_bulletproofs_plus`
3. **NO wire format changes** - same commitments, same proofs, same serialization
4. **API refactoring ONLY** - trait interface for better testability and flexibility
5. **Existing code path preserved** - `AssetCrypto` continues working during migration

**Mapping to existing functions:**

| New Trait Method | Existing Function | Notes |
|------------------|-------------------|-------|
| `create_commitment(...)` | `AssetCrypto::create_commitment(...)` | Direct delegation |
| `create_range_proof(...)` | `AssetCrypto::create_range_proof(...)` | Direct delegation |
| `verify_range_proof(...)` | `AssetCrypto::verify_range_proof(...)` | Direct delegation |
| `z00z_crypto::derive_hash(b"z00z/asset", ...)` | `derive_asset_hash(...)` | Wrapper with domain parameter |

**What changes in assets module:**
```rust
// BEFORE (current code):
use z00z_core::assets::crypto::AssetCrypto;

let commitment = AssetCrypto::create_commitment(amount, &blinding);
let proof = AssetCrypto::create_range_proof(amount, &blinding)?;

// AFTER (clean API, NO mention of Tari!):
use z00z_crypto::{create_commitment, create_range_proof};

let commitment = create_commitment(amount, &blinding);
let proof = create_range_proof(amount, &blinding, 64)?;

// Backend choice (Tari) is HIDDEN inside z00z_crypto crate!
// External code has NO IDEA which backend is used.
```

**Benefit:** Future flexibility for backend substitution, clean API separation, no cryptographic changes.

---

## 3. Proposed Architecture

### 3.1 Layered Design

```text
┌─────────────────────────────────────────────────────────────────────┐
│  ALL BLOCKCHAIN MODULES (Current + Future)                          │
│  ┌───────────────┐  ┌──────────────┐  ┌─────────────┐              │
│  │ ASSETS        │  │ TRANSACTIONS │  │ CONSENSUS   │ ...          │
│  │ (Phase 1)     │  │ (Phase 2)    │  │ (Phase 3)   │              │
│  └───────┬───────┘  └──────┬───────┘  └──────┬──────┘              │
│          │                 │                  │                      │
│          └─────────────────┴──────────────────┘                      │
└──────────────────────────────┬──────────────────────────────────────┘
                               │
                               │ Generic over trait T: CryptoBackend
                               ▼
┌─────────────────────────────────────────────────────────────────────┐
│  UNIVERSAL CRYPTO ABSTRACTION LAYER                                 │
│  crates/z00z_crypto/src/                                            │
│  ┌────────────────────────────────────────────────────────────┐     │
│  │ lib.rs (PUBLIC API - hides backend choice)                 │     │
│  │   // External modules use ONLY these functions:            │     │
│  │   pub fn create_commitment(...) -> Commitment;             │     │
│  │   pub fn create_range_proof(...) -> RangeProof;            │     │
│  │   pub fn verify_range_proof(...) -> Result<()>;           │     │
│  │   pub fn derive_hash(...) -> Hash;                         │     │
│  │                                                            │     │
│  │   // Backend selection HIDDEN inside this crate            │     │
│  │   fn default_backend() -> &'static impl CryptoBackend;     │     │
│  └────────────────────────────────────────────────────────────┘     │
│  ┌────────────────────────────────────────────────────────────┐     │
│  │ backend.rs (PRIVATE trait, not exported)                   │     │
│  │   trait CryptoBackend {  // Internal use only              │     │
│  │     fn create_commitment(...) -> Commitment;               │     │
│  │     fn create_range_proof(...) -> RangeProof;              │     │
│  │     fn verify_range_proof(...) -> Result<()>;             │     │
│  │     fn derive_hash(...) -> Hash;                           │     │
│  │   }                                                        │     │
│  └────────────────────────────────────────────────────────────┘     │
│  ┌────────────────────────────────────────────────────────────┐     │
│  │ protocol_types.rs (EXISTING)                               │     │
│  │   - Amount, BlindingFactor, Commitment, RangeProof         │     │
│  │   - RANGE_PROOF_BITS_V1, AGGREGATION_FACTOR               │     │
│  └────────────────────────────────────────────────────────────┘     │
│  ┌────────────────────────────────────────────────────────────┐     │
│  │ hash_config.rs (EXISTING)                                  │     │
│  │   - Blake2bHasher, DomainHasher                            │     │
│  └────────────────────────────────────────────────────────────┘     │
└──────────────────────────────┬──────────────────────────────────────┘
                               │
                               │ Implemented by concrete backends
                               ▼
┌─────────────────────────────────────────────────────────────────────┐
│  BACKEND IMPLEMENTATIONS                                            │
│  crates/z00z_crypto/src/                                            │
│  ┌────────────────────────────────────────────────────────────┐     │
│  │ backend_tari.rs (NEW)                                      │     │
│  │   struct TariCryptoBackend;                                │     │
│  │   impl CryptoBackend for TariCryptoBackend { ... }         │     │
│  └────────────────────────────────────────────────────────────┘     │
│                                                                     │
│  (Future: backend_post_quantum.rs, backend_hardware.rs)             │
└──────────────────────────────┬──────────────────────────────────────┘
                               │
                               │ Vendor-specific imports isolated here
                               ▼
┌─────────────────────────────────────────────────────────────────────┐
│  VENDOR CRYPTOGRAPHY (Tari)                                         │
│  tari_crypto::*, tari_bulletproofs_plus::*                          │
└─────────────────────────────────────────────────────────────────────┘
```

### 3.2 Key Design Principles

1. **Zero-cost abstraction:** Static dispatch via generics, no trait objects
2. **Backward compatibility:** Existing API unchanged, migration incremental
3. **Minimal surface area:** Only 4-6 trait methods covering core operations
4. **Performance parity:** <5% overhead vs direct Tari calls

---

## 4. Trait Definitions

### 4.1 Public API: `z00z_crypto` Functions

**File:** `crates/z00z_crypto/src/lib.rs` (UPDATED)

```rust
//! Universal cryptographic API for Z00Z blockchain.
//!
//! **PUBLIC API** - External modules use ONLY these functions.
//! Backend choice (Tari, post-quantum, etc.) is HIDDEN inside this crate.
//!
//! ## Usage (from any module)
//!
//! ```rust
//! use z00z_crypto::{create_commitment, create_range_proof, verify_range_proof};
//! 
//! // NO mention of Tari or any specific backend!
//! let commitment = create_commitment(amount, &blinding);
//! let proof = create_range_proof(amount, &blinding, 64)?;
//! verify_range_proof(&proof, &commitment, 64, 1)?;
//! ```

pub(crate) mod backend;  // Private module - NOT exported outside z00z_crypto
pub(crate) mod backend_tari;  // Private module - NOT exported outside z00z_crypto
mod protocol_types;  // Re-export types
mod hash_config;  // Re-export hash config

// Re-export protocol types (public)
pub use protocol_types::{
    Amount, BlindingFactor, Commitment, RangeProof,
    PublicKey, KernelSignature, Nonce,
    RANGE_PROOF_BITS_V1, AGGREGATION_FACTOR, MAX_PROOF_SIZE_V1,
};

pub use hash_config::{Blake2bHasher, DomainHasher};

// Error type
pub use crate::error::CryptoError;

/// Create Pedersen commitment hiding an amount.
///
/// Backend is chosen automatically (currently Tari, but external code doesn't know).
pub fn create_commitment(amount: u64, blinding: &BlindingFactor) -> Commitment {
    default_backend().create_commitment(amount, blinding)
}

/// Generate zero-knowledge range proof.
pub fn create_range_proof(
    amount: u64,
    blinding: &BlindingFactor,
    bits: usize,
) -> Result<RangeProof, CryptoError> {
    default_backend().create_range_proof(amount, blinding, bits)
}

/// Verify range proof against commitment.
pub fn verify_range_proof(
    proof: &RangeProof,
    commitment: &Commitment,
    bits: usize,
    aggregation_factor: usize,
) -> Result<(), CryptoError> {
    default_backend().verify_range_proof(proof, commitment, bits, aggregation_factor)
}

/// Derive deterministic hash with domain separation.
pub fn derive_hash(domain: &[u8], data: &[&[u8]]) -> [u8; 32] {
    default_backend().derive_hash(domain, data)
}

// ============================================================================
// PRIVATE: Backend Selection (NOT exported to external modules)
// ============================================================================

use backend::CryptoBackend;
use backend_tari::TariCryptoBackend;

static TARI_BACKEND: TariCryptoBackend = TariCryptoBackend;

/// Get default backend (Tari). This function is PRIVATE.
/// Returns trait implementation, not concrete type (for flexibility).
#[inline]
fn default_backend() -> &'static impl CryptoBackend {
    &TARI_BACKEND
}

/// Initialize crypto backend at startup (optional but recommended).
pub fn initialize() -> Result<(), CryptoError> {
    TariCryptoBackend::initialize()
}
```

### 4.2 Internal Trait: `CryptoBackend` (Private)

**File:** `crates/z00z_crypto/src/backend.rs` (NEW, PRIVATE)

```rust
//! PRIVATE module - trait abstraction for internal use only.
//!
//! External modules should NEVER import from this module.
//! Use public functions from `z00z_crypto::` instead.

use crate::protocol_types::{Amount, BlindingFactor, Commitment, RangeProof};
use crate::error::CryptoError;

/// Internal trait for cryptographic backend abstraction.
///
/// **PRIVATE:** This trait is NOT exported. External modules use
/// public functions from `z00z_crypto::` which delegate to this trait.
///
/// This allows backend swapping (Tari → post-quantum) without
/// changing any external code.
///
/// Implementations must be:
/// - **Thread-safe:** All methods are &self (shared reference)
/// - **Stateless:** No mutable state, can be used from multiple threads
/// - **Deterministic:** Same inputs always produce same outputs
///
/// # Security Requirements
///
/// Implementations MUST:
/// 1. Use cryptographically secure random number generation
/// 2. Validate all inputs (reject zero amounts, invalid commitments)
/// 3. Implement constant-time operations where applicable
/// 4. Reject proofs >10KB to prevent DoS attacks
/// 5. Use domain separation for all hash operations
///
/// # Performance Requirements
///
/// Reference benchmarks (Tari backend, 64-bit proofs):
/// - `create_commitment`: <1μs
/// - `create_range_proof`: <6ms
/// - `verify_range_proof`: <3ms (single), <1ms (batched)
/// - `derive_hash`: <2μs
///
/// New backends should match within 2x of these baselines.
///
/// # Usage Across Modules
///
/// - **Assets**: Commitment/proof for confidential amounts
/// - **Transactions**: Signature verification, kernel proofs
/// - **Consensus**: Block hash verification, leader election
/// - **Networking**: Peer identity, message authentication
/// - **Storage**: Data integrity, merkle proofs
pub(crate) trait CryptoBackend: Send + Sync + 'static {
    /// Create a Pedersen commitment hiding an amount.
    ///
    /// Computes: `C = v·H + b·G` where:
    /// - `v` = amount (value being hidden)
    /// - `b` = blinding factor (secret randomness)
    /// - `H` = Pedersen base for values
    /// - `G` = Pedersen base for blinding
    ///
    /// # Arguments
    /// * `amount` - Value to commit (0..2^64)
    /// * `blinding` - Secret blinding factor (32 bytes)
    ///
    /// # Returns
    /// Compressed 32-byte Pedersen commitment
    ///
    /// # Errors
    /// Returns `CryptoError::CryptoOperationFailed` if:
    /// - Blinding factor is invalid
    /// - Point compression fails
    ///
    /// # Security
    /// - Computationally hiding: Attacker cannot deduce `v` from `C`
    /// - Perfectly binding: Cannot find `v' ≠ v` with same commitment
    ///
    /// # Examples
    ///
    /// ```rust
    /// // External code uses public API (no backend mention)
    /// use z00z_crypto::{create_commitment, BlindingFactor};
    /// use rand::rngs::OsRng;
    /// 
    ///
    /// // Backend is hidden inside z00z_crypto crate
    /// let amount = 1000u64;
    /// let blinding = BlindingFactor::random(&mut OsRng);
    ///
    /// let commitment = create_commitment(amount, &blinding);
    /// assert_eq!(commitment.as_bytes().len(), 32);
    /// ```
    fn create_commitment(&self, amount: u64, blinding: &BlindingFactor) -> Commitment;

    /// Generate a zero-knowledge range proof for an amount.
    ///
    /// Proves that committed value satisfies: `0 ≤ v < 2^bits` without
    /// revealing the actual value. Uses Bulletproofs+ protocol.
    ///
    /// # Arguments
    /// * `amount` - Value to prove (must match commitment)
    /// * `blinding` - Blinding factor used in commitment
    /// * `bits` - Bit length for range (typically 64)
    ///
    /// # Returns
    /// Compressed range proof (~680 bytes for 64-bit single proof)
    ///
    /// # Errors
    /// Returns `CryptoError::ProofGenerationFailed` if:
    /// - Amount exceeds 2^bits
    /// - Blinding factor is invalid
    /// - Proof construction fails
    ///
    /// # Performance
    /// - Single 64-bit proof: ~5-6ms
    /// - Aggregated proof (N outputs): ~5ms + (N-1)×0.5ms
    ///
    /// # Security
    /// - Zero-knowledge: Proof reveals nothing about `v` except range
    /// - Soundness: Cannot prove false statement (except with negligible probability)
    /// - Malleability: Proofs are bound to commitments (non-malleable)
    ///
    /// # Examples
    ///
    /// ```rust
    /// # use z00z_crypto::{create_commitment, create_range_proof, verify_range_proof};
    /// # 
    /// # use z00z_crypto::protocol_types::BlindingFactor;
    /// # use rand::rngs::OsRng;
    /// # 
    /// # fn main() -> Result<(), Box<dyn std::error::Error>> {
    /// // Backend is hidden inside z00z_crypto crate
    /// let amount = 1000u64;
    /// let blinding = BlindingFactor::random(&mut OsRng);
    ///
    /// let proof = create_range_proof(amount, &blinding, 64)?;
    /// assert!(proof.as_bytes().len() < 1024); // ~680 bytes
    /// # Ok(())
    /// # }
    /// ```
    fn create_range_proof(
        &self,
        amount: u64,
        blinding: &BlindingFactor,
        bits: usize,
    ) -> Result<RangeProof, CryptoError>;

    /// Verify a zero-knowledge range proof against a commitment.
    ///
    /// Checks that proof demonstrates: `0 ≤ v < 2^bits` where `v` is
    /// the value hidden in the commitment.
    ///
    /// # Arguments
    /// * `proof` - Range proof to verify
    /// * `commitment` - Pedersen commitment to verify against
    /// * `bits` - Expected bit length (typically 64)
    /// * `aggregation_factor` - Number of proofs aggregated (1 for single)
    ///
    /// # Returns
    /// `Ok(())` if proof is valid, error otherwise
    ///
    /// # Errors
    /// Returns `CryptoError::ProofVerificationFailed` if:
    /// - Proof is malformed or too large (>10KB)
    /// - Commitment is invalid point
    /// - Proof does not verify
    /// - Aggregation factor mismatch
    ///
    /// # Performance
    /// - Single proof: ~2-3ms
    /// - Batched verification (N proofs): ~2ms + (N-1)×0.8ms
    ///
    /// # Security
    /// - Rejection of oversized proofs prevents DoS
    /// - Constant-time verification (where possible)
    /// - No partial information leakage on failure
    ///
    /// # Examples
    ///
    /// ```rust
    /// # use z00z_crypto::{create_commitment, create_range_proof, verify_range_proof};
    /// # 
    /// # use z00z_crypto::protocol_types::BlindingFactor;
    /// # use rand::rngs::OsRng;
    /// # 
    /// # fn main() -> Result<(), Box<dyn std::error::Error>> {
    /// // Backend is hidden inside z00z_crypto crate
    /// let amount = 1000u64;
    /// let blinding = BlindingFactor::random(&mut OsRng);
    ///
    /// let commitment = create_commitment(amount, &blinding);
    /// let proof = create_range_proof(amount, &blinding, 64)?;
    ///
    /// verify_range_proof(&proof, &commitment, 64, 1)?;
    /// # Ok(())
    /// # }
    /// ```
    fn verify_range_proof(
        &self,
        proof: &RangeProof,
        commitment: &Commitment,
        bits: usize,
        aggregation_factor: usize,
    ) -> Result<(), CryptoError>;

    /// Derive deterministic 32-byte hash with domain separation.
    ///
    /// Generic hashing function used across entire blockchain:
    /// - Assets: `derive_hash(b"z00z/asset", [chain_id, version, class, id])`
    /// - Transactions: `derive_hash(b"z00z/tx", [tx_data])`
    /// - Consensus: `derive_hash(b"z00z/block", [block_data])`
    /// - Networking: `derive_hash(b"z00z/peer", [peer_id])`
    ///
    /// Computes: `Hash(domain || data[0] || data[1] || ... || data[n])`
    /// using domain-separated hashing to prevent collision attacks.
    ///
    /// # Arguments
    /// * `domain` - Domain separator (e.g., b"z00z/asset", b"z00z/tx")
    /// * `data` - Variable-length data to hash (each element concatenated)
    ///
    /// # Returns
    /// 32-byte deterministic hash
    ///
    /// # Security
    /// - Domain separation prevents cross-protocol attacks
    /// - Length-prefixed encoding prevents collision attacks
    /// - Must use cryptographic hash (Blake2b-512 truncated to 256 bits)
    ///
    /// # Examples
    ///
    /// ```rust
    /// # use z00z_crypto::{create_commitment, create_range_proof, verify_range_proof};
    /// # 
    /// // Backend is hidden inside z00z_crypto crate
    /// 
    /// // Asset hash
    /// let asset_hash = z00z_crypto::derive_hash(
    ///     b"z00z/asset",
    ///     &[b"z00z", &[1u8], b"coin"]
    /// );
    /// 
    /// // Transaction hash  
    /// let tx_hash = z00z_crypto::derive_hash(
    ///     b"z00z/tx",
    ///     &[tx_bytes]
    /// );
    /// ```
    fn derive_hash(
        &self,
        domain: &[u8],
        data: &[&[u8]],
    ) -> [u8; 32];
}
```

### 4.2 Type Aliases and Definitions

**File:** `crates/z00z_crypto/src/backend.rs` (continued)

```rust
// Re-export protocol types
pub use crate::protocol_types::{
    Amount, BlindingFactor, Commitment, RangeProof,
    PublicKey, KernelSignature, Nonce,
    RANGE_PROOF_BITS_V1, AGGREGATION_FACTOR, MAX_PROOF_SIZE_V1,
};

// Generic hash type (used for asset hashes, tx hashes, block hashes, etc.)
/// 32-byte hash output from derive_hash()
pub type Hash = [u8; 32];

// Chain identifier type
/// 32-byte chain identifier for network separation
pub type ChainId = [u8; 32];
```

**Note:** Module-specific newtypes (e.g., `AssetHash`, `TxHash`) should be defined
in their respective modules if stronger type safety is needed:

```rust
// In crates/z00z_core/src/assets/mod.rs
pub struct AssetHash(pub [u8; 32]);

// In crates/z00z_core/src/transactions/mod.rs  
pub struct TxHash(pub [u8; 32]);
```

### 4.3 Type Requirements

**Trait Dependencies from `z00z_crypto::protocol_types`:**

The trait relies on types defined in `crates/z00z_crypto/src/protocol_types.rs`.
These types are ALREADY IMPLEMENTED and MUST satisfy:

```rust
/// Blinding factor: Scalar field element (32 bytes)
/// Used as secret randomness in Pedersen commitments
pub struct BlindingFactor {
    // Internal: Ristretto scalar
    // Required traits: SecretKey, Zeroize, From<[u8; 32]>
    // Security: Automatically zeroized on drop
}

impl BlindingFactor {
    pub fn random<R: RngCore + CryptoRng>(rng: &mut R) -> Self;
    pub fn as_bytes(&self) -> &[u8; 32];
    pub fn from_bytes(bytes: [u8; 32]) -> Result<Self, CryptoError>;
}

/// Commitment: Compressed Ristretto point (32 bytes)
/// Represents C = v·H + b·G in Pedersen commitment scheme
pub struct Commitment {
    // Internal: CompressedRistretto
    // Required traits: PublicKey, Serialize, Deserialize
}

impl Commitment {
    pub fn as_bytes(&self) -> &[u8; 32];
    pub fn from_bytes(bytes: &[u8; 32]) -> Result<Self, CryptoError>;
    pub fn from_hex(hex: &str) -> Result<Self, CryptoError>;
}

/// RangeProof: Bulletproofs+ proof data
/// Typical size: ~680 bytes for 64-bit range proof
pub struct RangeProof {
    // Internal: Bulletproofs+ proof structure
    // Required traits: Serialize, Deserialize
}

impl RangeProof {
    pub fn as_bytes(&self) -> &[u8];
    pub fn from_bytes(bytes: &[u8]) -> Result<Self, CryptoError>;
}

/// Amount: Value type for asset amounts
pub type Amount = u64;
```

**Note:** For complete type specifications, see `z00z_crypto` crate documentation.

---

## 5. Tari Backend Implementation

### 5.1 TariCryptoBackend Implementation (Private)

**File:** `crates/z00z_crypto/src/backend_tari.rs` (NEW, PRIVATE MODULE)

```rust
//! Tari cryptography backend for entire Z00Z blockchain.
//!
//! This module implements `CryptoBackend` using Tari's cryptographic
//! primitives for ALL blockchain operations (assets, transactions, consensus, etc.).
//!
//! **IMPORTANT:** This is a WRAPPER around existing `AssetCrypto` from
//! `crates/z00z_core/src/assets/crypto.rs`. NO cryptographic logic changes.
//!
//! Uses: Bulletproofs+, Pedersen commitments, Ristretto curve, Blake2b hashing.
//!
//! ## Performance
//!
//! Cached Bulletproof+ service provides optimal batch performance:
//! - First proof: ~5ms (includes generator initialization)
//! - Subsequent proofs: ~5ms each (generators cached)
//! - Batch verification: ~2ms + (N-1)×0.8ms for N proofs
//!
//! ## Security
//!
//! Uses Tari's audited implementations:
//! - Curve25519/Ristretto for ECC operations
//! - Bulletproofs+ for range proofs
//! - Blake2b for hashing operations

use once_cell::sync::Lazy;
use std::borrow::Cow;

// Tari imports - isolated to this file
use tari_crypto::commitment::HomomorphicCommitmentFactory;
use tari_crypto::hash_domain;
use tari_crypto::range_proof::RangeProofService;
use tari_crypto::ristretto::bulletproofs_plus::BulletproofsPlusService;
use tari_crypto::ristretto::pedersen::extended_commitment_factory::ExtendedPedersenCommitmentFactory;

// Z00Z imports
use super::crypto_traits::{CryptoBackend, AssetHash, ChainId};
use crate::assets::{AssetClass, CryptoError};
use z00z_crypto::{
    Amount, BlindingFactor, Commitment, DomainHasher, RangeProof,
    AGGREGATION_FACTOR, MAX_PROOF_SIZE_V1, RANGE_PROOF_BITS_V1,
};

// Hash domain for asset ID derivation
hash_domain!(DeriveAssetHashDomain, "z00z_core/assets/derive_asset_hash", 1);

/// Cached Bulletproof+ service for optimal performance.
///
/// Initializing generators takes ~5-10ms. By caching the service globally,
/// we achieve >100x speedup for batch operations.
static BULLETPROOF_SERVICE: Lazy<Result<BulletproofsPlusService, String>> = Lazy::new(|| {
    BulletproofsPlusService::init(
        RANGE_PROOF_BITS_V1,
        AGGREGATION_FACTOR,
        ExtendedPedersenCommitmentFactory::default(),
    )
    .map_err(|e| format!("Failed to initialize Bulletproof+ service: {:?}", e))
});

/// Cached Pedersen commitment factory.
static COMMITMENT_FACTORY: Lazy<ExtendedPedersenCommitmentFactory> =
    Lazy::new(ExtendedPedersenCommitmentFactory::default);

/// Tari cryptography backend (PRIVATE, not exported).
///
/// This struct implements internal `CryptoBackend` trait.
/// External modules should use `z00z_crypto::create_commitment()` etc.
/// instead of directly accessing this backend.
///
/// # Implementation Note
///
/// This is the default backend, but external code doesn't know about it.
/// Backend choice is hidden inside `z00z_crypto` crate.
#[derive(Debug, Clone, Copy)]
pub(crate) struct TariCryptoBackend;  // NOT pub!

impl TariCryptoBackend {
    /// Create a new Tari crypto backend.
    ///
    /// This is a zero-cost operation as all state is cached globally.
    pub const fn new() -> Self {
        Self
    }

    /// Initialize crypto backend explicitly at service startup.
    ///
    /// This validates that the Bulletproof+ service can be initialized
    /// successfully. Call this during application startup to catch
    /// initialization failures early (fail-fast principle).
    ///
    /// # Returns
    /// `Ok(())` if initialization succeeds, error otherwise.
    ///
    /// # Examples
    /// ```rust
    /// fn main() -> Result<(), CryptoError> {
    ///     // Initialize at startup
    ///     TariCryptoBackend::initialize()?;
    ///     
    ///     // Now safe to use
    ///     // Backend is hidden inside z00z_crypto crate
    ///     Ok(())
    /// }
    /// ```
    pub fn initialize() -> Result<(), CryptoError> {
        Self::get_bulletproof_service()?;
        Ok(())
    }

    /// Get reference to cached Bulletproof+ service.
    fn get_bulletproof_service() -> Result<&'static BulletproofsPlusService, CryptoError> {
        BULLETPROOF_SERVICE
            .as_ref()
            .map_err(|e| CryptoError::ProofVerificationFailed(Cow::Owned(e.clone())))
    }

    /// Get reference to cached commitment factory.
    fn get_commitment_factory() -> &'static ExtendedPedersenCommitmentFactory {
        &COMMITMENT_FACTORY
    }
}

impl Default for TariCryptoBackend {
    fn default() -> Self {
        Self::new()
    }
}

impl CryptoBackend for TariCryptoBackend {
    fn create_commitment(&self, amount: u64, blinding: &BlindingFactor) -> Commitment {
        let factory = Self::get_commitment_factory();
        // Commit: C = v·H + b·G
        factory.commit_value(blinding, amount)
    }

    fn create_range_proof(
        &self,
        amount: u64,
        blinding: &BlindingFactor,
        bits: usize,
    ) -> Result<RangeProof, CryptoError> {
        let service = Self::get_bulletproof_service()?;
        
        // Generate single range proof
        let proof = service
            .construct_proof(blinding, amount)
            .map_err(|e| {
                CryptoError::ProofGenerationFailed(Cow::Owned(format!(
                    "Bulletproof+ construction failed: {:?}",
                    e
                )))
            })?;

        Ok(proof)
    }

    fn verify_range_proof(
        &self,
        proof: &RangeProof,
        commitment: &Commitment,
        bits: usize,
        aggregation_factor: usize,
    ) -> Result<(), CryptoError> {
        // Validate aggregation factor (only single proofs supported in v1)
        if aggregation_factor != 1 {
            return Err(CryptoError::ProofVerificationFailed(Cow::Borrowed(
                "Only single proofs supported (aggregation_factor must be 1)",
            )));
        }

        // Reject oversized proofs (DoS protection)
        if proof.as_bytes().len() > MAX_PROOF_SIZE_V1 {
            return Err(CryptoError::ProofVerificationFailed(Cow::Borrowed(
                "Proof size exceeds maximum allowed size",
            )));
        }

        let service = Self::get_bulletproof_service()?;

        // Verify single proof
        service
            .verify(proof, vec![commitment])
            .map_err(|e| {
                CryptoError::ProofVerificationFailed(Cow::Owned(format!(
                    "Bulletproof+ verification failed: {:?}",
                    e
                )))
            })
    }

    fn derive_asset_hash(
        &self,
        chain_id: ChainId,
        version: u32,
        class: AssetClass,
        asset_id: &str,
        domain: &[u8],
    ) -> AssetHash {
        let hash = DomainHasher::<DeriveAssetHashDomain>::new_with_label("asset_id")
            .chain(domain)
            .chain(chain_id)
            .chain(version.to_be_bytes())
            .chain([class.class_byte()])
            .chain(asset_id.as_bytes())
            .finalize();

        let mut id = [0u8; 32];
        id.copy_from_slice(&hash.as_ref()[..32]);
        id
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use rand::rngs::OsRng;
    

    #[test]
    fn test_commitment_deterministic() {
        // Backend is hidden inside z00z_crypto crate
        let amount = 1000u64;
        let blinding = BlindingFactor::random(&mut OsRng);

        let c1 = create_commitment(amount, &blinding);
        let c2 = create_commitment(amount, &blinding);

        assert_eq!(c1.as_bytes(), c2.as_bytes(), "Commitments must be deterministic");
    }

    #[test]
    fn test_range_proof_roundtrip() {
        // Backend is hidden inside z00z_crypto crate
        let amount = 1000u64;
        let blinding = BlindingFactor::random(&mut OsRng);

        let commitment = create_commitment(amount, &blinding);
        let proof = create_range_proof(amount, &blinding, 64)
            .expect("Proof generation should succeed");

        verify_range_proof(&proof, &commitment, 64, 1)
            .expect("Proof verification should succeed");
    }

    #[test]
    fn test_range_proof_rejects_invalid() {
        // Backend is hidden inside z00z_crypto crate
        let amount = 1000u64;
        let blinding1 = BlindingFactor::random(&mut OsRng);
        let blinding2 = BlindingFactor::random(&mut OsRng);

        let commitment = create_commitment(amount, &blinding1);
        let proof = create_range_proof(amount, &blinding2, 64)
            .expect("Proof generation should succeed");

        // Proof generated with different blinding factor should fail verification
        assert!(verify_range_proof(&proof, &commitment, 64, 1).is_err());
    }

    #[test]
    fn test_asset_hash_deterministic() {
        // Backend is hidden inside z00z_crypto crate
        let chain_id = [0u8; 32];
        let version = 1u32;
        let class = AssetClass::Coin;
        let asset_id = b"z00z";

        let hash1 = z00z_crypto::derive_hash(
            b"z00z/asset",
            &[&chain_id, &version.to_be_bytes(), &[class.class_byte()], asset_id]
        );
        let hash2 = z00z_crypto::derive_hash(
            b"z00z/asset",
            &[&chain_id, &version.to_be_bytes(), &[class.class_byte()], asset_id]
        );

        assert_eq!(hash1, hash2, "Asset hashes must be deterministic");
    }

    #[test]
    fn test_asset_hash_differs_by_class() {
        // Backend is hidden inside z00z_crypto crate
        let chain_id = [0u8; 32];
        let version = 1u32;
        let asset_id = b"z00z";

        let hash_coin = z00z_crypto::derive_hash(
            b"z00z/asset",
            &[&chain_id, &version.to_be_bytes(), &[AssetClass::Coin.class_byte()], asset_id]
        );
        let hash_token = z00z_crypto::derive_hash(
            b"z00z/asset",
            &[&chain_id, &version.to_be_bytes(), &[AssetClass::Token.class_byte()], asset_id]
        );

        assert_ne!(hash_coin, hash_token, "Different asset classes must produce different hashes");
    }
}
```

---

## 6. Migration Strategy

### 6.1 Overview: Universal Crypto Rollout

**Philosophy:** Design universal crypto layer once, roll out incrementally per module.

**Phases:**
1. **Phase 1 (Foundation):** Create universal traits in `z00z_crypto` crate
2. **Phase 2 (Assets Module):** Apply crypto backend to assets module (FIRST USE CASE)
3. **Phase 3 (Deprecation):** Mark old asset-specific crypto as deprecated
4. **Phase 4 (Expansion):** Roll out to transactions, consensus, networking, etc.
5. **Phase 5 (Cleanup):** Remove legacy code after all modules migrated

### 6.2 Phase 1: Universal Foundation (Non-Breaking)

**Goal:** Create blockchain-wide crypto abstraction in `z00z_crypto` crate.

**Steps:**

1. Create `crates/z00z_crypto/src/backend.rs` with universal `CryptoBackend` trait
2. Create `crates/z00z_crypto/src/backend_tari.rs` with `TariCryptoBackend` implementation
3. Update `crates/z00z_crypto/src/lib.rs` to re-export new modules
4. Add comprehensive unit tests in `z00z_crypto` using real Tari crypto

**Key Principle:** Generic naming (not module-specific):
- ✅ `CryptoBackend` (universal)
- ✅ `TariCryptoBackend` (universal implementation)
- ✅ `derive_hash()` (generic method)
- ❌ `AssetCryptoBackend` (module-specific, WRONG)
- ❌ `derive_asset_hash()` (module-specific, WRONG)

**No breaking changes.** New code added to `z00z_crypto`, existing modules untouched.

### 6.3 Phase 2: Assets Module Integration (First Use Case)

**Goal:** Apply universal crypto backend to assets module as proof-of-concept.

**Affected files:**
- `crates/z00z_core/src/assets/assets.rs` - Asset struct construction
- `crates/z00z_core/src/assets/definition.rs` - AssetDefinition methods
- `crates/z00z_core/src/assets/registry.rs` - Registry operations
- `crates/z00z_core/src/assets/wire.rs` - Serialization/deserialization

**Strategy:**

### 6.2.1 Asset Structure Design Decision

**IMPORTANT:** The `Asset` struct does **NOT** store a backend reference. This avoids lifetime and ownership complexity. Instead:

1. Backend is passed at **creation time** to generate commitment and proof
2. Backend is passed again at **verification time** if needed
3. Asset stores only cryptographic outputs (commitment, proof, metadata)

```rust
/// Asset structure (does not store backend)
pub struct Asset {
    commitment: Commitment,
    range_proof: RangeProof,
    // Other fields...
    // NO backend field
}

impl Asset {
    /// Create asset using z00z_crypto public API (backend hidden)
    pub fn new(
        amount: u64,
        blinding: BlindingFactor,
        // ... other params
    ) -> Result<Self, CryptoError> {
        use z00z_crypto::{create_commitment, create_range_proof};
        
        // NO mention of Tari or any backend!
        let commitment = create_commitment(amount, &blinding);
        let proof = create_range_proof(amount, &blinding, 64)?;
        
        Ok(Self {
            commitment,
            range_proof: proof,
            // ...
        })
    }
    
    /// Verify range proof using z00z_crypto API (backend hidden)
    pub fn verify_range_proof(&self) -> Result<(), CryptoError> {
        z00z_crypto::verify_range_proof(&self.range_proof, &self.commitment, 64, 1)
    }
    
    /// Verify asset (backward compatibility alias)
    pub fn verify(&self) -> Result<(), CryptoError> {
        self.verify_range_proof()
    }
}
```

**Rationale:**
- **No lifetime issues:** Asset owns its data, no references to backends
- **Flexibility:** Different backends can be used for creation vs verification
- **Performance:** Zero-sized `TariCryptoBackend` has no storage overhead

### 6.4 Phase 3: Deprecate Legacy (Assets Module Only)

**Goal:** Mark old asset-specific crypto as deprecated, prepare for removal.

**Changes:**
- Mark `crates/z00z_core/src/assets/crypto.rs` methods as `#[deprecated]`
- Update all asset examples to use `z00z_crypto::backend::CryptoBackend`
- Add migration guide for assets module users

**Timeline:** 2-3 release cycles for deprecation.

### 6.5 Phase 4: Expand to Other Modules (Incremental)

**Goal:** Roll out universal crypto backend to remaining blockchain modules.

**Module-by-module rollout:**

1. **Transactions Module** (Phase 4a)
   - Apply `CryptoBackend` for signature verification
   - Use `derive_hash(b"z00z/tx", ...)` for transaction hashes
   - Kernel proofs using `create_range_proof` / `verify_range_proof`

2. **Consensus Module** (Phase 4b)
   - Block hash verification using `derive_hash(b"z00z/block", ...)`
   - Leader election cryptographic primitives
   - Consensus signatures using `CryptoBackend` methods

3. **Networking Module** (Phase 4c)
   - Peer identity verification
   - Message authentication using `derive_hash(b"z00z/peer", ...)`
   - Encrypted channel establishment

4. **Storage Module** (Phase 4d)
   - Merkle proof generation and verification
   - Data integrity hashes using `derive_hash(b"z00z/storage", ...)`

**Each module follows same pattern:** Import `z00z_crypto::backend::CryptoBackend`, use generic methods with module-specific domain separators.

### 6.6 Phase 5: Remove Legacy Code (Breaking)

**Goal:** Clean removal of deprecated asset-specific crypto after all modules migrated.

**Breaking changes:**
**Breaking changes:**
- Remove `crates/z00z_core/src/assets/crypto.rs` (old stateless API)
- Universal `z00z_crypto::backend::CryptoBackend` becomes only crypto API
- All modules now use trait-based approach

**Major version bump required.**

### 6.6 Breaking Changes Analysis

**CRITICAL:** This section analyzes all breaking changes across migration phases to ensure proper versioning and downstream compatibility planning.

#### 6.6.1 Phase 1: No Breaking Changes ✅

**What changes:**
- New files added to `z00z_crypto` crate (backend.rs, backend_tari.rs)
- New public functions added to `z00z_crypto::` (create_commitment, create_range_proof, etc.)

**Impact:**
- ✅ Zero breaking changes
- ✅ All existing APIs preserved
- ✅ Purely additive changes
- ✅ No downstream crate modifications needed

**Version bump:** PATCH or MINOR (e.g., 1.122.0 → 1.123.0)

#### 6.6.2 Phase 2: Potential Breaking Changes ⚠️

**What changes:**
- Asset constructor signatures may change
- Error types may change: `AssetError` → `CryptoError`
- Internal imports change from `crypto::AssetCrypto` to `z00z_crypto::{...}`

**Breaking change #1: Error type unification**
```rust
// BEFORE:
impl Asset {
    pub fn new(...) -> Result<Self, AssetError> { ... }
}

// AFTER:
impl Asset {
    pub fn new(...) -> Result<Self, CryptoError> { ... }
}
```

**Mitigation strategy:**
```rust
// Add type alias for backward compatibility
pub type AssetError = CryptoError;

// Or use error conversion
impl From<CryptoError> for AssetError {
    fn from(e: CryptoError) -> Self {
        // Convert error types
    }
}
```

**Breaking change #2: Method signatures**
```rust
// BEFORE (if backend was exposed):
pub fn verify_with_backend<C: CryptoBackend>(backend: &C) -> Result<()>

// AFTER (clean API):
pub fn verify_range_proof(&self) -> Result<(), CryptoError>
```

**Impact:**
- ⚠️ Downstream crates using `Asset::new()` may need error type updates
- ⚠️ Code using specific error variants may break
- ✅ Wire format unchanged (commitments, proofs same)
- ✅ Consensus rules unchanged

**Version bump:** MINOR with deprecation warnings (e.g., 1.123.0 → 1.124.0)

#### 6.6.3 Phase 3: Deprecation (Warning) ⚠️

**What changes:**
```rust
// Mark old API as deprecated
#[deprecated(since = "1.124.0", note = "Use z00z_crypto::create_commitment instead")]
impl AssetCrypto {
    pub fn create_commitment(...) -> Commitment { ... }
}
```

**Impact:**
- ⚠️ Compiler warnings in downstream crates
- ✅ Code still compiles and runs
- ⚠️ Users must plan migration

**Version bump:** MINOR (e.g., 1.124.0 → 1.125.0)  
**Timeline:** 2-3 release cycles (6-9 months) before removal

#### 6.6.4 Phase 4: Module Expansion (Module-Specific)

**What changes:**
- Each module (transactions, consensus, networking) adopts `z00z_crypto` functions
- Module-specific error types may unify to `CryptoError`

**Breaking changes per module:**
```rust
// Transactions module
// BEFORE:
pub fn verify_signature(...) -> Result<(), TxError>
// AFTER:
pub fn verify_signature(...) -> Result<(), CryptoError>

// Consensus module
// BEFORE:
pub fn verify_block_hash(...) -> Result<(), ConsensusError>
// AFTER:
pub fn verify_block_hash(...) -> Result<(), CryptoError>
```

**Impact:**
- ⚠️ Each module migration is a MINOR version bump
- ⚠️ Downstream crates per module affected separately
- ✅ Can be rolled out gradually (module by module)

**Version bumps:** Multiple MINOR bumps (e.g., 1.125.0 → 1.126.0 → 1.127.0 → ...)

#### 6.6.5 Phase 5: Legacy Removal (BREAKING) ❌

**What changes:**
```rust
// REMOVED ENTIRELY:
- crates/z00z_core/src/assets/crypto.rs
- pub struct AssetCrypto
- pub fn derive_asset_hash(...)

// ONLY REMAINING API:
- z00z_crypto::create_commitment(...)
- z00z_crypto::create_range_proof(...)
- z00z_crypto::verify_range_proof(...)
- z00z_crypto::derive_hash(...)
```

**Impact:**
- ❌ Code using old `AssetCrypto` will NOT compile
- ❌ All downstream crates MUST migrate
- ✅ Clean codebase with single crypto API
- ✅ Future backend swaps easier

**Version bump:** MAJOR (e.g., 1.130.0 → 2.0.0)  
**Prerequisites:** All modules migrated, all downstream crates updated

#### 6.6.6 Downstream Crate Impact Matrix

| Downstream Crate | Phase 2 Impact | Phase 3 Impact | Phase 5 Impact | Action Required |
|------------------|----------------|----------------|----------------|-----------------|
| `z00z_wallet` | Error type changes | Deprecation warnings | Must migrate before 2.0 | Update error handling |
| `z00z_node` | Asset construction may change | Deprecation warnings | Must migrate before 2.0 | Update imports |
| `z00z_cli` | Minimal (uses high-level APIs) | Deprecation warnings | Update imports | Low priority |
| `z00z_tests` | Test utilities may need updates | Deprecation warnings | Rewrite test helpers | High priority |

#### 6.6.7 Feature Flag Strategy (Optional)

**Purpose:** Allow gradual adoption without breaking changes.

```toml
# In z00z_crypto/Cargo.toml
[features]
default = ["tari_backend"]
tari_backend = ["tari_crypto", "tari_bulletproofs_plus"]
legacy_api = []  # Keep old AssetCrypto during transition
```

**Usage:**
```rust
#[cfg(feature = "legacy_api")]
pub struct AssetCrypto { ... }  // Keep old API temporarily

#[cfg(not(feature = "legacy_api"))]
compile_error!("AssetCrypto removed. Use z00z_crypto:: functions.");
```

**Benefit:** Downstream crates can disable `legacy_api` incrementally.

#### 6.6.8 Semantic Versioning Summary

| Phase | Version Change | Breaking? | Timeline |
|-------|----------------|-----------|----------|
| Phase 1: Foundation | 1.122.0 → 1.123.0 | ❌ No | Sprint 1 (2 weeks) |
| Phase 2: Assets Integration | 1.123.0 → 1.124.0 | ⚠️ Minor | Sprint 2 (2 weeks) |
| Phase 3: Deprecation | 1.124.0 → 1.125.0 | ⚠️ Warnings | Sprint 3 (2 weeks) |
| Phase 4: Module Expansion | 1.125.0 → 1.130.0 | ⚠️ Per module | Sprints 4-8 (10 weeks) |
| Phase 5: Legacy Removal | 1.130.0 → 2.0.0 | ❌ Yes | Sprint 9 (after 6+ months) |

**Total migration timeline:** 6-12 months from Phase 1 to Phase 5.

### 6.7 Rollback Procedures

**Purpose:** Every migration phase needs a rollback plan for production safety.

#### Phase 1 Rollback (File Additions)

**If issues discovered:**
```bash
# Delete new files
rm crates/z00z_core/src/z00z_crypto/src/backend.rs
rm crates/z00z_core/src/z00z_crypto/src/backend_tari.rs

# Revert mod.rs changes
git checkout HEAD -- crates/z00z_core/src/assets/mod.rs
```

**Risk:** Low (no existing code affected)

#### Phase 2 Rollback (Integration)

**Feature flag approach:**
```toml
# Cargo.toml
[features]
default = []
crypto-traits = []  # Optional feature, off by default
```

**If issues discovered:**
```bash
# Disable feature in dependent crates
cargo build --no-default-features
```

**Risk:** Medium (new APIs added but old APIs unchanged)

#### Phase 3 Rollback (Default Enable)

**Runtime flag for emergency rollback:**
```rust
use std::sync::atomic::{AtomicBool, Ordering};

/// Runtime flag to disable trait backend (emergency rollback)
/// Set to false via config or environment variable
pub static USE_TRAIT_BACKEND: AtomicBool = AtomicBool::new(true);

impl Asset {
    pub fn new(...) -> Result<Self, CryptoError> {
        if USE_TRAIT_BACKEND.load(Ordering::Relaxed) {
            // New trait-based path
            Self::new_with_backend(&TariCryptoBackend::new(), ...)
        } else {
            // Old direct implementation (kept temporarily for rollback)
            Self::new_legacy(...)
        }
    }
    
    // Keep legacy implementation for 1-2 releases
    fn new_legacy(...) -> Result<Self, CryptoError> {
        // Direct Tari calls (original implementation)
    }
}
```

**Configuration:**
```bash
# Emergency rollback via environment variable
Z00Z_USE_LEGACY_CRYPTO=1 ./z00z_node
```

**Risk:** High (default changed, but rollback mechanism in place)

#### Phase 4 Rollback (Breaking Changes)

**No rollback available** - major version bump.

**Migration path:**
- Users staying on v1.x keep old API
- Users upgrading to v2.x must adapt to trait-based API
- Document migration in CHANGELOG.md

**Risk:** None (semver guarantees no surprise breakage)

---

## 7. Testing Strategy

### 7.1 Unit Tests

**File:** `crates/z00z_core/src/z00z_crypto/src/backend_tari.rs` (tests module)

**Coverage:**
- [ ] Commitment determinism (same inputs → same output)
- [ ] Commitment uniqueness (different inputs → different outputs)
- [ ] Range proof roundtrip (generate + verify succeeds)
- [ ] Range proof rejection (invalid proof fails verification)
- [ ] Range proof size limits (reject >10KB proofs)
- [ ] Asset hash determinism
- [ ] Asset hash collision resistance (different params → different hashes)
- [ ] Zero-amount commitments
- [ ] Maximum amount (2^64-1) commitments

### 7.2 Integration Tests

**File:** `crates/z00z_core/tests/assets/crypto_backend_tests.rs` (NEW)

**Scenarios:**
```rust
#[test]
fn test_asset_creation_with_trait_backend() {
    // Backend is hidden inside z00z_crypto crate
    let asset = Asset::new_with_backend(
        &backend,
        definition,
        amount,
        blinding,
        nonce,
    ).expect("Asset creation should succeed");
    
    // Verify commitment matches
    let expected_commitment = create_commitment(amount, &blinding);
    assert_eq!(asset.commitment(), &expected_commitment);
}

#[test]
fn test_batch_proof_generation() {
    // Backend is hidden inside z00z_crypto crate
    let outputs: Vec<Asset> = (0..100)
        .map(|i| create_test_asset(i * 1000))
        .collect();
    
    // All proofs should verify (backend hidden)
    for output in outputs {
        assert!(output.verify_range_proof().is_ok());
    }
}
```

### 7.3 Benchmarks

**File:** `crates/z00z_core/benches/assets/crypto_backend_bench.rs` (NEW)

**Metrics:**
```rust
#[bench]
fn bench_commitment_creation(b: &mut Bencher) {
    // Backend is hidden inside z00z_crypto crate
    let amount = 1000u64;
    let blinding = BlindingFactor::random(&mut OsRng);
    
    b.iter(|| create_commitment(amount, &blinding));
    // Target: <1μs per operation
}

#[bench]
fn bench_range_proof_generation(b: &mut Bencher) {
    // Backend is hidden inside z00z_crypto crate
    let amount = 1000u64;
    let blinding = BlindingFactor::random(&mut OsRng);
    
    b.iter(|| create_range_proof(amount, &blinding, 64));
    // Target: <6ms per 64-bit proof
}

#[bench]
fn bench_range_proof_verification(b: &mut Bencher) {
    // Backend is hidden inside z00z_crypto crate
    let amount = 1000u64;
    let blinding = BlindingFactor::random(&mut OsRng);
    let commitment = create_commitment(amount, &blinding);
    let proof = create_range_proof(amount, &blinding, 64).unwrap();
    
    b.iter(|| verify_range_proof(&proof, &commitment, 64, 1));
    // Target: <3ms per verification
}
```

**Acceptance criteria:**
- <5% performance regression vs current direct Tari calls
- Trait abstraction must be zero-cost (static dispatch)

### 7.4 Z00Z Crypto Crate Examples

**Location:** `crates/z00z_crypto/examples/` (NEW)

**Purpose:** Demonstrate universal crypto backend usage for ALL blockchain modules.

#### Example 1: Basic Backend Usage
**File:** `crates/z00z_crypto/examples/basic_backend.rs`

**What:** Demonstrates core `CryptoBackend` trait operations.
**Why:** Shows how to use trait for commitment/proof generation.
**How:** 
```rust
//! Basic example of CryptoBackend trait usage
//!
//! Shows:
//! - Creating TariCryptoBackend instance
//! - Generating commitments
//! - Creating and verifying range proofs
//! - Using derive_hash for generic hashing

use z00z_crypto::{create_commitment, create_range_proof, verify_range_proof};

use z00z_crypto::protocol_types::BlindingFactor;
use rand::rngs::OsRng;


fn main() -> Result<(), Box<dyn std::error::Error>> {
    println!("🔐 Z00Z Universal Crypto Backend Demo\n");
    
    // Initialize backend
    // Backend is hidden inside z00z_crypto crate
    println!("✅ TariCryptoBackend initialized\n");
    
    // Example 1: Create commitment
    let amount = 1000u64;
    let blinding = BlindingFactor::random(&mut OsRng);
    let commitment = create_commitment(amount, &blinding);
    println!("📦 Created commitment for amount {}", amount);
    println!("   Commitment: {} bytes", commitment.as_bytes().len());
    
    // Example 2: Generate range proof
    let proof = create_range_proof(amount, &blinding, 64)?;
    println!("\n🔒 Generated 64-bit range proof");
    println!("   Proof size: {} bytes", proof.as_bytes().len());
    
    // Example 3: Verify proof
    verify_range_proof(&proof, &commitment, 64, 1)?;
    println!("\n✅ Range proof verified successfully!");
    
    // Example 4: Generic hashing (asset use case)
    let asset_hash = z00z_crypto::derive_hash(
        b"z00z/asset",
        &[b"z00z", &[1u8], b"coin"]
    );
    println!("\n🔑 Asset hash: {:?}", &asset_hash[..8]);
    
    Ok(())
}
```

**Run:** `cargo run --example basic_backend`

#### Example 2: Cross-Module Usage
**File:** `crates/z00z_crypto/examples/cross_module_demo.rs`

**What:** Shows how different blockchain modules use same backend.
**Why:** Demonstrates universal design philosophy.
**How:**
```rust
//! Cross-module usage of universal crypto backend
//!
//! Demonstrates how assets, transactions, consensus, and networking
//! all use the same CryptoBackend trait with different domain separators.

use z00z_crypto::{create_commitment, create_range_proof, verify_range_proof};


fn main() {
    // Backend is hidden inside z00z_crypto crate
    
    println!("🌐 Cross-Module Crypto Backend Usage\n");
    
    // Assets module usage
    let asset_hash = z00z_crypto::derive_hash(
        b"z00z/asset",
        &[b"z00z", &[1u8], b"coin"]
    );
    println!("💰 Assets: derive_hash(b\"z00z/asset\", ...)");
    println!("   Hash: {:?}\n", &asset_hash[..8]);
    
    // Transactions module usage (future)
    let tx_hash = z00z_crypto::derive_hash(
        b"z00z/tx",
        &[b"tx_data_goes_here"]
    );
    println!("📝 Transactions: derive_hash(b\"z00z/tx\", ...)");
    println!("   Hash: {:?}\n", &tx_hash[..8]);
    
    // Consensus module usage (future)
    let block_hash = z00z_crypto::derive_hash(
        b"z00z/block",
        &[b"block_header_data"]
    );
    println!("⛏️  Consensus: derive_hash(b\"z00z/block\", ...)");
    println!("   Hash: {:?}\n", &block_hash[..8]);
    
    // Networking module usage (future)
    let peer_id = z00z_crypto::derive_hash(
        b"z00z/peer",
        &[b"peer_public_key"]
    );
    println!("🌍 Networking: derive_hash(b\"z00z/peer\", ...)");
    println!("   Hash: {:?}\n", &peer_id[..8]);
    
    println!("✨ Same backend, different domain separators!");
}
```

**Run:** `cargo run --example cross_module_demo`

#### Example 3: Testing Without Real Crypto
**File:** `crates/z00z_crypto/examples/testing_demo.rs`

**What:** Shows how external code tests crypto operations.
**Why:** Demonstrates that external code doesn't need mock backend access.
**How:**
```rust
//! Testing example - external modules don't need mock backends
//!
//! Shows:
//! - Testing with real crypto (fast enough for tests)
//! - External code uses same public API
//! - No need to access internal backends

use z00z_crypto::{create_commitment, create_range_proof, verify_range_proof};
use z00z_crypto::protocol_types::BlindingFactor;
use rand::rngs::OsRng;


fn main() {
    println!("🧪 Testing z00z_crypto Public API\n");
    
    // Test commitment creation
    let amount = 1000u64;
    let blinding = BlindingFactor::random(&mut OsRng);
    
    let commitment = create_commitment(amount, &blinding);
    println!("✅ Commitment created: {} bytes", commitment.as_bytes().len());
    
    // Test proof generation
    let proof = create_range_proof(amount, &blinding, 64)
        .expect("Proof generation failed");
    println!("✅ Proof generated: {} bytes", proof.as_bytes().len());
    
    // Test verification
    verify_range_proof(&proof, &commitment, 64, 1)
        .expect("Verification failed");
    println!("✅ Proof verified successfully!");
    
    println!("\n💡 External code doesn't need to know about backend choice!");
    println!("   (Tari backend is hidden inside z00z_crypto crate)");
}
```

**Run:** `cargo run --example testing_demo`

**Note:** Mock backends are ONLY used internally within `z00z_crypto` crate tests.
External modules use real crypto via public API (fast enough for testing).

### 7.5 Z00Z Crypto Crate Tests

**Location:** `crates/z00z_crypto/tests/` (NEW)

**Purpose:** Validate universal crypto backend across ALL use cases.

#### Test Suite 1: Backend Trait Compliance
**File:** `crates/z00z_crypto/tests/backend_compliance.rs`

**What:** Tests that public API behaves correctly.
**Why:** Validates z00z_crypto functions (backend choice is internal detail).
**How:**
```rust
//! Public API compliance tests
//!
//! Tests that z00z_crypto public functions:
//! - Produce deterministic outputs for same inputs
//! - Reject invalid inputs (zero amounts, bad proofs)
//! - Satisfy security properties (binding, hiding)
//!
//! NOTE: These tests use real Tari crypto (backend is internal)

use z00z_crypto::{create_commitment, create_range_proof, verify_range_proof};
use z00z_crypto::protocol_types::BlindingFactor;
use rand::rngs::OsRng;


#[test]
fn test_commitment_determinism() {
    let amount = 1000u64;
    let blinding = BlindingFactor::random(&mut OsRng);
    
    // Same inputs should produce same commitment
    let c1 = create_commitment(amount, &blinding);
    let c2 = create_commitment(amount, &blinding);
    
    assert_eq!(c1.as_bytes(), c2.as_bytes(), "Commitments must be deterministic");
}

#[test]
fn test_commitment_uniqueness() {
    let amount = 1000u64;
    let blinding1 = BlindingFactor::random(&mut OsRng);
    let blinding2 = BlindingFactor::random(&mut OsRng);
    
    // Different blinding should produce different commitment
    let c1 = create_commitment(amount, &blinding1);
    let c2 = create_commitment(amount, &blinding2);
    
    assert_ne!(c1.as_bytes(), c2.as_bytes(), "Different inputs must produce different commitments");
}

#[test]
fn test_range_proof_roundtrip() {
    let amount = 1000u64;
    let blinding = BlindingFactor::random(&mut OsRng);
    
    // Generate commitment and proof
    let commitment = create_commitment(amount, &blinding);
    let proof = create_range_proof(amount, &blinding, 64)
        .expect("Proof generation should succeed");
    
    // Verification should succeed
    verify_range_proof(&proof, &commitment, 64, 1)
        .expect("Proof verification should succeed");
}

#[test]
fn test_invalid_proof_rejected() {
    let amount = 1000u64;
    let blinding1 = BlindingFactor::random(&mut OsRng);
    let blinding2 = BlindingFactor::random(&mut OsRng);
    
    // Proof with wrong blinding should fail
    let commitment = create_commitment(amount, &blinding1);
    let proof = create_range_proof(amount, &blinding2, 64)
        .expect("Proof generation should succeed");
    
    assert!(verify_range_proof(&proof, &commitment, 64, 1).is_err(),
            "Invalid proof should be rejected");
}
```

**What it tests:**
- Deterministic commitment generation
- Range proof generation/verification roundtrip
- Invalid proof rejection
- Hash collision resistance
- Domain separation correctness

**Why important:**
- Guarantees all backends behave identically
- Catches regressions in trait implementations
- Validates security properties

#### Test Suite 2: Cross-Module Integration
**File:** `crates/z00z_crypto/tests/cross_module_integration.rs`

**What:** Tests backend usage patterns for different modules.
**Why:** Validates universal design works for assets, tx, consensus, etc.
**How:**
```rust
//! Cross-module integration tests
//!
//! Tests that CryptoBackend can be used by:
//! - Assets module (commitments, range proofs)
//! - Transactions module (signatures, tx hashes)
//! - Consensus module (block hashes)
//! - Networking module (peer IDs)

use z00z_crypto::{create_commitment, create_range_proof, verify_range_proof};


#[test]
fn assets_module_usage_pattern() {
    // Backend is hidden inside z00z_crypto crate
    
    // Assets use derive_hash with "z00z/asset" domain
    let asset_hash = z00z_crypto::derive_hash(
        b"z00z/asset",
        &[b"z00z", &[1u8], b"coin"]
    );
    
    assert_eq!(asset_hash.len(), 32);
    // Determinism check
    let asset_hash2 = z00z_crypto::derive_hash(
        b"z00z/asset",
        &[b"z00z", &[1u8], b"coin"]
    );
    assert_eq!(asset_hash, asset_hash2);
}

#[test]
fn transactions_module_usage_pattern() {
    // Backend is hidden inside z00z_crypto crate
    
    // Transactions use derive_hash with "z00z/tx" domain
    let tx_hash = z00z_crypto::derive_hash(
        b"z00z/tx",
        &[b"tx_bytes_here"]
    );
    
    assert_eq!(tx_hash.len(), 32);
    // Different domain should produce different hash
    let asset_hash = z00z_crypto::derive_hash(
        b"z00z/asset",
        &[b"tx_bytes_here"]  // Same data, different domain
    );
    assert_ne!(tx_hash, asset_hash, "Domain separation must work");
}

#[test]
fn consensus_module_usage_pattern() {
    // Backend is hidden inside z00z_crypto crate
    
    // Consensus uses derive_hash with "z00z/block" domain
    let block_hash = z00z_crypto::derive_hash(
        b"z00z/block",
        &[b"block_header", b"prev_hash", b"merkle_root"]
    );
    
    assert_eq!(block_hash.len(), 32);
}

#[test]
fn networking_module_usage_pattern() {
    // Backend is hidden inside z00z_crypto crate
    
    // Networking uses derive_hash with "z00z/peer" domain
    let peer_id = z00z_crypto::derive_hash(
        b"z00z/peer",
        &[b"peer_public_key_bytes"]
    );
    
    assert_eq!(peer_id.len(), 32);
}
```

**What it tests:**
- Correct domain separator usage per module
- Hash collision resistance across domains
- Deterministic hash generation
- Data format compatibility

**Why important:**
- Validates universal design works for ALL modules
- Ensures domain separation prevents cross-protocol attacks
- Documents expected usage patterns

#### Test Suite 3: Performance Regression
**File:** `crates/z00z_crypto/tests/performance_regression.rs`

**What:** Ensures trait abstraction has <5% overhead.
**Why:** Validates zero-cost abstraction principle.
**How:**
```rust
//! Performance regression tests
//!
//! Compares trait-based calls vs direct calls:
//! - Target: <5% overhead for trait abstraction
//! - Uses criterion.rs for accurate benchmarking

use z00z_crypto::{create_commitment, create_range_proof, verify_range_proof};

use z00z_crypto::protocol_types::BlindingFactor;
use rand::rngs::OsRng;

use std::time::Instant;

#[test]
fn commitment_performance_regression() {
    // Backend is hidden inside z00z_crypto crate
    let amount = 1000u64;
    let blinding = BlindingFactor::random(&mut OsRng);
    
    // Warmup
    for _ in 0..100 {
        create_commitment(amount, &blinding);
    }
    
    // Benchmark trait-based call
    let start = Instant::now();
    for _ in 0..1000 {
        create_commitment(amount, &blinding);
    }
    let trait_duration = start.elapsed();
    
    println!("Trait-based: {:?} per operation", trait_duration / 1000);
    // Assert reasonable performance (<1μs per commitment)
    assert!(trait_duration.as_micros() < 1000, "Too slow!");
}
```

**What it tests:**
- Commitment creation latency
- Range proof generation latency
- Verification latency
- Hash derivation latency

**Why important:**
- Prevents performance regressions
- Validates static dispatch optimization
- Ensures trait overhead is negligible

### 7.7 Assets Module Examples (Phase 2)

**File:** `crates/z00z_core/examples/assets/crypto_backend_usage.rs` (NEW)

```rust
//! Example: Using z00z_crypto clean API
//!
//! This example demonstrates:
//! 1. Creating commitments (NO mention of backend)
//! 2. Generating range proofs
//! 3. Verifying proofs
//! 4. Deriving generic hashes

use z00z_crypto::{
    create_commitment, create_range_proof, verify_range_proof, derive_hash,
    BlindingFactor,
};
use rand::rngs::OsRng;


fn main() -> Result<(), Box<dyn std::error::Error>> {
    println!("🔐 Z00Z Crypto API Demo (backend hidden!)\n");
    
    // Example 1: Create commitment
    let amount = 1000u64;
    let blinding = BlindingFactor::random(&mut OsRng);
    let commitment = create_commitment(amount, &blinding);
    println!("Commitment: {:?}", commitment);
    
    // Example 2: Generate range proof
    let proof = create_range_proof(amount, &blinding, 64)?;
    println!("Proof size: {} bytes", proof.as_bytes().len());
    
    // Example 3: Verify proof
    verify_range_proof(&proof, &commitment, 64, 1)?;
    println!("Proof verified successfully!");
    
    // Example 4: Derive asset hash (universal hash function)
    let chain_id = [0u8; 32];
    let version = 1u32;
    let class_byte = AssetClass::Coin.class_byte();
    let asset_id = b"z00z";
    
    let hash = derive_hash(
        b"z00z/asset",
        &[&chain_id, &version.to_be_bytes(), &[class_byte], asset_id]
    );
    println!("Asset hash: {:?}", hash);
    
    Ok(())
}
```

---

## 8. Performance Requirements

### 8.1 Baseline Benchmarks (Current Implementation)

| Operation | Current Performance | Target with Traits |
|-----------|---------------------|-------------------|
| `create_commitment` | 0.8μs | <1μs (<25% overhead) |
| `create_range_proof` (64-bit) | 5.2ms | <5.5ms (<5% overhead) |
| `verify_range_proof` (single) | 2.8ms | <3ms (<7% overhead) |
| `derive_asset_hash` | 2μs | <2.5μs (<25% overhead) |

### 8.2 Batch Performance

| Batch Size | Current (ms) | Target (ms) | Notes |
|------------|--------------|-------------|-------|
| 10 proofs generate | 52ms | <55ms | Sequential generation |
| 10 proofs verify | 28ms | <30ms | Bulletproofs+ batch verify |
| 100 proofs generate | 520ms | <550ms | Linear scaling |
| 100 proofs verify | 100ms | <110ms | Batching efficiency |

### 8.3 Zero-Cost Abstraction Validation

**Method:** Compare assembly output of:
```rust
// Direct call
let c1 = AssetCrypto::create_commitment(amount, &blinding);

// Trait call (monomorphized)
let c2 = create_commitment(amount, &blinding);
```

**Expected:** Identical assembly (static dispatch, no vtable, no indirection).

---

## 9. Security Considerations

### 9.1 Threat Model

**Assumptions:**
1. Cryptographic backend implementations are trusted
2. Random number generator is cryptographically secure
3. Blinding factors are not leaked
4. Tari crypto library is audited and secure

**Threats Addressed:**
- **DoS via oversized proofs:** Reject proofs >10KB
- **Malleability attacks:** Proofs bound to commitments
- **Side-channel attacks:** Constant-time operations where possible
- **Collision attacks:** Domain-separated hashing

**Out of Scope:**
- Physical side-channel attacks (power analysis, timing)
- Quantum attacks (future work: post-quantum backends)
- Social engineering or key management

### 9.2 Cryptographic Parameters

**Constants Definition:**

```rust
/// Range proof bit size (covers u64 amounts: 0..2^64-1)
pub const RANGE_PROOF_BITS_V1: usize = 64;

/// Aggregation factor for proof batching
/// Note: v1 only supports single proofs (aggregation_factor = 1)
/// Future versions may support batched proofs (aggregation_factor > 1)
pub const AGGREGATION_FACTOR: usize = 1;

/// Maximum allowed proof size for DoS protection
/// Typical 64-bit single proof: ~680 bytes
/// Safety margin allows for encoding overhead
pub const MAX_PROOF_SIZE_V1: usize = 10_240; // 10KB
```

**Parameter Table:**

| Parameter | Value | Rationale |
|-----------|-------|-----------|
| Curve | Ristretto255 | Cofactor-free, fast operations |
| Hash function | Blake2b | Fast, secure, domain separation |
| Range proof bits | 64 | Covers u64 amounts |
| Aggregation factor | 1 | Per spec, single output proofs |
| Max proof size | 10KB | DoS protection |
| Commitment factory | Pedersen | Additively homomorphic |

### 9.3 Security Invariants

**MUST hold for all implementations:**

1. **Commitment binding:** Cannot find `v' ≠ v` with same `C`
2. **Commitment hiding:** Cannot deduce `v` from `C` alone
3. **Range proof soundness:** Cannot prove false range
4. **Range proof zero-knowledge:** Proof leaks no info about `v` beyond range
5. **Hash collision resistance:** Cannot find `x ≠ y` with `H(x) = H(y)`
6. **Deterministic operations:** Same inputs → same outputs (no hidden state)

**Validation:** Each backend implementation MUST pass security test suite.

---

## 10. Backward Compatibility

### 10.1 Public API Stability

**Guaranteed stable (no breaking changes):**
```rust
// Existing Asset API
impl Asset {
    pub fn new(...) -> Result<Self, CryptoError>;
    pub fn commitment(&self) -> &Commitment;
    pub fn range_proof(&self) -> &RangeProof;
    pub fn verify_range_proof(&self) -> Result<(), CryptoError>;
}

// Existing AssetCrypto static methods
impl AssetCrypto {
    pub fn create_commitment(...) -> Commitment;
    pub fn create_range_proof(...) -> Result<RangeProof, CryptoError>;
    pub fn verify_range_proof(...) -> Result<(), CryptoError>;
}
```

**New additions in z00z_crypto crate (additive, non-breaking):**
```rust
// Public functions (backend choice hidden)
pub fn create_commitment(...) -> Commitment;
pub fn create_range_proof(...) -> Result<RangeProof, CryptoError>;
pub fn verify_range_proof(...) -> Result<(), CryptoError>;
pub fn derive_hash(...) -> [u8; 32];

// PRIVATE trait (NOT exported, internal only)
pub(crate) trait CryptoBackend { ... }
pub(crate) struct TariCryptoBackend { ... }

// Asset API remains clean (no backend exposure)
impl Asset {
    pub fn new(...) -> Result<Self, CryptoError>;  // Uses z00z_crypto:: functions internally
    pub fn verify_range_proof(&self) -> Result<(), CryptoError>;  // No backend parameter
}
```

### 10.2 Wire Format Compatibility

**NO CHANGES to serialization:**
- Asset binary format unchanged
- Commitment encoding unchanged (32 bytes compressed Ristretto point)
- RangeProof encoding unchanged (Bulletproofs+ format)
- Wire protocol version remains v1

**Interoperability:** Old and new code can exchange assets seamlessly.

### 10.3 Storage Compatibility

**NO CHANGES to database schema:**
- Asset table structure unchanged
- AssetDefinition table unchanged
- Registry storage format unchanged

**Migration:** None required, existing data compatible.

---

## 11. Implementation Checklist

**CRITICAL REMINDER:** This is API REFACTORING ONLY. All implementations WRAP existing `AssetCrypto` functions. NO new cryptographic code.

### 11.1 Phase 1: Foundation (Week 1)

- [ ] Create `crates/z00z_crypto/src/backend.rs` with `CryptoBackend` trait
- [ ] Create `crates/z00z_crypto/src/backend_tari.rs` with `TariCryptoBackend` wrapper
  - Delegates to existing `AssetCrypto::create_commitment()`
  - Delegates to existing `AssetCrypto::create_range_proof()`
  - Delegates to existing `AssetCrypto::verify_range_proof()`
  - Wraps existing `derive_asset_hash()` with generic `derive_hash()`
- [ ] Add `TariCryptoBackend::initialize()` method (wraps existing initialization)
- [ ] Create `crates/z00z_crypto/src/backend_mock.rs` for testing (fake crypto, not real)
- [ ] Update `crates/z00z_crypto/src/lib.rs` to re-export new modules
- [ ] Add comprehensive unit tests for wrapper behavior
- [ ] Add benchmarks to validate <5% overhead (wrapper tax)
- [ ] Verify existing `crates/z00z_core/tests/assets/` tests still pass (no breakage)

### 11.2 Phase 2: Integration (Week 2)

- [ ] Add `new_with_backend()` methods to `Asset`, `AssetDefinition`
- [ ] Create integration tests for trait-based asset creation
- [ ] Add examples demonstrating trait usage
- [ ] Create `crypto_mock.rs` for fast testing
- [ ] Add property-based tests using mock backend
- [ ] Update documentation with migration guide
- [ ] Benchmark full asset creation pipeline

### 11.3 Phase 3: Migration (Week 3)

- [ ] Enable `"crypto-traits"` by default
- [ ] Update internal code to use trait-based API
- [ ] Mark old stateless API as `#[deprecated]`
- [ ] Add deprecation warnings with migration hints
- [ ] Update all examples to new API
- [ ] Run full test suite on CI
- [ ] Performance regression testing

### 11.4 Phase 4: Cleanup (Future Release)

- [ ] Remove deprecated `AssetCrypto` stateless API (BREAKING)
- [ ] Remove old free functions
- [ ] Simplify module structure
- [ ] Major version bump (v2.0.0)
- [ ] Update changelog with migration guide

---

## 12. Open Questions & Decisions

### 12.1 Resolved

**Q: Should trait be object-safe for dynamic dispatch?**  
**A:** No. Performance-critical path, static dispatch only. `+ 'static` bound acceptable.

**Q: Should backend be passed as parameter or stored in Asset?**  
**A:** Passed as parameter. Avoids lifecycle issues, enables flexibility.

**Q: How to handle cached Bulletproof+ service?**  
**A:** Global `Lazy<T>` in `crypto_tari.rs`. Backend abstraction doesn't change caching strategy.

### 12.2 Open Questions

**Q: Should we support batched proof generation in trait?**  
**A:** TBD. Could add `fn create_range_proofs_batched(...)` later if needed.

**Q: Should backend be Clone or Copy?**  
**A:** TariCryptoBackend is Copy (zero-sized). Future backends may need Clone.

**Q: How to handle different proof versions (v1 vs v2)?**  
**A:** Pass `bits` parameter. Backend chooses appropriate version internally.

---

## 13. Future Work

### 13.1 Post-Quantum Backend

**File:** `crypto_post_quantum.rs` (FUTURE)

```rust
pub struct PostQuantumAssetCrypto {
    // FrodoKEM or NTRU commitment scheme
    // Lattice-based range proofs
}

impl CryptoBackend for PostQuantumAssetCrypto {
    // Quantum-resistant implementations
}
```

**Challenges:**
- Larger proof sizes (10-100x)
- Slower verification (10-100x)
- May require wire format v2

### 13.2 Multi-Backend Support

**Goal:** Support multiple backends in same binary, runtime selection.

```rust
pub enum DynamicBackend {
    Tari(TariCryptoBackend),
    PostQuantum(PostQuantumAssetCrypto),
    Mock(MockAssetCrypto),
}

impl CryptoBackend for DynamicBackend {
    fn create_commitment(&self, ...) -> Commitment {
        match self {
            Self::Tari(b) => b.create_commitment(...),
            Self::PostQuantum(b) => b.create_commitment(...),
            Self::Mock(b) => b.create_commitment(...),
        }
    }
    // ...
}
```

**Trade-off:** Dynamic dispatch overhead, but enables runtime flexibility.

### 13.3 Hardware Acceleration

**Goal:** GPU-accelerated proof generation for high-throughput nodes.

```rust
pub struct GpuAssetCrypto {
    // CUDA or OpenCL acceleration
}
```

**Requirements:**
- Batched operations for GPU efficiency
- Fallback to CPU for small batches

---

## 14. References

### 14.1 Related Specifications

- `specs/001-z00z-utils-traits/tari_ideas1.md` - Original crypto abstraction proposal
- `specs/001-z00z-utils-traits/assets_spec_release.md` - Asset wire format spec
- `specs/001-z00z-utils-traits/devils_advocate_verification.md` - Implementation review

### 14.2 External Documentation

- [Bulletproofs+ Paper](https://eprint.iacr.org/2020/735.pdf) - Range proof protocol
- [Tari Crypto Documentation](https://github.com/tari-project/tari-crypto) - Tari implementation
- [Ristretto Group](https://ristretto.group/) - Curve specification

### 14.3 Code References

- `crates/z00z_core/src/assets/crypto.rs` - Current implementation (538 lines)
- `crates/z00z_core/src/assets/mod.rs` - Module overview
- `crates/z00z_crypto/` - Cryptographic primitives crate

---

## 15. Approval & Sign-Off

**Spec Author:** GitHub Copilot  
**Spec Reviewer:** TBD  
**Status:** REVIEW (awaiting approval)  
**Target Completion:** Sprint 2025-12  

**Approval Checklist:**
- [ ] Architecture review (tech lead)
- [ ] Security review (crypto specialist)
- [ ] Performance review (benchmarking team)
- [ ] API review (library maintainers)
- [ ] Documentation review (tech writers)

---

**End of Specification**
