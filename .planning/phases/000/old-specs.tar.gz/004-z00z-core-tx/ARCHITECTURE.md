# Serial ID Architecture Diagrams

**Version**: 1.0  
**Date**: 2025-11-25  
**Related**: update-draft.md §4 (Architecture Changes)

---

## 1. Type Hierarchy

```
┌─────────────────────────────────────────────────────────────┐
│                    Asset Type Hierarchy                      │
└─────────────────────────────────────────────────────────────┘

                         AssetTag
                ┌──────────────────────┐
                │ id: [u8; 32]        │
                │ class: AssetClass   │
                │ decimals: u8        │
                │ serial_id: Option   │ ← NEW
                └──────────────────────┘
                           │
                           │ references
                           ↓
                   OutputFeatures
        ┌───────────────────────────────────┐
        │ lock_height: Option<u64>         │
        │ is_burned: bool                    │
        │ nonce: [u8; 32]                  │
        │ asset_tag: Option<AssetTag>      │
        │ serial_amounts: Vec<SerialAmount>    │ ← NEW
        └───────────────────────────────────┘
                           │
                           │ contains
                           ↓
                   SerialAmount
              ┌──────────────────────┐
              │ serial_id: u64      │ ← NEW
              │ amount: Amount      │
              └──────────────────────┘
                           │
          ┌────────────────┼────────────────┐
          │                │                │
          ↓                ↓                ↓
    CoinOutput      TokenOutput       NftOutput
    ┌──────────┐    ┌──────────┐     ┌──────────┐
    │serial_amounts │    │serial_amounts │     │serial_amounts │
    │commitment│    │commitment│     │commitment│
    │range_proof│   │range_proof│    │range_proof│
    │features  │    │features  │     │features  │
    │metadata  │    │metadata  │     │metadata  │
    └──────────┘    └──────────┘     └──────────┘
```

---

## 2. Genesis Serial ID Assignment

```
┌─────────────────────────────────────────────────────────────┐
│              Genesis: Serial ID Assignment                   │
└─────────────────────────────────────────────────────────────┘

Input: seed = [0u8; 32], num_coins = 50,000

                    ┌─────────────────┐
                    │  ChaChaRng      │
                    │  from_seed()    │
                    └─────────────────┘
                            │
                            │ Generate blinding factors
                            ↓
         ┌──────────────────────────────────────┐
         │  For index in 0..49,999:            │
         │                                      │
         │  serial_id = index                  │ ← KEY ASSIGNMENT
         │  blinding = RNG.next()              │
         │  nonce = derive_nonce(RNG)          │
         │                                      │
         │  serial_amounts = [SerialAmount {       │
         │    serial_id: index,                │
         │    amount: GENESIS_COIN_NOMINAL     │
         │  }]                                  │
         │                                      │
         │  commitment = commit(blinding, 20K) │
         │  range_proof = prove(blinding, 20K) │
         │                                      │
         │  features = OutputFeatures {        │
         │    asset_tag: Some(AssetTag {       │
         │      serial_id: Some(index),        │ ← Embedded in tag
         │      ...                             │
         │    }),                               │
         │    serial_amounts: serial_amounts,             │ ← Embedded in features
         │    ...                               │
         │  }                                   │
         │                                      │
         │  → CoinOutput { serial_amounts, ... }    │
         └──────────────────────────────────────┘
                            │
                            ↓
         ┌──────────────────────────────────────┐
         │  Genesis Unspent Set:                │
         │                                      │
         │  Coin #0:   serial_id=0,   20K      │
         │  Coin #1:   serial_id=1,   20K      │
         │  Coin #2:   serial_id=2,   20K      │
         │  ...                                 │
         │  Coin #49999: serial_id=49999, 20K  │
         │                                      │
         │  Total: 50K coins × 20K = 1B units  │
         └──────────────────────────────────────┘
```

---

## 3. Value Particles Flow

```
┌─────────────────────────────────────────────────────────────┐
│         Value Particles Through Transaction                  │
└─────────────────────────────────────────────────────────────┘

GENESIS STATE (Single Particles)
┌────────────────────────────────────────────────────────────┐
│ Output #0:  serial_amounts=[{serial_id:0, amt:20K}]            │
│ Output #1:  serial_amounts=[{serial_id:1, amt:20K}]            │
│ Output #2:  serial_amounts=[{serial_id:2, amt:20K}]            │
│ ...                                                        │
└────────────────────────────────────────────────────────────┘

                           ↓
                    Transaction #1
                 (Split coin #0)
                           ↓

POST-TX STATE (Still Single Particles)
┌────────────────────────────────────────────────────────────┐
│ Output #A:  serial_amounts=[{serial_id:0, amt:12K}]  ← Split   │
│ Output #B:  serial_amounts=[{serial_id:0, amt:8K}]   ← Split   │
│ Output #1:  serial_amounts=[{serial_id:1, amt:20K}]  ← Unchanged│
│ ...                                                        │
└────────────────────────────────────────────────────────────┘

                           ↓
                    Transaction #2
            (Payment: 15K from mixed sources)
         Input: Output #A (12K, serial_id=0)
         Input: Output #1 (20K, serial_id=1)
                           ↓

POST-TX STATE (MIXED Particles!)
┌────────────────────────────────────────────────────────────┐
│ Payment Output:                                            │
│   serial_amounts=[                                              │
│     {serial_id:0, amt:12K},  ← From Output #A             │
│     {serial_id:1, amt:3K}    ← From Output #1             │
│   ]                                                        │
│   total=15K                                                │
│                                                            │
│ Change Output:                                             │
│   serial_amounts=[                                              │
│     {serial_id:1, amt:17K}   ← Remainder from Output #1   │
│   ]                                                        │
└────────────────────────────────────────────────────────────┘

Key Insight: Output can contain MULTIPLE serial_ids!
Conservation: Per serial_id, inputs = outputs
  - serial_id=0: 12K in → 12K out ✅
  - serial_id=1: 20K in → 3K + 17K out ✅
```

---

## 4. Sharded State Architecture

```
┌─────────────────────────────────────────────────────────────┐
│            Sharded State (50K Independent Trees)             │
└─────────────────────────────────────────────────────────────┘

BEFORE (Single Tree)
┌──────────────────────────────────────┐
│      Global Sparse Merkle Tree      │
│                                      │
│  Coin #0:    [output data]          │
│  Coin #1:    [output data]          │
│  Coin #2:    [output data]          │
│  ...                                 │
│  Coin #49999: [output data]         │
│                                      │
│  Depth: log₂(50,000) ≈ 15 layers    │
│  Single-threaded updates            │
└──────────────────────────────────────┘

                    ↓ MIGRATION ↓

AFTER (Sharded Trees)
┌──────────────────────────────────────────────────────────────┐
│                  ShardedState                                │
│                                                              │
│  trees[0]:  SMT for serial_id=0     ← Independent tree     │
│  trees[1]:  SMT for serial_id=1     ← Independent tree     │
│  trees[2]:  SMT for serial_id=2     ← Independent tree     │
│  ...                                                         │
│  trees[49999]: SMT for serial_id=49999                      │
│                                                              │
│  Each tree: ~1000 outputs (after mixing)                    │
│  Depth: log₂(1000) ≈ 10 layers      ← Shallower           │
│  Parallel updates possible          ← 50x speedup          │
│                                                              │
│  ┌────────────────────────────────────────────┐            │
│  │  Global Root Computation:                  │            │
│  │                                             │            │
│  │  global_root = Merkle(                     │            │
│  │    trees[0].root(),                        │            │
│  │    trees[1].root(),                        │            │
│  │    ...                                      │            │
│  │    trees[49999].root()                     │            │
│  │  )                                          │            │
│  └────────────────────────────────────────────┘            │
└──────────────────────────────────────────────────────────────┘

Routing Logic:
┌──────────────────────────────────────────────────────────────┐
│  insert(output):                                             │
│    for serial_amount in output.serial_amounts:                         │
│      shard_idx = serial_amount.serial_id as usize                 │
│      trees[shard_idx].insert(output.coin_id(), output)       │
│                                                              │
│  is_unspent(coin_id, serial_id):                            │
│    shard_idx = serial_id as usize                            │
│    return trees[shard_idx].contains(coin_id)                 │
└──────────────────────────────────────────────────────────────┘
```

---

## 5. Transaction Validation Flow

```
┌─────────────────────────────────────────────────────────────┐
│         Transaction Validation (Serial ID Rules)             │
└─────────────────────────────────────────────────────────────┘

Input: Transaction { inputs: [...], outputs: [...] }

┌────────────────────────────────────────────────────────────┐
│  STEP 1: Extract all serial_amounts                             │
└────────────────────────────────────────────────────────────┘
                           │
                           ↓
         ┌─────────────────────────────────────┐
         │  For each input:                    │
         │    collect input.serial_amounts          │
         │                                      │
         │  For each output:                   │
         │    collect output.serial_amounts         │
         └─────────────────────────────────────┘
                           │
                           ↓
┌────────────────────────────────────────────────────────────┐
│  STEP 2: Group by serial_id                                │
└────────────────────────────────────────────────────────────┘
                           │
                           ↓
         ┌─────────────────────────────────────┐
         │  balances = BTreeMap<u64, i64>     │
         │                                      │
         │  For input serial_amount:                │
         │    balances[serial_id] += amount    │
         │                                      │
         │  For output serial_amount:               │
         │    balances[serial_id] -= amount    │
         └─────────────────────────────────────┘
                           │
                           ↓
┌────────────────────────────────────────────────────────────┐
│  STEP 3: Check conservation per serial_id                  │
└────────────────────────────────────────────────────────────┘
                           │
                           ↓
         ┌─────────────────────────────────────┐
         │  For (serial_id, balance):          │
         │    if balance != 0:                 │
         │      REJECT ❌                       │
         │                                      │
         │  If all balanced:                   │
         │    ACCEPT ✅                         │
         └─────────────────────────────────────┘

Example:
┌────────────────────────────────────────────────────────────┐
│  Inputs:                                                   │
│    - serial_amounts=[{serial_id:5, amt:10K}, {serial_id:78, amt:125}] │
│  Outputs:                                                  │
│    - serial_amounts=[{serial_id:5, amt:8K}]                    │
│    - serial_amounts=[{serial_id:5, amt:2K}, {serial_id:78, amt:125}] │
│                                                            │
│  Balances:                                                 │
│    serial_id=5:  10K in - 8K out - 2K out = 0 ✅         │
│    serial_id=78: 125 in - 125 out = 0 ✅                 │
│                                                            │
│  Result: VALID                                             │
└────────────────────────────────────────────────────────────┘
```

---

## 6. State Transition Diagram

```
┌─────────────────────────────────────────────────────────────┐
│              Output Lifecycle with Serial ID                 │
└─────────────────────────────────────────────────────────────┘

    GENESIS
       │
       │ serial_id assigned
       ↓
  ┌─────────┐
  │ Unspent │  ← Single serial_amount: {serial_id:X, amt:20K}
  │ Tree[X] │
  └─────────┘
       │
       │ Transaction: Split
       ↓
  ┌─────────┐
  │ Unspent │  ← Two serial_amounts:
  │ Tree[X] │     Output A: {serial_id:X, amt:12K}
  └─────────┘     Output B: {serial_id:X, amt:8K}
       │
       │ Transaction: Mix with serial_id Y
       ↓
  ┌─────────┐  ┌─────────┐
  │ Unspent │  │ Unspent │  ← Mixed output in BOTH trees:
  │ Tree[X] │  │ Tree[Y] │     serial_amounts=[
  └─────────┘  └─────────┘       {serial_id:X, amt:5K},
       │            │              {serial_id:Y, amt:3K}
       │            │            ]
       │            │
       │ Transaction: Spend
       ↓            ↓
  ┌─────────┐  ┌─────────┐
  │  SPENT  │  │  SPENT  │  ← Removed from BOTH trees
  │  (gone) │  │  (gone) │
  └─────────┘  └─────────┘

Key Rules:
1. Serial ID never changes (immutable from genesis)
2. Output can be in multiple trees (multi-serial_amount)
3. Tree presence = unspent (tree-only model)
4. Removal = mark as spent (no separate spent set needed)
```

---

## 7. CoinID vs Serial ID

```
┌─────────────────────────────────────────────────────────────┐
│           CoinID vs Serial ID: Key Distinction               │
└─────────────────────────────────────────────────────────────┘

CoinID (Output Identifier)
┌────────────────────────────────────────────────────────────┐
│  Purpose: Unique identifier for OUTPUT CONTAINER           │
│  Type:    [u8; 32]                                         │
│  Derived: Blake2b(nonce, commitment, asset_tag, serial_amounts) │
│  Changes: Every transaction creates NEW coin_id            │
│  Use:     Double-spend prevention                          │
│                                                            │
│  Example:                                                  │
│    Genesis Output:                                         │
│      coin_id = 0xAAA...                                   │
│      serial_amounts = [{serial_id:5, amt:20K}]                 │
│                                                            │
│    After Split:                                            │
│      Output A: coin_id = 0xBBB... (NEW!)                  │
│                serial_amounts = [{serial_id:5, amt:12K}]       │
│      Output B: coin_id = 0xCCC... (NEW!)                  │
│                serial_amounts = [{serial_id:5, amt:8K}]        │
│                                                            │
│    coin_id changed: 0xAAA → 0xBBB, 0xCCC                  │
└────────────────────────────────────────────────────────────┘

Serial ID (Value Provenance)
┌────────────────────────────────────────────────────────────┐
│  Purpose: Track VALUE PARTICLES from genesis               │
│  Type:    u64                                              │
│  Assigned: At genesis (serial_id = index)                  │
│  Changes: NEVER (immutable)                                │
│  Use:     Sharding, provenance, consolidation              │
│                                                            │
│  Example:                                                  │
│    Genesis Output:                                         │
│      coin_id = 0xAAA...                                   │
│      serial_amounts = [{serial_id:5, amt:20K}]                 │
│                 ↑ Serial ID = 5 (from genesis coin #5)    │
│                                                            │
│    After Split:                                            │
│      Output A: coin_id = 0xBBB...                         │
│                serial_amounts = [{serial_id:5, amt:12K}]       │
│                           ↑ STILL serial_id=5!             │
│      Output B: coin_id = 0xCCC...                         │
│                serial_amounts = [{serial_id:5, amt:8K}]        │
│                           ↑ STILL serial_id=5!             │
│                                                            │
│    serial_id unchanged: 5 → 5                             │
└────────────────────────────────────────────────────────────┘

Relationship:
┌────────────────────────────────────────────────────────────┐
│  One CoinID (output) can contain MULTIPLE serial_ids       │
│  One Serial ID can appear in MULTIPLE outputs              │
│                                                            │
│  Example (mixed output):                                   │
│    coin_id = 0xDDD...                                     │
│    serial_amounts = [                                           │
│      {serial_id:5,  amt:10K},   ← From genesis coin #5    │
│      {serial_id:78, amt:125},   ← From genesis coin #78   │
│      {serial_id:142, amt:30K}   ← From genesis coin #142  │
│    ]                                                       │
│                                                            │
│  This output exists in 3 trees: trees[5], trees[78], trees[142] │
└────────────────────────────────────────────────────────────┘
```

---

## 8. Migration Timeline

```
┌─────────────────────────────────────────────────────────────┐
│                   Implementation Timeline                    │
└─────────────────────────────────────────────────────────────┘

Week 1-2: Data Structures
┌────────────────────────────────────────────────────────────┐
│ Phase 1: AssetTag, SerialAmount, OutputFeatures          │
│ Phase 2: CoinOutput, TokenOutput, NftOutput, VoidOutput   │
│                                                            │
│ Status: No consensus changes yet (backwards compatible)   │
└────────────────────────────────────────────────────────────┘
                           │
                           ↓
Week 3: Genesis
┌────────────────────────────────────────────────────────────┐
│ Phase 3: Serial ID assignment in genesis                  │
│                                                            │
│ Status: Genesis fixtures regenerated                      │
│ ⚠️  Hard fork point #1                                    │
└────────────────────────────────────────────────────────────┘
                           │
                           ↓
Week 4: Validation
┌────────────────────────────────────────────────────────────┐
│ Phase 5: Per-serial-id conservation                        │
│                                                            │
│ Status: Consensus rule activated                          │
│ ⚠️  Hard fork point #2 (CRITICAL)                         │
└────────────────────────────────────────────────────────────┘
                           │
                           ↓
Week 5-6: Optimization
┌────────────────────────────────────────────────────────────┐
│ Phase 4: Sharded state (50K trees)                        │
│ Phase 6: YAML + codegen                                   │
│                                                            │
│ Status: Performance boost (50x)                           │
│ Safe: No consensus changes                                │
└────────────────────────────────────────────────────────────┘
                           │
                           ↓
Week 7: Testing
┌────────────────────────────────────────────────────────────┐
│ Unit tests (50+), integration tests, benchmarks           │
│ Security audit                                             │
└────────────────────────────────────────────────────────────┘
                           │
                           ↓
Week 8+: Deployment
┌────────────────────────────────────────────────────────────┐
│ Testnet deployment                                         │
│ Migration testing                                          │
│ Mainnet hard fork coordination                            │
└────────────────────────────────────────────────────────────┘
```

---

**Last Updated**: 2025-11-25  
**Related Docs**: update-draft.md, QUICK_REFERENCE.md
