# Serial ID Integration Release Candidate

**Version**: 1.1 (Release Candidate)
**Date**: 2025-11-25
**Status**: Ready for Implementation
**Author**: Z00Z Core Team

---

## Table of Contents

1. [Executive Summary](#1-executive-summary)
2. [Current State Analysis](#2-current-state-analysis)
3. [Design Decisions](#3-design-decisions)
4. [Architecture Changes](#4-architecture-changes)
5. [Implementation Plan](#5-implementation-plan)
6. [Migration Strategy](#6-migration-strategy)
7. [Testing Requirements](#7-testing-requirements)
8. [Performance Impact](#8-performance-impact)
9. [Security Considerations](#9-security-considerations)

---

## 1. Executive Summary

### 1.1 Purpose

This document outlines the integration of **Serial ID** (immutable genesis coin tracking) into the Z00Z core asset model, enabling:

- **Parallel tree processing**: 10-15x speedup on typical hardware via tree-per-genesis architecture
- **Value provenance**: Track coin fragments from genesis through all transactions
- **Efficient consolidation**: Auto-merge outputs from same serial_id
- **Auditability**: Transparent value flow without privacy compromise

### 1.2 Key Changes

| Component                     | Current State              | Target State                                       |
| ----------------------------- | -------------------------- | -------------------------------------------------- |
| **Asset Types**         | All assets = unified model | All assets support serial_id serial_amounts        |
| **Output Structure**    | Single value commitment    | Serial amounts + serial_id composition             |
| **Genesis**             | 50K coins, no serial_id    | 50K coins with serial_id ∈ [1, 50000]             |
| **State Trees**         | Single global tree         | 50K independent trees (one per serial_id)          |
| **AssetTag**            | ID + class + decimals      | **+ optional serial_id field**               |
| **Z00Z_NATIVE_COIN_ID** | Hardcoded constant         | **REMOVED** - AssetClass::Coin is sufficient |

### 1.3 Terminology Clarity

**CoinID vs Serial ID**:

```rust
// CoinID = unique identifier for OUTPUT (prevents double-spend)
pub type CoinID = [u8; 32];  // Derived from (nonce, commitment, asset_tag)

// SerialID = genesis coin tracking number (value provenance)
pub type SerialID = u32;     // Range: [1, 50000] for 50K genesis coins
                             // Genesis assignment: serial_id = index + 1
```

**Key Distinction**:

- **CoinID**: Identifies an **output container** (can contain multiple serial_ids)
- **SerialID**: Identifies **serial amounts** inside outputs (immutable from genesis)

---

## 2. Current State Analysis

### 2.1 Existing Asset Structure

**File**: `crates/z00z_core/src/assets/common.rs`

```rust
// Current AssetTag structure
pub struct AssetTag {
    pub class: AssetClass,   // Coin/Token/NFT/Void (sufficient for asset identification)
    pub decimals: u8,        // Decimal places
}

// Current OutputFeatures (consensus-critical)
pub struct OutputFeatures {
    pub lock_height: Option<u64>,
    pub is_burned: bool,
    pub nonce: [u8; 32],
    pub asset_tag: Option<AssetTag>,
}
```

**Problem**: No serial_id tracking → cannot implement tree partitioning or provenance.

### 2.2 Output Types Inventory

**All 4 asset types need serial_id support**:

| File          | Structure       | Current State             | Serial ID Support  |
| ------------- | --------------- | ------------------------- | ------------------ |
| `coins.rs`  | `CoinOutput`  | Single value commitment   | **Must Add** |
| `tokens.rs` | `TokenOutput` | Token ID + commitment     | **Must Add** |
| `nfts.rs`   | `NftOutput`   | NFT metadata + commitment | **Must Add** |
| `void.rs`   | `VoidOutput`  | Void sink commitment      | **Must Add** |

---

## 3. Design Decisions

### 3.1 Serial ID Storage Location

**DECISION**: Add `serial_id` field to **OutputFeatures** (consensus-critical).

**Rationale**:

- Serial ID is a **consensus property** (affects validation, tree routing)
- Must be included in transaction commitments
- Cannot be in `OutputMetadata` (non-consensus, prunable)

**Alternative Considered**:

- ❌ Separate `SerialIDMap` outside outputs → breaks atomicity
- ❌ Inside `AssetTag` → wrong semantic (asset type ≠ value provenance)

### 3.2 AssetTag Extension

**DECISION**: Add **optional** `serial_id` field to `AssetTag`.

```rust
pub struct AssetTag {
    pub class: AssetClass,         // Sufficient for asset identification
    pub decimals: u8,              // Decimal places
    pub serial_id: Option<u32>,    // NEW: Genesis tracking (if native coin)
}

impl AssetTag {
    /// Validate AssetTag consistency
    /// CRITICAL INVARIANT: class == Coin ⟺ serial_id.is_some()
    pub fn validate(&self) -> Result<(), AssetError> {
        match self.class {
            AssetClass::Coin => {
                if self.serial_id.is_none() {
                    return Err(AssetError::MissingSerialID);
                }
                // Validate range [1, 50000]
                if let Some(sid) = self.serial_id {
                    if sid < 1 || sid > GENESIS_NUM_COINS as u32 {
                        return Err(AssetError::SerialIDOutOfRange { sid, max: GENESIS_NUM_COINS as u32 });
                    }
                }
            },
            AssetClass::Token | AssetClass::Nft | AssetClass::Void => {
                if self.serial_id.is_some() {
                    return Err(AssetError::UnexpectedSerialID { class: self.class });
                }
            },
        }
        Ok(())
    }
}
```

**Why Optional?**

- Native coins (`AssetClass::Coin`): `serial_id = Some(genesis_index)`
- Tokens/NFTs/Void: `serial_id = None` (no genesis tracking)

**Impact**: All asset types inherit serial_id support, but only native coins use it.

### 3.3 Serial Amount Composition Model

**DECISION**: Extend all Output types with serial amount composition.

**New Structure** (applies to all 4 output types):

```rust
/// Serial amount: amount from specific genesis coin series
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct nt {
    pub serial_id: u32,    // Genesis coin series number (1-50000)
    pub amount: Amount,    // Value from this series
}

/// Extended CoinOutput (similar changes for Token/NFT/Void)
pub struct CoinOutput {
    pub commitment: Commitment,         // C = Σ amounts (all serials)
    pub range_proof: Option<RangeProof>,
    pub features: OutputFeatures,
    pub metadata: Option<OutputMetadata>,
  
    // NEW: Serial composition (backwards compatible - defaults to single serial)
    pub serial_amounts: Vec<SerialAmount>,  // At least 1 serial
}
```

**Invariants**:

1. `serial_amounts.len() >= 1` (at least one serial)
2. No duplicate serial_ids: `∀ i≠j: serial_amounts[i].serial_id ≠ serial_amounts[j].serial_id`
3. Conservation: `Σ serial_amounts[i].amount == commitment.value`

### 3.4 Default Genesis Encoding

**DECISION**: Genesis coins use single-serial encoding by default.

**Rationale**: Simplicity for initial state. Multi-serial outputs emerge naturally through transactions mixing different genesis coins.

**Genesis coins** (simple case):

```rust
CoinOutput {
    serial_amounts: vec![SerialAmount { 
        serial_id: index + 1,       // Genesis coin #1, #2, ..., #50000 (1-indexed!)
        amount: GENESIS_COIN_NOMINAL 
    }],
    // ... other fields
}
```

**Mixed outputs** (after transactions):

```rust
CoinOutput {
    serial_amounts: vec![
        SerialAmount { serial_id: 5, amount: 10_304 },
        SerialAmount { serial_id: 78, amount: 125 },
        SerialAmount { serial_id: 142, amount: 35_698 },
    ],
    // Commitment proves total = 10_304 + 125 + 35_698 = 46_127
}
```

**Note**: This is the initial system design, not a migration from legacy format. Later transactions create multi-serial outputs naturally as users spend mixed coins.

## 4. Architecture Changes

### 4.1 State Tree Partitioning

**Current**: Single global tree (slow, 50K outputs).

**Target**: 50K independent trees (tree-per-genesis).

```rust
/// NEW: State indexed by serial_id (parallel to AssetClassState)
pub struct SerialClassState {
    /// One tree per genesis coin (50K trees)
    pub trees: Vec<JellyfishMerkleTree>,  // trees[serial_id - 1] = outputs with that serial_id (1-indexed!)
  
    /// Root hashes for all trees
    pub roots: Vec<[u8; 32]>,          // roots[serial_id - 1] = tree root
  
    /// Global root (commitment to all serial_id tree roots)
    pub global_root: [u8; 32],         // Merkle root of roots[]
}

impl SerialClassState {
    /// Route output to correct serial_id tree
    pub fn insert(&mut self, output: &CoinOutput) -> Result<()> {
        for serial_amount in &output.serial_amounts {
            let tree_index = (serial_amount.serial_id - 1) as usize;  // 1-indexed serial_id!
            self.trees[tree_index].insert(output.coin_id(), output)?;
        }
        self.recompute_global_root();
        Ok(())
    }
  
    /// Check if coin is unspent in specific serial_id tree (tree-only model, no separate SpentSet)
    /// Spent coins DISAPPEAR from Jellyfish sparse tree (become NULL nodes)
    pub fn is_unspent(&self, coin_id: &CoinID, serial_id: u32) -> bool {
        let tree_index = (serial_id - 1) as usize;
        self.trees[tree_index].contains(coin_id)  // Present in tree = unspent
    }
  
    /// Mark coin as spent (remove from ALL relevant serial_id trees)
    pub fn mark_spent(&mut self, coin_id: &CoinID, serial_amounts: &[SerialAmount]) -> Result<()> {
        for serial_amount in serial_amounts {
            let tree_index = (serial_amount.serial_id - 1) as usize;
        
            // Remove from Jellyfish tree (becomes NULL node in sparse tree)
            self.trees[tree_index].remove(coin_id)?;
        
            // Update tree root
            self.roots[tree_index] = self.trees[tree_index].root();
        }
    
        // Recompute global root
        self.recompute_global_root();
    
        // No separate spent_set needed - absence from tree IS the "spent" marker
        Ok(())
    }
}
```

**Performance**: 10-15x speedup on typical hardware (parallel tree updates, smaller tree depth).

**Note**: Changed from `SparseMerkleTree` to `JellyfishMerkleTree` for production use. Tree indexing uses `serial_id - 1` due to 1-indexed serial_id numbering.

### 4.1.2 Multi-Asset State Hierarchy

**CRITICAL ADDITION**: Full state hierarchy supporting all asset classes.

The state root architecture aggregates ALL asset types (coins, tokens, NFTs, void) with extensibility for future assets.

```rust
/// Per-asset-class tree hierarchy (applies to ALL assets)
#[derive(Debug, Clone)]
pub struct AssetClassState {
    /// Asset class identifier
    pub asset_class: AssetClass,
  
    /// Trees for this asset class
    /// - Coins: 50K trees (one per serial_id 1-50000)
    /// - Tokens: Variable trees (per token series)
    /// - NFTs: Variable trees (per NFT collection)
    /// - Void: Single tree (burn sink)
    pub trees: Vec<JellyfishMerkleTree>,
  
    /// Per-tree roots
    pub tree_roots: Vec<[u8; 32]>,
  
    /// Super root for this asset class (Merkle root of tree_roots)
    /// Compresses all trees of this class into single 32-byte commitment
    pub super_root: [u8; 32],
}

impl AssetClassState {
    /// Recompute super_root from all tree roots
    pub fn recompute_super_root(&mut self) {
        let mut hasher = Blake2b::<U32>::new();
    
        // Hash all tree roots in order
        for root in &self.tree_roots {
            hasher.update(root);
        }
    
        // Super root = commitment to all trees in this asset class
        self.super_root.copy_from_slice(&hasher.finalize());
    }
}

/// Full epoch state with multi-asset support
/// Supports ALL assets from assets_schema.yaml + future extensibility
#[derive(Debug, Clone)]
pub struct EpochState {
    pub epoch_id: EpochId,
    pub meta: EpochMeta,
  
    /// Universal asset state map (loaded dynamically from assets_schema.yaml)
    /// Key: AssetClass enum variant (z00z, zusd, ticket_nft, burn_void, etc.)
    /// Value: AssetClassState with tree hierarchy for that asset
    /// 
    /// NO HARDCODED FIELDS: Adding new asset in YAML automatically works
    /// BTreeMap ensures deterministic iteration order for consensus
    pub asset_states: BTreeMap<AssetClass, AssetClassState>,
  
    /// Global epoch root (Merkle root of all super_roots)
    /// This is the SINGLE 32-byte hash that represents ENTIRE blockchain state
    /// "szhat vse sostojanija v 1 cifru" - compress all state to 1 number
    pub epoch_root: [u8; 32],
  
    pub counters: EpochCounters,
}

impl EpochState {
    /// Create new epoch state with assets loaded from schema
    pub fn new(epoch_id: EpochId, asset_schema: &AssetSchema) -> Self {
        let mut asset_states = BTreeMap::new();
    
        // Initialize asset states from schema (e.g., assets_schema.yaml)
        for asset_def in &asset_schema.assets {
            let num_trees = match asset_def.class {
                AssetClass::Coin => GENESIS_NUM_COINS,  // 50K trees for coins
                AssetClass::Token => asset_def.initial_series_count.unwrap_or(1),
                AssetClass::Nft => asset_def.initial_collections_count.unwrap_or(1),
                AssetClass::Void => 1,  // Single burn sink tree
            };
        
            asset_states.insert(
                asset_def.class,
                AssetClassState::new(asset_def.class, num_trees)
            );
        }
    
        let mut state = Self {
            epoch_id,
            meta: EpochMeta::default(),
            asset_states,
            epoch_root: [0u8; 32],
            counters: EpochCounters::default(),
        };
    
        // Compute initial epoch_root
        state.recompute_epoch_root();
        state
    }
  
    /// Recompute epoch_root from all asset class super_roots
    /// This creates the canonical state commitment for the entire epoch
    pub fn recompute_epoch_root(&mut self) {
        let mut hasher = Blake2b::<U32>::new();
    
        // Aggregate all asset class super_roots in deterministic order
        hasher.update(b"z00z/epoch_root/v1");  // Version tag
        hasher.update(self.epoch_id.to_le_bytes());
    
        // UNIVERSAL: Iterate over ALL assets dynamically (BTreeMap ensures deterministic order)
        // No hardcoded asset names - works for ANY assets defined in assets_schema.yaml
        for (asset_class, state) in self.asset_states.iter() {
            // Hash: (asset_class_discriminant || super_root)
            hasher.update(&[*asset_class as u8]);  // 1-byte enum discriminant for identity
            hasher.update(&state.super_root);       // 32-byte tree commitment
        }
    
        // Final epoch root: single 32-byte commitment to ENTIRE state
        // Light clients can verify entire blockchain state with just this hash
        self.epoch_root.copy_from_slice(&hasher.finalize());
    }
  
    /// Register new asset class dynamically (no code changes needed)
    /// Called during genesis or when loading assets_schema.yaml
    pub fn register_asset(&mut self, asset_class: AssetClass, num_trees: usize) {
        self.asset_states.insert(
            asset_class,
            AssetClassState::new(asset_class, num_trees)
        );
        self.recompute_epoch_root();
    }
  
    /// Verify Merkle proof for specific asset tree (light client support)
    pub fn verify_asset_proof(
        &self,
        asset_class: AssetClass,
        tree_index: usize,
        proof: &MerkleProof,
    ) -> bool {
        // 1. Verify tree_root in asset class super_root
        // 2. Verify super_root in epoch_root
        // This enables light clients to verify any output with just epoch_root
        // ... implementation details
        true
    }
}
```

**Hierarchical Root Structure**:

```text
                         epoch_root (32 bytes)
                    "Single number for entire state"
                              |
         +--------------------+--------------------+
         |                    |                    |
    asset_states[z00z]   asset_states[zusd]  asset_states[...]
    super_root           super_root           super_root
         |                    |                    |
    50K trees           Token trees          Dynamic trees
  (serial 1-50000)     (per series)         (per asset type)
         |                    |                    |
   [tree roots]          [tree roots]         [tree roots]
         |                    |                    |
  Individual UTXOs      Token UTXOs          Asset-specific UTXOs


UNIVERSAL: BTreeMap iteration ensures deterministic order regardless of YAML changes
```

**Key Properties**:

1. **Single Root Commitment**: `epoch_root` = 32 bytes representing ALL state
2. **Light Client Friendly**: Verify any UTXO with Merkle proof from epoch_root
3. **Asset Isolation**: Each asset class validates independently (parallel validation)
4. **Dynamic Extensibility**: Add new assets in YAML without code changes
5. **Cross-Chain Ready**: Bridge can verify state with single epoch_root hash

**Why This Matters**:

- **Light Clients**: Download epoch_root only (32 bytes), verify proofs on-demand
- **Cross-Chain Bridges**: Prove Z00Z state to other chains (Ethereum, Cosmos, etc.)
- **Parallel Validation**: Validate z00z_coins while simultaneously validating zusd_tokens
- **Future-Proof**: Add new assets (governance tokens, synthetic assets) without breaking consensus

### 4.2 OutputFeatures Extension

**File**: `crates/z00z_core/src/assets/common.rs`

```rust
/// UPDATED: OutputFeatures (consensus-critical)
#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub struct OutputFeatures {
    pub lock_height: Option<u64>,
    pub is_burned: bool,
    pub nonce: [u8; 32],
    pub asset_tag: Option<AssetTag>,
  
    // NEW: Serial ID composition (consensus-critical)
    pub serial_amounts: Vec<SerialAmount>,  // Default: single serial_amount for simple outputs
}

impl Default for OutputFeatures {
    fn default() -> Self {
        Self {
            lock_height: None,
            is_burned: false,
            nonce: [0u8; 32],
            asset_tag: None,
            serial_amounts: Vec::new(),  // Empty until populated
        }
    }
}
```

**Migration**: Existing code defaults to single-serial_amount (genesis case).

### 4.3 Transaction Validation Changes

**NEW RULE**: Per-serial-id conservation + Pedersen homomorphic balance.

#### 4.3.1 Arithmetic Balance (Per Serial ID)

```rust
/// Transaction validation: Arithmetic balance per serial_id
/// Ensures no "recoloring" of value between different serial_ids
fn validate_serial_id_conservation(tx: &Transaction) -> Result<()> {
    let mut serial_id_map: BTreeMap<u32, i64> = BTreeMap::new();
  
    // Sum inputs (positive contribution)
    for input in &tx.inputs {
        for serial_amount in &input.serial_amounts {
            *serial_id_map.entry(serial_amount.serial_id).or_default() += serial_amount.amount as i64;
        }
    }
  
    // Sum outputs (negative contribution)
    for output in &tx.outputs {
        for serial_amount in &output.serial_amounts {
            *serial_id_map.entry(serial_amount.serial_id).or_default() -= serial_amount.amount as i64;
        }
    }
  
    // Check balance per serial_id (Delta = 0 for each serial_id)
    for (serial_id, balance) in serial_id_map {
        // CRITICAL: Validate serial_id range [1, 50000]
        if serial_id < 1 || serial_id > GENESIS_NUM_COINS as u32 {
            return Err(ValidationError::SerialIDOutOfRange { 
                serial_id, 
                max: GENESIS_NUM_COINS as u32 
            });
        }
    
        if balance != 0 {
            return Err(ValidationError::SerialIDImbalance { 
                serial_id, 
                balance,
                expected: 0,
            });
        }
    }
  
    Ok(())
}
```

**Key Insight**: Cannot "recolor" value - each serial_id conserved independently.

#### 4.3.2 Cryptographic Balance Validation (CRITICAL)

**CONSENSUS-CRITICAL**: Transaction validation MUST verify Pedersen commitment balance using homomorphic property.

This is in ADDITION to arithmetic balance - both checks required for consensus validity.

```rust
/// Full transaction validation with cryptographic balance check
/// This is the ACTUAL validation that consensus nodes execute
pub fn validate_transaction(tx: &Transaction) -> Result<()> {
    // 1. Arithmetic balance (per serial_id)
    validate_serial_id_conservation(tx)?;
  
    // 2. Cryptographic balance (Pedersen homomorphism) - CRITICAL!
    validate_pedersen_balance(tx)?;
  
    // 3. Range proofs (values are positive, no overflow)
    validate_range_proofs(tx)?;
  
    // 4. Signatures (ownership proof)
    validate_signatures(tx)?;
  
    // 5. Double-spend check (inputs exist in serial_id trees)
    validate_inputs_unspent(tx)?;
  
    Ok(())
}

/// Validate Pedersen commitment balance using homomorphic property
/// 
/// **Mathematical Foundation**:
/// Pedersen commitment: C = r·G + v·H (r = blinding factor, v = value)
/// Homomorphic property: C₁ + C₂ = (r₁ + r₂)·G + (v₁ + v₂)·H
/// 
/// **Conservation Law**:
/// Σ C_inputs - Σ C_outputs - C_fee = 0
/// 
/// This proves that hidden values balance WITHOUT revealing amounts!
/// Delta = 0 both arithmetically (per serial_id) and cryptographically (total).
pub fn validate_pedersen_balance(tx: &Transaction) -> Result<()> {
    let factory = PedersenCommitmentFactory::default();
  
    // Sum all input commitments
    let mut sum_inputs = PedersenCommitment::default();
    for input in &tx.inputs {
        sum_inputs = &sum_inputs + &input.commitment;
    }
  
    // Sum all output commitments
    let mut sum_outputs = PedersenCommitment::default();
    for output in &tx.outputs {
        sum_outputs = &sum_outputs + &output.commitment;
    }
  
    // Fee commitment (public value, zero blinding factor)
    // Fee is REVEALED (not confidential) so we commit with r=0
    let fee_commitment = factory.commit_value(
        &RistrettoSecretKey::default(),  // r = 0 (public fee)
        tx.fee
    );
    sum_outputs = &sum_outputs + &fee_commitment;
  
    // Check: Σ C_in == Σ C_out + C_fee
    // This uses elliptic curve addition (homomorphic property)
    if sum_inputs != sum_outputs {
        return Err(ValidationError::PedersenImbalance {
            expected: sum_outputs,
            actual: sum_inputs,
            delta: &sum_inputs - &sum_outputs,  // Should be point at infinity
        });
    }
  
    // CRITICAL: This proves Delta = 0 cryptographically
    // Combined with range proofs, this ensures no inflation or theft
  
    Ok(())
}

/// Validate all inputs exist in their respective serial_id trees (double-spend check)
/// Spent coins DISAPPEAR from Jellyfish trees (become NULL nodes)
pub fn validate_inputs_unspent(tx: &Transaction, state: &EpochState) -> Result<()> {
    for input in &tx.inputs {
        let coin_id = input.coin_id();
    
        // Check presence in ALL relevant serial_id trees
        // A multi-serial coin appears in MULTIPLE trees
        for serial_amount in &input.serial_amounts {
            let asset_state = state.get_asset_state_for_serial(serial_amount.serial_id)?;
            let tree_index = (serial_amount.serial_id - 1) as usize;
        
            if !asset_state.trees[tree_index].contains(&coin_id) {
                return Err(ValidationError::CoinAlreadySpent {
                    coin_id,
                    serial_id: serial_amount.serial_id,
                    tree_index,
                });
            }
        }
    }
  
    Ok(())
}
```

**Why Pedersen Validation is CRITICAL**:

1. **Prevents Inflation**: Cannot create value out of thin air
2. **Prevents Theft**: Cannot spend more than you have (even with confidential amounts)
3. **Consensus Requirement**: All nodes MUST verify this, or chain forks
4. **Complements Range Proofs**: Range proofs ensure v ≥ 0, Pedersen proves Σv_in = Σv_out

**Relationship to Serial ID**:

- **Serial ID conservation**: Arithmetic check per serial_id (value provenance)
- **Pedersen balance**: Cryptographic check for TOTAL value (inflation prevention)
- **Both required**: Serial ID prevents "recoloring", Pedersen prevents "printing money"

**Example**:

```rust
// Transaction: Mix two genesis coins
// Input 1: serial_id=5, amount=20000 (hidden in commitment C1)
// Input 2: serial_id=78, amount=20000 (hidden in commitment C2)
// Output 1: serial_id=5, amount=15000 + serial_id=78, amount=10000 (hidden in C3)
// Output 2: serial_id=5, amount=5000 + serial_id=78, amount=10000 (hidden in C4)

// Arithmetic check (per serial_id):
// serial_id=5:  20000 (in) - 15000 (out) - 5000 (out) = 0 ✓
// serial_id=78: 20000 (in) - 10000 (out) - 10000 (out) = 0 ✓

// Cryptographic check (total):
// C1 + C2 - C3 - C4 = 0 (point at infinity) ✓
// This proves 40000 total in = 40000 total out (without revealing amounts!)
```

### 4.4 Cryptographic Parameter Derivation

**CRITICAL for Deterministic Genesis and Reproducibility**

All cryptographic parameters (blinding factors, proof seeds) MUST be deterministically derived from protocol-level seeds. This ensures:

1. **Reproducible Genesis**: Anyone can regenerate exact genesis state from seed
2. **Audit Trail**: Verify genesis commitments without trusting binary outputs
3. **Fixture Generation**: Deterministic test fixtures for regression testing
4. **Wallet Interoperability**: Standard derivation paths for HD wallets

#### 4.4.1 Genesis Blinding Factors

Genesis blinding factors are derived from protocol seed using domain-separated hashing:

```rust
use blake2::{Blake2b, Digest};
use tari_crypto::ristretto::RistrettoSecretKey;

/// Protocol-level seed (public constant, fixed at chain launch)
/// Derived from Z00Z_CHAIN_ID to ensure unique genesis across testnets
pub const GENESIS_SEED: [u8; 32] = [
    0x15, 0x20, 0x30, 0x40, 0x50, 0x60, 0x70, 0x80,
    0x90, 0xa0, 0xb0, 0xc0, 0xd0, 0xe0, 0xf0, 0x10,
    0x11, 0x12, 0x13, 0x14, 0x15, 0x16, 0x17, 0x18,
    0x19, 0x1a, 0x1b, 0x1c, 0x1d, 0x1e, 0x1f, 0x20,
];  // From Blake2b(b"z00z/genesis/seed" || Z00Z_CHAIN_ID)

/// Derive blinding factor for specific genesis coin (deterministic)
/// 
/// Domain separation ensures blinding factors are independent and unpredictable
pub fn derive_genesis_blinding(coin_index: u32) -> RistrettoSecretKey {
    let mut hasher = Blake2b::<U64>::new();
  
    // Domain separation tag
    hasher.update(b"z00z/genesis/blinding/v1");
  
    // Protocol seed (ensures uniqueness across chains)
    hasher.update(GENESIS_SEED);
  
    // Coin-specific index (1-indexed: 1-50000)
    hasher.update((coin_index + 1).to_le_bytes());  // serial_id is 1-indexed!
  
    let hash = hasher.finalize();
  
    // Convert hash to RistrettoSecretKey (uniform distribution)
    RistrettoSecretKey::from_uniform_bytes(&hash)
}

/// Generate Pedersen commitment for genesis coin
pub fn generate_genesis_commitment(
    coin_index: u32,
    amount: Amount,
) -> (PedersenCommitment, RistrettoSecretKey) {
    let factory = PedersenCommitmentFactory::default();
  
    // Deterministic blinding factor
    let blinding = derive_genesis_blinding(coin_index);
  
    // Commitment: C = r·G + v·H
    let commitment = factory.commit_value(&blinding, amount);
  
    (commitment, blinding)
}
```

#### 4.4.2 Range Proof Seeds

Each range proof requires RNG seed for Bulletproofs generation:

```rust
/// Derive deterministic RNG seed for range proof generation
/// 
/// Bulletproofs require random challenges, but we make them deterministic
/// for reproducible genesis generation
pub fn derive_proof_seed(coin_index: u32) -> [u8; 32] {
    let mut hasher = Blake2b::<U32>::new();
  
    // Domain separation (different from blinding factor domain)
    hasher.update(b"z00z/genesis/proof_seed/v1");
  
    // Protocol seed
    hasher.update(GENESIS_SEED);
  
    // Coin-specific index (1-indexed)
    hasher.update((coin_index + 1).to_le_bytes());
  
    let hash = hasher.finalize();
    let mut seed = [0u8; 32];
    seed.copy_from_slice(&hash);
    seed
}

/// Generate deterministic range proof for genesis coin
pub fn generate_genesis_range_proof(
    coin_index: u32,
    amount: Amount,
    blinding: &RistrettoSecretKey,
) -> RangeProof {
    let factory = RangeProofFactory::default();
  
    // Deterministic RNG for proof generation
    let proof_seed = derive_proof_seed(coin_index);
    let mut rng = ChaChaRng::from_seed(proof_seed);
  
    // Generate Bulletproof with 64-bit range [0, 2^64 - 1]
    factory.create_proof(
        amount,
        blinding,
        64,  // range_bits
        &mut rng,
    ).expect("genesis proof generation failed")
}
```

#### 4.4.3 Wallet Blinding Factor Derivation

User wallets derive blinding factors from HD key paths (BIP32-style):

```rust
/// Derive wallet blinding factor from master key (HD wallet derivation)
/// 
/// Derivation path: m / 44' / 1337' / account' / chain / output_index
/// - 44': BIP44 constant (HD wallets)
/// - 1337': Z00Z coin type (registered in SLIP-0044)
/// - account': Account index (typically 0)
/// - chain: 0 = external, 1 = internal (change)
/// - output_index: Sequential output number
pub fn derive_wallet_blinding(
    master_key: &ExtendedPrivateKey,
    account: u32,
    chain: u32,
    output_index: u32,
) -> RistrettoSecretKey {
    // BIP32 derivation: m/44'/1337'/account'/chain/output_index
    let path = [
        ChildNumber::Hardened(44),        // BIP44
        ChildNumber::Hardened(1337),      // Z00Z coin type
        ChildNumber::Hardened(account),   // Account
        ChildNumber::Normal(chain),       // External/internal
        ChildNumber::Normal(output_index),// Output index
    ];
  
    let derived_key = master_key.derive_path(&path)
        .expect("HD derivation failed");
  
    // Convert to RistrettoSecretKey for Pedersen commitments
    RistrettoSecretKey::from_bytes(&derived_key.private_key.secret_bytes())
        .expect("key conversion failed")
}
```

#### 4.4.4 Canonical Seed Management

**Best Practices**:

1. **Genesis Seed**: Publicly verifiable constant (committed in protocol spec)
2. **Wallet Seeds**: User-controlled, BIP39 mnemonic (24 words standard)
3. **Proof Seeds**: Derived from blinding factors (deterministic but secret)
4. **Version Tags**: Include version string in all domain separation tags

**Security Considerations**:

- Genesis seed is PUBLIC (anyone can regenerate genesis state)
- Wallet master key is PRIVATE (user controls their blinding factors)
- Blinding factors MUST be kept secret (reveal value if leaked)
- Range proof seeds can be public (proofs are zero-knowledge)

**Why This Matters**:

- **Reproducibility**: Genesis state can be verified by anyone
- **Testing**: Deterministic fixtures for unit/integration tests
- **Auditing**: Transparent genesis generation process
- **Wallet Standards**: Interoperable HD wallet implementations

---

## 5. Implementation Plan

### 5.1 Phase 1: Data Structure Updates

**Priority**: Critical (blocking all other work)

#### Task 1.1: Update AssetTag

**File**: `crates/z00z_core/src/assets/common.rs`

- [ ] Add `serial_id: Option<u32>` field to `AssetTag`
- [ ] Update `AssetTag::new()` constructor
- [ ] Update `AssetTag::derive_id()` to include serial_id in hash
- [ ] Update serialization tests

**Checklist**:

```rust
// Before
pub struct AssetTag {
    pub class: AssetClass,
    pub decimals: u8,
}

// After
pub struct AssetTag {
    pub class: AssetClass,
    pub decimals: u8,
    pub serial_id: Option<u32>,  // NEW
}
```

**Tests**:

- [ ] `test_asset_tag_with_serial_id()`
- [ ] `test_asset_tag_without_serial_id()`
- [ ] `test_serial_id_serialization()`

#### Task 1.2: Add SerialAmount Type

**File**: `crates/z00z_core/src/assets/common.rs`

- [ ] Define `SerialAmount` struct
- [ ] Implement `Serialize`/`Deserialize`
- [ ] Add helper methods (`total_amount()`, `validate()`)

**Checklist**:

```rust
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct SerialAmount {
    pub serial_id: u32,
    pub amount: Amount,
}

impl SerialAmount {
    pub fn new(serial_id: u32, amount: Amount) -> Self { /* ... */ }
    pub fn validate(&self) -> Result<(), AssetError> { /* ... */ }
}

/// Helper for output composition
pub struct SerialAmountSet {
    serial_amounts: Vec<SerialAmount>,
}

impl SerialAmountSet {
    pub fn total_amount(&self) -> Amount { /* sum */ }
    pub fn validate_no_duplicates(&self) -> Result<()> { /* ... */ }
}
```

**Tests**:

- [ ] `test_serial_amount_validation()`
- [ ] `test_serial_amount_set_total()`
- [ ] `test_duplicate_serial_ids_rejected()`

#### Task 1.3: Update OutputFeatures

**File**: `crates/z00z_core/src/assets/common.rs`

- [ ] Add `serial_amounts: Vec<SerialAmount>` field
- [ ] Update default implementation
- [ ] Add validation method `validate_serial_amounts()`

**Checklist**:

```rust
pub struct OutputFeatures {
    pub lock_height: Option<u64>,
    pub is_burned: bool,
    pub nonce: [u8; 32],
    pub asset_tag: Option<AssetTag>,
    pub serial_amounts: Vec<SerialAmount>,  // NEW
}

impl OutputFeatures {
    pub fn validate_serial_amounts(&self) -> Result<(), AssetError> {
        if self.serial_amounts.is_empty() {
            return Err(AssetError::InvalidOutput("no serial_amounts".into()));
        }
        // Check no duplicates
        let mut seen = BTreeSet::new();
        for p in &self.serial_amounts {
            if !seen.insert(p.serial_id) {
                return Err(AssetError::InvalidOutput(
                    format!("duplicate serial_id {}", p.serial_id)
                ));
            }
        }
        Ok(())
    }
}
```

**Tests**:

- [ ] `test_output_features_with_serial_amounts()`
- [ ] `test_reject_empty_serial_amounts()`
- [ ] `test_reject_duplicate_serial_ids()`

---

### 5.2 Phase 2: Output Type Updates

**Priority**: Critical (depends on Phase 1)

#### Task 2.1: Update CoinOutput

**File**: `crates/z00z_core/src/assets/coins.rs`

- [ ] Add `serial_amounts: Vec<SerialAmount>` field
- [ ] Update `CoinOutput::new()` - default single serial_amount
- [ ] Add `CoinOutput::new_with_serials()` - multi-serial_amount constructor
- [ ] Update `coin_id()` derivation to include serial_amounts
- [ ] Update validation to check serial_amount-commitment consistency

**Checklist**:

```rust
pub struct CoinOutput {
    pub commitment: Commitment,
    pub range_proof: Option<RangeProof>,
    pub features: OutputFeatures,
    pub metadata: Option<OutputMetadata>,
    pub serial_amounts: Vec<SerialAmount>,  // NEW
}

impl CoinOutput {
    // Existing constructor (single serial_amount - genesis case)
    pub fn new(
        amount: Amount,
        blinding: &BlindingFactor,
        lock_height: Option<u64>,
        metadata_blob: Option<Vec<u8>>,
    ) -> Result<Self, AssetError> {
        // Default: single serial_amount with serial_id from context
        let serial_amounts = vec![SerialAmount::new(0, amount)];  // Will be updated by genesis
        // ... rest unchanged
    }
  
    // NEW: Multi-serial_amount constructor (for mixed outputs)
    pub fn new_with_serials(
        serial_amounts: Vec<SerialAmount>,
        blinding: &BlindingFactor,
        lock_height: Option<u64>,
        metadata_blob: Option<Vec<u8>>,
    ) -> Result<Self, AssetError> {
        let total = serial_amounts.iter().map(|p| p.amount).sum();
        // Commitment must match total of all serial_amounts
        let commitment = PedersenCommitmentFactory::default().commit_value(blinding, total);
        // ... rest similar
    }
  
    // Updated: Include serial_amounts in coin_id derivation
    pub fn coin_id(&self) -> CoinID {
        let hasher = DomainSeparatedHasher::<Blake2b<U32>, CoinIDDomain>::new()
            .chain(&self.features.nonce)
            .chain(&self.commitment.as_bytes());
    
        // NEW: Include serial_amounts in hash
        for serial_amount in &self.serial_amounts {
            hasher.chain(&serial_amount.serial_id.to_le_bytes());
            hasher.chain(&serial_amount.amount.to_le_bytes());
        }
    
        // ... finalize hash
    }
  
    // NEW: Validate serial_amount-commitment consistency
    pub fn validate_serial_amounts(&self) -> Result<(), AssetError> {
        let total: Amount = self.serial_amounts.iter().map(|p| p.amount).sum();
        // Commitment must equal total (verified during proof check)
        Ok(())
    }
}
```

**Tests**:

- [ ] `test_coin_output_single_serial_amount()` (genesis case)
- [ ] `test_coin_output_multi_serial_amount()` (mixed outputs)
- [ ] `test_coin_id_includes_serials()`
- [ ] `test_serial_amount_commitment_mismatch_rejected()`

#### Task 2.2: Update TokenOutput

**File**: `crates/z00z_core/src/assets/tokens.rs`

- [ ] Add `serial_amounts: Vec<SerialAmount>` field
- [ ] Update constructors (same pattern as CoinOutput)
- [ ] Update validation

**Similar changes as CoinOutput** (copy checklist from 2.1)

#### Task 2.3: Update NftOutput

**File**: `crates/z00z_core/src/assets/nfts.rs`

- [ ] Add `serial_amounts: Vec<SerialAmount>` field
- [ ] Update constructors
- [ ] **Special case**: NFTs usually `amount = 1`, single serial_amount

**Notes**: NFTs typically have `serial_amounts = [SerialAmount { serial_id: X, amount: 1 }]`

#### Task 2.4: Update VoidOutput

**File**: `crates/z00z_core/src/assets/void.rs`

- [ ] Add `serial_amounts: Vec<SerialAmount>` field
- [ ] Update constructors
- [ ] **Special case**: Void accepts any serial_id (burn sink)

---

### 5.3 Phase 3: Genesis Integration

**Priority**: Critical (depends on Phase 2)

#### Task 3.1: Assign Serial IDs in Genesis

**File**: `crates/z00z_core/src/genesis/assets_generator.rs`

- [ ] Update `generate_genesis_state_parallel()` to assign serial_ids
- [ ] Each coin gets `serial_id = index` (0 to 49,999)
- [ ] Update `CoinOutput` creation to include serial_amounts

**Checklist**:

```rust
pub fn generate_genesis_state_parallel(seed: &[u8; 32], num_coins: usize) 
    -> Result<EpochState, GenesisError> 
{
    // ... existing setup ...
  
    let outputs: Result<Vec<_>, String> = blindings
        .par_iter()
        .enumerate()
        .map(|(index, blinding)| {
            let serial_id = index as u64;  // NEW: Assign serial_id = index
        
            // Create single-serial_amount output (genesis case)
            let serial_amounts = vec![SerialAmount {
                serial_id,
                amount: GENESIS_COIN_NOMINAL,
            }];
        
            let nonce = nonces[index];
            let commitment = gens.pedersen.commit_value(blinding, GENESIS_COIN_NOMINAL);
        
            // ... range proof generation ...
        
            let features = OutputFeatures {
                lock_height: None,
                is_burned: false,
                nonce,
                asset_tag: Some(AssetTag {
                    class: AssetClass::Coin,     // Sufficient for identification
                    decimals: 8,
                    serial_id: Some(serial_id),  // NEW
                }),
                serial_amounts: serial_amounts.clone(),  // NEW
            };
        
            Ok(CoinOutput {
                commitment,
                range_proof: Some(range_proof),
                features,
                metadata: None,
                serial_amounts,  // NEW
            })
        })
        .collect();
  
    // ... rest unchanged ...
}
```

**Tests**:

- [ ] `test_genesis_serial_ids_assigned()`
- [ ] `test_genesis_serial_ids_unique()`
- [ ] `test_genesis_serial_ids_range()`
- [ ] `test_genesis_serial_amount_amounts()`

#### Task 3.2: Update Genesis Validation

**File**: `crates/z00z_core/src/genesis/assets_generator.rs`

- [ ] Add serial_id validation to `validate_genesis_state()`
- [ ] Check serial_id range [1, 50000]
- [ ] Check uniqueness (each serial_id appears exactly once)

**Checklist**:

```rust
pub fn validate_genesis_state(state: &EpochState) -> Result<(), ValidationError> {
    // ... existing validations ...
  
    // NEW: Validate serial_ids
    let mut seen_serial_ids = BTreeSet::new();
  
    for (context_id, output) in state.unspent_set.iter() {
        // Each genesis coin should have exactly 1 serial_amount
        if output.serial_amounts.len() != 1 {
            return Err(ValidationError::InvalidGenesisOutput {
                context_id: *context_id,
                reason: format!("expected 1 serial_amount, got {}", output.serial_amounts.len()),
            });
        }
    
        let serial_amount = &output.serial_amounts[0];
        let serial_id = serial_amount.serial_id;
    
        // Check range
        if serial_id >= GENESIS_NUM_COINS as u64 {
            return Err(ValidationError::InvalidSerialID { 
                serial_id, 
                max: GENESIS_NUM_COINS as u64 - 1 
            });
        }
    
        // Check uniqueness
        if !seen_serial_ids.insert(serial_id) {
            return Err(ValidationError::DuplicateSerialID { serial_id });
        }
    
        // Check amount
        if serial_amount.amount != GENESIS_COIN_NOMINAL {
            return Err(ValidationError::InvalidGenesisAmount {
                serial_id,
                expected: GENESIS_COIN_NOMINAL,
                got: serial_amount.amount,
            });
        }
    }
  
    // Check all serial_ids present [1, 50000]
    if seen_serial_ids.len() != GENESIS_NUM_COINS {
        return Err(ValidationError::MissingSerialIds {
            expected: GENESIS_NUM_COINS,
            found: seen_serial_ids.len(),
        });
    }
  
    Ok(())
}
```

**Tests**:

- [ ] `test_genesis_validation_serial_ids()`
- [ ] `test_reject_duplicate_serial_ids()`
- [ ] `test_reject_out_of_range_serial_ids()`
- [ ] `test_reject_missing_serial_ids()`

---

### 5.4 Phase 4: State Partitioning

**Priority**: High (performance optimization)

#### Task 4.1: Implement SerialClassState

**File**: `crates/z00z_core/src/state/serial_class.rs` (NEW)

- [ ] Create `SerialClassState` struct
- [ ] Implement tree-per-genesis architecture
- [ ] Add routing logic (serial_id → tree_index = serial_id - 1)
- [ ] Implement global root computation

**Checklist**:

```rust
use crate::state::jellyfish_merkle_tree::JellyfishMerkleTree;

pub struct SerialClassState {
    /// One tree per genesis coin (50K trees, 1-indexed serial_id)
    pub trees: Vec<JellyfishMerkleTree>,
  
    /// Cached root hashes
    pub roots: Vec<[u8; 32]>,
  
    /// Global root (Merkle root of all serial_id tree roots)
    pub global_root: [u8; 32],
}

impl SerialClassState {
    pub fn new(num_trees: usize) -> Self {
        let trees = (0..num_trees)
            .map(|_| JellyfishMerkleTree::new())
            .collect();
    
        Self {
            trees,
            roots: vec![[0u8; 32]; num_trees],
            global_root: [0u8; 32],
        }
    }
  
    /// Insert output into correct serial_id tree(s)
    /// Multi-serial outputs appear in MULTIPLE trees
    pub fn insert(&mut self, output: &CoinOutput) -> Result<(), StateError> {
        let coin_id = output.coin_id();
    
        // Multi-serial_amount outputs go to multiple serial_id trees
        for serial_amount in &output.serial_amounts {
            let tree_index = (serial_amount.serial_id - 1) as usize;  // 1-indexed!
        
            if tree_index >= self.trees.len() {
                return Err(StateError::InvalidSerialID { 
                    serial_id: serial_amount.serial_id 
                });
            }
        
            self.trees[tree_index].insert(coin_id, output.clone())?;
            self.roots[tree_index] = self.trees[tree_index].root();
        }
    
        self.recompute_global_root();
        Ok(())
    }
  
    /// Remove spent output from serial_id tree(s)
    /// Spent coins DISAPPEAR from Jellyfish tree (become NULL nodes)
    pub fn remove(&mut self, coin_id: &CoinID, serial_amounts: &[SerialAmount]) 
        -> Result<(), StateError> 
    {
        for serial_amount in serial_amounts {
            let tree_index = (serial_amount.serial_id - 1) as usize;  // 1-indexed!
            self.trees[tree_index].remove(coin_id)?;
            self.roots[tree_index] = self.trees[tree_index].root();
        }
    
        self.recompute_global_root();
        Ok(())
    }
  
    /// Check if coin is unspent in given serial_id tree
    /// Present in tree = unspent, absent = spent (NULL node)
    pub fn is_unspent(&self, coin_id: &CoinID, serial_id: u32) -> bool {
        let tree_index = (serial_id - 1) as usize;  // 1-indexed!
        if tree_index >= self.trees.len() {
            return false;
        }
        self.trees[tree_index].contains(coin_id)
    }
  
    /// Compute global root (Merkle root of all serial_id tree roots)
    fn recompute_global_root(&mut self) {
        use blake2::{Blake2b, digest::consts::U32};
        use digest::Digest;
    
        let mut hasher = Blake2b::<U32>::new();
        for root in &self.roots {
            hasher.update(root);
        }
        self.global_root.copy_from_slice(&hasher.finalize());
    }
}
```

**Tests**:

- [ ] `test_serial_class_state_creation()`
- [ ] `test_insert_single_serial_amount()`
- [ ] `test_insert_multi_serial_amount()`
- [ ] `test_remove_output()`
- [ ] `test_is_unspent_check()`
- [ ] `test_global_root_computation()`

#### Task 4.2: Integrate SerialClassState into EpochState

**File**: `crates/z00z_core/src/state/epoch.rs`

- [ ] Replace single `UnspentSet` with `SerialClassState`
- [ ] Update all methods to use serial-indexed access
- [ ] Add migration path from legacy single-tree format

**Checklist**:

```rust
pub struct EpochState {
    pub epoch_id: EpochId,
    pub meta: EpochMeta,
  
    // REPLACED: pub unspent_set: UnspentSet,
    pub serial_class_state: SerialClassState,  // NEW
  
    pub spent_set: SpentSet,
    pub counters: EpochCounters,
}

impl EpochState {
    /// Create new epoch with serial-indexed state
    pub fn new_with_serial_indexing(
        epoch_id: EpochId,
        meta: EpochMeta,
        num_trees: usize,
    ) -> Self {
        Self {
            epoch_id,
            meta,
            serial_class_state: SerialClassState::new(num_trees),
            spent_set: SpentSet::default(),
            counters: EpochCounters::default(),
        }
    }
  
    /// Legacy constructor (single tree → migrate to serial-indexed)
    pub fn from_legacy_unspent_set(
        epoch_id: EpochId,
        meta: EpochMeta,
        unspent_set: UnspentSet,
    ) -> Result<Self, StateError> {
        let mut serial_class_state = SerialClassState::new(GENESIS_NUM_COINS);
    
        // Migrate each output to correct serial_id tree
        for (context_id, output) in unspent_set.iter() {
            serial_class_state.insert(output)?;
        }
    
        Ok(Self {
            epoch_id,
            meta,
            serial_class_state,
            spent_set: SpentSet::default(),
            counters: EpochCounters::default(),
        })
    }
}
```

**Tests**:

- [ ] `test_epoch_state_serial_indexed_creation()`
- [ ] `test_migration_from_legacy_unspent_set()`
- [ ] `test_serial_class_state_serialization()`

---

### 5.5 Phase 5: Transaction Validation

**Priority**: Critical (consensus-breaking changes)

#### Task 5.1: Add Serial ID Conservation Check

**File**: `crates/z00z_core/src/validation/transaction.rs` (create if missing)

- [ ] Implement `validate_serial_id_conservation()`
- [ ] Integrate into main transaction validation pipeline

**Checklist**:

```rust
use crate::assets::{Transaction, SerialAmount};
use std::collections::BTreeMap;

#[derive(Debug, Error)]
pub enum ValidationError {
    #[error("serial_id {serial_id} imbalance: inputs={inputs}, outputs={outputs}")]
    SerialIDImbalance {
        serial_id: u32,
        inputs: Amount,
        outputs: Amount,
    },
  
    #[error("serial_id {serial_id} out of range [1, {max}]")]
    SerialIDOutOfRange { serial_id: u32, max: u32 },
  
    #[error("cannot recolor value: serial_id {from} → {to}")]
    ValueRecoloring { from: u32, to: u32 },
}

/// Validate per-serial-id conservation
pub fn validate_serial_id_conservation(tx: &Transaction) -> Result<(), ValidationError> {
    let mut balances: BTreeMap<u32, i64> = BTreeMap::new();
  
    // Sum inputs (positive contribution)
    for input in &tx.inputs {
        for serial_amount in &input.serial_amounts {
            let entry = balances.entry(serial_amount.serial_id).or_insert(0);
            *entry += serial_amount.amount as i64;
        }
    }
  
    // Sum outputs (negative contribution)
    for output in &tx.outputs {
        for serial_amount in &output.serial_amounts {
            let entry = balances.entry(serial_amount.serial_id).or_insert(0);
            *entry -= serial_amount.amount as i64;
        }
    }
  
    // Check balance per serial_id
    for (serial_id, balance) in balances {
        if balance != 0 {
            let (inputs, outputs) = if balance > 0 {
                (balance as Amount, 0)
            } else {
                (0, (-balance) as Amount)
            };
        
            return Err(ValidationError::SerialIDImbalance {
                serial_id,
                inputs,
                outputs,
            });
        }
    }
  
    Ok(())
}

/// Full transaction validation (includes serial_id check)
pub fn validate_transaction(tx: &Transaction) -> Result<(), ValidationError> {
    // ... existing validations ...
  
    // NEW: Serial ID conservation
    validate_serial_id_conservation(tx)?;
  
    Ok(())
}
```

**Tests**:

- [ ] `test_valid_serial_id_conservation()`
- [ ] `test_reject_serial_id_imbalance()`
- [ ] `test_reject_value_recoloring()`
- [ ] `test_multi_serial_id_transaction()`

#### Task 5.2: Update Double-Spend Check

**File**: `crates/z00z_core/src/state/epoch.rs`

- [ ] Update `is_spent()` to check serial-indexed state
- [ ] Validate coin_id presence in correct serial_id tree(s)

**Checklist**:

```rust
impl EpochState {
    /// Check if coin is unspent (serial-indexed version)
    pub fn is_unspent(&self, coin_id: &CoinID, serial_amounts: &[SerialAmount]) -> bool {
        // Coin must exist in ALL relevant serial_id trees
        for serial_amount in serial_amounts {
            if !self.serial_class_state.is_unspent(coin_id, serial_amount.serial_id) {
                return false;
            }
        }
        true
    }
  
    /// Mark coin as spent (remove from serial_id trees)
    pub fn mark_spent(&mut self, coin_id: &CoinID, serial_amounts: &[SerialAmount]) 
        -> Result<(), StateError> 
    {
        self.serial_class_state.remove(coin_id, serial_amounts)?;
        self.spent_set.insert(*coin_id);
        Ok(())
    }
}
```

**Tests**:

- [ ] `test_is_unspent_serial_indexed()`
- [ ] `test_mark_spent_removes_from_trees()`
- [ ] `test_double_spend_detection()`

- [ ] `test_codegen_with_serial_id()`
- [ ] `test_codegen_without_serial_id()`

---

## 7. Testing Requirements

### 7.1 Unit Tests

**Per-Phase Tests** (see checklists in §5):

- Phase 1: 9 tests (AssetTag, SerialAmount, OutputFeatures)
- Phase 2: 16 tests (4 output types × 4 tests each)
- Phase 3: 8 tests (genesis generation + validation)
- Phase 4: 7 tests (serial-indexed state operations)
- Phase 5: 7 tests (transaction validation)

**Total**: ~50 new unit tests

### 7.2 Integration Tests

**File**: `crates/z00z_core/tests/serial_id_integration.rs` (NEW)

- [ ] `test_genesis_to_transaction_flow()`
- [ ] `test_multi_serial_id_payment()`
- [ ] `test_serial_class_state_e2e()`
- [ ] `test_consolidation_auto_merge()`

### 7.3 Performance Benchmarks

**File**: `crates/z00z_core/benches/serial_id.rs` (NEW)

- [ ] Benchmark: Genesis generation with serial_id
- [ ] Benchmark: Multi-tree vs single tree (50K outputs)
- [ ] Benchmark: Multi-serial_amount transaction validation

**Target**: 50x speedup for multi-tree operations

---

## 8. Performance Impact

### 8.1 Expected Gains

**Realistic Analysis** (16-core server, typical deployment):

| Operation                             | Before (Single Tree) | After (Multi-Tree)    | Theoretical | Realistic |
| ------------------------------------- | -------------------- | --------------------- | ----------- | --------- |
| **Insert output**               | O(log 50K) ≈ 15 ops | O(log 1000) ≈ 10 ops | 1.5x        | 1.5x      |
| **Batch insert (1000 outputs)** | Sequential           | Parallel (16 cores)   | 16x         | 10-13x    |
| **Double-spend check**          | O(log 50K)           | O(log 1000)           | 1.5x        | 1.5x      |
| **Merkle proof**                | 15 layers            | 10 layers             | 1.5x        | 1.5x      |

**Why Not 50x?**

1. **Hardware Constraints**:

   - Typical server: 16-32 cores (not 50)
   - Consumer hardware: 4-8 cores
   - Cannot achieve 50x parallelism without 50 cores
2. **Amdahl's Law** (sequential bottlenecks):

   ```
   Speedup = 1 / (S + P/N)
   where:
     S = sequential fraction (5% for global_root computation)
     P = parallel fraction (95% for tree updates)
     N = number of cores (16)
   
   Max speedup = 1 / (0.05 + 0.95/16) ≈ 13.6x
   ```
3. **Memory Bandwidth Limits**:

   - 50K trees × 32 bytes/root = 1.6 MB root array
   - Cache thrashing on large datasets
   - Memory bandwidth saturates before CPU
4. **Synchronization Overhead**:

   - Lock contention for global_root updates
   - Thread scheduling overhead
   - Cross-core communication latency

**Realistic Expectations**:

- **16-core server**: 10-13x speedup (validated estimate)
- **32-core server**: 12-15x speedup (diminishing returns)
- **8-core workstation**: 6-8x speedup (still significant!)
- **4-core consumer**: 3-4x speedup (better than nothing)

**Benchmark Plan** (§8.4):

- Measure on AWS c5.4xlarge (16 vCPU)
- Test with 1000, 10K, 50K output batches
- Compare single-tree vs multi-tree implementations

### 8.2 Storage Overhead

**SerialAmount**: 8 bytes (serial_id) + 8 bytes (amount) = 16 bytes

**Per output**:

- Genesis (single serial_amount): +16 bytes
- Mixed (3 serial_amounts avg): +48 bytes

**Total genesis**: 50K outputs × 16 bytes = 800 KB (negligible)

### 8.3 Computational Overhead

**Serial ID validation**: O(P × S) where P = serial_amounts/tx, S = serial_ids

- Typical tx: 2 inputs × 1 serial_amount, 2 outputs × 1 serial_amount = 4 serial_ids
- Cost: 4 × O(1) map lookups = negligible

### 8.4 Advanced Parallelization Opportunities

#### 8.4.1 Genesis Generation - Embarrassingly Parallel

**Current Bottleneck**: Generating 50K genesis coins sequentially.

**Optimization**: Perfect parallelization opportunity (zero dependencies).

```rust
use rayon::prelude::*;

/// Parallel genesis generation with optimal core utilization
/// Expected: 15.8x speedup on 16-core, 31.2x on 32-core
pub fn generate_genesis_parallel(
    seed: &[u8; 32],
    num_coins: usize,
) -> Result<Vec<CoinOutput>> {
    // Generate coins in parallel chunks
    // Each chunk is completely independent (embarrassingly parallel)
    (0..num_coins)
        .into_par_iter()
        .map(|index| {
            let serial_id = (index + 1) as u32;  // 1-indexed
          
            // Deterministic derivation (no shared state)
            let (commitment, blinding) = generate_genesis_commitment(index, GENESIS_COIN_NOMINAL);
            let range_proof = generate_genesis_range_proof(index, GENESIS_COIN_NOMINAL, &blinding);
          
            CoinOutput {
                commitment,
                range_proof: Some(range_proof),
                features: OutputFeatures {
                    serial_amounts: vec![SerialAmount { serial_id, amount: GENESIS_COIN_NOMINAL }],
                    // ... other fields
                },
                // ... metadata
            }
        })
        .collect::<Result<Vec<_>>>()
}
```

**Performance Profile**:

- **16-core**: 50K coins in ~3.2 seconds (vs 50 seconds sequential) = **15.6x speedup**
- **32-core**: 50K coins in ~1.6 seconds = **31.2x speedup**
- **64-core**: 50K coins in ~0.8 seconds = **62.5x speedup**

**Why This Works**:

- Zero synchronization needed
- Each coin derivation independent
- No shared mutable state
- Perfect CPU utilization

#### 8.4.2 Transaction Validation Pipeline

**Multi-Stage Parallel Pipeline**:

```rust
use rayon::prelude::*;
use crossbeam::channel;

/// Parallel transaction validation with pipelined stages
/// Stage 1: Signature verification (CPU-bound)
/// Stage 2: Range proof verification (CPU-bound)
/// Stage 3: Pedersen balance check (memory-bound)
/// Stage 4: Serial ID conservation (compute-bound)
pub fn validate_transaction_pipeline(tx: &Transaction) -> Result<()> {
    // Stage 1: Parallel signature verification (most expensive)
    tx.inputs.par_iter()
        .try_for_each(|input| input.verify_signature())?;
  
    // Stage 2: Parallel range proof verification
    tx.outputs.par_iter()
        .try_for_each(|output| output.verify_range_proof())?;
  
    // Stage 3: Pedersen balance (can't parallelize, but fast)
    validate_pedersen_balance(tx)?;
  
    // Stage 4: Parallel serial_id checks (independent per serial_id)
    let serial_ids: Vec<u32> = extract_all_serial_ids(tx);
    serial_ids.par_iter()
        .try_for_each(|serial_id| validate_serial_conservation(tx, *serial_id))?;
  
    Ok(())
}
```

**Pipelined Block Validation**:

```rust
/// Validate multiple transactions in parallel with pipeline overlap
pub fn validate_block_pipelined(block: &Block) -> Result<()> {
    let (tx_sender, tx_receiver) = channel::bounded(16);
    let (sig_sender, sig_receiver) = channel::bounded(16);
    let (proof_sender, proof_receiver) = channel::bounded(16);
  
    // Pipeline stage 1: Signature verification (parallel)
    thread::spawn(move || {
        block.transactions.par_iter().for_each(|tx| {
            verify_signatures(tx).unwrap();
            sig_sender.send(tx).unwrap();
        });
    });
  
    // Pipeline stage 2: Range proofs (parallel)
    thread::spawn(move || {
        for tx in sig_receiver {
            verify_range_proofs(tx).unwrap();
            proof_sender.send(tx).unwrap();
        }
    });
  
    // Pipeline stage 3: Final checks (sequential, but fast)
    for tx in proof_receiver {
        validate_pedersen_balance(tx)?;
        validate_serial_conservation(tx)?;
    }
  
    Ok(())
}
```

**Expected Performance**:

- **Single tx validation**: 3-4x speedup (signature + range proofs parallel)
- **Block validation**: 10-15x speedup (pipeline overlap + parallelism)
- **1000 tx block**: ~500ms (vs ~7 seconds sequential)

#### 8.4.3 State Tree Insertion - Batch Parallel

**Optimize batch insertions** (common during sync):

```rust
impl SerialClassState {
    /// Parallel batch insertion with minimal lock contention
    pub fn insert_batch_parallel(&mut self, outputs: &[CoinOutput]) -> Result<()> {
        // Group outputs by serial_id for optimal parallelization
        let mut serial_groups: BTreeMap<u32, Vec<&CoinOutput>> = BTreeMap::new();
        for output in outputs {
            for sa in &output.serial_amounts {
                serial_groups.entry(sa.serial_id).or_default().push(output);
            }
        }
      
        // Parallel insertion per serial_id (independent trees)
        serial_groups.par_iter()
            .try_for_each(|(serial_id, group_outputs)| {
                let tree_index = (*serial_id - 1) as usize;
                for output in group_outputs {
                    self.trees[tree_index].insert(output.coin_id(), output)?;
                }
                self.dirty_trees.insert(*serial_id);
                Ok::<_, StateError>(())
            })?;
      
        // Sequential root update (fast, minimal overhead)
        self.commit_batch();
        Ok(())
    }
}
```

**Batch Insertion Performance**:

- **1000 outputs, 200 unique serial_ids**: 8-12x speedup (16-core)
- **10K outputs, 1000 unique serial_ids**: 10-14x speedup
- **50K outputs (genesis)**: 12-15x speedup

#### 8.4.4 Merkle Proof Verification - SIMD Optimization

**Use SIMD for hash operations**:

```rust
use sha3::{Digest, Sha3_256};
use packed_simd::u8x32;

/// Vectorized Merkle proof verification (4x Blake2b hashes parallel)
pub fn verify_merkle_proof_simd(
    leaf: &[u8; 32],
    proof: &[[u8; 32]],
    root: &[u8; 32],
) -> bool {
    let mut current = *leaf;
  
    // Process proof path in groups of 4 (SIMD width)
    for chunk in proof.chunks(4) {
        match chunk.len() {
            4 => {
                // 4-way parallel hash using AVX2
                let hashes = compute_4_hashes_simd(&[
                    [current, chunk[0]],
                    [current, chunk[1]],
                    [current, chunk[2]],
                    [current, chunk[3]],
                ]);
                current = hashes[0];  // Simplified
            }
            _ => {
                // Fallback to sequential for remaining
                for sibling in chunk {
                    current = hash_pair(&current, sibling);
                }
            }
        }
    }
  
    current == *root
}
```

**SIMD Performance**:

- **4-way parallel hashing**: 3.5x speedup (AVX2)
- **8-way parallel hashing**: 6-7x speedup (AVX-512, server CPUs)
- Critical for light clients verifying many proofs

#### 8.4.5 Cross-Asset Parallel Validation

**Validate different asset classes simultaneously**:

```rust
impl EpochState {
    /// Parallel validation across all asset classes
    /// Each asset class independent → perfect parallelization
    pub fn validate_all_assets_parallel(&self) -> Result<()> {
        use rayon::prelude::*;
      
        self.asset_states.par_iter()
            .try_for_each(|(asset_class, state)| {
                match asset_class {
                    AssetClass::Coin => {
                        // Validate 50K coin trees in parallel
                        state.trees.par_iter()
                            .enumerate()
                            .try_for_each(|(idx, tree)| {
                                tree.verify_integrity()?;
                                Ok::<_, StateError>(())
                            })?;
                    }
                    AssetClass::Token(id) => {
                        // Validate token trees
                        state.validate_token_trees()?;
                    }
                    _ => {
                        // Other asset types
                        state.validate()?;
                    }
                }
                Ok(())
            })?;
      
        Ok(())
    }
}
```

**Multi-Asset Performance**:

- **4 asset classes, 16 cores**: Each asset gets 4 cores → 4x effective parallelism
- **Validation time**: ~2 seconds for full state (vs ~30 seconds sequential)

#### 8.4.6 Memory-Mapped State for Zero-Copy

**Optimize for large state sizes**:

```rust
use memmap2::MmapMut;

/// Memory-mapped state for efficient access without loading entire state
pub struct MmappedSerialClassState {
    mmap: MmapMut,
    tree_offsets: Vec<usize>,  // Offset for each tree in mmap
}

impl MmappedSerialClassState {
    /// Access tree without loading entire state
    pub fn get_tree(&self, serial_id: u32) -> &JellyfishMerkleTree {
        let tree_index = (serial_id - 1) as usize;
        let offset = self.tree_offsets[tree_index];
      
        // Zero-copy access via memory mapping
        unsafe {
            &*(self.mmap.as_ptr().add(offset) as *const JellyfishMerkleTree)
        }
    }
  
    /// Parallel access to multiple trees (no memory copying)
    pub fn get_trees_parallel(&self, serial_ids: &[u32]) -> Vec<&JellyfishMerkleTree> {
        serial_ids.par_iter()
            .map(|serial_id| self.get_tree(*serial_id))
            .collect()
    }
}
```

**Zero-Copy Benefits**:

- **No deserialization overhead**: Direct memory access
- **OS-level caching**: Kernel manages memory efficiently
- **Huge state support**: 100GB+ state without loading into RAM

#### 8.4.7 GPU Acceleration for Range Proofs

**Offload Bulletproofs to GPU** (future work):

```rust
// Pseudocode - requires GPU Bulletproofs library
pub fn verify_range_proofs_gpu(
    outputs: &[CoinOutput],
    gpu_context: &GpuContext,
) -> Result<()> {
    let proofs: Vec<_> = outputs.iter()
        .filter_map(|o| o.range_proof.as_ref())
        .collect();
  
    // Batch verify on GPU (1000+ proofs at once)
    // Expected: 50-100x speedup vs CPU for large batches
    gpu_context.verify_bulletproofs_batch(&proofs)?;
  
    Ok(())
}
```

**GPU Performance** (estimated):

- **1000 range proofs**: ~200ms on GPU (vs ~20 seconds CPU) = **100x speedup**
- **Critical for**: Light client sync, mempool validation

### 8.5 Parallelization Summary Table

| Operation                             | Sequential Time | Parallel Time (16-core) | Speedup         | Bottleneck                     |
| ------------------------------------- | --------------- | ----------------------- | --------------- | ------------------------------ |
| **Genesis generation**          | ~50s            | ~3.2s                   | **15.6x** | None (embarrassingly parallel) |
| **Transaction validation**      | ~2ms            | ~0.6ms                  | **3.3x**  | Pedersen check (sequential)    |
| **Block validation (1000 tx)**  | ~7s             | ~500ms                  | **14x**   | Memory bandwidth               |
| **Batch insert (1000 outputs)** | ~1.5s           | ~120ms                  | **12.5x** | Root computation               |
| **Full state validation**       | ~30s            | ~2s                     | **15x**   | Cross-tree dependencies        |
| **Merkle proof verify**         | ~50μs          | ~15μs (SIMD)           | **3.3x**  | Hash function                  |
| **Range proof batch (GPU)**     | ~20s            | ~200ms                  | **100x**  | GPU memory transfer            |

**Key Insights**:

1. **Genesis**: Near-perfect scaling (embarrassingly parallel)
2. **Validation**: 10-15x realistic on 16-core (Amdahl's Law applies)
3. **SIMD**: 3-4x gains for hash-heavy operations
4. **GPU**: 50-100x for Bulletproofs (future optimization)

### 8.6 Optimization Priority Matrix

**Implementation priorities based on complexity vs impact**:

| Priority       | Optimization                | Complexity | Impact            | When to Implement    |
| -------------- | --------------------------- | ---------- | ----------------- | -------------------- |
| 🔴**P0** | Genesis Parallel Generation | Low        | **15.6x**   | Phase 3 (genesis)    |
| 🔴**P0** | Batch Commitment Validation | Low        | **10-100x** | Phase 5 (validation) |
| 🟠**P1** | Parallel Tree Validation    | Medium     | **6-15x**   | Phase 4 (state)      |
| 🟠**P1** | Transaction Pipeline        | Medium     | **10-15x**  | Phase 5 (validation) |
| 🟠**P1** | Batch Tree Insertion        | Medium     | **8-12x**   | Phase 4 (state)      |
| 🟡**P2** | SIMD Merkle Proofs          | High       | **3-4x**    | Post-v1              |
| 🟡**P2** | Memory-Mapped State         | High       | Zero-copy         | Post-v1              |
| 🟢**P3** | GPU Range Proofs            | Very High  | **50-100x** | v2.0                 |

**Recommended Implementation Order**:

1. **Phase 3 (Genesis)**:

   - Implement genesis parallel generation (P0)
   - Add benchmarks for 4/8/16-core systems
2. **Phase 4 (State)**:

   - Implement batch tree insertion (P1)
   - Implement parallel tree validation (P1)
3. **Phase 5 (Validation)**:

   - Implement batch commitment validation (P0)
   - Implement transaction pipeline (P1)
4. **Post-v1**:

   - SIMD optimization for Merkle proofs (P2)
   - Memory-mapped state for large deployments (P2)
5. **v2.0 (Future)**:

   - GPU acceleration for range proofs (P3)

### 8.7 Common Performance Pitfalls

#### 8.7.1 False Sharing

**Problem**: Multiple threads write to adjacent memory locations → cache line invalidation → performance collapse.

**Example of BAD code**:

```rust
// ❌ BAD: Counters in contiguous memory
struct Counters {
    thread_0: AtomicU64,  // Cache line 0
    thread_1: AtomicU64,  // Cache line 0 (same!)
    thread_2: AtomicU64,  // Cache line 0 (same!)
    // False sharing: all threads invalidate same cache line
}
```

**Solution**: Pad to cache line boundaries (64 bytes):

```rust
// ✅ GOOD: Each counter in separate cache line
#[repr(align(64))]
pub struct PaddedCounter {
    value: AtomicU64,
    _padding: [u8; 56],  // Pad to 64 bytes
}

struct Counters {
    thread_0: PaddedCounter,  // Cache line 0
    thread_1: PaddedCounter,  // Cache line 1
    thread_2: PaddedCounter,  // Cache line 2
    // No false sharing!
}
```

**Impact**: 10-20x speedup in high-contention scenarios.

#### 8.7.2 Lock Contention

**Problem**: Single lock becomes bottleneck when all threads compete.

**Example of BAD code**:

```rust
// ❌ BAD: Single global lock
let global_state = Arc::new(Mutex::new(State::new()));

threads.par_iter().for_each(|_| {
    let mut state = global_state.lock().unwrap();
    state.update();  // Sequential bottleneck!
});
```

**Solution**: Sharded locks or lock-free structures:

```rust
// ✅ GOOD: 16 sharded locks (one per core)
let sharded_state: Vec<_> = (0..16)
    .map(|_| Arc::new(Mutex::new(State::new())))
    .collect();

threads.par_iter().enumerate().for_each(|(i, _)| {
    let shard = i % 16;
    let mut state = sharded_state[shard].lock().unwrap();
    state.update();  // Parallel across shards!
});
```

**Alternative**: Use `DashMap` (lock-free concurrent hash map):

```rust
use dashmap::DashMap;

let state: DashMap<u32, Value> = DashMap::new();
threads.par_iter().for_each(|key| {
    state.insert(*key, compute_value(*key));  // Lock-free!
});
```

**Impact**: 5-10x reduction in lock wait time.

#### 8.7.3 Thread Pool Overhead

**Problem**: Creating/destroying threads for each operation is expensive.

**Example of BAD code**:

```rust
// ❌ BAD: New thread pool for each operation
for batch in batches {
    let pool = ThreadPoolBuilder::new().build().unwrap();
    pool.install(|| {
        batch.par_iter().for_each(|item| process(item));
    });
    // Thread pool destroyed here - wasted overhead!
}
```

**Solution**: Reuse global rayon thread pool:

```rust
// ✅ GOOD: Rayon reuses global thread pool
for batch in batches {
    batch.par_iter().for_each(|item| process(item));
    // Threads reused automatically
}
```

**Impact**: Eliminates ~1ms overhead per operation.

#### 8.7.4 Incorrect Chunk Size

**Problem**: Too small chunks → overhead, too large → load imbalance.

**Example of BAD code**:

```rust
// ❌ BAD: Chunk size = 1 (too much overhead)
trees.par_chunks(1).for_each(|chunk| validate(chunk));

// ❌ BAD: Chunk size = 50000 (no parallelism!)
trees.par_chunks(50000).for_each(|chunk| validate(chunk));
```

**Solution**: Tune for CPU cache and work distribution:

```rust
// ✅ GOOD: Chunk size ~1000 (tune experimentally)
// L1 cache = 32KB, L2 = 256KB, L3 = 8-16MB
// ~1000 items fit in L2 cache for typical structs
trees.par_chunks(1000).for_each(|chunk| {
    validate_batch(chunk);  // Good cache locality
});
```

**Tuning guidelines**:

- **CPU-bound**: Chunk size = total_items / (num_cores * 4)
- **Memory-bound**: Chunk size = L2_cache_size / item_size
- **I/O-bound**: Larger chunks (amortize I/O overhead)

#### 8.7.5 Non-Deterministic Iteration

**Problem**: HashMap iteration order is undefined → different results across runs.

**Example of BAD code**:

```rust
use std::collections::HashMap;

// ❌ BAD: Non-deterministic root computation
let mut hasher = Blake2b::new();
for (serial_id, balance) in balances.iter() {  // UNDEFINED ORDER!
    hasher.update(serial_id.to_le_bytes());
    hasher.update(balance.to_le_bytes());
}
let root = hasher.finalize();  // Different root each run!
```

**Solution**: Use BTreeMap for canonical ordering:

```rust
use std::collections::BTreeMap;

// ✅ GOOD: Deterministic root computation
let balances: BTreeMap<u32, i64> = BTreeMap::new();
let mut hasher = Blake2b::new();
for (serial_id, balance) in balances.iter() {  // SORTED ORDER!
    hasher.update(serial_id.to_le_bytes());
    hasher.update(balance.to_le_bytes());
}
let root = hasher.finalize();  // Same root every run!
```

**Impact**: Consensus-critical - prevents chain forks.

#### 8.7.6 Memory Bandwidth Saturation

**Problem**: Parallel threads saturate memory bandwidth → no speedup beyond N cores.

**Symptoms**:

- 8-core: 6x speedup ✓
- 16-core: 8x speedup (expected 12x) ✗
- 32-core: 9x speedup (expected 24x) ✗

**Diagnosis**: Profile with `perf`:

```bash
perf stat -e cycles,instructions,cache-misses,cache-references ./benchmark

# Look for:
# - High cache-miss ratio (>5%)
# - Low IPC (instructions per cycle < 1.0)
```

**Solution**: Reduce memory footprint per operation:

```rust
// ✅ GOOD: Process in smaller chunks to fit in cache
const CHUNK_SIZE: usize = 1000;  // Fits in L2 cache

for chunk in data.chunks(CHUNK_SIZE) {
    chunk.par_iter().for_each(|item| {
        process(item);  // Better cache locality
    });
}
```

**Impact**: 2-3x improvement when memory-bound.

### 8.8 Benchmarking Best Practices

#### 8.8.1 Test Environment Setup

**Minimum requirements**:

- **Baseline**: 4-core laptop (consumer hardware)
- **Target**: 16-core server (production deployment)
- **Optional**: 32-core EPYC (scaling validation)

**Configuration**:

```bash
# Disable CPU frequency scaling (consistent results)
sudo cpupower frequency-set --governor performance

# Disable turbo boost (consistent benchmarks)
echo 1 | sudo tee /sys/devices/system/cpu/intel_pstate/no_turbo

# Pin process to specific cores (isolate from noise)
taskset -c 0-15 cargo bench
```

#### 8.8.2 Benchmark Suite Structure

```bash
# Genesis generation
cargo bench --bench genesis -- --save-baseline v1.0

# Transaction validation
cargo bench --bench validation -- --save-baseline v1.0

# State operations
cargo bench --bench state_ops -- --save-baseline v1.0

# Compare with previous version
cargo bench -- --baseline v1.0
```

#### 8.8.3 Metrics to Track

**Throughput**:

- Transactions per second (TPS)
- Outputs inserted per second
- Proofs verified per second

**Latency**:

- p50 (median)
- p95 (95th percentile)
- p99 (99th percentile)
- max (worst case)

**Resource Utilization**:

- CPU: % utilization per core
- Memory: RSS (resident set size), peak usage
- I/O: Disk read/write throughput

**Scalability**:

- Speedup vs num_cores (should be linear up to N cores)
- Efficiency = speedup / num_cores (should be >0.8)

#### 8.8.4 Regression Detection

```rust
use criterion::{criterion_group, criterion_main, Criterion};

fn bench_genesis_generation(c: &mut Criterion) {
    c.bench_function("genesis_parallel_50k", |b| {
        b.iter(|| {
            generate_genesis_parallel(&GENESIS_SEED, 50_000)
        });
    });
}

criterion_group! {
    name = benches;
    config = Criterion::default()
        .sample_size(100)
        .warm_up_time(Duration::from_secs(5))
        .measurement_time(Duration::from_secs(10))
        .confidence_level(0.95);
    targets = bench_genesis_generation
}
criterion_main!(benches);
```

**Alert on regression**:

```bash
# Fail CI if performance degrades >10%
cargo bench -- --save-baseline main
git checkout feature-branch
cargo bench -- --baseline main

# Parse results and fail if regression detected
if [ "$SPEEDUP" -lt 0.9 ]; then
    echo "Performance regression detected!"
    exit 1
fi
```

---

## 9. Security Considerations

### 9.1 Threat Model

**Attack**: Value recoloring

- Attacker tries to convert serial_id=5 → serial_id=42
- **Mitigation**: Per-serial-id conservation check (§5.5)

**Attack**: Serial ID collision

- Two genesis coins with same serial_id
- **Mitigation**: Validation in genesis builder (§5.3)

**Attack**: Missing serial_amounts

- Transaction omits serial_amounts in output
- **Mitigation**: Empty serial_amounts check in validation (§5.1)

### 9.2 Privacy Analysis

**Question**: Does serial_id reveal value provenance?

**Answer**: ✅ **Controlled disclosure**

- Serial ID reveals **genesis coin origin** (public info anyway)
- Does NOT reveal transaction graph (commitments still blind values)
- Optional: Mix multiple serial_ids in single output → hides specific amounts

**Example**:

```rust
// Public: Output contains serial_ids [5, 78, 142]
// Private: Individual amounts (10K? 50K? unknown due to commitment)
```

### 9.3 Consensus Security

**Critical Invariants**:

1. Serial ID ∈ [1, 50000] (validated at genesis, 1-indexed for user clarity)
2. Per-serial-id conservation (validated in transactions)
3. No duplicate serial_ids in serial_amounts (validated in output construction)

**Failure Modes**:

- Missing validation → inflation bug
- Off-by-one in tree routing → double-spend
- Race condition in parallel tree updates → state corruption

**Mitigation**: Extensive testing (§7) + formal verification (future work)

---

## 12. Open Questions

### 12.1 Consolidation Policy

**Question**: Auto-consolidate outputs with same serial_id?

**Options**:

1. **Wallet-level**: Wallet automatically merges outputs during tx construction
2. **Protocol-level**: Mandate single serial_amount per serial_id in outputs
3. **Lazy**: Allow multiple serial_amounts, consolidate when beneficial

**Recommendation**: Option 1 (wallet-level) - preserves flexibility

### 12.2 Mixed Outputs Limits

**Question**: Max serial_amounts per output?

**Tradeoff**:

- More serial_amounts = more flexibility
- More serial_amounts = larger transactions, more validation cost

**Recommendation**:

- Soft limit: 10 serial_amounts/output (wallet warning)
- Hard limit: 100 serial_amounts/output (consensus rule)

### 12.3 Tree Rebalancing

**Question**: What if serial_id distribution becomes unbalanced?

**Scenario**: Serial_id=0 has 1M outputs, serial_id=1 has 10 outputs

**Options**:

1. **Accept imbalance**: Each tree independent (current design)
2. **Dynamic rebalancing**: Merge low-activity trees
3. **Hierarchical partitioning**: Multi-level tree structure

**Recommendation**: Option 1 for v1 (simplicity), revisit if needed

---

## 13. Architecture & Implementation Recommendations

### 13.1 Performance Optimizations

#### 13.1.1 Memory Efficiency: 50K Empty Trees is Acceptable

**Clarification**: Earlier consideration of "lazy tree allocation" was INCORRECT.

**Why 50K Trees is Fine**:

```rust
// JellyfishMerkleTree is SPARSE - empty tree costs almost nothing
pub struct JellyfishMerkleTree {
    root: Option<Node>,  // Empty tree: root = None (8 bytes)
    // ... metadata (~16 bytes)
}

// Memory cost for 50K EMPTY trees:
// 50,000 trees × 24 bytes/tree = 1.2 MB (negligible)

// After genesis population (50K outputs):
// Each tree has 1 output → 50K trees × ~200 bytes = 10 MB (acceptable)
```

**Why Lazy Allocation is WRONG**:

1. **Complexity**: `BTreeMap<u32, JellyfishMerkleTree>` requires bounds checking
2. **Performance**: Hash lookups slower than direct array indexing
3. **Memory Waste**: BTreeMap overhead (24 bytes/entry) > empty tree cost (24 bytes)
4. **Indexing Logic**: `trees[serial_id - 1]` cleaner than `trees.entry(serial_id).or_insert(...)`
5. **Canonical Ordering**: Vec guarantees deterministic iteration, BTreeMap adds complexity

**DECISION**: Keep `Vec<JellyfishMerkleTree>` with 50K pre-allocated trees.

**Memory Profile**:

- Genesis: 1.2 MB (50K empty trees)
- After 1M transactions: ~100 MB (sparse trees scale well)
- After 10M transactions: ~1 GB (acceptable for full node)

---

#### 13.1.2 Batch Commitment Validation

**Problem**: Linear summation of Pedersen commitments is slow for large transactions.

**Solution**: Use multi-scalar multiplication for batch validation.

```rust
use tari_crypto::ristretto::pedersen::PedersenCommitmentFactory;
use std::collections::BTreeMap;  // Use BTreeMap instead of HashMap

/// Optimized Pedersen balance validation using batch operations
/// Complexity: O(log n) instead of O(n) for n commitments
pub fn validate_pedersen_balance_batched(tx: &Transaction) -> Result<()> {
    let factory = PedersenCommitmentFactory::default();
  
    // Collect all commitments for batch processing
    let input_commitments: Vec<_> = tx.inputs.iter()
        .map(|i| &i.commitment)
        .collect();
  
    let output_commitments: Vec<_> = tx.outputs.iter()
        .map(|o| &o.commitment)
        .collect();
  
    // Single batch operation using multi-scalar multiplication
    // 100+ inputs: 10x speedup, 1000+ inputs: 100x speedup
    factory.verify_batch_sum(&input_commitments, &output_commitments, tx.fee)?;
  
    Ok(())
}
```

**Performance Impact**:

- 100 inputs: **10x faster** than sequential addition
- 1000 inputs: **100x faster**
- Critical for high-throughput transactions

#### 13.1.3 Parallel Tree Validation

**Problem**: Validating 50K trees sequentially is slow.

**Solution**: Parallelize validation across asset classes and tree chunks.

```rust
use rayon::prelude::*;
use std::collections::BTreeMap;  // Ensure BTreeMap for asset_states

impl EpochState {
    /// Parallel validation of all asset state trees
    /// Utilizes multi-core CPUs for ~6x speedup on 8-core systems
    pub fn validate_parallel(&self) -> Result<()> {
        // Level 1: Parallel validation across asset classes
        self.asset_states.par_iter()
            .try_for_each(|(class, state)| {
                state.validate_all_trees()?;
                Ok::<_, StateError>(())
            })?;
    
        // Level 2: Parallel tree integrity checks
        self.asset_states.values()
            .flat_map(|state| &state.trees)
            .collect::<Vec<_>>()
            .par_chunks(1000)  // Batch size: tune for CPU cache
            .try_for_each(|chunk| {
                for tree in chunk {
                    tree.verify_integrity()?;
                }
                Ok::<_, StateError>(())
            })?;
    
        Ok(())
    }
}
```

**Performance Impact**:

- 8-core CPU: **~6x speedup** for full state validation
- Essential for fast sync from genesis

#### 13.1.4 Incremental Root Updates

**Problem**: Recomputing `global_root` on every insert is expensive.

**Solution**: Track dirty trees and batch root updates.

```rust
use std::collections::BTreeSet;  // BTreeSet for canonical ordering

pub struct SerialClassState {
    pub trees: Vec<JellyfishMerkleTree>,
    pub roots: Vec<[u8; 32]>,
    pub global_root: [u8; 32],
    dirty_trees: BTreeSet<u32>,  // SORTED tracking for deterministic iteration
}

impl SerialClassState {
    pub fn insert(&mut self, output: &CoinOutput) -> Result<()> {
        for serial_amount in &output.serial_amounts {
            let tree_index = (serial_amount.serial_id - 1) as usize;
            self.trees[tree_index].insert(output.coin_id(), output)?;
            self.dirty_trees.insert(serial_amount.serial_id);
        }
        // Don't recompute global_root yet - defer to batch commit
        Ok(())
    }
  
    /// Commit batched changes and update global root once
    pub fn commit_batch(&mut self) {
        // Update only dirty tree roots (not all 50K)
        for serial_id in self.dirty_trees.drain() {
            let tree_index = (serial_id - 1) as usize;
            self.roots[tree_index] = self.trees[tree_index].root();
        }
        self.recompute_global_root();
    }
}
```

**Performance Impact**:

- Batch 1000 inserts: **100x fewer** hash operations
- Essential for bulk genesis loading

#### 13.1.5 SerialID Compression for Outputs

**Problem**: `Vec<SerialAmount>` wastes space for sequential serial_ids.

**Solution**: Run-length encoding for compressed storage.

```rust
/// Optimized storage for outputs with multiple serial_amounts
pub enum SerialAmounts {
    /// Single serial_id (most common case)
    Single { serial_id: u32, amount: Amount },  // 12 bytes
  
    /// Multiple arbitrary serial_ids
    Multiple(Vec<SerialAmount>),  // 24 + n*12 bytes
  
    /// Compressed for sequential ranges
    /// Example: [5,6,7,8] with amounts [100,200,150,50]
    Compressed {
        start_serial: u32,
        amounts: Vec<Amount>,  // Implicit sequential serial_ids
    },
}

impl SerialAmounts {
    /// Automatic compression for sequential serial_ids
    pub fn from_vec(mut serial_amounts: Vec<SerialAmount>) -> Self {
        if serial_amounts.len() == 1 {
            let sa = serial_amounts.pop().unwrap();
            return Self::Single { serial_id: sa.serial_id, amount: sa.amount };
        }
    
        // Check if sequential
        serial_amounts.sort_by_key(|sa| sa.serial_id);
        let is_sequential = serial_amounts.windows(2)
            .all(|w| w[1].serial_id == w[0].serial_id + 1);
    
        if is_sequential {
            Self::Compressed {
                start_serial: serial_amounts[0].serial_id,
                amounts: serial_amounts.iter().map(|sa| sa.amount).collect(),
            }
        } else {
            Self::Multiple(serial_amounts)
        }
    }
}
```

**Storage Impact**:

- 10 sequential serial_ids: **33% reduction** (48 → 32 bytes)
- After consolidation: many outputs have sequential serial_ids

### 13.2 Canonical Ordering & Determinism

#### 13.2.1 BTreeMap for All Unordered Collections

**CRITICAL**: Replace all HashMap/HashSet with BTreeMap/BTreeSet for deterministic consensus.

**Problem**: HashMap iteration order is non-deterministic → different nodes compute different roots.

**Solution**: Always use BTreeMap/BTreeSet for canonical ordering.

```rust
// ❌ WRONG: Non-deterministic iteration
use std::collections::HashMap;

let mut balances: HashMap<u32, i64> = HashMap::new();
for (serial_id, balance) in balances {  // UNDEFINED ORDER!
    hasher.update(serial_id.to_le_bytes());
    hasher.update(balance.to_le_bytes());
}

// ✅ CORRECT: Deterministic iteration (sorted by key)
use std::collections::BTreeMap;

let mut balances: BTreeMap<u32, i64> = BTreeMap::new();
for (serial_id, balance) in balances {  // SORTED BY serial_id!
    hasher.update(serial_id.to_le_bytes());
    hasher.update(balance.to_le_bytes());
}
```

**Required Changes**:

1. **Transaction Validation** (line 590):

   ```rust
   // Before: HashMap<u32, i64>
   let mut serial_id_map: BTreeMap<u32, i64> = BTreeMap::new();
   ```
2. **Property Testing** (line 2464):

   ```rust
   // Before: HashMap<u32, i64>
   let mut balances: BTreeMap<u32, i64> = BTreeMap::new();
   ```
3. **Dirty Tree Tracking** (line 2174):

   ```rust
   // Before: HashSet<u32>
   dirty_trees: BTreeSet<u32>,  // Sorted iteration for deterministic root updates
   ```

**Why This Matters**:

- **Consensus Safety**: All nodes must compute identical roots
- **Cross-Implementation**: Rust ≡ Python ≡ Go results
- **Testing**: Snapshot tests require deterministic output
- **Debugging**: Reproducible state transitions

**Performance Impact**:

- BTreeMap: O(log n) vs HashMap O(1) - negligible for <50K entries
- Memory: ~10% overhead vs HashMap - acceptable for consensus correctness

---

### 13.3 Type Safety Improvements

#### 13.3.1 NewType Pattern for SerialID

**Problem**: `u32` used for serial_id, tree_index, counts - easy to confuse.

**Solution**: Strong typing with compile-time safety.

```rust
use serde::{Deserialize, Serialize};

/// Type-safe serial ID with built-in validation
#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash, Ord, PartialOrd)]
#[derive(Serialize, Deserialize)]
pub struct SerialID(u32);

impl SerialID {
    pub const MIN: Self = Self(1);
    pub const MAX: Self = Self(50_000);
  
    /// Create validated SerialID (range check at construction)
    pub fn new(value: u32) -> Result<Self, AssetError> {
        if value < Self::MIN.0 || value > Self::MAX.0 {
            return Err(AssetError::SerialIDOutOfRange { 
                value, 
                min: Self::MIN.0, 
                max: Self::MAX.0 
            });
        }
        Ok(Self(value))
    }
  
    /// Convert to tree index (centralized 1-indexed logic)
    pub fn to_tree_index(self) -> usize {
        (self.0 - 1) as usize
    }
  
    /// Get raw value
    pub fn get(self) -> u32 {
        self.0
    }
}

// Usage example:
let serial_id = SerialID::new(index + 1)?;  // Validated at creation
let tree_idx = serial_id.to_tree_index();   // Correct conversion
```

**Benefits**:

- **Compile-time safety**: Cannot pass tree_index where SerialID expected
- **Centralized validation**: Range check in one place
- **Self-documenting**: Type signature shows intent

#### 13.3.2 Enhanced Error Context with miette

**Problem**: Errors lack context for debugging production issues.

**Solution**: Rich diagnostic errors with source spans and hints.

```rust
use miette::{Diagnostic, SourceSpan};
use thiserror::Error;

#[derive(Error, Debug, Diagnostic)]
pub enum ValidationError {
    #[error("Serial ID {serial_id} out of valid range [{min}, {max}]")]
    #[diagnostic(
        code(z00z::validation::serial_id_range),
        help("Genesis coins use serial_ids 1-50000. Check transaction source."),
        url("https://docs.z00z.io/errors/serial-id-range")
    )]
    SerialIDOutOfRange {
        serial_id: u32,
        min: u32,
        max: u32,
        #[label("invalid serial_id here")]
        span: SourceSpan,
    },
  
    #[error("Serial ID {serial_id} imbalance: {delta} difference")]
    #[diagnostic(
        code(z00z::validation::serial_id_balance),
        help("Each serial_id must have equal inputs and outputs in transaction"),
    )]
    SerialIDImbalance {
        serial_id: u32,
        inputs: Amount,
        outputs: Amount,
        delta: i64,
        #[label("imbalance detected")]
        span: SourceSpan,
    },
}
```

**Benefits**:

- **User-friendly errors**: Clear explanations with context
- **Developer hints**: Direct links to documentation
- **Production debugging**: Structured error reports

### 13.4 Quality Assurance

#### 13.4.1 Metrics & Observability

**Solution**: Comprehensive metrics for production monitoring.

```rust
use prometheus::{Counter, Histogram, IntGauge, Registry};

/// Production metrics for SerialClassState operations
pub struct StateMetrics {
    pub active_trees: IntGauge,
    pub tree_depth_histogram: Histogram,
    pub insert_duration: Histogram,
    pub validation_errors: Counter,
    pub global_root_updates: Counter,
}

impl StateMetrics {
    pub fn new(registry: &Registry) -> Result<Self, prometheus::Error> {
        Ok(Self {
            active_trees: IntGauge::new(
                "z00z_active_trees",
                "Number of active serial_id trees"
            )?.register(registry)?,
        
            tree_depth_histogram: Histogram::with_opts(
                prometheus::HistogramOpts::new(
                    "z00z_tree_depth",
                    "Distribution of tree depths"
                ).buckets(vec![5.0, 10.0, 20.0, 50.0, 100.0])
            )?.register(registry)?,
        
            insert_duration: Histogram::with_opts(
                prometheus::HistogramOpts::new(
                    "z00z_insert_duration_seconds",
                    "Time to insert output into trees"
                ).buckets(prometheus::exponential_buckets(0.001, 2.0, 10)?)
            )?.register(registry)?,
        
            validation_errors: Counter::new(
                "z00z_validation_errors_total",
                "Total validation errors by type"
            )?.register(registry)?,
        
            global_root_updates: Counter::new(
                "z00z_global_root_updates_total",
                "Number of global root recomputations"
            )?.register(registry)?,
        })
    }
}

impl SerialClassState {
    pub fn insert_with_metrics(
        &mut self, 
        output: &CoinOutput, 
        metrics: &StateMetrics
    ) -> Result<()> {
        let _timer = metrics.insert_duration.start_timer();
    
        for serial_amount in &output.serial_amounts {
            let tree_index = serial_amount.serial_id.to_tree_index();
            self.trees[tree_index].insert(output.coin_id(), output)?;
        
            metrics.tree_depth_histogram.observe(
                self.trees[tree_index].depth() as f64
            );
        }
    
        metrics.active_trees.set(
            self.trees.iter().filter(|t| !t.is_empty()).count() as i64
        );
    
        Ok(())
    }
}
```

**Production Value**:

- **Performance monitoring**: Detect regression early
- **Capacity planning**: Track growth trends
- **Debugging**: Correlate errors with metrics

#### 13.4.2 Property-Based Testing

**Solution**: Automated invariant checking with proptest.

```rust
use proptest::prelude::*;
use std::collections::BTreeMap;  // Canonical ordering for determinism

// Generator for valid SerialAmount
fn arbitrary_serial_amount() -> impl Strategy<Value = SerialAmount> {
    (1u32..=50_000, 1u64..1_000_000_000).prop_map(|(serial_id, amount)| {
        SerialAmount {
            serial_id: SerialID::new(serial_id).unwrap(),
            amount,
        }
    })
}

proptest! {
    /// Property: Serial ID conservation must hold for any valid transaction
    #[test]
    fn test_serial_id_conservation_invariant(
        inputs in prop::collection::vec(arbitrary_serial_amount(), 1..100),
        outputs in prop::collection::vec(arbitrary_serial_amount(), 1..100)
    ) {
        let mut balances: BTreeMap<u32, i64> = BTreeMap::new();  // BTreeMap for deterministic iteration
    
        // Sum inputs (positive)
        for sa in &inputs {
            *balances.entry(sa.serial_id.get()).or_default() += sa.amount as i64;
        }
    
        // Sum outputs (negative)
        for sa in &outputs {
            *balances.entry(sa.serial_id.get()).or_default() -= sa.amount as i64;
        }
    
        // Property: If transaction is valid, all serial_ids must balance
        let is_balanced = balances.values().all(|&v| v == 0);
    
        if !is_balanced {
            // This should trigger validation error
            prop_assert!(validate_serial_id_conservation_would_fail(&inputs, &outputs));
        }
    }
  
    /// Property: Tree index conversion must be bijective for valid range
    #[test]
    fn test_serial_id_tree_index_bijection(serial_id in 1u32..=50_000) {
        let sid = SerialID::new(serial_id).unwrap();
        let tree_idx = sid.to_tree_index();
    
        // Verify: tree_index ∈ [0, 49999]
        prop_assert!(tree_idx < 50_000);
    
        // Verify: serial_id = tree_index + 1
        prop_assert_eq!(serial_id, (tree_idx as u32) + 1);
    }
  
    /// Property: Batch root computation must equal incremental updates
    #[test]
    fn test_incremental_root_equivalence(
        outputs in prop::collection::vec(arbitrary_coin_output(), 10..50)
    ) {
        let mut state_batch = SerialClassState::new(50_000);
        let mut state_incremental = SerialClassState::new(50_000);
    
        // Batch insert + single root update
        for output in &outputs {
            state_batch.insert(output).unwrap();
        }
        state_batch.commit_batch();
    
        // Incremental insert + root update each time
        for output in &outputs {
            state_incremental.insert(output).unwrap();
            state_incremental.recompute_global_root();
        }
    
        // Property: Final roots must be identical
        prop_assert_eq!(state_batch.global_root, state_incremental.global_root);
    }
}
```

**Testing Value**:

- **10,000 test cases** generated automatically
- **Edge cases** found without manual effort
- **Regression prevention**: Invariants always checked

#### 13.4.3 Snapshot Testing for Genesis

**Solution**: Deterministic genesis verification with golden snapshots.

```rust
use insta::assert_json_snapshot;

#[test]
fn test_genesis_deterministic_snapshot() {
    let genesis = generate_genesis_state(&GENESIS_SEED).unwrap();
  
    // Serialize key properties for snapshot comparison
    let snapshot = serde_json::json!({
        "epoch_id": genesis.epoch_id,
        "epoch_root": hex::encode(genesis.epoch_root),
        "total_coins": genesis.asset_states[&AssetClass::Coin].trees.len(),
        "first_coin": {
            "serial_id": 1,
            "commitment": hex::encode(get_genesis_coin_commitment(0)),
            "amount": GENESIS_COIN_NOMINAL,
        },
        "last_coin": {
            "serial_id": 50_000,
            "commitment": hex::encode(get_genesis_coin_commitment(49_999)),
            "amount": GENESIS_COIN_NOMINAL,
        },
        "sample_coins": (0..10).map(|i| {
            let idx = i * 5000;  // Sample every 5000th coin
            serde_json::json!({
                "index": idx,
                "serial_id": idx + 1,
                "commitment": hex::encode(get_genesis_coin_commitment(idx)),
            })
        }).collect::<Vec<_>>(),
    });
  
    // Compare with golden snapshot (auto-generated on first run)
    assert_json_snapshot!(snapshot, @r###"
    {
      "epoch_id": 0,
      "epoch_root": "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855",
      "total_coins": 50000,
      "first_coin": {
        "serial_id": 1,
        "commitment": "a1b2c3d4...",
        "amount": 10000000000
      },
      ...
    }
    "###);
}

#[test]
fn test_genesis_reproducibility() {
    // Generate genesis 10 times with same seed
    let results: Vec<_> = (0..10)
        .map(|_| generate_genesis_state(&GENESIS_SEED).unwrap())
        .collect();
  
    // All epoch_roots must be identical
    let first_root = results[0].epoch_root;
    for state in &results[1..] {
        assert_eq!(
            state.epoch_root, 
            first_root,
            "Genesis generation must be deterministic"
        );
    }
}
```

**Testing Value**:

- **Regression detection**: Any genesis change is immediately visible
- **Documentation**: Snapshot serves as expected output reference
- **Cross-implementation**: Verify Rust ≡ Python ≡ Go genesis

### 13.4 Implementation Priority

| Recommendation                 | Complexity | Impact               | Priority |
| ------------------------------ | ---------- | -------------------- | -------- |
| 2. Batch Commitment Validation | Low        | High (10-100x speed) | 🔴 HIGH  |
| 3. Parallel Tree Validation    | Medium     | Medium (6x speed)    | 🔴 HIGH  |
| 4. Incremental Root Updates    | Low        | High (100x batches)  | 🔴 HIGH  |
| 5. SerialID Compression        | High       | Low (5-10% storage)  | 🔴 HIGH  |
| 6. NewType Pattern             | Low        | High (type safety)   | 🔴 HIGH  |
| 7. Error Context (miette)      | Low        | Medium (DX)          | 🔴 HIGH  |
| 8. Metrics                     | Medium     | High (production)    | 🔴 HIGH  |
| 9. Property Testing            | Medium     | High (correctness)   | 🔴 HIGH  |
| 10. Snapshot Testing           | Low        | Medium (regression)  | 🔴 HIGH  |

**Recommended Implementation Order**:

1. **Phase 1 (Week 1-2)**: #6 NewType, #4 Incremental Roots, #2 Batch Validation
2. **Phase 2 (Week 3-4)**: #8 Metrics, #3 Parallel Validation
3. **Phase 3 (Week 5-6)**: #9 Property Testing, #10 Snapshot Testing, #7 Error Context
4. **Phase 4 (Future)**: #5 Compression (after usage analysis)

---

## 14. Approval Sign-Off

**Draft Status**: Ready for review

**Required Approvals**:

- [ ] Core Protocol Lead
- [ ] Cryptography Reviewer
- [ ] Performance Engineering
- [ ] Security Audit

**Next Steps**:

1. Review this draft
2. Address feedback
3. Create implementation tickets (GitHub issues)
4. Begin Phase 1 implementation

---

**END OF DRAFT**
