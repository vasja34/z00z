# SRS: Z00Z Transaction Structure

## 1. Introduction

### 1.1 Purpose

This Software Requirements Specification (SRS) document describes the transaction structure for the Z00Z blockchain system. It provides detailed requirements for implementing the core transaction functionality as specified in the Coins__Tx_Structure.pdf document. This SRS is designed to be understandable for junior developers, providing clear implementation guidance with Rust code examples.

### 1.2 Scope

This document covers:

- SpendTx structure and validation
- ACK (Acknowledgement) structure and processing
- Domain tag separation mechanism
- Link tag verification system
- Nullifier set management
- Merkle tree-based state verification
- Pedersen commitment balance verification

This SRS does NOT cover:

- Network layer protocols
- Wallet user interface components
- Validator consensus rules
- Cross-chain integration

### 1.3 Definitions and Acronyms

- **SpendTx**: The main transaction type for spending coins
- **ACK**: Off-chain acknowledgment structure
- **Nullifier**: Unique identifier preventing double-spending
- **Pedersen Commitment**: Cryptographic commitment scheme used to hide values
- **Merkle Tree**: Data structure for efficient state verification
- **Domain Tag**: Prefix used to separate different types of cryptographic operations
- **Link Tag**: Identifier connecting transactions while preserving privacy
- **PTB**: Production Transaction Batch

## 2. Overall Description

### 2.1 Product Perspective

The transaction structure is a core component of the Z00Z blockchain system. It enables secure, private value transfers while maintaining the system's stateless architecture. The transaction structure interacts with:

- State management (Merkle trees, nullifier set)
- Cryptographic primitives (signatures, commitments)
- Network layer (transaction propagation)
- Wallet components (transaction creation and validation)

### 2.2 Product Functions

Key functions of the transaction structure:

1. **SpendTx Creation**: Allowing users to create spend transactions
2. **Transaction Validation**: Verifying the validity of transactions
3. **ACK Processing**: Handling off-chain acknowledgments
4. **Nullifier Management**: Preventing double-spending
5. **Pedersen Balance Verification**: Ensuring value conservation without revealing amounts
6. **Link Tag Verification**: Maintaining privacy while preventing fraud

### 2.3 User Characteristics

This system is primarily used by:

- **Blockchain Nodes**: For transaction validation and processing
- **Wallet Applications**: For transaction creation and management
- **Developers**: Integrating with the transaction system

### 2.4 Constraints

- Must maintain stateless architecture (~200 KB active state)
- Must support offline payments
- Must ensure complete unlinkability and untraceability
- Must use minimal transaction fees
- Must prevent probe-attacks through cover traffic

## 3. Specific Requirements

### 3.1 Functional Requirements

#### 3.1.1 SpendTx Structure

**FR-SpendTx-001**: SpendTx must contain a domain_tag field with value "Z00Z_SPEND".

*Implementation Location*: `src/core/tx/spend.rs`

*Rust Code Example*:

```rust
/// Domain tags used for transaction separation and replay protection
#[derive(Debug, Clone, PartialEq, Eq, Hash)]
pub enum DomainTag {
    Spend,
    Ack,
    Challenge,
    PenaltyClaim,
    Merge,
}

impl DomainTag {
    /// Convert domain tag to string representation for hashing
    pub fn as_str(&self) -> &'static str {
        match self {
            DomainTag::Spend => "Z00Z_SPEND",
            DomainTag::Ack => "Z00Z_ACK",
            DomainTag::Challenge => "Z00Z_CHALLENGE",
            DomainTag::PenaltyClaim => "Z00Z_PENALTY_CLAIM",
            DomainTag::Merge => "Z00Z_MERGE",
        }
    }
}
```

**FR-SpendTx-002**: SpendTx must contain an array of CoinInput structures.

*Implementation Location*: `src/core/tx/spend.rs`

*Rust Code Example*:

```rust
/// Represents a coin input in a SpendTx transaction
#[derive(Debug, Clone)]
pub struct CoinInput {
    /// Context ID that uniquely identifies the coin in the state tree
    pub context_id: [u8; 32],
  
    /// Pedersen commitment representing the coin value
    pub commitment: PedersenCommitment,
  
    /// Merkle proof that the coin exists in the current state
    pub inclusion_proof: MerkleProof,
  
    /// Ephemeral signature proving ownership of the coin
    pub sig_eph: SchnorrSignature,
  
    /// Link tag that connects transactions while preserving privacy
    pub link_tag: CompressedRistretto,
  
    /// Proof for the link tag correctness
    pub link_proof: SchnorrSignature,
  
    /// Nullifier that prevents double spending
    pub nullifier: [u8; 32],
}
```

**FR-SpendTx-003**: SpendTx must contain an array of CoinOutput structures.

*Implementation Location*: `src/core/tx/spend.rs`

*Rust Code Example*:

```rust
/// Represents a coin output in a SpendTx transaction
#[derive(Debug, Clone)]
pub struct CoinOutput {
    /// Context ID for the new coin
    pub context_id: [u8; 32],
  
    /// Pedersen commitment for the new coin
    pub commitment: PedersenCommitment,
  
    /// Content ID that specifies the type of asset
    pub content_id: ContentId,
}
```

**FR-SpendTx-004**: SpendTx must contain a tx_id field that is a hash of the transaction body.

*Implementation Location*: `src/core/tx/spend.rs`

*Rust Code Example*:

```rust
/// Main transaction structure for spending coins
#[derive(Debug, Clone)]
pub struct SpendTx {
    /// Domain tag for transaction separation and replay protection
    pub domain_tag: DomainTag,
  
    /// Inputs being spent
    pub inputs: Vec<CoinInput>,
  
    /// New outputs being created
    pub outputs: Vec<CoinOutput>,
  
    /// Unique transaction ID (hash of transaction body)
    pub tx_id: [u8; 32],
}
```

#### 3.1.2 ACK Structure

**FR-ACK-001**: ACK must contain an ack_id field that uniquely identifies the ACK session.

*Implementation Location*: `src/core/tx/ack.rs`

*Rust Code Example*:

```rust
/// Off-chain acknowledgment (ACK) structure
#[derive(Debug, Clone)]
pub struct Ack {
    /// Unique identifier for this ACK session
    /// Generated as Hash(pk_receiver || ack_id || i) as per document
    pub ack_id: [u8; 32],
  
    /// Outputs that are promised to the recipient
    pub outputs: Vec<CoinOutput>,
  
    /// Signature from sender confirming the ACK
    pub sig_ack: SchnorrSignature,
  
    /// Public key of the sender (Alice)
    pub from_pk: CompressedRistretto,
  
    /// Deadline height after which this ACK becomes invalid
    pub deadline_height: u64,
  
    /// Optional metadata (TTL, fee info, etc.)
    pub metadata: Option<AckMetadata>,
  
    /// Timestamp when this ACK was created
    pub timestamp: SystemTime,
}
```

**FR-ACK-002**: ACK must be fully encrypted with the recipient's public key and never appear on-chain.

*Implementation Location*: `src/core/tx/ack.rs`

*Rust Code Example*:

```rust
impl Ack {
    /// Encrypts the ACK with the recipient's public key
    pub fn encrypt(&self, recipient_pk: &PublicKey) -> Vec<u8> {
        // Implementation would use ECIES or similar
        // ACK must remain off-chain and fully encrypted
        todo!("Implement ACK encryption")
    }
  
    /// Validates an ACK structure
    pub fn validate(&self, current_height: u64) -> Result<(), AckError> {
        // Verify ACK is not expired
        if current_height >= self.deadline_height {
            return Err(AckError::Expired);
        }
      
        // Verify signature
        let message = self.create_signature_message();
        if !self.verify_signature(&message) {
            return Err(AckError::InvalidSignature);
        }
      
        Ok(())
    }
}
```

#### 3.1.3 Domain Tag Separation

**FR-Domain-001**: All cryptographic operations must use domain-separated tags following the format "Z00Z_[TYPE]".

*Implementation Location*: `src/core/crypto/domain.rs`

*Rust Code Example*:

```rust
/// Creates a domain-separated message
fn create_domain_separated_message(message: &[u8], domain_tag: &str) -> Vec<u8> {
    let mut result = Vec::with_capacity(domain_tag.len() + message.len());
    result.extend_from_slice(domain_tag.as_bytes());
    result.extend_from_slice(message);
    result
}

/// Verifies a Schnorr signature with domain separation
pub fn verify_with_domain(
    pk: &RistrettoPoint,
    message: &[u8],
    domain_tag: &str,
    signature: &SchnorrSignature
) -> bool {
    let domain_separated_message = create_domain_separated_message(message, domain_tag);
    let c = create_challenge(&signature.r_point, &domain_separated_message);
  
    // Verify equation: R + c*P = s*G
    let lhs = signature.r_point + c * pk;
    let rhs = RistrettoPoint::from(signature.s) * RistrettoPoint::generator();
  
    lhs == rhs
}
```

#### 3.1.4 Link Tag Verification

**FR-LinkTag-001**: Each CoinInput must contain a valid link_tag and link_proof.

*Implementation Location*: `src/core/tx/spend/link_tag.rs`

*Rust Code Example*:

```rust
/// Verifies the correctness of a link tag
/// Implements the "link_equation_holds" function from Coins__Tx_Structure.pdf
pub fn verify_link_tag(
    p_in: &CompressedRistretto,
    link_tag: &CompressedRistretto,
    link_proof: &SchnorrSignature,
    tx_id: &[u8; 32]
) -> bool {
    // Implementation of link tag verification as described in document:
    // "link_tag + link_proof — доказывают правильность L = P_in^a"
  
    // The verification would use Schnorr proof verification with domain separation
    // using the transaction ID as part of the challenge
  
    // Pseudocode from document:
    // ensure!(link_equation_holds(tx.P_in, tx.link_tag, tx.link_proof, tx_id));
  
    // 1. Recreate the challenge message
    let mut message = Vec::new();
    message.extend_from_slice(p_in.as_bytes());
    message.extend_from_slice(link_tag.as_bytes());
    message.extend_from_slice(tx_id);
  
    // 2. Verify the Schnorr proof
    verify_schnorr(p_in, &message, link_proof)
}
```

**FR-LinkTag-002**: The system must detect and blacklist link tags from fraudulent transactions.

*Implementation Location*: `src/core/blacklist/mod.rs`

*Rust Code Example*:

```rust
/// Blacklist for compromised link tags
#[derive(Debug, Default)]
pub struct Blacklist {
    /// Set of blacklisted link tags
    link_tags: HashSet<CompressedRistretto>,
  
    /// Timestamps of when link tags were blacklisted
    timestamps: HashMap<CompressedRistretto, SystemTime>,
}

impl Blacklist {
    /// Adds a link tag to the blacklist
    pub fn add_link_tag(&mut self, link_tag: CompressedRistretto) {
        self.link_tags.insert(link_tag);
        self.timestamps.insert(link_tag, SystemTime::now());
    }
  
    /// Checks if a link tag is blacklisted
    pub fn contains(&self, link_tag: &CompressedRistretto) -> bool {
        self.link_tags.contains(link_tag)
    }
}
```

#### 3.1.5 Nullifier Set Management

**FR-Nullifier-001**: Each CoinInput must contain a unique nullifier that prevents double-spending.

*Implementation Location*: `src/core/state/nullifier.rs`

*Rust Code Example*:

```rust
/// Set of used nullifiers to prevent double spending
#[derive(Debug, Default)]
pub struct NullifierSet {
    /// Active nullifiers (recently used)
    active: HashSet<[u8; 32]>,
  
    /// Bloom filter for efficient nullifier lookup
    bloom_filter: BloomFilter,
  
    /// Historical nullifiers (for pruning)
    history: Vec<[u8; 32]>,
}

impl NullifierSet {
    /// Checks if a nullifier has been used
    pub fn contains(&self, nullifier: &[u8; 32]) -> bool {
        self.active.contains(nullifier) || self.bloom_filter.contains(nullifier)
    }
  
    /// Adds a nullifier to the set
    pub fn add(&mut self, nullifier: [u8; 32]) {
        self.active.insert(nullifier);
        self.bloom_filter.add(&nullifier);
        self.history.push(nullifier);
      
        // Prune old nullifiers if needed
        self.maybe_prune();
    }
  
    /// Checks if nullifier set is consistent with Merkle tree
    pub fn verify_with_state(&self, state_root: &[u8; 32]) -> bool {
        // Implementation would verify nullifier set consistency
        // with the current state root
        true
    }
}
```

**FR-Nullifier-002**: The system must prevent double spends through nullifier reuse detection.

*Implementation Location*: `src/core/tx/spend.rs`

*Rust Code Example*:

```rust
impl SpendTx {
    /// Validates a SpendTx transaction
    pub fn validate(&self, state: &TransactionState) -> Result<(), TransactionError> {
        // Check nullifier uniqueness
        for input in &self.inputs {
            if state.nullifier_set.contains(&input.nullifier) {
                return Err(TransactionError::DoubleSpend);
            }
        }
      
        // Other validation steps...
        Ok(())
    }
}
```

#### 3.1.6 Pedersen Balance Verification

**FR-Pedersen-001**: SpendTx must verify that input commitments equal output commitments (Pedersen balance: C_in == Σ C_out_i).

*Implementation Location*: `src/core/tx/spend.rs`

*Rust Code Example*:

```rust
impl SpendTx {
    /// Verifies that input commitments equal output commitments (Pedersen balance)
    /// As described in Coins__Tx_Structure.pdf: "Pedersen‐баланс: C_in == Σ C_out_i"
    fn verify_pedersen_balance(&self) -> bool {
        let mut total_input = PedersenCommitment::zero();
        let mut total_output = PedersenCommitment::zero();

        for input in &self.inputs {
            total_input = total_input + &input.commitment;
        }

        for output in &self.outputs {
            total_output = total_output + &output.commitment;
        }

        total_input == total_output
    }
}
```

**FR-Pedersen-002**: Balance verification must work without revealing individual values.

*Implementation Location*: `src/core/crypto/commitments/pedersen.rs`

*Rust Code Example*:

```rust
/// Pedersen commitment structure
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct PedersenCommitment {
    /// Commitment point
    pub point: RistrettoPoint,
}

impl PedersenCommitment {
    /// Creates a new Pedersen commitment: C = v*G + r*H
    pub fn new(value: u64, randomness: &Scalar, gens: &PedersenGens) -> Self {
        let v = Scalar::from(value);
        let commitment = (gens.G * v) + (gens.H * randomness);
        PedersenCommitment { point: commitment }
    }
  
    /// Adds two Pedersen commitments
    pub fn add(&self, other: &Self) -> Self {
        PedersenCommitment {
            point: self.point + other.point,
        }
    }
  
    /// Checks if two Pedersen commitments are equal
    pub fn equals(&self, other: &Self) -> bool {
        self.point == other.point
    }
}
```

#### 3.1.7 Merkle Tree Verification

**FR-Merkle-001**: Each CoinInput must contain a valid inclusion_proof that verifies the coin exists in the current state.

*Implementation Location*: `src/core/state/merkle.rs`

*Rust Code Example*:

```rust
/// Merkle proof structure
#[derive(Debug, Clone)]
pub struct MerkleProof {
    /// Sibling hashes along the path
    pub siblings: Vec<[u8; 32]>,
  
    /// Bitmask indicating left/right path
    pub path: u64,
  
    /// Depth in the tree
    pub depth: u8,
}

impl MerkleProof {
    /// Verifies that a leaf exists in the Merkle tree with the given root
    pub fn verify(&self, leaf: &[u8; 32], root: &[u8; 32]) -> bool {
        let mut current_hash = *leaf;
      
        for (i, sibling) in self.siblings.iter().enumerate() {
            let is_right = (self.path >> i) & 1 == 1;
          
            if is_right {
                current_hash = hash_pair(sibling, &current_hash);
            } else {
                current_hash = hash_pair(&current_hash, sibling);
            }
        }
      
        &current_hash == root
    }
}
```

**FR-Merkle-002**: The system must support efficient state verification using Merkle proofs.

*Implementation Location*: `src/core/tx/spend.rs`

*Rust Code Example*:

```rust
impl SpendTx {
    /// Validates a SpendTx transaction
    pub fn validate(&self, state: &TransactionState) -> Result<(), TransactionError> {
        // Verify inclusion proof for input coins
        for input in &self.inputs {
            if !state.coin_tree.verify(
                &input.context_id, 
                &input.inclusion_proof, 
                &input.commitment
            ) {
                return Err(TransactionError::InvalidInclusionProof);
            }
        }
      
        // Other validation steps...
        Ok(())
    }
}
```

### 3.2 Performance Requirements

**PR-Performance-001**: SpendTx validation must complete within 50ms for transactions with up to 10 inputs/outputs.

**PR-Performance-002**: Nullifier set lookup must have O(1) average time complexity.

**PR-Performance-003**: Merkle proof verification must have O(log n) time complexity where n is the number of leaves.

### 3.3 Design Constraints

**DC-Design-001**: The system must maintain stateless architecture with ~200 KB active state.

**DC-Design-002**: All cryptographic operations must use domain-separated tags to prevent signature reuse.

**DC-Design-003**: ACK must remain off-chain and fully encrypted.

**DC-Design-004**: The system must support offline payments without internet connectivity.

## 4. External Interface Requirements

### 4.1 User Interfaces

The transaction structure does not directly provide user interfaces. It provides APIs for wallet applications to implement user interfaces.

### 4.2 Hardware Interfaces

No specific hardware interfaces are required.

### 4.3 Software Interfaces

**SI-Software-001**: Transaction validation API

*Implementation Location*: `src/core/tx/spend.rs`

*Rust Code Example*:

```rust
/// State required for transaction validation
/// Represents the current blockchain state at the time of validation
pub struct TransactionState<'a> {
    /// Merkle tree for coins
    pub coin_tree: &'a MerkleTree,
  
    /// Set of used nullifiers to prevent double spending
    pub nullifier_set: &'a NullifierSet,
  
    /// Blacklist for compromised link tags
    pub blacklist: &'a Blacklist,
}

impl SpendTx {
    /// Validates a SpendTx transaction according to the rules in Coins__Tx_Structure.pdf
    pub fn validate(&self, state: &TransactionState) -> Result<(), TransactionError> {
        // Implementation as shown in previous examples
    }
}
```

**SI-Software-002**: ACK processing API

*Implementation Location*: `src/core/tx/ack.rs`

*Rust Code Example*:

```rust
impl Ack {
    /// Validates an ACK structure
    pub fn validate(&self, current_height: u64) -> Result<(), AckError> {
        // Implementation as shown in previous examples
    }
  
    /// Creates a ChallengeNotSpent transaction if ACK deadline is approaching
    /// and SpendTx hasn't been published
    pub fn create_challenge_not_spent(&self) -> ChallengeNotSpent {
        ChallengeNotSpent {
            ack_id: self.ack_id,
            outputs_hash: self.calculate_outputs_hash(),
            deadline_height: self.deadline_height,
        }
    }
}
```

## 5. System Features

### 5.1 Offline Payment Support

**SF-Offline-001**: The system must support offline payments through the ACK mechanism.

*Implementation Location*: `src/core/tx/ack.rs` and `src/core/offline/transfer.rs`

*Rust Code Example*:

```rust
/// Process for creating an offline payment
pub fn create_offline_payment(
    sender_sk: &Scalar,
    recipient_pk: &PublicKey,
    amount: u64,
    deadline_height: u64
) -> (Ack, SpendTxPreparation) {
    // 1. Generate random values for the new coin
    let r = Scalar::random(&mut OsRng);
    let gens = PedersenGens::default();
    let commitment = gens.commit(amount, &r);
  
    // 2. Create context ID
    let context_id = create_context_id(recipient_pk, &commitment);
  
    // 3. Prepare the ACK
    let outputs = vec![CoinOutput {
        context_id,
        commitment,
        content_id: ContentId::native_Z00Z(),
    }];
  
    // 4. Sign the ACK
    let ack_id = generate_ack_id(recipient_pk);
    let sig_ack = sign_ack(sender_sk, &outputs, ack_id, recipient_pk);
  
    // 5. Create the ACK
    let ack = Ack {
        ack_id,
        outputs,
        sig_ack,
        from_pk: PublicKey::from(sender_sk),
        deadline_height,
        metadata: None,
        timestamp: SystemTime::now(),
    };
  
    // 6. Prepare SpendTx for later
    let spend_preparation = SpendTxPreparation {
        inputs: Vec::new(), // Will be filled when spending
        outputs: ack.outputs.clone(),
        deadline_height,
    };
  
    (ack, spend_preparation)
}

/// Process for receiving an offline payment
pub fn receive_offline_payment(ack: &Ack, my_sk: &Scalar) -> Result<OfflinePaymentReceipt, AckError> {
    // 1. Validate the ACK
    let current_height = get_current_block_height();
    ack.validate(current_height)?;
  
    // 2. Store the ACK for later verification
    let receipt = OfflinePaymentReceipt {
        ack_id: ack.ack_id,
        outputs: ack.outputs.clone(),
        deadline_height: ack.deadline_height,
        timestamp: SystemTime::now(),
    };
  
    Ok(receipt)
}
```

### 5.2 Fraud Detection and Prevention

**SF-Fraud-001**: The system must detect and prevent double spending through nullifier set management.

*Implementation Location*: `src/core/state/nullifier.rs` and `src/core/tx/spend.rs`

*Rust Code Example*:

```rust
/// Challenge transaction for invalid transactions
#[derive(Debug, Clone)]
pub struct ChallengeInvalid {
    /// Domain tag for challenge
    pub domain_tag: DomainTag,
  
    /// ACK ID being challenged
    pub ack_id: [u8; 32],
  
    /// Signature from sender on the ACK
    pub sig_ack: SchnorrSignature,
  
    /// Inputs from the ACK
    pub inputs_ack: Vec<CoinInput>,
  
    /// Proofs for the coins
    pub proofs_coin: Vec<VerkleProof>,
  
    /// Proof of absence of nullifier
    pub proof_absence_null: VerkleNonProof,
  
    /// Penalty amount due
    pub penalty_due: u64,
  
    /// Signature from Bob (recipient)
    pub sig_bob: SchnorrSignature,
  
    /// Deposit to prevent spam
    pub deposit: u64,
}

impl ChallengeInvalid {
    /// Creates a challenge for a fraudulent transaction
    pub fn new(
        ack: &Ack,
        spend_tx: &SpendTx,
        state: &TransactionState
    ) -> Result<Self, FraudDetectionError> {
        // 1. Verify that the SpendTx doesn't match the ACK
        if spend_tx.outputs != ack.outputs {
            return Err(FraudDetectionError::OutputMismatch);
        }
      
        // 2. Verify that the nullifier wasn't used
        for input in &spend_tx.inputs {
            if state.nullifier_set.contains(&input.nullifier) {
                return Err(FraudDetectionError::NullifierAlreadyUsed);
            }
        }
      
        // 3. Create the challenge
        Ok(ChallengeInvalid {
            domain_tag: DomainTag::Challenge,
            ack_id: ack.ack_id,
            sig_ack: ack.sig_ack.clone(),
            inputs_ack: spend_tx.inputs.clone(),
            proofs_coin: Vec::new(), // Would be filled with actual proofs
            proof_absence_null: VerkleNonProof::new(),
            penalty_due: calculate_penalty(&spend_tx),
            sig_bob: SchnorrSignature::new(), // Would be properly signed
            deposit: CHALLENGE_DEPOSIT,
        })
    }
}
```

## 6. Non-Functional Requirements

### 6.1 Security Requirements

**NFR-Security-001**: All cryptographic operations must use domain-separated tags to prevent signature reuse across different transaction types.

**NFR-Security-002**: The system must detect and blacklist link tags from fraudulent transactions.

**NFR-Security-003**: Nullifier set must efficiently prevent double spends without revealing user identities.

**NFR-Security-004**: ACK must remain off-chain and fully encrypted to preserve privacy.

**NFR-Security-005**: Pedersen balance verification must work without revealing individual values.

### 6.2 Reliability Requirements

**NFR-Reliability-001**: The transaction validation system must have 99.99% uptime.

**NFR-Reliability-002**: The system must correctly validate 99.999% of valid transactions.

**NFR-Reliability-003**: The system must correctly reject 100% of invalid transactions.

### 6.3 Maintainability Requirements

**NFR-Maintainability-001**: The code must follow Rust idioms and best practices.

**NFR-Maintainability-002**: All public APIs must have comprehensive documentation.

**NFR-Maintainability-003**: The system must have at least 80% unit test coverage.

## 7. Appendix: Code Examples

### 7.1 Full SpendTx Validation Example

*Implementation Location*: `src/core/tx/spend.rs`

```rust
impl SpendTx {
    /// Validates a SpendTx transaction according to the rules in Coins__Tx_Structure.pdf
    /// 
    /// Validation steps (as per document section "Алгоритм проверки"):
    /// 1. Domain tag verification
    /// 2. Inclusion proof for input coins
    /// 3. Ownership signature verification (sig_eph)
    /// 4. Link tag proof verification
    /// 5. Blacklist check for link_tag
    /// 6. Nullifier uniqueness check
    /// 7. Pedersen balance verification (C_in == Σ C_out_i)
    /// 
    /// # Arguments
    /// * `state` - Current blockchain state containing Merkle trees and nullifier set
    /// 
    /// # Returns
    /// * `Ok(())` if transaction is valid
    /// * `Err(TransactionError)` if validation fails
    pub fn validate(&self, state: &TransactionState) -> Result<(), TransactionError> {
        // 1. Domain tag verification
        if self.domain_tag != DomainTag::Spend {
            return Err(TransactionError::InvalidDomainTag);
        }

        // 2. Inclusion proof for input coins and ownership verification
        for input in &self.inputs {
            // Verify inclusion proof
            if !state.coin_tree.verify(&input.context_id, &input.inclusion_proof, &input.commitment) {
                return Err(TransactionError::InvalidInclusionProof);
            }

            // Verify ownership signature (sig_eph)
            let message = format!("{}{}", self.domain_tag.as_str(), self.tx_body_hash());
            if !verify_schnorr(&input.commitment.point, &message, &input.sig_eph) {
                return Err(TransactionError::InvalidOwnershipProof);
            }

            // Verify link tag proof
            if !verify_link_tag(&input.commitment.point, &input.link_tag, &input.link_proof, &self.tx_id) {
                return Err(TransactionError::InvalidLinkProof);
            }

            // Check blacklist
            if state.blacklist.contains(&input.link_tag) {
                return Err(TransactionError::BlacklistedLinkTag);
            }

            // Check nullifier uniqueness
            if state.nullifier_set.contains(&input.nullifier) {
                return Err(TransactionError::DoubleSpend);
            }
        }

        // 7. Pedersen balance verification (C_in == Σ C_out_i)
        if !self.verify_pedersen_balance() {
            return Err(TransactionError::InvalidBalance);
        }

        Ok(())
    }
}
```

### 7.2 Full ACK Processing Example

*Implementation Location*: `src/core/tx/ack.rs`

```rust
impl Ack {
    /// Creates a ChallengeInvalid transaction if fraud is detected
    pub fn create_challenge_invalid(
        &self,
        spend_tx: &SpendTx,
        state: &TransactionState
    ) -> Result<ChallengeInvalid, ChallengeError> {
        // 1. Verify that the SpendTx doesn't match the ACK
        if spend_tx.outputs != self.outputs {
            return Err(ChallengeError::OutputMismatch);
        }
      
        // 2. Verify that the nullifier wasn't used
        for input in &spend_tx.inputs {
            if state.nullifier_set.contains(&input.nullifier) {
                return Err(ChallengeError::NullifierAlreadyUsed);
            }
        }
      
        // 3. Create the challenge
        Ok(ChallengeInvalid {
            domain_tag: DomainTag::Challenge,
            ack_id: self.ack_id,
            sig_ack: self.sig_ack.clone(),
            inputs_ack: spend_tx.inputs.clone(),
            proofs_coin: Vec::new(), // Would be filled with actual proofs
            proof_absence_null: VerkleNonProof::new(),
            penalty_due: calculate_penalty(spend_tx),
            sig_bob: SchnorrSignature::new(), // Would be properly signed
            deposit: CHALLENGE_DEPOSIT,
        })
    }
  
    /// Processes a ChallengeInvalid transaction
    pub fn process_challenge(
        &self,
        challenge: &ChallengeInvalid,
        state: &mut TransactionState
    ) -> Result<(), ChallengeProcessingError> {
        // 1. Verify the challenge signature
        if !challenge.verify_signature() {
            return Err(ChallengeProcessingError::InvalidSignature);
        }
      
        // 2. Verify the challenge data matches our ACK
        if challenge.ack_id != self.ack_id || challenge.sig_ack != self.sig_ack {
            return Err(ChallengeProcessingError::InvalidChallengeData);
        }
      
        // 3. Blacklist the link tag
        for input in &challenge.inputs_ack {
            state.blacklist.add_link_tag(input.link_tag);
        }
      
        // 4. Apply penalty
        state.penalty_system.apply_penalty(
            challenge.penalty_due,
            &challenge.inputs_ack[0].link_tag
        );
      
        Ok(())
    }
}
```

### 7.3 Test Cases

*Implementation Location*: `src/core/tx/spend.rs`

```rust
#[cfg(test)]
mod tests {
    use super::*;
    use crate::core::crypto::commitments::pedersen::{PedersenGens, PedersenCommitment};
    use crate::core::crypto::keys::{KeyPair, generate_keys};
  
    #[test]
    fn test_spend_tx_validation() {
        // Test case based on "Пошаговый пример «Алиса → Боб 30 Z00Z»" from document
      
        // 1. Setup: Create test keys and commitments
        let (sk_alice, pk_alice) = generate_keys();
        let (sk_bob, pk_bob) = generate_keys();
        let gens = PedersenGens::default();
      
        // 2. Create input coin (Alice's coin)
        let input_value = 30;
        let input_commitment = gens.commit(input_value, &sk_alice);
        let input_context_id = [0u8; 32]; // Simplified for test
      
        // 3. Create output coins (Bob's coin and change)
        let output_commitment_bob = gens.commit(30, &sk_bob);
        let output_commitment_change = gens.commit(0, &sk_alice); // No change in this simple example
      
        // 4. Create SpendTx
        let spend_tx = SpendTx {
            domain_tag: DomainTag::Spend,
            inputs: vec![CoinInput {
                context_id: input_context_id,
                commitment: input_commitment,
                inclusion_proof: MerkleProof::new(), // Simplified
                sig_eph: SchnorrSignature::new(), // Would be properly signed in real implementation
                link_tag: CompressedRistretto::from_uniform_bytes(&[0u8; 32]),
                link_proof: SchnorrSignature::new(),
                nullifier: [1u8; 32],
            }],
            outputs: vec![
                CoinOutput {
                    context_id: [2u8; 32],
                    commitment: output_commitment_bob,
                    content_id: ContentId::native_Z00Z(),
                },
                CoinOutput {
                    context_id: [3u8; 32],
                    commitment: output_commitment_change,
                    content_id: ContentId::native_Z00Z(),
                },
            ],
            tx_id: [4u8; 32],
        };
      
        // 5. Create mock state
        let state = TransactionState {
            coin_tree: &MerkleTree::new(), // Simplified
            nullifier_set: &NullifierSet::new(),
            blacklist: &Blacklist::new(),
        };
      
        // 6. Validate transaction
        assert!(spend_tx.validate(&state).is_ok());
    }
  
    #[test]
    fn test_pedersen_balance_verification() {
        // Test case for "Pedersen‐баланс: C_in == Σ C_out_i"
        let gens = PedersenGens::default();
      
        // Create a SpendTx with valid balance
        let valid_tx = SpendTx {
            domain_tag: DomainTag::Spend,
            inputs: vec![CoinInput {
                context_id: [0u8; 32],
                commitment: gens.commit(30, &[0u8; 32]),
                inclusion_proof: MerkleProof::new(),
                sig_eph: SchnorrSignature::new(),
                link_tag: CompressedRistretto::from_uniform_bytes(&[0u8; 32]),
                link_proof: SchnorrSignature::new(),
                nullifier: [1u8; 32],
            }],
            outputs: vec![
                CoinOutput {
                    context_id: [1u8; 32],
                    commitment: gens.commit(20, &[0u8; 32]),
                    content_id: ContentId::native_Z00Z(),
                },
                CoinOutput {
                    context_id: [2u8; 32],
                    commitment: gens.commit(10, &[0u8; 32]),
                    content_id: ContentId::native_Z00Z(),
                },
            ],
            tx_id: [3u8; 32],
        };
      
        assert!(valid_tx.verify_pedersen_balance());
      
        // Create a SpendTx with invalid balance
        let invalid_tx = SpendTx {
            domain_tag: DomainTag::Spend,
            inputs: vec![CoinInput {
                context_id: [0u8; 32],
                commitment: gens.commit(30, &[0u8; 32]),
                inclusion_proof: MerkleProof::new(),
                sig_eph: SchnorrSignature::new(),
                link_tag: CompressedRistretto::from_uniform_bytes(&[0u8; 32]),
                link_proof: SchnorrSignature::new(),
                nullifier: [1u8; 32],
            }],
            outputs: vec![
                CoinOutput {
                    context_id: [1u8; 32],
                    commitment: gens.commit(25, &[0u8; 32]),
                    content_id: ContentId::native_Z00Z(),
                },
                CoinOutput {
                    context_id: [2u8; 32],
                    commitment: gens.commit(10, &[0u8; 32]),
                    content_id: ContentId::native_Z00Z(),
                },
            ],
            tx_id: [3u8; 32],
        };
      
        assert!(!invalid_tx.verify_pedersen_balance());
    }
}
```

## 8. Conclusion

This SRS document provides a comprehensive specification for the Z00Z transaction structure system. It details all functional requirements with clear implementation guidance, including Rust code examples that map to specific files in the project structure.

The document is designed to be understandable for junior developers, providing enough detail to implement the transaction system without requiring deep knowledge of the underlying cryptography. Each requirement is accompanied by code examples that show exactly how the functionality should be implemented.

By following this SRS, developers can implement a transaction structure that meets all the requirements specified in the Coins__Tx_Structure.pdf document while maintaining the system's stateless architecture, privacy guarantees, and security properties.

---

---




## 4. Use Cases

### 4.1 Alice Sends 30 Z00Z to Bob (Online)

1. Alice creates a SpendTx with inputs (her coins) and outputs (Bob's coin + change)
2. Alice signs the transaction with domain-separated signatures
3. Alice publishes the SpendTx to the network
4. Bob verifies the transaction using the network state
5. Bob updates his wallet to reflect the new balance

### 4.2 Alice Sends 30 Z00Z to Bob (Offline)

1. Alice creates an ACK with output details for Bob
2. Alice signs the ACK with domain-separated signature
3. Alice sends the encrypted ACK to Bob via secure channel
4. Bob verifies the ACK signature and stores it
5. When online, Alice publishes the SpendTx matching the ACK
6. Bob verifies the SpendTx matches his stored ACK

### 4.3 Bob Detects Fraudulent Transaction from Alice

1. Bob receives an ACK from Alice for 30 Z00Z
2. Alice publishes a SpendTx with different outputs than promised
3. Bob creates a ChallengeInvalid transaction with:
   - The original ACK
   - Proof of mismatched outputs
   - Proof of non-existence of nullifier
4. The network verifies the challenge and:
   - Blacklists Alice's link tag
   - Requires Alice to pay penalty
   - Invalidates all future transactions with that link tag

### 4.4 Bob Fails to Receive Spent Transaction Before Deadline

1. Bob receives an ACK from Alice with deadline_height = 1000
2. Alice never publishes the SpendTx before block 1000
3. Bob creates a ChallengeNotSpent transaction with:
   - The ACK ID
   - Proof of outputs
   - Proof of non-existence of nullifier
4. The network verifies the challenge and:
   - Blacklists Alice's link tag
   - Requires Alice to pay penalty

## 5. Acceptance Criteria

### 5.1 Core Transaction Structure

- [ ] SpendTx must contain all mandatory fields as specified in section 3.1.1
- [ ] ACK must contain all mandatory fields as specified in section 3.1.2
- [ ] All domain tags must follow the "Z00Z_[TYPE]" format
- [ ] CoinInput must include valid link_tag and link_proof fields
- [ ] CoinOutput must include valid content_id for Multi-SEED support

### 5.2 Transaction Validation

- [ ] SpendTx validation must reject transactions with invalid domain tags
- [ ] SpendTx validation must reject transactions with invalid inclusion proofs
- [ ] SpendTx validation must reject transactions with invalid ownership signatures
- [ ] SpendTx validation must reject transactions with invalid link tag proofs
- [ ] SpendTx validation must reject transactions with reused nullifiers
- [ ] SpendTx validation must reject transactions with unbalanced Pedersen commitments
- [ ] ACK validation must reject expired ACKs
- [ ] ACK validation must reject ACKs with invalid signatures

### 5.3 Security Requirements

- [ ] Domain separation must prevent signature reuse across different transaction types
- [ ] System must detect and blacklist link tags from fraudulent transactions
- [ ] Nullifier set must efficiently prevent double spends
- [ ] ACK must remain off-chain and fully encrypted
- [ ] System must allow creation of ChallengeInvalid transactions for fraud detection

### 5.4 Edge Cases

- [ ] System must handle transactions with zero-value outputs
- [ ] System must handle transactions with multiple inputs and outputs
- [ ] System must handle ACK expiration gracefully
- [ ] System must handle network delays in ACK delivery
- [ ] System must prevent replay attacks through domain separation

## 6. Design Solution

### 6.1 High-Level Architecture

The transaction structure is implemented across three main modules:

- **Transaction Core**: Contains SpendTx and Coin structures
- **Validation Engine**: Contains validation logic for transactions
- **Security Layer**: Contains domain tag and cryptographic verification

```
core/
├── tx/
│   ├── mod.rs
│   ├── spend/
│   │   ├── mod.rs
│   │   ├── structure.rs
│   │   └── validation.rs
│   ├── ack/
│   │   ├── mod.rs
│   │   └── structure.rs
│   └── domain/
│       ├── mod.rs
│       └── tags.rs
```

### 6.2 Component Interactions

1. **Transaction Creation**:

   - Wallet creates SpendTx with inputs, outputs, and domain tag
   - Wallet generates link tags and proofs for each input
   - Wallet signs the transaction with domain-separated signatures
2. **Transaction Validation**:

   - Validation engine checks domain tag consistency
   - Validation engine verifies all proofs and signatures
   - Validation engine checks Pedersen balance
   - Validation engine checks nullifier set
3. **ACK Handling**:

   - Wallet creates ACK with outputs and deadline
   - Wallet signs ACK with "Z00Z_ACK" domain tag
   - Recipient verifies ACK signature and stores it
   - On-chain transaction must match stored ACK

### 6.3 Key Decisions

- **Domain Separation**: All cryptographic operations use domain tags to prevent signature reuse
- **Link Tag Structure**: Link tags use Schnorr proofs to connect transactions without revealing identity
- **Nullifier Design**: Nullifiers are derived from transaction inputs to prevent double spending
- **Pedersen Balance**: Input and output commitments must balance without revealing values

## 7. Verification Plan

### 7.1 Unit Testing

- [ ] Test SpendTx structure with valid inputs
- [ ] Test SpendTx validation with invalid domain tags
- [ ] Test SpendTx validation with invalid inclusion proofs
- [ ] Test SpendTx validation with invalid ownership signatures
- [ ] Test SpendTx validation with reused nullifiers
- [ ] Test SpendTx validation with unbalanced Pedersen commitments
- [ ] Test ACK structure with valid data
- [ ] Test ACK validation with expired deadlines
- [ ] Test ACK validation with invalid signatures

### 7.2 Integration Testing

- [ ] Test full transaction lifecycle from creation to validation
- [ ] Test offline payment scenario with ACK and SpendTx
- [ ] Test ChallengeInvalid creation and processing
- [ ] Test ChallengeNotSpent creation and processing
- [ ] Test link tag blacklisting after fraud detection

### 7.3 Security Testing

- [ ] Verify domain separation prevents signature reuse
- [ ] Verify link tag reuse is detectable and punishable
- [ ] Verify nullifier set efficiently prevents double spends
- [ ] Verify ACK remains off-chain and encrypted
- [ ] Verify Pedersen balance verification works without value disclosure

### 7.4 Performance Testing

- [ ] Measure validation time for transactions with 1-100 inputs/outputs
- [ ] Measure memory usage during validation
- [ ] Test nullifier set performance with 1M+ entries
- [ ] Test ACK verification performance with various deadlines
