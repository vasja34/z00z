# `z00z_core` Spec

## Table of Contents

1. [Prerequisites](#prerequisites)
2. [Mathematical Notation](#mathematical-notation)
3. [Task Understanding](#task-understanding)
4. [Genesis and Structure of Z00Z Coins](#genesis-and-structure-of-z00z-coins)
5. [Foundations and Terminology](#foundations-and-terminology)
6. [Genesis Constants](#genesis-constants)
7. [Z00Z Coin: Fields and Intent](#z00z-coin-fields-and-intent)
8. [Detailed Generator](#detailed-generator-build_genesis_state)
9. [Claim: Capturing a Coin](#claim-capturing-a-coin)
10. [SpendTx: Sending](#spendtx-sending)
11. [Mapping to Tari Fields](#mapping-to-tari-fields)
12. [Complete End-to-End Example](#complete-end-to-end-example)
13. [Off-chain vs On-chain Varieties](#off-chain-vs-on-chain-varieties)
14. [Summary](#summary)
15. [Tari-inspired Wallet Concepts](#tari-inspired-wallet-concepts-for-implementation-tasks)
16. [Crypto Primitives](#crypto-primitives-grounded-on-cratesz00z_cryptotari)
17. [Module Specifications](#module-specifications)
    - [types](#cratesz00z_coretypes)
    - [assets](#cratesz00z_coreassets)
    - [tx](#cratesz00z_coretx)
    - [validation](#cratesz00z_corevalidation)
    - [state](#cratesz00z_corestate)
    - [genesis](#cratesz00z_coregenesis)
18. [Tests and Scenarios](#tests-and-scenarios-summary)
19. [Common Pitfalls](#common-pitfalls)
20. [Implementation Checklist](#implementation-checklist)
21. [Conclusion](#conclusion)

---

## Prerequisites

Before implementing `z00z_core`, developers should have understanding of:

### Required Knowledge

1. **Mimblewimble Protocol**
   - Confidential transactions using Pedersen commitments
   - Transaction kernels and excess blinding factors
   - Cut-through property and UTXO aggregation
   - Reference: [Mimblewimble whitepaper](https://docs.beam.mw/Mimblewimble.pdf)

2. **Cryptographic Primitives**
   - **Pedersen Commitments**: `C = v·G + r·H` where:
     - `v` = value (amount)
     - `r` = blinding factor (random scalar)
     - `G`, `H` = generator points with unknown discrete log relationship
   - **Schnorr Signatures**: proving knowledge of secret key
   - **Bulletproofs**: zero-knowledge range proofs (0 ≤ v ≤ 2^64)
   - **Hash Functions**: Blake2b, SHA3 for deterministic derivations

3. **Rust Ecosystem**
   - `tari_crypto` library and its abstractions
   - `tari_bulletproofs` for range proofs
   - Error handling with `Result<T, E>` and `anyhow`
   - Serialization with `bincode` or `borsh`

4. **Verkle Trees** (conceptual)
   - Vector commitment schemes
   - Efficient membership/non-membership proofs
   - State root computation

### Recommended Reading

- `docs/001-TLD/z00z_med-level-design-v1.md` section 6.2 - High-level design of z00z_core
- `crates/z00z_crypto/tari/` - Available cryptographic primitives
- Tari protocol documentation - Reference implementation patterns (conceptual)
  - Transaction structures (inputs, outputs, kernels)
  - Validation pipeline architecture
  - UTXO model and state management

### Skill Level

This specification targets **junior-to-mid level Rust developers** with:
- 6+ months Rust experience
- Basic cryptography understanding
- Familiarity with blockchain UTXO model
- Ability to read academic papers and apply concepts

---

## Mathematical Notation

This document uses consistent mathematical notation throughout:

### Operators and Symbols

| Symbol | Meaning | Example |
|--------|---------|----------|
| `·` | Scalar multiplication on elliptic curve | `v·G` = point G multiplied by scalar v |
| `+` | Point addition on elliptic curve | `C = v·G + r·H` |
| `∥` or `||` | Concatenation of byte arrays | `seed ∥ index` |
| `Σ` | Summation | `ΣCin` = sum of all input commitments |
| `←$` | Random sampling from set | `r ←$ Fq` = random scalar |
| `Hash(...)` | Cryptographic hash function (Blake2b) | `nullifier = Hash(...)` |
| `HMAC(...)` | Keyed hash for derivation | `spend_key = HMAC(seed, data)` |

### Curve Points and Scalars

- **G, H**: Generator points on Ristretto255 curve
  - `G` = primary generator
  - `H` = secondary generator (nothing-up-my-sleeve construction)
  - Property: discrete log `k` where `H = k·G` is unknown

- **Scalar**: Element of field Fq (mod curve order)
  - Size: 32 bytes
  - Type: `RistrettoSecretKey` in code

- **Point**: Element of Ristretto255 group
  - Size: 32 bytes compressed
  - Type: `RistrettoPublicKey` in code

### Commitment Notation

```
C = v·G + r·H
```

Where:
- `C` = Commitment (curve point)
- `v` = Value/amount (scalar, typically u64)
- `r` = Blinding factor (random scalar)
- `G, H` = Generator points

**Homomorphic Property**:
```
C1 + C2 = (v1·G + r1·H) + (v2·G + r2·H) 
        = (v1+v2)·G + (r1+r2)·H
```

### Balance Equation

```
ΣCin - ΣCout - fee·H = kernel.excess
```

Where:
- `ΣCin` = Sum of input commitments
- `ΣCout` = Sum of output commitments  
- `fee·H` = Fee commitment (fee is public, blinding=0)
- `kernel.excess` = Excess commitment (proves balance)

### Nullifier Derivation

**Two contexts exist** (see [issue #2](#fix-nullifier-derivation-inconsistency)):

1. **Simplified notation** (conceptual):
   ```
   nullifier = Hash(spend_key || commitment || "Z00Z_NULLIFIER")
   ```

2. **Full implementation** (in code):
   ```rust
   fn derive_nullifier(output: &Output, nonce: &[u8]) -> Nullifier {
       Blake2b(
           nonce || 
           output.features.flags || 
           output.features.metadata || 
           output.commitment
       )
   }
   ```

**Resolution**: The simplified form is used in documentation for clarity. In practice, `spend_key` influences the `nonce` parameter, and `features` are included for replay protection.

---

## Task Understanding

- Create a detailed implementation guide for `crates/z00z_core` and its auxiliary modules (`assets`, `genesis`, `state`, `tx`, `types`, `validation`) based on the descriptions in `docs/001-TLD/z00z_med-level-design-v1.md` (section 6.2 and subsections).
- Source all cryptographic primitives from `crates/z00z_crypto/tari` which contains ported Tari cryptographic code (Pedersen commitments, Schnorr signatures, Bulletproofs).
- Use Tari protocol as conceptual reference for transaction structures, validation patterns, and UTXO management.
- Deliver a step-by-step checklist for a junior developer covering the required types, functions, invariants, and tests to fulfill the Mimblewimble-like core requirements without DA or consensus logic.

## Foundations and terminology

| Concept                              | Source in specification                                | Tari analog (conceptual)               | Comment                                                      |
| ------------------------------------ | ------------------------------------------------------ | -------------------------------------- | ------------------------------------------------------------ |
| `CoinOutput`                         | `assets::CoinOutput`, `assets::CoinFeatures`           | TransactionOutput                      | commitment and range proof plus metadata                     |
| `Input`                              | `tx::Input`                                            | TransactionInput (with InputFeatures)  | part of `Transaction`, includes `nullifier`, `nonce`, `proof_of_possession` |
| `Transaction`, `Kernel`              | `tx::Transaction`, `tx::Kernel`                        | Transaction (inputs, outputs, kernels) | balance `ΣCin - ΣCout - fee·H = kernel.excess` verified by `validation::BalanceValidator` |
| `EpochState`, `BatchMeta`, `UtxoSet` | `state::EpochState`, `tx::BatchMeta`, `state::UtxoSet` | Chain state management                 | manage roots, counters, and mixers (G1-G4)                   |

This specification is the foundation; this prose provides examples, pseudocode, and Tari references to make genesis and early transactions deterministic.


## Genesis and structure of **Z00Z** coins

This document shows how the sections of `specs/002-z00z-core/z00z-core-spec.md` map to actual implementations, from `CoinOutput` through `EpochState`. Every part highlights the link between `crates/z00z_core`, `crates/z00z_crypto/tari`, and the UTXO paradigm inspired by Tari's transaction model.

---

## Genesis constants

```rust
pub const GENESIS_NUM_COINS: usize = 50_000;
pub const GENESIS_COIN_NOMINAL: Amount = 200_000;
pub const GENESIS_EPOCH: EpochId = 0;
pub const PROTOCOL_SEED: &[u8; 16] = b"Z00Z_GENESIS_2025";
```

`GENESIS_TOTAL_SUPPLY = GENESIS_NUM_COINS * GENESIS_COIN_NOMINAL` is stored in `state::EpochState.total_supply` and is immutable.

## Z00Z coin: fields and intent

| Field        | Type                                                        | Purpose                                              | Correspondence in specification                                                |
| --------------- | ------------------------------------------------------------- | ----------------------------------------------------------------- | --------------------------------------------------------------------------------------------------- |
| `context_id`  | `Scalar` (`hash(PROTOCOL_SEED ∥ index)`)                 | key for the Merkle tree                               | described in the `context_id` and `MerkleCoinSet` discussion                         |
| `commitment`  | `Commitment` (`PedersenGens::commit_value`)               | hides the value `v`                                 | `assets::CoinOutput.commitment`                                                               |
| `range_proof` | `RangeProof`                                                | guarantees `0 <= v <= MAX`                          | `RangeProofValidator`                                                                             |
| `features`    | `OutputFeatures` (`lock_height`, `metadata`, `nonce`) | participates in `derive_nullifier`                        | additional fields for scripts, timing, and signatures |
| `nullifier`   | `Hash(nonce ∥ commitment ∥ extras)`                       | appears after the claim                             | `tx::derive_nullifier`, validated by `InputsExistValidator`                           |
| `status`      | `pending / confirmed / spent`                               | wallet tracks the lifecycle | local tag reflecting `state`                                           |

`OfflineCoinRecord` tracks `output: CoinOutput`, `owner_pub: PublicKey`, `proof_of_possession: KernelSignature`, `slashed: bool`, and `offline_metadata: Option<OfflineMeta>`. The spec requires wallets to set `slashed = true` on double spends, retain `offline_metadata` (origin slot / counter / DA proof), and only exchange the record when connectivity returns.

## Detailed generator (`build_genesis_state`)

1. Initialize `PedersenGens::default()` and `BulletproofGens::new(64, 1)`.
2. `ChaChaRng::from_seed(seed)` ensures repeatability; `seed` is stored in `EpochMeta.entropy_seed`.
3. Loop over `0..GENESIS_NUM_COINS`:
   - `context_id = hash_to_scalar(seed ∥ index)`.
   - `blinding = BlindingFactor::random(&mut rng)`.
   - `commitment = gens.commit_value(GENESIS_COIN_NOMINAL, blinding)`.
   - `proof = RangeProof::prove_single(...)`.
   - `output = CoinOutput::new_from_parts(commitment, proof, OutputFeatures::default(), None)`.
   - `epoch_state.utxo_set.insert(context_id.clone(), output.clone())` and `epoch_state.counters.output_count += 1`.
4. After the loop `EpochState.total_supply`, `utxo_root`, `spent_root` are calculated and stored.

### Pseudocode

```rust
let mut rng = ChaChaRng::from_seed(seed);
let gens = PedersenGens::default();
let mut epoch_state = EpochState::default();
for index in 0..GENESIS_NUM_COINS {
    let context_id = hash_to_scalar(seed.concat(&index.to_be_bytes()));
    let blinding = BlindingFactor::random(&mut rng);
    let commitment = gens.commit_value(GENESIS_COIN_NOMINAL, blinding);
    let proof = RangeProof::prove_single(&gens, &BulletproofGens::new(64, 1), GENESIS_COIN_NOMINAL, &blinding);
    let output = CoinOutput::new(commitment, proof, OutputFeatures::default(), None)?;

    epoch_state.utxo_set.insert(context_id.clone(), output.clone());
    epoch_state.counters.output_count += 1;
}
epoch_state.total_supply = GENESIS_NUM_COINS as Amount * GENESIS_COIN_NOMINAL;
epoch_state.meta = EpochMeta::genesis(seed);
epoch_state.utxo_root = epoch_state.utxo_set.root_hash();
```

> `CoinOutput::new` relies on `PedersenGens::commit_value` and `RangeProof::prove_single`, while `OutputFeatures.nonce` seeds future `nullifier`s.

## Claim: capturing a coin

A genesis coin is `context_id → commitment` with no `nullifier`. Claiming moves it under personal control:

1. `context_id` is looked up from the `build_genesis_state` table.
2. Generate `spend_key = HMAC(sk_user, context_id || value || r)` (a `SecretKey` from `tari_crypto`).
3. Compute `nullifier = Hash(spend_key || commitment || "Z00Z_NULLIFIER")` (similar concept to Tari's OutputId but with Z00Z-specific derivation).
4. Construct a `Input` with `proof_of_possession` and `nonce`.
5. Publish a `SpendTx` paired with the corresponding `Kernel`.

### Claim math details

- **Unified Nullifier Derivation**: The system uses a two-stage approach:
  
  1. **User-facing (conceptual)**:
     ```
     spend_key = HMAC(sk_user, context_id || v || r)
     nullifier = Hash(spend_key || commitment || "Z00Z_NULLIFIER")
     ```
     This shows the logical dependency: the nullifier binds to the user's secret.
  
  2. **Implementation (in `tx::derive_nullifier`)**:
     ```rust
     fn derive_nullifier(output: &Output, nonce: &[u8]) -> Nullifier {
         Blake2b(
             nonce ||                      // Derived from spend_key
             output.features.flags ||      // Replay protection
             output.features.metadata ||   // Context binding
             output.commitment             // Output identity
         )
     }
     ```
     
  
  The `nonce` parameter in the implementation is derived from `spend_key`, so both formulas are equivalent. The implementation adds `features.flags` and `features.metadata` for additional replay protection and metadata binding, preventing the same output from being claimed multiple times with different conditions.
  
- The claim message `Hash("CLAIM" || context_id || commitment || new_commitment || pk_spender)` is signed via a Schnorr signature built from the prover's `spend_key`, as shown in the example (use `tari_crypto::signatures::SchnorrSignature` helpers for `T = v·G`, challenge `c`, response `r`). This ensures the wallet claiming the coin proves knowledge of `spend_key`/`sk_spender`.

### Alice → Bob (invoice/stealth path)

1. **Invoice address:** Bob generates a single-use `P_invoice = g^x_bob` and shares it via messenger/QR. Alice treats that public key as `P_bob`.
2. **Stealth code (optional):** instead of a single-use address Bob publishes a permanent `payment_code = {scan_key, spend_key_pub}`. Alice picks random `k` and computes `P_bob = spend_key_pub + H(k·scan_key)·G`, hiding the link between payments.
3. **Applying to `SpendTx`:** Alice builds a `Transaction` with the input, new `nullifier`, outputs (`context_id_bob`, `context_id_change`), kernels, and offset; `P_bob`/`P_change` generate the stealth `Output` commitments similar to `genesis_tx_structures-Z00Z (copy).md`.
4. **Broadcast:** The `SpendTx` is signed, blinding factors are encrypted, and the transaction is sent into the p2p network; validators check the `nullifier`, range proof, kernel signature, and update both `utxo_root` and `spent_root`.

### Balance equation

`ΣCin - ΣCout - fee·H = kernel.excess` is verified by `validation::BalanceValidator` and signed by `tari_crypto::signatures::SchnorrSignature`.

## SpendTx: sending

| Component | Content                             | Reflection in specification                     |
| ------------------ | ------------------------------------------------ | ------------------------------------------------------------------ |
| inputs             | `Input` with `nullifier`                   | `tx::Input`, validated by `InputsExistValidator` |
| outputs            | `Output` for 30 and 70 Z00Z                | `tx::Output` with range proof, features                        |
| kernels            | `Kernel` with `excess`, `fee`, `flags` | `tx::Kernel`, validated by `KernelSignatureValidator`  |
| offset             | conceals global blinding   | used during summation           |

After publication, `state.utxo_root`, `state.spent_root`, `EpochState.counters` are updated.

### ACK and wallet observability

- **ACK #1 (mempool)**: wallets immediately treat outputs as `pending` when a `SpendTx` hits the mempool and primary script signatures + `nullifier` pass validation.
- **ACK #2 (block)**: after the next block includes the tx, the wallet moves outputs to `confirmed`. This mirrors the description where Alice and Bob watch mempool and block roots for status transitions.
- Wallets scan new commitments added to the state (Verkle tree entries) by trying to open them with their known secrets (`x_bob`, `x_change`). When `G·value + H·r` matches, that output gets linked to the owner. Observers need this step because the ledger no longer annotates the recipient – only the secret key reveals the link.

## Mapping to Tari fields

| Tari entity                                                  | Z00Z equivalent                                              | Notes                                                        |
| ------------------------------------------------------------ | ------------------------------------------------------------ | ------------------------------------------------------------ |
| `Transaction` (`offset`, `script_offset`, `body`)            | `Transaction` (`offset`, `kernels`, `inputs`, `outputs`)     | `script_offset`/`script_signature` capture script proofs and should be carried in `Kernel` metadata. |
| `TransactionInput` (`version`, `SpentOutput`, `script_signature`) | `Input` (`nullifier`, `proof_of_possession`, optional metadata`)             | `SpentOutput` data (features, metadata_signature, rangeproof_hash, minimum_value_promise) becomes part of `Output.features`/`metadata` when a `Claim` turns into a `SpendTx`. |                                                              |
| `TransactionOutput` (`features`, `commitment`, `proof`, `script`, `metadata_signature`, `minimum_value_promise`) | `Output` (`range_proof`, `OutputFeatures`, `metadata`, `nonce`) | All fields replicate: `script` → `OutputFeatures.script`, `metadata_signature` → `metadata.signature`, `minimum_value_promise` → `features.minimum_value`. |
| `TransactionKernel` (`excess`, `excess_sig`, `fee`, `kernel.features`, `burn_commitment`) | `Kernel` (`excess`, `signature`, `fee`, `flags`, optional burn markers`) | Kernel flags from `BatchMeta`/`KernelFeatures` map to `KernelFlags`, while `burn_commitment` sets `is_burned` in `OutputFeatures`. |                                                              |
| `EpochState` (`utxo_root`, `spent_root`, `total_supply`, `counters`) | `state::EpochState` (same fields plus `BatchMeta`)           | `counters` (`input_count`, `output_count`, `kernel_count`) are maintained during genesis and after every `SpendTx`. |

## Complete End-to-End Example

This section walks through a complete transaction flow with **concrete values**, showing genesis → claim → spend with actual cryptographic operations.

```mermaid
flowchart TD
    G["Genesis UTXO<br/>(context_id, commitment,<br/>ownerless)"]
    C["Claim tx<br/>input: genesis coin<br/>output: Alice coin<br/>kernel: balance proof<br/>nullifier_genesis"]
    A["Alice UTXO<br/>(commitment_A, owner Alice)"]
    S["Spend tx<br/>input: Alice coin<br/>outputs: Bob + change<br/>fee + kernel<br/>nullifier_alice"]
    B["Bob UTXO"]
    CH["Alice change UTXO"]
    SR["Spent set<br/>(nullifier list)"]

    G -->|"lookup by context_id"| C
    C -->|"apply_tx()"| A
    C -->|"write nullifier_genesis"| SR

    A -->|"used as input"| S
    S -->|"apply_tx()"| B
    S -->|"apply_tx()"| CH
    S -->|"write nullifier_alice"| SR

```



### Setup: Cryptographic Parameters

```rust
// Curve generators (fixed, nothing-up-my-sleeve)
G = RistrettoPoint::generator();
H = RistrettoPoint::from_hash(Blake2b("Z00Z_H_GENERATOR"));

// Genesis constants
GENESIS_SEED = b"Z00Z_GENESIS_2025";
GENESIS_COIN_VALUE = 200_000; // Z00Z units
```

---

### Phase 1: Genesis - Creating Coin #42

```rust
// 1. Generate deterministic context_id
index = 42;
context_id = Blake2b(GENESIS_SEED || index.to_be_bytes());
// Result: context_id = 0x7a3f9e2c...d18b (32 bytes)

// 2. Random blinding factor (from ChaChaRng seeded by GENESIS_SEED)
r_genesis = Scalar::from_bytes([0x3a, 0x7f, 0xe1, ...]) // 32 random bytes
// Result: r_genesis = 0x3a7fe1...9c2d

// 3. Create Pedersen commitment
C_genesis = GENESIS_COIN_VALUE * G + r_genesis * H
// Result: C_genesis = RistrettoPoint(0x4b8d2a...7f3e)

// 4. Generate range proof
proof_genesis = RangeProof::prove_single(
    value: GENESIS_COIN_VALUE,
    blinding: r_genesis,
    generators: (G, H)
);
// Result: 672-byte Bulletproof

// 5. Create output
output_genesis = CoinOutput {
    commitment: C_genesis,
    range_proof: proof_genesis,
    features: OutputFeatures {
        lock_height: 0,
        metadata: None,
        nonce: [0u8; 32], // No owner yet
    },
};

// 6. Insert into state
epoch_state.utxo_set.insert(context_id, output_genesis);
epoch_state.counters.output_count += 1;
```

**State after genesis:**
```yaml
UTXO Set:
  context_id: 0x7a3f9e2c...d18b
    commitment: 0x4b8d2a...7f3e
    value: 200000 (hidden)
    blinding: 0x3a7fe1...9c2d (hidden)
    status: confirmed
    owner: none (unclaimed)
```

---

### Phase 2: Alice Claims Coin #42

Alice discovers coin #42 from a public registry and decides to claim it.

```rust
// Alice's secrets
sk_alice = Scalar::random(); // 0x9d2c8b...4a1f
// Result: sk_alice = 0x9d2c8b4e...4a1f

// 1. Derive spend_key for this specific coin
spend_key = HMAC_Blake2b(
    key: sk_alice,
    data: context_id || GENESIS_COIN_VALUE || r_genesis
);
// Result: spend_key = 0x6f2a8d...9e3c

// 2. Generate new blinding factor for Alice's output
r_alice = Scalar::random(); // 0x8c3f2d...7b1a

// 3. Create new commitment (same value, new blinding)
C_alice = GENESIS_COIN_VALUE * G + r_alice * H
// Result: C_alice = RistrettoPoint(0x2d9f7a...8c4e)

// 4. Compute nullifier (marks genesis coin as spent)
nonce_alice = Blake2b(spend_key || "CLAIM_NONCE");
nullifier_genesis = Blake2b(
    nonce_alice ||
    output_genesis.features.flags ||
    output_genesis.features.metadata ||
    C_genesis
);
// Result: nullifier_genesis = 0xa4c7e9...2f1b

// 5. Build claim transaction
// Input: genesis coin
input = Input {
    committed_output: C_genesis,
    nonce: nonce_alice,
    proof_of_possession: None, // Added below
};

// Output: Alice's new coin
output_alice = Output {
    commitment: C_alice,
    range_proof: RangeProof::prove_single(GENESIS_COIN_VALUE, r_alice, (G,H)),
    features: OutputFeatures {
        lock_height: 0,
        metadata: Some(b"alice_claim".to_vec()),
        nonce: nonce_alice,
    },
};

// 6. Build kernel (proves balance)
// Balance: C_genesis = C_alice + 0 (no fee for simplicity)
// Excess: e = r_genesis - r_alice
excess_blinding = r_genesis - r_alice;
kernel_excess = excess_blinding * G;

// Sign the transaction
msg = Blake2b(
    "CLAIM" ||
    context_id ||
    C_genesis ||
    C_alice ||
    spend_key * G // Alice's public key
);
kernel_signature = SchnorrSignature::sign(excess_blinding, msg);

kernel = Kernel {
    excess: kernel_excess,
    signature: kernel_signature,
    fee: 0,
    lock_height: None,
    flags: KernelFlags::None,
};

// 7. Complete transaction
claim_tx = Transaction {
    inputs: vec![input],
    outputs: vec![output_alice],
    kernels: vec![kernel],
    offset: Scalar::zero(), // Simplified
};
```

**Validation checks:**
```rust
// ✓ Balance equation
assert_eq!(C_genesis, C_alice + 0*H + kernel.excess);

// ✓ Kernel signature valid
assert!(kernel.signature.verify(msg, kernel.excess));

// ✓ Range proof valid
assert!(output_alice.range_proof.verify());

// ✓ Nullifier not seen before
assert!(!epoch_state.spent_root.contains(nullifier_genesis));
```

**State after claim:**
```yaml
UTXO Set:
  # Genesis coin removed
  - context_id: 0x7a3f9e2c...d18b (REMOVED)
  
  # Alice's new coin added
  + commitment: 0x2d9f7a...8c4e
    value: 200000 (hidden)
    blinding: 0x8c3f2d...7b1a (hidden, Alice knows)
    status: confirmed
    owner: Alice (only she knows r_alice)

Spent Set:
  + nullifier_genesis: 0xa4c7e9...2f1b

Counters:
  input_count: 1
  output_count: 2 (genesis + alice)
  kernel_count: 1
```

---

### Phase 3: Alice Sends 100k Z00Z to Bob

Alice wants to split her 200k Z00Z: send 100k to Bob, keep 100k as change.

```rust
// Bob's public invoice address
P_bob = RistrettoPoint(0x5e7c8d...3a2f); // Bob shared via QR code

// 1. Alice creates two outputs
r_bob = Scalar::random();    // 0x4d8c7a...9e2b
r_change = Scalar::random(); // 0x7f3a9d...5c1e

C_bob = 100_000 * G + r_bob * H;
C_change = 100_000 * G + r_change * H;

// 2. Alice's input (her claimed coin)
nonce_spend = Blake2b(spend_key || "SPEND_NONCE" || timestamp);
nullifier_alice = Blake2b(
    nonce_spend ||
    output_alice.features.flags ||
    output_alice.features.metadata ||
    C_alice
);

input_alice = Input {
    committed_output: C_alice,
    nonce: nonce_spend,
    proof_of_possession: Some(kernel_sig), // Proves Alice's ownership
};

// 3. Build outputs
output_bob = Output {
    commitment: C_bob,
    range_proof: RangeProof::prove_single(100_000, r_bob, (G,H)),
    features: OutputFeatures::default(),
};

output_change = Output {
    commitment: C_change,
    range_proof: RangeProof::prove_single(100_000, r_change, (G,H)),
    features: OutputFeatures::default(),
};

// 4. Build kernel with fee
fee = 100; // 100 Z00Z
// Balance: C_alice = C_bob + C_change + fee*H + excess
// => excess = r_alice - r_bob - r_change
excess_blinding = r_alice - r_bob - r_change;
kernel_excess = excess_blinding * G;

msg = Blake2b(
    inputs ||
    outputs ||
    fee ||
    kernel.lock_height
);
kernel_signature = SchnorrSignature::sign(excess_blinding, msg);

kernel = Kernel {
    excess: kernel_excess,
    signature: kernel_signature,
    fee: 100,
    lock_height: None,
    flags: KernelFlags::None,
};

// 5. Complete transaction
spend_tx = Transaction {
    inputs: vec![input_alice],
    outputs: vec![output_bob, output_change],
    kernels: vec![kernel],
    offset: Scalar::zero(),
};
```

**Validation:**
```rust
// ✓ Balance equation
let sum_in = C_alice;
let sum_out = C_bob + C_change;
let fee_commitment = 100 * H;
assert_eq!(sum_in, sum_out + fee_commitment + kernel.excess);

// ✓ Outputs sum correctly
assert_eq!(100_000 + 100_000 + 100, 200_000); // value check

// ✓ All range proofs valid
assert!(output_bob.range_proof.verify());
assert!(output_change.range_proof.verify());
```

**Final state:**
```yaml
UTXO Set:
  # Alice's coin removed
  - commitment: 0x2d9f7a...8c4e (REMOVED)
  
  # Bob's coin added
  + commitment: C_bob
    value: 100000 (hidden)
    owner: Bob (only he can scan with his keys)
  
  # Alice's change added
  + commitment: C_change
    value: 100000 (hidden)
    owner: Alice (she knows r_change)

Spent Set:
  + nullifier_alice: 0xf8d3c9...7a4e

Total Supply: 10_000_000_000 Z00Z (unchanged)
Total Fee Collected: 100 Z00Z

Counters:
  input_count: 2
  output_count: 4
  kernel_count: 2
```

---

### Key Observations

1. **Value Privacy**: No one can determine amounts without knowing blinding factors
2. **Balance Proof**: Kernel signature proves `Σinputs = Σoutputs + fee` without revealing values
3. **No Address Linkage**: Bob's output not linked to his identity on-chain
4. **Deterministic Genesis**: Same seed always produces same coins (testable)
5. **Compact State**: Only commitments stored, full transaction data can be pruned

---

## Example: claim + spend

```yaml
context_id: hash("Z00Z_GENESIS_2025" || 123)
commitment: 100_000·G + r·H
nullifier: hash(sk||commitment||"Z00Z_NULLIFIER")
status: pending
```

In the block:

- `nullifier` is written into `state.spent_root`.
- `context_id_bob` and `context_id_change` enter the `state.utxo_set`.
- `EpochState.counters` are updated.
- Observers (wallets) scan the updated `context_id` keys in the tree and match candidates with their secrets (`x_bob`, `x_change`) so they can move entries from `pending` to `confirmed` without publishing addresses.

## Off-chain vs. on-chain varieties

| Hypothesis     | On-chain (Tari)                                                        | Off-chain (Z00Z)                                                                               |
| -------------------- | ---------------------------------------------------------------------- | ---------------------------------------------------------------------------------------------- |
| Publication | every UTXO is immediately in the block                             | coins are minted once and remain "ownerless" |
| Owner     | tied to the on-chain output               | established only after a `claim`                               |
| Verification     | centralized per block            | via the `ValidationPipeline` and `EpochState`                                            |
| Examples       | Tari TransactionOutput (conceptual) | `CoinOutput` + `OfflineCoinRecord`                                                     |

An off-chain coin is a cash-like banknote: until its `nullifier` is published nobody knows the owner, but the cryptographic invariants are the same as in Tari.

## Summary

Z00Z coins are the same UTXO components found in Tari, temporarily held "in escrow" until a `claim` releases them. This structure enables genesis, transactions, and validation to follow the spec while preserving the off-chain cash semantics and compatibility with Tari cryptography.

## Tari-inspired wallet concepts (for implementation tasks)

- **Batch/block scanning with checkpoints** — Wallet scanning should perform loops that limit work by `max_blocks`/`batch_size`, handle reorgs, and log periodic progress. Adopt this pattern when describing how Z00Z wallets should scan the Verkle tree or DA layers: provide explicit controls for batch size, maximum lookback, and progress logging so feature owners understand how to avoid unbounded work.
- **SQL-backed wallet model** — Design wallet schema with tables for `accounts`, `outputs`, `inputs`, `balance_changes`, `events`, `scanned_tip_blocks`, and `pending_transactions`. Use column categories for status tracking, memo parsing, confirmation tracking, and request locking to guide spec writers on how to persist `OfflineCoinRecord` flows, ACK statuses, and double-spend markers without leaking private keys. Highlight the requirement to index by `context_id`/`output_hash` and to track `created_at`/`confirmed_height` for accurate history.
- **Encryption and keys** — README notes (`README.md` section “Security”) that wallet keys are encrypted with XChaCha20-Poly1305, padded to 32 bytes, and never leave the device. Capture this idea in the spec by describing how `OfflineCoinRecord` secrets (`owner_pub`, `spend_key`, `x_bob`) must be encrypted in storage and only decrypted temporarily for claiming/spending, mirroring Tari’s security posture.
- **Acknowledgements and UX** — Wallet scans should mark outputs as `pending` immediately and move them to `confirmed` after N blocks (e.g., 6), emitting events like `OutputDetected` + `OutputConfirmed`. Codify similar ACK phases in the spec so task writers know to wire up event flows and to expose `nullifier` writing only when both ACKs are satisfied.
- **Multi-account & migration hygiene** — Wallets should support multiple accounts per database with structured schema migrations. Recommend the `z00z` spec include requirements for multi-account handling (e.g., namespace per `OfflineCoinRecord`) and structured migrations for on-disk state so new fields (features, metadata, counters) can be rolled out safely.
- **UTXO scanning workflow pattern** — Implement a `UtxoScannerService` that runs periodic scanning loops (e.g., using `tokio::interval`) spawning scanner tasks each round. The scanner should walk from the last cached checkpoint, handle reorgs by clearing stale headers, and scan batches until the current tip while emitting progress events (`Progress`, `Completed`, `ScanningRoundFailed`). After each round, revalidate pending transactions to keep `pending`/`confirmed` states consistent even after reorgs.
- **Event-driven transaction service ACKs** — Implement a `TransactionService` that watches multiple event streams (output manager, node service, UTXO scanner, client requests) inside a `tokio::select!` loop, coordinating async handles for send/receive/broadcast/validation protocols. Define a `TransactionEvent` enum with variants like `DetectedTransactionUnconfirmed`, `DetectedTransactionConfirmed`, `TransactionBroadcast`, and `TransactionMined`. The ACK sequence: mempool notice raises unconfirmed event (pending ACK), block inclusion triggers confirmed event (final ACK). Use this pattern to ensure the state machine reacts to scanner updates, revalidation notifications, and output-manager events without blocking other requests.

## Crypto primitives grounded on `crates/z00z_crypto/tari`

This section details how to leverage existing Tari cryptographic primitives for Z00Z implementation.

### Architecture Overview

```mermaid
flowchart TD
    subgraph Z00Z_Core["z00z_core"]
        types["types"] --> assets["assets"]
        types --> tx["tx"]
        types --> state["state"]
        types --> validation["validation"]
        types --> genesis["genesis"]

        assets --> tx
        tx --> validation
        tx --> state
        genesis --> state
    end

    subgraph Crypto["z00z_crypto/tari (primitives)"]
        C["Commitments
        (Pedersen)"]
        S["Signatures
        (Schnorr, CommitmentSignature)"]
        R["Range proofs
        (Bulletproofs)"]
        H["Hashing
        (Blake2b)"]
    end

    assets --> C
    assets --> R

    tx --> S
    validation --> S
    validation --> R

    state --> H

```

### 1. Commitments and Keys

**Location**: `crates/z00z_crypto/tari/crypto/src/commitment.rs`, `keys.rs`

**Usage Example**:
```rust
use tari_crypto::{
    commitment::{HomomorphicCommitment, HomomorphicCommitmentFactory},
    keys::{PublicKey, SecretKey},
    ristretto::{RistrettoPublicKey, RistrettoSecretKey},
};

// Create commitment factory
let factory = PedersenCommitmentFactory::default();

// Generate blinding factor
let blinding = RistrettoSecretKey::random(&mut OsRng);

// Create commitment: C = v·G + r·H
let value = 100_000u64;
let commitment = factory.commit_value(&blinding, value);

// Commitment is now a RistrettoPublicKey (curve point)
assert_eq!(commitment.as_bytes().len(), 32);
```

**Type Mappings**:
```rust
// In z00z_core/types.rs
pub type BlindingFactor = RistrettoSecretKey;
pub type Commitment = HomomorphicCommitment<RistrettoPublicKey>;
```

**Key Operations**:
- `SecretKey::random()` - Generate random scalar
- `SecretKey::from_bytes()` - Deserialize from 32 bytes
- `PublicKey::from_secret_key()` - Derive public key from secret
- `commitment.as_bytes()` - Serialize to bytes (32 bytes)

### 2. Schnorr Signatures

**Location**: `crates/z00z_crypto/tari/crypto/src/signatures/`

Z00Z uses Schnorr signatures for:
- Kernel signatures (proving balance)
- Proof of possession (claiming coins)
- Authorization signatures (spending permissions)

**Standard Schnorr Example**:
```rust
use tari_crypto::signatures::{SchnorrSignature, SchnorrSignatureError};
use tari_crypto::ristretto::{RistrettoSecretKey, RistrettoPublicKey};

// Sign a message
let secret_key = RistrettoSecretKey::random(&mut OsRng);
let message = b"Transfer 100 Z00Z to Bob";

let signature = SchnorrSignature::sign(
    &secret_key,
    message,
    &mut OsRng
)?;

// Verify signature
let public_key = RistrettoPublicKey::from_secret_key(&secret_key);
assert!(signature.verify(&public_key, message));
```

**Commitment Signature Example** (for kernels):
```rust
use tari_crypto::signatures::CommitmentSignature;

// Create kernel signature
// Proves: I know r such that excess = r·G AND balance equation holds
let excess_blinding = r_in - r_out; // Sum of input blindings minus output blindings
let kernel_excess = RistrettoPublicKey::from_secret_key(&excess_blinding);

let message = Blake2b(
    tx.inputs.as_bytes() ||
    tx.outputs.as_bytes() ||
    tx.fee.to_be_bytes()
);

let kernel_signature = CommitmentSignature::sign(
    &excess_blinding,
    &message,
    &mut OsRng
)?;

// In z00z_core/tx.rs
pub struct Kernel {
    pub excess: Commitment,        // kernel_excess from above
    pub signature: KernelSignature, // kernel_signature
    pub fee: Fee,
    // ...
}
```

**Type Alias**:
```rust
pub type KernelSignature = CommitmentSignature<RistrettoPublicKey, RistrettoSecretKey>;
```

### 3. Range Proofs (Bulletproofs)

**Location**: `crates/z00z_crypto/tari/bulletproofs/src/range_proof/`

Range proofs ensure output values are in `[0, 2^64)` without revealing the value.

**Proving Example**:
```rust
use tari_bulletproofs::{
    BulletproofGens, PedersenGens, RangeProof,
};

// Setup (done once, reused)
let pc_gens = PedersenGens::default();
let bp_gens = BulletproofGens::new(64, 1); // 64-bit values, batch size 1

// Prove
let value = 100_000u64;
let blinding = Scalar::random(&mut OsRng);
let commitment = pc_gens.commit(Scalar::from(value), blinding);

let (proof, commitment_out) = RangeProof::prove_single(
    &bp_gens,
    &pc_gens,
    &mut transcript,
    value,
    &blinding,
    64, // bit length
)?;

// Proof is ~672 bytes for 64-bit range
assert!(proof.to_bytes().len() < 1024);
```

**Verification Example**:
```rust
// Verify (during validation)
let valid = proof.verify_single(
    &bp_gens,
    &pc_gens,
    &mut transcript,
    &commitment,
    64,
)?;

assert!(valid);
```

**Batch Verification** (optimization):
```rust
// Verify multiple proofs at once (faster)
let proofs: Vec<&RangeProof> = tx.outputs.iter()
    .map(|o| &o.range_proof)
    .collect();

let commitments: Vec<&Commitment> = tx.outputs.iter()
    .map(|o| &o.commitment)
    .collect();

RangeProof::verify_batch(
    &bp_gens,
    &pc_gens,
    &mut transcript,
    &proofs,
    &commitments,
    64,
)?;
```

**In `z00z_core/assets`**:
```rust
impl CoinOutput {
    pub fn verify_proof(&self, bp_gens: &BulletproofGens) -> Result<()> {
        let pc_gens = PedersenGens::default();
        let mut transcript = Transcript::new(b"Z00Z_RANGE_PROOF");
        
        self.range_proof.verify_single(
            bp_gens,
            &pc_gens,
            &mut transcript,
            &self.commitment,
            64,
        ).map_err(|e| ValidationError::InvalidRangeProof(e))
    }
}
```

### 4. Hashing Utilities

**Location**: `crates/z00z_crypto/tari/hashing`, `crates/z00z_crypto/tari/utils`

Z00Z uses Blake2b for all hashing (nullifiers, context_ids, state roots).

**Hash-to-Scalar** (for context_id):
```rust
use blake2::Blake2b;
use digest::Digest;
use tari_crypto::ristretto::RistrettoSecretKey;

fn hash_to_scalar(data: &[u8]) -> RistrettoSecretKey {
    let mut hasher = Blake2b::<U32>::new();
    hasher.update(data);
    let hash_bytes = hasher.finalize();
    
    // Interpret as scalar (mod curve order)
    RistrettoSecretKey::from_bytes(&hash_bytes)
        .expect("valid scalar from hash")
}

// Usage
let context_id = hash_to_scalar(&[GENESIS_SEED, &index.to_be_bytes()].concat());
```

**Nullifier Derivation**:
```rust
pub fn derive_nullifier(output: &Output, nonce: &[u8]) -> [u8; 32] {
    let mut hasher = Blake2b::<U32>::new();
    hasher.update(nonce);
    hasher.update(&output.features.flags.to_bytes());
    hasher.update(&output.features.metadata.unwrap_or_default());
    hasher.update(output.commitment.as_bytes());
    hasher.finalize().into()
}
```

**State Root Hashing** (deterministic):
```rust
pub fn compute_utxo_root(utxo_set: &BTreeMap<Nullifier, Output>) -> [u8; 32] {
    let mut hasher = Blake2b::<U32>::new();
    
    // BTreeMap iteration is sorted, ensuring determinism
    for (nullifier, output) in utxo_set.iter() {
        hasher.update(nullifier);
        hasher.update(output.commitment.as_bytes());
    }
    
    hasher.finalize().into()
}
```

### 5. Missing Primitives (Implemented in z00z_core)

The following are NOT in `tari_crypto` and must be implemented in `z00z_core`:

#### Nullifier Type
```rust
// In z00z_core/types.rs
pub type Nullifier = [u8; 32];

pub fn derive_nullifier(/* ... */) -> Nullifier {
    // Implementation as shown above
}
```

**Rationale**: Tari uses `OutputId` differently; Z00Z needs custom nullifier binding to `features` for replay protection.

#### EpochId and DaSlot
```rust
pub type EpochId = u64;
pub type DaSlot = u64;
pub type BatchId = u64;
```

**Rationale**: Z00Z-specific identifiers for DA layer integration, not present in Tari.

#### KernelFlags
```rust
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum KernelFlags {
    None,
    NoRecentDuplicate,
    Immature,
}
```

**Rationale**: Z00Z adds replay protection flags beyond Tari's `KernelFeatures`.

#### OutputFeatures Extensions
```rust
pub struct OutputFeatures {
    pub lock_height: u64,
    pub is_burned: bool,
    pub nonce: [u8; 32],
    pub script: Option<Vec<u8>>,
    pub metadata: Option<Vec<u8>>,
}
```

**Rationale**: Extends Tari's `OutputFeatures` with `nonce` for nullifier derivation and Z00Z-specific metadata.

### 6. Generator Setup

**CRITICAL**: All parties must use identical generators.

```rust
// In z00z_core/types.rs or constants module
use once_cell::sync::Lazy;
use tari_crypto::ristretto::RistrettoPoint;

/// Primary generator G (standard Ristretto generator)
pub static GENERATOR_G: Lazy<RistrettoPoint> = Lazy::new(|| {
    RistrettoPoint::generator()
});

/// Secondary generator H (nothing-up-my-sleeve)
/// Derived from hash of protocol identifier
pub static GENERATOR_H: Lazy<RistrettoPoint> = Lazy::new(|| {
    let bytes = Blake2b::digest(b"Z00Z_GENERATOR_H_v1");
    RistrettoPoint::from_uniform_bytes(&bytes)
});

// Pedersen generators (used throughout)
pub static PEDERSEN_GENS: Lazy<PedersenGens> = Lazy::new(|| {
    PedersenGens {
        B: *GENERATOR_G,
        B_blinding: *GENERATOR_H,
    }
});
```

**Usage**:
```rust
// Always use shared generators
let commitment = PEDERSEN_GENS.commit(Scalar::from(value), blinding);
```

### 7. Thread Safety and Performance

**Reuse Generators**:
```rust
// GOOD: Reuse globally
static BP_GENS: Lazy<BulletproofGens> = Lazy::new(|| {
    BulletproofGens::new(64, 1)
});

// BAD: Creating new generators each time
fn verify(proof: &RangeProof) {
    let bp_gens = BulletproofGens::new(64, 1); // Expensive!
    // ...
}
```

**Batch Operations**:
```rust
// Batch verify range proofs (10x faster for 10 outputs)
RangeProof::verify_batch(&proofs, &commitments, &BP_GENS);

// Batch verify Schnorr signatures
SchnorrSignature::verify_batch(&signatures, &public_keys, &messages);
```

### 8. Error Handling

```rust
use thiserror::Error;

#[derive(Error, Debug)]
pub enum CryptoError {
    #[error("Invalid range proof: {0}")]
    InvalidRangeProof(#[from] tari_bulletproofs::ProofError),
    
    #[error("Invalid signature: {0}")]
    InvalidSignature(#[from] tari_crypto::signatures::SchnorrSignatureError),
    
    #[error("Invalid commitment")]
    InvalidCommitment,
    
    #[error("Serialization error: {0}")]
    Serialization(String),
}
```

### Summary

| Primitive | Source | Z00Z Type | Usage |
|-----------|--------|-----------|-------|
| Pedersen Commitment | `tari_crypto::commitment` | `Commitment` | Output values |
| Schnorr Signature | `tari_crypto::signatures` | `KernelSignature` | Kernel authorization |
| Bulletproof | `tari_bulletproofs` | `RangeProof` | Value range proofs |
| Blake2b | `blake2` crate | Hash functions | Nullifiers, roots |
| Ristretto | `tari_crypto::ristretto` | Keys, scalars | All curve operations |
| Nullifier | **z00z_core** | `[u8; 32]` | Spent tracking |
| OutputFeatures | **z00z_core** | Custom struct | Z00Z-specific metadata |

---

## Module Specifications

### Validation Pipeline Flow

```mermaid
flowchart TD
    TX["Incoming Transaction"]
    VP["ValidationPipeline::validate(tx, state)"]
    IE["InputsExistValidator"]
    ND["NoDuplicateInputsValidator"]
    RP["RangeProofValidator"]
    BAL["BalanceValidator"]
    WL["WeightLimitValidator"]
    OK["SUCCESS"]
    ERR["REJECTED<br/>(ValidationError)"]

    TX --> VP
    VP --> IE --> ND --> RP --> BAL --> WL
    WL --> OK

    IE -->|error| ERR
    ND -->|error| ERR
    RP -->|error| ERR
    BAL -->|error| ERR
    WL -->|error| ERR

```

---

## `crates/z00z_core/types`

1. **General types**
   - `pub type Amount = u64;` and `pub type Fee = Amount;` (see `docs/001-TLD`, section 6.2.1).
   - `pub type EpochId = u64; pub type DaSlot = u64; pub type BatchId = u64;` — basic identifiers for epochs, DA slots, and batches.
   - `pub type Commitment = HomomorphicCommitment<RistrettoPublicKey>;` (reusing `RistrettoPublicKey`/`SecretKey` implementations from `z00z_crypto/tari/crypto/src/ristretto`).
   - `pub type RangeProof = tari_bulletproofs::range_proof::RangeProof;`
   - `pub type KernelSignature = tari_crypto::signatures::SchnorrSignature;` (or `CommitmentAndPublicKeySignature` if dual verification is required).
   - `pub type BlindingFactor = RistrettoSecretKey;` (wrapping the `SecretKey`).
2. **Helper structures**
   - `pub struct EpochIndex { epoch: EpochId, slot: DaSlot }` for the `Batch` metadata.
   - `pub enum KernelFlags { None, NoRecentDuplicate, Immature }` and `OutputFeatures` (including `script` and `metadata`).
3. **Serialization / conversions**
   - Points and scalars implement `ByteArray`, so provide `fn to_bytes(&self) -> [u8; ...]` helpers.
   - Document the constraint that commitments sum only when all parties use the same base generators.

<!-- markdownlint-disable MD022 MD031 MD032 MD040 MD051 MD056 -->

## `crates/z00z_core/assets`

```mermaid
classDiagram
    class CoinOutput {
        +Commitment commitment
        +RangeProof range_proof
        +OutputFeatures features
        +Option<OutputMetadata> metadata
    }

    class TokenOutput {
        +Commitment commitment
        +RangeProof range_proof
        +OutputFeatures features
        +TokenId token_id
        +Option<OutputMetadata> metadata
    }

    class VoidOutput {
        +Commitment commitment
        +bool is_void
        +Option<RangeProof> range_proof
        +OutputFeatures features
    }

    class OutputFeatures {
        +Option<u64> lock_height
        +bool is_burned
        +Option<TokenId> token_id_hint
        +Option<AssetTag> asset_tag
    }

    class OutputMetadata {
        +Option<String> memo
        +Option<[u8;32]> wallet_hint
        +Option<[u8;32]> app_tag
    }

    CoinOutput --> OutputFeatures
    TokenOutput --> OutputFeatures
    VoidOutput --> OutputFeatures

    CoinOutput --> OutputMetadata
    TokenOutput --> OutputMetadata
    VoidOutput --> OutputMetadata

```



1. **`coins.rs`**
   - Define the structures:
     - `CoinOutput` (Mimblewimble-style outputs) containing `commitment`, `range_proof`, `features: OutputFeatures`, and `metadata: Option<OutputMetadata>`.
     - `CoinFeatures` with fields `lock_height`, `is_burned`, and `nonce` (used for nullifier derivation); reuse `tari_crypto::hashing` for nonce hashing.
   - Methods:
     - `pub fn new(amount: Amount, blinding: &BlindingFactor, height: u64, metadata: Option<Vec<u8>>) -> Result<Self>` that produces the commitment via `PedersenGens::default().commit_value`.
     - `pub fn verify_proof(&self, bp_gens: &BulletproofGens) -> Result<()>` calling `RangeProof::verify_single`.
     - `pub fn commitment(&self) -> Commitment` for integrating with the UTXO set.
2. **`tokens.rs`, `nfts.rs`, `void.rs`**
   - Document the templates (see `docs/001-TLD`, section 6.2.4). For example, `TokenOutput` should include `token_id`, `amount`, and `owner_commitment`.
   - `VoidOutput` represents a burn sink flagged as `is_void`, optionally omitting the range proof or proving zero value.
3. **Offline coin**
   - `pub struct OfflineCoinRecord { output: CoinOutput, owner_pub: PublicKey, proof_of_possession: KernelSignature, slashed: bool, offline_metadata: Option<OfflineMeta> }` where `OfflineMeta` stores the origin slot, counter, and a DA-inclusion proof placeholder so FR-OFF-01..05 requirements (re-signing, slashing, double-spend detection) are satisfied.
   - Add a `serialize_to_file` helper to support offline handoffs between wallets.
   - Note that the wallet keeps `OfflineCoinRecord`s locally, marks them `slashed` once double spends are observed, and only assembles a `Transaction` when connectivity returns or receipt proofs are refreshed.
   
   ```mermaid
   flowchart TD
       MINT["On-chain tx<br/>creates CoinOutput"]
       OCR["OfflineCoinRecord<br/>{ output, owner_pub,<br/>proof_of_possession,<br/>offline_metadata, slashed=false }"]
       W1["Wallet A (sender)"]
       W2["Wallet B (receiver)"]
       REDEEM["Redeem online tx<br/>(build Transaction)"]
       SLASH["On-chain check<br/>spent_root / slashed flag"]
   
       MINT -->|"export OfflineCoinRecord<br/>serialize_to_file()"| OCR
       OCR -->|"stored in"| W1
       W1 -->|"hand-off file / QR"| W2
       W2 -->|"local checks<br/>!slashed & !in spent_root"| OCR
       W2 -->|"when online"| REDEEM --> SLASH
   
   ```
   
### Offline Wallet Handoff Flow

1. **Wallet A (sender)** scans its local UTXO set for native `CoinOutput`s, wraps the selected output in an
  `OfflineCoinRecord` (populating `owner_pub`, `proof_of_possession`, and `OfflineMeta`), serializes the bytes with the
  version header, and shares the file/QR payload over the offline channel.
2. **Wallet B (receiver)** imports the binary blob, checks the checksum and version, verifies `!slashed`, and consults
  the latest `spent_root` snapshot it has locally before storing the record in its staging database.
3. **Wallet B (online redemption)** periodically syncs headers; when connectivity returns, it verifies the DA proof in
  `OfflineMeta`, reconstructs a `Transaction` that spends the embedded `CoinOutput`, and submits it for inclusion in the
  next batch.
4. **Slashing / replay detection** — if Wallet B (or the validator set) observes that the same output appears in the
  on-chain spent set twice or that the proof-of-possession fails, the wallet marks `slashed = true` on the local record
  and refuses to redeem it again.

   

## `crates/z00z_core/tx`

1. **Transaction structures**
   
   - `pub struct Input { committed_output: Commitment, nonce: [u8; 32], proof_of_possession: Option<KernelSignature> }`.
   - `pub struct Output { commitment: Commitment, range_proof: RangeProof, features: OutputFeatures }`.
   - `pub struct Kernel { excess: Commitment, signature: KernelSignature, fee: Fee, lock_height: Option<u64>, flags: KernelFlags }`.
   - `pub struct Transaction { inputs: Vec<Input>, outputs: Vec<Output>, kernels: Vec<Kernel>, offset: BlindingFactor }`.
   - `pub struct Batch { id: BatchId, epoch: EpochId, da_slot: DaSlot, txs: Vec<Transaction>, meta: BatchMeta }`.
   - Define `pub struct BatchMeta { epoch_id: EpochId, batch_id: BatchId, da_slot: DaSlot, namespace: Namespace, da_height: u64, total_fee: Amount, kernel_count: u64, input_count: u64, output_count: u64, aggregator_proof: Option<Vec<u8>> }` capturing Celestia namespace proofs, counters aligned with the master spec, total fees, and an optional aggregator mixing proof that satisfies the privacy obligations (G1-G4).
   
   ```mermaid
   classDiagram
       class Transaction {
           +Vec<Input> inputs
           +Vec<Output> outputs
           +Vec<Kernel> kernels
           +BlindingFactor offset
       }
   
       class Input {
           +Commitment committed_output
           +[u8;32] nonce
           +Option<KernelSignature> proof_of_possession
       }
   
       class Output {
           +Commitment commitment
           +RangeProof range_proof
           +OutputFeatures features
       }
   
       class Kernel {
           +Commitment excess
           +KernelSignature signature
           +Fee fee
           +Option<u64> lock_height
           +KernelFlags flags
       }
   
       class Batch {
           +BatchId id
           +EpochId epoch
           +DaSlot da_slot
           +Vec<Transaction> txs
           +BatchMeta meta
       }
   
       class BatchMeta {
           +EpochId epoch_id
           +BatchId batch_id
           +DaSlot da_slot
           +NamespaceId namespace
       }
   
       Transaction --> "inputs *" Input
       Transaction --> "outputs *" Output
       Transaction --> "kernels *" Kernel
   
       Batch --> "txs *" Transaction
       Batch --> BatchMeta
   
   ```
   
2. **Serialization**
   
   - Serialize `Transaction` via `bincode` or `borsh` (controlled by cargo features). `ByteArray` support on `Commitment` and `Signature` simplifies the byte handling.
   - Provide `impl From<Transaction> for Vec<u8>` and `TryFrom<&[u8]>`.
3. **Helper functions**
   - `pub fn build_tx(inputs, outputs, fee, lock_height) -> Transaction`:
     - Computes `kernel.excess = Σinput_commits − Σoutput_commits − fee·H` using `PedersenGens`.
     - Signs the resulting excess and `msg = hash(inputs || outputs || fee)` via `tari_crypto::signatures::SchnorrSignature`.
     - Returns an `offset` to conceal the total blinding factor.
   - `pub fn verify_tx_balance(tx, bp_gens, pc_gens) -> Result<()>` to check `ΣCommitments` and range proofs.
   - `pub fn derive_nullifier(output: &Output, nonce: &[u8]) -> Nullifier` via `Blake2b` mixing `nonce`, `output.features.flags`, `output.features.metadata`, and the commitment to align with Tari's `OutputId` derivation and prevent inconsistencies when validating against the reference implementation.

## `crates/z00z_core/validation`

1. **Pipeline**
   - `pub trait TxValidator { fn validate(&self, tx: &Transaction, state: &EpochState) -> Result<(), ValidationError>; }`.
   - `pub struct ValidationPipeline { validators: Vec<Box<dyn TxValidator>> }`.
   - The pipeline's `fn validate(&self, tx, state) -> Result<()>` iterates through each validator (following standard validation pipeline patterns).
2. **Validators**
   - `InputsExistValidator`: ensures each `Input.nullifier` is present in `state.utxo_set` (or resolves to outputs created within the same batch).
   - `NoDuplicateInputsValidator`: compares input nullifiers via a `HashSet` to avoid duplicates.
   - `RangeProofValidator`: calls `output.verify_proof(bp_gens)`.
   - `BalanceValidator`: checks `ΣCin − ΣCout − fee·H = kernel.excess` and verifies `kernel.signature.verify(msg, kernel.excess)`.
   - `KernelSignatureValidator`: delegates to `KernelSignature::verify`.
   - `WeightLimitValidator`: calculates `tx.weight = inputs.len() * INPUT_WEIGHT + outputs.len() * OUTPUT_WEIGHT + kernels.len() * KERNEL_WEIGHT` and compares it to `config.batch_limits.max_tx_weight`.
3. **Batch validation**
   - `BatchValidator` (in the same module) validates:
     - `total_fee` stays within configured bounds and matches the sum of kernel fees declared in `BatchMeta` to align with the financial invariants (ΣCin − ΣCout = total_fee + Σkernels);
     - the combined `txs` do not reuse nullifiers or violate replay protections visible in `state.spent_root`;
     - `EpochState` transitions remain consistent (see `apply_batch`);
     - optional `aggregator_proof` blobs keep proofs G1–G4 compliant, ensuring no plaintext metadata leaks while allowing mixers to attest to compliance.
4. **Error modeling**
   - `pub struct ValidationError { kind: ValidationErrorKind, source: Option<anyhow::Error> }`.
   - `ValidationErrorKind` enumerates `InvalidRangeProof`, `MissingInput`, `BadKernelSignature`, `OutOfBalance`, `WeightExceeded`, and `StateMismatch`.

## `crates/z00z_core/state`

1. **Core structures**
   - `pub struct UtxoSet { outputs: HashMap<Nullifier, Output> }` (a `BTreeMap` can be used instead for deterministic ordering).
   - `pub struct EpochState { epoch_id: EpochId, utxo_root: Hash, spent_root: Hash, total_supply: Amount, counters: EpochCounters, validators: EpochValidators, meta: EpochMeta }` where `EpochCounters { input_count: u64, output_count: u64, kernel_count: u64 }` mirrors the master spec.
   - `pub struct EpochDelta { removed: Vec<Nullifier>, added: Vec<Output>, total_fee: Amount, new_utxo_root: Hash }`.
   
   ```mermaid
   flowchart TD
       ES0["EpochState (epoch_id = e)<br/>{ utxo_root, spent_root,<br/>total_supply, counters }"]
       B["Batch<br/>{ txs, BatchMeta }"]
       AP["apply_batch(state, batch)"]
       BV["BatchValidator"]
       Δ["EpochDelta<br/>{ added, removed,<br/>total_fee, new_utxo_root }"]
       ES1["EpochState' (epoch_id = e)<br/>updated roots & counters"]
   
       ES0 --> AP
       B --> AP
       AP --> BV
       BV -->|"ok"| Δ --> ES1
       BV -->|"error"| B
   
   ```
   
   
   
2. **Interfaces**
   
   - `pub fn apply_tx(state: &mut EpochState, tx: &Transaction, validator: &ValidationPipeline) -> Result<EpochDelta>`:
     - Validates the transaction.
     - Removes `state.utxo_set.remove(input.nullifier)` and inserts the new `outputs`.
     - Keeps `total_supply` constant (except for fees) and increments `state.total_fee_collected += tx.total_fee()`.
   - `pub fn apply_batch(state: &mut EpochState, batch: &Batch, validator: &BatchValidator) -> Result<EpochDelta>`:
     - Processes each transaction with `apply_tx`.
     - Computes `batch_meta` (including `da_slot`, `epoch`, counters, and total fees) and verifies it matches the `BatchMeta` carried by the batch.
     - Updates `state.counters` (`input_count`, `output_count`, `kernel_count`) and ensures the `utxo_root` / `spent_root` calculations use the same sorted nullifier sets described in the master doc, protecting replay-resistant invariants.
3. **Roots and proofs**
   - Derive `utxo_root` and `spent_root` as a `Hash` (e.g., `Blake2b256`) over the sorted nullifier list.
   - Document `EpochState::verify_delta(old, delta, new)` logic: `new.utxo_root == Hash(old.utxo_root, delta.added, delta.removed)`.
   - Track `EpochMeta` metadata (`description`, `timestamp`, `entropy_seed`, `da_height`) as part of the stored state so reproducibility goals align with the master design.
4. **Persistence helper**
   - `pub trait EpochStore { fn get_epoch(&self, id: EpochId) -> Option<EpochState>; fn put_epoch(&mut self, state: EpochState) -> Result<()>; }`.
   - Provide an `InMemoryEpochStore` implementation for tests.

## `crates/z00z_core/genesis`

1. **Constants**
   - `pub const GENESIS_NUM_COINS: usize = 50_000;`
   - `pub const GENESIS_COIN_NOMINAL: Amount = 200_000;`
   - `pub const GENESIS_EPOCH: EpochId = 0;`
   
   ```mermaid
   flowchart TD
       S["Input seed<br/>PROTOCOL_SEED / external 32 bytes"]
       RNG["ChaChaRng::from_seed(seed)"]
       LOOP["for index in 0..GENESIS_NUM_COINS"]
       CID["context_id = hash_to_scalar(seed || index)"]
       R["blinding = BlindingFactor::random(&mut rng)"]
       COM["commitment = PEDERSEN_GENS.commit(value, blinding)"]
       RP["range_proof = RangeProof::prove_single(...)"]
       OUT["CoinOutput{commitment,<br/>range_proof, features=default}"]
       UTXO["epoch_state.utxo_set.insert(context_id, output)"]
       CNT["epoch_state.counters.output_count += 1"]
       ROOT["Compute utxo_root & spent_root,<br/>set total_supply, fill EpochMeta"]
       ES["Genesis EpochState"]
   
       S --> RNG --> LOOP
       LOOP --> CID --> R --> COM --> RP --> OUT --> UTXO --> CNT --> LOOP
       LOOP --> ROOT --> ES
   
   ```
   
2. **Builder**
   - `pub fn build_genesis_state(seed: &[u8; 32]) -> EpochState`:
     - Takes `PedersenGens::default()` and `BulletproofGens::new(64, 1)`.
     - Initializes a deterministic RNG (e.g., `ChaChaRng::from_seed(seed)`) so testing and release builds reproduce identical outputs.
     - Iteratively creates `CoinOutput` instances with `value = GENESIS_COIN_NOMINAL` and `blinding = BlindingFactor::random(&mut rng)`.
     - For each output, generates `RangeProof::prove_single` and inserts it into the `UtxoSet`, incrementing `epoch.counters` accordingly.
     - Sets `EpochState.total_supply = GENESIS_NUM_COINS * GENESIS_COIN_NOMINAL`, updates `meta` with `description`, `timestamp: now`, `entropy_seed: seed`, `da_height: 0`, and exports the resulting state as JSON for reuse by `z00z_runtime` or release tooling.
3. **Validation**
   - Ensure the generated outputs pass `RangeProof::verify_single`.
   - Populate `EpochMeta { description: "genesis", timestamp: now }`.
4. **Documentation**
   - Note that the genesis state export can be stored as JSON or another file format for reuse by `z00z_runtime`.

## Tests and scenarios (summary)

1. `crates/z00z_core/tests/basic_flow.rs`
   - Unpack `build_genesis_state`, take one output, build a `Transaction` (payment + change), apply `apply_tx`, and assert:
     - `state.total_supply` remains `GENESIS_TOTAL_SUPPLY`.
     - The `UtxoSet` removed the spent input and added the two outputs.
     - `EpochDelta::removed` contains the input's nullifier.
     - Both `BalanceValidator` and `RangeProofValidator` succeed.
2. `tests/negative/*.rs`
   - Coverage for: double nullifier use, invalid range proof, and mismatched `kernel.signature`.
3. `tests/offline_coin_flow.rs`
   - Simulate moving an `OfflineCoinRecord` between two wallets and assembling a transaction once connectivity is restored.

---

## Common Pitfalls

This section documents frequently encountered mistakes and anti-patterns to avoid during implementation.

### 1. Cryptographic Mistakes

#### ❌ Using Wrong Generators
```rust
// WRONG: Using same generator for value and blinding
let C = value * G + blinding * G; // Insecure!

// CORRECT: Use independent generators
let C = value * G + blinding * H; // H must have unknown discrete log
```

**Why it matters**: If `H = k·G` for known `k`, then `C = (value + k·blinding)·G`, allowing attackers to determine `value`.

#### ❌ Reusing Blinding Factors
```rust
// WRONG: Same blinding for multiple outputs
let r = Scalar::random();
let C1 = value1 * G + r * H;
let C2 = value2 * G + r * H; // Leaks value difference!

// CORRECT: Fresh blinding for each output
let r1 = Scalar::random();
let r2 = Scalar::random();
let C1 = value1 * G + r1 * H;
let C2 = value2 * G + r2 * H;
```

**Impact**: Reusing `r` allows observers to compute `C1 - C2 = (value1 - value2)·G`, revealing the value difference.

#### ❌ Incorrect Balance Calculation
```rust
// WRONG: Forgetting fee in balance equation
let excess = sum_input_blindings - sum_output_blindings;

// CORRECT: Include fee (fee has zero blinding)
let excess = sum_input_blindings - sum_output_blindings;
// Fee commitment is separate: fee * H
```

### 2. State Management Errors

#### ❌ Not Checking Nullifier Duplicates
```rust
// WRONG: Adding to spent set without checking
spent_set.insert(nullifier);

// CORRECT: Validate before insertion
if spent_set.contains(&nullifier) {
    return Err(ValidationError::DoubleSpend);
}
spent_set.insert(nullifier);
```

**Impact**: Allows double-spending attacks where same UTXO is spent multiple times.

#### ❌ Incorrect UTXO Set Updates
```rust
// WRONG: Adding outputs before removing inputs
for output in tx.outputs {
    utxo_set.insert(output);
}
for input in tx.inputs {
    utxo_set.remove(input.nullifier); // Might remove new output!
}

// CORRECT: Remove inputs first
for input in tx.inputs {
    utxo_set.remove(input.nullifier)?;
}
for output in tx.outputs {
    utxo_set.insert(output);
}
```

#### ❌ Not Maintaining Total Supply Invariant
```rust
// WRONG: Forgetting to track fees
state.total_supply -= tx.fee; // Supply shrinks!

// CORRECT: Total supply is immutable except genesis
assert_eq!(
    sum_inputs_value,
    sum_outputs_value + tx.fee
);
// total_supply unchanged (fee burned/collected separately)
```

### 3. Serialization Issues

#### ❌ Unstable Serialization
```rust
// WRONG: Using HashMap iteration (non-deterministic order)
for (k, v) in utxo_set.iter() {
    hasher.update(k);
    hasher.update(v);
}

// CORRECT: Sort before hashing
let mut sorted: Vec<_> = utxo_set.iter().collect();
sorted.sort_by_key(|(k, _)| k);
for (k, v) in sorted {
    hasher.update(k);
    hasher.update(v);
}
```

**Impact**: Different machines compute different `utxo_root`, breaking consensus.

#### ❌ Endianness Issues
```rust
// WRONG: Platform-dependent serialization
let bytes = value.to_ne_bytes(); // Native endian varies!

// CORRECT: Explicit endianness
let bytes = value.to_be_bytes(); // Or to_le_bytes, but consistent
```

### 4. Range Proof Mistakes

#### ❌ Skipping Range Proof Verification
```rust
// WRONG: Trusting outputs without verification
fn validate_output(output: &Output) -> Result<()> {
    // Check commitment... but not range proof
    Ok(())
}

// CORRECT: Always verify range proofs
fn validate_output(output: &Output, bp_gens: &BulletproofGens) -> Result<()> {
    output.range_proof.verify_single(
        &output.commitment,
        bp_gens
    )?;
    Ok(())
}
```

**Impact**: Allows negative values or overflows, breaking supply cap.

#### ❌ Wrong Range Proof Parameters
```rust
// WRONG: Mismatched generators
let proof = RangeProof::prove_single(value, blinding, (&G_wrong, &H_wrong));
let valid = proof.verify_single(commitment, (&G_correct, &H_correct)); // false!

// CORRECT: Use same generators throughout
const GENS: Lazy<PedersenGens> = Lazy::new(|| PedersenGens::default());
```

### 5. Wallet Implementation Traps

#### ❌ Exposing Secrets in Logs
```rust
// WRONG: Logging sensitive data
log::debug!("spend_key: {:?}", spend_key);
log::info!("blinding factor: {}", blinding);

// CORRECT: Never log secrets
log::debug!("spend_key: [REDACTED]");
// Or use separate debug builds with opt-in secret logging
```

#### ❌ Not Encrypting Persistent State
```rust
// WRONG: Storing blinding factors in plaintext
fs::write("wallet.dat", bincode::serialize(&blindings)?)?;

// CORRECT: Encrypt before writing
let encrypted = encrypt_xchacha20(
    &bincode::serialize(&blindings)?,
    &wallet_key
)?;
fs::write("wallet.dat", encrypted)?;
```

#### ❌ Forgetting to Scan for Change
```rust
// WRONG: Only scanning with recipient key
let outputs = scan_utxo_set(&bob_scan_key);

// CORRECT: Scan with both keys (if sender has change)
let received = scan_utxo_set(&bob_scan_key);
let change = scan_utxo_set(&alice_scan_key); // Alice's change
```

### 6. Concurrency Bugs

#### ❌ Race Conditions in State Updates
```rust
// WRONG: Non-atomic read-modify-write
if !spent_set.contains(&nullifier) {
    // Another thread might insert here!
    spent_set.insert(nullifier);
}

// CORRECT: Atomic operations or locks
let inserted = spent_set.insert(nullifier);
if !inserted {
    return Err(ValidationError::DoubleSpend);
}
```

#### ❌ Deadlocks in Validation Pipeline
```rust
// WRONG: Holding multiple locks
let state_lock = state.write().unwrap();
let utxo_lock = utxo_set.write().unwrap(); // Might deadlock!

// CORRECT: Lock ordering or single lock
// Document lock hierarchy: state > utxo_set > spent_set
```

### 7. Genesis Reproducibility

#### ❌ Non-Deterministic RNG
```rust
// WRONG: Using system entropy for genesis
let mut rng = OsRng;
for i in 0..GENESIS_NUM_COINS {
    let blinding = Scalar::random(&mut rng); // Different each run!
}

// CORRECT: Seeded RNG for deterministic genesis
let mut rng = ChaChaRng::from_seed(PROTOCOL_SEED);
for i in 0..GENESIS_NUM_COINS {
    let blinding = Scalar::random(&mut rng); // Reproducible
}
```

**Impact**: Cannot verify genesis state, breaks testability.

### 8. Off-chain Payment Risks

#### ❌ Not Checking Slashed Status
```rust
// WRONG: Accepting offline coin without verification
fn accept_payment(coin: OfflineCoinRecord) -> Result<()> {
    wallet.add_coin(coin); // Might be double-spent!
}

// CORRECT: Check slashed flag and verify on-chain
fn accept_payment(coin: OfflineCoinRecord) -> Result<()> {
    if coin.slashed {
        return Err(Error::DoubleSpend);
    }
    // Verify nullifier not in spent_set
    if state.spent_root.contains(&coin.nullifier) {
        return Err(Error::AlreadySpent);
    }
    wallet.add_coin(coin)
}
```

---

## Implementation Checklist

Step-by-step guide for implementing `z00z_core` modules. Check off each item as completed.

### Phase 1: Foundation (Week 1-2)

#### `crates/z00z_core/types`

- [ ] Define basic type aliases
  ```rust
  pub type Amount = u64;
  pub type Fee = Amount;
  pub type EpochId = u64;
  pub type DaSlot = u64;
  pub type BatchId = u64;
  ```

- [ ] Create commitment type wrapper
  ```rust
  pub type Commitment = HomomorphicCommitment<RistrettoPublicKey>;
  pub type BlindingFactor = RistrettoSecretKey;
  ```

- [ ] Implement `KernelFlags` enum
  - [ ] Add `None`, `NoRecentDuplicate`, `Immature` variants
  - [ ] Implement `Display` and `FromStr`

- [ ] Create `OutputFeatures` struct
  - [ ] Add fields: `lock_height`, `is_burned`, `nonce`, `script`, `metadata`
  - [ ] Implement `Default` trait
  - [ ] Add serialization support (bincode/borsh)

- [ ] Write unit tests
  - [ ] Test type conversions
  - [ ] Test serialization round-trips
  - [ ] Test flag combinations

**Verification**: `cargo test -p z00z_core --lib types`

---

#### `crates/z00z_core/assets`

- [ ] Implement `CoinOutput` struct
  ```rust
  pub struct CoinOutput {
      pub commitment: Commitment,
      pub range_proof: RangeProof,
      pub features: OutputFeatures,
      pub metadata: Option<OutputMetadata>,
  }
  ```

- [ ] Add constructor methods
  - [ ] `new(amount, blinding, features) -> Result<Self>`
  - [ ] `from_parts(commitment, proof, features) -> Self`

- [ ] Implement verification
  - [ ] `verify_proof(&self, bp_gens) -> Result<()>`
  - [ ] `verify_features(&self) -> Result<()>`

- [ ] Create `OfflineCoinRecord` struct
  - [ ] Add fields: `output`, `owner_pub`, `proof_of_possession`, `slashed`, `offline_metadata`
  - [ ] Implement `serialize_to_file` and `deserialize_from_file`
  - [ ] Add `mark_slashed(&mut self)` method

- [ ] Write tests
  - [ ] Test output creation with valid/invalid amounts
  - [ ] Test range proof verification
  - [ ] Test offline coin serialization
  - [ ] Test negative values (should fail)

**Verification**: `cargo test -p z00z_core --lib assets`

---

### Phase 2: Transactions (Week 3-4)

#### `crates/z00z_core/tx`

- [ ] Define transaction structures
  - [ ] `Input` with `committed_output`, `nonce`, `proof_of_possession`
  - [ ] `Output` (alias or wrapper for `CoinOutput`)
  - [ ] `Kernel` with `excess`, `signature`, `fee`, `lock_height`, `flags`
  - [ ] `Transaction` with `inputs`, `outputs`, `kernels`, `offset`

- [ ] Implement `Batch` and `BatchMeta`
  - [ ] Add fields from spec
  - [ ] Implement counters tracking

- [ ] Add helper functions
  - [ ] `build_tx(inputs, outputs, fee, lock_height) -> Result<Transaction>`
  - [ ] `verify_tx_balance(tx, gens) -> Result<()>`
  - [ ] `derive_nullifier(output, nonce) -> Nullifier`

- [ ] Implement serialization
  - [ ] `impl From<Transaction> for Vec<u8>`
  - [ ] `impl TryFrom<&[u8]> for Transaction`

- [ ] Write tests
  - [ ] Test transaction building (1 input, 2 outputs)
  - [ ] Test balance verification
  - [ ] Test nullifier derivation consistency
  - [ ] Test serialization round-trips

**Verification**: `cargo test -p z00z_core --lib tx`

---

### Phase 3: Validation (Week 5)

#### `crates/z00z_core/validation`

- [ ] Define `TxValidator` trait
  ```rust
  pub trait TxValidator {
      fn validate(&self, tx: &Transaction, state: &EpochState) -> Result<()>;
  }
  ```

- [ ] Implement validators
  - [ ] `InputsExistValidator`: checks nullifiers exist
  - [ ] `NoDuplicateInputsValidator`: checks for duplicate inputs
  - [ ] `RangeProofValidator`: verifies all range proofs
  - [ ] `BalanceValidator`: checks balance equation and kernel signature
  - [ ] `KernelSignatureValidator`: validates kernel signatures
  - [ ] `WeightLimitValidator`: checks transaction weight limits

- [ ] Create `ValidationPipeline`
  - [ ] Add `validators: Vec<Box<dyn TxValidator>>`
  - [ ] Implement `validate(&self, tx, state) -> Result<()>` (runs all validators)

- [ ] Implement `BatchValidator`
  - [ ] Validate total fees
  - [ ] Check no replay attacks
  - [ ] Verify state transitions

- [ ] Define error types
  - [ ] `ValidationError` with `ValidationErrorKind` enum
  - [ ] Implement `Display` and `Error` traits

- [ ] Write comprehensive tests
  - [ ] Test each validator independently
  - [ ] Test pipeline with valid transactions
  - [ ] Test rejection of invalid transactions (negative tests)
  - [ ] Test error propagation

**Verification**: `cargo test -p z00z_core --lib validation`

---

### Phase 4: State Management (Week 6)

#### `crates/z00z_core/state`

- [ ] Implement `UtxoSet`
  - [ ] Use `BTreeMap<Nullifier, Output>` for deterministic ordering
  - [ ] Add `insert`, `remove`, `contains`, `get` methods
  - [ ] Implement `root_hash() -> Hash` (sorted hash of all entries)

- [ ] Create `EpochState` struct
  - [ ] Add all fields from spec
  - [ ] Implement `EpochCounters` tracking

- [ ] Implement state transitions
  - [ ] `apply_tx(state, tx, validator) -> Result<EpochDelta>`
  - [ ] `apply_batch(state, batch, validator) -> Result<EpochDelta>`
  - [ ] `verify_delta(old, delta, new) -> Result<()>`

- [ ] Implement `EpochStore` trait
  - [ ] Define interface: `get_epoch`, `put_epoch`
  - [ ] Create `InMemoryEpochStore` for tests

- [ ] Write tests
  - [ ] Test UTXO set operations
  - [ ] Test state transitions (genesis → claim → spend)
  - [ ] Test total supply invariant
  - [ ] Test root hash determinism

**Verification**: `cargo test -p z00z_core --lib state`

---

### Phase 5: Genesis (Week 7)

#### `crates/z00z_core/genesis`

- [ ] Define constants
  - [ ] `GENESIS_NUM_COINS`, `GENESIS_COIN_NOMINAL`, `GENESIS_EPOCH`
  - [ ] `PROTOCOL_SEED`

- [ ] Implement `build_genesis_state(seed) -> EpochState`
  - [ ] Initialize generators
  - [ ] Create deterministic RNG (`ChaChaRng::from_seed`)
  - [ ] Loop to create all coins
  - [ ] Compute initial roots

- [ ] Add genesis validation
  - [ ] Verify all range proofs
  - [ ] Check total supply calculation
  - [ ] Validate state integrity

- [ ] Create export functionality
  - [ ] Serialize genesis state to JSON
  - [ ] Add import for testing

- [ ] Write tests
  - [ ] Test genesis reproducibility (same seed → same state)
  - [ ] Test different seeds produce different states
  - [ ] Test total supply correctness
  - [ ] Benchmark genesis generation time

**Verification**: 
```bash
cargo test -p z00z_core --lib genesis
cargo bench -p z00z_core genesis
```

---

### Phase 6: Integration (Week 8)

#### End-to-End Tests

- [ ] `tests/basic_flow.rs`
  - [ ] Genesis → Claim → Spend workflow
  - [ ] Assert state consistency at each step

- [ ] `tests/negative/*.rs`
  - [ ] Double spend attempts
  - [ ] Invalid range proofs
  - [ ] Balance violations
  - [ ] Signature failures

- [ ] `tests/offline_coin_flow.rs`
  - [ ] Create offline coin
  - [ ] Transfer between wallets
  - [ ] Redeem online

- [ ] Performance benchmarks
  - [ ] Transaction validation throughput
  - [ ] State update latency
  - [ ] Memory usage profiling

**Verification**: `cargo test -p z00z_core --all-targets`

---

### Phase 7: Documentation (Week 9)

- [ ] Add rustdoc comments to all public APIs
  - [ ] Module-level documentation
  - [ ] Struct/enum documentation with examples
  - [ ] Function documentation with usage examples

- [ ] Create examples directory
  - [ ] `examples/simple_transaction.rs`
  - [ ] `examples/offline_payment.rs`
  - [ ] `examples/genesis_export.rs`

- [ ] Update README.md
  - [ ] Add quick start guide
  - [ ] Link to this spec
  - [ ] Add troubleshooting section

**Verification**: `cargo doc --open --no-deps`

---

### Final Checklist

- [ ] All tests passing (`cargo test --workspace`)
- [ ] No clippy warnings (`cargo clippy --all-targets -- -D warnings`)
- [ ] Code formatted (`cargo fmt --check`)
- [ ] Documentation complete (`cargo doc`)
- [ ] Benchmarks run and recorded
- [ ] Security review completed (see Common Pitfalls)
- [ ] Integration with `z00z_crypto` verified
- [ ] Genesis state exported and committed

**Sign-off**: Ready for code review and integration with `z00z_runtime`.

---

## Conclusion

- The junior developer has the following reference set: `docs/001-TLD/z00z_med-level-design-v1.md` (section 6.2), Tari protocol documentation (for transaction/validation patterns), and `crates/z00z_crypto/tari` (Pedersen commitments, signature and range proof implementations).
- Clarify that no additional cryptographic primitives belong in `z00z_core` beyond those listed, and document that `Nullifier`/`OutputId` are derived via hashing because they are not provided by `tari_crypto`.
