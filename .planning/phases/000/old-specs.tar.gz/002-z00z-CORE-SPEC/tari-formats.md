# Tari Format Notes

## Transaction

📌 `Transaction` in Tari’s `transaction_components` crate bundles a kernel offset (`offset: PrivateKey`), a `body: AggregateBody` (inputs, outputs, kernels), and a `script_offset: PrivateKey` that keeps cut-through-safe script metadata.
🎯 The `body` exposes helpers like `calculate_weight`, `max_input_maturity`, `max_kernel_timelock`, and `min_spendable_height` so validators know the transaction weight, highest maturity input, output lock limits, and spendable height derived from inputs+kernels.

## TransactionInput / TxInput

📌 `TransactionInput` carries a `version`, `spent_output`, `input_data`, and `script_signature`; `spent_output` is a `SpentOutput` enum that either holds just the `OutputHash` (compact input) or the full output data (features, commitment, script, covenant, encrypted data, metadata signature, rangeproof hash, minimum value promise).
🎯 Helpers let you attach full output data after construction, compute the script signature challenge, validate scripts/signatures, and fetch `commitment`, `features`, `script`, `sender_offset_public_key`, `covenant`, `encrypted_data`, `metadata_signature`, `rangeproof_hash`, or `minimum_value_promise` (each failing for compact inputs).
💥 Tari’s reference mirrors the `Z00Z` spec’s `TxInput`: a lightweight reference to a previous output/UTXO (by commitment or output ID) that later proves ownership via metadata signatures before consumption.

## TransactionOutput / TxOutput

📌 `TransactionOutput` exposes `version`, `features`, `commitment`, optional `proof`, `script`, `sender_offset_public_key`, `metadata_signature`, `covenant`, `encrypted_data`, and `minimum_value_promise`, embodying a Tari output’s cryptographic state.
🎯 Methods cover hashing (`hash`, `smt_hash`), range proof verification (RevealedValue or BulletproofPlus paths), metadata signature verification, and helpers for revealing the output’s destiny (coinbase/burn detection, equality checks, mask verification).
💥 The `Z00Z` `TxOutput` is conceptually identical: it tracks the new commitment, range proof, output features, and metadata/script that will be enforced when spending the resulting UTXO.

## TransactionKernel / Kernel

📌 `TransactionKernel` holds `version`, `features` (`KernelFeatures` flags), `fee: MicroMinotari`, `lock_height`, `excess`, `excess_sig`, and an optional `burn_commitment` for burned outputs.
🎯 It hashes via a domain-separated hasher, derives kernel signature challenges/messages, and verifies the Schnorr-style `excess_sig` to ensure `Σ(C_in − C_out − fee) = 0` while respecting lock heights and burn flags.
💥 This kernel structure matches the `Z00Z` concept of `Kernel`: a commitment to the excess, its signature, explicit `fee`, `lock_height`, and additional flags that encode coinbase/burn semantics.

## Fees

📌 Fees live inside each `TransactionKernel` as `MicroMinotari` and are part of the kernel signature challenge so the validator can prove `Σ(C_in − C_out − fee) = 0` on the commitment level.
🎯 For batch processing (`Z00ZBatch`/`Tari` blocks) totals of all kernel fees are tracked, and invariants ensure that the sum of declared fees equals the difference between input and output balances before supply adjustments.

## UTXO

📌 The `UtxoSet` in the `z00z_core` spec (inspired by Tari’s validation) is a storage-agnostic map of live `Z00ZOutput`s keyed by commitment (or UTXO ID) that validators consult to ensure each input references an unspent coin.
🎯 The set supports deduplication, membership proofs, and replay resistance: every input either points to an existing UTXO or a new output created within the same batch to avoid inconsistent ordering.

## EpochState

📌 `EpochState` is the canonical view of which offline coins (coin IDs / UTXOs) are currently spendable or invalidated; its minimal shape is `struct EpochState { epoch_id, utxo_root, spent_root/nullifier_root, total_supply, /* counters */ }`.
🎯 APIs include `apply_tx(state: &mut EpochState, tx: &Z00ZTx) -> Result<()>`, `apply_batch(state: &mut EpochState, batch: &Z00ZBatch) -> Result<EpochDelta>`, and `verify(old_state + delta == new_state)` so updates can be atomically reconciled with batch metadata.

## YAML Reference

```yaml
Transaction:
  description: "Transaction fields (Rust types)—`offset: PrivateKey`, `script_offset: PrivateKey`, `body: AggregateBody { inputs: Vec<TransactionInput>, outputs: Vec<TransactionOutput>, kernels: Vec<TransactionKernel> }`."
  offset: PrivateKey
  script_offset: PrivateKey
  body:
    inputs: [TransactionInput]
    outputs: [TransactionOutput]
    kernels: [TransactionKernel]

TransactionInput:
  description: "TransactionInput fields — `version: TransactionInputVersion`, `spent_output: SpentOutput` (either `OutputHash` or composed data), `input_data: ExecutionStack`, `script_signature: ComAndPubSignature`; `SpentOutput` data holds typed fields (`features: OutputFeatures`, `commitment: CompressedCommitment`, `script: TariScript`, `sender_offset_public_key: CompressedPublicKey`, `covenant: Covenant`, `metadata_signature: ComAndPubSignature`, `encrypted_data: EncryptedData`, `rangeproof_hash: FixedHash`, `minimum_value_promise: MicroMinotari`)."
  version: TransactionInputVersion
  spent_output:
    type: OutputHash | OutputData
    data:
      features: OutputFeatures
      commitment: CompressedCommitment
      script: TariScript
      sender_offset_public_key: CompressedPublicKey
      covenant: Covenant
      metadata_signature: ComAndPubSignature
      encrypted_data: EncryptedData
      rangeproof_hash: FixedHash
      minimum_value_promise: MicroMinotari
  input_data: ExecutionStack
  script_signature: ComAndPubSignature

TransactionOutput:
  description: "TransactionOutput fields — `version: TransactionOutputVersion`, `features: OutputFeatures`, `commitment: CompressedCommitment`, `proof: Option<RangeProof>`, `script: TariScript`, `sender_offset_public_key: CompressedPublicKey`, `metadata_signature: ComAndPubSignature`, `covenant: Covenant`, `encrypted_data: EncryptedData`, `minimum_value_promise: MicroMinotari`."
  version: TransactionOutputVersion
  features: OutputFeatures
  commitment: CompressedCommitment
  proof: RangeProof | null
  script: TariScript
  sender_offset_public_key: CompressedPublicKey
  metadata_signature: ComAndPubSignature
  covenant: Covenant
  encrypted_data: EncryptedData
  minimum_value_promise: MicroMinotari

TransactionKernel:
  description: "TransactionKernel fields — `version: TransactionKernelVersion`, `features: KernelFeatures`, `fee: MicroMinotari`, `lock_height: u64`, `excess: CompressedCommitment`, `excess_sig: CompressedSignature`, `burn_commitment: Option<CompressedCommitment>`."
  version: TransactionKernelVersion
  features: KernelFeatures
  fee: MicroMinotari
  lock_height: u64
  excess: CompressedCommitment
  excess_sig: CompressedSignature
  burn_commitment: CompressedCommitment | null

EpochState:
  description: "EpochState fields — `epoch_id: EpochId`, `utxo_root: FixedHash`, `spent_root: FixedHash`, `total_supply: MicroMinotari`, `counters: { input_count: u64, output_count: u64, kernel_count: u64 }`."
  epoch_id: EpochId
  utxo_root: Hash
  spent_root: Hash
  total_supply: MicroMinotari
  counters:
    input_count: u64
    output_count: u64
    kernel_count: u64

Fees:
  description: "Fees view — kernel-level `MicroMinotari` amounts aggregated per batch/epoch with `fee_offset` accounted in kernel signatures."
  per_kernel: MicroMinotari
  totals:
    batch: MicroMinotari
    epoch: MicroMinotari

UTXO:
  description: "UTXO entry — key `CompressedCommitment`, value `TransactionOutput`, status flag `unspent`/`spent`, metadata referencing `TariScript`, `EncryptedData`, and `minimum_value_promise` for proofs."
  key: CompressedCommitment
  output: TransactionOutput
  status: unspent | spent
  metadata:
    script: TariScript
    encrypted_data: EncryptedData
    minimum_value_promise: MicroMinotari
```


## Type Table

📌 This table links each Tari-derived entity to its main fields and exact source file so you can inspect the implementation directly.

| Entity | Key Fields & Types | Tari Source |
| --- | --- | --- |
| `Transaction` | `offset: PrivateKey`, `script_offset: PrivateKey`, `body: AggregateBody { inputs: Vec<TransactionInput>, outputs: Vec<TransactionOutput>, kernels: Vec<TransactionKernel> }` | [`transaction.rs`](.temp/tari-development/base_layer/transaction_components/src/transaction_components/transaction.rs) |
| `TransactionInput` | `version: TransactionInputVersion`, `spent_output: SpentOutput` (hash or full data), `input_data: ExecutionStack`, `script_signature: ComAndPubSignature`; `SpentOutput` data fields (features, commitment, script, sender offset key, covenant, signatures, encrypted data, rangeproof hash, minimum value) | [`transaction_input.rs`](.temp/tari-development/base_layer/transaction_components/src/transaction_components/transaction_input.rs) |
| `TransactionOutput` (UTXO) | `version: TransactionOutputVersion`, `features: OutputFeatures`, `commitment: CompressedCommitment`, `proof: Option<RangeProof>`, `script: TariScript`, `sender_offset_public_key: CompressedPublicKey`, `metadata_signature: ComAndPubSignature`, `covenant: Covenant`, `encrypted_data: EncryptedData`, `minimum_value_promise: MicroMinotari` | [`transaction_output.rs`](.temp/tari-development/base_layer/transaction_components/src/transaction_components/transaction_output.rs) |
| `TransactionKernel` (fees & lock info) | `version: TransactionKernelVersion`, `features: KernelFeatures`, `fee: MicroMinotari`, `lock_height: u64`, `excess: CompressedCommitment`, `excess_sig: CompressedSignature`, `burn_commitment: Option<CompressedCommitment>` | [`transaction_kernel.rs`](.temp/tari-development/base_layer/transaction_components/src/transaction_components/transaction_kernel.rs) |
| `EpochState` | `epoch_id`, `utxo_root`, `spent_root/nullifier_root`, `total_supply`, `counters { input_count, output_count, kernel count }` | *Defined in Z00Z spec document* [`docs/001-TLD/z00z_med-level-design-v1.md`](docs/001-TLD/z00z_med-level-design-v1.md) (no direct Tari source) |
