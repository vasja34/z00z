# 🔑 Nested JMT Refactor Workflow

> [!Important]
> This workflow defines the execution order for replacing the current single-namespaced JMT backend in `crates/z00z_storage/src/assets/` with a real multi-tree hierarchical JMT design that preserves the public storage API and unlocks subtree sharding.

**📌 Source intent comes from `specs/014-z00z-storage/jmt-migration-plan.md` plus verified codebase facts from the active storage, wallet, simulator, and genesis configuration files.**

> [!Caution]
> The current implementation now uses real logical child trees routed through private `TreeId` namespaces and one shared `TreeStore` over one physical `MemTreeStore`, but it still does not expose independently durable per-tree transactions or subtree-local public commit APIs.
> The workflow must preserve the current public facade exported from `crates/z00z_storage/src/assets/mod.rs` and `crates/z00z_storage/src/lib.rs`.

## 🔔 Table of Contents

- Scope Lock
- Verified Inputs And Constraints
- Phase 1. Contract Freeze And Gap Lock
- Phase 2. Private Storage Topology Design
- Phase 3. Transaction Coordinator And Atomic Commit Path
- Phase 4. AssetStore Backend Refactor
- Phase 5. Proof Path Rewire
- Phase 6. Downstream Adapter Stabilization
- Phase 7. Benchmark Harness And Shard Validation
- Phase 8. Acceptance, Rollback, And Cleanup Lock
- Acceptance Commands
- Open Decisions And Stop Rules

## 🎯 Scope Lock

> [!Important]
> The refactor must deliver these outcomes and nothing broader:

- preserve the canonical path `definition_id -> serial_id -> asset_id`
- preserve the public types `AssetPath`, `StoreItem`, `ProofItem`, `ProofBlob`, `AssetStateRoot`, `CheckRoot`, `RootApi`, `AssetStore`, and `StoreOp`
- replace the current single-JMT physical layout with real logical child trees
- support parallel update planning and execution for disjoint `definition_id` shards and disjoint `(definition_id, serial_id)` asset buckets
- keep one shared external transition version per state transition
- support multi-tree atomic commit through the fixed shared-store `TreeStore` substrate over one `MemTreeStore` commit boundary
- prove performance benefit on reproducible benchmarks grounded in `crates/z00z_core/src/genesis/genesis_config_devnet_small.yaml`

> [!Warning]
> This workflow must not widen wallet or simulator public traits, must not expose raw `jmt` types outside `z00z_storage`, and must not modify vendored Tari sources.

## 👁️‍🗨️ Verified Inputs And Constraints

**📌 Verified source files and direct integration anchors:**

- `specs/014-z00z-storage/jmt-migration-plan.md`
- `crates/z00z_storage/src/assets/{mod.rs,store.rs,model.rs,types.rs,proof.rs,keys.rs}`
- `crates/z00z_storage/src/assets/store_internal/{tx_plan.rs,whitebox_help.rs,whitebox_crud.rs,whitebox_state.rs,whitebox_proofs.rs,whitebox_paths.rs}`
- `crates/z00z_wallets/src/core/tx/{state_update.rs,witness_gate.rs,spending.rs,claim_tx.rs}`
- `crates/z00z_wallets/tests/{test_tx_spent_gate.rs,test_phase24_gate.rs,test_tx_wrong_root.rs}`
- `crates/z00z_simulator/src/{claim_pkg_consumer.rs,scenario_1/stage_4.rs,scenario_1/stage_6.rs}`
- `crates/z00z_simulator/tests/test_claim_tx_pipeline.rs`
- `crates/z00z_core/src/genesis/genesis_config_devnet_small.yaml`

> [!Caution]
> Existing files that were seen in earlier planning but are not verified here as direct storage-integration anchors must be treated as secondary follow-up targets, not as phase-entry facts:

- `crates/z00z_wallets/src/core/tx/{output_flow.rs,lifecycle.rs,claim_tx_tests.rs}`
- `crates/z00z_simulator/src/scenario_1/stage_3.rs`
- Stage-4 simulator test files outside `test_claim_tx_pipeline.rs`

**📌 Verified current backend facts:**

- `AssetStore` currently owns one `MemTreeStore`, one shared `flat_version`, one `path_by_id` helper map, and one shared commit path in `store.rs`
- `AssetModel` already computes the semantic hierarchy and must remain the reference oracle during the refactor
- `z00z_storage` currently has no `benches/` directory and no `criterion` dependency; benchmark infrastructure must be introduced explicitly
- the current proof bridge in `store.rs` builds `ProofBlob` from one asset proof plus two aggregate namespace proofs, so proof rewiring must preserve the current semantic `ProofItem` shape while changing only private proof sourcing

> [!Important]
> Verified and now-resolved infrastructure fact:

- the current backend is one in-memory `MemTreeStore`, and its existing write path already provides the exact primitive this refactor needs for Phase 2 substrate selection: one shared `Sha256Jmt::put_value_set(...)` batch over one store plus full in-memory snapshot rollback through `snap_store()` and `restore_store()`
- the refactor therefore fixes the private commit substrate now: introduce a private `TreeStore` that multiplexes many logical trees over one shared `MemTreeStore` commit boundary and preserves one external transition version
- a private write-ahead journal is explicitly out of scope for this refactor because the active backend is process-local and in-memory; journaled crash recovery becomes relevant only when this tree topology is later moved onto a persistent backend
- the current repository still has no benchmark baseline artifact for `z00z_storage`, so baseline capture must happen before backend code changes begin

```mermaid
flowchart TD
    A[Current Public API] --> B[Private Multi-Tree Backend]
    B --> C[Transaction Coordinator]
    C --> D[Proof Builder]
    D --> E[Wallet And Simulator Reuse Existing Facade]
    B --> F[Benchmark Harness]
```

## ⚙️ Phase 1. Contract Freeze And Gap Lock

### 🎯 1.1 Execution intent

**📌 Freeze the semantic contract and record the exact gap between the current implementation and the required physical tree layout before touching any code.**

### 🔑 1.2 Required files

- `specs/014-z00z-storage/jmt-migration-plan.md`
- `specs/014-z00z-storage/jmt-refactor-workflow.md`
- `crates/z00z_storage/src/assets/README.md`
- `crates/z00z_storage/Cargo.toml`
- proposed `crates/z00z_storage/benches/assets_shard.rs`
- proposed `crates/z00z_storage/benches/common/fixture.rs`

### 🔑 1.3 Required outputs

- one written mismatch summary between the current single-JMT layout and the required multi-tree layout
- one frozen list of public APIs that must remain source-compatible
- one frozen list of private modules that are allowed to change freely
- one frozen command log that captures the last green pre-refactor storage, wallet, and simulator gates
- one stored benchmark baseline artifact for the current single-JMT implementation

### ⚙️ 1.4 Serialized steps

1. Record that the current implementation satisfies semantic hierarchy but not literal child-tree topology.
2. Freeze the public facade exported by `crates/z00z_storage/src/assets/mod.rs`.
3. Freeze the wallet and simulator consumer surfaces that must remain unchanged.
4. Freeze the benchmark input source to `crates/z00z_core/src/genesis/genesis_config_devnet_small.yaml`.
5. Run and store the pre-refactor correctness gates before any backend change begins.
6. Add and run one minimal benchmark harness against the current single-JMT implementation before replacing the backend.
7. Keep all Phase 1 code edits limited to benchmark infrastructure and benchmark-report capture; do not modify `store.rs`, `model.rs`, `proof.rs`, or `store_internal/` yet.

### ✅ 1.5 Validation gate

- confirm that no workflow step introduces a new public `jmt` type outside `z00z_storage`
- confirm that no workflow step widens wallet or simulator traits
- run `cargo check -p z00z_storage`
- run `cargo test -p z00z_storage --test assets_suite`
- run `cargo check -p z00z_wallets`
- run `cargo test -p z00z_wallets --features test-fast --features wallet_debug_dump --test test_tx_spent_gate`
- run `cargo test -p z00z_wallets --features test-fast --features wallet_debug_dump --test test_phase24_gate`
- run `cargo test -p z00z_wallets --features test-fast --features wallet_debug_dump --test test_tx_wrong_root`
- run `cargo check -p z00z_simulator`
- run `cargo test -p z00z_simulator --features test-fast --features wallet_debug_dump --test test_claim_tx_pipeline`

### ⏰ 1.6 Baseline benchmark rule

> [!Important]
> The workflow must capture the current single-JMT benchmark numbers before Phase 2 code work starts.

Required artifact:

- proposed `crates/z00z_storage/outputs/assets/jmt-refactor-baseline.md`

Required command shape after the benchmark harness is introduced:

```bash
cargo bench -p z00z_storage --bench assets_shard -- --save-baseline current_single_jmt
```

### ✅ 1.7 Exit condition

**✅ Start Phase 2 only when the current gap is explicitly documented as: semantic hierarchy present, physical child-tree hierarchy absent, and the pre-refactor benchmark baseline is stored.**

## ⚙️ Phase 2. Private Storage Topology Design

### 🎯 2.1 Execution intent

**📌 Define the private multi-tree storage layout with the smallest structural change that can unlock real sharding.**

### 🔑 2.2 Design rule

**🎯 Preserve existing public semantics and move the refactor behind `AssetStore`.**

### ⚙️ 2.3 Required private structures

**📌 Introduce or replace only private structures under `crates/z00z_storage/src/assets/store_internal/` unless an existing file can absorb the logic cleanly.**

Required private types:

- `TreeId`: identifies one physical tree namespace
- `TreeRootRef`: carries the latest root for one private tree
- `ShardPlan`: groups touched shards for one transition
- `TreeBatch`: one tree-local write set and resulting root
- `TxCoord`: transaction coordinator for one shared version
- `PathIndexRec`: storage-internal reverse lookup record
- `TreeStore`: private storage substrate that multiplexes many logical trees over one backend commit boundary

Required private tree layout:

- `DefinitionTree`: key `DefinitionId` -> value `DefinitionRootLeaf`
- `SerialTree(definition_id)`: key `SerialId` -> value `SerialRootLeaf`
- `AssetTree(definition_id, serial_id)`: key `AssetId` -> value `AssetLeaf`
- `PathIndexTree`: key `AssetId` -> value canonical `AssetPath`

### 🔑 2.4 Allowed file targets

- extend `crates/z00z_storage/src/assets/store_internal/tx_plan.rs`
- add proposed private files only if needed:
  - `crates/z00z_storage/src/assets/store_internal/tree_id.rs`
  - `crates/z00z_storage/src/assets/store_internal/tree_batch.rs`
  - `crates/z00z_storage/src/assets/store_internal/tx_coord.rs`
  - `crates/z00z_storage/src/assets/store_internal/tree_store.rs`

### 🔑 2.5 Required outputs

- one fixed private commit substrate strategy
- one written tree-id and namespace map
- one written rule for how child-tree roots are encoded into parent leaves without changing public types
- one written domain-separation rule for private tree-id and namespace derivation

### ⚙️ 2.5A Fixed commit substrate decision

> [!Important]
> Phase 2 commit-substrate choice is resolved now and is no longer an implementation-stage open question.

Chosen substrate:

- one private `TreeStore` layered over one shared `MemTreeStore`
- one shared external `Version` per transition
- one serialized internal commit path that writes all touched logical-tree batches through one underlying JMT batch boundary
- one full in-memory rollback path that restores `flat_store`, `flat_version`, `flat_root`, `model`, `path_by_id`, `root_by_ver`, and `model_by_ver` if any step in the transition fails before commit completion

Rejected substrate for this refactor:

- no private write-ahead log
- no recovery journal
- no per-tree independent durable transaction layer

Rationale from verified codebase facts:

- `store_internal/tx_plan.rs::commit_plan()` already snapshots the full in-memory store state before commit and restores it on error
- `store_internal/tx_plan.rs::commit_all()` already aggregates namespace writes into one `Sha256Jmt::put_value_set(...)` call over one store
- `store.rs::MemTreeStore::write_tree_update_batch()` already applies the produced JMT update batch as one store mutation path
- the active backend is in-memory only, so adding WAL semantics now would add durable-recovery complexity without any durable storage substrate to recover into

> [!Caution]
> Atomicity for this refactor is therefore defined precisely as single-process transition atomicity plus rollback-on-error inside one shared in-memory store. Durable crash recovery is not part of this refactor's definition of done.

### 👁️‍🗨️ 2.6 Architectural sketch

```mermaid
flowchart TD
    A[StoreOp Vec] --> B[ShardPlan]
    B --> C[AssetTree Batch per definition_id+serial_id]
    C --> D[SerialTree Batch per definition_id]
    D --> E[DefinitionTree Batch]
    B --> F[PathIndexTree Batch]
    C --> G[TxCoord]
    D --> G
    E --> G
    F --> G
    G --> H[Atomic Shared-Version Commit]
```

### ⚙️ 2.7 Serialized steps

1. Define `TreeId` and the mapping from logical tree to physical namespace.
2. Extend `MemTreeStore` into a private `TreeStore` that isolates many logical trees behind private `TreeId` routing while preserving one shared batch-commit boundary and one shared external version.
3. Define `ShardPlan` so touched asset buckets are grouped by `(definition_id, serial_id)`.
4. Define `TxCoord` so one external transition version is shared across all touched trees.
5. Define `PathIndexRec` as a private tree record, not as a public API type.
6. Define the parent-leaf encoding rule so `SerialRootLeaf` and `DefinitionRootLeaf` remain the only committed public semantic parent records.
7. Define `TreeId` and physical namespace derivation with storage-private domain separation so `DefinitionTree`, `SerialTree`, `AssetTree`, and `PathIndexTree` cannot collide even when child trees are parameterized by `definition_id` and `serial_id`.
8. Keep rollback semantics aligned with the existing `snap_store()` and `restore_store()` discipline rather than introducing WAL or durable journal logic into this phase.

### ⚙️ 2.8 Parallelizable steps

- tree-id enumeration and physical namespace layout can run in parallel with path-index record design
- proof-shape notes can run in parallel with tree-store topology notes

### ✅ 2.9 Validation gate

- prove that different `DefinitionTree`, `SerialTree`, `AssetTree`, and `PathIndexTree` instances cannot collide physically
- prove that the design keeps one shared external version and does not leak per-tree versions into public records
- prove that the fixed `TreeStore` substrate can express one atomic many-tree commit over one shared in-memory store without introducing per-tree partial success
- prove that namespace and tree-id derivation preserve deterministic domain separation instead of relying on ad hoc concatenation
- prove that rollback semantics remain full-store and version-consistent by construction, using the same state set already covered by `snap_store()` and `restore_store()`

### ✅ 2.10 Exit condition

**✅ Start Phase 3 only when every touched logical tree has a private `TreeId`, one deterministic physical namespace strategy, and the fixed shared-store `TreeStore` substrate is fully specified.**

## ⚙️ Phase 3. Transaction Coordinator And Atomic Commit Path

### 🎯 3.1 Execution intent

**📌 Build one rollback-capable internal write path that can commit many child trees under one shared version.**

### 🚨 3.2 Critical rule

> [!Warning]
> Do not start rewriting `AssetStore` methods until the coordinator can express a full transition from asset leaves up to the definition root and path index.
> Do not start any parallel shard work before one serialized pre-pass proves there is no duplicate `AssetId` binding conflict and no duplicate canonical `AssetPath` conflict inside the incoming batch.

### 🔑 3.3 Required behavior

- one transition version for all touched trees
- bottom-up recalculation order
- child-tree failure must prevent parent-root commit
- reverse lookup write, delete, and prune must share the same atomic boundary
- parallel shard build must still fold parent inputs in one deterministic canonical order
- no child-tree batch may be committed independently; all tree-local batches must remain uncommitted until one final shared `TxCoord` commit assembles the whole transition

### 🔑 3.4 Required file targets

- `crates/z00z_storage/src/assets/store_internal/tx_plan.rs`
- proposed private coordinator files from Phase 2 if created
- `crates/z00z_storage/src/assets/store.rs`

### 🔑 3.5 Required outputs

- one committed internal coordinator path that can plan and atomically commit many touched trees under one shared version
- one rollback test result that proves no parent-root commit survives a child-tree failure
- one determinism test result that proves worker scheduling does not change the external root

### ⚙️ 3.6 Serialized steps

1. Replace the current flat `TxPlan` with a subtree-aware `ShardPlan` plus `TreeBatch` plan.
2. Run one serialized global validation pass that rejects duplicate canonical `AssetPath` values, duplicate terminal `AssetId` bindings, malformed paths, and path-leaf mismatches before any shard split starts.
3. Build child asset-tree batches first, but keep them staged in memory only.
4. Sort child asset-tree outputs by canonical `(definition_id, serial_id, asset_id)` order before deriving any parent inputs.
5. Build serial-tree parent updates from child asset-tree roots, still without mutating the shared store.
6. Sort serial-tree outputs by canonical `definition_id` then `serial_id` order before deriving definition inputs.
7. Build definition-tree parent updates from child serial-tree roots, still without mutating the shared store.
8. Build path-index updates in the same staged transition.
9. Assemble one full many-tree commit set and pass it through one `TxCoord` write path.
10. Roll back all in-memory state and staged private tree roots if final shared commit assembly or final shared commit application fails.

### ⚙️ 3.7 Parallelizable steps

- build `AssetTree` batches for disjoint `(definition_id, serial_id)` pairs in parallel
- build `SerialTree` batches for disjoint `definition_id` values in parallel after asset-tree roots are known
- root finalization and atomic commit must remain serialized

### 👁️‍🗨️ 3.8 Pseudocode sketch

```text
plan = shard_ops(ops)
asset_batches = parallel_build_asset_batches(plan.asset_groups)
asset_batches = sort_asset_batches(asset_batches)
serial_inputs = collect_serial_roots(asset_batches)
serial_batches = parallel_build_serial_batches(serial_inputs)
serial_batches = sort_serial_batches(serial_batches)
def_inputs = collect_definition_roots(serial_batches)
def_batch = build_definition_batch(def_inputs)
path_batch = build_path_index_batch(plan.path_ops)
tx_coord.commit(version, asset_batches, serial_batches, def_batch, path_batch)
```

### ✅ 3.9 Validation gate

- injected child-tree failure must leave no committed parent root
- rollback must remove stale path-index entries
- one successful transition must produce one externally visible version
- same logical operation batch must produce the same external root regardless of worker scheduling
- no test may observe an externally visible partial child-tree commit before the final shared commit point
- run `cargo check -p z00z_storage`
- run `cargo test -p z00z_storage whitebox_state`
- run `cargo test -p z00z_storage whitebox_paths`

### ✅ 3.10 Exit condition

**✅ Start Phase 4 only when one full bottom-up transition can be planned and committed without exposing per-tree partial success.**

## ⚙️ Phase 4. AssetStore Backend Refactor

### 🎯 4.1 Execution intent

**📌 Rewire `AssetStore` to the new multi-tree backend while keeping the current public method set unchanged.**

> [!Note]
> In this workflow, `real child trees` means distinct logical child trees with independent `TreeId`, root tracking, proof sourcing, and routed read/write paths. It does not mean one separate durable database per child tree.

### 🔑 4.2 Frozen public API

- `put_item(&mut self, item: StoreItem) -> Result<AssetStateRoot, AssetStoreError>`
- `get_item(&self, path: &AssetPath) -> Result<Option<StoreItem>, AssetStoreError>`
- `del_item(&mut self, path: &AssetPath) -> Result<AssetStateRoot, AssetStoreError>`
- `proof_item(&self, path: &AssetPath) -> Result<ProofItem, AssetStoreError>`
- `apply_ops(&mut self, ops: Vec<StoreOp>) -> Result<AssetStateRoot, AssetStoreError>`
- `root(&self) -> Result<AssetStateRoot, AssetStoreError>`

### 🔑 4.3 Required file targets

- `crates/z00z_storage/src/assets/store.rs`
- `crates/z00z_storage/src/assets/model.rs`
- `crates/z00z_storage/src/assets/types.rs`
- `crates/z00z_storage/src/assets/keys.rs`
- proposed private backend files chosen in Phase 2

### 🔑 4.4 Required outputs

- one `AssetStore` implementation backed by real logical child trees routed through the shared-store `TreeStore`
- one preserved public facade in `mod.rs` and `lib.rs`
- one storage-side parity report against `AssetModel`

### ⚙️ 4.5 Serialized steps

1. Replace flat asset-leaf reads with routed reads into `AssetTree(definition_id, serial_id)`.
2. Replace flat proofs with routed proof reads from the correct child trees.
3. Replace the current single `flat_root` state with private root tracking per tree plus one external `AssetStateRoot`.
4. Keep `AssetModel` as the parity oracle until all storage tests prove concrete equality.
5. Preserve `resolve_path` behavior through the private path-index tree.
6. Preserve wrong-path rejection and serial-mismatch rejection semantics.

### ⚙️ 4.6 Parallelizable steps

- read-path rewiring and write-path rewiring can proceed in parallel only after the coordinator interface is frozen
- parity-test updates can run in parallel with internal root-cache updates

### ✅ 4.7 Validation gate

- every storage test that currently proves path, delete, rollback, and root determinism must stay green after the backend swap
- no public file outside `z00z_storage` may require code changes for type exposure only
- run `cargo test -p z00z_storage`

### ✅ 4.8 Exit condition

**✅ Start Phase 5 only when `AssetStore` is backed by real logical child trees with distinct `TreeId`/root routing and still exports the same public signatures.**

## ⚙️ Phase 5. Proof Path Rewire

### 🎯 5.1 Execution intent

**📌 Rebuild proof production so `ProofItem` and `ProofBlob` are grounded in real child-tree proofs instead of flat-tree aggregate proof assembly.**

### 🔑 5.2 Required file targets

- `crates/z00z_storage/src/assets/proof.rs`
- `crates/z00z_storage/src/assets/store.rs`
- `crates/z00z_storage/src/assets/types.rs`
- `crates/z00z_storage/src/assets/store_internal/whitebox_proofs.rs`
- `crates/z00z_storage/tests/assets/store_api.rs`

### 🔑 5.3 Required behavior

- asset proof must come from the real `AssetTree(definition_id, serial_id)`
- serial proof must come from the real `SerialTree(definition_id)`
- definition proof must come from `DefinitionTree`
- witness codec must still be storage-owned and private to `z00z_storage`

### 🔑 5.4 Required outputs

- one proof-builder path that sources all three proof layers from concrete child trees
- one storage proof parity result against `AssetModel::proof_case`
- one replay-rejection result set for wrong root, wrong path, wrong leaf hash, and wrong upper-level root leaf

### ⚙️ 5.5 Serialized steps

1. Freeze the current `ProofItem` semantic shape.
2. Rewrite `proof_item()` to load child-tree roots from the concrete backend rather than reconstructing them only through the model.
3. Rewrite `proof_blob()` to encode the three physical proof layers plus the terminal leaf hash.
4. Keep negative replay cases for wrong root, wrong path, wrong leaf, and wrong upper-level root leaf.

### ✅ 5.6 Validation gate

- `ProofItem` must still agree with `AssetModel::proof_case`
- `ProofBlob` round-trip and replay rejection tests must stay green
- run `cargo test -p z00z_storage --release`

### ✅ 5.7 Exit condition

**✅ Start Phase 6 only when proof construction uses real child-tree proofs and wallet-facing proof bytes remain source-compatible.**

## ⚙️ Phase 6. Downstream Adapter Stabilization

### 🎯 6.1 Execution intent

**📌 Keep wallet and simulator code stable on the same facade while adapting them to the new proof and path-resolution internals only where required.**

### 🔑 6.2 Required file targets

- `crates/z00z_wallets/src/core/tx/{state_update.rs,witness_gate.rs,spending.rs,claim_tx.rs}`
- `crates/z00z_wallets/tests/{test_tx_spent_gate.rs,test_phase24_gate.rs,test_tx_wrong_root.rs}`
- `crates/z00z_simulator/src/{claim_pkg_consumer.rs,scenario_1/stage_4.rs,scenario_1/stage_6.rs}`
- `crates/z00z_simulator/tests/test_claim_tx_pipeline.rs`

> [!Caution]
> Additional downstream files may become in-scope only if compile failures or behavior regressions point to them after the storage backend swap. Do not start by editing wider wallet or simulator modules that have no verified direct storage anchor.

### 🔑 6.3 Required outputs

- one downstream compatibility result for wallet typed-root flows
- one downstream compatibility result for simulator claim pipeline flows
- one proof-decoding compatibility result for `claim_tx.rs`

### ⚙️ 6.4 Serialized steps

1. Verify that no downstream crate imports private storage internals.
2. Keep wallet and simulator trait signatures unchanged.
3. Verify that `claim_tx.rs` still accepts storage-owned proof bytes and still maps proof decode failures into the existing wallet error taxonomy.
4. Verify that storage-backed adapters still resolve terminal `asset_id` through the private path-index path.
5. Verify that `CheckRoot` still comes only from storage-owned root conversion.
6. Re-run all wrong-root, proof, and reject-class tests.

### ⚙️ 6.5 Parallelizable steps

- wallet validation and simulator validation can run in parallel after storage proof outputs are frozen

### ✅ 6.6 Validation gate

- run `cargo check -p z00z_wallets`
- run `cargo check -p z00z_simulator`
- targeted wallet tests green
- targeted simulator pipeline green
- no downstream code reconstructs `definition_id` heuristically
- no downstream code imports `jmt` directly
- no downstream change widens `claim_tx` proof-decoding inputs or output error classes
- run `cargo test -p z00z_wallets --features test-fast --features wallet_debug_dump --test test_tx_spent_gate`
- run `cargo test -p z00z_wallets --features test-fast --features wallet_debug_dump --test test_phase24_gate`
- run `cargo test -p z00z_wallets --features test-fast --features wallet_debug_dump --test test_tx_wrong_root`
- run `cargo test -p z00z_simulator --features test-fast --features wallet_debug_dump --test test_claim_tx_pipeline`

### ✅ 6.7 Exit condition

**✅ Start Phase 7 only when downstream code stays on the same public facade and all typed-root gates are green.**

## ⚙️ Phase 7. Benchmark Harness And Shard Validation

### 🎯 7.1 Execution intent

**📌 Prove that the new physical layout yields measurable benefit for disjoint subtree workloads and does not regress core storage operations.**

### 🔑 7.2 Required new infrastructure

**📌 Extend the minimal benchmark harness introduced in Phase 1 into the full comparison matrix for the refactor.**

Required targets:

- `crates/z00z_storage/Cargo.toml`
- proposed `crates/z00z_storage/benches/assets_shard.rs`
- proposed `crates/z00z_storage/benches/common/fixture.rs`

Required benchmark dependency:

- `criterion`

### 🔑 7.3 Required outputs

- one criterion baseline named `current_single_jmt`
- one criterion baseline named `nested_jmt_serial`
- one criterion baseline named `nested_jmt_parallel`
- one benchmark report under `crates/z00z_storage/outputs/assets/jmt-refactor-bench.md`
- one explicit conclusion in that report stating whether the workflow's shard-performance claim is confirmed, rejected, or still blocked by harness limitations

### ⏰ 7.4 Benchmark data source

**📌 Use `crates/z00z_core/src/genesis/genesis_config_devnet_small.yaml` as the reproducible dataset seed and derive realistic path distributions from it.**

### ⚙️ 7.5 Benchmark matrix

- insert on many distinct `definition_id`
- insert on one `definition_id` across many `serial_id`
- delete on many distinct `definition_id`
- update on disjoint serial buckets
- read and proof lookup by `AssetPath`
- helper-index resolution by `asset_id` plus `serial_id`

### 🔑 7.6 Required comparison modes

- baseline current single-JMT implementation
- new multi-tree implementation in serialized mode
- new multi-tree implementation with shard-parallel planning and child-tree batch build

> [!Important]
> Phase 7 is now executable because `crates/z00z_storage/benches/assets_shard.rs` exposes explicit benchmark mode selection through `Z00Z_ASSET_BENCH_MODE=current_single_jmt|nested_jmt_serial|nested_jmt_parallel`.

### ⚙️ 7.7 Serialized steps

1. Extend the Phase 1 minimal harness into a reproducible benchmark fixture builder from the devnet-small genesis config.
2. Run and store the baseline current-single-JMT benchmark if Phase 1 did not already persist it.
3. Build deterministic path sets grouped by definition and serial.
4. Measure insert, delete, update, read, and proof lookup.
5. Measure shard-parallel transitions only on disjoint shards and only after Phase 3 proves the serialized conflict pre-pass plus atomic coordinator path.
6. Publish benchmark output in `crates/z00z_storage/outputs/assets/jmt-refactor-bench.md`.

### ⚙️ 7.8 Parallelizable steps

- benchmark fixture generation and criterion harness setup can run in parallel
- operation families can run in separate benchmark groups

### ✅ 7.9 Validation gate

- benchmark harness must use `criterion::black_box`
- benchmark data must be deterministic and reproducible from the checked-in genesis config
- the new backend must show no material regression on read and delete correctness tests before performance numbers are accepted
- comparison must use the stored `current_single_jmt` baseline instead of an inferred historical estimate
- the benchmark harness must expose explicit mode selection for `nested_jmt_serial` and `nested_jmt_parallel` before Phase 8 acceptance commands are considered complete
- the report must evaluate disjoint-shard write workloads separately from non-shardable workloads; do not claim a generic speedup across all operations
- the workflow's performance-benefit claim is considered confirmed only if `nested_jmt_parallel` outperforms `current_single_jmt` on at least one disjoint-shard write workload from the benchmark matrix while preserving correctness gates
- if `nested_jmt_parallel` does not beat `current_single_jmt` on any disjoint-shard write workload, Phase 8 must not claim the performance goal is complete; the report must explicitly mark that outcome as a blocker or rejected expectation

### ✅ 7.10 Exit condition

**✅ Start Phase 8 only when benchmark results, correctness gates, and the report's explicit conclusion all exist. Phase 8 may still close with a blocked performance verdict when the report rejects the shard-speedup expectation explicitly.**

## ⚙️ Phase 8. Acceptance, Rollback, And Cleanup Lock

### 🎯 8.1 Execution intent

**📌 Close the refactor only after correctness, performance, and compatibility all pass in the right order.**

### 🔑 8.2 Required outputs

- one final acceptance record that maps the implementation state to Boundaries A through E
- one updated storage architecture description in `crates/z00z_storage/src/assets/README.md`
- one confirmed cleanup result showing which transitional private files were removed or retained
- one benchmark conclusion that explicitly states whether shard-parallel benefit was proven on the workloads that this refactor is supposed to accelerate

### ⚙️ 8.3 Serialized steps

1. Re-run storage compile and test gates.
2. Re-run targeted wallet and simulator gates.
3. Run benchmark gate and store the report.
4. Update `crates/z00z_storage/src/assets/README.md` and neighboring spec text to match the accepted architecture.
5. Remove transitional private scaffolding that is no longer required.
6. Confirm that the workflow document and migration plan still describe the accepted execution order and stop rules.

### 🚨 8.4 Rollback rule

> [!Warning]
> If any phase fails, revert to the last green boundary before continuing. Do not continue from a half-migrated storage backend.

**⚠️ A phase is not considered green until its required outputs are written and its validation gate is green.**

### ✅ 8.5 Green boundaries

- Boundary A: workflow and contract docs green
- Boundary B: private topology and coordinator compile green
- Boundary C: storage tests green
- Boundary D: downstream tests green
- Boundary E: release gate green plus a benchmark rerun with one explicit shard-performance conclusion

### ✅ 8.6 Exit condition

**✅ The refactor is complete only when the codebase exposes the same public storage facade, uses real logical child trees internally through the shared-store `TreeStore`, commits all touched trees atomically under one shared version, and records benchmark evidence together with an explicit shard-performance conclusion.**

## ✅ Acceptance Commands

**✅ Run the following commands in this order:**

```bash
cargo check -p z00z_storage
cargo test -p z00z_storage --release
cargo check -p z00z_wallets
cargo test -p z00z_wallets --release --features test-fast --features wallet_debug_dump --test test_tx_spent_gate
cargo test -p z00z_wallets --release --features test-fast --features wallet_debug_dump --test test_phase24_gate
cargo test -p z00z_wallets --release --features test-fast --features wallet_debug_dump --test test_tx_wrong_root
cargo check -p z00z_simulator
cargo test -p z00z_simulator --release --features test-fast --features wallet_debug_dump --test test_claim_tx_pipeline
cargo test --release --features test-fast --features wallet_debug_dump
```

> [!Important]
> The final release-wide command above is required because Boundary E is defined as benchmark and release gates green. Targeted wallet and simulator tests are not sufficient, by themselves, to prove the whole release feature set still compiles and runs.

**📌 The benchmark acceptance step is phase-owned and must not be collapsed into the fixed command block above.**

Verified benchmark command shape already required earlier in this workflow:

```bash
cargo bench -p z00z_storage --bench assets_shard -- --save-baseline current_single_jmt
```

> [!Caution]
> That command is the Phase 1 baseline-capture step. It is not, by itself, the final Phase 8 benchmark acceptance gate.

**📌 Additional Phase 7 benchmark commands are now verified through the implemented mode selector in `assets_shard.rs`.**

Verified command shapes:

```bash
Z00Z_ASSET_BENCH_MODE=nested_jmt_serial cargo bench -p z00z_storage --bench assets_shard -- --save-baseline nested_jmt_serial
Z00Z_ASSET_BENCH_MODE=nested_jmt_parallel cargo bench -p z00z_storage --bench assets_shard -- --save-baseline nested_jmt_parallel
```

> [!Warning]
> Do not mark Phase 8 green by re-running only the `current_single_jmt` baseline capture. Final benchmark acceptance requires the harness-defined serialized and shard-parallel runs plus the published report in `crates/z00z_storage/outputs/assets/jmt-refactor-bench.md`.
> Do not mark Phase 8 green by publishing raw benchmark numbers without an explicit conclusion about the shard-performance goal. The report must state whether the expected benefit was actually demonstrated on disjoint-shard write workloads.

## 🚨 Open Decisions And Stop Rules

> [!Important]
> The storage backend commit model is no longer open in this workflow.

Fixed rule:

- use one private `TreeStore` over one shared `MemTreeStore`
- commit all touched logical trees through one shared JMT batch boundary
- keep one external transition version
- use full in-memory rollback on failure
- do not introduce WAL or recovery-journal logic in this refactor

> [!Warning]
> Stop immediately if any of the following becomes true:

- one shared external transition version cannot be preserved across all touched trees
- parent roots can commit after failed child-tree writes
- wallet or simulator code requires a public API change to remain green
- proof bytes cannot stay owned by `z00z_storage`
- benchmark gains require breaking deterministic semantics or typed-root guarantees
- benchmark execution cannot produce an explicit shard-performance conclusion

> [!Important]
> If the benchmark report concludes that `nested_jmt_parallel` does not beat `current_single_jmt` on any disjoint-shard write workload, keep the release evidence and document the outcome as a blocker. Do not claim the performance goal is complete, but do not treat that documented blocker verdict as a reason to skip Phase 8 drift lock.
> [!Note]
> Remaining sequencing ambiguity after closing the commit-substrate decision:

- the repository does not currently include storage benchmarks, so benchmark thresholds must be set after the first reproducible baseline run
- durable crash-recovery semantics remain intentionally deferred until a persistent backend exists; they are not a blocker for this in-memory topology refactor

> [!Tip]
> Assumption used by this workflow:

- a minimal-change path is preferred over a greenfield rewrite, so the refactor must extend `store.rs`, `store_internal/`, and the current `AssetModel` parity path before introducing any additional private modules
