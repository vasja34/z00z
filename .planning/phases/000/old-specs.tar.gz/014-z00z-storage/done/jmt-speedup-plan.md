# 🔑 JMT Speedup Plan

> [!Important]
> This plan rewrites the current speedup workflow into implementation-ready execution units for `crates/z00z_storage`.
> It covers only the verified storage speedup sequence and must not be used as a license to widen public APIs or weaken semantic guarantees.

## 🎯 Scope And Constraints

**📌 This plan must deliver only these outcomes:**

- reduce the dominant commit-side serialization cost around `TreeStore::commit_all()`
- remove the eager nested `sem_root` recompute that hides the real incremental-path win
- isolate and, if safe, reduce the historical `self.model.clone()` cost in `commit_stage()`
- prove every phase with fresh benchmark evidence written under `crates/z00z_storage/outputs/assets`

**📌 This plan must preserve these invariants:**

- keep the public facade from `crates/z00z_storage/src/assets/mod.rs` unchanged
- keep one external transition version per committed state transition
- keep `AssetStateRoot`, `CheckRoot`, `ProofItem`, and `ProofBlob` semantics unchanged
- keep rollback, proof parity, and historical-version inspection green in every phase
- keep all implementation work inside the existing storage and bench structure unless a new file is explicitly marked as proposed

> [!Warning]
> This plan must not expose raw `jmt` types outside `z00z_storage`, must not modify vendored Tari code, and must not accept benchmark gains that come from semantic drift.

## 👁️‍🗨️ Verified Codebase Anchors

**📌 The following code anchors were verified before writing this plan:**

- `crates/z00z_storage/src/assets/store_internal/tree_store.rs`
- `crates/z00z_storage/src/assets/store_internal/tx_plan.rs`
- `crates/z00z_storage/src/assets/model.rs`
- `crates/z00z_storage/src/assets/store_internal/whitebox_state.rs`
- `crates/z00z_storage/src/assets/store_internal/whitebox_help.rs`
- `crates/z00z_storage/tests/assets_suite.rs`
- `crates/z00z_storage/benches/assets/shard.rs`
- `crates/z00z_storage/benches/assets/nested.rs`
- `crates/z00z_storage/benches/common/output.rs`
- `crates/z00z_storage/scripts/run_storage_assets_shard_bench.sh`
- `crates/z00z_storage/scripts/run_storage_assets_nested_bench.sh`

**📌 Verified current implementation facts that constrain the plan:**

- `TreeStore::commit_all()` in `tree_store.rs` still flattens all logical batches into one `put_value_set(...)` path and one `apply_batch(...)` call
- `next_roots()` in `tx_plan.rs` still computes `state_root_from_defs(&def_leaves)` before the final root-mode decision
- `plan_root()` in `tx_plan.rs` still recomputes the top semantic root in full mode and reuses `tree_roots.sem_root` in incremental mode
- `commit_stage()` in `tx_plan.rs` still inserts `self.model.clone()` into `model_by_ver`
- `AssetModel` exists in `crates/z00z_storage/src/assets/model.rs`
- `whitebox_state.rs`, `whitebox_help.rs`, and `assets_suite.rs` already exist and must be reused before proposing parallel test structures
- `assets_nested` executes all four planner and root-mode combinations in one run and does not support a full-only or incremental-only runtime selector
- `crates/z00z_storage/outputs/assets` is currently covered by the repository-wide `**/outputs` ignore rule

```mermaid
flowchart TD
    A[Phase 1<br/>Measure wall] --> B[Phase 2<br/>Shrink commit serialization]
    B --> C[Phase 3<br/>Remove eager sem_root recompute]
    C --> D[Phase 4<br/>Classify and optimize model clone]
    D --> E[Phase 5<br/>Final acceptance and direction lock]
```

```mermaid
sequenceDiagram
    participant Bench as Bench Wrapper
    participant Plan as tx_plan.rs
    participant Tree as tree_store.rs
    participant Hist as model_by_ver

    Bench->>Plan: apply_ops benchmark case
    Plan->>Plan: precheck_ops + next_roots + plan_root
    Plan->>Tree: commit_all(version, batches)
    Tree->>Tree: put_value_set(all ops)
    Tree->>Tree: apply_batch(batch)
    Plan->>Hist: model_by_ver.insert(version, self.model.clone())
    Bench->>Bench: write log and markdown artifact
```

## ❓ Assumptions, Blockers, And Open Decisions

**📌 The following decisions remain explicit and must not be hidden inside implementation work:**

- if a dedicated timing helper file becomes necessary, it must be labeled as proposed rather than treated as an existing codebase fact
- if `model_by_ver` cannot be made cheaper without changing historical semantics, Phase 4 must stop at measurement and publish the blocker
- if a benchmark summary must be tracked in Git, the execution must first add a precise `.gitignore` exception or mirror the summary into a tracked path
- if nested wrapper output already contains enough evidence, the plan must not invent a second public benchmark path only for aesthetics
- if the execution wants stable markdown file names, it must pass explicit `--log-base` values or write a separate mirrored summary file, because the current bench runner derives default output names from the invoked bench arguments

> [!Caution]
> The plan must not treat existing benchmark markdown files as permanent truth. Every hot-path change must be followed by a fresh measurement pass on the same code revision.

## ⚙️ Phase 1. Measure The Commit Serialization Wall

### 🔔 Implement Phase 1 Timing Surface

**📌 Required behavior:** the first phase must add a private measurement surface that can attribute nested write cost to planning, root maintenance, final commit, optional batch application, and historical model capture.

**📌 Canonical implementation shape:**

- keep timing collection private to the bench layer or test-only storage internals
- prefer extending `crates/z00z_storage/benches/assets/nested.rs` and `crates/z00z_storage/benches/common/output.rs`
- reuse existing execution through `AssetStore::apply_ops()` and existing wrapper scripts
- if a helper module is required, use a proposed bench-local helper such as `crates/z00z_storage/benches/common/timing.rs`

**📌 Target files:**

- `crates/z00z_storage/benches/assets/nested.rs`
- `crates/z00z_storage/benches/assets/shard.rs`
- `crates/z00z_storage/benches/common/output.rs`
- `crates/z00z_storage/src/assets/store_internal/tx_plan.rs`
- `crates/z00z_storage/src/assets/store_internal/tree_store.rs`
- proposed `crates/z00z_storage/benches/common/timing.rs`

**📌 Required measured segments:**

- `precheck_ops()` plus `NextState` application
- `next_roots()`
- `TreeStore::commit_all()`
- `apply_batch(...)` only if the segment can be isolated without changing commit semantics
- `model_by_ver.insert(version, self.model.clone())`

**📌 Ordering constraints:**

- do not expose timing hooks through the public storage facade
- do not add a second public benchmark binary before proving the existing nested host is insufficient
- serialize interpretation of timing output after all Phase 1 measurements are captured on one revision

**📌 Test and acceptance expectations:**

- both `assets_shard` and `assets_nested` must still compile cleanly
- the produced timing output must identify the dominant wall-time segment for the nested full rows
- the measurement artifacts must include command lines and output file names

**✔️ Implementation Checklist:**

- [x] Extend `crates/z00z_storage/benches/assets/nested.rs` to emit or collect private timing data for the nested write path without changing benchmark semantics.
- [x] Reuse `crates/z00z_storage/benches/common/output.rs` for metadata output and extend it only if command or timing fields are missing.
- [x] Add instrumentation points in `crates/z00z_storage/src/assets/store_internal/tx_plan.rs` around `precheck_ops`, `next_roots`, and `commit_stage` only through private or test-only paths.
- [x] Add instrumentation points in `crates/z00z_storage/src/assets/store_internal/tree_store.rs` around `commit_all()` and, if safe, `apply_batch(...)`.
- [x] If helper logic becomes repetitive, introduce proposed `crates/z00z_storage/benches/common/timing.rs` and label it as a new file in the implementation diff.
- [x] Keep all timing code English-only and avoid widening any public API.
- [x] Verify `cargo bench -p z00z_storage --bench assets_nested --no-run` and `cargo bench -p z00z_storage --bench assets_shard --no-run` still pass.

### 🔔 Execute Phase 1 Measurements And Record The Baseline

**📌 Required behavior:** the first evidence pass must establish the nested full-path baseline before any performance refactor starts.

**📌 Canonical measurement path:**

- run the canonical nested wrapper and interpret the `nested_jmt_serial/full` and `nested_jmt_parallel/full` rows from the four-mode output
- use `assets_shard` only for supporting root-mode context, not as a substitute for nested end-to-end evidence
- if the four-mode nested run does not expose enough timing detail, run the proposed private timing harness from the same revision

**📌 Output expectations:**

- one markdown artifact that states which segment dominates nested full-mode wall time
- one explicit note that says whether the artifact remains runtime-only or is mirrored to a tracked path
- one baseline comparison reference for Phase 2

> [!Important]
> Phase 1 is incomplete if it reports only intuition such as “commit is probably dominant.” The artifact must name the measured dominant segment.

**✔️ Implementation Checklist:**

- [x] Run `./crates/z00z_storage/scripts/run_storage_assets_nested_bench.sh` on the Phase 1 revision and retain the nested full rows as the baseline comparison set.
- [x] Run supporting `assets_shard` commands only if they are needed to interpret root-mode behavior separately from nested end-to-end cost.
- [x] Store logs and markdown output under `crates/z00z_storage/outputs/assets`.
- [x] Add a phase-local note that states whether the benchmark summary stays runtime-only or must also be mirrored into a tracked path.
- [x] Record exact commands, output file names, and the dominant measured segment for later phases.

**📌 Phase 1 note (2026-03-21):**

- runtime-only artifacts: `crates/z00z_storage/outputs/assets/phase1_nested_wall.log`, `crates/z00z_storage/outputs/assets/phase1_nested_wall.md`, `crates/z00z_storage/outputs/assets/phase1_nested_wall.tsv`, `crates/z00z_storage/outputs/assets/phase1_nested_timing.md`, `crates/z00z_storage/outputs/assets/phase1_shard_full.log`, and `crates/z00z_storage/outputs/assets/phase1_shard_full.md`
- canonical nested baseline command: `./crates/z00z_storage/scripts/run_storage_assets_nested_bench.sh --baseline phase1_nested_wall --log-base phase1_nested_wall`
- supporting shard command: `./crates/z00z_storage/scripts/run_storage_assets_shard_bench.sh --bench-mode nested_jmt_serial --root-mode current_full_recompute --baseline phase1_shard_full --log-base phase1_shard_full`
- private timing probe command: `Z00Z_ASSET_TIME_PROBE=1 cargo bench -p z00z_storage --bench assets_nested`
- dominant measured nested full-row segment: `precheck_ops`

## ⚙️ Phase 2. Refactor The Commit-Side Serialization Path

### 🔔 Reshape `commit_all()` Without Changing Commit Semantics

**📌 Required behavior:** the second phase must reduce the dominant serialized region while preserving one external transition version and one semantic commit boundary.

**📌 Canonical implementation shape:**

- keep `TreeBatch`, `TreeStore`, and `tx_plan.rs` as the main batching path
- move deterministic preparation work out of the final serialized commit region
- keep one final shared mutation path through `put_value_set(...)` plus `apply_batch(...)` unless the current substrate proves that a different private shape is necessary

**📌 Target files:**

- `crates/z00z_storage/src/assets/store_internal/tree_store.rs`
- `crates/z00z_storage/src/assets/store_internal/tx_plan.rs`

**📌 Write-flow contract:**

1. derive all touched tree batches first
2. prebuild namespace-wrapped key-value operations before the final commit section
3. enter the serialized commit section once
4. execute `put_value_set(...)`
5. execute `apply_batch(...)`
6. update flat-store version markers
7. merge semantic next state only after commit succeeds

**📌 Invariants and rejection rules:**

- rollback after any failure must restore pre-commit state exactly
- semantic roots and historical version visibility must remain byte-identical for successful transitions
- no partial version leak may remain visible through whitebox state checks

**✔️ Implementation Checklist:**

- [x] Review `crates/z00z_storage/src/assets/store_internal/tree_store.rs` and isolate deterministic prework that currently happens too close to the serialized commit section.
- [x] Refactor `commit_all()` so batch flattening, namespacing, and allocation work moves earlier without changing the external commit boundary.
- [x] Keep the final shared mutation path private and reuse the existing `TreeBatch` representation.
- [x] Recheck `crates/z00z_storage/src/assets/store_internal/tx_plan.rs` call sites so they still feed the same logical batches into `commit_all()`.
- [x] Avoid introducing a second commit abstraction unless the existing path cannot support the refactor.

### 🔔 Prove Rollback And Version Safety After The Commit Refactor

**📌 Required behavior:** Phase 2 must prove that the commit-path rewrite does not trade correctness for speed.

**📌 Target files:**

- `crates/z00z_storage/src/assets/store_internal/whitebox_state.rs`
- `crates/z00z_storage/src/assets/store_internal/whitebox_help.rs`
- `crates/z00z_storage/tests/assets_suite.rs`

**📌 Required tests:**

- forced commit-failure rollback coverage
- no partial version leak into `model_by_ver` or root history
- semantic and proof parity coverage through existing integration targets

**📌 Acceptance conditions:**

- `cargo test -p z00z_storage --lib`
- `cargo test -p z00z_storage --test assets_suite`
- refreshed nested matrix with comparison against the Phase 1 full rows

**✔️ Implementation Checklist:**

- [x] Extend `crates/z00z_storage/src/assets/store_internal/whitebox_state.rs` with failure-path assertions that prove pre-commit state restoration after a forced commit failure.
- [x] Reuse helpers from `crates/z00z_storage/src/assets/store_internal/whitebox_help.rs` instead of adding duplicate whitebox fixtures.
- [x] Extend `crates/z00z_storage/tests/assets_suite.rs` only where integration coverage is required for externally visible parity.
- [x] Run `cargo test -p z00z_storage --lib` and `cargo test -p z00z_storage --test assets_suite` after the refactor.
- [x] Run `./crates/z00z_storage/scripts/run_storage_assets_nested_bench.sh` and compare only the refreshed `nested_jmt_serial/full` and `nested_jmt_parallel/full` rows against Phase 1.
- [x] Publish a comparison artifact under `crates/z00z_storage/outputs/assets` before starting Phase 3.

**📌 Phase 2 note:** the public integration suite stayed unchanged because the refactor did not alter external asset-store behavior. External parity was validated by rerunning `cargo test -p z00z_storage --test assets_suite`, and the Phase 2 comparison artifact is stored in `crates/z00z_storage/outputs/assets/phase2_nested_compare.md`.

## ⚙️ Phase 3. Remove The Eager Nested `sem_root` Recompute

### 🔔 Separate Full-Mode And Incremental-Mode Semantic Root Work

**📌 Required behavior:** Phase 3 must make incremental mode avoid the unconditional top semantic-root recompute that currently happens inside `next_roots()`.

**📌 Canonical implementation shape:**

- keep canonical definition ordering as the source of truth
- keep full mode as the semantic oracle path
- let incremental mode reuse cached incremental state rather than paying the same eager recompute path as full mode

**📌 Target files:**

- `crates/z00z_storage/src/assets/store_internal/tx_plan.rs`
- `crates/z00z_storage/src/assets/model.rs`

**📌 Required API and data-shape expectations:**

- `next_roots()` must no longer unconditionally compute `state_root_from_defs(&def_leaves)` for every root mode
- `plan_root()` must clearly separate full-mode top-root derivation from incremental-mode reuse
- no second semantic source of truth may be added outside the existing `TreeRoots`-driven path unless explicitly justified by code constraints

**📌 Acceptance conditions:**

- incremental mode no longer pays the same eager top-level semantic recompute as full mode
- full and incremental paths remain byte-identical for the same committed state

**✔️ Implementation Checklist:**

- [x] Refactor `crates/z00z_storage/src/assets/store_internal/tx_plan.rs` so `def_root` maintenance and `sem_root` maintenance are separated explicitly.
- [x] Change `next_roots()` to skip unconditional top semantic-root recomputation when the selected root mode does not require it.
- [x] Change `plan_root()` so full mode recomputes from canonical `def_leaves` and incremental mode consumes the cached incremental state.
- [x] Reuse `crates/z00z_storage/src/assets/model.rs` only for the state needed to preserve semantic parity; do not create a parallel semantic-cache type unless the current model shape forces it.
- [x] Keep all new identifiers within the repository naming rules and avoid long names that violate the five-word limit.

### 🔔 Prove Full And Incremental Parity After The Root-Path Change

**📌 Required behavior:** Phase 3 must demonstrate that the root-path optimization changes cost, not semantics.

**📌 Target files:**

- `crates/z00z_storage/src/assets/store_internal/whitebox_state.rs`
- `crates/z00z_storage/src/assets/store_internal/whitebox_help.rs`
- `crates/z00z_storage/benches/assets/shard.rs`
- `crates/z00z_storage/benches/assets/nested.rs`

**📌 Required tests and benchmarks:**

- whitebox parity assertions for the same transition shapes under full and incremental modes
- isolated root-mode benchmark pair through `assets_shard`
- refreshed nested four-mode matrix through `assets_nested`

**📌 Comparison rule:** compare Phase 3 results against the immediately previous Phase 2 matrix, not against the older Phase 1 numbers.

**✔️ Implementation Checklist:**

- [x] Extend `crates/z00z_storage/src/assets/store_internal/whitebox_state.rs` with parity assertions for identical transitions under full and incremental root modes.
- [x] Reuse `crates/z00z_storage/src/assets/store_internal/whitebox_help.rs` for common state inspection rather than adding duplicate parity helpers.
- [x] Run `cargo test -p z00z_storage --lib` and `cargo test -p z00z_storage --test assets_suite` on the Phase 3 revision.
- [x] Run `./crates/z00z_storage/scripts/run_storage_assets_shard_bench.sh --bench-mode nested_jmt_serial --root-mode current_full_recompute --baseline current_full_recompute`.
- [x] Run `./crates/z00z_storage/scripts/run_storage_assets_shard_bench.sh --bench-mode nested_jmt_serial --root-mode current_incremental --baseline current_incremental`.
- [x] Run `./crates/z00z_storage/scripts/run_storage_assets_nested_bench.sh` and compare the refreshed matrix only against the Phase 2 matrix.
- [x] Publish a delta note that separates root-mode gains from nested end-to-end gains.

**📌 Phase 3 note:** the root-path refactor now keeps cached definition rows inside `TreeRoots`, so full mode recomputes the top semantic root only in `plan_root()` while incremental mode consumes the cached row set. The isolated `assets_shard` pair shows a large win for `semantic_root`, but the refreshed nested matrix still regresses against Phase 2 on this revision. The Phase 3 delta artifact is stored in `crates/z00z_storage/outputs/assets/phase3_root_delta.md`.

## ⚙️ Phase 4. Isolate And Optimize Historical Model Clone Cost

### 🔔 Classify The Post-Commit History Cost

**📌 Required behavior:** Phase 4 must first prove whether `self.model.clone()` remains a dominant, secondary, or negligible cost after the first two optimizations.

**📌 Canonical implementation shape:**

- instrument `self.model.clone()` and `model_by_ver.insert(...)` as one explicit measured segment
- reuse the Phase 1 timing surface when it already exists
- do not start history-shape refactors until the cost classification artifact exists

**📌 Target files:**

- `crates/z00z_storage/src/assets/store_internal/tx_plan.rs`
- `crates/z00z_storage/src/assets/model.rs`

**📌 Acceptance conditions:**

- the plan can state with evidence whether model history capture is still a meaningful post-commit wall
- the classification artifact exists before any history-layout change lands

**✔️ Implementation Checklist:**

- [x] Reuse the Phase 1 timing path to isolate `self.model.clone()` plus `model_by_ver.insert(...)` on the Phase 4 revision.
- [x] Store the classification artifact under `crates/z00z_storage/outputs/assets` with exact commands and timings.
- [x] Record whether clone cost is dominant, secondary, or negligible relative to the current nested full rows.
- [x] Stop Phase 4 immediately if the measurement shows the clone path is no longer a meaningful optimization target.

**📌 Phase 4 note (2026-03-21):** the reused timing probe shows `model_hist` between `82 ns` and `23.591 us` across the current nested full rows, with a worst-case end-to-end share of `0.5587%` on `nested_root_mix_ops/nested_jmt_parallel/full`. The dominant full-row stage is still `precheck_ops`, so history capture is currently a negligible optimization target. Phase 4 therefore stops after classification, and the blocker artifact is stored in `crates/z00z_storage/outputs/assets/phase4_hist_class.md`.

### 🔔 Optimize History Capture Only If Semantics Stay Intact

**📌 Required behavior:** any Phase 4 optimization must preserve historical-version semantics, rollback behavior, and proof parity.

**📌 Allowed optimization order:**

1. structural sharing inside `AssetModel` if the current type shape supports it
2. narrower versioned payload only if historical readers still observe identical semantics
3. delayed or conditional history materialization only if successful and failed transitions preserve identical externally visible behavior

**📌 Target files:**

- `crates/z00z_storage/src/assets/store_internal/tx_plan.rs`
- `crates/z00z_storage/src/assets/model.rs`
- `crates/z00z_storage/src/assets/store_internal/whitebox_state.rs`
- proposed `crates/z00z_storage/src/assets/store_internal/history.rs`

> [!Warning]
> If no safe reduction path exists, the correct Phase 4 outcome is a published blocker, not a speculative history redesign.

**✔️ Implementation Checklist:**

- [x] Stop the optimization path immediately because Phase 4 classification proved `model_hist` is not a meaningful wall on this revision.
- [x] Do not introduce proposed `crates/z00z_storage/src/assets/store_internal/history.rs` while the blocker path remains active.
- [x] Reuse the existing historical-version assertions unchanged because no history refactor landed.
- [x] Do not run the post-refactor Phase 4 test pass because no history optimization was applied on this path.
- [x] Do not rerun the post-refactor nested and timing pass because the blocker path ended Phase 4 before any code change.
- [x] Publish an explicit blocker artifact before entering Phase 5.

**📌 Phase 4 blocker note (2026-03-21):** the optimization branch was intentionally not executed after classification. `phase4_hist_class.md` is the required blocker artifact for this subsection, no history-layout code changed on the Phase 4 path, and the next execution step therefore moved directly to Phase 5 final acceptance.

## ⚙️ Phase 5. Final Benchmark Gate And Direction Lock

### 🔔 Execute Final Acceptance Benchmarks

**📌 Required behavior:** the last phase must lock the final performance conclusion on one revision with one consistent acceptance run set.

**📌 Required commands:**

```bash
cargo test -p z00z_storage --lib
cargo test -p z00z_storage --test assets_suite
./crates/z00z_storage/scripts/run_storage_assets_shard_bench.sh --bench-mode nested_jmt_serial --root-mode current_full_recompute --baseline current_full_recompute
./crates/z00z_storage/scripts/run_storage_assets_shard_bench.sh --bench-mode nested_jmt_serial --root-mode current_incremental --baseline current_incremental
./crates/z00z_storage/scripts/run_storage_assets_nested_bench.sh
```

**📌 Conditional command:** rerun the Phase 1 timing harness only if Phase 1 introduced a dedicated measurement path beyond the nested wrapper output.

**📌 Acceptance conditions:**

- all validation gates are green on the final revision
- root-mode and nested benchmark artifacts match the final code state
- the final conclusion states clearly whether planner-parallel mode wins anywhere

**✔️ Implementation Checklist:**

- [x] Run `cargo test -p z00z_storage --lib` on the final revision.
- [x] Run `cargo test -p z00z_storage --test assets_suite` on the final revision.
- [x] Run the two `assets_shard` root-mode commands and retain the output artifacts under `crates/z00z_storage/outputs/assets`.
- [x] Run `./crates/z00z_storage/scripts/run_storage_assets_nested_bench.sh` and retain the four-mode output artifacts under `crates/z00z_storage/outputs/assets`.
- [x] Rerun the Phase 1 timing harness only if that harness exists on the chosen path.

**📌 Phase 5 gate note (2026-03-21):** the final acceptance run set is green, and the final artifacts are stored under `crates/z00z_storage/outputs/assets` with the `phase5_*` prefix.

### 🔔 Publish The Final Decision Artifact

**📌 Required behavior:** Phase 5 must finish with one explicit engineering conclusion rather than a loose collection of logs.

**📌 Required artifact content:**

- exact commands
- exact output files
- median timings
- dominant segment conclusion
- statement of whether planner-parallel mode wins on any workload
- statement of whether the artifact is runtime-only or mirrored to a tracked path

**📌 Required artifact targets:**

- the wrapper-generated markdown files produced by the final `assets_shard` and `assets_nested` commands under `crates/z00z_storage/outputs/assets`
- one final breakdown artifact only if Phase 1 introduced a dedicated breakdown markdown; otherwise the final breakdown summary must live inside the refreshed nested benchmark markdown or this plan file
- optional mirrored summary files such as `crates/z00z_storage/outputs/assets/jmt-incremental-bench.md` and `crates/z00z_storage/outputs/assets/jmt-overlay-bench.md` only if the execution explicitly chooses stable names via `--log-base` or a separate summary-write step

> [!Important]
> Because `crates/z00z_storage/outputs/assets` is ignored by Git, the final publication step must explicitly choose between runtime-only artifacts and a tracked mirror path before claiming that benchmark evidence is checked in.
> [!Note]
> The current runner in `crates/z00z_storage/scripts/run_storage_assets_bench.py` does not create `jmt-incremental-bench.md` or `jmt-overlay-bench.md` by default. It writes report names from `--log-base`, `--baseline`, or the bench arguments when neither is provided.

**✔️ Implementation Checklist:**

- [x] Retain the wrapper-generated markdown files from the final acceptance commands as the primary evidence set.
- [x] If stable summary file names are required, rerun with explicit `--log-base` values or write a mirrored summary file that references the wrapper-generated outputs.
- [x] State explicitly whether planner-parallel mode is a proven win, a workload-specific win, or still not a win.
- [x] State explicitly which segment remains dominant if no full end-to-end win was achieved.
- [x] Choose and record one artifact policy: runtime-only output or tracked mirror path.
- [x] Stop the sequence with an explicit blocker note if the final evidence remains inconclusive or contradicts the expected speedup direction.

**📌 Phase 5 note (2026-03-21):** the final decision artifact is stored in `crates/z00z_storage/outputs/assets/phase5_final_decision.md`. Planner-parallel mode is still not a win on any measured workload, isolated incremental root-mode wins remain real, and the dominant nested full-row segment is still `precheck_ops`. The final evidence therefore stays runtime-only and ends with an explicit blocker note rather than a claim of broad end-to-end speedup.

## 🚨 Stop Rules And Recovery Guidance

**📌 The execution must stop and publish a blocker if any of the following occurs:**

- a commit refactor changes externally visible root or proof semantics
- incremental and full modes disagree on semantic roots for the same state
- history optimization weakens versioned state guarantees
- benchmark numbers improve while validation gates regress

> [!Warning]
> A faster benchmark with weaker semantics is a failed implementation outcome.

**📌 Recovery order after a failed phase:**

1. revert only the current phase changes
2. rerun the last green validation gate
3. keep the last valid benchmark artifact
4. record the blocker and the failing command before exploring another optimization path

## ✅ Completion Definition

**📌 This plan is complete only when all of the following are true:**

- every phase was executed in order with fresh measurements on the phase revision
- commit-side serialization was reduced or explicitly proven to remain the wall
- eager nested `sem_root` recompute was removed or explicitly proven to be blocked by a verified invariant
- `model.clone()` cost was classified and either reduced safely or published as a blocker
- final benchmark artifacts match the final code revision
- any remaining material ambiguity was recorded as an assumption, blocker, or open decision rather than hidden inside the implementation
