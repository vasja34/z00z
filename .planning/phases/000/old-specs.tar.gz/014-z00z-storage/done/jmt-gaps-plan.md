# JMT Storage Gaps Plan

<!-- markdownlint-disable MD024 -->

> [!Important]
> This plan rewrites the reviewed workflow into implementation-ready execution units for the current repository state.
> It is based on the existing codebase in `z00z_storage`, `z00z_wallets`, `z00z_simulator`, and `z00z_core`.
> It does not authorize implementation inside this document.

## 🎯 Scope And Execution Target

**🎯 This plan must close the remaining first-party storage gaps without reopening the accepted hierarchy contract `definition_id -> serial_id -> asset_id`.**

**📌 The plan assumes the following baseline contracts are already fixed and must be reused, not redesigned:** `AssetPath`, `AssetStateRoot`, `CheckRoot`, `ProofItem`, `ProofBlob`, `chk_item(...)`, `chk_blob(...)`, `StoreItem`, `SnapItem`, `AssetStore`, `AssetState`, `MemberIdx`, and `TxPkgSum`.

**📌 The implementation target is a repository state where wallet and simulator code stop flattening path semantics, stop treating witness data as opaque bytes, and stop reconstructing `prev_root` through compatibility-only code paths.**

## 👁️‍🗨️ Verified Codebase Baseline

**👁️‍🗨️ The following files were verified and must anchor the implementation plan:**

- `crates/z00z_storage/src/assets/types.rs`
- `crates/z00z_storage/src/assets/store.rs`
- `crates/z00z_storage/src/assets/proof.rs`
- `crates/z00z_storage/src/assets/keys.rs`
- `crates/z00z_wallets/src/core/tx/state_update.rs`
- `crates/z00z_simulator/src/scenario_1/stage_4.rs`
- `crates/z00z_simulator/src/scenario_1/stage_6.rs`
- `crates/z00z_storage/tests/assets/store_api.rs`
- `crates/z00z_wallets/tests/test_tx_spent_gate.rs`
- `crates/z00z_wallets/tests/test_tx_wrong_root.rs`
- `crates/z00z_wallets/tests/test_phase24_gate.rs`
- `crates/z00z_simulator/tests/test_stage4_digest.rs`
- `crates/z00z_simulator/tests/test_stage4_gates.rs`
- `crates/z00z_simulator/tests/test_stage6_checkpoint.rs`
- `crates/z00z_simulator/tests/test_pipeline_genesis_tx.rs`
- `crates/z00z_simulator/tests/test_scenario1_unified_gate.rs`

```mermaid
flowchart TD
  P1[Phase 1<br/>Lock scope] --> P2[Phase 2<br/>Storage leaf surface]
  P2 --> P3[Phase 3<br/>Wallet path retention]
  P3 --> P4[Phase 4<br/>ProofBlob boundary]
  P4 --> P5[Phase 5<br/>Simulator root adoption]
  P5 --> P6[Phase 6<br/>Optional hardening]
  P6 --> P7[Phase 7<br/>Final validation]
```

## ❓ Open Decisions And Freeze Rules

**❓ The following items remain materially open and must be handled explicitly instead of being half-implemented across phases:**

1. whether `z00z_storage` becomes the final canonical owner of `AssetLeaf` or exposes a storage-owned compatibility surface
2. whether `MemberWit` stays as a typed wrapper over canonical bytes or is replaced by a storage-owned proof type
3. whether `DefinitionKey` and `SerialKey` wrappers are still worth introducing after the functional migration lands
4. whether backend abstraction remains in scope after the functional phases are complete

**📌 The current wallet hook surface in `crates/z00z_wallets/src/core/tx/state_update.rs` only exposes `CheckRoot`, terminal `asset_id`, `serial_id`, `AssetLeaf`, and opaque witness bytes. It does not yet expose the full proof-validation inputs required by `chk_blob(...)`: `AssetStateRoot`, `AssetPath`, `DefinitionRootLeaf`, and `SerialRootLeaf`. The plan must therefore treat wallet proof-boundary work as an API-shape change, not as a pure fixture rewrite.**

**📌 The current compatibility root surface in `crates/z00z_storage/src/assets/types.rs` is `CompatRoot<Vec<RootRec>>`, and `RootRec` carries only `asset_id`, `serial_id`, and `leaf`. It does not encode `definition_id`. Any Stage 4 legacy-root comparison must therefore be scoped to the currently accepted Stage 4 row shape and must not be presented as a general proof that the compatibility root preserves full hierarchy semantics.**

**📌 The verified public `AssetStore` surface exposes `get_item(&AssetPath)` and `proof_item(&AssetPath)`, but this review did not verify a public `asset_id -> AssetPath` lookup on the accepted storage API surface. The current `path_by_id` tracking is internal to storage planning code. Any wallet migration step that requires path recovery from terminal `asset_id` must therefore introduce one explicit proposed resolver boundary instead of assuming that a public lookup already exists.**

**📌 The existing `ProofItem` type in `crates/z00z_storage/src/assets/types.rs` already binds exactly the proof-validation fields the wallet needs for `chk_blob(...)`: `AssetStateRoot`, `AssetPath`, `DefinitionRootLeaf`, `SerialRootLeaf`, and `AssetLeaf`. Any new wallet-side proof context record must therefore be treated as a fallback only when direct reuse of `ProofItem` is demonstrably impossible.**

> [!Warning]
> These decisions must not block Phases 3, 4, or 5. If one decision is still unresolved after the corresponding functional phase is complete, freeze it explicitly into Phase 6 or into a deferred follow-up note.

```mermaid
sequenceDiagram
    participant Store as z00z_storage
    participant Wallet as state_update.rs
    participant Sim4 as stage_4.rs
    participant Sim6 as stage_6.rs

    Store->>Wallet: Path-bound leaf state plus canonical witness bytes
    Wallet->>Wallet: Resolve full AssetPath and validate ProofBlob
    Wallet->>Sim4: Consume storage-produced root semantics
    Sim4->>Sim6: Persist root-bound witness material
    Sim6->>Sim6: Enforce get_wit(prev_root, asset_id)
```

## ⚙️ Phase 1. Lock Remaining Scope And Acceptance Targets

### 1.1 Build The Gap Ledger

This unit must translate the reviewed workflow into one deterministic execution ledger so every remaining gap maps to one owner phase and one acceptance gate. The source of truth is `specs/014-z00z-storage/jmt-gaps-workflow.md`, and the ledger must not reopen the already accepted hierarchy, root typing, or proof container contracts.

Verified source note:

- the reviewed workflow was read in full for this phase
- the remaining-gap source currently present in the repository is `specs/014-z00z-storage/tmp/jmt-storage-gaps.md`
- any later attempt to reopen baseline contracts must stop this plan and move to a new spec instead of widening this execution slice

Target files:

- `specs/014-z00z-storage/jmt-gaps-workflow.md`
- `specs/014-z00z-storage/jmt-gaps-plan.md`

#### 📌 Inputs, Outputs, And Side Effects

- Inputs: the reviewed workflow file, the verified baseline contracts already named in this plan, and the current repository phase ordering.
- Outputs: one deterministic execution ledger in `jmt-gaps-plan.md` that maps each remaining gap to exactly one implementation phase and one validation gate.
- Side effects: later phases lose permission to reinterpret closed contracts or move work between phases without updating this ledger first.

#### 🔑 Invariants, Dependencies, And Ordering

- This unit must run before any implementation phase that changes storage, wallet, or simulator code.
- It must preserve the accepted `AssetPath`, `AssetStateRoot`, `CheckRoot`, `ProofItem`, and `ProofBlob` meanings as non-negotiable baseline contracts.
- It must not silently move optional hardening work into functional migration phases, because that would distort execution order and acceptance scope.

#### 🚨 Failure Modes And Review Questions

- Failure mode: one remaining gap appears in more than one phase, which creates ambiguous ownership and duplicated execution.
- Failure mode: a later phase redefines a closed contract because this ledger left room for interpretation.
- Reviewer questions: which exact gaps remain open, where each one is implemented, and which phase owns its validation gate.

Acceptance conditions:

- every remaining gap is mapped to exactly one phase below
- every phase below has at least one executable validation gate
- no phase mixes required functional work with optional hardening

**✔️ Implementation Checklist:**

- [x] Read `specs/014-z00z-storage/jmt-gaps-workflow.md` in full before starting code work.
- [x] Record the functional gap buckets as: storage leaf surface, wallet path retention, canonical witness boundary, simulator root adoption, and optional hardening.
- [x] Mark `AssetPath`, `AssetStateRoot`, `CheckRoot`, `ProofItem`, and `ProofBlob` as closed baseline contracts that must not be redesigned during implementation.
- [x] Freeze the acceptance target for the migration as: no byte-only first-party witness boundary, no path erasure before checkpoint apply, and no simulator `CompatRoot` dependency in the accepted path.
- [x] If a later code change requires reopening one of those baseline contracts, stop the execution plan and create a new spec instead of widening this plan.

### 1.2 Freeze Test Gates And Stop Rules

This unit must lock the command-level validation gates before code changes begin, so later phases cannot weaken acceptance by silently skipping feature flags or substituting helper files for executable tests.

Target files:

- `specs/014-z00z-storage/jmt-gaps-plan.md`

Frozen validation matrix:

```bash
cargo test -p z00z_storage --lib
cargo test -p z00z_wallets --lib
cargo test -p z00z_storage --test assets_suite
cargo test -p z00z_wallets --test test_tx_spent_gate
cargo test -p z00z_wallets --test test_tx_wrong_root
cargo test -p z00z_wallets --test test_phase24_gate
cargo test -p z00z_simulator --lib --release --features test-fast --features wallet_debug_dump
cargo test -p z00z_simulator --test test_stage4_digest --release --features test-fast --features wallet_debug_dump
cargo test -p z00z_simulator --test test_stage4_gates --release --features test-fast --features wallet_debug_dump
cargo test -p z00z_simulator --test test_stage6_checkpoint --release --features test-fast --features wallet_debug_dump
cargo test -p z00z_simulator --test test_pipeline_genesis_tx --release --features test-fast --features wallet_debug_dump
cargo test -p z00z_simulator --test test_scenario1_unified_gate --release --features test-fast --features wallet_debug_dump
```

Frozen stop rules:

- any regression back to flat `asset_id` identity before checkpoint apply invalidates the migration
- any first-party byte-only witness boundary invalidates the migration
- any accepted-path dependency on `CompatRoot`-driven root semantics invalidates the migration

Validation note at phase-freeze time:

- the frozen targets were verified as real cargo targets
- the wallet gate is intentionally limited to the verified path and witness tests for this migration slice instead of the unrelated full wallet integration suite
- the corrected wallet gate was rerun and is green for `test_tx_spent_gate`, `test_tx_wrong_root`, and `test_phase24_gate`
- the corrected simulator unit gate is `cargo test -p z00z_simulator --lib --release --features test-fast --features wallet_debug_dump`, because the Stage 4 unit path requires release-mode crypto for range-proof generation
- this avoids pulling in baseline-red release-path tests that are outside the current storage-gap review scope

#### 📌 Inputs, Outputs, And Side Effects

- Inputs: the verified storage, wallet, and simulator test targets already present in the repository.
- Outputs: one immutable command-level validation matrix for the full migration.
- Side effects: later implementation units must reuse these exact gates instead of inventing narrower or weaker substitutes.

#### 🔑 Invariants, Dependencies, And Ordering

- This unit depends on the scope ledger in `1.1` because gates must match owned phases.
- It must complete before any code unit relies on green local tests as proof of acceptance.
- Feature flags for simulator gates must stay explicit so release-sensitive behavior is exercised under the accepted runtime shape.

#### 🚨 Failure Modes And Review Questions

- Failure mode: a phase omits one crate-level gate and later ships with untested cross-crate regressions.
- Failure mode: simulator acceptance is claimed from debug-only or feature-mismatched tests.
- Reviewer questions: which exact commands gate acceptance, why these commands are sufficient, and what regression class each one catches.

Acceptance conditions:

- every phase gate names an executable crate or test target
- simulator gates include the required `test-fast` and `wallet_debug_dump` features
- stop rules are explicit for root mixing, proof format drift, and path flattening regressions

**✔️ Implementation Checklist:**

- [x] Freeze `cargo test -p z00z_storage --lib` as the minimum storage compilation gate.
- [x] Freeze `cargo test -p z00z_wallets --lib` as the wallet unit-test gate for `state_update.rs` contract changes.
- [x] Freeze `cargo test -p z00z_storage --test assets_suite` as the storage semantic gate.
- [x] Freeze `cargo test -p z00z_wallets --test test_tx_spent_gate`, `cargo test -p z00z_wallets --test test_tx_wrong_root`, and `cargo test -p z00z_wallets --test test_phase24_gate` as the wallet path and witness gate.
- [x] Freeze `cargo test -p z00z_simulator --lib --release --features test-fast --features wallet_debug_dump` as the simulator unit-test gate for `PrepIdx`, proof decode, and root-binding behavior.
- [x] Freeze the simulator gates with `--release --features test-fast --features wallet_debug_dump` for `test_stage4_digest`, `test_stage4_gates`, `test_stage6_checkpoint`, `test_pipeline_genesis_tx`, and `test_scenario1_unified_gate`.
- [x] Record a stop rule that any regression back to flat `asset_id` identity, opaque witness acceptance, or `CompatRoot`-driven root semantics invalidates the migration.

## ⚙️ Phase 2. Introduce One Storage-Owned Leaf Surface

### 2.1 Define The Storage Leaf Surface

This unit must define one storage-owned terminal leaf surface inside `z00z_storage` that later phases can depend on without forcing an immediate crate-wide ownership migration. The shape must preserve the existing wire payload and canonical terminal identity `asset_id`.

Target files:

- `crates/z00z_storage/src/assets/types.rs`
- `crates/z00z_storage/src/assets/model.rs`
- `crates/z00z_storage/src/assets/mod.rs`
- proposed `crates/z00z_storage/src/assets/leaf.rs`
- `crates/z00z_core/src/assets/leaf.rs`

Canonical shape:

- use one storage-facing leaf type or storage-owned wrapper only
- preserve `asset_id` as terminal identity
- preserve the existing serialized leaf payload unless a separate migration spec exists

#### 📌 Inputs, Outputs, And Side Effects

- Inputs: the current `z00z_core::assets::AssetLeaf` contract, storage hashing code, storage proof code, and public storage exports.
- Outputs: one storage-owned leaf surface that later storage, wallet, and simulator phases can reference without importing a second authoritative leaf contract.
- Side effects: imports in storage-facing modules move toward `z00z_storage` ownership, but public wire payload and committed leaf bytes stay stable.

#### 🔑 Invariants, Dependencies, And Ordering

- This unit must finish before wallet path retention and proof-boundary work, because those later units depend on stable storage-owned leaf semantics.
- It must preserve the committed hash shape and the terminal `asset_id` identity contract.
- It must prefer extension or compatibility wrapping over duplicating a second leaf type with slightly different semantics.

#### 🚨 Failure Modes And Review Questions

- Failure mode: two first-party leaf definitions both become write-authoritative.
- Failure mode: field or encoding drift changes committed leaf hashes without an explicit migration spec.
- Reviewer questions: which type becomes authoritative, where the compatibility surface lives, and how hash stability is preserved.

Acceptance conditions:

- storage-facing modules compile against one storage-owned leaf surface
- no duplicate leaf semantics exist in parallel modules
- later phases can reference storage-owned leaf semantics without importing a second leaf contract

**✔️ Implementation Checklist:**

- [x] Verify whether `z00z_storage` can own the canonical leaf type directly without breaking public crate boundaries.
- [ ] If direct ownership is safe, define the storage-owned leaf type in `crates/z00z_storage/src/assets/leaf.rs` and export it through `crates/z00z_storage/src/assets/mod.rs`.
- [x] If direct ownership is not yet safe, define one storage-owned compatibility wrapper in `z00z_storage` and document `z00z_core::assets::AssetLeaf` as compatibility-only.
- [x] Keep field meanings unchanged for `asset_id`, `serial_id`, and any committed leaf payload bytes.
- [x] Reject any implementation that creates two write-authoritative leaf definitions at the same time.

### 2.2 Redirect Storage Internals

This unit must redirect storage internals to the storage-owned leaf surface while reusing the existing proof, key, and store logic. The goal is to remove storage-internal dependence on a foreign leaf contract before wallet and simulator migration work begins.

Target files:

- `crates/z00z_storage/src/assets/store.rs`
- `crates/z00z_storage/src/assets/proof.rs`
- `crates/z00z_storage/src/assets/types.rs`

#### 📌 Inputs, Outputs, And Side Effects

- Inputs: the storage-owned leaf surface chosen in `2.1`, plus current `asset_hash(...)`, key derivation helpers, and proof/store code paths.
- Outputs: storage internals that compile and run only against the chosen storage-owned leaf surface.
- Side effects: import graphs inside storage change, but key derivation, proof bytes, and root semantics must not change.

#### 🔑 Invariants, Dependencies, And Ordering

- This unit depends directly on `2.1` and must complete before any wallet or simulator unit assumes storage owns its leaf semantics.
- It must preserve `asset_key(...)`, `def_key(...)`, and `ser_key(...)` behavior exactly.
- It must not widen public storage APIs unless a later unit explicitly needs that widening and documents it.

#### 🚨 Failure Modes And Review Questions

- Failure mode: imports are redirected, but one helper still hashes or serializes the old leaf shape.
- Failure mode: storage modules compile while proof bytes or roots drift semantically.
- Reviewer questions: which imports changed, which code paths remain byte-stable, and which tests prove no semantic regression occurred.

Acceptance conditions:

- storage modules import only the chosen storage-owned leaf surface internally
- proof hashing and store write flow still produce the same semantic results
- no terminal key or root semantics change during the redirect

**✔️ Implementation Checklist:**

- [x] Replace storage-internal imports of `z00z_core::assets::AssetLeaf` with the storage-owned surface in `store.rs`, `proof.rs`, and related `types.rs` helpers.
- [x] Keep `asset_hash(...)`, proof payload generation, and JMT write flow behavior unchanged during the redirect.
- [x] Reuse the existing `asset_key(...)`, `def_key(...)`, and `ser_key(...)` derivation flow without introducing a new key path.
- [x] If a compatibility re-export is required, keep it in one place only and do not duplicate encode or hash logic.
- [x] Run the storage gates before starting Phase 3 work.

Validation note:

- direct storage ownership was verified as not yet safe for this slice because `z00z_core::assets::AssetLeaf` still anchors current public crate boundaries
- `z00z_storage` now exposes one storage-owned compatibility surface in `src/assets/leaf.rs` and storage internals compile against that surface
- committed payload stability was checked with the storage codec-parity unit test and preserved storage gate results
- Phase 2 storage gates are green: `cargo test -p z00z_storage --lib` and `cargo test -p z00z_storage --test assets_suite`
- Phase 2 review revalidated the storage-facing examples with `cargo test -p z00z_storage --doc` and the benchmark fixture with `cargo check -p z00z_storage --benches`

## 🎯 Wallet API Boundary Slice

**🎯 This embedded execution slice isolates only the wallet-side semantic boundary work from `Phase 3` and `Phase 4`. It must be executable without waiting for simulator migration or optional hardening work.**

### Slice Scope

The slice includes only these implementation units:

- `Phase 3.1` `Make Resolved Input Path-Bound`
- `Phase 3.2` `Complete Path-Bound Resolution Flow`
- `Phase 3.3` `Rewrite Wallet Gates Around Path Retention`
- `Phase 4.1` `Replace Opaque Witness Acceptance`
- `Phase 4.2` `Align Storage And Wallet Fixtures`

The slice must not expand into these out-of-scope items:

- storage leaf ownership cut-over from `Phase 2`
- simulator Stage 4 and Stage 6 migration from `Phase 5`
- key-wrapper or backend-abstraction decisions from `Phase 6`
- broad tx module re-exports outside `crates/z00z_wallets/src/core/tx/mod.rs` unless the changed wallet boundary must become public

### Slice Preconditions

This slice may start only when all of the following are true:

- the accepted storage proof contracts remain `AssetPath`, `ProofItem`, `ProofBlob`, and `chk_blob(...)`
- no implementation step assumes a verified public `asset_id -> AssetPath` lookup on `AssetStore`
- wallet work is allowed to introduce one explicit proposed resolver boundary if path recovery cannot be expressed through current public APIs

> [!Important]
> The wallet slice must prefer direct reuse of `z00z_storage::assets::ProofItem` for proof context. A wallet-local proof record is allowed only as a documented fallback when direct `ProofItem` reuse is not viable.

### Slice Execution Order

The slice must run in this order and must not skip ahead:

1. stabilize one dedicated pre-state resolver contract for path-bound input loading in `state_update.rs`
2. make `ResolvedInput` and `TxPkgSum` path-aware enough that no later step reconstructs `definition_id`
3. convert witness ingestion from non-empty-bytes acceptance to canonical `chk_blob(...)` validation
4. rewrite wallet unit tests in `state_update.rs` before relying on crate-level integration tests
5. replace placeholder proof fixtures in wallet tests with canonical proof blobs

> [!Important]
> The preferred accepted wallet boundary is one dedicated pre-state resolver trait colocated with `prepare_tx_sum(...)` in `crates/z00z_wallets/src/core/tx/state_update.rs`. The current `AssetState` trait is shared with checkpoint apply and mutable state replay, while the current `MemberIdx` trait is witness-only and returns bytes keyed by `(prev_root, asset_id)`. The slice must therefore prefer a resolver boundary over overloading either existing trait unless code-level constraints prove that a new trait is impossible.

### Slice Exit Gate

The slice is complete only when all of the following pass on one revision:

```bash
cargo test -p z00z_wallets --lib
cargo test -p z00z_wallets --tests
cargo test -p z00z_storage --test assets_suite
```

The slice must also satisfy these semantic exit conditions:

- `prepare_tx_sum(...)` no longer succeeds on flat terminal-id-only resolved input semantics
- malformed, root-mixed, and path-mixed witness bytes reject through the canonical wallet validation path
- wallet tests no longer depend on opaque placeholder witness bytes such as `vec![1u8]`
- no slice step introduces a second first-party proof format beside `ProofBlob`

## ⚙️ Phase 3. Preserve Full AssetPath Across Wallet Checkpoint Preparation

### 3.1 Make Resolved Input Path-Bound

This unit must make the wallet resolved-input contract path-bound so `definition_id`, `serial_id`, and `asset_id` remain available until verification and checkpoint apply are complete. The current `ResolvedInput` shape in `state_update.rs` is not sufficient because it flattens identity to terminal `asset_id` plus `serial_id`.

Target files:

- `crates/z00z_wallets/src/core/tx/state_update.rs`
- `crates/z00z_wallets/src/core/tx/state_update.rs` unit tests

Canonical shape:

- `ResolvedInput` must carry `AssetPath`
- resolved input data must keep `leaf` and `member_wit` in the same record as the path
- `TxPkgSum` must retain access to path-bound resolved inputs or an equivalent storage-owned record
- the preferred reuse target is an existing storage-facing record shape such as `StoreItem` or `SnapItem`, extended only if the current signatures are insufficient

#### 📌 Inputs, Outputs, State Transitions, And Side Effects

- Inputs: compact tx input references, current wallet state resolution hooks, and storage-facing path semantics.
- Outputs: one path-bound `ResolvedInput` contract and one `TxPkgSum` shape that preserve full `AssetPath` until verification is complete.
- State transition: wallet preparation moves from terminal-id resolution to path-bound resolution before any checkpoint apply step is allowed to proceed.
- Side effects: wallet fixtures and any helper that assumed `asset_id` alone was enough must be rewritten.

#### 🔑 Invariants, Dependencies, And Ordering

- This unit depends on stable storage-owned leaf semantics from Phase 2.
- It must complete before canonical witness validation in `4.1`, because `chk_blob(...)` needs full path-bound proof context.
- It must keep terminal `asset_id` as the terminal key while rejecting it as the full semantic identity boundary.

#### 🚨 Failure Modes And Review Questions

- Failure mode: `ResolvedInput` stores `AssetPath`, but later code still reconstructs `definition_id` from unrelated state.
- Failure mode: `TxPkgSum` keeps only flat ids and silently drops path semantics after resolution.
- Reviewer questions: which types changed, where `AssetPath` is preserved, and which tests prove no later code path guesses missing coordinates.

Acceptance conditions:

- no internal checkpoint preparation step must guess missing `definition_id`
- resolved inputs remain fully path-bound until witness verification completes
- terminal `asset_id` remains the terminal key, not the full semantic identity boundary

**✔️ Implementation Checklist:**

- [x] Redesign `ResolvedInput` in `crates/z00z_wallets/src/core/tx/state_update.rs` to carry `AssetPath` rather than only `asset_id` and `serial_id`.
- [x] Keep `leaf` and `member_wit` stored in the same resolved-input record as the path.
- [x] Decide whether `ResolvedInput` should directly reuse `z00z_storage::assets::StoreItem` or `SnapItem` semantics instead of inventing a second path-carrying record with overlapping fields.
- [x] Decide whether `TxPkgSum` keeps a vector of path-bound resolved inputs or stores a parallel path-bound field set with equivalent semantics.
- [x] Widen the wallet-side state resolution contract so full path data is available before `prepare_tx_sum(...)` returns; do not rely on reconstructing `definition_id` from terminal `asset_id` later.
- [x] Treat `asset_id -> AssetPath` recovery as a proposed boundary unless a verified public storage API is introduced for it; do not rely on internal storage planner helpers such as `path_by_id` or `path_opt(...)`.
- [x] Treat any remaining `AssetState` lookup by terminal `asset_id` only as a load helper, not as the final verifier identity boundary.
- [x] Reject designs where `definition_id` is reconstructed later from unrelated state or simulator context.
- [x] Update the unit tests in `crates/z00z_wallets/src/core/tx/state_update.rs` so the path-bound contract is exercised before only integration tests are considered sufficient.

### 3.2 Complete Path-Bound Resolution Flow

This unit must make `prepare_tx_sum(...)` the final boundary where full input resolution becomes complete. The function must validate path consistency, state lookup consistency, and witness presence before a `TxPkgSum` is returned. The preferred accepted shape is a dedicated resolver boundary colocated with `state_update.rs`, because the current `AssetState` and `MemberIdx` traits serve narrower roles in both wallet tests and simulator wiring.

Target files:

- `crates/z00z_wallets/src/core/tx/state_update.rs`
- `crates/z00z_wallets/src/core/tx/state_update.rs` unit tests

Canonical verifier flow:

1. parse compact input reference
2. resolve the state leaf and its canonical path-bearing storage record
3. bind the resolved state to full `AssetPath`
4. require the witness for the same path-bound record under `prev_root`
5. emit one path-bound summary contract for later apply

#### 📌 Inputs, Outputs, State Transitions, And Side Effects

- Inputs: `prev_root`, compact input references, wallet-visible state records, and member witness bytes or wrapper values.
- Outputs: one `TxPkgSum` assembled only from fully resolved path-bound input records.
- State transition: unresolved compact inputs become verified, path-bound, proof-context-bound records before apply-time code runs.
- Side effects: `AssetState`, `MemberIdx`, or a new resolver trait boundary may require signature changes and test fixture rewrites.

#### 🔑 Invariants, Dependencies, And Ordering

- This unit depends on `3.1` because the resolver cannot complete until `ResolvedInput` is path-bound.
- It must complete before `4.1`, because witness validation must attach to the final resolved-input flow rather than an earlier flat helper.
- It must preserve fast rejection order so malformed reference, duplicate input, state mismatch, and witness failures remain distinguishable.

#### 🚨 Failure Modes And Review Questions

- Failure mode: `prepare_tx_sum(...)` returns success while some input is still only terminal-id-resolved.
- Failure mode: witness failure is deferred to apply-time code and loses its pre-state rejection semantics.
- Reviewer questions: where path-bound resolution ends, which trait boundary owns it, and how reject ordering is preserved.

Acceptance conditions:

- `prepare_tx_sum(...)` returns success only after path-bound resolution completes
- `serial_id` mismatch still rejects early
- witness decode or semantic proof failure still rejects through the pre-apply member-witness path rather than being deferred to apply-time shape checks
- no post-resolution code depends on back-filling missing path data

**✔️ Implementation Checklist:**

- [x] Update `resolve_inputs(...)` so it returns path-bound records rather than flat terminal-id records.
- [x] Prefer introducing one dedicated pre-state resolver trait in `crates/z00z_wallets/src/core/tx/state_update.rs` that returns one path-bound, proof-context-bound record for `prepare_tx_sum(...)`.
- [x] Only if a dedicated resolver trait is demonstrably impossible, widen `AssetState` or `MemberIdx`; if that fallback is taken, label the widened boundary as a deliberate compatibility compromise in the implementation notes.
- [x] If that resolver boundary depends on storage lookups, base it on verified public `AssetStore` operations such as `get_item(&AssetPath)` and `proof_item(&AssetPath)` after path resolution is available, rather than assuming a public terminal-id lookup already exists.
- [x] Make `prepare_tx_sum(...)` assemble `TxPkgSum` only from those path-bound resolved records.
- [x] Preserve fast rejection order: malformed input reference, duplicate input, missing state, leaf mismatch, bad witness.
- [x] Preserve reject classification so witness decode, empty witness bytes, and canonical proof mismatch still surface as `StateErr::BadMember` during pre-state resolution; keep `StateErr::BadResolve` reserved for impossible post-resolution shape inconsistencies in `apply_batch_checkpoint(...)`.
- [x] Ensure `member_idx.get_wit(...)` is no longer the only semantic source of identity for the resolved input, because the current signature `get_wit(prev_root, id)` does not carry `AssetPath` by itself.
- [x] Keep the current compact public input wire contract unless an existing verified file already requires a wider public wire shape.
- [x] Run `cargo test -p z00z_wallets --lib` after the resolver shape is stabilized so internal state-update tests fail before integration wiring hides the regression.

### 3.3 Rewrite Wallet Gates Around Path Retention

This unit must update wallet tests so they verify the new path-bound internal contract rather than the old flat resolved-input behavior.

Target files:

- `crates/z00z_wallets/tests/test_tx_spent_gate.rs`
- `crates/z00z_wallets/tests/test_tx_wrong_root.rs`
- `crates/z00z_wallets/tests/test_phase24_gate.rs`

#### 📌 Inputs, Outputs, And Side Effects

- Inputs: rewritten path-bound wallet contracts from `3.1` and `3.2`, plus existing wrong-root and spent-gate fixtures.
- Outputs: wallet integration tests that assert path-bound preparation and rejection semantics explicitly.
- Side effects: older flat fixtures become invalid and must be removed or rebuilt.

#### 🔑 Invariants, Dependencies, And Ordering

- This unit depends on the new resolver and `TxPkgSum` shape from `3.1` and `3.2`.
- It must finish before Phase 4 fixture alignment claims the wallet path is canonical.
- It must preserve current reject-class precision for spent, wrong-root, and malformed witness failures.

#### 🚨 Failure Modes And Review Questions

- Failure mode: tests still pass only because fixtures bypass the path-bound boundary.
- Failure mode: path-bound semantics land in code, but regression tests never assert that missing path data is fatal.
- Reviewer questions: which fixtures changed, which assertions were added, and how each wallet gate proves path retention is real.

Acceptance conditions:

- wallet tests reject incorrect root and spent conditions under the path-bound contract
- at least one wallet test proves that later checkpoint code does not reconstruct missing path data

**✔️ Implementation Checklist:**

- [x] Update wallet test fixtures to build path-bound resolved input expectations.
- [x] Add or adjust assertions that `prepare_tx_sum(...)` fails when path semantics cannot be fully resolved.
- [x] Keep rejection-class ordering stable so spent, wrong-root, and malformed-witness failures remain precise.
- [x] Re-run `cargo test -p z00z_wallets --tests` before moving to Phase 4.

Validation note:

- Phase 3 now retains `AssetPath` through `ResolvedInput` and `TxPkgSum`, introduces the dedicated `InputResolver` boundary, and adapts simulator Stage 6 to resolve one path-bound record per compact input without reconstructing `definition_id` later.
- Phase 3 wallet review added one explicit integration assertion that the wallet-side batch snapshot still carries retained `input_paths` metadata and one integration-level negative case proving `prepare_tx_sum(...)` rejects path-mixed resolution before checkpoint apply.
- The release validation gates that passed were `cargo test -p z00z_simulator --lib --release --features test-fast --features wallet_debug_dump`, `cargo test -p z00z_simulator --test test_stage6_checkpoint --release --features test-fast --features wallet_debug_dump`, `cargo test -p z00z_wallets --lib --release`, `cargo test -p z00z_wallets --test test_tx_spent_gate --release`, `cargo test -p z00z_wallets --test test_tx_wrong_root --release`, `cargo test -p z00z_wallets --test test_phase24_gate --release`, and `cargo test -p z00z_wallets --tests --release`.

## ⚙️ Phase 4. Make ProofBlob The Mandatory First-Party Witness Boundary

### 4.1 Replace Opaque Witness Acceptance

This unit must replace the current byte-only witness acceptance model with canonical `ProofBlob` validation at the first downstream boundary. The wallet must not accept arbitrary bytes as long as they are non-empty.

Target files:

- `crates/z00z_wallets/src/core/tx/state_update.rs`
- `crates/z00z_storage/src/assets/proof.rs`
- `crates/z00z_wallets/src/core/tx/state_update.rs` unit tests

Canonical shape:

- downstream witness ingestion must decode canonical proof bytes
- `chk_blob(...)` must remain the semantic and backend-proof validator
- any wallet-local witness type must be a thin typed wrapper over canonical storage bytes, not a new proof format
- the resolved wallet-side proof context must provide `AssetStateRoot`, `AssetPath`, `DefinitionRootLeaf`, `SerialRootLeaf`, and `AssetLeaf`, because `chk_blob(...)` cannot validate from `CheckRoot` plus terminal `asset_id` alone
- the preferred proof-context reuse target is the existing `ProofItem` type; do not introduce a second record with the same semantic fields unless a verified code-level constraint forces it

#### 📌 Inputs, Outputs, State Transitions, And Side Effects

- Inputs: path-bound resolved inputs, canonical proof bytes, `prev_root`, and storage proof-validation helpers.
- Outputs: a wallet boundary that accepts only canonical `ProofBlob`-compatible witness data and emits `StateErr::BadMember` on proof-boundary failures.
- State transition: witness handling moves from non-empty byte acceptance to semantic proof validation before checkpoint apply.
- Side effects: wallet resolver APIs, proof-context records, and wallet unit fixtures all change together.

#### 🔑 Invariants, Dependencies, And Ordering

- This unit depends on `3.1` and `3.2`, because canonical proof validation needs full path-bound proof context.
- It must complete before simulator root adoption relies on wallet canonical witness semantics.
- It must preserve `chk_blob(...)` as the only first-party semantic proof validator and must not add a second parser or validator.

#### 🚨 Failure Modes And Review Questions

- Failure mode: wallet still accepts arbitrary non-empty bytes because decode failure is not wired into the resolver boundary.
- Failure mode: a second wallet-local proof format appears to compensate for fixture or API friction.
- Reviewer questions: where witness bytes are decoded, which proof context record is reused, and how malformed, root-mixed, and path-mixed failures are classified.

Acceptance conditions:

- malformed or non-canonical proof bytes reject before checkpoint apply
- the wallet does not introduce a second proof validator
- proof verification still binds root, path, definition leaf, serial leaf, and terminal leaf consistently
- wallet pre-state proof failures keep the current reject taxonomy by surfacing as `StateErr::BadMember`; `StateErr::BadResolve` must not become the generic bucket for malformed, root-mixed, or path-mixed witness bytes

**✔️ Implementation Checklist:**

- [x] Decide whether `MemberWit` remains as a thin typed wrapper over canonical `ProofBlob` bytes or is replaced with a storage-owned witness type.
- [x] Reuse `z00z_storage::assets::ProofItem` as the wallet-side proof context if the wallet boundary can import it without creating a duplicate semantic record.
- [x] Only if direct `ProofItem` reuse is not viable, define one wallet-side proof context record as a proposed fallback and keep its field set identical to `ProofItem`.
- [x] Make the dedicated resolver path, or `resolve_inputs(...)` if it remains the entry point, decode and validate witness bytes before returning success.
- [x] Reuse `chk_blob(...)` from `crates/z00z_storage/src/assets/proof.rs` as the only semantic validator for first-party witness acceptance.
- [x] If `CheckRoot` remains the externally declared tx root, add one explicit conversion rule at the wallet boundary for deriving `AssetStateRoot::new(prev_root.into_bytes())` rather than letting multiple ad hoc conversions appear.
- [x] Reject any design that keeps a wallet-local proof parser or alternate witness container.
- [x] Preserve deterministic rejection when bytes are empty, malformed, or semantically inconsistent.
- [x] Preserve deterministic error-class behavior so empty, malformed, root-mixed, and path-mixed proof bytes reject as `StateErr::BadMember` in `prepare_tx_sum(...)`, while `StateErr::BadResolve` stays limited to post-resolution structural mismatches.
- [x] Update the unit tests in `crates/z00z_wallets/src/core/tx/state_update.rs` so malformed, root-mixed, and path-mixed proof cases fail under the new canonical validator path.

### 4.2 Align Storage And Wallet Fixtures

This unit must align tests and fixture builders with canonical proof blobs so the migration is exercised by realistic witness payloads rather than placeholders like `vec![1u8]`.

Target files:

- `crates/z00z_storage/tests/assets/store_api.rs`
- `crates/z00z_wallets/tests/test_tx_spent_gate.rs`
- `crates/z00z_wallets/tests/test_tx_wrong_root.rs`
- `crates/z00z_wallets/tests/test_phase24_gate.rs`

#### 📌 Inputs, Outputs, And Side Effects

- Inputs: current placeholder fixtures, canonical `ProofBlob` builders, and existing storage proof helpers.
- Outputs: one consistent canonical fixture path for storage and wallet witness tests.
- Side effects: ad hoc byte literals and duplicated proof-byte assembly must be removed from wallet-facing tests.

#### 🔑 Invariants, Dependencies, And Ordering

- This unit depends on `4.1`, because fixture builders must match the accepted witness boundary.
- It must finish before final wallet and simulator gates are treated as authoritative acceptance.
- It must keep fixture generation centralized so later proof-format edits do not fork test behavior across files.

#### 🚨 Failure Modes And Review Questions

- Failure mode: one test still uses opaque bytes and passes even though canonical proof validation is broken.
- Failure mode: each test file reimplements its own proof-byte builder and drifts over time.
- Reviewer questions: where canonical fixtures are built, which placeholder values were removed, and which tests now prove realistic witness handling.

Acceptance conditions:

- storage and wallet tests use canonical proof bytes or a canonical proof fixture builder
- no accepted first-party test depends on opaque placeholder witness bytes

**✔️ Implementation Checklist:**

- [x] Identify the current placeholder witness fixtures in storage and wallet tests.
- [x] Replace them with canonical `ProofBlob` bytes produced from existing store or proof helpers.
- [x] Keep fixture generation centralized instead of duplicating ad hoc proof byte assembly in multiple tests.
- [x] Re-run `cargo test -p z00z_storage --test assets_suite` and `cargo test -p z00z_wallets --tests` after the fixture rewrite.

Validation note:

- Phase 4 now makes `MemberWit` a thin typed wallet wrapper over canonical storage proof bytes plus `ProofItem`, and `resolve_inputs(...)` validates the first downstream witness boundary through `chk_blob(...)` with one explicit `CheckRoot -> AssetStateRoot` conversion helper.
- Wallet unit tests now cover malformed, root-mixed, and path-mixed witness rejection as `StateErr::BadMember`, while wallet integration tests use the shared `tests/proof_blob_fix.rs` builder instead of opaque `vec![1u8]` fixtures.
- The passing validation gates were `cargo test -p z00z_storage --test assets_suite`, `cargo test -p z00z_wallets --lib --release --features test-fast --features wallet_debug_dump`, `cargo test -p z00z_wallets --tests --release --features test-fast --features wallet_debug_dump`, and `cargo test -p z00z_simulator --lib --release --features test-fast --features wallet_debug_dump`.

## ⚙️ Phase 5. Remove Compatibility-Root Reconstruction From Simulator Paths

### 5.1 Verify Stage 4 Root Transition Before Deletion

This unit must prove, in executable simulator coverage, what the accepted Stage 4 rows actually do before compatibility-root wiring is removed. In the current repository state, that verification must distinguish the storage-produced root from the legacy compatibility-root path instead of assuming parity.

Target files:

- `crates/z00z_simulator/src/scenario_1/stage_4.rs`
- `crates/z00z_simulator/tests/test_stage4_digest.rs`

#### 📌 Inputs, Outputs, And Side Effects

- Inputs: accepted Stage 4 row fixtures, storage-produced root calculation, and current compatibility-root calculation.
- Outputs: one executable Stage 4 root test that proves the prep artifact persists the storage-produced root for the currently accepted row shape and no longer follows the legacy compatibility-root path.
- Side effects: future Stage 4 deletion work becomes blocked on this test instead of relying on comments, debug assertions, or stale assumptions about compatibility-root parity.

#### 🔑 Invariants, Dependencies, And Ordering

- This unit must complete before `5.2` deletes compatibility-root usage.
- It must preserve the current `PrepRow.definition_id_hex` namespace source.
- It must explicitly scope its claim to the current Stage 4 row shape because `CompatRoot` does not encode full hierarchy semantics and uses a legacy flattened root path.

#### 🚨 Failure Modes And Review Questions

- Failure mode: Stage 4 compatibility wiring is deleted without an executable root-transition proof.
- Failure mode: the test overclaims legacy compatibility behavior as proof of general hierarchy equivalence.
- Reviewer questions: which rows are compared, which roots are computed, and whether the accepted Stage 4 path now follows storage-root semantics only.

Acceptance conditions:

- an executable simulator test proves that Stage 4 persists the storage-produced root for the current accepted row shape
- the same executable test proves the accepted Stage 4 path no longer follows the legacy compatibility-root result for those rows
- the test labels its claim as scoped to the current accepted Stage 4 row shape, because `CompatRoot` does not encode `definition_id`

**✔️ Implementation Checklist:**

- [x] Extend `crates/z00z_simulator/tests/test_stage4_digest.rs` to compute both the storage-produced root path and the current compatibility-root path for the same Stage 4 rows.
- [x] Assert, before deleting the compatibility-root path from accepted flow, that Stage 4 prep persists the storage-produced root and no longer follows the legacy compatibility-root result.
- [x] Keep the existing `PrepRow.definition_id_hex` field as the Stage 4 namespace source and do not introduce a second namespace field.
- [x] State in the test and this plan note that the gate is scoped to the accepted Stage 4 row shape only, not a general proof that `CompatRoot` preserves the full hierarchy contract.
- [x] Do not begin Stage 4 compatibility-path deletion until the executable Stage 4 root-transition test is green under the required simulator feature flags.

### 5.2 Replace CompatRoot In Stage 4

This unit must switch Stage 4 witness preparation to consume storage-produced roots directly and stop relying on `CompatRoot::new(rows)?.check_root()` inside the accepted path.

Target files:

- `crates/z00z_simulator/src/scenario_1/stage_4.rs`

Canonical write flow:

1. build storage state from Stage 4 rows
2. obtain the storage-produced root
3. emit canonical witness blobs without semantic rebinding
4. persist the root together with the prep rows

#### 📌 Inputs, Outputs, State Transitions, And Side Effects

- Inputs: Stage 4 rows, storage proof providers, and the executable Stage 4 root-transition verification from `5.1`.
- Outputs: Stage 4 prep artifacts that persist storage-produced root semantics directly.
- State transition: Stage 4 root sourcing moves from compatibility-root reconstruction to storage-owned root production.
- Side effects: any helper or artifact expecting `ProofBlob::rebind(...)` semantics must be rewritten or explicitly frozen out of accepted flow.

#### 🔑 Invariants, Dependencies, And Ordering

- This unit depends on a green Stage 4 root-transition verification from `5.1`.
- It must complete before Stage 6 root-bound witness lookup is validated against accepted Stage 4 artifacts.
- It must keep witness bytes canonical and storage-owned; no silent semantic rebinding is allowed.

#### 🚨 Failure Modes And Review Questions

- Failure mode: Stage 4 persists storage roots, but witness bytes are still compatibility-rebound.
- Failure mode: a temporary debug adapter silently remains in accepted flow and keeps old semantics alive.
- Reviewer questions: where `prev_root` is sourced now, whether `ProofBlob::rebind(...)` is gone from accepted flow, and how artifact compatibility is validated.

Acceptance conditions:

- Stage 4 persists storage-produced root semantics directly
- `ProofBlob::rebind(...)` is no longer used as a silent semantic rewrite in the accepted flow

**✔️ Implementation Checklist:**

- [x] Replace `CompatRoot::new(rows)?.check_root()` as the accepted `prev_root` source in `stage_4.rs`.
- [x] Source Stage 4 witness blobs from storage proof providers rather than compatibility-only reconstruction.
- [x] Remove `ProofBlob::rebind(...)` from the accepted Stage 4 path unless a documented compatibility adapter remains temporarily for non-accepted debug flow.
- [x] Keep the emitted witness bytes canonical and storage-owned.

### 5.3 Enforce Root-Bound Lookup In Stage 6

This unit must make Stage 6 witness lookup root-bound so `get_wit(prev_root, asset_id)` returns a witness only for the exact root and asset pair that was prepared earlier.

Target files:

- `crates/z00z_simulator/src/scenario_1/stage_6.rs`
- `crates/z00z_simulator/tests/test_stage6_checkpoint.rs`
- `crates/z00z_simulator/src/scenario_1/stage_6.rs` unit tests

#### 📌 Inputs, Outputs, State Transitions, And Side Effects

- Inputs: Stage 4-produced prep artifacts, `prev_root`, terminal `asset_id`, and current `PrepIdx` or equivalent witness index state.
- Outputs: Stage 6 lookup behavior that binds witness retrieval to the exact `(prev_root, asset_id)` pair.
- State transition: Stage 6 moves from root-agnostic witness reuse to root-bound witness retrieval before checkpoint application.
- Side effects: simulator unit fixtures for `PrepIdx` and checkpoint preparation must be updated to exercise root mismatches explicitly.

#### 🔑 Invariants, Dependencies, And Ordering

- This unit depends on Stage 4 producing storage-owned root semantics in `5.2`.
- It must complete before the end-to-end simulator gates in `5.4` are rerun.
- It must preserve the existing public lookup signature if that signature is already accepted, fixing semantics before widening APIs.

#### 🚨 Failure Modes And Review Questions

- Failure mode: Stage 6 accepts a witness from the wrong root because the index key still ignores `prev_root` internally.
- Failure mode: a hidden root-agnostic cache becomes the real source of truth after validation.
- Reviewer questions: which data structure changed, how root mismatch is rejected, and which tests prove lookup is now root-bound.

Acceptance conditions:

- Stage 6 no longer accepts root-agnostic witness lookup
- a mismatched `prev_root` rejects the lookup even when `asset_id` matches

**✔️ Implementation Checklist:**

- [x] Redesign the Stage 6 witness index key so `prev_root` is part of the accepted lookup contract; the current simulator API already accepts `get_wit(prev_root, asset_id)`, so this phase must remove the current implementation bug that ignores `prev_root` rather than widening the public trait first.
- [x] Keep any root-agnostic cache strictly internal and only after root-bound validation succeeds.
- [x] Add or update a Stage 6 test that proves lookup rejection on root mismatch.
- [x] Keep the existing `PrepIdx::new(...)` negative-path unit tests green for root mix and path mix, and extend them if the new root-bound index shape changes fixture assumptions.
- [x] Re-run `test_stage6_checkpoint` with `--features test-fast --features wallet_debug_dump` before final simulator validation.
- [x] Run `cargo test -p z00z_simulator --lib` after the Stage 6 index change so the internal `PrepIdx` and proof-validation unit tests fail before acceptance tests are rerun.

### 5.4 Re-Run End-To-End Simulator Gates

This unit must validate that Stage 4 and Stage 6 changes hold under the full simulator acceptance surface.

Target files:

- `crates/z00z_simulator/tests/test_stage4_gates.rs`
- `crates/z00z_simulator/tests/test_pipeline_genesis_tx.rs`
- `crates/z00z_simulator/tests/test_scenario1_unified_gate.rs`

#### 📌 Inputs, Outputs, And Side Effects

- Inputs: one revision with `5.1`, `5.2`, and `5.3` already landed.
- Outputs: one green simulator acceptance surface under the required release-mode feature flags.
- Side effects: failures here force rollback into the last green simulator phase rather than piecemeal local fixes that bypass the acceptance sequence.

#### 🔑 Invariants, Dependencies, And Ordering

- This unit depends on all prior simulator migration units in Phase 5.
- It must run after unit-level simulator gates are already green so acceptance failures isolate integration drift rather than basic compile breakage.
- It must reuse the exact accepted release-mode flags and test targets named earlier in the plan.

#### 🚨 Failure Modes And Review Questions

- Failure mode: Stage 4 and Stage 6 each pass locally but disagree on the accepted root-bound witness contract when executed together.
- Failure mode: one acceptance test is skipped and the migration claims green status on an incomplete simulator surface.
- Reviewer questions: which tests were run, under which feature set, and what cross-stage behavior they validate together.

Acceptance conditions:

- all simulator acceptance tests pass on one consistent revision
- Stage 4 and Stage 6 semantics agree on the same root-bound witness contract

**✔️ Implementation Checklist:**

- [x] Run `cargo test -p z00z_simulator --test test_stage4_digest --release --features test-fast --features wallet_debug_dump`.
- [x] Run `cargo test -p z00z_simulator --test test_stage4_gates --release --features test-fast --features wallet_debug_dump`.
- [x] Run `cargo test -p z00z_simulator --test test_stage6_checkpoint --release --features test-fast --features wallet_debug_dump`.
- [x] Run `cargo test -p z00z_simulator --test test_pipeline_genesis_tx --release --features test-fast --features wallet_debug_dump`.
- [x] Run `cargo test -p z00z_simulator --test test_scenario1_unified_gate --release --features test-fast --features wallet_debug_dump`.

## ⚙️ Phase 6. Resolve Optional Type Hardening And Backend Scope

### 6.1 Decide Key Wrapper Scope

This unit must decide whether semantic wrappers like `DefinitionKey` and `SerialKey` still provide enough value after the functional migration lands. They must not be introduced merely because they were mentioned earlier.

Target files:

- `crates/z00z_storage/src/assets/keys.rs`
- `crates/z00z_storage/src/assets/types.rs`

#### 📌 Inputs, Outputs, And Side Effects

- Inputs: the existing helper-based key derivation surface and the completed functional migration from Phases 2 through 5.
- Outputs: either one explicit wrapper-type decision with concrete code changes or one explicit deferral note.
- Side effects: if wrappers are introduced, key-call sites and tests may need mechanical updates; if deferred, no functional code path should change.

#### 🔑 Invariants, Dependencies, And Ordering

- This unit must run only after the functional migration is stable, because wrappers are optional hardening rather than a prerequisite.
- It must preserve current root, path, and proof semantics whether wrappers are adopted or deferred.
- It must not invent wrapper types solely to satisfy stylistic symmetry.

#### 🚨 Failure Modes And Review Questions

- Failure mode: optional wrappers destabilize already-green storage semantics.
- Failure mode: wrappers are added without clear semantic value and create parallel key representations.
- Reviewer questions: why wrappers are needed now, what exact type boundary they improve, and what remains unchanged if they are deferred.

Acceptance conditions:

- wrapper types are either implemented with clear semantic value or explicitly deferred
- no functional phase remains blocked on wrapper-type work

**✔️ Implementation Checklist:**

- [x] Re-evaluate whether existing `def_key(...)`, `ser_key(...)`, and `asset_key(...)` helpers already provide sufficient semantic clarity.
- [ ] If wrapper types are justified, add them as thin semantic wrappers over existing derivation outputs without changing root or path semantics.
- [x] If wrapper types are not justified, record them as deferred and keep the helper-based key path unchanged.
- [x] Do not modify earlier proof or store behavior only to justify wrapper introduction.

Validation note:

- Phase 6.1 re-evaluation keeps the helper-based key path unchanged and explicitly defers wrapper types.
- `DefinitionId`, `SerialId`, and `AssetId` already provide the semantic boundary, while `def_key(...)`, `ser_key(...)`, and `asset_key(...)` remain one-source-of-truth derivation helpers with stable call sites across proof and store internals.
- No wrapper type was added because it would create a parallel representation without improving the accepted root, path, or proof contract for this milestone.

### 6.2 Decide Backend Abstraction Scope

This unit must decide whether backend abstraction is still part of the current migration milestone. Any trait boundary added here must come after semantic contracts are stable.

Target files:

- `crates/z00z_storage/src/assets/store.rs`
- `crates/z00z_storage/src/assets/store_internal/tree_store.rs`

#### 📌 Inputs, Outputs, And Side Effects

- Inputs: the current in-memory backend implementation and the now-stable semantic storage contracts.
- Outputs: either one explicit backend abstraction boundary with named target files or one explicit deferral decision.
- Side effects: if abstraction is introduced, internal storage wiring and tests may need trait-bound updates; if deferred, no functional migration behavior may be revisited under this unit.

#### 🔑 Invariants, Dependencies, And Ordering

- This unit must run after the functional phases are green, because backend abstraction is optional milestone scope.
- It must preserve semantic storage behavior and keep backend details behind internal storage boundaries.
- It must not widen public hierarchy-facing APIs only to accommodate an optional backend trait.

#### 🚨 Failure Modes And Review Questions

- Failure mode: backend abstraction is introduced early and destabilizes already-accepted root or proof semantics.
- Failure mode: the plan claims abstraction is in scope without naming the exact trait boundary and affected files.
- Reviewer questions: which boundary is extracted, why it belongs to this milestone, and what proof exists that hierarchy-facing semantics remain untouched.

Acceptance conditions:

- backend abstraction is either introduced with one explicit boundary or explicitly frozen out of scope
- no hierarchy-facing semantic code is destabilized by premature trait extraction

**✔️ Implementation Checklist:**

- [x] Confirm whether the in-memory backend remains the accepted milestone endpoint for the current migration.
- [ ] If backend abstraction is required now, define one explicit trait boundary between hierarchy logic and backend operations in storage internals.
- [ ] Label any new backend trait as proposed until it exists in code and passes storage tests.
- [x] If backend abstraction is not required now, freeze it as deferred and keep the current `MemTreeStore`-based milestone.

Validation note:

- Phase 6.2 keeps `MemTreeStore` as the accepted milestone backend and explicitly defers any broader backend abstraction.
- The current code already isolates backend mechanics behind the private `TreeStore` namespace multiplexer and internal `MemTreeStore` host, so introducing a new trait boundary here would be optional architecture work rather than a migration requirement.
- No hierarchy-facing semantic code changed under this phase.

## ⚙️ Phase 7. Final Validation, Spec Sync, And Acceptance

### 7.1 Run The Unified Validation Pass

This unit must prove that the full migration passes on one consistent revision rather than on a collection of locally green partial states.

Target files:

- workspace test targets only

#### 📌 Inputs, Outputs, And Side Effects

- Inputs: one revision with all accepted implementation units from Phases 2 through 6 applied.
- Outputs: one unified validation record that proves storage, wallet, and simulator behavior are green together on the same revision.
- Side effects: any failure here invalidates claims of partial completion and forces rollback to the last green phase boundary.

#### 🔑 Invariants, Dependencies, And Ordering

- This unit depends on completion of every required functional phase.
- It must run after focused crate and phase gates are already green so failures identify cross-phase drift rather than local compile errors.
- It must preserve one-revision acceptance; mixing outputs from different revisions is invalid.

#### 🚨 Failure Modes And Review Questions

- Failure mode: the migration is declared complete from separate locally green states that were never validated together.
- Failure mode: one crate-level gate is skipped and leaves cross-crate regression undetected.
- Reviewer questions: which commands were run on the same revision, what failed first if the pass is red, and which phase must be rolled back.

Acceptance conditions:

- storage, wallet, and simulator gates all pass on the same revision
- no phase-specific fixture drift remains

**✔️ Implementation Checklist:**

- [x] Run `cargo test -p z00z_storage --lib`.
- [x] Run `cargo test -p z00z_wallets --lib`.
- [x] Run `cargo test -p z00z_storage --test assets_suite`.
- [x] Run `cargo test -p z00z_wallets --tests`.
- [x] Run `cargo test -p z00z_simulator --lib`.
- [x] Run `cargo test -p z00z_simulator --test test_stage4_digest --release --features test-fast --features wallet_debug_dump`.
- [x] Run `cargo test -p z00z_simulator --test test_stage4_gates --release --features test-fast --features wallet_debug_dump`.
- [x] Run `cargo test -p z00z_simulator --test test_stage6_checkpoint --release --features test-fast --features wallet_debug_dump`.
- [x] Run `cargo test -p z00z_simulator --test test_pipeline_genesis_tx --release --features test-fast --features wallet_debug_dump`.
- [x] Run `cargo test -p z00z_simulator --test test_scenario1_unified_gate --release --features test-fast --features wallet_debug_dump`.
- [x] Run `./scripts/full_verify.sh --max-safe-run` after all focused gates are green.

Validation note:

- The focused unified gates passed for `z00z_storage`, `z00z_wallets`, and the required simulator targets before the final Phase 7 review pass.
- The first `full_verify` pass failed on repository-local formatting and bench-helper clippy warnings, and the final Phase 7 review found one additional workspace-validation blocker: `crates/z00z_storage/benches/assets/shard.rs` panicked during workspace `--all-targets` verification when `Z00Z_ASSET_ROOT_MODE` was unset.
- Phase 7 fixed that blocker by defaulting the shard bench root mode to `current_full_recompute`, then revalidated the workspace bench path with `cargo test -p z00z_storage --release --all-targets`.
- The accepted final validation sweep is green: a definitive foreground `./scripts/full_verify.sh --max-safe-run` completed successfully, and `reports/full_verify-report-long-running-tests.txt` now records `max-safe summary: 269 planned, 22 skipped, 0 failed` with `IsolatedMeasurements: none`.
- The final full-spec audit also re-ran the Phase 7 exact checklist commands `cargo test -p z00z_wallets --tests` and `cargo test -p z00z_simulator --lib` on the same tagged revision, closing the last evidence gap between the checked boxes above and the recorded validation note. Command logs were captured under `.agent_work/jmt_full_spec_matrix_v1.728.0.log` and `.agent_work/jmt_phase7_exact_checklist_v1.728.0.log`.

### 7.2 Sync Remaining Specs And Deferred Work

This unit must update the remaining-gap documentation so closed items are removed from the live gap list and deferred items are named explicitly.

Target files:

- `specs/014-z00z-storage/tmp/jmt-storage-gaps.md`
- any adjacent storage spec only if public wording changed

#### 📌 Inputs, Outputs, And Side Effects

- Inputs: the final accepted implementation state and the deferred decisions from Phase 6.
- Outputs: a synchronized remaining-gap document that names what is closed and what is intentionally deferred.
- Side effects: stale open-gap claims are removed, and follow-up work is isolated instead of being left half-described in live specs.

#### 🔑 Invariants, Dependencies, And Ordering

- This unit depends on a green unified validation pass in `7.1`.
- It must update only documents whose public contract wording actually changed; it must not rewrite adjacent specs speculatively.
- It must preserve explicit deferral language for optional hardening work rather than implying silent completion.

#### 🚨 Failure Modes And Review Questions

- Failure mode: the code is green, but the live remaining-gap spec still claims already-closed gaps are open.
- Failure mode: documentation hides a half-migration by using vague wording instead of naming deferral.
- Reviewer questions: which gaps are now closed, which items remain deferred, and which files changed because the public contract wording actually moved.

Acceptance conditions:

- closed gaps are removed from the remaining-gap list
- deferred optional items are named explicitly rather than left half-implemented

**✔️ Implementation Checklist:**

- [x] Update `specs/014-z00z-storage/tmp/jmt-storage-gaps.md` so each closed gap is no longer presented as open.
- [x] Update adjacent storage specs only when public contract wording changed during implementation.
- [x] Record unresolved optional work from Phase 6 as deferred with a short rationale.
- [x] Reject any documentation update that hides a half-migration behind vague wording.

Validation note:

- The live remaining-gap document now removes the closed functional migration gaps from the open list and keeps only the explicit deferred optional work from Phase 6.
- No adjacent storage spec required wording changes for this phase because the accepted public contract already matched the implemented migration state.

## 🚨 Stop Rules And Recovery

**🚨 Stop execution immediately if any phase causes one of the following regressions:**

- terminal `asset_id` stops being the canonical terminal key
- `AssetStateRoot`, `CheckRoot`, and `TxDigest` start mixing again
- wallet or simulator code introduces a second proof format beside `ProofBlob`
- a path-bound verification step silently falls back to flat `asset_id` identity
- simulator lookup stops enforcing root-bound witness semantics

> [!Caution]
> A migration that compiles while reintroducing path flattening, root substitution, or opaque witness acceptance is not acceptable progress.

**📌 Recovery order must be:**

1. revert only the failing phase changes
2. rerun the last green gate for the preceding phase
3. preserve the last valid proof fixtures and simulator fixtures
4. record the blocker before reopening the phase

## ✅ Completion Definition

**✅ This plan is complete only when all of the following are true on one consistent revision:**

- storage owns the terminal storage-facing contract or one explicit storage-owned compatibility surface
- wallet checkpoint preparation preserves full `AssetPath` semantics until verification is complete
- canonical `ProofBlob` validation is mandatory at the first downstream witness boundary
- simulator Stage 4 and Stage 6 operate on storage-produced root semantics and root-bound witness lookup
- optional hardening items are either finished or explicitly deferred
- the unified validation pass is green
