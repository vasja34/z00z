# 🔑 Incremental Semantic Root Workflow

> [!Important]
> This workflow rewrites the source note in `specs/014-z00z-storage/incremental-semantic-root-tree.md` into an execution plan for adding incremental semantic root calculation to `z00z_storage` without changing the external meaning of `AssetStateRoot`.

**📌 The workflow must preserve two valid calculation paths during rollout: the current full semantic recompute through `AssetModel.root()` and the new incremental semantic cache path.**

**📌 The workflow must not replace the exported semantic root with the physical JMT root. The physical store root and the exported semantic root have different semantics and different hash contours.**

## 🎯 Scope Lock

**📌 This workflow covers only the incremental semantic root tree rollout for `crates/z00z_storage/src/assets/`.**

Required outcomes:

- keep `AssetStateRoot` source-compatible for wallets, simulator, and checkpoint consumers
- keep `ProofItem`, `ProofBlob`, `chk_item`, and `chk_blob` semantics stable
- preserve the canonical hierarchy `definition_id -> serial_id -> asset_id`
- preserve the ability to compute the exported semantic root both by full recompute and by incremental cache
- add tests that prove both calculation paths produce identical roots for the same state transition
- add benchmarks that measure full recompute against incremental cache on the same fixture data
- make the default runtime path switchable only after parity and performance gates pass

> [!Warning]
> This workflow must not widen the public API, must not expose raw `jmt` types outside `z00z_storage`, and must not duplicate an existing cache abstraction when `TreeRoots`, `AssetModel`, or `tx_plan.rs` can be extended safely.

## 👁️‍🗨️ Verified Inputs And Constraints

**📌 Verified source inputs used to build this workflow:**

- `specs/014-z00z-storage/incremental-semantic-root-tree.md`
- `crates/Z00Z_DESIGN_FOUNDATION_short.md`
- `.github/copilot-instructions.md`
- `crates/z00z_storage/src/assets/{README.md,mod.rs,model.rs,proof.rs,store.rs,types.rs}`
- `crates/z00z_storage/src/assets/store_internal/{tree_id.rs,tree_store.rs,tx_plan.rs,whitebox_crud.rs,whitebox_help.rs,whitebox_paths.rs,whitebox_proofs.rs,whitebox_state.rs}`
- `crates/z00z_storage/benches/{assets_shard.rs,common/fixture.rs}`
- `crates/z00z_storage/Cargo.toml`

**📌 Verified current codebase facts:**

- `AssetStore::root()` in `store.rs` still returns `self.model.root()?`
- `ShardPlan.root` in `tx_plan.rs` is still derived through `next.model.root()?`
- `AssetModel` in `model.rs` remains the deterministic semantic oracle for the exported root contract
- `TreeRoots` already caches intermediate semantic subtree roots for definitions and serial buckets, but it does not yet drive the final exported `AssetStateRoot` incrementally
- `root_by_ver` and `model_by_ver` already store versioned semantic outputs and can anchor parity validation and rollback checks
- `ProofItem` and `ProofBlob` are already bound to the semantic root contract and must not change wire meaning during this optimization
- `criterion` benchmark support and shared storage fixtures already exist in `crates/z00z_storage`
- the currently registered storage bench target is `assets_shard`; there is no `semantic_root` bench target yet
- the current `assets_shard` bench uses `Z00Z_ASSET_BENCH_MODE` and exits early for `current_single_jmt`, so the pre-cache baseline gate is not executable yet without first extending benchmark infrastructure

**📌 Verified source-spec conclusion that becomes a hard workflow rule:**

- physical locality already exists in the JMT update path
- semantic locality is still incomplete because final root export depends on a full `AssetModel.root()` pass
- the next safe step is an incremental semantic cache, not a substitution of semantic root with physical root

## ❓ Assumptions And Open Decisions

**📌 The workflow resolves the primary ambiguity from the source note as follows: the optimization target is the exported semantic root path only, not the private physical JMT root path.**

Open decisions that must stay explicit:

- prefer extending the existing private `TreeRoots` structure first; introduce a new private cache type only if `TreeRoots` cannot absorb the required state without mixing unrelated responsibilities
- keep the full recompute path callable after incremental rollout as an oracle path for tests, audits, and benchmark parity
- keep the public method set unchanged; if a runtime mode switch is needed, it must stay private or test-only

> [!Important]
> If Phase 2 shows that `TreeRoots` cannot safely carry top-level semantic root state and touched-cache invalidation, the new structure must be labeled as proposed and kept private to `z00z_storage/src/assets/`.

```mermaid
flowchart TD
  A[Freeze semantic contract] --> B[Define incremental cache contract]
  B --> C[Integrate dual root helpers]
  C --> D[Run parity tests]
  D --> E[Run root-mode benchmarks]
  E --> F{Benchmark win is defensible?}
  F -->|Yes| G[Switch default runtime path]
  F -->|No| H[Keep full recompute default]
  G --> I[Final acceptance gates]
  H --> I
```

## ⚙️ Phase 1. Freeze The Semantic Contract And Benchmark Baseline

### 1.1 Intent

**📌 Freeze what must not change before any cache logic is introduced.**

### 1.2 Entry Conditions

- the nested child-tree topology is already in place
- `AssetStateRoot`, `CheckRoot`, and proof semantics are already stabilized
- the current full recompute path is green and trusted

### 1.3 Steps

1. Freeze the rule that the exported root remains the semantic state commitment produced from the canonical hierarchy.
2. Freeze the rule that `AssetModel.root()` remains the acceptance oracle during the migration.
3. Freeze the rule that `AssetStore::root()`, `RootApi::asset_root()`, and `RootApi::check_root()` keep their public signatures.
4. Freeze the rule that `ProofItem.root()` and `ProofBlob` stay bound to the exported semantic root, not to the physical JMT root.
5. Freeze the benchmark fixture source to `crates/z00z_storage/benches/common/fixture.rs` so both root modes run on identical data.
6. First extend the benchmark surface so the full recompute path can run as a live benchmark target instead of an early-exit placeholder.
7. Capture the pre-cache benchmark baseline for the full recompute path only after that benchmark bootstrap lands.

### 1.4 Required File Targets

- `crates/z00z_storage/src/assets/store.rs`
- `crates/z00z_storage/src/assets/model.rs`
- `crates/z00z_storage/src/assets/proof.rs`
- `crates/z00z_storage/benches/assets_shard.rs`
- `crates/z00z_storage/Cargo.toml`
- proposed `crates/z00z_storage/benches/semantic_root.rs`
- proposed `crates/z00z_storage/outputs/assets/jmt-incremental-bench.md`

### 1.5 Parallelization Rule

- baseline bench wiring can run in parallel with workflow-note updates
- contract freeze decisions must stay serialized before cache design starts
- benchmark bootstrap and baseline capture must stay serialized because the baseline command is invalid until the benchmark target exists

### 1.6 Exit Conditions

- the semantic root contract is written down with no ambiguity
- the benchmark surface can execute a live full-recompute root benchmark
- the full recompute benchmark baseline is stored
- no workflow step still implies that the physical JMT root can replace `AssetStateRoot`

## ⚙️ Phase 2. Define The Incremental Semantic Cache Contract

### 2.1 Intent

**📌 Turn the existing partial subtree-root cache into a deterministic semantic cache that can update only the touched chain and still match `AssetModel.root()`.**

### 2.2 Required Design Rules

1. Reuse `TreeRoots` if it can safely absorb the new responsibilities.
2. If `TreeRoots` is insufficient, introduce one private companion structure under `crates/z00z_storage/src/assets/store_internal/` and keep it off the public facade.
3. The cache contract must cover:
   - asset bucket root for each `(definition_id, serial_id)`
   - serial aggregate root for each `definition_id`
   - top semantic `AssetStateRoot`
4. The cache contract must define empty-state behavior explicitly.
5. The cache contract must define touched-path invalidation and removal behavior explicitly for delete transitions.
6. The cache contract must define snapshot and rollback behavior together with `snap_store()` and `restore_store()`.

### 2.3 Preferred File Targets

- `crates/z00z_storage/src/assets/store.rs`
- `crates/z00z_storage/src/assets/model.rs`
- `crates/z00z_storage/src/assets/store_internal/tx_plan.rs`
- `crates/z00z_storage/src/assets/store_internal/tree_id.rs`
- proposed `crates/z00z_storage/src/assets/store_internal/semantic_cache.rs`

### 2.4 Required Outputs

- one explicit cache ownership rule
- one explicit touched-update rule for put and delete
- one explicit rollback rule
- one explicit parity rule against `AssetModel.root()`
- one explicit historical-root rule that states whether versioned cache state is stored directly or reconstructed from versioned semantic roots plus model snapshots

### 2.5 Critical Pseudocode

```text
on apply_ops(ops):
  next_state = clone current model and path map
  apply ops to next_state
  touched = derive touched (definition_id, serial_id, asset_id) scope
  next_cache = clone current semantic cache
  recompute touched asset bucket roots only
  recompute touched serial roots only
  recompute touched definition leaves only
  recompute top AssetStateRoot from cached definition leaves only
  if parity gate enabled:
    assert next_cache.state_root == next_state.model.root()
  commit plan and snapshot next_cache together with model and path map
```

> [!Caution]
> The top semantic root must be recomputed from canonical definition-leaf ordering, not from internal hash-map iteration order.

### 2.6 Exit Conditions

- the cache stores enough data to update the root incrementally
- no duplicated root source of truth is introduced without a documented reason
- the cache contract is compatible with rollback and historical version tracking

## ⚙️ Phase 3. Integrate The Dual Root Paths Into AssetStore

### 3.1 Intent

**📌 Introduce incremental root calculation behind the existing store facade while keeping the full recompute path alive as the acceptance oracle.**

### 3.2 Serialized Steps

1. Add a private full recompute helper that delegates to `AssetModel.root()`.
2. Add a private incremental helper that derives the root from the semantic cache.
3. Update `plan_ops()` in `tx_plan.rs` so `ShardPlan.root` is computed through the chosen private helper rather than hard-coded `next.model.root()?`.
4. Update `commit_stage()` snapshot handling so cache state rolls back together with `model`, `path_by_id`, `root_by_ver`, and `model_by_ver`.
5. Update both `AssetStore::root()` and `impl RootApi for AssetStore` in `store.rs` so they route through one shared private semantic-root helper; do not change the trait signature in `types.rs` or the `RootApi` implementation for `AssetModel`.
6. Add test-only helpers behind `#[cfg(test)]` for exact dual-path assertions instead of exposing a second public root API.
7. Keep the full recompute helper callable for parity tests, debug checks, and benchmark mode selection.

### 3.3 Required File Targets

- `crates/z00z_storage/src/assets/store.rs`
- `crates/z00z_storage/src/assets/store_internal/tx_plan.rs`
- `crates/z00z_storage/src/assets/store_internal/whitebox_help.rs`
- proposed private cache module if Phase 2 required it

### 3.4 Parallelization Rule

- helper extraction and snapshot extension can run in parallel
- the final root-routing change must stay serialized after both helpers exist

### 3.5 Integration Checkpoint

**📌 At the end of this phase, the public API must still expose only one `root()` path, but internally the store must be able to calculate the semantic root in both modes.**

**📌 The workflow must keep this as a private dual-path design. A second public root method is forbidden.**

**📌 `AssetStore::root()` and `RootApi::asset_root()` must stay behaviorally identical because downstream code can reach the semantic root through either entrypoint.**

### 3.6 Exit Conditions

- public API is unchanged
- full recompute path is still callable privately
- incremental root path is integrated into `AssetStore`
- snapshot rollback includes semantic cache state

## ⚙️ Phase 4. Add Deterministic Parity Gates

### 4.1 Intent

**📌 Prove that full recompute and incremental cache produce the same semantic root for the same state at every relevant transition shape.**

### 4.2 Required Test Scope

- empty state
- single insert
- multi-definition insert
- multi-serial insert under one definition
- delete last asset in a serial bucket
- delete last serial under a definition
- mixed put and delete in one `apply_ops()` call
- repeated no-op equivalent updates
- rollback after injected commit failure
- historical root lookup parity by version
- proof generation parity where `ProofItem.root()` must stay unchanged

### 4.3 Required File Targets

- `crates/z00z_storage/src/assets/model_tests.rs`
- `crates/z00z_storage/src/assets/store_internal/whitebox_help.rs`
- `crates/z00z_storage/src/assets/store_internal/whitebox_state.rs`
- `crates/z00z_storage/src/assets/store_internal/whitebox_proofs.rs`
- `crates/z00z_storage/tests/assets/store_api.rs`

### 4.4 Required Test Rules

1. Every parity test must compute the root both ways and compare exact bytes.
2. Every versioned-state test must compare both the current root and stored historical roots.
3. Every rollback test must verify that cache state is restored together with model state.
4. Every proof test must verify that the root embedded in `ProofItem` is identical regardless of calculation mode.
5. At least one property-style test must randomize operation order and confirm that both modes converge on the same root for equivalent final state.
6. At least one historical-version test must compare `root_by_ver` outputs against both calculation paths after more than one committed version.
7. Test-only dual-root helpers must stay private to `whitebox_help.rs` or equivalent `#[cfg(test)]` storage-only helpers.

### 4.5 Critical Pseudocode

```text
for scenario in parity_scenarios:
  store = seeded_store(scenario.initial)
  store.apply_ops(scenario.ops)
  root_full = store.root_full_for_test()
  root_inc = store.root_inc_for_test()
  assert root_full == root_inc
```

> [!Warning]
> A passing incremental cache with no explicit parity tests is not acceptable. The migration must fail closed on any root divergence.

### 4.6 Exit Conditions

- parity is proven for CRUD, rollback, historical root, and proof paths
- no test relies on undefined map ordering
- both modes are demonstrably deterministic

## ⚙️ Phase 5. Add Focused Benchmarks For Root Calculation Modes

### 5.1 Intent

**📌 Measure whether incremental semantic caching actually improves root-calculation cost on representative storage transitions.**

### 5.2 Benchmark Rules

1. Reuse `benches/common/fixture.rs` for all benchmark data generation.
2. Keep existing operation benches intact.
3. Either extend `assets_shard.rs` with a live root-only mode or add one dedicated root-mode benchmark target if the current `assets_shard.rs` structure cannot isolate root cost cleanly.
4. The benchmark harness must be able to force both semantic-root code paths explicitly, independent of whichever path is the default runtime path at the time of measurement.
5. Measure the same scenarios in both modes:
   - full recompute
   - incremental cache
6. Measure at least these scenario families:
   - one-asset update in a large state
   - one-serial bucket update
   - one-definition fanout update
   - mixed put and delete batch
   - no-op equivalent update

### 5.3 Preferred File Targets

- `crates/z00z_storage/benches/common/fixture.rs`
- `crates/z00z_storage/benches/assets_shard.rs`
- `crates/z00z_storage/Cargo.toml`
- proposed `crates/z00z_storage/benches/semantic_root.rs`
- proposed `crates/z00z_storage/outputs/assets/jmt-incremental-bench.md`

### 5.4 Required Output Artifact

- one benchmark report that records exact command lines, exact mode-selector inputs, fixture shape, mode names, and observed timing deltas
- one explicit note that states whether the benchmark was implemented inside `assets_shard.rs` or in a dedicated `semantic_root` bench target

### 5.5 Decision Gate

**📌 If the benchmark shows no meaningful win for incremental root calculation, keep the full recompute path as the default runtime path and treat the cache as experimental or test-only until a later iteration.**

> [!Important]
> Performance is a required validation gate, not a guaranteed outcome. The workflow must preserve the ability to reject the default-mode switch if the measured gain is weak or negative.

```mermaid
sequenceDiagram
  participant Ops as StoreOps
  participant Model as AssetModel
  participant Cache as Semantic cache
  participant Gate as Parity gate
  participant Bench as Benchmark gate
  participant API as AssetStore::root()

  Ops->>Model: apply deterministic transition
  Ops->>Cache: update touched chain only
  Cache->>Gate: produce incremental root
  Model->>Gate: produce full recompute root
  Gate-->>Bench: equal roots required
  Bench-->>API: incremental default only if faster enough
```

### 5.6 Exit Conditions

- benchmark numbers exist for both modes
- fixture and command lines are reproducible
- the workflow can state clearly whether incremental mode wins, ties, or loses

## ⚙️ Phase 6. Switch The Default Runtime Path Only After Gates Pass

### 6.1 Intent

**📌 Promote incremental calculation from parity path to default runtime path only when correctness and benchmark gates are both green.**

### 6.2 Serialized Steps

1. Keep the public `root()` method unchanged.
2. Switch the shared private semantic-root helper from full recompute to incremental cache.
3. Keep the full recompute helper available for regression checks.
4. Keep at least one regression test that forces parity against the full recompute oracle after the switch.
5. Verify that `AssetStore::root()` and `RootApi::asset_root()` still return identical bytes after the default-path switch.
6. Update storage module documentation so the runtime source of truth is described accurately.

### 6.3 Required File Targets

- `crates/z00z_storage/src/assets/store.rs`
- `crates/z00z_storage/src/assets/README.md`
- `crates/z00z_storage/src/assets/store_internal/whitebox_state.rs`
- `crates/z00z_storage/tests/assets/store_api.rs`

### 6.4 Blocker Rule

**📌 Do not switch the default runtime path in this phase if any parity gate fails or if the benchmark report does not show a defensible benefit.**

### 6.5 Exit Conditions

- the runtime default is switched only if correctness and performance both justify it
- the old full recompute path is still available privately for audits
- documentation matches the real implementation order and source of truth

## ⚙️ Phase 7. Final Acceptance And Recovery Flow

### 7.1 Intent

**📌 Close the rollout with deterministic acceptance commands, stop rules, and rollback guidance.**

### 7.2 Acceptance Commands

Run these gates in order:

```bash
cargo fmt --all
cargo clippy --workspace --release --all-targets -- -D warnings
cargo test -p z00z_storage --lib
cargo test -p z00z_storage --test assets_suite
cargo bench -p z00z_storage --bench assets_shard --no-run
./scripts/full_verify.sh --max-safe-run
```

> [!Note]
> Run `cargo bench -p z00z_storage --bench semantic_root --no-run` only if Phase 5 introduced a dedicated `semantic_root` target and registered it in `crates/z00z_storage/Cargo.toml`.
>
> [!Important]
> Before final acceptance, run the exact two benchmark commands recorded in `crates/z00z_storage/outputs/assets/jmt-incremental-bench.md`: one command that forces the full recompute semantic-root path and one command that forces the incremental semantic-cache path. Do not treat `--no-run` bench compilation as a substitute for the performance gate.

### 7.3 Recovery Rules

1. If parity tests fail, stop the rollout and keep full recompute as the runtime path.
2. If rollback tests fail, do not proceed to benchmark work.
3. If benchmark infrastructure fails, land correctness work only if the workflow explicitly marks the performance decision as blocked.
4. If incremental mode regresses correctness after the default switch, revert only the default-mode selection and keep the dual-path code for diagnosis.

### 7.4 Final Acceptance Criteria

- exported semantic root meaning is unchanged
- both root-calculation paths still exist
- parity tests prove exact output equality
- proof semantics are unchanged
- benchmark results are recorded and reproducible
- the workflow outcome states clearly whether incremental mode became the default runtime path

## ✅ Completion And Sequencing Check

**📌 H2 and H3 sections in this document follow the real implementation order: freeze contract, define cache, integrate dual paths, prove parity, measure performance, switch default only if justified, then close with acceptance.**

**📌 No section order from the source note was preserved when it would hide dependencies. The workflow intentionally places benchmark baseline before cache design, parity before default switch, and performance decision before final rollout.**
