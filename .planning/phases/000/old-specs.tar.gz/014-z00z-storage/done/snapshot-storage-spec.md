# Prep Snapshot Storage Specification For z00z_storage

[TOC]

## 1. Scope

### 1.1 Scope Contract

This document specifies the storage contract for the pre-state snapshot artifact that sits between transaction input resolution and checkpoint application.

The goal is to define one canonical `PrepSnapshot` format for `z00z_storage` that is fully aligned with the hierarchical asset JMT model described in `specs/014-z00z-storage/jmt-storage-spec-gaps.md`.

This document is intentionally strict about the difference between the current simulator `PrepFile`, the canonical wallet-side `MemberWit` and resolved-input model, and the target storage contract.

Implementation checklist:

- [ ] Freeze the scope of this document to pre-state snapshot artifacts, witness packaging, and replay anchors only; do not fold checkpoint outputs or unrelated runtime state into this contract.
- [ ] Require every implementation task derived from this spec to state whether it changes canonical snapshot payloads, witness semantics, replay helpers, or migration adapters.
- [ ] Keep snapshot responsibilities separate from checkpoint finalization and from wallet scan cryptography so one artifact does not serve multiple roles implicitly.
- [ ] Treat this spec as dependent on the JMT storage contract and as an input contract for the checkpoint spec, not as an independent storage design.
- [ ] Block implementation kickoff until the team agrees that `PrepSnapshot` is the canonical pre-state record and not a simulator debugging file with nicer names.

### 1.2 Non-Goals And Scope Boundaries

This document does not redefine terminal JMT leaf semantics, checkpoint proof semantics, or wallet ownership logic.

Implementation checklist:

- [ ] Reject any implementation task that attempts to redefine `AssetLeaf`, `AssetCommitProof`, or final checkpoint artifact semantics from inside snapshot work.
- [ ] Keep audit convenience fields, scenario labels, and report references out of canonical snapshot bytes unless a later explicit revision requires them.
- [ ] Require any proposed new canonical snapshot field to name the exact verification need it serves and why it cannot live in a wrapper.
- [ ] Fail review if execution-input or checkpoint-output data is proposed for direct inclusion into the canonical snapshot payload.

## 2. Current Repository State

### 2.1 Current State Inventory

The current simulator pre-state artifact exists in `crates/z00z_simulator/src/scenario_1/stage_4.rs` as:

- `PrepFile { prev_root_hex, rows }`
- `PrepRow { definition_id_hex, asset_id_hex, serial_id, leaf, member_wit_hex }`

The current simulator artifact is structurally useful because it already captures the four essential ideas of a pre-state snapshot:

1. one root anchor
2. one terminal `asset_id` per input
3. one resolved `AssetLeaf` per input
4. one membership witness field per input

The canonical wallet-side checkpoint application already defines the actual typed membership witness and resolved input model in `crates/z00z_wallets/src/core/tx/state_update.rs` through:

- `MemberWit { proof: Vec<u8>, proof_item: ProofItem }`
- `ResolvedInput { path, leaf, member_wit }`

The legacy repository boundary still exposes `MemberIdx::get_wit(prev_root, asset_id)`, but the active checkpoint preparation path already consumes the path-bound `InputResolver::resolve(prev_root, asset_id, serial_id)` contract and validates `ResolvedInput` against `ProofItem` plus `chk_blob(...)` semantics.

However, the hierarchical JMT design in `jmt-storage-spec-gaps.md` requires aggregate proof path metadata `AssetPath { definition_id, serial_id, asset_id }` for unambiguous membership verification.

The current simulator `PrepFile` already carries namespace metadata through `PrepRow.definition_id_hex`, but it still transports the path as split fields instead of one typed `AssetPath` record.

The current simulator witness field now carries storage-owned proof bytes. `member_wit_hex` is filled from `AssetStore::proof_blob(&path)` and stores `ProofBlob::encode()` output rather than a placeholder digest.

The current simulator no longer sources `prev_root_hex` from `tx_digest_hex`. Stage 4 builds `prev_root_hex` from `AssetStore::check_root()`, while `tx_digest_hex` remains a separate transaction-envelope field in the stage snapshot and tx package.

Implementation checklist:

- [ ] Inventory every producer and consumer of snapshot-related fields in `z00z_simulator`, `z00z_wallets`, and any scenario/report outputs before changing artifact semantics.
- [ ] Record the exact source of truth for `prev_root`, `definition_id`, `serial_id`, `asset_id`, `leaf`, and witness bytes, and reject any implementation that derives them from wrappers instead of canonical typed inputs.
- [ ] Record that Stage 4 and Stage 6 already transport storage-owned `ProofBlob` bytes in `member_wit_hex`, and reject any regression back to placeholder witness digests.
- [ ] Keep `tx_digest_hex` separate from snapshot root material and reject any regression that reuses it as `prev_root_hex`.
- [ ] Require one migration map that links current `PrepFile` and `PrepRow` fields to their target canonical equivalents or to audit-only wrappers.

### 2.2 Current Mismatch Map

The repository currently mixes a simulator wrapper, a wallet-side typed witness model, and a hierarchical JMT proof model that are only partially aligned.

Implementation checklist:

- [ ] Write one mismatch matrix mapping current simulator fields, wallet-side resolved input fields, and target canonical snapshot fields one-to-one.
- [ ] Distinguish which mismatches are missing fields, wrong proof bytes, wrong root source, or missing path metadata so migration tasks remain precise.
- [ ] Add one migration note per mismatch explaining whether it is solved by field addition, source correction, type split, or wrapper removal.
- [ ] Refuse implementation if any current field can still map to more than one target meaning after the mismatch matrix is written.

## 3. Current Design Limits

### 3.1 Current Gaps That Block Canonical Snapshot Storage

The current repository therefore has three distinct prep-snapshot layers that are not yet fully aligned:

1. simulator JSON wrapper
2. wallet-side typed membership model
3. storage-owned proof blob and path semantics

The first design limit is that the live snapshot artifact still exists as a simulator-local JSON wrapper rather than a dedicated `z00z_storage` snapshot facade.

The second design limit is that the simulator wrapper still splits `definition_id_hex`, `asset_id_hex`, and `serial_id` across transport fields instead of persisting one typed `AssetPath` record.

The third design limit is that the repository still keeps a flat `MemberIdx::get_wit(prev_root, asset_id)` trait for some boundaries even though the active checkpoint path already prefers path-bound `InputResolver` resolution.

The fourth design limit is that the current simulator snapshot is useful operationally, but it is not yet expressed as a canonical storage-layer schema with explicit versioning, typed semantics, and migration guarantees.

The fifth design limit is that there is still no canonical content-addressed snapshot identity or dedicated storage-side persistence API for pre-state snapshot artifacts.

Implementation checklist:

- [ ] Treat each design limit in this section as a blocking implementation gap with explicit owner and removal criteria.
- [ ] Add one failing test or failing validation rule per gap before implementing the final fix so progress can be measured concretely.
- [ ] Prohibit rollout where canonical snapshot structs exist but simulator-local wrappers, split path transport fields, or path-free verification remain silently accepted.
- [ ] Add one migration risk note for every place where structurally valid snapshot bytes can still carry semantically wrong root, path, or witness meaning.
- [ ] Reject any implementation plan that solves serialization only and leaves storage-owned witness binding or typed path semantics ambiguous.

### 3.2 Blocker Enforcement Rules

The limits in this section are release blockers for canonical snapshot storage, not soft warnings.

Implementation checklist:

- [ ] Convert each blocker into one tracked validation gate in tests, runtime checks, or migration feature flags.
- [ ] Require each blocker to have one “how it fails today” example and one explicit acceptance rule for the fixed state.
- [ ] Do not mark snapshot rollout complete while any blocker can still produce a structurally valid but semantically wrong snapshot artifact.
- [ ] Add a release checklist item requiring explicit sign-off that all blockers here are eliminated or isolated behind non-production paths.

## 4. Required Target Model

### 4.1 Target Snapshot Artifact Contract

The corrected target model is one canonical pre-state artifact named `PrepSnapshot`.

`PrepSnapshot` records the exact resolved input set under one canonical `prev_root`, before any checkpoint update is applied.

The intended lifecycle is:

1. load the canonical asset-state root from JMT storage
2. resolve each input reference to one terminal `asset_id`
3. load the concrete pre-state `AssetLeaf`
4. load the canonical membership witness under `prev_root`
5. persist the result as `PrepSnapshot`

This artifact is the pre-state replay anchor for checkpoint construction, checkpoint auditing, and deterministic simulator execution.

It is necessary for checkpoint apply, but not sufficient by itself. Checkpoint apply also needs ordered execution input carrying output leaves and tx-proof bytes.

Implementation checklist:

- [ ] Define one canonical artifact lifecycle from resolved input set under one validated root to persisted `PrepSnapshot` bytes and forbid shortcut flows that skip root or witness validation.
- [ ] Require `PrepSnapshot` to be the only canonical pre-state record and treat `PrepFile` or other scenario wrappers as compatibility-only artifacts.
- [ ] Add tests proving that a snapshot cannot be built without a validated asset-state root and resolved typed path information.
- [ ] Keep the snapshot payload minimal and separate from checkpoint execution input, tx-proof bytes, and post-state deltas.
- [ ] Require `PrepSnapshotId` to be content-addressed from canonical bytes only and forbid identity schemes based on filenames or stage labels.

### 4.2 Snapshot Artifact Boundary

The canonical snapshot boundary ends at validated pre-state leaf material plus validated membership witness bytes.

Implementation checklist:

- [ ] Treat output leaves, tx-proof bytes, and checkpoint deltas as out-of-scope for canonical snapshot payloads even if simulators want one combined export file.
- [ ] Add tests proving that adding replay-execution material to wrappers does not alter the canonical snapshot bytes or `PrepSnapshotId`.
- [ ] Reject any API that claims `PrepSnapshot` alone is a full checkpoint execution package.
- [ ] Ensure `PrepSnapshotId` is computed only from canonical pre-state bytes and never from wrapper or audit fields.

## 5. Root Semantics Separation

### 5.1 Snapshot Root Binding Contract

The snapshot storage contract must preserve the same root-semantics separation already required by `jmt-storage-spec-gaps.md`.

The following values are distinct and must never be substituted for one another:

1. asset-state root
2. checkpoint `prev_root`
3. checkpoint `new_root`
4. transaction digest

The required contract is:

- `PrepSnapshot.prev_root` is an asset-state root only
- `tx_digest_hex` is a transaction-envelope digest only

The forbidden equivalences are:

- `PrepSnapshot.prev_root == tx_digest_hex`
- `PrepSnapshot.prev_root == build_tx_package_digest(...)`

No current Stage 4 builder path should reuse `tx_digest_hex` as a root anchor. The live safety requirement is to keep the existing storage-root behavior locked by tests and to reject any future regression that reintroduces tx-digest root aliasing.

Implementation checklist:

- [ ] Introduce or reuse typed root wrappers so asset-state roots and tx digests cannot be mixed at public snapshot boundaries without explicit conversion.
- [ ] Remove all code paths that source snapshot roots from tx-digest placeholders before canonical snapshot validation is enabled outside isolated migration tests.
- [ ] Require snapshot builders to read `prev_root` only from validated asset-state root APIs, never from scenario wrappers or transport fields.
- [ ] Add negative tests proving that tx-digest values of the correct byte length still fail snapshot root validation and witness verification.
- [ ] Add migration assertions around simulator adapters so placeholder root sources fail loudly once typed asset-state roots are available.

### 5.2 Root Source Enforcement

Typed roots are necessary but not sufficient. The implementation must also restrict which subsystem is allowed to produce root values for snapshots.

Implementation checklist:

- [ ] Restrict snapshot root production to validated JMT storage APIs and forbid arbitrary callers from supplying free-form root bytes.
- [ ] Add adapter-level assertions that test fixtures and scenario wrappers can only pass roots through typed constructors fed from canonical sources.
- [ ] Add tests proving that cached strings, report files, and tx-digest-derived values are rejected even when they fit the expected root size.
- [ ] Require code review to flag any new function that accepts a snapshot root without documenting its source of truth.

## 6. Proposed Artifact Layout

### 6.1 Snapshot Artifact Shape

The canonical prep snapshot should be named `PrepSnapshot`.

Recommended fields:

- `version`
- `prev_root`
- `entries`

Recommended entry shape:

- `PrepEntry { path, leaf, member_wit }`

Where:

- `path = AssetPath { definition_id, serial_id, asset_id }`

Field semantics:

- `version`: snapshot schema version only
- `prev_root`: canonical asset-state root under which all entries were resolved
- `definition_id`: logical asset namespace identity
- `serial_id`: serial bucket identity inside that namespace
- `asset_id`: terminal consumed leaf identity
- `leaf`: full resolved `AssetLeaf` bytes used by state application
- `member_wit`: opaque membership witness bytes for that leaf under `prev_root`

The snapshot must store the full resolved leaf, not only `leaf_hash`, because checkpoint application already expects concrete `AssetLeaf` values and not only hashes.

The snapshot must also remain strictly pre-state only. It must not absorb output leaves, tx-proof bytes, or checkpoint delta material.

The path metadata must not be inferred from `AssetLeaf` bytes alone, because `AssetLeaf` does not carry `definition_id`.

A content-addressed `PrepSnapshotId` should still exist, but it should be derived from the canonical serialized snapshot body and kept outside the self-serialized canonical payload. Otherwise the artifact identity becomes recursively self-referential.

`PrepSnapshotId` must not depend on external filenames, simulator stage labels, or audit-wrapper metadata.

Reference type sketch:

```rust
pub struct PrepSnapshot {
    pub version: PrepSnapshotVersion,
    pub prev_root: AssetStateRoot,
    pub entries: Vec<PrepEntry>,
}

pub struct PrepEntry {
    pub path: AssetPath,
    pub leaf: AssetLeaf,
    pub member_wit: MemberWitnessBytes,
}

pub struct AssetPath {
    pub definition_id: DefinitionId,
    pub serial_id: SerialId,
    pub asset_id: AssetId,
}
```

Reference identity rule:

```rust
pub fn derive_prep_snapshot_id(
    snapshot: &PrepSnapshot,
) -> Result<PrepSnapshotId, PrepSnapshotError> {
    let bytes = canonical_encode_snapshot(snapshot)?;
    Ok(PrepSnapshotId::from_canonical_bytes(&bytes))
}
```

Implementation checklist:

- [ ] Define canonical `PrepSnapshot` and `PrepEntry` structs with fixed field order and stable semantics for every field.
- [ ] Require every entry to carry explicit `AssetPath`, full `AssetLeaf`, and witness bytes, and reject path reconstruction from leaf payloads.
- [ ] Keep `PrepSnapshotId` external to the self-serialized payload and derive it only from canonical bytes.
- [ ] Add tests proving that wrapper-only metadata changes do not alter canonical snapshot bytes or `PrepSnapshotId`.
- [ ] Reject any implementation that stores only leaf hashes or only path fragments in place of full resolved snapshot entries.
- [ ] Implement `PrepSnapshot` and `PrepEntry` as concrete typed records, not generic maps, so field order, field names, and optionality are frozen at the type boundary.
- [ ] Freeze the canonical encode rule in code and docs: encode `version`, `prev_root`, then ordered `entries`, and reject any serializer that can permute fields silently.
- [ ] Add one round-trip test that derives `PrepSnapshotId`, reloads the same bytes, and proves the reloaded artifact yields the same id with no wrapper participation.
- [ ] Add one corruption test proving that changing `path`, `leaf`, or `member_wit` after id derivation invalidates the canonical bytes and yields a different `PrepSnapshotId`.

### 6.2 Payload Minimality Rules

The canonical snapshot payload must contain everything needed for pre-state membership replay and nothing that belongs to later checkpoint execution stages.

Implementation checklist:

- [ ] Keep output leaves, tx-proof bytes, checkpoint deltas, fragment ids, and report metadata out of canonical snapshot entries.
- [ ] Add validation rules rejecting extra fields in canonical codecs when those fields belong to execution or audit layers.
- [ ] Add tests proving that a snapshot with valid entries but extra checkpoint-only material is rejected as non-canonical.
- [ ] Require wrapper artifacts for any audit or debug metadata instead of overloading the canonical snapshot type.

## 7. Why Snapshot Must Stay Separate From Checkpoint

### 7.1 Artifact Separation Contract

The snapshot artifact and the checkpoint artifact should remain separate records.

The snapshot records pre-state truth.

The checkpoint artifact records post-state transition output.

The pre-state snapshot exists so that a checkpoint builder, simulator, or auditor can prove exactly what was consumed under one `prev_root` before trusting any `new_root` or `created_delta`.

If these records are merged prematurely, it becomes too easy to accept a post-state artifact without first validating that the consumed inputs were correctly resolved under the committed pre-state root.

Implementation checklist:

- [ ] Keep `PrepSnapshot` and `CheckpointArtifact` as distinct persisted types with distinct codecs, ids, and validation paths.
- [ ] Forbid APIs that accept one merged pre-state-plus-post-state record as the canonical representation of a transition.
- [ ] Add validation rules requiring snapshot verification to succeed before checkpoint finalization or replay proceeds.
- [ ] Add tests proving that invalid pre-state material causes checkpoint construction or audit to fail even if post-state output is otherwise well-formed.
- [ ] Reject any implementation that duplicates checkpoint output material inside canonical snapshot bytes for convenience.

### 7.2 Enforced Consequences Of Separation

Artifact separation is not only a modeling choice. It changes builder and audit control flow.

Implementation checklist:

- [ ] Make checkpoint builders consume snapshot identity explicitly rather than reconstructing or discovering snapshot context implicitly.
- [ ] Require replay and audit code to load snapshot and checkpoint artifacts independently and cross-check them through linkage metadata.
- [ ] Add tests proving that mutating checkpoint wrappers does not change snapshot meaning, only whether later replay/linkage succeeds.
- [ ] Reject any convenience wrapper that collapses snapshot, execution input, and checkpoint output into one canonical record.

## 8. Where Canonical Fields Come From

### 8.1 Field Source Of Truth Contract

The field origins must be explicit.

`PrepSnapshot` fields come from:

- `prev_root`: canonical asset-state root from the JMT-backed state API
- `definition_id`: trusted namespace resolution at the storage boundary
- `asset_id`: consumed input reference after canonical parse
- `serial_id`: input reference consistency field from the tx input
- `leaf`: resolved pre-state leaf loaded from JMT-backed storage
- `member_wit`: serialized `MemberWit.proof` bytes under `prev_root`

The snapshot must not be built from ad-hoc cached wallet objects, tx outputs, or synthetic hashes.

It must always be built from the canonical state view under one root.

The snapshot builder must also not guess `definition_id` from `asset_id` or from display-only fields such as `symbol`. Namespace resolution must come from trusted transaction or registry metadata supplied before the storage boundary.

Implementation checklist:

- [ ] Define one source-of-truth mapping for `prev_root`, `definition_id`, `serial_id`, `asset_id`, `leaf`, and `member_wit`, and require builders to populate fields only from those sources.
- [ ] Compute snapshot fields from validated state and validated input references, not from cached wallet objects or simulator wrapper order.
- [ ] Add tests proving that changing display-only metadata like `symbol` does not alter canonical snapshot field derivation when `definition_id` remains the same.
- [ ] Fail builders that attempt to source canonical fields from report files, filenames, row numbers, or debug records.

### 8.2 Forbidden Field Sources

Some field sources remain invalid even if they are convenient during debugging or simulation.

Implementation checklist:

- [ ] Forbid sourcing snapshot roots from tx digests, wrapper placeholders, or report files.
- [ ] Forbid sourcing `definition_id` from `asset_id`, `symbol`, or any derived display metadata.
- [ ] Forbid sourcing witness bytes from placeholder digests, caches, or themed hashes once canonical witness bytes are available.
- [ ] Add tests proving that builders reject snapshot artifacts assembled from debug or wrapper data when canonical typed inputs are unavailable.

## 9. Type Integrity And Domains

### 9.1 Typed Snapshot Domain Contract

The snapshot storage contract should use strong semantic wrappers.

Recommended wrappers:

- `AssetStateRoot`
- `DefinitionId`
- `AssetId`
- `SerialId`
- `AssetPath`
- `PrepSnapshotVersion`
- `PrepSnapshotId`
- `MemberWitnessBytes`

Internally, the snapshot layer should never use free-form strings as roots or ids. Hex encoding is only a transport encoding for JSON or human-facing reports.

The old placeholder witness digest described in earlier drafts is no longer the live Stage 4 path.

- current live bridge: `AssetStore::proof_blob(&path)` -> `ProofBlob::encode()` -> `member_wit_hex`
- wallet-side typed bridge: `MemberWit { proof, proof_item }`
- verifier boundary: `chk_blob(...)` over `ProofBlob` bytes plus `ProofItem` context

Therefore the target storage layer stores storage-owned witness bytes, not witness-themed digests.

At the current repository boundary, `MemberWit.proof` is still an opaque witness container, but the repository does already bind it to a typed `ProofItem`. This spec must therefore not invent a current-state `AssetCommitProof` type or decoder that does not exist in the codebase.

What must already be fixed, however, is the verification binding: canonical snapshot verification must bind witness bytes to the exact tuple `(prev_root, definition_id, serial_id, asset_id, leaf)` under the hierarchical JMT contract. A future-proof storage spec must not treat `asset_id`-only witness lookup as sufficient verifier meaning.

Implementation checklist:

- [ ] Introduce or reuse strong types for roots, ids, paths, snapshot ids, versions, and witness byte containers in all public snapshot APIs.
- [ ] Forbid raw string roots, generic byte arrays, and untyped path tuples at public snapshot boundaries except inside explicit codec modules.
- [ ] Keep witness bytes as a typed container distinct from generic blobs so snapshot code cannot confuse proof bytes with arbitrary payload bytes.
- [ ] Add negative tests proving that wrong root type, wrong id type, wrong path element, or wrong witness container cannot cross the snapshot boundary silently.
- [ ] Require the current `ProofBlob` plus `ProofItem` bridge to stay explicit in code and docs until a replacement codec actually lands in the repository.

### 9.2 Transport Conversion Boundary

Transport formats may still use hex strings or JSON fields, but conversion into typed snapshot values must happen before canonical validation.

Implementation checklist:

- [ ] Keep all string and hex decoding logic inside codec or adapter modules and out of canonical snapshot validation logic.
- [ ] Require decoders to fail before validation starts if external data cannot be converted into typed snapshot fields.
- [ ] Add tests proving malformed transport encodings cannot reach proof verification or replay logic as partially decoded values.
- [ ] Forbid storing transport-local field names as internal semantic identifiers inside snapshot code.

## 10. Consistency Contract With JMT Storage

### 10.1 Snapshot Consistency Invariants

The prep snapshot is valid only if it is fully consistent with the hierarchical JMT asset-state contract.

The mandatory invariants are:

1. `PrepSnapshot.prev_root` must equal a real asset-state root produced by the JMT hierarchy.
2. Every `PrepEntry.path.definition_id` must equal the logical asset namespace used by the hierarchical proof path.
3. Every `PrepEntry.path.asset_id` must equal the terminal leaf key used in the per-serial asset tree.
4. Every `PrepEntry.path.serial_id` must equal `PrepEntry.leaf.serial_id`.
5. Every `PrepEntry.leaf.asset_id` must equal `PrepEntry.path.asset_id`.
6. Every `PrepEntry.member_wit` must verify membership of the resolved leaf under `PrepSnapshot.prev_root` and the exact hierarchical path.
7. No snapshot entry may use `definition_id` as a substitute for terminal `asset_id`.
8. All entries in one snapshot must bind to the same `prev_root`.
9. Snapshot entry order must be deterministic for identical resolved input sets.
10. If one snapshot spans multiple tx packages, entry order must follow the same flattened canonical input order that checkpoint preparation will later consume.
11. Snapshot entries must not contain duplicate exact `AssetPath` values.
12. Snapshot entries must not reuse one terminal `asset_id` under multiple distinct hierarchical paths inside the same canonical snapshot.
13. Every `PrepEntry.member_wit` must decode into one canonical commitment-layer proof object whose carried `asset_state_root` equals `PrepSnapshot.prev_root`.
14. Every decoded commitment-layer proof object must carry the same canonical terminal JMT value hash that is recomputed from the enclosing `PrepEntry.leaf`.

The snapshot layer must therefore preserve the same identity split fixed by `jmt-storage-spec-gaps.md`:

- `definition_id` identifies the logical asset namespace
- `asset_id` identifies the terminal encrypted leaf

The snapshot therefore carries full `AssetPath` metadata, while preserving the rule that terminal leaf identity is still `asset_id` and not `definition_id`.

Implementation checklist:

- [ ] Implement one validation function that checks every invariant in this section against the snapshot entries, decoded witness objects, and resolved leaf material before the snapshot is accepted or exported.
- [ ] Add distinct failure cases for root mismatch, path mismatch, serial mismatch, asset-id mismatch, duplicate path reuse, duplicate terminal-id reuse, and leaf-hash mismatch.
- [ ] Verify decoded witness root and path against the enclosing entry rather than trusting the enclosing entry alone.
- [ ] Add tests proving that substituting `definition_id` for terminal `asset_id` causes a hard reject even when proof bytes are otherwise well-formed.
- [ ] Reject snapshots whose entries do not all bind to exactly the same `prev_root`.

### 10.2 Ordering And Uniqueness Rules

Consistency is not only cryptographic. It also depends on deterministic ordering and injective path usage.

Implementation checklist:

- [ ] Preserve deterministic entry order from canonical input order and reject any builder that sorts entries by convenience after resolution.
- [ ] Add tests proving that duplicate `AssetPath` values and ambiguous reuse of one terminal `asset_id` under multiple paths are rejected independently.
- [ ] Require replay comparison to use exact ordered entry equality rather than set equality.
- [ ] Add tests proving that the same resolved input set always yields the same ordered snapshot bytes and the same `PrepSnapshotId`.

## 11. Storage Abstractions For z00z_storage

### 11.1 Public Snapshot Facade Contract

The new crate should expose a dedicated pre-state snapshot abstraction instead of leaking simulator-only JSON wrappers.

Recommended public abstractions:

- `PrepSnapshotStore`
- `PrepSnapshot`
- `PrepSnapshotId`
- `PrepEntry`
- `PrepSnapshotError`

Recommended responsibilities:

- build canonical prep snapshots from resolved storage state
- persist and load canonical prep snapshots
- assign or verify a content-addressed `PrepSnapshotId` from canonical bytes only
- validate snapshot integrity against one `prev_root`
- expose snapshot entries to checkpoint builders and auditors
- keep pre-state witness material separate from ordered execution input used later by checkpoint apply
- preserve full hierarchical path metadata required for membership verification

The JMT asset hierarchy remains the source of truth for roots and leaf resolution. The snapshot layer is a typed persisted view over that pre-state.

Reference facade sketch:

```rust
pub trait PrepSnapshotStore {
    fn build_snapshot(
        &self,
        prev_root: AssetStateRoot,
        inputs: &[ResolvedSpendRef],
    ) -> Result<PrepSnapshot, PrepSnapshotError>;

    fn save_snapshot(
        &mut self,
        snapshot: &PrepSnapshot,
    ) -> Result<PrepSnapshotId, PrepSnapshotError>;

    fn load_snapshot(
        &self,
        snapshot_id: &PrepSnapshotId,
    ) -> Result<PrepSnapshot, PrepSnapshotError>;

    fn validate_snapshot(
        &self,
        snapshot: &PrepSnapshot,
    ) -> Result<(), PrepSnapshotError>;
}
```

Reference ownership split:

```mermaid
flowchart TD
    JMT[JMT Asset State]
    STORE[PrepSnapshotStore]
    SNAP[PrepSnapshot]
    CHECK[Checkpoint Builder]
    AUDIT[Audit Wrapper]

    JMT --> STORE
    STORE --> SNAP
    SNAP --> CHECK
    SNAP --> AUDIT
```

Implementation checklist:

- [ ] Define a narrow public `PrepSnapshotStore` API that exposes only canonical snapshot operations and validation needed by callers.
- [ ] Keep snapshot persistence explicit rather than hiding canonical and wrapper behavior behind one ambiguous save method.
- [ ] Define one explicit error taxonomy for root mismatch, path mismatch, witness decode failure, leaf mismatch, id calculation failure, and backend failure.
- [ ] Add adapter modules for simulator and wallet integration rather than leaking snapshot storage internals into those crates.
- [ ] Add API tests proving callers can validate and load snapshots without depending on simulator-local wrapper types.
- [ ] Separate `build_snapshot`, `save_snapshot`, `load_snapshot`, and `validate_snapshot` into distinct facade calls and reject APIs that infer operation kind from payload shape.
- [ ] Require the facade to accept typed roots and typed input references only; do not allow free-form strings, filenames, or partially decoded tuples at public boundaries.
- [ ] Add one API conformance test proving that a caller can validate a stored snapshot without being able to mutate backend state through the same handle.
- [ ] Add one adapter test proving simulator code can use wrapper exports without importing canonical snapshot modules directly.

### 11.2 Persistence Surface Rules

Persistence methods must make artifact class explicit so callers cannot confuse canonical snapshots with wrappers or reports.

Implementation checklist:

- [ ] Provide distinct save/load operations or distinct typed handles for canonical snapshots and any future audit wrappers.
- [ ] Require API naming to reflect artifact class and reject generic methods that infer meaning from payload shape alone.
- [ ] Add tests proving that callers cannot accidentally load wrapper content through canonical snapshot APIs.
- [ ] Keep backend paths and content-addressed ids consistent across save/load operations so snapshot identity does not depend on caller-selected filenames.
- [ ] Define one canonical backend key rule for `PrepSnapshotId` and reject per-caller filename selection for canonical snapshot persistence.
- [ ] Require save operations to write canonical bytes first, re-read them through the canonical loader, and fail if the reloaded artifact produces a different `PrepSnapshotId`.
- [ ] Require load operations to recompute `PrepSnapshotId` from persisted canonical bytes and reject any mismatch with backend key, wrapper metadata, or caller-supplied handle.
- [ ] Add corruption tests proving that truncated bytes, wrapper substitution, duplicate writes under different names, and id/key mismatches fail before replay code sees the artifact.

## 12. Build Algorithm

### 12.1 Input Resolution And Witness Acquisition

Snapshot construction must happen strictly before checkpoint apply.

For one tx package or checkpoint batch:

1. Read the canonical `prev_root` from the asset-state store.
2. Resolve trusted `definition_id` for each input before the storage boundary.
3. For each input reference, resolve the terminal `asset_id`.
4. Load the `AssetLeaf` from the JMT-backed state.
5. Check that the resolved leaf matches the input `serial_id` consistency field.
6. Obtain the membership witness bytes under `prev_root` for the exact hierarchical path `{definition_id, serial_id, asset_id}`.

Reference build flow:

```mermaid
sequenceDiagram
    participant Builder as Snapshot Builder
    participant State as JMT Asset State
    participant Wit as Witness Provider

    Builder->>State: load_asset_state_root()
    State-->>Builder: prev_root
    Builder->>Builder: resolve definition_id, serial_id, asset_id
    Builder->>State: load_asset_leaf(path)
    State-->>Builder: AssetLeaf
    Builder->>Wit: load_member_wit(prev_root, path)
    Wit-->>Builder: MemberWitnessBytes
```

Reference resolver sketch:

```rust
pub fn resolve_snapshot_entry(
    prev_root: AssetStateRoot,
    input: &ResolvedSpendRef,
    state: &dyn AssetStateReader,
    witness: &dyn MemberWitnessReader,
) -> Result<PrepEntry, PrepSnapshotError> {
    let path = AssetPath {
        definition_id: input.definition_id,
        serial_id: input.serial_id,
        asset_id: input.asset_id,
    };
    let leaf = state.load_leaf(prev_root, &path)?;
    let member_wit = witness.load_member_wit(prev_root, &path)?;

    Ok(PrepEntry { path, leaf, member_wit })
}
```

Implementation checklist:

- [ ] Resolve `definition_id`, `serial_id`, and terminal `asset_id` before touching snapshot encoding so malformed or ambiguous input references fail early.
- [ ] Load `AssetLeaf` and witness bytes from canonical JMT-backed state under one validated `prev_root`, not from caches or simulator placeholder paths.
- [ ] Reject the build if any input cannot be resolved, any leaf cannot be loaded, or witness bytes cannot be fetched for the exact hierarchical path.
- [ ] Add tests for missing path metadata, wrong `serial_id`, wrong `definition_id`, and absent witness bytes as distinct reject cases.
- [ ] Forbid builders from reconstructing witness bytes from placeholder digests or inferred path rules once canonical witness acquisition exists.
- [ ] Run input-resolution in one fixed order: root load, path resolution, leaf load, witness load, then entry assembly; do not let callers interleave encoding or persistence before those steps succeed.
- [ ] Emit distinct errors for unresolved path, missing leaf, serial mismatch, missing witness, and non-canonical root source so failed builds are diagnosable and testable.
- [ ] Add a negative test where the same `asset_id` resolves under the wrong `definition_id` path and prove the builder rejects it before witness decode.
- [ ] Reject any builder path that reads report files, simulator cache rows, or filename-derived metadata before canonical state and witness sources are checked.

### 12.2 Witness Decode And Entry Validation

1. Decode the witness bytes as the canonical commitment-layer proof object, recompute the canonical terminal JMT value hash from the resolved `AssetLeaf`, and reject any witness whose carried root, path, or committed leaf hash does not match the snapshot entry.
2. Reject any duplicate `AssetPath` or any ambiguous reuse of the same `asset_id` under multiple paths.
3. Compute `PrepSnapshotId` from the canonical serialized snapshot body.
4. Persist `PrepSnapshot` together with that external content-addressed identity.

The builder must preserve deterministic entry ordering. The simplest safe first rule is to preserve the canonical tx input order after duplicate detection and successful resolution. If a snapshot covers a checkpoint batch, the builder should preserve the flattened batch input order used by later checkpoint preparation rather than introducing a secondary sort.

The builder must reject the snapshot if:

- any input cannot be resolved
- any loaded leaf mismatches the input `serial_id`
- any membership witness is empty or invalid
- any membership witness fails canonical decode into the commitment-layer proof object expected by the JMT contract
- any decoded witness carries a different `asset_state_root`, `AssetPath`, or canonical terminal leaf hash than the snapshot entry claims
- the root source is not the canonical asset-state root API
- duplicate terminal `asset_id` values appear in one snapshot
- trusted `definition_id` resolution is missing or inconsistent with the hierarchical path
- canonical snapshot id calculation depends on mutable wrapper metadata instead of canonical snapshot bytes
- canonical snapshot identity is defined recursively by hashing a payload that already embeds that same identity

Reference validation flow:

```mermaid
flowchart TD
    A[Resolved PrepEntry] --> B[Decode MemberWitnessBytes]
    B --> C[Recompute canonical AssetLeaf hash]
    C --> D[Check root and AssetPath match]
    D --> E[Check duplicate path and duplicate asset_id rules]
    E --> F[Encode canonical PrepSnapshot body]
    F --> G[Derive external PrepSnapshotId]
```

Reference validator sketch:

```rust
pub fn validate_snapshot_entry(
    prev_root: AssetStateRoot,
    entry: &PrepEntry,
) -> Result<(), PrepSnapshotError> {
    let proof = decode_asset_commit_proof(&entry.member_wit)?;
    let leaf_hash = canonical_asset_leaf_hash(&entry.leaf)?;

    if proof.asset_state_root != prev_root {
        return Err(PrepSnapshotError::RootMismatch);
    }
    if proof.path != entry.path {
        return Err(PrepSnapshotError::PathMismatch);
    }
    if proof.asset_leaf_hash != leaf_hash {
        return Err(PrepSnapshotError::LeafHashMismatch);
    }
    Ok(())
}
```

Implementation checklist:

- [ ] Decode witness bytes into one canonical commitment-layer proof object before snapshot bytes are finalized and reject any decode failure.
- [ ] Recompute the terminal leaf hash from canonical serialized `AssetLeaf` bytes and require exact agreement with the decoded proof object.
- [ ] Reject the build on root mismatch, path mismatch, leaf-hash mismatch, duplicate path, duplicate terminal-id reuse, or non-canonical snapshot id calculation.
- [ ] Add tests proving that witness bytes that decode successfully but bind the wrong root, wrong path, or wrong leaf hash are all rejected independently.
- [ ] Ensure `PrepSnapshotId` is computed only after every entry has passed validation and before wrapper metadata can be attached.
- [ ] Freeze validation order in code: decode proof, compute canonical leaf hash, compare root, compare path, then enforce duplicate rules and derive id; do not allow caller-specific reorderings.
- [ ] Add one tamper test per bound field so the suite proves independent rejection for wrong root, wrong `definition_id`, wrong `serial_id`, wrong `asset_id`, and wrong `AssetLeaf` bytes.
- [ ] Add one negative fixture where proof bytes decode successfully but correspond to a different path with the same terminal `asset_id`, proving path binding is not optional.
- [ ] Reject any code path that derives `PrepSnapshotId` before all entries have passed witness and uniqueness checks.

### 12.3 Deterministic Ordering And Output Boundary

The snapshot builder must not claim that `PrepSnapshot` alone is sufficient to re-run checkpoint apply. The checkpoint apply path still needs ordered execution input carrying outputs and tx-proof bytes.

Implementation checklist:

- [ ] Preserve canonical input order for entries and reject any builder that introduces a secondary sort not defined by this spec.
- [ ] Add tests proving that identical resolved inputs under the same root produce identical snapshot bytes and identical `PrepSnapshotId`.
- [ ] Keep output leaves, tx-proof bytes, and checkpoint deltas outside canonical snapshot bytes even if a simulator export wants them nearby.
- [ ] Add validation rules and tests proving that `PrepSnapshot` cannot be treated as a full checkpoint execution package.

## 13. Versioning Strategy

### 13.1 Snapshot Version Contract

The snapshot schema version must be separate from both JMT tree version and checkpoint height.

Recommended initial artifact type:

- `PrepSnapshot`

The version split is therefore:

- JMT tree version: state progression
- checkpoint height: chain progression
- snapshot schema version: artifact serialization progression

This avoids overloading one integer with three unrelated meanings.

Implementation checklist:

- [ ] Define snapshot version semantics explicitly and keep them separate from checkpoint height and JMT state version in both code and docs.
- [ ] Make `PrepSnapshot.version` the single source of truth for snapshot schema expectations.
- [ ] Reject any implementation that infers snapshot schema from stage names, filenames, or JMT state version.
- [ ] Add tests proving that unsupported snapshot versions fail before witness verification or replay logic begins.
- [ ] Reopen versioned codec evolution only through an explicit snapshot revision with migration tests and compatibility rules.

### 13.2 Version Compatibility Rules

Versioning must control upgrade and reject behavior, not only codec selection.

Implementation checklist:

- [ ] Define explicit behavior for older supported versions, newer unsupported versions, and malformed version tags.
- [ ] Require loaders to reject unknown versions before any witness decode, root validation, or replay processing begins.
- [ ] Add compatibility tests proving that supported-version snapshots round-trip without implicit upgrade or silent field rewriting.
- [ ] Forbid snapshot version branching logic from leaking into simulator wrappers as an alternative source of truth.
- [ ] Implement one explicit version-acceptance table mapping each supported version to its codec, validator set, and migration policy, and reject ad-hoc branching outside that table.
- [ ] Require every future version bump to land forward-reject tests, backward-support tests, and migration notes before the new codec path is accepted.
- [ ] Forbid automatic in-memory upgrades during load unless a dedicated migration API is called and emits new canonical bytes under a new version.
- [ ] Add tests proving malformed versions, unsupported future versions, and legacy snapshots missing mandatory fields all fail at the same early version gate.

## 14. Proof Model

### 14.1 Witness Verification Sequence

The snapshot itself is not a consensus proof object. It is a persisted pre-state witness package.

Its job is to carry the exact pre-state membership material needed for checkpoint application or for replay validation.

The canonical verifier-side interpretation is:

1. deserialize `PrepSnapshot`
2. verify that all entries bind to the same `prev_root`
3. decode each `member_wit` into the canonical commitment-layer proof object
4. recompute the canonical terminal JMT value hash from each resolved `AssetLeaf`
5. verify each `member_wit` against that leaf hash under the shared root and exact `AssetPath`
6. only then allow checkpoint application to proceed

This means the snapshot is proof-adjacent, but not proof-equivalent.

The snapshot is also not a complete checkpoint execution package. Outputs and tx-proof material belong to ordered execution input, not to the snapshot record.

Reference verifier sketch:

```rust
pub fn verify_prep_snapshot(
    snapshot: &PrepSnapshot,
) -> Result<(), PrepSnapshotError> {
    ensure_single_prev_root(snapshot)?;
    for entry in &snapshot.entries {
        validate_snapshot_entry(snapshot.prev_root, entry)?;
    }
    Ok(())
}
```

Implementation checklist:

- [ ] Implement one canonical verifier function whose steps follow the exact order listed here and reuse it everywhere snapshot semantics are checked.
- [ ] Add distinct reject reasons for bad witness bytes, bad root binding, bad path binding, and bad terminal leaf-hash binding.
- [ ] Add one negative test per verifier step so every failure mode is independently covered.
- [ ] Add tests proving that identical branch nodes cannot validate under a different `AssetPath` or a different `prev_root`.
- [ ] Add tests proving that semantic verification over resolved `AssetLeaf` and commitment-layer verification agree on the same terminal leaf hash.
- [ ] Freeze verifier order in code: decode snapshot, enforce single-root invariant, decode each proof, recompute each leaf hash, then compare proof bindings; do not allow shortcut verification based on cached booleans or wrapper status.
- [ ] Add one regression test proving that attaching audit wrappers or execution-input hints around the same snapshot does not alter verifier input or verifier output.
- [ ] Add one fixture where branch nodes are syntactically valid but the enclosing `AssetPath` is wrong, proving the verifier rejects path transplant attacks.
- [ ] Reject any verifier helper that accepts caller-supplied predecoded proof bindings instead of reconstructing them from the snapshot entry being verified.

### 14.2 Separation From Checkpoint Execution Input

Snapshot proof-adjacent data remains insufficient for full checkpoint re-apply because execution input carries outputs and tx-proof bytes separately.

Implementation checklist:

- [ ] Keep execution-input material out of canonical snapshot bytes and reject any codec that embeds output leaves or tx-proof bytes directly.
- [ ] Ensure snapshot verification can run without loading checkpoint execution input, while replay of full checkpoint apply still requires that extra material explicitly.
- [ ] Add tests proving that missing execution-input material does not change snapshot verification results, only full replay capability.
- [ ] Document in code and spec that snapshot verification and checkpoint application are complementary but distinct steps.
- [ ] Define separate public entry points for pure snapshot validation and full checkpoint replay so callers cannot accidentally pull execution input into snapshot verification.
- [ ] Require replay code to name the exact execution-input artifact it needs in addition to `PrepSnapshotId`, rather than discovering it from wrappers heuristically.
- [ ] Add tests proving that attaching output leaves or tx-proof bytes to audit wrappers does not alter canonical snapshot bytes, validation result, or `PrepSnapshotId`.
- [ ] Reject any API or codec that returns one mixed canonical object containing both pre-state snapshot entries and execution-input payload.

## 15. Replay And Audit Semantics

### 15.1 Snapshot Replay Semantics

`PrepSnapshot` is the pre-state replay anchor.

A local deterministic replay of pre-state resolution must be able to:

1. load `PrepSnapshot`
2. reconstruct the resolved input set from its entries
3. verify membership under `prev_root`
4. feed the result into checkpoint construction together with separate ordered execution input

`PrepSnapshot` alone is sufficient to replay input resolution, but not sufficient to replay full checkpoint apply.

Implementation checklist:

- [ ] Keep snapshot replay and full checkpoint replay as distinct APIs with distinct preconditions and error surfaces.
- [ ] Require snapshot replay tooling to reconstruct resolved input sets and verify membership under the stored `prev_root` before any checkpoint-specific work proceeds.
- [ ] Reject any replay request that tries to proceed from `PrepSnapshot` directly into full checkpoint apply without ordered execution input.
- [ ] Add tests proving that snapshot replay can succeed while full checkpoint replay intentionally fails on missing execution input.
- [ ] Add tests proving that replay output must match stored path, leaf, and witness bindings exactly or the snapshot is flagged as locally inconsistent.

### 15.2 Audit Metadata Boundary

Audit metadata such as source file names, simulator stage ids, or report links may exist in wrapper artifacts, but they must not change the canonical replay meaning of the snapshot itself.

If external artifacts such as checkpoint links refer to one snapshot, they should do so through `PrepSnapshotId` or an equivalent canonical digest. Replay-critical linkage must not rely only on mutable filenames, row numbers, or transport-local handles.

Implementation checklist:

- [ ] Keep audit metadata in separate wrappers or reports and forbid it from changing canonical snapshot bytes, ids, or replay meaning.
- [ ] Add tests proving that filenames, stage ids, and report references can change without affecting `PrepSnapshotId` or witness verification.
- [ ] Require audit tooling to consume canonical snapshots plus optional wrappers, not the other way around.
- [ ] Add review gates rejecting any future attempt to promote audit-only fields into canonical snapshot payloads without an explicit spec revision.
- [ ] Define one explicit audit-wrapper schema listing allowed non-canonical fields such as filenames, stage ids, report links, and operator notes, and reject any field that duplicates canonical snapshot meaning.
- [ ] Require all replay-critical links from wrappers or reports to point to `PrepSnapshotId` first and treat filenames or row numbers only as optional UI hints.
- [ ] Add tests proving that deleting, regenerating, or renaming audit wrappers leaves canonical snapshot loading and validation unchanged.
- [ ] Add migration rules preventing current simulator wrapper fields from being silently promoted into canonical snapshot payloads during refactors.

## 16. Migration From Current PrepFile

### 16.1 Pre-Migration Blockers

The current simulator `PrepFile` should be treated as a compatibility wrapper, not as the final storage-layer contract.

Before canonical snapshot rollout begins, the following blockers must be removed:

- the canonical snapshot artifact must move behind a dedicated storage-layer facade instead of staying simulator-local
- split transport fields such as `definition_id_hex`, `asset_id_hex`, and `serial_id` must stop standing in for one typed `AssetPath`
- path-free witness lookup and wrapper-driven linkage must stop being tolerated as the long-term public contract

Implementation checklist:

- [ ] Make these blockers explicit release blockers and fail rollout if any one remains active outside isolated migration tests.
- [ ] Add temporary assertions or feature-gated hard rejects at each blocker call site so stale flows fail loudly.
- [ ] Land one regression test per blocker proving it is gone before canonical snapshot artifacts are enabled in non-test paths.
- [ ] Record the owning files and removal tasks for every blocker so shim removal can be tracked to completion.

### 16.2 Migration Phase Order

The clean migration path is:

1. keep the current JSON artifact for simulator compatibility and debugging
2. introduce canonical `PrepSnapshot` in the storage layer
3. normalize each snapshot entry from split transport fields into one typed `AssetPath`
4. reuse the already-live storage-owned witness bytes and formalize their verifier contract in storage-facing APIs
5. keep ordered execution input separate instead of extending the snapshot into a mixed pre-state plus execution record
6. move simulator-only metadata into reports or audit wrappers if needed
7. introduce content-addressed `PrepSnapshotId` instead of using mutable file names as the long-term linkage key
8. remove path-free witness shims from public-facing snapshot boundaries once the canonical adapter path is in place

The minimum acceptance criteria are:

1. no snapshot binds membership under `tx_digest_hex`
2. no snapshot entry regresses from storage-owned witness bytes back to placeholder digests
3. no snapshot entry omits hierarchical path metadata required for membership verification
4. no snapshot entry uses `definition_id` as terminal leaf identity
5. every snapshot entry is consistent with the JMT terminal leaf contract
6. no code path treats `PrepSnapshot` as a full substitute for ordered execution input during checkpoint apply
7. no replay-critical snapshot linkage relies only on mutable filenames, row numbers, or transport-local ids
8. no canonical verifier path treats `prev_root + asset_id` alone as sufficient witness-binding context once hierarchical verification is enabled

Reference migration sequence:

```text
Phase A: Introduce PrepSnapshot and PrepEntry types with canonical codecs.
Phase B: Add AssetPath metadata and typed root/id wrappers.
Phase C: Normalize split transport fields into one typed `AssetPath` entry shape.
Phase D: Move simulator-only metadata into wrappers and make `PrepSnapshotId` content-addressed.
Phase E: Remove legacy path-free witness shims from public APIs.
```

Implementation checklist:

- [ ] Convert the numbered migration path into named phases with immutable entry criteria, scope, exit criteria, and explicit canonical versus compatibility APIs.
- [ ] Do not overlap root-source repair, witness-byte repair, and path-metadata repair unless earlier phase exit tests are already green.
- [ ] Require each phase to document expected root source, expected witness format, expected path shape, and expected linkage rule so later phases cannot regress them.
- [ ] Add one integration test suite that is rerun after every migration phase and proves both supported legacy behavior and new canonical snapshot behavior.
- [ ] Mark the migration incomplete until every minimum acceptance criterion in this section is enforced by code or tests rather than comments alone.
- [ ] Treat each phase as blocked until one unchanged fixture from the previous phase still passes through the new canonical APIs, so migration cannot regress already-closed semantics silently.
- [ ] Require each phase to name the exact legacy `PrepFile` fields that remain compatibility-only and the exact canonical snapshot fields that replace them.
- [ ] Add one migration audit table mapping every tx-digest root source, placeholder witness digest, missing-path snapshot row, and filename-based link to its removal phase and replacement API.
- [ ] Reject any migration step that adds new wrapper-only snapshot semantics instead of shrinking the wrapper surface.

### 16.3 Compatibility Shim Removal

Implementation checklist:

- [ ] Introduce every compatibility shim with an owning file, list of callers, explicit removal condition, and target removal phase.
- [ ] Forbid long-lived generic fallback paths that silently accept both legacy and canonical snapshot semantics.
- [ ] Remove path-free verification helpers and wrapper-only linkage paths before canonical snapshot validation is wired into non-test flows.
- [ ] Add tests proving that once a shim is removed, legacy callers fail loudly rather than being auto-mapped into canonical semantics.
- [ ] Close the migration only when shim inventory is empty and no legacy wrapper semantics remain reachable from public snapshot APIs.

## 17. Suggested Crate Layout

### 17.1 Module Boundary Contract

A practical first layout is:

```text
crates/z00z_storage/
├── src/
│   ├── lib.rs
│   ├── error.rs
│   ├── checkpoint/
│   │   ├── mod.rs
│   │   ├── prep.rs
│   │   ├── ids.rs
│   │   ├── codec.rs
│   │   └── store.rs
│   └── assets/
│       └── ...
```

The public facade should expose typed snapshot records, not simulator-local `PrepFile` and `PrepRow` wrappers.

Implementation checklist:

- [ ] Keep snapshot ids, codecs, stores, wrappers, and asset-hierarchy dependencies in separate modules with one source of truth per responsibility.
- [ ] Keep simulator wrapper adapters outside canonical snapshot modules so simulator concerns cannot leak into consensus-facing codecs.
- [ ] Restrict public re-exports in `lib.rs` to typed snapshot-side contracts and keep helper modules `pub(crate)` unless cross-crate adapters require them.
- [ ] Add module-level documentation stating whether each module is canonical, replay-facing, or audit-only.
- [ ] Prevent downstream crates from depending on internal snapshot modules directly when a facade or adapter API exists.

### 17.2 Dependency Direction Rules

Snapshot storage modules must depend downward on JMT/state primitives, not sideways on simulator-local wrapper code.

Implementation checklist:

- [ ] Keep simulator adapters at the outer boundary and forbid canonical snapshot modules from importing `PrepFile` or scenario wrapper types directly.
- [ ] Ensure snapshot modules depend on typed ids, roots, codecs, and JMT proof abstractions only.
- [ ] Add review checks rejecting cyclic dependencies between canonical snapshot modules and audit or scenario wrappers.
- [ ] Keep dependency direction documented so future persistent backends do not force simulator concerns into canonical modules.
- [ ] Add one dependency map in module docs showing allowed imports for canonical modules, adapters, and audit wrappers, and fail review on undocumented new edges.
- [ ] Keep proof decode, root loading, and path resolution behind storage-side traits so simulator crates consume adapters instead of internal canonical modules.
- [ ] Add workspace checks proving canonical snapshot modules can compile without simulator crates present.
- [ ] Reject helper modules that look generic but import scenario-specific constants, filenames, or wrapper structs into canonical storage code.

## 18. Minimal First Milestone

### 18.1 First Milestone Scope

The first milestone should focus on structural correctness.

Recommended scope:

1. define `PrepSnapshot` and `PrepEntry`
2. add canonical JSON and binary codecs
3. add adapter logic from resolved input tuples into `PrepSnapshot`
4. add tests proving canonical round-trip encoding
5. add tests proving `definition_id`, `asset_id`, `serial_id`, and `leaf.asset_id` cannot drift silently
6. add tests proving `prev_root` must come from the asset-state root API
7. add tests proving simulator-style wrapper artifacts are rejected until adapters normalize them into canonical snapshot entries
8. add tests proving duplicate `asset_id` entries are rejected
9. add tests proving deterministic entry order for identical resolved input sets
10. add tests proving that wrong `definition_id` causes hierarchical membership verification failure
11. add tests proving that `PrepSnapshotId` is stable across export and reload because it is computed from canonical snapshot bytes only
12. add tests proving that witness verification rejects the same `asset_id` and leaf when replayed under the wrong `definition_id` or `serial_id` path
13. add tests proving that `MemberWit.proof` and `ProofItem` stay mutually consistent and that the carried `asset_state_root` equals `PrepSnapshot.prev_root`
14. add tests proving that snapshot verification rejects witness bytes that decode successfully but carry a different `AssetPath` than the enclosing snapshot entry
15. add tests proving that snapshot verification rejects witness bytes that decode successfully but commit to a different canonical terminal leaf hash than the enclosing `PrepEntry.leaf`

Implementation checklist:

- [ ] Freeze the first milestone to canonical snapshot shape, canonical witness bytes, canonical path metadata, and structural validation only.
- [ ] Keep the first milestone independent of checkpoint finalization, persistent backend optimization, and simulator UX improvements.
- [ ] Require milestone code to expose only the minimum snapshot operations needed to create, persist, load, and validate canonical snapshots.
- [ ] Produce deterministic fixtures covering at least one valid snapshot, one wrong-root snapshot, one wrong-path witness, and one unnormalized simulator-wrapper artifact.
- [ ] Reject milestone sign-off if any required artifact, witness, root-binding, or ordering test remains missing.

### 18.2 Mandatory Test Matrix

Implementation checklist:

- [ ] Group milestone tests into explicit buckets: root consistency, path consistency, witness decode, terminal leaf-hash binding, ordering determinism, and snapshot-id stability.
- [ ] Provide at least one positive and one negative test for every bucket so each invariant is covered in both directions.
- [ ] Add golden fixtures for canonical `PrepSnapshot` bytes and canonical witness bytes so future migrations can detect codec drift.
- [ ] Add replay tests proving that the same witness bytes cannot validate under wrong root, wrong path, or wrong terminal leaf hash.
- [ ] Require CI to fail if any test bucket is skipped, filtered out, or left without negative coverage.
- [ ] Split each bucket into fixed case names, fixture inputs, expected reject reasons, and acceptance criteria so coverage cannot be claimed by overlapping generic tests.
- [ ] Require one end-to-end fixture family where the same logical input is replayed as valid, wrong-root, wrong-path, wrong-leaf-hash, duplicate-path, and placeholder-witness variants through the same builder path.
- [ ] Add one regression fixture derived from current simulator-style data and prove canonical loaders reject it until migration adapters normalize every forbidden placeholder semantic.
- [ ] Track the matrix in CI through a stable manifest so any new invariant must add both positive and negative rows before merge.

Reference test layout:

```text
tests/
    snapshot_root_binding.rs
    snapshot_path_binding.rs
    snapshot_witness_decode.rs
    snapshot_leaf_hash.rs
    snapshot_ordering.rs
    snapshot_ids.rs
    fixtures/
        snapshot_valid.json
        snapshot_wrong_root.json
        snapshot_wrong_path.json
        snapshot_wrong_leaf_hash.json
        snapshot_placeholder_witness.json
```

Reference test buckets:

```rust
#[test]
fn snapshot_prev_root_must_be_asset_state_root() {}

#[test]
fn witness_path_must_match_entry_path() {}

#[test]
fn witness_bytes_must_decode_as_asset_commit_proof() {}

#[test]
fn canonical_leaf_hash_must_match_resolved_leaf() {}

#[test]
fn entry_order_is_stable_for_identical_inputs() {}

#[test]
fn prep_snapshot_id_is_stable_across_roundtrip() {}
```

### 18.3 Milestone Exit Criteria

Implementation checklist:

- [ ] Mark the milestone complete only when all test buckets pass and no blocker from sections `5`, `10`, `12`, `14`, or `16` remains unresolved.
- [ ] Require one review pass focused only on root aliasing, placeholder-witness rejection, and path-binding soundness before acceptance.
- [ ] Document exactly which canonical snapshot artifacts the milestone produces and which simulator wrappers remain compatibility-only.
- [ ] Do not start persistent backend expansion or richer simulator integration until this exit checklist is fully checked off.
- [ ] Require a written sign-off record naming the exact commit or tag where snapshot invariants were verified, the fixtures used, and the blockers proven closed.
- [ ] Keep one explicit deferred-work list for backend optimization, richer simulator UX, and audit ergonomics so correctness completion cannot be mistaken for product completion.
- [ ] Add one final pre-merge audit proving public APIs expose only canonical snapshot operations and no placeholder-witness or tx-digest-root path remains reachable.
- [ ] Refuse milestone closure if any shim from section `16.3` still exists without a named removal phase and a failing misuse test.

## 19. Concrete Recommendation

### 19.1 Implementation Direction Contract

The correct implementation strategy is not to invent a new pre-state format from scratch.

The correct strategy is:

- promote the current simulator `PrepFile` into a typed `PrepSnapshot`
- keep the current useful field structure that already includes `prev_root_hex`, `definition_id_hex`, `asset_id_hex`, `serial_id`, `leaf`, and storage-owned witness bytes
- extend it with full hierarchical path metadata
- preserve storage-owned witness bytes while moving them behind canonical typed snapshot APIs
- bind `prev_root` to real JMT asset-state roots only
- keep audit-only metadata outside the canonical snapshot record
- keep ordered execution input outside the snapshot record

In practical terms, `PrepSnapshot` should become the typed storage-layer record that bridges:

- hierarchical JMT asset state below
- checkpoint application above

Implementation checklist:

- [ ] Use this section as the architecture guardrail for code review and reject any patch that changes canonical snapshot shape, witness semantics, and simulator UX all in one step.
- [ ] Keep the implementation sequence aligned with this recommendation: reuse useful current fields first, add canonical path metadata next, then migrate witness bytes and wrappers.
- [ ] Reject any proposal that duplicates checkpoint execution material or audit metadata into final snapshot artifacts for convenience.
- [ ] Require canonical snapshot ids before treating simulator exports as durable storage artifacts.
- [ ] Keep optimization work out of the first correctness milestone unless it is proven semantics-preserving.

### 19.2 Explicit Non-Goals

The recommended implementation direction excludes several tempting but unsafe shortcuts.

Implementation checklist:

- [ ] Do not collapse snapshot, checkpoint execution input, and checkpoint result into one canonical artifact.
- [ ] Do not infer durable snapshot identity from filenames, stage labels, or export order.
- [ ] Do not keep placeholder witness digests as a second accepted canonical witness format once the bridge is enabled.
- [ ] Do not add audit metadata to canonical snapshot payloads without an explicit spec revision and new validation tests.
- [ ] Do not add temporary fallback code that accepts path-free verification, tx-digest roots, or wrapper-derived ids in production-facing snapshot APIs.
- [ ] Do not optimize codec size or backend layout ahead of proving root binding, path binding, and leaf-hash binding under the canonical verifier.
- [ ] Do not allow simulator convenience exports to become the de facto canonical format through wider use than the typed storage APIs.
- [ ] Reject any delivery chunk that mixes correctness tasks from this spec with unrelated UX, reporting, or scenario-polish work.

## 20. Compliance And Open Questions

### 20.1 Compliance Gates

This specification is compliant with `jmt-storage-spec-gaps.md` only under the following interpretations:

1. `prev_root` is a real JMT-backed asset-state root
2. snapshot entries carry full hierarchical path metadata while preserving `asset_id` as the terminal leaf identity
3. membership witnesses are real witness bytes, even if the final aggregate-proof serialization format evolves later
4. `serial_id` remains a consistency field and not a substitute key for the terminal leaf
5. the snapshot remains a pure pre-state record and does not absorb checkpoint execution inputs
6. decoded witness material is leaf-binding, not only root-binding, because it must commit to the same canonical terminal JMT value hash as the enclosed `PrepEntry.leaf`

Implementation checklist:

- [ ] Turn every required interpretation in this section into one tracked validation rule or test before production wiring begins.
- [ ] Require code review for every consensus-affecting snapshot change to state which compliance gate it satisfies and which gates remain open.
- [ ] Fail milestone sign-off if any gate about root identity, terminal asset identity, witness bytes, or snapshot purity remains only partially addressed.
- [ ] Keep snapshot compliance checks synchronized with the JMT and checkpoint specs so weaker semantics cannot slip in through wrapper code.

### 20.2 Deferred Questions And Resolution Order

The main open questions are:

1. whether the first canonical snapshot codec should be JSON-only for debugging or dual JSON plus binary from day one
2. whether snapshot audit wrappers should live in `z00z_storage` or remain simulator-local

The following items are already fixed by this contract and should no longer be treated as open:

1. The first safe witness serialization bridge is canonical binary encoding of `AssetCommitProof` inside `MemberWit.proof`.

None of these open questions should block the main decision: the prep snapshot must be rooted in the same JMT asset-state semantics as the storage hierarchy itself.

Implementation checklist:

- [ ] Resolve the open questions in the exact order listed here and record the chosen answer in the spec before implementation begins in the affected area.
- [ ] Do not let individual developers choose locally between JSON-only and dual-codec storage or between storage-local and simulator-local audit wrappers.
- [ ] After each open question is resolved, replace it in the document with a fixed contract statement and corresponding validation tasks.
- [ ] Keep the “already fixed” list immutable unless a later explicit spec revision reopens one item with migration rules and new tests.
- [ ] Assign one decision owner, deadline, and blocked downstream task to each open question so unresolved choices cannot linger while implementation proceeds inconsistently.
- [ ] Freeze code touching an unresolved question behind one feature gate or adapter boundary until the decision is recorded here and tests are updated.
- [ ] Add follow-up tasks for each resolved question covering code changes, fixture updates, migration notes, and review scope so the answer becomes enforceable work.
- [ ] Reject any patch that informally reopens an already fixed item in wrapper code or review comments without an explicit spec amendment section.
