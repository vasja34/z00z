# 🔑 Nested JMT Refactor Plan

> [!Important]
> This document rewrites `specs/014-z00z-storage/jmt-refactor-workflow.md` into an implementation-ready task plan for the nested JMT storage refactor.
> The plan must preserve the current public storage facade in `crates/z00z_storage/src/assets/` while replacing the private flat backend with a real logical multi-tree layout.
> All technical content in this plan is English-only and aligned to the current repository state on 2026-03-20.

**📌 Proposed canonical private types and logical tree labels for this refactor:**

- `TreeId`
- `TreeRootRef`
- `PathIndexRec`
- logical `DefinitionTree`
- logical `SerialTree(definition_id)`
- logical `AssetTree(definition_id, serial_id)`
- logical `PathIndexTree`

> [!Tip]
> If implementation finds one verified existing private structure that already satisfies any of these roles, extend that structure instead of creating a duplicate under a new name.

## 🎯 Scope And Fixed Constraints

**📌 The refactor scope is limited to the asset-state storage backend and the minimum downstream adapter work required to keep wallet and simulator behavior green.**

> [!Important]
> The public semantic contract that must survive unchanged is:

- `AssetPath`
- `StoreItem`
- `ProofItem`
- `ProofBlob`
- `AssetStateRoot`
- `CheckRoot`
- `RootApi`
- `AssetStore`
- `StoreOp`

> [!Important]
> The private commit substrate is already fixed by verified codebase facts:

- use one private `TreeStore` over one shared `MemTreeStore`
- keep one shared external `Version` per transition
- use one shared JMT batch boundary for all touched logical trees
- use full in-memory rollback via `snap_store()` and `restore_store()`
- do not introduce WAL or recovery-journal logic in this refactor

> [!Caution]
> The benchmark goal is narrow and must not be generalized: the refactor only needs to prove benefit on disjoint-shard write workloads, not on every storage operation.

## 👁️‍🗨️ Verified Codebase Anchors

**📌 Verified existing files that this plan may target directly:**

- `crates/z00z_storage/src/assets/{mod.rs,store.rs,model.rs,types.rs,proof.rs,keys.rs}`
- `crates/z00z_storage/src/assets/store_internal/{tx_plan.rs,whitebox_help.rs,whitebox_crud.rs,whitebox_state.rs,whitebox_proofs.rs,whitebox_paths.rs}`
- `crates/z00z_storage/tests/{assets_suite.rs,assets/store_api.rs}`
- `crates/z00z_wallets/src/core/tx/{state_update.rs,witness_gate.rs,spending.rs,claim_tx.rs,output_flow.rs,lifecycle.rs,claim_tx_tests.rs}`
- `crates/z00z_wallets/tests/{test_tx_spent_gate.rs,test_phase24_gate.rs,test_tx_wrong_root.rs}`
- `crates/z00z_simulator/src/{claim_pkg_consumer.rs,scenario_1/stage_3.rs,scenario_1/stage_4.rs,scenario_1/stage_6.rs}`
- `crates/z00z_simulator/tests/test_claim_tx_pipeline.rs`
- `crates/z00z_core/src/genesis/genesis_config_devnet_small.yaml`

> [!Note]
> Verified files that were created during implementation:

- `crates/z00z_storage/benches/assets_shard.rs`
- `crates/z00z_storage/benches/common/fixture.rs`
- `crates/z00z_storage/outputs/assets/jmt-refactor-baseline.md`
- `crates/z00z_storage/outputs/assets/jmt-refactor-bench.md`
- `crates/z00z_storage/src/assets/store_internal/{tree_id.rs,tree_store.rs}`

> [!Note]
> Remaining proposed files that still do not exist:

- `crates/z00z_storage/src/assets/store_internal/{tree_batch.rs,tx_coord.rs}`

```mermaid
flowchart TD
    A[Phase 1 Contract Freeze] --> B[Phase 2 Topology Design]
    B --> C[Phase 3 Coordinator]
    C --> D[Phase 4 AssetStore Rewire]
    D --> E[Phase 5 Proof Rewire]
    E --> F[Phase 6 Downstream Stabilization]
    F --> G[Phase 7 Benchmarks]
    G --> H[Phase 8 Acceptance And Cleanup]
```

## ⚙️ Phase 1. Freeze Contract And Baseline

### 🔑 1.1 Freeze The Public Storage Contract

**📌 Required behavior:**

- freeze the existing public storage facade before any backend topology rewrite begins
- record the exact semantic-versus-physical gap: semantic hierarchy exists, literal child-tree topology does not
- keep downstream wallet and simulator traits unchanged throughout the refactor

**📌 Canonical API surface that must remain stable:**

- `put_item(&mut self, item: StoreItem) -> Result<AssetStateRoot, AssetStoreError>`
- `get_item(&self, path: &AssetPath) -> Result<Option<StoreItem>, AssetStoreError>`
- `del_item(&mut self, path: &AssetPath) -> Result<AssetStateRoot, AssetStoreError>`
- `proof_item(&self, path: &AssetPath) -> Result<ProofItem, AssetStoreError>`
- `apply_ops(&mut self, ops: Vec<StoreOp>) -> Result<AssetStateRoot, AssetStoreError>`
- `root(&self) -> Result<AssetStateRoot, AssetStoreError>`

**📌 Target files:**

- `specs/014-z00z-storage/jmt-refactor-workflow.md`
- `crates/z00z_storage/src/assets/{mod.rs,store.rs,types.rs}`
- `crates/z00z_storage/README.md`
- `crates/z00z_wallets/src/core/tx/{state_update.rs,witness_gate.rs,spending.rs,claim_tx.rs}`
- `crates/z00z_simulator/src/{claim_pkg_consumer.rs,scenario_1/stage_4.rs,scenario_1/stage_6.rs}`

**📌 Acceptance conditions:**

- the stable public type set is written explicitly into the plan and README-facing notes
- no phase after Phase 1 is allowed to widen public wallet or simulator traits
- no private `jmt` type is allowed to escape `z00z_storage`

**✔️ Implementation Checklist:**

- [x] Write one mismatch summary that states the current backend is semantically hierarchical but physically still one namespaced JMT.
- [x] Freeze the public API list from `crates/z00z_storage/src/assets/mod.rs` and `crates/z00z_storage/src/assets/store.rs`.
- [x] Freeze the downstream trait consumers in `crates/z00z_wallets/src/core/tx/{state_update.rs,witness_gate.rs,spending.rs,claim_tx.rs}`.
- [x] Freeze the simulator-facing storage anchors in `crates/z00z_simulator/src/{claim_pkg_consumer.rs,scenario_1/stage_4.rs,scenario_1/stage_6.rs}`.
- [x] Record that `output_flow.rs`, `lifecycle.rs`, `claim_tx_tests.rs`, and `stage_3.rs` are verified secondary anchors, not initial phase-entry files.
- [x] Record the public no-go rules: no public API widening, no vendored Tari edits, no raw `jmt` exposure outside `z00z_storage`.

### ⏰ 1.2 Capture The Pre-Refactor Correctness And Benchmark Baseline

**📌 Required behavior:**

- capture the last green correctness gates before backend changes
- add only the minimal benchmark harness needed to persist the current single-JMT baseline
- do not modify storage topology files in this unit

**📌 Target files:**

- `crates/z00z_storage/Cargo.toml`
- `crates/z00z_storage/benches/assets_shard.rs`
- `crates/z00z_storage/benches/common/fixture.rs`
- `crates/z00z_storage/outputs/assets/jmt-refactor-baseline.md`

**📌 Acceptance conditions:**

- correctness gates are recorded before topology changes begin
- `current_single_jmt` baseline exists or the phase is not green
- benchmark files are still marked as proposed until created

**✔️ Implementation Checklist:**

- [x] `cargo check -p z00z_storage`
- [x] `cargo test -p z00z_storage --test assets_suite`
- [x] `cargo check -p z00z_wallets`
- [x] `cargo test -p z00z_wallets --features test-fast --features wallet_debug_dump --test test_tx_spent_gate`
- [x] `cargo test -p z00z_wallets --features test-fast --features wallet_debug_dump --test test_phase24_gate`
- [x] `cargo test -p z00z_wallets --features test-fast --features wallet_debug_dump --test test_tx_wrong_root`
- [x] `cargo check -p z00z_simulator`
- [x] `cargo test -p z00z_simulator --features test-fast --features wallet_debug_dump --test test_claim_tx_pipeline`
- [x] Add `criterion` to `crates/z00z_storage/Cargo.toml` only when the benchmark harness is actually introduced.
- [x] Create `crates/z00z_storage/benches/assets_shard.rs` with one minimal mode for `current_single_jmt` only.
- [x] Create `crates/z00z_storage/benches/common/fixture.rs` only if the benchmark setup cannot remain in a single bench file cleanly. The Phase 1 baseline stayed minimal, and the extracted fixture module was introduced later in Phase 7 for the full matrix.
- [x] Run `cargo bench -p z00z_storage --bench assets_shard -- --save-baseline current_single_jmt` after the harness exists.
- [x] Persist the baseline summary in `crates/z00z_storage/outputs/assets/jmt-refactor-baseline.md`.
- [x] Do not edit `store.rs`, `model.rs`, `proof.rs`, or `store_internal/` in this H3 unit.

## ⚙️ Phase 2. Design The Private Multi-Tree Topology

### 🔑 2.1 Define Tree Identity, Namespace Routing, And Parent Encoding

**📌 Required behavior:**

- define the private logical tree set and its physical namespace routing
- preserve existing public semantic parent records
- keep tree identity and namespace bytes private to storage

**📌 Proposed canonical private types and logical tree labels for this phase:**

- `TreeId`
- `TreeRootRef`
- `PathIndexRec`
- logical `DefinitionTree`
- logical `SerialTree(definition_id)`
- logical `AssetTree(definition_id, serial_id)`
- logical `PathIndexTree`

**📌 Target files:**

- `crates/z00z_storage/src/assets/store_internal/tx_plan.rs`
- `crates/z00z_storage/src/assets/{keys.rs,types.rs,store.rs}`
- `crates/z00z_storage/src/assets/store_internal/{tree_id.rs,tree_store.rs}`

**📌 Invariants:**

- no two logical trees may collide physically
- `DefinitionRootLeaf` and `SerialRootLeaf` remain the public semantic parent records
- namespace derivation must be deterministic and domain-separated

**📌 Acceptance conditions:**

- tree identity and namespace routing are documented with one canonical rule
- all parent-leaf encoding rules are fixed before coordinator work starts

**📌 Fixed canonical rule for Phase 2:**

- `TreeId` stays storage-private in `store_internal/tree_id.rs`
- logical trees map to one shared physical `MemTreeStore` through deterministic domain-separated namespace bytes
- `DefinitionTree` => `0x01`
- `SerialTree(definition_id)` => `0x02 || definition_id.as_bytes()`
- `AssetTree(definition_id, serial_id)` => `0x03 || definition_id.as_bytes() || serial_id.to_le_bytes()`
- `PathIndexTree` => `0x04`
- public key derivation remains unchanged and continues to flow through `def_key`, `ser_key`, and `asset_key`
- child-tree roots are wrapped privately as `TreeRootRef` and embedded back into the existing public parent leaves without changing `DefinitionRootLeaf` or `SerialRootLeaf`
- `PathIndexRec` is storage-internal only and must not affect consensus-visible semantics or exported root meaning

**✔️ Implementation Checklist:**

- [x] Define `TreeId` and document the exact mapping from logical tree kind to physical namespace.
- [x] Reuse `def_key`, `ser_key`, and `asset_key` as the canonical public key-derivation entry points.
- [x] Define how `DefinitionTree`, `SerialTree`, `AssetTree`, and `PathIndexTree` derive unique private namespace bytes.
- [x] Define how child-tree roots are embedded into `SerialRootLeaf` and `DefinitionRootLeaf` without changing public types.
- [x] Decide whether `TreeId` and namespace helpers stay inside `tx_plan.rs` or move into proposed `tree_id.rs`.
- [x] Mark every new private helper file as proposed until code creation proves it is needed. `tree_id.rs` and `tree_store.rs` are now created; `tree_batch.rs` and `tx_coord.rs` remain proposed only.
- [x] Add one written rule that `PathIndexTree` is storage-internal only and must not affect consensus-visible semantics.

### ⚙️ 2.2 Fix The Shared-Store Commit Substrate

**📌 Required behavior:**

- preserve one shared external version and one shared commit boundary
- formalize the already-verified rollback discipline
- keep durable crash recovery out of scope

**📌 Target files:**

- `crates/z00z_storage/src/assets/store_internal/tx_plan.rs`
- `crates/z00z_storage/src/assets/store.rs`
- `crates/z00z_storage/src/assets/store_internal/tree_store.rs`
- proposed `crates/z00z_storage/src/assets/store_internal/{tx_coord.rs,tree_batch.rs}`

**📌 Acceptance conditions:**

- no per-tree partial commit path remains allowed
- no WAL or recovery journal work is scheduled in this refactor
- one explicit full-store rollback rule exists for every failed transition

**📌 Fixed substrate rule for Phase 2:**

- one shared external `Version` remains the only commit boundary
- `TreeStore` is the private namespace multiplexer over the shared `MemTreeStore`
- Phase 2 deliberately keeps the existing private `TxPlan` plus `commit_plan()` as the only effective coordinator, so a separate `TxCoord` file stays deferred until Phase 3
- rollback remains allowed only via full-store `snap_store()` and `restore_store()` around the shared commit attempt
- per-tree independent durable transactions are rejected explicitly
- WAL and recovery-journal logic remain out of scope until a persistent backend exists

**✔️ Implementation Checklist:**

- [x] Write the fixed substrate decision into the plan section that governs coordinator work.
- [x] Reuse the verified facts from `commit_plan()`, `commit_all()`, `snap_store()`, and `restore_store()` as the only allowed rollback basis.
- [x] Define proposed `TreeStore` as a private multiplexer over one shared `MemTreeStore`, unless an existing private structure can absorb that role cleanly.
- [x] Define proposed `TxCoord` as the only owner of the final shared commit step, unless an existing private coordinator can be extended without duplicating responsibilities. Phase 2 keeps that role in the existing private `TxPlan` path and defers explicit extraction to Phase 3.
- [x] Reject per-tree independent durable transactions explicitly.
- [x] Reject WAL and recovery-journal logic explicitly.
- [x] State that durable crash recovery stays deferred until a persistent backend exists.

## ⚙️ Phase 3. Build The Atomic Coordinator Path

### 🚨 3.1 Build Serialized Pre-Validation And Shard Planning

**📌 Required behavior:**

- reject malformed or conflicting inputs before any shard split starts
- preserve deterministic shard grouping by `(definition_id, serial_id)`
- keep path and terminal-id conflicts impossible to commit

**📌 Target files:**

- `crates/z00z_storage/src/assets/store_internal/tx_plan.rs`
- `crates/z00z_storage/src/assets/store.rs`

**📌 Rejection rules:**

- reject duplicate canonical `AssetPath`
- reject duplicate terminal `AssetId` binding
- reject path-leaf mismatch
- reject malformed path inputs before staging any child-tree batch

**📌 Acceptance conditions:**

- one serialized pre-pass exists and runs before any parallel shard work
- all duplicate-path and duplicate-id conflicts fail before commit staging begins

**✔️ Implementation Checklist:**

- [x] Replace the flat planning shape with proposed `ShardPlan` plus proposed `TreeBatch` planning, unless an existing private planning structure can be extended to carry the same roles.
- [x] Add one serialized validation pass before shard splitting.
- [x] Validate canonical `AssetPath` uniqueness inside one transition.
- [x] Validate terminal `AssetId` binding uniqueness inside one transition.
- [x] Validate path-leaf agreement before any tree-local batch is built.
- [x] Group valid operations by `(definition_id, serial_id)` only after the serialized pre-pass succeeds.
- [x] Keep the staged plan deterministic so the same input order yields the same shard grouping.

### ⚙️ 3.2 Build The Shared-Version Commit Path

**📌 Required behavior:**

- stage child-tree writes in memory first
- compute parent roots bottom-up in canonical order
- assemble one final shared commit only after all local batches succeed

**📌 Canonical write flow:**

1. build staged `AssetTree` batches
2. derive staged `SerialTree` batches from asset roots
3. derive staged `DefinitionTree` batch from serial roots
4. build staged `PathIndexTree` updates
5. commit all touched trees through one `TxCoord` call

**📌 Target files:**

- `crates/z00z_storage/src/assets/store_internal/tx_plan.rs`
- `crates/z00z_storage/src/assets/store.rs`
- proposed `crates/z00z_storage/src/assets/store_internal/{tree_batch.rs,tx_coord.rs}`

```mermaid
sequenceDiagram
    participant Ops as StoreOp Batch
    participant Plan as ShardPlan
    participant Asset as AssetTree Batches
    participant Serial as SerialTree Batches
    participant Def as DefinitionTree Batch
    participant Path as PathIndexTree Batch
    participant Coord as TxCoord
    Ops->>Plan: validate and shard
    Plan->>Asset: build staged batches
    Asset->>Serial: derive parent roots
    Serial->>Def: derive top-level roots
    Plan->>Path: stage path-index updates
    Def->>Coord: assemble final transition
    Path->>Coord: assemble final transition
    Coord->>Coord: one shared commit or full rollback
```

**📌 Acceptance conditions:**

- no child-tree batch can become externally visible before final commit
- rollback clears parent roots and helper-index state after injected failure
- worker scheduling cannot change the final external root

**✔️ Implementation Checklist:**

- [x] Build asset-tree batches first and keep them staged only.
- [x] Sort asset outputs by canonical `(definition_id, serial_id, asset_id)` before parent derivation.
- [x] Build serial-tree parent updates without mutating visible store state.
- [x] Sort serial outputs by canonical `definition_id` then `serial_id` before definition derivation.
- [x] Build definition-tree updates without mutating visible store state.
- [x] Build path-index updates inside the same staged transition.
- [x] Assemble one final proposed `TxCoord` commit call for all touched trees, or extend an equivalent verified private coordinator if one is discovered during implementation.
- [x] Reuse full-store snapshot and restore for rollback.
- [x] Add injected-failure tests for child-tree failure before final commit.
- [x] Add determinism tests proving identical roots under different worker scheduling.
- [x] Keep final commit serialized even if child-tree batch building is parallelized.

## ⚙️ Phase 4. Rewire AssetStore To The New Backend

### ⚙️ 4.1 Rewire Reads, Writes, Deletes, And Root Tracking

**📌 Required behavior:**

- rewire all storage operations to routed child-tree access
- preserve current public method signatures
- preserve wrong-path and serial-mismatch rejection behavior

**📌 Target files:**

- `crates/z00z_storage/src/assets/{store.rs,model.rs,types.rs,keys.rs}`
- proposed private topology files chosen in Phase 2

**📌 Reuse rules:**

- keep `AssetModel` as the reference oracle during the backend swap
- keep `resolve_path` semantics routed through the private path index
- keep public facade exports in `mod.rs` and `lib.rs` unchanged

**📌 Acceptance conditions:**

- `AssetStore` is backed by logical child trees, not one flat physical namespace
- the external `AssetStateRoot` remains deterministic and source-compatible

**✔️ Implementation Checklist:**

- [x] Route `get_item()` into `AssetTree(definition_id, serial_id)` lookups.
- [x] Route `put_item()` and `del_item()` through the staged coordinator path.
- [x] Replace single `flat_root`-only logic with private per-tree root tracking plus one external `AssetStateRoot`.
- [x] Preserve private path-index lookup for terminal-id driven resolution.
- [x] Preserve wrong-path rejection semantics.
- [x] Preserve serial-mismatch rejection semantics.
- [x] Keep public signatures in `store.rs` unchanged.
- [x] Keep `mod.rs` and `lib.rs` re-exports stable.
- [x] Run full `cargo test -p z00z_storage` after the swap.

### ✅ 4.2 Re-Prove Store Parity Against AssetModel

**📌 Required behavior:**

- storage rewrite is only accepted if the concrete backend still matches `AssetModel`
- parity must cover roots, deletes, and path-sensitive lookups

**📌 Target files:**

- `crates/z00z_storage/src/assets/{model.rs,store.rs}`
- `crates/z00z_storage/src/assets/store_internal/{whitebox_crud.rs,whitebox_state.rs,whitebox_paths.rs}`
- `crates/z00z_storage/tests/assets_suite.rs`

**📌 Acceptance conditions:**

- parity tests stay green for insert, delete, rollback, and deterministic root behavior

**✔️ Implementation Checklist:**

- [x] Re-run existing parity-oriented storage tests against the new backend.
- [x] Add parity cases if child-tree routing introduces new failure modes not covered by the flat backend tests.
- [x] Keep `AssetModel` as the acceptance oracle until the entire storage test suite is green.
- [x] Reject the phase if any new backend logic can only be justified without `AssetModel` parity.

## ⚙️ Phase 5. Rewire Proof Production

### ⚙️ 5.1 Rebuild proof_item() On Real Child Trees

**📌 Required behavior:**

- `proof_item()` must source proof layers from the real child-tree layout
- `ProofItem` semantic shape must remain unchanged

**📌 Target files:**

- `crates/z00z_storage/src/assets/{proof.rs,store.rs,types.rs}`
- `crates/z00z_storage/src/assets/store_internal/whitebox_proofs.rs`

**📌 Canonical proof layers:**

- terminal asset proof from `AssetTree(definition_id, serial_id)`
- serial proof from `SerialTree(definition_id)`
- definition proof from `DefinitionTree`

**📌 Acceptance conditions:**

- `ProofItem` still agrees with `AssetModel::proof_case`
- proof sourcing no longer depends on flat aggregate reconstruction

**✔️ Implementation Checklist:**

- [x] Freeze the current `ProofItem` shape before rewriting proof sourcing.
- [x] Route terminal proof loading to `AssetTree(definition_id, serial_id)`.
- [x] Route serial proof loading to `SerialTree(definition_id)`.
- [x] Route definition proof loading to `DefinitionTree`.
- [x] Preserve storage ownership of proof-building logic inside `z00z_storage`.
- [x] Re-run and extend `whitebox_proofs.rs` coverage.

### 🔑 5.2 Rebuild proof_blob() And The Witness Codec

**📌 Required behavior:**

- `proof_blob()` must encode the physical three-layer proof plus terminal leaf hash
- wallet-facing proof bytes must remain source-compatible
- witness codec ownership must remain storage-side

**📌 Target files:**

- `crates/z00z_storage/src/assets/{proof.rs,store.rs,types.rs}`
- `crates/z00z_storage/tests/assets/store_api.rs`

**📌 Acceptance conditions:**

- round-trip tests remain green
- replay rejection remains green for wrong root, wrong path, wrong leaf hash, and wrong upper-level root leaf

**✔️ Implementation Checklist:**

- [x] Rewrite `proof_blob()` to encode child-tree proof layers from the concrete backend.
- [x] Keep the witness codec private to `z00z_storage`.
- [x] Re-run round-trip proof blob tests in `crates/z00z_storage/tests/assets/store_api.rs`.
- [x] Add replay rejection cases for wrong root.
- [x] Add replay rejection cases for wrong path.
- [x] Add replay rejection cases for wrong leaf hash.
- [x] Add replay rejection cases for wrong upper-level root leaf.
- [x] Run `cargo test -p z00z_storage --release` after the proof rewrite.

## ⚙️ Phase 6. Stabilize Downstream Adapters

### ✅ 6.1 Stabilize Wallet Typed-Root And Proof Consumers

**📌 Required behavior:**

- keep wallet trait signatures unchanged
- keep storage membership-witness decoding owned by storage output format
- preserve reject-class precision in claim verification

**📌 Target files:**

- `crates/z00z_wallets/src/core/tx/{state_update.rs,witness_gate.rs,spending.rs,claim_tx.rs,claim_tx_tests.rs}`
- `crates/z00z_wallets/tests/{test_tx_spent_gate.rs,test_phase24_gate.rs,test_tx_wrong_root.rs}`

**📌 Invariants:**

- no wallet code reconstructs `definition_id` heuristically
- `CheckRoot` only comes from storage-owned root conversion
- storage witness decode failures keep the existing wallet error taxonomy
- claim-proof decode failures keep the existing claim error taxonomy

**📌 Acceptance conditions:**

- targeted wallet gates pass without public trait changes
- claim verification still reports proof and fee failures before digest-mismatch fallback

**✔️ Implementation Checklist:**

- [x] Reconfirm that `state_update.rs` trait signatures remain unchanged.
- [x] Reconfirm that `state_update.rs` still sources membership witnesses through `MemberIdx::get_wit()` under storage-owned `CheckRoot`.
- [x] Reconfirm that `witness_gate.rs` still binds typed `CheckRoot` plus canonical leaf-derived input refs without reconstructing storage namespaces.
- [x] Reconfirm that `claim_tx.rs` remains on canonical claim-proof bytes and therefore stays isolated from storage witness-format changes.
- [x] Reconfirm that proof decode failures still map into the existing wallet error classes.
- [x] Re-run `claim_tx_tests.rs` reject-class coverage.
- [x] Run `cargo check -p z00z_wallets`.
- [x] `cargo test -p z00z_wallets --features test-fast --features wallet_debug_dump --test test_tx_spent_gate`
- [x] `cargo test -p z00z_wallets --features test-fast --features wallet_debug_dump --test test_phase24_gate`
- [x] `cargo test -p z00z_wallets --features test-fast --features wallet_debug_dump --test test_tx_wrong_root`

### ✅ 6.2 Stabilize Simulator Claim And Checkpoint Flows

**📌 Required behavior:**

- keep simulator code on the public `z00z_storage::assets` facade
- preserve typed-root checkpoint behavior
- keep storage-owned proof bytes and path resolution boundaries intact

**📌 Target files:**

- `crates/z00z_simulator/src/{claim_pkg_consumer.rs,scenario_1/stage_3.rs,scenario_1/stage_4.rs,scenario_1/stage_6.rs}`
- `crates/z00z_simulator/tests/test_claim_tx_pipeline.rs`

**📌 Acceptance conditions:**

- targeted simulator claim pipeline remains green
- no simulator path manufactures `CheckRoot` from arbitrary raw bytes

**✔️ Implementation Checklist:**

- [x] Verify that simulator code still imports only the public `z00z_storage::assets` facade.
- [x] Verify that Stage-4 and Stage-6 flows continue to consume typed roots from storage-owned helpers.
- [x] Verify that simulator fixtures do not reconstruct missing `definition_id` outside storage.
- [x] Verify that simulator fixtures consume storage-owned proof bytes.
- [x] Run `cargo check -p z00z_simulator`.
- [x] Run `cargo test -p z00z_simulator --features test-fast --features wallet_debug_dump --test test_claim_tx_pipeline`.

## ⚙️ Phase 7. Build And Evaluate The Benchmark Harness

### ⚙️ 7.1 Build The Full Comparison Harness

**📌 Required behavior:**

- extend the Phase 1 minimal harness into the full comparison matrix
- use deterministic fixture generation from the checked-in devnet-small genesis config
- expose explicit benchmark modes for `current_single_jmt`, `nested_jmt_serial`, and `nested_jmt_parallel`

**📌 Target files:**

- `crates/z00z_storage/Cargo.toml`
- `crates/z00z_storage/benches/assets_shard.rs`
- `crates/z00z_storage/benches/common/fixture.rs`

**📌 Benchmark matrix:**

- insert on many distinct `definition_id`
- insert on one `definition_id` across many `serial_id`
- delete on many distinct `definition_id`
- update on disjoint serial buckets
- read and proof lookup by `AssetPath`
- helper-index resolution by `asset_id` plus `serial_id`

**📌 Acceptance conditions:**

- the harness uses `criterion::black_box`
- the harness exposes explicit mode selectors
- the harness remains deterministic from the checked-in genesis config

**✔️ Implementation Checklist:**

- [x] Extend the minimal harness into full fixture generation from `crates/z00z_core/src/genesis/genesis_config_devnet_small.yaml`.
- [x] Add explicit mode selection for `current_single_jmt`, `nested_jmt_serial`, and `nested_jmt_parallel`.
- [x] Separate benchmark groups by operation family.
- [x] Use `criterion::black_box` in all measured hot paths.
- [x] Keep generated path sets deterministic and reproducible.
- [x] Measure only disjoint-shard parallel transitions after Phase 3 atomicity is already proven.

### ✅ 7.2 Decide The Performance Claim

**📌 Required behavior:**

- compare the nested backend only against the stored `current_single_jmt` baseline
- distinguish disjoint-shard write workloads from non-shardable workloads
- produce one explicit decision on the shard-performance claim

**📌 Target files:**

- `crates/z00z_storage/outputs/assets/jmt-refactor-baseline.md`
- `crates/z00z_storage/outputs/assets/jmt-refactor-bench.md`

**📌 Acceptance conditions:**

- Phase 8 cannot be green without an explicit benchmark conclusion
- the performance goal is confirmed only if `nested_jmt_parallel` wins on at least one disjoint-shard write workload while correctness gates remain green
- if no such workload wins, the result must be labeled as a blocker or rejected expectation

**✔️ Implementation Checklist:**

- [x] Reuse the stored `current_single_jmt` baseline instead of inferring historical numbers.
- [x] Run and store `nested_jmt_serial` after explicit mode selection exists.
- [x] Run and store `nested_jmt_parallel` after explicit mode selection exists.
- [x] Compare disjoint-shard write workloads separately from non-shardable operations.
- [x] Publish one explicit conclusion in `crates/z00z_storage/outputs/assets/jmt-refactor-bench.md`.
- [x] Reject any generic “overall faster” claim that is not supported by the benchmark matrix.
- [x] Mark the performance goal blocked if `nested_jmt_parallel` does not beat `current_single_jmt` on any disjoint-shard write workload.

## ⚙️ Phase 8. Final Acceptance, Cleanup, And Drift Lock

### ✅ 8.1 Re-Run Final Acceptance In The Only Allowed Order

**📌 Required behavior:**

- re-run storage, downstream, release-wide, and benchmark gates in one deterministic order
- do not mark the phase green from targeted tests alone

**📌 Required command order:**

1. `cargo check -p z00z_storage`
2. `cargo test -p z00z_storage --release`
3. `cargo check -p z00z_wallets`
4. `cargo test -p z00z_wallets --release --features test-fast --features wallet_debug_dump --test test_tx_spent_gate`
5. `cargo test -p z00z_wallets --release --features test-fast --features wallet_debug_dump --test test_phase24_gate`
6. `cargo test -p z00z_wallets --release --features test-fast --features wallet_debug_dump --test test_tx_wrong_root`
7. `cargo check -p z00z_simulator`
8. `cargo test -p z00z_simulator --release --features test-fast --features wallet_debug_dump --test test_claim_tx_pipeline`
9. `cargo test --release --features test-fast --features wallet_debug_dump`
10. benchmark acceptance steps owned by Phase 7

**📌 Acceptance conditions:**

- Boundary E requires the release gate to be green and the benchmark gate to be re-run with an explicit shard-performance conclusion
- a blocked benchmark verdict must prevent any claim that the shard-performance goal is complete
- benchmark acceptance is incomplete without an explicit shard-performance conclusion

**⚠️ Current accepted status:**

- release and downstream gates re-ran green in the required order on `2026-03-20`
- Phase 7 benchmark acceptance was re-run with explicit serial and parallel modes
- the shard-performance claim remains blocked by the published benchmark report, so the Phase 8 acceptance record is complete but the refactor-level speedup goal remains explicitly blocked

**✔️ Implementation Checklist:**

- [x] Re-run the storage compile and release test gates.
- [x] Re-run downstream compile gates for wallet and simulator.
- [x] Re-run the targeted wallet gates in the documented order.
- [x] Re-run the targeted simulator gate.
- [x] Re-run the final release-wide gate.
- [x] Re-run Phase 7 benchmark acceptance after explicit mode selection exists.
- [x] Reject the phase if only the baseline capture was re-run.
- [x] Reject the phase if benchmark numbers were published without an explicit conclusion.

### ♨️ 8.2 Clean Up Private Scaffolding And Lock Document Drift

**📌 Required behavior:**

- remove only private transitional scaffolding that is no longer needed
- update adjacent docs so accepted architecture, stop rules, and benchmark semantics stay aligned
- prevent drift between workflow and plan artifacts

**📌 Target files:**

- `crates/z00z_storage/src/assets/README.md`
- `specs/014-z00z-storage/{jmt-refactor-workflow.md,jmt-refactor-plan.md,jmt-migration-plan.md}`
- any proposed private helper file that became obsolete during implementation

**📌 Acceptance conditions:**

- README and plan docs describe the same accepted architecture
- no stale transitional private file remains without justification
- no document still implies that raw benchmark numbers alone close the performance goal

**📌 Cleanup result:**

- `tree_id.rs` and `tree_store.rs` are retained because they are active private topology files
- proposed `tree_batch.rs` and `tx_coord.rs` were never created, so no private-file deletion was required
- the accepted benchmark outcome is an explicit blocker, not a silent or ambiguous performance claim

**✔️ Implementation Checklist:**

- [x] Update `crates/z00z_storage/src/assets/README.md` to reflect the accepted child-tree architecture.
- [x] Update `specs/014-z00z-storage/jmt-refactor-workflow.md` if implementation forced any verified change in file ownership, gate order, or stop rules.
- [x] Update `specs/014-z00z-storage/jmt-migration-plan.md` if implementation forced any verified change in benchmark acceptance wording or substrate wording.
- [x] Keep `specs/014-z00z-storage/jmt-refactor-plan.md` aligned with the accepted final behavior.
- [x] Remove only private helper files that are demonstrably obsolete after implementation.
- [x] Reject cleanup if any document still leaves the benchmark decision ambiguous.
- [x] Reject cleanup if any document reopens the already-closed shared-store `TreeStore` substrate decision.

## 🚨 Stop Rules And Remaining Ambiguity

> [!Warning]
> Stop immediately if any of the following becomes true:

- one shared external version cannot be preserved across all touched trees
- parent roots can commit after failed child-tree writes
- wallet or simulator code requires a public API change to remain green
- proof bytes cannot remain storage-owned inside `z00z_storage`
- benchmark execution cannot produce an explicit conclusion for the shard-performance claim

> [!Important]
> If the benchmark report concludes that `nested_jmt_parallel` does not beat `current_single_jmt` on any disjoint-shard write workload, do not stop the documentation lock. Record that outcome explicitly as a blocker and do not claim the shard-performance goal is complete.
> [!Note]
> Remaining material ambiguity is intentionally limited to these explicitly labeled items:

- durable crash recovery remains deferred until a persistent backend exists
- optional extraction of `tree_batch.rs` and `tx_coord.rs` remains deferred unless the existing `tx_plan.rs` coordinator path stops being the single clear owner of staged commit assembly

> [!Tip]
> Assumption used by this plan:

- the safest path is to extend `store.rs`, `store_internal/`, and the existing `AssetModel` parity route before introducing any extra private modules

---

## 👁️‍🗨️ Implemented Hierarchical JMT Layout

📌 The diagram below shows the logical hierarchical JMT layout as it is implemented in code today.

📌 One shared physical `MemTreeStore` holds all nodes, while private namespace routing splits the data into logical child trees.

📌 `DefinitionTree` is the top logical tree, each `SerialTree(definition_id)` stores serial-root leaves for one definition, each `AssetTree(definition_id, serial_id)` stores terminal `AssetLeaf` values for one shard, and `PathIndexTree` stores the storage-internal terminal-id to canonical-path index.

📌 The staged write path is bottom-up: asset-tree batches are built first, serial-tree parent leaves are derived from staged asset roots, definition-tree parent leaves are derived from staged serial roots, path-index updates are staged alongside them, and one final shared commit writes all touched logical trees through the same external version boundary.

```mermaid
flowchart TD
    subgraph Phys["Shared Physical Store"]
        M["MemTreeStore"]
    end

    subgraph Top["Top Logical Tree"]
        D["DefinitionTree"]
    end

    subgraph MidA["Definition Namespace A"]
        SA["SerialTree(definition_id A)"]
        AA1["AssetTree(definition_id A, serial_id 1)"]
        AA2["AssetTree(definition_id A, serial_id 2)"]
    end

    subgraph MidB["Definition Namespace B"]
        SB["SerialTree(definition_id B)"]
        AB1["AssetTree(definition_id B, serial_id 1)"]
    end

    subgraph Side["Side Index"]
        P["PathIndexTree"]
    end

    D -->|"DefinitionRootLeaf binds child root"| SA
    D -->|"DefinitionRootLeaf binds child root"| SB

    SA -->|"SerialRootLeaf binds child root"| AA1
    SA -->|"SerialRootLeaf binds child root"| AA2
    SB -->|"SerialRootLeaf binds child root"| AB1

    AA1 -->|"terminal values"| LA1["AssetLeaf"]
    AA2 -->|"terminal values"| LA2["AssetLeaf"]
    AB1 -->|"terminal values"| LB1["AssetLeaf"]

    P -->|"asset_id -> AssetPath"| IDX["Canonical path record"]

    M -. "namespace routed" .-> D
    M -. "namespace routed" .-> SA
    M -. "namespace routed" .-> SB
    M -. "namespace routed" .-> AA1
    M -. "namespace routed" .-> AA2
    M -. "namespace routed" .-> AB1
    M -. "namespace routed" .-> P

    AA1 -. "staged asset batches" .-> SA
    AA2 -. "staged asset batches" .-> SA
    AB1 -. "staged asset batches" .-> SB
    SA -. "staged serial batches" .-> D
    SB -. "staged serial batches" .-> D
    P -. "staged in same transition" .-> D
```

1
