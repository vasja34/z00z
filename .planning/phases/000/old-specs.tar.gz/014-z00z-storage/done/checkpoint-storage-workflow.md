# Checkpoint Storage Workflow

[TOC]

**📌 This workflow defines the execution order for turning the current checkpoint storage specification into one executable implementation path grounded in the current wallet checkpoint types and the current simulator Stage 6 wrapper flow.**

**🎯 The goal is to introduce one canonical checkpoint storage contract above the asset JMT layer without freezing current Stage 6 placeholders into long-term artifact semantics.**

**🔑 This workflow must extend verified repository anchors first:**

- `crates/z00z_wallets/src/core/tx/state_update.rs` for the current typed `Checkpoint`, `CheckpointPubIn`, `prepare_tx_sum(...)`, and `apply_batch_checkpoint(...)` contract
- `crates/z00z_simulator/src/scenario_1/stage_6.rs` for the current simulator checkpoint JSON wrapper, replay wiring, and `tx_digest_hex` placeholder proof path
- `crates/z00z_storage/src/assets/types.rs` for the existing `AssetId`, `SerialId`, `AssetStateRoot`, and `CheckRoot` semantic wrappers that new checkpoint types should reuse rather than duplicate
- `crates/z00z_storage/src/lib.rs` for the current public facade, which still exports only `assets`
- `specs/014-z00z-storage/snapshot-storage-spec.md` as the separate pre-state dependency contract that checkpoint storage must consume but must not duplicate
- `crates/z00z_wallets/tests/test_tx_wrong_root.rs` and `crates/z00z_wallets/tests/test_tx_spent_gate.rs` for root and spent-index checkpoint behavior
- `crates/z00z_simulator/tests/test_stage6_checkpoint.rs` for the current Stage 6 wrapper and artifact regression anchor

> [!Important]
> This workflow covers checkpoint draft/final artifact storage, replay linkage, and audit boundaries. It does not authorize redesign of snapshot semantics, JMT leaf identity, or simulator UX outside what is required to remove placeholder checkpoint storage behavior.

## 📌 Verified Starting Point

**✅ The current repository already enforces the following facts and the workflow must preserve them:**

- `z00z_wallets::core::tx::Checkpoint` is the implemented typed checkpoint output and already carries `height`, `prev_root`, `new_root`, `spent_delta`, `created_delta`, and `cp_proof`
- `CheckpointPubIn` is reconstructed from typed artifact fields and currently excludes `height`
- `apply_batch_checkpoint(...)` still emits `cp_proof: Vec::new()`, so the implemented typed checkpoint object is proofless draft-like output rather than a final proved artifact
- Stage 6 persists a reduced simulator JSON `Checkpoint` wrapper with `prev_root_hex`, `new_root_hex`, `spent_delta`, `created_delta`, and `fragment_ids`
- Stage 6 derives `prev_root_hex` from Stage 4 prep material and rechecks the root rather than deriving it from `tx_digest_hex`
- Stage 6 still reuses `pkg.tx_digest_hex` bytes as temporary `tx_proof` input to `prepare_tx_sum(...)`

**📌 The canonical checkpoint rollout must therefore preserve typed root and delta semantics, split proofless draft outputs from final artifacts, and remove `tx_digest_hex` placeholder proof behavior instead of documenting it as durable storage design.**

## ❓ Assumptions And Open Decisions

**📌 Assumption 1: the first safe storage milestone may introduce canonical checkpoint types and persistence boundaries before a real checkpoint proof producer lands, but proofless outputs must stay explicitly typed as drafts during that phase.**

**📌 Assumption 2: the pre-state side remains governed by the separate snapshot contract and current Stage 4 prep file until the snapshot storage rollout provides canonical persisted snapshot artifacts.**

**❓ Open decision 1: the first storage codec may be JSON-only for debugging or dual JSON plus binary from day one. The workflow isolates that choice behind codec boundaries and version gates.**

**❓ Open decision 2: the final checkpoint artifact may infer proof-system identity from artifact versioning or may require an explicit proof-system discriminator. That question must not block the first structural milestone.**

**❓ Open decision 3: audit wrappers such as `CheckpointAuditView` may live in `z00z_storage` or may remain simulator-local. That decision must not leak audit fields into canonical artifact bytes.**

**🚩 Resolution order is mandatory and phase-bound: codec strategy must be fixed before Phase 3 begins, proof-system discrimination must be fixed before Phase 5 wires final proof verification beyond one versioned contract, and audit-wrapper ownership must be fixed before Phase 6 lands any persistent audit wrapper path.**

> [!Warning]
> No phase may silently keep `tx_digest_hex` as checkpoint proof material, treat proofless typed outputs as final artifacts, or allow `fragment_ids` to drift into canonical public-input storage.

## 🔑 Implementation Anchors

**📌 The workflow must target the following verified modules first.**

| Area | Existing file | Role in workflow |
| --- | --- | --- |
| Typed checkpoint contract | `crates/z00z_wallets/src/core/tx/state_update.rs` | Source of current `Checkpoint`, `CheckpointPubIn`, `prepare_tx_sum(...)`, and `apply_batch_checkpoint(...)` semantics |
| Current simulator wrapper | `crates/z00z_simulator/src/scenario_1/stage_6.rs` | Current JSON checkpoint export, replay helper flow, and placeholder proof wiring |
| Snapshot dependency contract | `specs/014-z00z-storage/snapshot-storage-spec.md` | Separate pre-state contract that checkpoint storage must consume |
| Root regression gate | `crates/z00z_wallets/tests/test_tx_wrong_root.rs` | Guards typed checkpoint root behavior |
| Spent gate regression | `crates/z00z_wallets/tests/test_tx_spent_gate.rs` | Guards deterministic state-apply boundary |
| Stage 6 regression | `crates/z00z_simulator/tests/test_stage6_checkpoint.rs` | Guards current wrapper payload and replay-facing behavior |

**📌 Proposed storage-layer files, if needed, are listed below. These are proposed targets, not current code facts.**

- `crates/z00z_storage/src/checkpoint/artifact.rs`
- `crates/z00z_storage/src/checkpoint/ids.rs`
- `crates/z00z_storage/src/checkpoint/codec.rs`
- `crates/z00z_storage/src/checkpoint/store.rs`
- `crates/z00z_storage/src/checkpoint/link.rs`
- `crates/z00z_storage/src/checkpoint/exec_input.rs`
- `crates/z00z_storage/src/checkpoint/audit.rs`
- `crates/z00z_storage/tests/checkpoint_*.rs`

## 🚩 Execution Guardrails

**📌 The workflow must preserve the following boundaries while phases are executed:**

- checkpoint draft and final artifact semantics must stay distinct at the type boundary
- snapshot witness material must stay outside canonical checkpoint artifact bytes
- `CheckpointArtifact` proof verification must stay separate from local deterministic replay
- `CheckpointArtifact`, `CheckpointLink`, `CheckpointExecInput`, and any audit wrapper must remain distinct artifact classes with distinct persistence surfaces
- `CheckpointId` and `CheckpointExecInputId` must be content-addressed from canonical bytes only and must remain external to the self-serialized payloads
- replay-critical linkage must use `checkpoint_id`, `prep_snapshot_id`, and `exec_input_id` together rather than filenames or transport-local handles
- `spent_delta` and `created_delta` must preserve deterministic apply order and terminal `asset_id` identity only
- no final artifact API may accept empty `cp_proof` bytes once finalization is wired in
- transport strings, hex fields, and raw bytes must stop at codec and adapter boundaries and must never enter canonical validation as partially decoded semantic values

> [!Caution]
> A proofless typed checkpoint object may continue to exist during migration, but it must be named and persisted as a draft only. The workflow must not leave a gray zone where a draft can be mistaken for a final artifact by codec, file path, or API shape.

## 🧭 Dependency Map

```mermaid
flowchart TD
    A[Phase 1 Freeze Current Semantics] --> B[Phase 2 Introduce Draft Final Types]
    B --> C[Phase 3 Add Facade Codec Linkage]
    C --> D[Phase 4 Validate Replay Inputs And Build Draft]
    D --> E[Phase 5 Finalize Artifact And Identities]
    E --> F[Phase 6 Cut Over Simulator Wrappers]
    F --> G[Phase 7 Land Test Matrix And Acceptance]
```

```mermaid
sequenceDiagram
    participant SNAP as PrepSnapshot Store
    participant EXEC as CheckpointExecInput Store
    participant BUILD as Checkpoint Builder
    participant PROVE as Proof Producer
    participant STORE as Checkpoint Store

    SNAP->>BUILD: load validated PrepSnapshot
    EXEC->>BUILD: load ordered execution input
    BUILD->>BUILD: validate ids and prev_root agreement
    BUILD->>BUILD: apply checkpoint and emit CheckpointDraft
    BUILD->>PROVE: build proof over CheckpointPubIn
    PROVE-->>STORE: non-empty cp_proof
    STORE->>STORE: finalize artifact and derive CheckpointId
    STORE-->>BUILD: persisted CheckpointArtifact plus linkage
```

## ⚙️ Phase 1. Freeze Current Checkpoint Semantics

### Phase 1 Intent

**📌 Lock the current typed wallet checkpoint semantics and the current Stage 6 wrapper behavior before any storage-layer type split begins.**

### Phase 1 Entry Conditions

- `checkpoint-storage-spec.md` remains the source checkpoint intent document
- the separate snapshot contract is treated as an input dependency rather than rewritten here

### Phase 1 Execution Steps

1. Reconfirm the typed checkpoint contract in `crates/z00z_wallets/src/core/tx/state_update.rs`.
1. Reconfirm the current simulator wrapper and placeholder proof path in `crates/z00z_simulator/src/scenario_1/stage_6.rs`.
1. Record one mismatch matrix covering typed wallet fields, simulator wrapper fields, and target storage artifact fields.
1. Record one blocker list covering proofless final outputs, `tx_digest_hex` placeholder proof bytes, audit-only wrapper fields, and missing storage artifact identities.
1. For every blocker, record one `fails today` example, one `success state` acceptance rule, one owning file, and one planned runtime or feature-gated hard reject that makes stale flows fail loudly.
1. Convert the blocker inventory into one persisted blocker-enforcement table referenced by later migration and sign-off phases.
1. Treat any unresolved field that maps to more than one target meaning as a blocker to later phases.

### Phase 1 Parallelization Rules

- steps 1 and 2 may run in parallel
- mismatch matrix and blocker inventory must wait until both code reads are complete

### Phase 1 Validation Gate

```bash
cargo test -p z00z_wallets --features test-fast test_tx_wrong_root -- --nocapture
cargo test -p z00z_wallets --features test-fast test_tx_spent_gate -- --nocapture
cargo test -p z00z_simulator --features test-fast test_stage6_checkpoint -- --nocapture
```

The gate also requires one blocker regression or hard-reject check per active blocker before canonical checkpoint behavior can move outside isolated migration tests.

### Phase 1 Exit Conditions

- one verified mismatch matrix exists
- one explicit blocker inventory exists
- later phases do not treat `cp_proof: []` or `fragment_ids` as canonical final artifact semantics

### Phase 1 Rollback Rule

**🛑 If any current field or placeholder behavior cannot be classified as canonical, draft-only, or audit-only, stop and resolve that classification before introducing storage-layer types.**

## ⚙️ Phase 2. Introduce Draft Final Artifact Types And Identities

### Phase 2 Intent

**📌 Create the minimum canonical checkpoint storage shape inside `z00z_storage` without yet changing Stage 6 persistence or pretending that proofless artifacts are final.**

### Phase 2 Target Files

- existing insertion point: `crates/z00z_storage/src/checkpoint/`
- existing semantic types: `crates/z00z_storage/src/assets/types.rs`
- proposed: `crates/z00z_storage/src/checkpoint/artifact.rs`
- proposed: `crates/z00z_storage/src/checkpoint/ids.rs`
- proposed: `crates/z00z_storage/src/checkpoint/mod.rs`
- proposed: `crates/z00z_storage/src/error.rs`
- existing facade update: `crates/z00z_storage/src/lib.rs`

### Phase 2 Execution Steps

1. Define `CheckpointDraft` and `CheckpointArtifact` as separate concrete typed records.
1. Reuse the existing wallet-side field model for `height`, `prev_root`, `new_root`, `spent_delta`, and `created_delta` rather than inventing a parallel checkpoint payload.
1. Define `CheckpointId` and `CheckpointExecInputId` as external content-addressed identifiers derived from canonical bytes only.
1. Define a checkpoint artifact version type separate from checkpoint height and JMT state progression.
1. Freeze the three-way split explicitly: artifact schema version controls serialization and proof contract, checkpoint height tracks chain progression, and any JMT tree version remains storage progression only.
1. Reuse the existing `z00z_storage::assets` semantic wrappers for `AssetId`, `SerialId`, `AssetStateRoot`, and `CheckRoot` where they already match checkpoint meaning, and introduce new checkpoint-local wrappers only where the current assets module has no existing semantic type.
1. Keep proof bytes in a dedicated typed container for final artifacts only.
1. Define the first acceptable public shape as a narrow `CheckpointStore`-style facade with explicit draft, final, link, and replay-helper operations.
1. Add one adapter contract from the current wallet-side `Checkpoint` value into `CheckpointDraft` so the migration path reuses existing typed state-apply output rather than duplicating checkpoint semantics.
1. Keep simulator adapters outside canonical checkpoint modules and keep helper modules `pub(crate)` unless a facade requires export.
1. Require all new checkpoint codecs and persistence code to use `z00z_utils::codec` and `z00z_utils::io` abstractions rather than direct `serde_json` or `std::fs` calls.

### Phase 2 Required Constraints

- `CheckpointDraft` must be proofless by construction
- `CheckpointArtifact` must not accept empty final proof bytes
- checkpoint artifacts must not embed snapshot witness bytes, `fragment_ids`, filenames, or report metadata
- `CheckpointId` and `CheckpointExecInputId` must stay external to self-serialized payloads so identities are not recursively self-referential
- the public facade must define one explicit error taxonomy for proofless final artifacts, linkage mismatch, replay-input mismatch, root mismatch, codec failure, and backend failure
- raw string roots and generic byte arrays must be forbidden at public checkpoint boundaries except inside explicit codec modules
- public review must reject any new function that accepts a checkpoint root without documenting the root source of truth it trusts
- canonical checkpoint modules must not import simulator-only wrapper structs directly

### Phase 2 Module Boundary Rules

- `lib.rs` may re-export only typed checkpoint-side contracts
- helper modules must stay `pub(crate)` unless a cross-crate adapter requires a narrower export
- each checkpoint module must declare whether it is consensus-facing, replay-facing, or audit-only
- canonical checkpoint modules must depend downward on ids, roots, codecs, and asset-state abstractions only

### Phase 2 Critical Sketch

```rust
pub struct CheckpointDraft {
    pub version: CheckpointVersion,
    pub height: CheckpointHeight,
    pub prev_root: CheckRoot,
    pub new_root: CheckRoot,
    pub spent_delta: Vec<SpentEnt>,
    pub created_delta: Vec<CreatedEnt>,
}

pub struct CheckpointArtifact {
    pub version: CheckpointVersion,
    pub height: CheckpointHeight,
    pub prev_root: CheckRoot,
    pub new_root: CheckRoot,
    pub spent_delta: Vec<SpentEnt>,
    pub created_delta: Vec<CreatedEnt>,
    pub cp_proof: CheckpointProofBytes,
}
```

**📌 The persisted final shape above is not the replay boundary by itself. Local deterministic replay also depends on separate validated snapshot and execution-input artifacts.**

### Phase 2 Parallelization Rules

- type design and id design may run in parallel
- public re-export wiring must wait until both are stable

### Phase 2 Validation Gate

- code review confirms that draft and final artifact classes cannot be confused by a shared optional proof field
- code review confirms that transport strings and raw bytes stop in codec or adapter modules before semantic validation begins
- `cargo test -p z00z_storage --lib` passes once the new module compiles

### Phase 2 Exit Conditions

- canonical draft and final artifact types compile behind the storage layer
- no simulator file imports canonical checkpoint modules directly yet
- no persistence semantics have been cut over yet

### Phase 2 Rollback Rule

**🛑 If the new checkpoint types require Stage 6 persistence changes immediately, the phase is ordered incorrectly and must be split again before merge.**

## ⚙️ Phase 3. Add Checkpoint Facade, Codec, Linkage, And Persistence Boundaries

### Phase 3 Intent

**📌 Turn the new checkpoint types into explicit storage artifact classes with separate persistence surfaces for drafts, finals, links, execution inputs, and audit wrappers.**

### Phase 3 Target Files

- existing insertion point: `crates/z00z_storage/src/checkpoint/`
- proposed: `crates/z00z_storage/src/checkpoint/store.rs`
- proposed: `crates/z00z_storage/src/checkpoint/codec.rs`
- proposed: `crates/z00z_storage/src/checkpoint/link.rs`
- proposed: `crates/z00z_storage/src/checkpoint/exec_input.rs`
- proposed: `crates/z00z_storage/src/checkpoint/audit.rs`

### Phase 3 Execution Steps

1. Resolve open decision 1 for codec strategy before any storage codec implementation starts and record the chosen contract in the spec and workflow.
1. Implement canonical codecs for `CheckpointDraft`, `CheckpointArtifact`, `CheckpointLink`, and `CheckpointExecInput`.
1. Define one narrow `CheckpointStore`-style facade with explicit `save_draft`, `save_exec_input`, `save_link`, `finalize_artifact`, `load_artifact`, `load_exec_input`, `load_link`, and `validate_artifact` responsibilities.
1. Keep checkpoint persistence, linkage persistence, and execution-input persistence as separate operations or distinct typed handles.
1. Keep all string and hex decoding logic inside codec or adapter modules and require decoders to fail before canonical validation begins if data cannot be converted into typed checkpoint values.
1. Require adapter-level assertions so scenario wrappers and transport paths can only pass roots through typed constructors fed from canonical sources rather than from tx digests, debug strings, or length-matching byte buffers.
1. Require load operations to recompute content-addressed ids from persisted canonical bytes and reject key or handle mismatches before replay or verification begins.
1. Require final-artifact loaders to reject drafts and replay-helper loaders to reject final artifacts rather than inferring artifact class from payload shape.
1. Keep audit wrappers as separate non-consensus records even if their final owning crate remains an open decision.
1. Define explicit loader behavior for supported older versions, newer unsupported versions, and malformed version tags before any proof verification, replay linkage, or artifact-class casting begins.

### Phase 3 Pre-Validation Gate

Before semantic validation, replay logic, or proof verification begins, decoders and adapters must either produce fully typed checkpoint values or fail closed. Partially decoded transport values and transport-local field names must not cross this gate.

### Phase 3 Critical Pseudocode

```rust
pub trait CheckpointStore {
    fn save_draft(&mut self, draft: &CheckpointDraft) -> Result<CheckpointDraftId, CheckpointStorageError>;
    fn save_exec_input(&mut self, exec_input: &CheckpointExecInput) -> Result<CheckpointExecInputId, CheckpointStorageError>;
    fn save_link(&mut self, link: &CheckpointLink) -> Result<(), CheckpointStorageError>;
    fn finalize_artifact(&mut self, draft_id: &CheckpointDraftId, proof: CheckpointProofBytes, link: &CheckpointLink) -> Result<CheckpointId, CheckpointStorageError>;
    fn load_artifact(&self, checkpoint_id: &CheckpointId) -> Result<CheckpointArtifact, CheckpointStorageError>;
    fn load_exec_input(&self, exec_input_id: &CheckpointExecInputId) -> Result<CheckpointExecInput, CheckpointStorageError>;
    fn load_link(&self, checkpoint_id: &CheckpointId) -> Result<CheckpointLink, CheckpointStorageError>;
    fn validate_artifact(&self, artifact: &CheckpointArtifact) -> Result<CheckpointPubIn, CheckpointStorageError>;
}
```

### Phase 3 Parallelization Rules

- codec implementation and API test scaffolding may run in parallel
- final facade surface and persistence taxonomy must stay serialized behind one source-of-truth storage module

### Phase 3 Validation Gate

The phase must add and pass tests for:

- draft rejected by final-artifact load APIs
- final artifact rejected by replay-helper load APIs
- malformed version tag
- unsupported artifact version
- supported-version round-trip without implicit upgrade or silent field rewriting
- id drift after canonical re-encode
- backend key mismatch against recomputed `CheckpointId`
- backend key mismatch against recomputed `CheckpointExecInputId`
- wrapper content rejected by canonical artifact APIs
- linkage incomplete for `checkpoint_id`, `prep_snapshot_id`, and `exec_input_id`
- malformed transport encodings rejected before validation or replay logic begins
- tx-digest-shaped and transport-local root values rejected even when byte length matches the typed root length

### Phase 3 Exit Conditions

- one storage-owned persistence boundary exists for drafts, final artifacts, links, and execution-input helpers
- canonical load and save semantics are explicit enough that callers cannot confuse artifact classes through one API surface
- simulator-local wrapper behavior is not yet removed, but it is now clearly outside the new storage boundary

### Phase 3 Rollback Rule

**🛑 If artifact class is still inferred from payload shape or file path after this phase, stop and separate the persistence surface before continuing.**

## ⚙️ Phase 4. Validate Replay Inputs And Build Checkpoint Drafts

### Phase 4 Intent

**📌 Build checkpoint drafts only from validated snapshot artifacts plus validated execution-input artifacts, then apply state once and capture deltas in typed deterministic order.**

### Phase 4 Target Files

- existing anchor: `crates/z00z_wallets/src/core/tx/state_update.rs`
- existing anchor: `crates/z00z_simulator/src/scenario_1/stage_6.rs`
- proposed: `crates/z00z_storage/src/checkpoint/exec_input.rs`
- proposed: `crates/z00z_storage/src/checkpoint/store.rs`

### Phase 4 Execution Steps

1. Load validated `PrepSnapshot` before any checkpoint apply logic begins.
1. Load validated `CheckpointExecInput` carrying ordered outputs and per-tx proof bytes.
1. Load `CheckpointLink` and cross-check `checkpoint_id`, `prep_snapshot_id`, `exec_input_id`, and `prev_root` agreement in one fixed order.
1. Persist one field source-of-truth inventory that names, for each canonical field, whether it comes from validated snapshot state, typed apply result, or proof layer, and explicitly lists forbidden sources such as filenames, row numbers, report caches, and wrapper-local traces.
1. Build one canonical typed apply summary from validated snapshot plus validated execution input.
1. Apply the state transition exactly once against the validated `prev_root`.
1. Capture `spent_delta`, `created_delta`, and `new_root` from that one execution result and emit `CheckpointDraft` immediately.
1. Compute every `CreatedEnt.leaf_hash` from the same canonical JMT terminal leaf-hash rule used by the proof layer rather than from wrapper caches or report artifacts.
1. Preserve apply order exactly and reject helper code that re-sorts deltas after apply.
1. Record one migration table mapping current Stage 6 wrapper fields to canonical draft fields, final artifact fields, audit-only wrapper fields, or deprecated placeholders before simulator cut-over begins.

### Phase 4 Structural Validation Contract

Before any draft can be accepted for persistence or export, one storage-owned validator must check the full artifact, snapshot, and apply-result invariant set:

- `prev_root` equals the validated snapshot root used for apply
- `new_root` equals the resulting JMT root after deletes and inserts
- `spent_delta` carries terminal `asset_id` values only and has no duplicates
- `created_delta` carries terminal `asset_id` values only and has no duplicates
- every `CreatedEnt.leaf_hash` matches the canonical JMT terminal value hash
- replay comparison uses exact ordered delta equality rather than set equality

Any attempt to substitute `definition_id` for terminal `asset_id` must fail before proof verification or replay comparison begins.

The leaf-hash rule above must stay aligned with the canonical terminal JMT leaf-hash contract and must not be replaced by wrapper caches, report artifacts, or alternate checkpoint-local hash meanings.

### Phase 4 Integration Constraint

**🚫 The builder integration must evolve the current `prepare_tx_sum(...)` plus `apply_batch_checkpoint(...)` path. It must not create a second simulator-only checkpoint apply path beside the typed wallet contract.**

### Phase 4 Parallelization Rules

- replay-input validation wiring and later finalization planning may be developed in parallel
- apply-summary construction and deterministic delta capture must remain serialized through one typed apply path

### Phase 4 Validation Gate

```bash
cargo test -p z00z_wallets --features test-fast test_tx_wrong_root -- --nocapture
cargo test -p z00z_wallets --features test-fast test_tx_spent_gate -- --nocapture
cargo test -p z00z_simulator --features test-fast test_stage6_checkpoint -- --nocapture
```

The gate passes only if:

- replay-input linkage failures remain distinct for snapshot mismatch, exec-input mismatch, and root mismatch
- identical snapshot plus execution-input fixtures produce identical draft bytes and identical public inputs
- typed apply order is preserved without post-processing or sorting
- duplicate `asset_id` values in either delta are rejected even when roots are otherwise valid
- `definition_id` substitution is rejected where terminal `asset_id` is required
- wrong `leaf_hash` values fail before any artifact is accepted or exported
- no builder path still depends on mutable filenames or row ids once canonical ids exist

### Phase 4 Exit Conditions

- checkpoint drafts can be built from validated snapshot plus validated execution input through one canonical path
- deterministic apply order is preserved in both deltas
- no final artifact semantics have been claimed yet for proofless outputs

### Phase 4 Rollback Rule

**🛑 If replay-input linkage or root agreement cannot be proven before apply, revert to Phase 3 and fix the canonical artifact boundary first.**

## ⚙️ Phase 5. Finalize Checkpoint Artifacts And External Identities

### Phase 5 Intent

**📌 Upgrade proofless drafts into final checkpoint artifacts only through explicit non-empty proof attachment, public-input reconstruction, and external content-addressed identity derivation.**

### Phase 5 Target Files

- proposed: `crates/z00z_storage/src/checkpoint/artifact.rs`
- proposed: `crates/z00z_storage/src/checkpoint/store.rs`
- existing anchor: `crates/z00z_wallets/src/core/tx/state_update.rs`

### Phase 5 Execution Steps

1. Resolve open decision 2 before introducing any proof-verifier branch that depends on proof-system identity beyond the chosen artifact version contract.
1. Reconstruct `CheckpointPubIn` from `CheckpointDraft` immediately before proof attachment.
1. Attach non-empty `cp_proof` bytes only through one explicit finalization function.
1. Preserve `height`, `prev_root`, `new_root`, `spent_delta`, and `created_delta` byte-for-byte from the draft and attach only the proof-carrying final layer.
1. Derive `CheckpointId` from canonical final artifact bytes only and keep it external to the payload.
1. Persist `CheckpointLink` only after the final artifact bytes and `CheckpointId` are fixed.
1. Reject finalization if proof bytes are empty, linkage is incomplete, artifact bytes are non-canonical, or the linked snapshot root does not match the validated `prev_root`.
1. Freeze verifier order as one canonical path: decode artifact, rebuild public inputs, verify proof, then compare external root expectations.

### Phase 5 Critical Pseudocode

```rust
fn finalize_checkpoint(
    draft: CheckpointDraft,
    cp_proof: CheckpointProofBytes,
) -> Result<CheckpointArtifact, CheckpointStorageError> {
    if cp_proof.is_empty() {
        return Err(CheckpointStorageError::EmptyCheckpointProof);
    }

    Ok(CheckpointArtifact {
        version: draft.version,
        height: draft.height,
        prev_root: draft.prev_root,
        new_root: draft.new_root,
        spent_delta: draft.spent_delta,
        created_delta: draft.created_delta,
        cp_proof,
    })
}
```

### Phase 5 Parallelization Rules

- proof production integration and finalization tests may run in parallel
- artifact id derivation and linkage persistence must wait until final artifact bytes are fixed

### Phase 5 Validation Gate

- empty `cp_proof` rejected for final artifacts
- finalization does not alter `height`, roots, or deltas
- two different proof payloads over the same draft yield different final bytes and different `CheckpointId` values
- valid proof paired with the wrong `CheckpointLink` is rejected
- persisted final artifact round-trips with the same recomputed `CheckpointId`
- tampering with any one of `prev_root`, `new_root`, `spent_delta`, or `created_delta` causes proof verification to fail distinctly
- proof verification never consumes simulator-only metadata or replay-only helpers

### Phase 5 Exit Conditions

- final artifact semantics are explicit and proof-carrying only
- checkpoint identity is fixed from canonical bytes only
- linkage records point to immutable final artifact bytes rather than mutable draft-stage payloads

### Phase 5 Rollback Rule

**🛑 If a proofless output can still be loaded through a final-artifact API after this phase, reject the phase as incomplete.**

## ⚙️ Phase 6. Cut Over Simulator Wrappers And Public APIs

### Phase 6 Intent

**📌 Move simulator exports and replay helpers onto canonical checkpoint storage semantics while keeping audit-only wrapper fields out of final artifact bytes.**

### Phase 6 Target Files

- existing simulator wrapper: `crates/z00z_simulator/src/scenario_1/stage_6.rs`
- proposed storage adapters: `crates/z00z_storage/src/checkpoint/audit.rs`
- proposed storage facade: `crates/z00z_storage/src/checkpoint/store.rs`

### Phase 6 Execution Steps

1. Resolve open decision 3 before persisting any audit wrapper outside purely local review artifacts.
1. Update Stage 6 wrapper paths so they wrap canonical draft and final artifact shapes rather than redefining checkpoint semantics locally.
1. Remove `tx_digest_hex` placeholder proof wiring from any path that claims final checkpoint storage semantics.
1. Move `fragment_ids` and any similar simulator-only trace fields into an audit wrapper or report artifact only.
1. Keep consensus-facing checkpoint validation separate from local deterministic replay helpers.
1. Remove filename-based or row-based replay-critical linkage from public APIs once canonical ids exist.
1. Remove remaining non-canonical wrapper paths within this phase and forbid parallel checkpoint semantics after the canonical cut-over lands.
1. Re-run one fixed integration suite after every migration phase and require at least one unchanged fixture from the previous phase to keep passing under the new canonical API surface.
1. Maintain one migration audit table mapping each non-canonical root source, proofless-final path, filename-based link, and audit-only field to its removal phase, owning file, and replacement API.
1. For every non-canonical caller path, record caller list, explicit removal condition, target removal phase, and one fail-loud test proving that removed callers no longer auto-map into canonical semantics.

### Phase 6 Parallelization Rules

- simulator adapter rewrites and documentation updates may run in parallel
- placeholder proof removal, wrapper shrinkage, and public API cleanup must land together

### Phase 6 Validation Gate

- no simulator wrapper path claims final artifact semantics while still omitting `height` or `cp_proof`
- no public API accepts filename-derived artifact identity
- no audit-only field changes canonical artifact bytes or `CheckpointPubIn`
- no replay path claims deterministic re-apply from `CheckpointArtifact` alone without execution input
- no non-canonical caller path lacks an owner, caller list, removal condition, or target removal phase

### Phase 6 Exit Conditions

- simulator wrappers either wrap canonical artifacts without adding checkpoint meaning or are removed from the canonical execution path
- placeholder proof paths are removed from any final-artifact surface
- public APIs expose only canonical checkpoint semantics

### Phase 6 Rollback Rule

**🛑 If Stage 6 still needs to redefine checkpoint fields locally after cut-over, stop and move that meaning into canonical storage types or explicit audit wrappers before continuing.**

## ⚙️ Phase 7. Land Test Matrix, Rollout, And Acceptance

### Phase 7 Intent

**📌 Make checkpoint storage enforceable by tests, gates, and sign-off rather than by prose, then define when the canonical rollout is allowed to close.**

### Phase 7 Target Test Files

- proposed: `crates/z00z_storage/tests/checkpoint_draft_final.rs`
- proposed: `crates/z00z_storage/tests/checkpoint_root_binding.rs`
- proposed: `crates/z00z_storage/tests/checkpoint_leaf_hash.rs`
- proposed: `crates/z00z_storage/tests/checkpoint_link_injective.rs`
- proposed: `crates/z00z_storage/tests/checkpoint_replay_inputs.rs`
- proposed: `crates/z00z_storage/tests/checkpoint_ids.rs`
- existing wallet regressions: `crates/z00z_wallets/tests/test_tx_wrong_root.rs`, `crates/z00z_wallets/tests/test_tx_spent_gate.rs`
- existing simulator regression: `crates/z00z_simulator/tests/test_stage6_checkpoint.rs`

### Phase 7 Target Fixtures

- proposed: `crates/z00z_storage/tests/fixtures/checkpoint_valid.json`
- proposed: `crates/z00z_storage/tests/fixtures/checkpoint_draft.json`
- proposed: `crates/z00z_storage/tests/fixtures/checkpoint_wrong_root.json`
- proposed: `crates/z00z_storage/tests/fixtures/checkpoint_wrong_link.json`
- proposed: `crates/z00z_storage/tests/fixtures/checkpoint_exec_input.json`

### Phase 7 Required Test Buckets

1. draft-versus-final separation
1. root consistency
1. terminal asset identity in deltas
1. created leaf-hash consistency
1. linkage injectivity
1. replay-input necessity
1. artifact-id stability
1. proof verification boundary
1. audit-wrapper boundary
1. transport pre-validation boundary
1. blocker-enforcement regressions
1. migration fail-loud behavior

### Phase 7 Execution Steps

1. Group milestone tests into explicit buckets with at least one positive and one negative case per bucket.
1. Add golden fixtures for canonical draft, final artifact, link, and execution-input bytes.
1. Add one end-to-end fixture family replayed as valid, wrong-root, wrong-link, wrong-leaf-hash, proofless-final, and wrong-exec-input variants.
1. Add one regression fixture derived from current simulator-style checkpoint JSON and prove canonical loaders reject it until adapters normalize missing `height`, empty `cp_proof`, and audit-only fields.
1. Add tests proving final proof verification reconstructs `CheckpointPubIn` from artifact fields rather than accepting caller-supplied public inputs.
1. Add wrapper-boundary tests proving `fragment_ids`, stage ids, and report references can change without affecting canonical artifact bytes or proof verification.
1. Add one determinism test that encodes the same draft twice, finalizes twice with the same proof bytes, and proves identical final bytes and identical `CheckpointId` values across runs.
1. Add tamper tests that swap `spent_delta`, `created_delta`, or `height` during finalization or verification and prove the finalizer or verifier rejects the mutation under the correct failure class.
1. Add replay tests proving proof verification can succeed while local replay fails when ordered execution input is missing, and proving replay output must match stored public inputs exactly.
1. Add explicit linkage injectivity tests proving that two different execution-input bodies for the same `PrepSnapshotId` cannot both link to one final checkpoint artifact.
1. Add one focused review pass that checks only root substitution, proofless-final rejection, and replay-linkage injectivity before milestone sign-off.
1. Track the checkpoint test matrix in CI through a stable manifest so any new invariant must add both positive and negative rows.
1. Record which simulator wrapper fields were removed, which moved into audit wrappers, and which canonical fields replace them after each rollout step.
1. Verify that the already-resolved open decisions were applied in the required order and that the spec was amended before implementation expanded into the affected phase.
1. Leave one sign-off record naming the verified fixtures, the closed invariant buckets, and the exact commit or tag where checkpoint storage invariants were accepted.

### Phase 7 Reference Tests

- `final_artifact_rejects_empty_cp_proof`
- `artifact_prev_root_must_match_snapshot_prev_root`
- `created_leaf_hash_must_match_canonical_jmt_leaf_hash`
- `checkpoint_link_requires_all_three_content_ids`
- `replay_requires_exec_input_even_when_proof_verifies`
- `checkpoint_id_is_stable_across_roundtrip`

### Phase 7 Validation Gate

```bash
cargo test -p z00z_storage --tests
cargo test -p z00z_wallets --features test-fast test_tx_wrong_root -- --nocapture
cargo test -p z00z_wallets --features test-fast test_tx_spent_gate -- --nocapture
cargo test -p z00z_simulator --features test-fast test_stage6_checkpoint -- --nocapture
```

### Phase 7 Exit Conditions

- all test buckets pass with both positive and negative coverage
- no blocker from root substitution, proofless-final rejection, replay-linkage injectivity, or audit-boundary separation remains unresolved
- no non-canonical wrapper path remains undocumented or ownerless
- no unresolved compliance gate for root identity, terminal asset identity, proof bytes, or replay separation remains open
- no unresolved transport-boundary, duplicate-delta, `definition_id` substitution, or versioning rule remains only in prose

### Phase 7 Recovery Rules

- if proof verification still depends on simulator wrapper fields, stop rollout and move the dependency into canonical artifact reconstruction or reject it entirely
- if replay linkage is unstable, freeze rollout and fix canonical `CheckpointLink` and execution-input id rules before widening callers
- if Stage 6 breaks during cut-over, roll back wrapper changes and canonical public API changes together so no mixed semantic pair becomes active
- if any open decision is informally reopened through wrapper code or review comments, stop rollout and require an explicit spec amendment before continuing

### Phase 7 Final Acceptance Gate

The workflow is complete only when all of the following are true:

1. canonical `CheckpointDraft`, `CheckpointArtifact`, `CheckpointLink`, and `CheckpointExecInput` types exist in the storage layer
1. one canonical storage facade distinguishes drafts, finals, links, and replay inputs explicitly
1. no final artifact path accepts empty `cp_proof` bytes
1. no final artifact path derives proof material from `tx_digest_hex`
1. `CheckpointId` and `CheckpointExecInputId` are stable across round-trip serialization and external to payloads
1. proof verification reconstructs `CheckpointPubIn` from artifact fields only
1. local deterministic replay remains separate from consensus proof verification and still requires ordered execution input explicitly
1. the three version concepts remain separate: artifact schema version, checkpoint height, and JMT tree progression are not inferred from one another
1. each migration minimum acceptance criterion is enforced directly by code or tests: no tx-digest roots, no proofless final artifacts, no `definition_id` substitution, no audit-field public-input mixing, no replay-from-artifact-alone claims, no filename-only linkage, no recursive artifact-id hashing, and no `prep_snapshot_id`-only execution-input identity
1. no non-canonical wrapper field remains reachable from canonical APIs, and no unresolved compliance gate for root identity, terminal asset identity, proof bytes, or replay separation remains open

## 🔔 Acceptance Flow

1. Run baseline wallet and simulator regressions.
1. Run checkpoint storage unit and integration tests.
1. Verify draft-versus-final separation and proofless-final rejection.
1. Verify linkage injectivity across `checkpoint_id`, `prep_snapshot_id`, and `exec_input_id`.
1. Verify that final proof verification does not depend on replay helpers or audit wrappers.
1. Verify that transport decoding fails before semantic validation and that duplicate delta ids plus `definition_id` substitution fail with distinct reject reasons.
1. Record any remaining ambiguity as an explicit blocker or deferred decision.

**🔔 The workflow must prefer one explicit canonical checkpoint path over a prolonged dual-path rollout. Correct artifact class boundaries, proof boundaries, and linkage rules must close together.**

## 🚫 Non-Goals During This Workflow

- do not redesign snapshot semantics inside checkpoint storage work
- do not collapse snapshot, replay input, and checkpoint result into one canonical artifact
- do not treat simulator filenames or stage-local counters as durable checkpoint identities
- do not add audit metadata to canonical checkpoint payloads without an explicit spec revision
- do not mix checkpoint correctness work with unrelated simulator UX or reporting polish

## ✅ Completion Record

**📌 The implementation owner must leave one completion record that states:**

- which file introduced canonical draft and final checkpoint types
- which file introduced finalization and checkpoint id derivation
- which file introduced canonical linkage and replay-input helpers
- which tests close each invariant bucket
- which simulator wrapper fields were removed or moved into audit wrappers
- which transport-boundary, duplicate-delta, and `definition_id`-substitution checks were enforced in code
- which open decisions remain unresolved and why they do not block correctness
