# 🔑 JMT Speedup Workflow

> [!Important]
> This workflow is built from `workflow_goal` plus verified codebase facts because no reliable `current_spec` was provided.
> It must prescribe one execution order for the next storage performance work in `crates/z00z_storage` and must not silently substitute another repository note as the source spec.

**📌 This workflow covers only the next speedup sequence for the storage assets backend:**

- attack commit-side serialization in `crates/z00z_storage/src/assets/store_internal/tree_store.rs`
- remove the false incremental win ceiling caused by eager `sem_root` recompute in `crates/z00z_storage/src/assets/store_internal/tx_plan.rs`
- isolate the post-commit historical clone cost in `crates/z00z_storage/src/assets/store_internal/tx_plan.rs`
- prove the outcome with reproducible storage bench evidence written under `crates/z00z_storage/outputs/assets`

## 🎯 Scope Lock

**📌 The workflow must deliver these outcomes and nothing broader:**

- preserve the public storage facade exported from `crates/z00z_storage/src/assets/mod.rs`
- preserve the semantic meaning of `AssetStateRoot`, `CheckRoot`, `ProofItem`, and `ProofBlob`
- preserve one external transition version per committed state transition
- improve end-to-end transition cost on the nested backend only through verified private-path changes
- keep rollback safety and deterministic parity gates green while optimizing
- keep all benchmark logs and markdown artifacts under `crates/z00z_storage/outputs/assets`

> [!Warning]
> This workflow must not widen the public API, must not expose raw `jmt` types outside `z00z_storage`, must not modify vendored Tari code, and must not claim a planner-parallel speedup unless the measured nested end-to-end matrix actually proves it.

## 👁️‍🗨️ Verified Inputs And Constraints

**📌 Verified source files used to ground this workflow:**

- `crates/Z00Z_DESIGN_FOUNDATION_short.md`
- `.github/copilot-instructions.md`
- `crates/z00z_storage/src/assets/store_internal/tree_store.rs`
- `crates/z00z_storage/src/assets/store_internal/tx_plan.rs`
- `crates/z00z_storage/src/assets/model.rs`
- `crates/z00z_storage/benches/assets/shard.rs`
- `crates/z00z_storage/benches/assets/nested.rs`
- `crates/z00z_storage/benches/common/fixture.rs`
- `crates/z00z_storage/benches/common/output.rs`
- `crates/z00z_storage/scripts/run_storage_assets_shard_bench.sh`
- `crates/z00z_storage/scripts/run_storage_assets_nested_bench.sh`

**📌 Verified current codebase facts that become hard workflow constraints:**

- `TreeStore::commit_all()` in `tree_store.rs` still flattens all logical batches into one `put_value_set(...)` path and one `apply_batch(...)` call
- `tx_plan.rs::next_roots()` still computes `roots.sem_root = state_root_from_defs(&def_leaves)` before `plan_root()` chooses full versus incremental root export
- `tx_plan.rs::plan_root()` still performs a second top-level `state_root_from_defs(...)` call in full mode and returns `tree_roots.sem_root` in incremental mode
- `tx_plan.rs::commit_stage()` still stores `self.model.clone()` into `model_by_ver` after commit succeeds
- the recent rollback patch already narrowed `snap_store()` and `restore_store()` to flat-store state, so rollback snapshot cloning is no longer the primary unexplained bottleneck
- canonical storage bench wrappers already exist and write runtime artifacts under `crates/z00z_storage/outputs/assets`
- `crates/z00z_storage/outputs/assets` is currently ignored by Git through the repository-wide `**/outputs` rule, so runtime output and versioned decision artifacts are not automatically the same thing
- `crates/z00z_storage/benches/assets/nested.rs` currently executes all four planner and root-mode combinations in one run; it does not expose a runtime selector that limits the run to full-only or incremental-only nested cases

**📌 Verified performance conclusion that this workflow must operationalize:**

- root-mode speedup exists in isolated `assets_shard` measurements
- nested end-to-end speedup is currently capped because commit serialization dominates and the nested path still eagerly computes `sem_root`
- planner-parallel mode is not yet a proven end-to-end win

**📌 Mandatory measurement rule for every implementation phase:**

- each phase that changes a hot path must run fresh timing measurements and the relevant storage benchmarks before the phase may be considered complete
- each measurement pass must be used to track progress versus the immediately previous phase and to verify that the optimization direction is still correct
- if fresh timings do not confirm the expected direction, the workflow must stop, publish the observed regression or flat result, and reassess the next phase instead of continuing on assumption alone

## ❓ Assumptions And Open Decisions

**📌 The following assumptions stay explicit because no source spec fixed them in advance:**

- the preferred path is to extend existing bench targets and existing whitebox test modules before proposing any new benchmark file
- if a dedicated breakdown bench becomes necessary, it must be labeled as proposed and justified by phase complexity rather than added preemptively
- if `model_by_ver` cannot be made cheaper without changing history semantics, the workflow must stop at measurement and publish the blocker instead of silently weakening historical guarantees
- if the final benchmark markdown must be committed as a tracked artifact, the workflow must first add a precise `.gitignore` exception or relocate the checked-in summary to a tracked path; otherwise `crates/z00z_storage/outputs/assets` remains a runtime-output directory only

> [!Caution]
> The workflow must not treat the current benchmark reports as permanent truth. Each phase that changes the hot path must rerun the relevant storage benchmarks through the canonical wrapper scripts and replace the prior decision artifact with fresh numbers.

```mermaid
flowchart TD
    A[Measure commit wall] --> B[Refactor commit_all substrate]
    B --> C[Re-run nested matrix]
    C --> D[Fix eager sem_root path]
    D --> E[Re-run root and nested benches]
    E --> F[Isolate model clone cost]
    F --> G[Final acceptance and direction]
```

```mermaid
sequenceDiagram
    participant Bench as Bench Wrapper
    participant Plan as tx_plan.rs
    participant Tree as tree_store.rs
    participant Hist as model_by_ver

    Bench->>Plan: apply_ops() benchmark case
    Plan->>Plan: precheck_ops() and next_roots()
    Plan->>Tree: commit_all(version, batches...)
    Tree->>Tree: put_value_set(all ops)
    Tree->>Tree: apply_batch(batch)
    Plan->>Hist: model_by_ver.insert(version, self.model.clone())
    Bench->>Bench: store log + markdown report
```

## ⚙️ Phase 1. Measure The Commit Serialization Wall

### 1.1 Intent

**📌 Measure the current hot path before changing structure so the workflow can prove which cost belongs to planning, shared commit, batch apply, and historical clone.**

### 1.2 Entry Conditions

- canonical bench wrappers are available
- `assets_shard` and `assets_nested` compile cleanly
- current nested matrix still shows no planner-parallel end-to-end win

### 1.3 Serialized Steps

1. Extend the existing storage bench surface to record a breakdown for the nested write path instead of introducing a separate public benchmark story immediately.
2. Add one internal timing split around these segments:
   - `precheck_ops()` plus `NextState` application
   - `next_roots()`
   - `TreeStore::commit_all()`
   - `apply_batch(...)` if it can be measured without semantic drift
   - `model_by_ver.insert(version, self.model.clone())`
3. Keep the measurement code private to the bench layer or behind test-only instrumentation; do not ship timing hooks through the public facade.
4. Run the current nested matrix through the canonical nested wrapper and interpret the `nested_jmt_serial/full` and `nested_jmt_parallel/full` rows first; do not prescribe a nonexistent full-only nested selector.
5. If Phase 1 still needs a narrower timing view than the four-mode matrix exposes, label the extra timing harness explicitly as proposed and keep it private to bench or test-only code.
6. Store the captured timings and command lines under `crates/z00z_storage/outputs/assets`.
7. Record whether the benchmark decision artifact is runtime-only or must also be copied into a tracked markdown path because `crates/z00z_storage/outputs/assets` is gitignored.

### 1.4 Preferred File Targets

- `crates/z00z_storage/benches/assets/nested.rs`
- `crates/z00z_storage/benches/assets/shard.rs`
- `crates/z00z_storage/benches/common/output.rs`
- `crates/z00z_storage/src/assets/store_internal/tree_store.rs`
- `crates/z00z_storage/src/assets/store_internal/tx_plan.rs`
- proposed `crates/z00z_storage/benches/common/timing.rs`

### 1.5 Parallelization Rule

- bench-output formatting and markdown artifact updates may run in parallel with internal measurement wiring
- the actual timing-gate interpretation must stay serialized after all measurements are captured on one code revision

### 1.6 Required Outputs

- one reproducible timing split for serial full mode
- one reproducible timing split for parallel full mode
- one markdown artifact that states which segment dominates wall time
- one explicit artifact rule that states whether the benchmark summary remains runtime-only or is also mirrored into a tracked path

### 1.7 Exit Conditions

- the workflow can state with evidence whether `commit_all`, `apply_batch`, or `model.clone()` dominates the current nested path
- the next phase target is justified by measured cost rather than by intuition alone

## ⚙️ Phase 2. Refactor The Commit-Side Serialization Path

### 2.1 Intent

**📌 Reduce the dominant serialized region in `tree_store.rs` before touching secondary optimizations.**

### 2.2 Required Design Rules

1. Keep one external transition version and one semantic commit boundary.
2. Keep rollback behavior equivalent to the current in-memory atomicity model.
3. Do not weaken the semantic root contract while changing only private tree-store write plumbing.
4. Reuse `TreeBatch`, `TreeStore`, and `tx_plan.rs` batching structure before proposing a new commit abstraction.

### 2.3 Serialized Steps

1. Review whether `commit_all()` can separate batch preparation from the final store mutation without changing externally observed atomicity.
2. Move any avoidable flattening, allocation, or namespace packaging work out of the final serialized commit section.
3. If `put_value_set(...)` must remain one underlying operation, make the preceding transformation steps deterministic and precomputed before the final commit call.
4. Preserve one rollback rule: a failed transition must restore pre-commit state exactly.
5. Add whitebox tests that force commit failure and prove no semantic or versioned state leaks through partial work.
6. Re-run the full nested matrix after the refactor and compare only the `nested_jmt_serial/full` and `nested_jmt_parallel/full` rows against the pre-refactor measurement, because the current nested bench host does not support a full-only filtered run.

### 2.4 Preferred File Targets

- `crates/z00z_storage/src/assets/store_internal/tree_store.rs`
- `crates/z00z_storage/src/assets/store_internal/tx_plan.rs`
- `crates/z00z_storage/src/assets/store_internal/whitebox_state.rs`
- `crates/z00z_storage/src/assets/store_internal/whitebox_help.rs`

### 2.5 Critical Pseudocode

```text
plan transition
  derive all touched tree batches first
  prebuild namespaced ops outside final commit lock
  enter serialized commit section once
  run put_value_set(prebuilt ops, version)
  run apply_batch(batch)
  update flat_root and flat_version
  merge semantic next state only after commit succeeds
```

### 2.6 Validation Gate

- run `cargo test -p z00z_storage --lib`
- run `cargo test -p z00z_storage --test assets_suite`
- rerun the nested matrix through the wrapper script and compare the refreshed full-root rows against the pre-refactor baseline rows
- publish the new comparison under `crates/z00z_storage/outputs/assets`

### 2.7 Exit Conditions

- the dominant serialized commit region is smaller or is proven irreducible under the current in-memory substrate
- the nested matrix is refreshed with post-refactor numbers
- if no improvement appears, the workflow must record that the remaining dominant cost moved elsewhere

## ⚙️ Phase 3. Remove The Eager Nested `sem_root` Recompute

### 3.1 Intent

**📌 Make incremental mode actually incremental in the nested path by removing the precomputed top semantic root from `next_roots()` when the runtime mode does not require it.**

### 3.2 Required Design Rules

1. Keep canonical definition ordering for every top-root derivation.
2. Keep full mode as the semantic oracle path.
3. Keep incremental mode byte-identical to full mode for the same committed state.
4. Do not duplicate a second semantic source of truth outside the existing `TreeRoots`-driven path unless Phase 3 proves it is required.

### 3.3 Serialized Steps

1. Separate `def_root` maintenance from `sem_root` maintenance in `tx_plan.rs`.
2. Change `next_roots()` so it does not always call `state_root_from_defs(&def_leaves)` unconditionally.
3. Ensure `plan_root()` computes:
   - full mode from canonical `def_leaves`
   - incremental mode from cached incremental state only
4. Add parity assertions in whitebox tests that compare both paths on the same transition shapes.
5. Rerun isolated root-mode benches first, then rerun the nested matrix.
6. Compare the new nested matrix against the immediately previous matrix rather than against an older pre-Phase-2 matrix, so the Phase 3 decision isolates the eager `sem_root` change instead of mixing commit-path and root-path deltas.

### 3.4 Preferred File Targets

- `crates/z00z_storage/src/assets/store_internal/tx_plan.rs`
- `crates/z00z_storage/src/assets/model.rs`
- `crates/z00z_storage/src/assets/store_internal/whitebox_state.rs`
- `crates/z00z_storage/src/assets/store_internal/whitebox_help.rs`
- `crates/z00z_storage/benches/assets/shard.rs`
- `crates/z00z_storage/benches/assets/nested.rs`

### 3.5 Critical Pseudocode

```text
next_roots(scope, next_model, root_mode):
  update touched asset_roots
  update touched serial_roots
  def_leaves = canonical definition leaves
  roots.def_root = def_tree_from_defs(def_leaves)
  if root_mode == full:
    roots.sem_root = recompute from def_leaves
  else:
    roots.sem_root = update from incremental semantic cache only
```

> [!Warning]
> Phase 3 is wrong if incremental mode still pays the same top-level semantic-root recompute inside `next_roots()` and only avoids a second recompute in `plan_root()`.

### 3.6 Validation Gate

- run `cargo test -p z00z_storage --lib`
- run `cargo test -p z00z_storage --test assets_suite`
- run root-mode full and incremental benchmark commands through `./crates/z00z_storage/scripts/run_storage_assets_shard_bench.sh`
- run the nested matrix through `./crates/z00z_storage/scripts/run_storage_assets_nested_bench.sh`
- publish a phase-local delta note that separates root-mode deltas from nested matrix deltas

### 3.7 Exit Conditions

- incremental mode no longer performs an unconditional eager top semantic-root recompute in the nested path
- root-mode benchmark deltas are refreshed on the new code
- nested end-to-end measurements show whether the removed eager recompute creates a visible wall-time win

## ⚙️ Phase 4. Isolate And Optimize Historical Model Clone Cost

### 4.1 Intent

**📌 Measure and then reduce the post-commit historical snapshot cost only after commit serialization and eager root recompute are addressed.**

### 4.2 Required Design Rules

1. Preserve `root_by_ver` and `model_by_ver` history semantics unless a new history strategy is proven equivalent.
2. Do not weaken rollback, proof parity, or historical-version inspection to buy benchmark speed.
3. Prefer isolating `self.model.clone()` cost first; optimize second.

### 4.3 Serialized Steps

1. Instrument `self.model.clone()` and the following `model_by_ver.insert(...)` path as its own measured segment.
2. Publish whether clone cost is dominant, secondary, or negligible after the Phase 2 and Phase 3 changes.
3. If clone cost is dominant, test the smallest safe refactor first:
   - structural sharing inside `AssetModel` if already supported
   - narrower versioned history payload if semantic parity survives
   - delayed or conditional history materialization only if versioned callers still observe identical semantics
4. Keep failure and rollback tests green throughout the change.
5. If no safe reduction path exists, stop at measurement and publish the historical-state blocker explicitly instead of letting Phase 5 imply that clone cost was optimized.

### 4.4 Preferred File Targets

- `crates/z00z_storage/src/assets/store_internal/tx_plan.rs`
- `crates/z00z_storage/src/assets/model.rs`
- `crates/z00z_storage/src/assets/store_internal/whitebox_state.rs`
- proposed `crates/z00z_storage/src/assets/store_internal/history.rs`

### 4.5 Parallelization Rule

- measurement of clone cost can run in parallel with documentation updates
- any history representation change must stay serialized and must land only after the measurement artifact exists

### 4.6 Validation Gate

- run `cargo test -p z00z_storage --lib`
- run `cargo test -p z00z_storage --test assets_suite`
- rerun the nested matrix through the wrapper script and rerun the Phase 1 timing harness only if that harness exists on the chosen execution path
- update the decision artifact under `crates/z00z_storage/outputs/assets`

### 4.7 Exit Conditions

- the workflow can state whether `model.clone()` remains a dominant post-commit cost
- either the cost is reduced safely or the blocker is published explicitly with evidence

## ⚙️ Phase 5. Final Benchmark Gate And Direction Lock

### 5.1 Intent

**📌 End the sequence with one measured conclusion that tells the next engineer whether the bottleneck is still commit serialization, still semantic-root maintenance, still history clone, or something else.**

### 5.2 Serialized Steps

1. Run the final root-mode full versus incremental benchmark pair.
2. Run the final nested four-mode matrix.
3. Run the final breakdown measurement with the same code revision only if Phase 1 introduced a dedicated timing harness beyond the nested wrapper output.
4. Update one final markdown workflow artifact that records:
   - exact commands
   - exact output files
   - median timings
   - dominant segment conclusion
   - whether planner-parallel mode now wins on any workload
5. If the data still does not prove a parallel end-to-end win, state that explicitly and stop rather than inventing a positive conclusion.

### 5.3 Required Artifact Targets

- `crates/z00z_storage/outputs/assets/jmt-incremental-bench.md`
- `crates/z00z_storage/outputs/assets/jmt-overlay-bench.md`
- one final breakdown artifact only if Phase 1 introduced a dedicated breakdown markdown; otherwise the final breakdown summary must live inside the refreshed nested benchmark markdown or this workflow file
- this workflow file

> [!Important]
> Because `crates/z00z_storage/outputs/assets` is currently gitignored, Phase 5 must either:
>
> 1. treat those markdown files as runtime-only output artifacts, or
> 2. add an explicit `.gitignore` exception before claiming that the final decision artifacts are checked in.
>
> The workflow must choose one of those two paths explicitly during execution.

### 5.4 Final Acceptance Commands

```bash
cargo test -p z00z_storage --lib
cargo test -p z00z_storage --test assets_suite
./crates/z00z_storage/scripts/run_storage_assets_shard_bench.sh --bench-mode nested_jmt_serial --root-mode current_full_recompute --baseline current_full_recompute
./crates/z00z_storage/scripts/run_storage_assets_shard_bench.sh --bench-mode nested_jmt_serial --root-mode current_incremental --baseline current_incremental
./crates/z00z_storage/scripts/run_storage_assets_nested_bench.sh
# rerun the same Phase 1 timing harness only if Phase 1 introduced one beyond the nested wrapper output
```

### 5.5 Completion Criteria

**✅ This workflow is complete only when all of the following are true:**

- the dominant nested hot path has been measured after each major phase
- time measurements and benchmark reruns were used throughout the workflow to track progress and verify that the chosen speedup direction stayed correct
- commit-side serialization has been reduced or explicitly proven to remain the wall
- incremental mode no longer hides an eager top-level `sem_root` recompute in the nested path
- `model.clone()` cost has been isolated and classified with evidence
- the final reports under `crates/z00z_storage/outputs/assets` match the final code revision

## 🚨 Stop Rules And Recovery Guidance

**📌 Stop the sequence and publish a blocker instead of continuing if any of the following occurs:**

- a commit-path refactor changes externally visible root or proof semantics
- incremental and full paths produce different semantic roots for the same state
- history optimization weakens versioned state guarantees
- benchmark numbers improve but the validation gates regress

> [!Warning]
> A faster benchmark with weaker semantics is a failed phase, not a successful optimization.

**📌 Recovery order when a phase fails:**

1. revert only the current phase changes
2. rerun the last green validation gate
3. keep the last valid report artifact
4. record the blocker and the exact failing command before starting another optimization branch

## ✅ Workflow Order Check

**📌 H2 and H3 sections are intentionally ordered by implementation dependency, not by topic grouping:**

1. measure the current wall first
2. reduce commit serialization first because it is the dominant measured bottleneck
3. remove eager incremental-path recompute second because it can only be interpreted correctly after commit-wall changes are known
4. isolate `model.clone()` third because its true share is only meaningful after the first two phases land
5. lock the final direction only after all refreshed measurements exist

**✅ No unresolved section-order blocker remains from the provided inputs.**
