# 🔑 JMT Migration Implementation Plan

## 🔑 Phase 1. Purpose

### 🎯 1.1 Planning Outcome And Scope Lock

**📌 This plan rewrites the direct backend migration workflow into implementation units that can be executed without reopening storage design.**

**📌 The semantic source of truth remains `specs/014-z00z-storage/jmt-storage-spec-gaps.md`. This plan must only define the work needed to move the active first-party storage path from the current workspace `jmt` usage to `crates.io jmt` while preserving the hierarchy contract already expressed by `AssetPath`, `StoreItem`, `ProofItem`, `AssetStateRoot`, `CheckRoot`, and `RootApi`.**

**📌 The implementation must extend the existing storage stack rooted in `crates/z00z_storage/src/assets/`. It must not introduce a new public backend abstraction layer unless the concrete port proves that the current storage API cannot be kept coherent without it.**

**📌 Completion means the repository can move directly into semantic implementation completion and acceptance against `jmt-storage-spec-gaps.md` without creating another migration-planning document.**

Acceptance conditions:

- the migration preserves the current hierarchy model shape: definition tree -> serial tree -> asset tree
- all first-party callers continue to consume typed storage types from `z00z_storage`
- no first-party crate outside `z00z_storage` imports backend `jmt` types
- no mandatory storage-spec section remains without an owning implementation unit, file target, and test gate

```mermaid
flowchart TD
    A[Spec And Contract Lock] --> B[Dependency Cutover]
    B --> C[Storage Port]
    C --> D[Wallet And Simulator Rewire]
    D --> E[Acceptance Closure]
    E --> F[Cleanup And Doc Lock]
```

Checklist:

- [x] Keep this plan implementation-only: preserve semantic rules in `specs/014-z00z-storage/jmt-storage-spec-gaps.md` and backend rollout rules here.
- [x] Use the current storage home in `crates/z00z_storage/src/assets/` as the only canonical implementation area for JMT storage work.
- [x] Keep `AssetPath`, `StoreItem`, `ProofItem`, `AssetStateRoot`, `CheckRoot`, and `RootApi` as the semantic anchors referenced throughout the implementation.
- [x] Reject any implementation step that requires a third migration spec instead of extending this plan.
- [x] Reject any implementation step that leaks `jmt` backend types outside `z00z_storage`.

## 🚩 Phase 2. Entry Conditions

### 🔑 2.1 Required Inputs And Repository Baseline

**📌 Implementation must start from the actual repository state, not from the archived vendor-first flow.**

**📌 The following files are mandatory inputs and must stay mutually consistent while the migration is executed:**

- `specs/014-z00z-storage/jmt-storage-spec-gaps.md`
- `Cargo.toml`
- `crates/z00z_storage/Cargo.toml`
- `crates/z00z_core/Cargo.toml`
- `crates/z00z_storage/src/assets/{keys.rs,model.rs,store.rs,types.rs,mod.rs}`

**📌 The current storage implementation is still flat at the concrete store layer. The reference hierarchy already exists in `AssetModel`, `StoreItem`, and `ProofItem`. The migration must use those existing reference types to guide the concrete backend port.**

**📌 Active workflow inputs were frozen against the current repository layout before implementation starts:**

- `specs/014-z00z-storage/jmt-migration-plan.md` is the surviving implementation and workflow record for execution order, stop rules, file ownership, and acceptance evidence
- the temporary workflow notes that previously lived under `specs/014-z00z-storage/tmp/` were retired after closure and must not remain referenced as live repository inputs
- no planned edit in this phase may touch `crates/z00z_crypto/tari/`

**📌 Mandatory sections extracted from the workflow traceability matrix for this implementation baseline are:**

- Phase 5 root semantics separation
- Phase 6 proposed tree layout
- Phase 7 terminal `asset_id` stability
- Phase 8 namespace resolution
- Phase 9 type integrity and identity cleanup
- Phase 10 tree namespace isolation
- Phase 11 public facade contract
- Phase 12 update algorithm and rollback handling
- Phase 13 version coordination
- Phase 14 proof model and witness bridge
- Phase 15 scan compatibility
- Phase 16 migration blockers and phase order
- Phase 17 module boundary contract
- Phase 18 mandatory test matrix and exit criteria
- Phase 19 implementation direction
- Phase 20 compliance gates and deferred questions

**📌 Initial compile baseline for this phase was frozen before logic changes begin with these commands, all passing on the current repository state:**

- `cargo check -p z00z_storage`
- `cargo check -p z00z_wallets`
- `cargo check -p z00z_simulator`

**📌 Verified infrastructure facts for the storage refactor are now fixed and must not be reopened during implementation:**

- the active backend is one in-memory `MemTreeStore`
- the existing write path already commits through one shared `Sha256Jmt::put_value_set(...)` batch boundary
- rollback already exists as full in-memory snapshot restore through `snap_store()` and `restore_store()`
- the private commit substrate is therefore fixed to one private `TreeStore` layered over one shared `MemTreeStore`, with one shared external transition version per committed state transition
- private write-ahead log or recovery-journal logic is explicitly out of scope for this refactor because there is no persistent backend to recover into yet

**📌 Benchmark acceptance is also fixed now so later phases cannot drift:**

- the repository currently has no `crates/z00z_storage/benches/` harness, so benchmark infrastructure must be introduced explicitly
- one pre-refactor baseline for the current single-JMT implementation must be stored before backend replacement begins
- final benchmark acceptance is not satisfied by re-running only that baseline capture; it requires harness-defined serialized and shard-parallel nested-JMT runs plus one published comparison report

Entry conditions:

- the archived vendor-first spec is treated as historical only
- `jmt-storage-spec-gaps.md` remains the semantic target
- the active first-party backend cutover is restricted to `z00z_storage`, `z00z_wallets`, and `z00z_simulator`
- vendored Tari sources under `crates/z00z_crypto/tari/` remain untouched

### 👁️‍🗨️ 2.2 Consolidated Archive Of Former Phase 1-4 Notes

**📌 The former standalone Phase 1-4 planning notes are retired. The still-relevant repository baseline from those notes is consolidated here so the active spec set stays self-contained.**

**📌 Former Phase 1 scope lock, now archived into this plan:**

- the migration boundary is the asset-storage subtree only
- the canonical deliverable is one asset-state root over `definition_id -> serial_id -> asset_id`
- rejected deliverables are a best-effort parallel index, a sidecar root that is not the canonical asset-state root, and any scope expansion that folds checkpoints, nullifiers, or rollup metadata into this storage contract
- the touched first-party crate set frozen for this migration is `z00z_storage`, `z00z_wallets`, `z00z_simulator`, and `z00z_core`
- the old task-class split of `storage`, `proof`, and `adapters` is retained only as historical traceability for implementation ownership; it is no longer a live gating artifact

**📌 Former Phase 2 repository-audit findings, now archived into this plan:**

- the workflow-start concrete backend was one flat JMT keyed only by terminal `asset_id`
- the direct first-party migration rule is now frozen: first-party crates use only crates.io `jmt`, while any remaining `tari_jellyfish` usage is a vendored-Tari-only exception inside the read-only Tari subtree
- the historical alias family that motivated the migration was repository-wide, not local to storage: `definition.id` was repeatedly treated as if it were terminal `asset_id`, and `tx_digest_hex` was transported through root-adjacent fields such as `prev_root_hex` and `input_tx_digest_hex`
- migration closure requires removing both wrong producers and wrong adapter repairs; renamed fields alone are not sufficient if the old equality still survives semantically

**📌 Former Phase 3 blocker-map findings, now archived into this plan:**

- the blocked properties at workflow start were missing definition namespace, missing per-definition serial subtree, flat proof shape, digest-to-root substitution, and ambiguous witness/root binding
- each blocked property required a failing-test gate before the runtime fix was accepted
- partial rollout was and remains forbidden: hierarchy layout, proof shape, witness binding, and checkpoint-root consumers must move together
- every ambiguous 32-byte value remains a typed migration risk until the storage-owned path, root, and proof boundaries remove the alias class end to end

**📌 Former Phase 4 frozen target-model findings, now archived into this plan:**

- the canonical public path is `AssetPath { definition_id, serial_id, asset_id }`
- `definition_id` is the only accepted consensus namespace key; display `symbol`, `AssetClass`, and registry order are forbidden as path coordinates
- `AssetLeaf` remains the terminal committed payload for this migration
- path integrity requires `AssetLeaf.asset_id` and `AssetLeaf.serial_id` to agree with the enclosing `AssetPath`
- only `AssetStateRoot` is exported as the public state-root type; child roots remain encapsulated inside `DefinitionRootLeaf` and `SerialRootLeaf`
- reference-vector coverage must prove that shared `serial_id` values across definitions and within one definition remain unambiguous under the typed path model

Checklist:

- [x] Read `specs/014-z00z-storage/jmt-storage-spec-gaps.md` before starting code edits and extract the mandatory sections listed in the workflow traceability matrix.
- [x] Treat `specs/014-z00z-storage/jmt-migration-plan.md` as the surviving execution contract for phase ordering, stop rules, and file ownership after migration closure.
- [x] Retire the temporary migration workflow notes under `specs/014-z00z-storage/tmp/` after closure so no deleted file remains referenced as an active implementation input.
- [x] Verify that no planned edit touches `crates/z00z_crypto/tari/`.
- [x] Freeze the initial compile state for `z00z_storage`, `z00z_wallets`, and `z00z_simulator` before logic changes begin.

## 👁️‍🗨️ Phase 3. Current Codebase Facts

### 🔑 3.1 Existing Storage Surface To Preserve

**📌 The concrete backend is currently implemented in `crates/z00z_storage/src/assets/store.rs` through `AssetStore`, `StoreOp`, private flat JMT helpers, and `apply_ops`.**

**📌 The semantic storage model already exists in:**

- `crates/z00z_storage/src/assets/types.rs`: `DefinitionId`, `AssetId`, `SerialId`, `AssetPath`, `AssetStateRoot`, `CheckRoot`, `StoreItem`, `ProofItem`, `RootApi`
- `crates/z00z_storage/src/assets/model.rs`: `AssetModel::{put_leaf, root, proof_case, del_leaf}`
- `crates/z00z_storage/src/assets/keys.rs`: `def_key`, `ser_key`, `asset_key`

**📌 The downstream state pipeline already exposes storage-facing hooks that the migration must satisfy without backend leakage:**

- `crates/z00z_wallets/src/core/tx/state_update.rs`: `AssetState`, `MemberIdx`, `TxProofChk`, `SpentIdx`
- `crates/z00z_wallets/src/core/tx/witness_gate.rs`: canonical `asset_id` generation and `CheckRoot` binding
- `crates/z00z_wallets/tests/{test_tx_spent_gate.rs,test_phase24_gate.rs,test_tx_wrong_root.rs}` and internal wallet tx test modules: direct `CheckRoot` imports that must stay aligned with typed-root rewiring
- `crates/z00z_simulator/src/claim_pkg_consumer.rs`: storage facade usage that must stay narrowed to `z00z_storage::assets` re-exports rather than `store::{...}` submodule imports
- `crates/z00z_simulator/src/scenario_1/stage_4.rs`: current root and identity bridging code that must stop treating `definition.id` and terminal `asset_id` as interchangeable and must stop using tx-digest stand-ins as storage-root fixtures
- `crates/z00z_simulator/src/scenario_1/stage_6.rs`: current checkpoint-prep state code that must continue deriving `CheckRoot` through storage-owned compatibility-root helpers instead of simulator-local raw-byte relabeling

**📌 Current preservation inventory confirmed from the active codebase:**

- `crates/z00z_storage/src/assets/model.rs` already exposes the reference oracle surface through `AssetModel::{put_leaf, root, proof_case, del_leaf}`
- `crates/z00z_storage/src/assets/types.rs` already owns the typed semantic anchors `DefinitionId`, `AssetId`, `SerialId`, `AssetPath`, `AssetStateRoot`, `CheckRoot`, `StoreItem`, `ProofItem`, and `RootApi`
- `crates/z00z_storage/src/assets/keys.rs` already owns the key-derivation entry points `def_key`, `ser_key`, and `asset_key`
- `crates/z00z_wallets/src/core/tx/state_update.rs` currently imports `AssetId`, `AssetLeaf`, and `CheckRoot`, and its `AssetState`, `MemberIdx`, `TxProofChk`, and `SpentIdx` traits still operate on terminal `AssetId` and typed roots rather than on `AssetPath`
- `crates/z00z_wallets/src/core/tx/witness_gate.rs` currently imports `CheckRoot` and derives canonical terminal `asset_id` values from `s_in`
- `crates/z00z_wallets/tests/test_tx_spent_gate.rs`, `crates/z00z_wallets/tests/test_phase24_gate.rs`, and `crates/z00z_wallets/tests/test_tx_wrong_root.rs` currently import `CheckRoot` directly for typed-root checkpoint and wrong-root coverage
- `crates/z00z_wallets/src/core/tx/spending.rs` currently imports `CheckRoot` inside wallet tx test modules that exercise spend-proof root binding
- `crates/z00z_simulator/src/claim_pkg_consumer.rs` currently imports `AssetStore`, `StoreOp`, and typed path components through `z00z_storage::assets`, builds `StoreOp::Put(StoreItem)` batches, and publishes them through `AssetStore::apply_ops`
- `crates/z00z_simulator/src/scenario_1/stage_4.rs` currently imports `AssetId as StorAssetId`, `CheckRoot`, `CompatRoot`, `RootApi`, `RootRec`, and `SerialId as StorSerialId` from `z00z_storage::assets::types`
- `crates/z00z_simulator/src/scenario_1/stage_6.rs` currently imports storage root types and derives checkpoint-state roots through storage-owned `CompatRoot`/`RootRec` helpers instead of simulator-local raw-byte relabeling
- `crates/z00z_simulator/tests/test_claim_tx_pipeline.rs` currently imports `AssetStore` and typed identifiers through the narrowed `z00z_storage::assets` facade in integration coverage

Checklist:

- [x] Preserve `AssetModel` as the reference oracle for root and proof semantics during the port.
- [x] Preserve `AssetPath` as the canonical storage address and stop using bare `asset_id` alone as the final proof request shape.
- [x] Preserve typed roots through `AssetStateRoot` and `CheckRoot`; do not collapse them into raw byte arrays in new code.
- [x] Preserve key derivation entry points in `crates/z00z_storage/src/assets/keys.rs` and extend them only if tree namespace isolation requires additional internal helpers.
- [x] Record every current downstream import of `AssetStore`, `StoreOp`, `AssetId`, `CheckRoot`, and proof-related types before refactoring those surfaces.

### 🚨 3.2 Current Gaps To Close During Migration

**📌 The public storage facade is now path-aware through `AssetStore::{put_item, get_item, del_item, proof_item, apply_ops}`. The remaining gap is that the concrete backend below that facade is still one flat asset-id keyed JMT leaf store, with `AssetModel` acting as the semantic oracle for typed root and proof-item construction.**

**📌 `ProofItem` is currently a semantic proof-facing record in `crates/z00z_storage/src/assets/types.rs`, not a complete branch-proof byte container. The migration must keep `ProofItem` as the typed semantic contract while defining one storage-owned canonical witness-proof codec for the aggregate branch proof bytes needed by `MemberWit.proof`.**

**📌 `crates/z00z_simulator/src/claim_pkg_consumer.rs` now imports storage types through `z00z_storage::assets` re-exports. The migration must keep that narrowed facade and avoid reintroducing direct `store::{...}` submodule imports downstream.**

**📌 `crates/z00z_wallets/src/core/tx/state_update.rs` currently consumes `CheckRoot` through `AssetState::root()` and compact input references based on `asset_id_hex`. The migration must preserve this wire compactness while ensuring full typed path resolution at the storage boundary.**

**📌 Root relabeling must stay centralized. Wallet and simulator adapters must obtain `CheckRoot` from the storage-owned root-provider path, not by ad-hoc raw-byte relabeling or local `CheckRoot::new(...)` reconstruction from arbitrary 32-byte values.**

**📌 The migration must not widen `AssetState`, `MemberIdx`, `SpentIdx`, or `TxProofChk` into path-aware traits during this backend cutover. Path resolution must happen inside the storage adapter boundary that serves those hooks, so wallet checkpoint logic keeps its current narrow integration surface.**

**📌 This path resolution must not depend on new public wire fields, because current wallet and checkpoint inputs carry terminal `asset_id_hex` and `serial_id`, but not `definition_id`. The storage layer must therefore own one private canonical path-resolution rule for recovering `AssetPath` from terminal identity inputs.**

**📌 `crates/z00z_simulator/src/scenario_1/stage_4.rs` no longer rewrites `wire.definition.id` inline. Stage-4 outputs now bind decrypt identity explicitly through `crates/z00z_core/src/assets/wire.rs::AssetWire.leaf_ad_id` and `crates/z00z_wallets/src/core/tx/output_flow.rs::bind_output_wire()`, while positive-path witness-gate checks no longer use `CheckRoot::new(tx_digest)` stand-ins.**

**📌 `crates/z00z_simulator/src/scenario_1/stage_4.rs` input selection no longer treats plain rows or missing stealth fields as canonical terminal-id carriers. Non-stealth or undecryptable rows are filtered out before spend selection, and the prior Stage-4 identity-mixing bug class was removed by separating terminal spend/state identity from decrypt/scan identity for imported claim rows. The remaining Stage-3 restart/auth regression was traced to `AssetWire.leaf_ad_id` using `skip_serializing_if = "Option::is_none"`, which broke bincode roundtrips for claimed-asset snapshots; after removing that omission on the binary wire path, Scenario-1 release e2e (`stage34_ok`) is green again.**

**📌 `crates/z00z_wallets/src/core/tx/witness_gate.rs` now encodes that contract split explicitly: `asset_wire_to_leaf()` remains the canonical terminal/state leaf path, `resolve_input_pack()` performs sender-side input recovery only through the explicit decrypt leaf contract, and `wire_decrypt_leaf()` now requires explicit `leaf_ad_id` instead of reviving any `definition.id` fallback.**

**📌 `crates/z00z_simulator/src/scenario_1/stage_6.rs` now rebuilds checkpoint roots through storage-owned `CompatRoot`/`RootRec` helpers over the prep rows and mutable leaf set. Any future root reconstruction in this flow must continue to go through that storage-owned compatibility-root path.**

**📌 Current gap callsites confirmed from the active codebase:**

- `crates/z00z_storage/src/assets/store.rs` now exposes the path-aware public methods `put_item`, `get_item`, `del_item`, `proof_item`, and `apply_ops`, while keeping flat JMT helpers private behind the facade
- `crates/z00z_storage/src/assets/store.rs` now exposes `StoreOp::{Put, Delete}` and `AssetStore::proof_item(&AssetPath)` as the current proof and mutation surface
- `crates/z00z_storage/src/assets/store.rs` now keeps the canonical `asset_id -> AssetPath` binding map private and resolves stored paths from that storage-owned rule before path-aware reads, deletes, and proof lookups
- `crates/z00z_wallets/src/core/tx/state_update.rs` still resolves membership and deletion through `AssetId`, `asset_id_hex`, and `CheckRoot`, without any public `AssetPath`-aware storage boundary yet
- `crates/z00z_simulator/src/claim_pkg_consumer.rs` now builds direct `StoreOp::Put(StoreItem)` batches and publishes them with `AssetStore::apply_ops` through the narrowed `z00z_storage::assets` facade
- `crates/z00z_wallets/src/core/tx/output_flow.rs` now binds decrypt identity explicitly through `bind_output_wire()` and `AssetWire.leaf_ad_id`; scattered inline rewrites of `wire.definition.id = out.leaf.asset_id` were removed from simulator and wallet helpers
- `crates/z00z_simulator/src/scenario_1/stage_4_utils/persistence.rs` now sends canonical `Asset::asset_id()` into `asset.send`, instead of forwarding `definition.id` through the public `asset_id` argument
- `crates/z00z_simulator/src/scenario_1/stage_4.rs` now skips non-stealth or undecryptable rows during sender-input selection instead of treating `definition.id` as a canonical terminal-id fallback; the canonical selection fix is in place, and the follow-on Stage-3 restart/auth regression was fixed by preserving the `leaf_ad_id` `Option` discriminant in `AssetWire` bincode serialization so claimed-asset snapshots reopen cleanly after restart
- `crates/z00z_simulator/src/scenario_1/stage_4.rs` now derives positive-path witness-gate roots from storage-owned `CompatRoot` rows instead of `CheckRoot::new(tx_digest)` fixtures
- `crates/z00z_simulator/src/scenario_1/stage_6.rs` now derives `CheckRoot` from storage-owned compatibility-root helpers in checkpoint prep and inside `SimState`
- `crates/z00z_simulator/tests/test_claim_tx_pipeline.rs` now validates inserted rows through `AssetStore::get_item(&AssetPath)` instead of the old flat `asset_id` lookup shape
- `crates/z00z_wallets/src/core/tx/witness_gate.rs` now separates canonical terminal/state leaf recovery from decrypt/scan recovery through `resolve_input_pack()` and `wire_decrypt_leaf()` so stage-3 claim imports and stage-4 outputs can be read without reintroducing `definition.id` fallback into canonical spend selection

**Checklist:**

- [x] Replace asset-id-only storage proof entry points with path-aware storage entry points that can build `ProofItem`.
- [x] Replace direct downstream reliance on `store::{AssetStore, StoreOp}` with `z00z_storage::assets` re-exports or a narrower facade defined in `mod.rs`.
- [x] Keep `TxInputWire.asset_id_hex` as a terminal wire identifier while moving typed path resolution into storage-facing adapters.
- [x] Eliminate any remaining call path that substitutes a tx digest for a typed asset-state root.
- [x] Eliminate Stage-4 bridge code that rewrites `definition.id` to terminal `asset_id` by carrying decrypt identity explicitly through wire-owned `leaf_ad_id`.
- [x] Keep wallet checkpoint traits narrow and flat; do not introduce new path-aware trait signatures in `crates/z00z_wallets/src/core/tx/state_update.rs` for this migration.
- [x] Define one storage-owned private path-resolution rule for callers that only provide terminal identity data.
- [x] Define one storage-owned root-provider path so downstream adapters derive `CheckRoot` from `AssetStateRoot` through typed storage conversion rather than through ad-hoc raw-byte relabeling.
- [x] Keep canonical spend selection strict while routing decrypt/scan identity through wallet-owned adapter helpers instead of reintroducing `definition.id` fallback into canonical input identity.

## 🚩 Phase 4. Workflow Overview

### ⚙️ 4.1 Execution Order And Rollback Boundaries

**📌 Work must follow six implementation stages derived from the seven workflow phases: contract lock, dependency cutover, storage port, downstream rewiring, acceptance closure, and cleanup lock.**

**📌 Each stage must end in one explicit rollback boundary:**

- Stage A: documentation-only green state
- Stage B: compile inventory green state
- Stage C: `z00z_storage` test green state
- Stage D: wallet and simulator targeted test green state
- Stage E: release acceptance green state
- Stage F: post-cleanup doc and dependency green state

**📌 If a stage fails, revert only to the last green boundary. Do not keep partial fixes from later stages mixed into earlier boundaries.**

**📌 Current workflow status is no longer Stage A only. The current repository state has reached these rollback boundaries:**

- Stage A: green through the planning and workflow documents in this spec set
- Stage B: green through `cargo check -p z00z_storage`, `cargo check -p z00z_wallets`, and `cargo check -p z00z_simulator`
- Stage C: green through `cargo test -p z00z_storage`
- Stage D: green through downstream wallet and simulator rewires, including the targeted release-mode regressions exercised during Phase 9
- Stage E: green through `cargo test --release --features test-fast --features wallet_debug_dump`

**📌 Later rollback boundaries must stay unchecked until their concrete compile or test gates actually run green.**

```mermaid
sequenceDiagram
    participant Doc as Docs
    participant Cargo as Cargo Graph
    participant Store as z00z_storage
    participant Down as Wallet+Simulator
    participant Test as Acceptance
    Doc->>Cargo: lock contract and targets
    Cargo->>Store: expose mismatch inventory
    Store->>Down: publish typed facade and proof API
    Down->>Test: run targeted rewired flows
    Test->>Doc: lock cleanup and status updates
```

Checklist:

- [x] Finish documentation alignment before changing manifests or code.
- [x] Freeze compiler mismatch inventory immediately after the dependency cutover.
- [x] Complete `z00z_storage` API and test work before rewriting wallet and simulator call sites.
- [x] Run targeted downstream tests before release-wide acceptance.
- [x] Perform cleanup and doc-lock work only after acceptance is green.

### 👁️‍🗨️ 4.2 Traceability Ownership Matrix

**📌 Every mandatory implementation section from `jmt-storage-spec-gaps.md` must map to one concrete owner in this plan.**

Ownership rules:

- Phase 5 root semantics separation: `crates/z00z_storage/src/assets/types.rs`, `crates/z00z_wallets/src/core/tx/{state_update.rs,witness_gate.rs}`, `crates/z00z_simulator/src/scenario_1/{stage_4.rs,stage_6.rs}`, and the wallet wrong-root checkpoint tests
- Phase 6 proposed tree layout: `crates/z00z_storage/src/assets/{keys.rs,store.rs,types.rs,tests.rs}`
- Phase 7 terminal `asset_id` stability: `crates/z00z_wallets/src/core/tx/{claim_tx.rs,witness_gate.rs}`, `crates/z00z_simulator/src/{claim_pkg_consumer.rs,scenario_1/stage_4.rs}`, and downstream claim-pipeline tests
- Phase 8 namespace resolution: `crates/z00z_wallets/src/core/tx/{claim_tx.rs,witness_gate.rs,lifecycle.rs}`, `crates/z00z_simulator/src/{claim_pkg_consumer.rs,scenario_1/stage_3.rs,scenario_1/stage_4.rs}`, and `crates/z00z_storage/src/assets/types.rs`
- Phase 9 type integrity and identity cleanup: `crates/z00z_storage/src/assets/{types.rs,keys.rs}`, wallet tx adapters, simulator checkpoint adapters, and identity-mismatch tests
- Phase 10 tree namespace isolation: `crates/z00z_storage/src/assets/{store.rs,tests.rs}` and any private backend-compat helper extracted under `crates/z00z_storage/src/assets/`
- Phase 11 public facade contract: `crates/z00z_storage/src/{lib.rs,assets/mod.rs,assets/store.rs,assets/types.rs}` plus every downstream crate that currently imports `z00z_storage::assets` internals directly
- Phase 12 update algorithm and rollback handling: `crates/z00z_storage/src/assets/{store.rs,model.rs,tests.rs}`
- Phase 13 version coordination: `crates/z00z_storage/src/assets/{store.rs,tests.rs}` and any private backend-compat helper that owns version translation
- Phase 14 proof model and witness bridge: `crates/z00z_storage/src/assets/{types.rs,store.rs,mod.rs}`, `crates/z00z_wallets/src/core/tx/{state_update.rs,witness_gate.rs,spending.rs}`, and `crates/z00z_simulator/src/scenario_1/{stage_4.rs,stage_6.rs}`
- Phase 15 scan compatibility: wallet scan and witness paths in `crates/z00z_wallets/src/core/tx/` plus simulator claim-pipeline fixtures that consume canonical `asset_id`
- Phase 16 migration blockers and phase order: the rollback boundaries in this plan plus the named storage, wallet, and simulator callsites tracked across `crates/z00z_storage`, `crates/z00z_wallets`, and `crates/z00z_simulator`
- Phase 17 module boundary contract: `crates/z00z_storage/src/{lib.rs,assets/mod.rs}` and every downstream crate that currently imports `z00z_storage::assets` internals directly
- Phase 18 mandatory test matrix and exit criteria: `crates/z00z_storage` tests, `crates/z00z_wallets` tests, `crates/z00z_simulator` tests, and the acceptance command gates recorded in this plan
- Phase 19 implementation direction: the coordinated storage, wallet, and simulator owner buckets listed above, with final acceptance tied back to the definition-tree -> serial-tree -> asset-tree model
- Phase 20 compliance gates and deferred questions: this plan and the final acceptance evidence attached to the same owner buckets

Checklist:

- [x] Keep a one-to-one mapping between each mandatory storage-spec section and at least one file owner listed in this plan.
- [x] Reject any implementation PR that introduces a new storage behavior without attaching it to an existing owner bucket.
- [x] Add or update tests in the same owner bucket as the behavior being changed.
- [x] Keep acceptance evidence attached to the owner bucket instead of storing it only in prose.

Current owner-bucket evidence:

- Phase 6 proposed tree layout / Phase 10 tree namespace isolation / Phase 12 update algorithm and rollback handling / Phase 13 version coordination:
    `crates/z00z_storage/src/assets/{store.rs,tests.rs}`
    Evidence: `cargo check -p z00z_storage` green; `cargo test -p z00z_storage` green; path-binding coverage lives in `assets::store::tests::{test_get_rejects_same_asset_wrong_path,test_path_resolution_uses_asset_binding}`.
- Phase 7 terminal `asset_id` stability / Phase 8 namespace resolution / Phase 15 scan compatibility:
    `crates/z00z_wallets/src/core/tx/{witness_gate.rs,output_flow.rs}` and `crates/z00z_simulator/src/{claim_pkg_consumer.rs,scenario_1/stage_4.rs}`
    Evidence: `cargo check -p z00z_wallets` green; `cargo test -p z00z_wallets --release --test test_s5_spec6_bridge --quiet` green; `cargo check -p z00z_simulator` green; `cargo test -p z00z_simulator --release --test test_claim_tx_pipeline --quiet` green; `cargo test -p z00z_simulator --test test_claim_tx_pipeline --release --features test-fast -- --nocapture` green.
- Phase 14 proof model and witness bridge / Phase 18 mandatory test matrix and exit criteria / Phase 20 compliance gates and deferred questions:
    `crates/z00z_storage/src/assets/{types.rs,store.rs,mod.rs}`, `crates/z00z_wallets/src/core/tx/{state_update.rs,witness_gate.rs,spending.rs}`, and `crates/z00z_simulator/src/scenario_1/{stage_4.rs,stage_6.rs}`
    Evidence: `cargo test -p z00z_simulator --release --features test-fast deterministic_outputs_same_seed -- --exact --nocapture` green; required acceptance command `cargo test --release --features test-fast --features wallet_debug_dump` green.

## ⚙️ Phase 5. Spec Realignment

### 🔑 5.1 Documentation Canonicalization

**📌 This stage is doc-only. It must declare which documents are active and which are historical.**

Canonical document roles:

- `specs/014-z00z-storage/jmt-storage-spec-gaps.md`: semantic contract
- `specs/014-z00z-storage/jmt-migration-plan.md`: surviving workflow, implementation, and acceptance record

**📌 The temporary migration workflow notes that previously lived under `specs/014-z00z-storage/tmp/` were retired after closure. They are no longer required runtime repository inputs and must not be referenced as active workflow authorities.**

**📌 The plan must preserve backend-agnostic rules for path semantics, terminal `asset_id`, proof shape, and root typing, while classifying version behavior, stale-node handling, and adapter shape as backend-validation work.**

Checklist:

- [x] Retire temporary migration workflow notes under `specs/014-z00z-storage/tmp/` after closure so no deleted file remains referenced as active authority.
- [x] Keep `specs/014-z00z-storage/jmt-storage-spec-gaps.md` as the only semantic source of truth.
- [x] Keep `specs/014-z00z-storage/jmt-migration-plan.md` as the surviving workflow, stop-rule, and acceptance contract after closure.
- [x] Keep this plan focused on implementation units, file targets, acceptance checkpoints, and final workflow status.
- [x] Record in docs that `AssetPath`, `ProofItem`, and typed roots are backend-agnostic and must survive the port unchanged.

### ⚙️ 5.2 Deferred-Question Freeze For Implementation

**📌 Implementation must start with the deferred questions already frozen to the answers established by the migration workflow.**

Frozen decisions:

- use one shared transition version contract; do not add separate public per-tree version semantics
- use one private `TreeStore` over one shared `MemTreeStore`; do not introduce WAL, recovery-journal logic, or per-tree independent durable transactions in this refactor
- keep `TxInputWire.asset_id_hex` as a terminal asset identifier at the wire boundary only
- keep `AssetDefinition.id` and cryptographic `asset_id` separated; do not treat them as interchangeable in any adapter
- bind typed asset-state roots through storage-root providers before acceptance begins
- normalize multi-serial containers into one committed leaf per `(definition_id, serial_id, asset_id)` path or reject them before storage
- treat the current single-JMT benchmark capture as Phase-1 baseline evidence only; final benchmark acceptance additionally requires harness-defined `nested_jmt_serial` and `nested_jmt_parallel` runs plus a published report

Acceptance bindings for frozen decisions:

- shared transition version is carried forward into Phase 13 version-coordination tasks and acceptance gates; no later phase may introduce public per-tree version semantics without updating this plan first
- the fixed shared-store `TreeStore` substrate carries forward into Phase 8 atomicity rules and Phase 10 acceptance gates; no later phase may reintroduce per-tree partial commits, WAL, or durable journal semantics without updating this plan first
- `TxInputWire.asset_id_hex` stays at the wire boundary only, while Phase 9 and Phase 15 adapter and acceptance tasks must prove typed `AssetPath` resolution before storage proof lookup
- `AssetDefinition.id` and cryptographic `asset_id` remain separated through the Phase 9 and Phase 15 identity-cleanup and scan-compatibility tasks; later acceptance must fail if adapters treat them as interchangeable
- typed asset-state roots are bound through storage-owned root providers in the Phase 14 witness bridge and the Phase 18 acceptance matrix; later acceptance must fail if tx digest bytes are reused as typed storage roots
- multi-serial containers remain outside direct storage writes; later storage-boundary tasks must normalize them into one `(definition_id, serial_id, asset_id)` leaf path or reject them before commit
- benchmark closure carries forward into Phase 10 acceptance gates; later acceptance must fail if it relies only on the `current_single_jmt` baseline capture without the nested serialized and shard-parallel evidence and one published comparison report

Checklist:

- [x] Encode these deferred-question answers into the implementation plan and acceptance tests before code edits start.
- [x] Reject any migration patch that changes public API shape, root binding, witness format, or terminal-key semantics without updating this plan first.
- [x] Reject any storage adapter that accepts ambiguous `definition.id` versus `asset_id` identity input.
- [x] Reject any state-update adapter that accepts raw tx digests where `AssetStateRoot` or `CheckRoot` is required.

## ⚙️ Phase 6. Backend Contract Definition

### 🔑 6.1 Private Backend Compatibility Boundary

**📌 The compatibility boundary must be derived from the current private usage surface in `crates/z00z_storage/src/assets/store.rs`.**

Required compatibility topics:

- `LeafKey` generation for definition, serial, and asset trees
- `jmt_node_hash` or equivalent value-hash behavior
- `JellyfishMerkleTree::<_, Vec<u8>>::batch_put_value_set` mapping
- `get_with_proof` mapping
- `TreeUpdateBatch<Vec<u8>>` application
- stale-node recording through `record_stale_tree_node`
- version progression through `persisted_ver` and `next_ver`

Canonical implementation rule:

- keep the compatibility boundary private inside `store.rs` unless API mismatch volume forces extraction into `crates/z00z_storage/src/assets/jmt_compat.rs`
- do not create a new public trait for backend polymorphism in this migration

**📌 Verified current private backend surface from `crates/z00z_storage/src/assets/store.rs`:**

- direct backend storage imports: `LeafNode`, `Node`, `NodeKey`, `StaleNodeIndex`, `TreeReader`, `TreeUpdateBatch`, `TreeWriter`
- direct backend hash and version imports: `KeyHash`, `RootHash`, `Sha256Jmt`, `ValueHash`, `Version`
- direct backend proof type usage remains private and test-only through `jmt::proof::SparseMerkleProof<Sha256>`
- concrete backend calls currently used: `Sha256Jmt::new`, `put_value_set`, `get_with_proof`, `TreeWriter::write_node_batch`, `TreeReader::{get_node_option,get_value_option,get_rightmost_leaf}`
- private compatibility helpers already present in `store.rs`: `key_from_id`, `val_hash`, `next_ver`, `apply_batch`, and `map_jmt_err`

**📌 Current contract decision for this phase:**

- keep the compatibility surface private inside `store.rs`; the current mismatch surface is small enough that `jmt_compat.rs` is not justified yet
- keep `AssetStore` as the concrete storage entry point; no public backend trait is needed for the current first-party rollout
- keep `StoreItem`, `ProofItem`, `AssetPath`, `AssetStateRoot`, `CheckRoot`, and `RootApi` unchanged as the public semantic contract while backend calls remain private

Checklist:

- [x] Inventory every current `jmt` type and function used in `crates/z00z_storage/src/assets/store.rs`.
- [x] Map each current usage to the exact `crates.io jmt` equivalent or to one private wrapper function.
- [x] Keep wrapper helpers private to `store.rs` unless extraction to a private `jmt_compat.rs` module becomes necessary.
- [x] Preserve `AssetStore` as a concrete first-party storage entry point unless the port proves that a narrower facade is easier to keep stable.
- [x] Preserve `StoreItem`, `ProofItem`, `AssetPath`, `AssetStateRoot`, `CheckRoot`, and `RootApi` as the public semantic contract.

### 👁️‍🗨️ 6.2 Backend Contract Table And Mismatch List

**📌 Before storage edits begin, create a concrete mismatch table that lists each used current API, the `crates.io jmt` replacement, and the adapter action.**

Required output fields per mismatch row:

- current import or callsite
- target import or callsite
- adapter location
- behavior that must remain identical
- test that proves the behavior

**📌 Verified backend contract table for the current `store.rs` surface:**

| Current import or callsite | Target import or callsite | Adapter location | Behavior that must remain identical | Test that proves the behavior |
| --- | --- | --- | --- | --- |
| `asset_key(asset_id) -> KeyHash` through `key_from_id` | same `asset_key(asset_id) -> KeyHash` on `crates.io jmt` `KeyHash` | private `key_from_id` in `store.rs` | terminal `asset_id` stays the backend key source for the flat asset tree | `assets::store::tests::test_asset_id_leaf_split` |
| `ValueHash::with::<Sha256>(payload)` through `val_hash` | same `ValueHash::with::<Sha256>(payload)` | private `val_hash` in `store.rs` | committed leaf value hash stays stable for the same serialized `AssetLeaf` bytes | `assets::store::tests::test_asset_hash_bytes` |
| `Sha256Jmt::new(&flat_store)` | same `Sha256Jmt::new(&flat_store)` | direct private call in `put_flat`, `get_flat`, `del_flat`, and test-only proof helpers | concrete backend remains a private store-owned JMT instance, not a public dependency | `assets::store::tests::test_insert_and_get` |
| `put_value_set([(key_hash, Some(payload))], version)` | same `put_value_set` call | direct private call in `put_flat`; `apply_batch` remains the write-commit wrapper | batch put returns the root plus `TreeUpdateBatch` that is committed without semantic drift | `assets::store::tests::test_insert_and_get` |
| `put_value_set([(key_hash, None)], version)` | same delete-through-`put_value_set` call | direct private call in `del_flat`; `apply_batch` remains the write-commit wrapper | delete semantics and resulting root progression stay identical | `assets::store::tests::test_delete_removes_leaf` |
| `get_with_proof(key_from_id(*asset_id), flat_version)` for reads | same `get_with_proof` call | direct private call in `get_flat` | read path must decode the same leaf bytes and reject key/leaf mismatch through `chk_leaf` | `assets::store::tests::test_insert_and_get` and `assets::store::tests::test_get_rejects_mixed_payload` |
| `get_with_proof(key_from_id(*asset_id), flat_version)` for proof extraction | same `get_with_proof` call returning `SparseMerkleProof<Sha256>` | private test-only helpers `get_flat_proof` and `get_proof_flat` | backend proof type stays private while public proof semantics remain in `ProofItem` | `assets::store::tests::test_get_proof_valid` |
| `TreeWriter::write_node_batch(&batch.node_batch)` | same writer call on `crates.io jmt` node batches | private `MemTreeStore::write_tree_update_batch` | node batch application order and stored values must remain stable | `assets::store::tests::test_apply_batch_writes_value` |
| `batch.stale_node_index_batch` ingestion into `stale_nodes` | same stale-node batch field on `TreeUpdateBatch` | private `MemTreeStore::write_tree_update_batch` | stale-node recording must stay lossless across batch commit | `assets::store::tests::test_apply_batch_tracks_stale` |
| `next_ver(flat_version)` using `Version::saturating_add(1)` | same `Version` increment rule | private `next_ver` in `store.rs` | persisted version progression stays monotonic and saturating | `assets::store::tests::test_next_ver_edges` |
| backend errors returned by `put_value_set`, `get_with_proof`, and writer calls | same backend errors mapped into `AssetStoreError::Jmt(String)` | private `map_jmt_err` in `store.rs` | backend failures must cross the public boundary only through `AssetStoreError` | `assets::store::tests::test_map_jmt_error` |

**📌 Verified mismatch list for the current backend contract:**

- historical local `JellyfishMerkleTree` naming is now represented by `Sha256Jmt`; the required behavior is identical, so no public adapter is needed
- proof bytes still come from backend `SparseMerkleProof<Sha256>`, but the public semantic proof surface remains `ProofItem`; backend proof objects must therefore stay private or test-only until the witness codec phase
- backend error types are intentionally erased into `AssetStoreError::Jmt(String)` by `map_jmt_err`; this keeps backend-specific error types from leaking outside `z00z_storage`
- `TreeUpdateBatch` field layout is consumed directly through `node_batch` and `stale_node_index_batch`; any future backend delta here is the exact trigger for extracting a private `jmt_compat.rs`
- no current mismatch requires a public trait or a new public module; the existing private helpers inside `store.rs` are the approved compatibility boundary for this phase

Checklist:

- [x] Record the current `store.rs` backend imports and map the historical `JellyfishMerkleTree`/`LeafKey`/`TreeStore*` naming to the current `crates.io jmt` surface.
- [x] Record the target `crates.io jmt` equivalents or mark a local wrapper as required.
- [x] Identify any mismatch in error types and plan exact conversion into `AssetStoreError`.
- [x] Identify any mismatch in `TreeUpdateBatch<Vec<u8>>` field layout before editing write logic.
- [x] Identify any mismatch in proof return types before editing `get_proof` or introducing a path-aware proof API.

## ⚙️ Phase 7. Dependency Cutover

### ⚙️ 7.1 Manifest Changes And Compile Inventory

**📌 Manifest work must stop at compile inventory before storage logic changes begin.**

Target files:

- `Cargo.toml`
- `crates/z00z_storage/Cargo.toml`
- `crates/z00z_core/Cargo.toml`

Required dependency rules:

- first-party crates in this repository must consume JMT only from `crates.io jmt`; do not keep any first-party alias, path override, or vendored `tari_jellyfish` fallback for Z00Z-owned crates
- `tari_jellyfish` is tolerated only inside the read-only vendored Tari subtree under `crates/z00z_crypto/tari/`; that exception does not apply to first-party crates such as `z00z_storage`, `z00z_wallets`, `z00z_simulator`, `z00z_core`, or other Z00Z-owned crates
- keep Tari crypto dependencies unchanged
- remove first-party `jmt` dependency from `crates/z00z_core/Cargo.toml` only if compile inventory proves it is unused
- do not edit vendored Tari manifests or sources under `crates/z00z_crypto/tari/`
- do not reintroduce any workspace `jmt` alias to vendored Tari in this phase or later phases; if a vendored Tari crate still needs `tari_jellyfish`, it must remain an explicitly vendored-only dependency and must not leak back into first-party manifests

**📌 Verified current manifest cutover state:**

- `crates/z00z_storage/Cargo.toml` already consumes `jmt = "0.12.0"` directly from crates.io
- no first-party `Cargo.toml` under `crates/` declares `tari_jellyfish`
- `crates/z00z_core/Cargo.toml` no longer declares any direct `jmt` dependency
- `crates/z00z_core/src/` currently contains no `jmt` imports or `tari_jellyfish` references
- workspace `Cargo.toml` still carries `tari_jellyfish` only as a vendored Tari workspace dependency, which is allowed under the read-only vendor exception and is not resolved by first-party crate manifests in the active storage path

Checklist:

- [x] Ensure every first-party crate that needs JMT declares or resolves only `crates.io jmt`, never `tari_jellyfish` and never a workspace alias pointing at vendored Tari.
- [x] Update `crates/z00z_storage/Cargo.toml` to consume `crates.io jmt` explicitly instead of the workspace `jmt` alias.
- [x] Check whether `crates/z00z_core/Cargo.toml` still needs a direct `jmt` dependency and remove it in this stage if it is unused.
- [x] Keep all Tari crypto-related dependencies intact.
- [x] Keep any remaining `tari_jellyfish` dependency scoped to vendored Tari crates only; treat any appearance in a first-party crate manifest as a migration failure.
- [x] Stop after manifest edits and capture compile errors before touching `crates/z00z_storage/src/assets/` logic.

### ✅ 7.2 Compile Gates Before Porting Logic

**📌 The compile mismatch inventory is the input for the storage port. It must isolate backend API deltas before semantic refactoring starts.**

Required commands:

```bash
cargo check -p z00z_storage
cargo check -p z00z_wallets
cargo check -p z00z_simulator
```

**📌 Frozen compile mismatch inventory after the manifest cutover check:**

- `cargo check -p z00z_storage`: green
- `cargo check -p z00z_wallets`: green
- `cargo check -p z00z_simulator`: green
- current mismatch inventory is empty; this phase produced no backend API mismatch, no public storage surface mismatch, and no downstream import mismatch at compile time

Checklist:

- [x] Run `cargo check -p z00z_storage` immediately after manifest edits.
- [x] Run `cargo check -p z00z_wallets` to surface downstream compile fallout from dependency shape changes.
- [x] Run `cargo check -p z00z_simulator` to surface direct `AssetStore` and `StoreOp` fallout.
- [x] Save the mismatch inventory and do not start storage logic edits until the error list is frozen.
- [x] Classify each compile failure as backend API mismatch, public storage surface mismatch, or downstream import mismatch.

## ⚙️ Phase 8. Storage Adaptation In z00z_storage

### 🔑 8.1 Canonical Storage API Shape

**📌 `z00z_storage` must end this stage with a hierarchy-aware storage API that keeps raw backend operations private.**

Canonical public storage surface:

- keep public exports rooted under `crates/z00z_storage/src/assets/mod.rs`
- keep crate entry through `crates/z00z_storage/src/lib.rs`
- expose typed update, read, root, and proof entry points using `AssetPath`, `StoreItem`, `ProofItem`, `AssetStateRoot`, and `CheckRoot`
- keep backend-specific helper functions and raw JMT imports private to `store.rs` or a private `jmt_compat.rs`
- replace the backend-branded public op enum with a storage-neutral public op enum in `crates/z00z_storage/src/assets/store.rs` or `crates/z00z_storage/src/assets/types.rs`; the canonical name is `StoreOp`, not `JmtOp`
- keep `ProofItem` as the typed semantic proof record in `crates/z00z_storage/src/assets/types.rs`, and keep aggregate branch-proof byte encoding as a storage-owned witness codec rather than overloading `ProofItem` itself with adapter-only wire bytes

Canonical public method set on `AssetStore`:

- `put_item(&mut self, item: StoreItem) -> Result<AssetStateRoot, AssetStoreError>`
- `get_item(&self, path: &AssetPath) -> Result<Option<StoreItem>, AssetStoreError>`
- `del_item(&mut self, path: &AssetPath) -> Result<AssetStateRoot, AssetStoreError>`
- `proof_item(&self, path: &AssetPath) -> Result<ProofItem, AssetStoreError>`
- `apply_ops(&mut self, ops: Vec<StoreOp>) -> Result<AssetStateRoot, AssetStoreError>`
- `root(&self) -> Result<AssetStateRoot, AssetStoreError>`

Canonical batch rule:

- `apply_ops` must evaluate ops in the caller-provided order against one evolving logical pre-state for that batch
- conflicting duplicate ops that touch the same canonical `AssetPath` more than once in one `apply_ops` call must be rejected before commit rather than delegated to backend-specific last-write behavior
- batch validation must finish before any committed state change begins when the batch contains malformed paths, path-leaf mismatches, or same-batch path conflicts

Canonical root rule:

- `root()` must always return a deterministic typed state root, including for empty state; public storage APIs must not encode root absence as `Option`
- the empty-state root must be derived by the same semantic rule used by `AssetModel::root()` for an empty hierarchy

Canonical private lookup rule:

- because wallet and checkpoint flows currently resolve by terminal `asset_id` plus `serial_id`, storage must maintain one private auxiliary reverse lookup helper index from terminal identity inputs to canonical `AssetPath`, or an equivalent private resolver that can recover `definition_id` deterministically; this helper is non-consensus, storage-internal, and not part of the public semantic contract
- this auxiliary helper index must be written, updated, deleted, and pruned atomically with canonical tree updates so stale path mappings cannot survive delete or rollback paths
- public wallet and simulator APIs must not expose this lookup as a new public trait, DTO field, or wire field during this migration

Canonical storage write flow:

1. validate `StoreItem::new(path, leaf)` or equivalent path and leaf match
2. write terminal asset leaf
3. compute and write serial-root leaf
4. compute and write definition-root leaf
5. return `AssetStateRoot`

Atomicity rule:

- canonical child-tree and parent-root updates must commit through one atomic batch or one rollback-capable internal write path; parent roots must not commit if the child-tree write failed or was not persisted
- no child-tree batch may be committed independently; tree-local asset, serial, definition, and helper-index batches must remain staged until one final shared commit assembles the whole transition
- public storage APIs must not mutate serial-root or definition-root leaves directly; parent refreshes must remain internal consequences of child-tree updates

Canonical storage delete flow:

1. resolve, load, or prove the targeted terminal leaf under the exact `AssetPath` before removal
2. remove the terminal asset leaf from the per-serial asset tree
3. refresh the serial-root leaf, or prune it if the serial bucket becomes empty
4. refresh the definition-root leaf, or prune it if the definition bucket becomes empty
5. return the deterministic post-delete `AssetStateRoot`

Checklist:

- [x] Replace `AssetStore::{insert,get,delete,get_proof,batch_update}` with the canonical typed method set in one stage; do not keep both flat and path-aware public APIs active past the migration boundary.
- [x] Replace public `JmtOp` usage with a storage-neutral `StoreOp` that carries `StoreItem` for writes and `AssetPath` for deletes.
- [x] Expose the canonical proof-returning entry point as `proof_item(&self, path: &AssetPath) -> Result<ProofItem, AssetStoreError>`.
- [x] Keep `ProofItem` as the typed semantic proof record and define any aggregate branch-proof byte container or codec in a storage-owned proof or adapter module rather than by mutating wallet code to reinterpret raw backend proofs.
- [x] Make `root()` return a deterministic `AssetStateRoot` for empty and non-empty state alike; remove public `Option`-based root semantics from the storage facade.
- [x] Make `apply_ops` preserve caller-provided op order as the only canonical batch ordering rule.
- [x] Reject any `apply_ops` batch that touches the same canonical `AssetPath` more than once instead of relying on backend-specific duplicate-key behavior.
- [x] Finish batch validation before any committed write begins when a batch contains malformed paths, path-leaf mismatches, or same-path conflicts.
- [x] Make `del_item` resolve, load, or prove the exact terminal leaf under the exact `AssetPath` before removal; reject silent no-op deletes against the wrong bucket.
- [x] Implement deterministic post-delete pruning so zero-child `SerialRootLeaf` and `DefinitionRootLeaf` entries cannot survive canonical delete.
- [x] Implement one atomic batch or one rollback-capable internal write path so parent roots cannot commit if child-tree writes fail or are not persisted.
- [x] Forbid public storage APIs from mutating serial-root or definition-root leaves directly; keep parent refreshes as internal consequences of child-tree updates.
- [x] Add one private auxiliary reverse-lookup helper index inside `store.rs` or a private helper module so `asset_id`-first callers can recover canonical `AssetPath` without changing wallet wire formats; keep it outside the public semantic contract.
- [x] Write, update, and delete the reverse-lookup record atomically with canonical tree updates, and ensure rollback removes stale helper mappings.
- [x] Keep raw backend batch application private to `store.rs` or a private helper module.
- [x] Re-export only the narrow public storage API from `crates/z00z_storage/src/assets/mod.rs`.
- [x] Keep `crates/z00z_storage/src/lib.rs` unchanged except for necessary re-export stabilization.

### 🔑 8.2 Tree Layout, Keys, And Namespace Isolation

**📌 The port must implement one explicit physical namespace strategy so global, definition, serial, and asset trees cannot collide even if keys and versions overlap.**

Canonical files:

- `crates/z00z_storage/src/assets/keys.rs`
- `crates/z00z_storage/src/assets/store.rs`
- `crates/z00z_storage/src/assets/types.rs`

Required invariants:

- `asset_key(asset_id)` remains the terminal asset-tree key basis
- definition and serial tree keys remain typed through `DefinitionId` and `SerialId`
- physical tree namespace bytes or an equivalent backend-specific isolation mechanism must be internal to storage
- no logical tree may share the same physical namespace without an explicit test proving safety
- reverse lookup from terminal `asset_id` to canonical `AssetPath` must be unique; duplicate terminal `asset_id` values across different canonical `AssetPath` values must be rejected before commit, and `asset_id` plus `serial_id` resolution must fail on any serial mismatch instead of choosing an arbitrary path

Checklist:

- [x] Keep `def_key`, `ser_key`, and `asset_key` as the canonical key derivation entry points.
- [x] Add internal namespace isolation logic if the backend requires tree disambiguation beyond current key derivation.
- [x] Prove that two logical trees cannot collide when using the same identifier bytes and version numbers.
- [x] Keep namespace bytes or prefixes out of the public API.
- [x] Add reverse-lookup invariants that reject duplicate terminal `asset_id` mappings across different canonical paths before commit and fail resolution on serial mismatch.
- [x] Add tests that fail if definition, serial, and asset trees can collide physically.

### ⚙️ 8.3 Hashing, Batch Application, And Version Semantics

**📌 Hashing and write semantics must stay behaviorally identical where required by the semantic contract.**

Canonical implementation topics:

- `asset_hash` and value-hash behavior
- `apply_batch`
- `persisted_ver`
- `next_ver`
- stale-node recording

Cryptographic boundary rules:

- do not introduce new public application hash domains in `store.rs` just to mimic backend internals
- keep backend value hashing inside the backend adapter boundary
- prove externally visible parity through `AssetStateRoot`, `ProofItem`, and reference-model agreement, not through a forced byte-equality claim between `jmt_node_hash` and `model::asset_leaf_hash`
- use one shared transition version for all logical trees touched by one state transition in the first implementation; reject mixed per-tree local version strategies unless historical-read requirements are revised explicitly
- keep child-tree versions out of committed root-leaf payloads and proof-facing semantic records unless a later proof revision explicitly requires them

Checklist:

- [x] Port `asset_hash` so identical leaf bytes produce the same committed value-hash behavior expected by the storage contract.
- [x] Port `apply_batch` to the `crates.io jmt` batch shape without changing write ordering.
- [x] Preserve stale-node recording for every stale node emitted by the backend batch.
- [x] Preserve shared version progression through `persisted_ver` and `next_ver`.
- [x] Choose one shared transition version for the first implementation and reject mixed local version strategies across logical trees.
- [x] Ensure every modified logical tree in one state transition is written under the same external version so proofs and replay logic cannot observe skew.
- [x] Keep child-tree versions out of committed root-leaf payloads, `ProofItem`, and other proof-facing semantic records unless a later proof revision explicitly introduces them.
- [x] Keep backend hash details private and prove correctness through root and proof outputs rather than through ad-hoc public hash helpers.
- [x] Add tests for insert, delete, batch update, version bump, and stale-node recording after each write path.
- [x] Add tests proving that version advancement without a state change is either impossible or produces no new committed root, according to the final storage API contract.
- [x] Add historical-read tests proving the chosen shared-version model can retrieve prior roots and proofs deterministically.
- [x] Add batch-conflict tests proving `apply_ops` rejects duplicate canonical `AssetPath` entries in one call before any committed state change begins.
- [x] Add crash-simulation or injected-failure tests proving partial writes cannot leave a definition root or global root pointing at stale or missing child roots.
- [x] Add tests proving parent root leaves are rewritten only when the corresponding child root hash actually changes.

### ✅ 8.4 Reference-Model Parity And Proof Construction

**📌 The concrete store must be validated against `AssetModel`, not against ad-hoc assumptions.**

Canonical proof contract:

- use `AssetModel::{put_leaf, proof_case, del_leaf}` as reference behavior
- construct `ProofItem` with `asset_state_root`, `AssetPath`, `DefinitionRootLeaf`, `SerialRootLeaf`, and terminal `AssetLeaf`
- keep verifier ordering consistent with existing wallet claim and witness validation expectations
- keep canonical aggregate branch-proof bytes for `MemberWit.proof` under one storage-owned codec that is explicit about `asset_state_root` and `AssetPath`; do not treat raw `ProofItem` serialization as a substitute for the witness-proof bridge unless the codec contract says so explicitly

Checklist:

- [x] Add storage tests that compare concrete store root results with `AssetModel::put_leaf` and `AssetModel::del_leaf` for the same path sets.
- [x] Add storage tests that compare concrete proof construction with `AssetModel::proof_case` for the same `AssetPath`.
- [x] Add negative tests for wrong root, wrong path, wrong terminal leaf, and wrong upper-level root leaf.
- [x] Add delete-path tests that distinguish leaf removed while bucket remains, serial bucket pruned, and definition bucket pruned.
- [x] Add delete determinism tests that prove deleting the same last leaf from the same pre-state yields the same post-delete root and the same absence proof shape.
- [x] Add reverse-lookup tests that prove `asset_id` plus `serial_id` resolves through the auxiliary helper index to exactly one canonical `AssetPath` and that stale helper mappings disappear after delete or rollback.
- [x] Add rebuild determinism tests that replay the same logical path set into both the concrete store and `AssetModel`.
- [x] Keep proof-building logic inside `z00z_storage`; do not rebuild `ProofItem` ad hoc in wallet or simulator code.
- [x] Define one storage-owned canonical witness-proof codec for aggregate branch proof bytes and add round-trip tests proving `MemberWit.proof` decodes into a proof object whose root and path agree with the typed `ProofItem` and resolved leaf.
- [x] Add replay tests proving the same witness-proof bytes fail under wrong `AssetStateRoot`, wrong `AssetPath`, or wrong terminal leaf hash.

## ⚙️ Phase 9. Downstream Integration

### ✅ 9.1 Wallet State And Witness Rewire

**📌 Wallet code must consume the post-port storage facade without backend leakage.**

Target files:

- `crates/z00z_wallets/src/core/tx/claim_tx.rs`
- `crates/z00z_wallets/src/core/tx/witness_gate.rs`
- `crates/z00z_wallets/src/core/tx/state_update.rs`
- `crates/z00z_wallets/src/core/tx/spending.rs`
- `crates/z00z_wallets/src/core/tx/lifecycle.rs`
- `crates/z00z_wallets/src/core/tx/claim_tx_tests.rs`

Required outcomes:

- `asset_id_hex` remains a compact wire reference only
- path resolution happens in storage-facing adapters
- `AssetState::root()` remains typed through `CheckRoot`
- witness verification binds to typed roots rather than tx digests
- `definition.id` is no longer accepted as a terminal asset identifier in claim and witness paths
- claim verification order remains: structure/scope/tx fields/nullifier/card/portable leaf/proof/authority/owner attest before digest mismatch classification so reject classes stay precise for proof and fee failures
- `AssetState`, `MemberIdx`, `SpentIdx`, and `TxProofChk` signatures remain unchanged during this migration; only their backing adapters and fixtures may change
- storage-backed adapters resolve terminal `asset_id` inputs through the storage-owned private lookup instead of through wallet-side reconstruction of missing `definition_id`
- storage-backed adapters obtain `CheckRoot` from the storage-owned root-provider path instead of manufacturing it from raw 32-byte values in wallet code
- storage-backed adapters decode witness-proof bytes through the storage-owned canonical proof codec before semantic verification; they must not reinterpret opaque bytes as backend-native proofs directly in wallet code

Checklist:

- [x] Update wallet storage adapters so proof and state requests pass or resolve `AssetPath` instead of relying on bare `asset_id` lookups alone.
- [x] Keep `CheckRoot` binding intact in `verify_spend_witness_gate` and related spend paths.
- [x] Keep `TxInputWire.asset_id_hex` parsing as the wire entry point, but route it through typed path resolution before storage proof lookup.
- [x] Add wallet tests that reject `definition.id` when used as if it were a terminal `asset_id`.
- [x] Add wallet tests that reject tx-digest placeholder roots where typed storage roots are required.
- [x] Add wallet tests in `claim_tx_tests.rs` that preserve reject-class precision by proving semantic, proof, and fee failures are reported before any later digest-mismatch classification.
- [x] Keep `state_update.rs` trait signatures stable and implement any new path-aware lookup logic behind their adapters instead of inside the traits themselves.
- [x] Verify that wallet-side adapters never reconstruct `definition_id` heuristically from wire data and always resolve through the storage-owned private lookup.
- [x] Verify that wallet-side adapters never construct `CheckRoot` from arbitrary raw bytes and always source it from the storage-owned root-provider conversion path.
- [x] Verify that wallet-side adapters decode `MemberWit.proof` only through the storage-owned canonical witness-proof codec and reject opaque bytes whose embedded root or path does not match the resolved snapshot input.

### ✅ 9.2 Simulator Claim Publish And Checkpoint Rewire

**📌 Simulator code must stop depending on `store::{AssetStore, StoreOp}` as an internal module detail and must consume the stabilized storage facade.**

Target files:

- `crates/z00z_simulator/src/claim_pkg_consumer.rs`
- `crates/z00z_simulator/src/scenario_1/stage_3.rs`
- `crates/z00z_simulator/src/scenario_1/stage_4.rs`
- `crates/z00z_simulator/src/scenario_1/stage_6.rs`

Required outcomes:

- claim package publish uses canonical storage inserts or batch updates through public `z00z_storage::assets` exports
- checkpoint preparation and application keep typed root semantics
- simulator fixtures and scenario tests use canonical terminal `asset_id`
- simulator bridge code stops rewriting `wire.definition.id` to terminal `asset_id` and stops using `CheckRoot::new(tx_digest)` as a stand-in for a storage root except in explicit negative tests
- simulator `SimState`, `PrepIdx`, `NoSpent`, and `PassProof` stay on the existing wallet trait signatures while their backing data is sourced from typed storage outputs
- simulator checkpoint prep resolves terminal ids through storage-owned lookup or storage-produced fixtures rather than through local reconstruction of missing `definition_id`
- simulator checkpoint prep sources `CheckRoot` from storage-owned root conversion or typed fixtures rather than from local raw-byte relabeling
- simulator fixtures consume storage-owned canonical witness-proof bytes rather than simulator-local proof byte layouts

Checklist:

- [x] Replace direct simulator imports of `store::{AssetStore, StoreOp}` with the public `z00z_storage::assets` facade and the storage-neutral `StoreOp` API.
- [x] Update claim publish logic so batch operations use typed storage input shapes when the public storage API changes.
- [x] Keep canonical `asset_id` generation and duplicate checks intact during claim bundle publish.
- [x] Replace Stage-4 bridge code that overwrites `wire.definition.id` with adapter logic that carries `definition_id` and decrypt/terminal identity separately.
- [x] Replace Stage-4 positive-path test fixtures that call `CheckRoot::new(tx_digest)` with typed storage-root fixtures or storage-backed roots.
- [x] Update scenario code in `stage_3.rs` and `stage_6.rs` to consume typed roots from storage instead of placeholder digest paths.
- [x] Add simulator regression tests for canonical `asset_id`, typed root binding, and successful claim publish after the backend cutover.
- [x] Keep `stage_6.rs` checkpoint helper traits unchanged and feed them from typed storage adapters instead of widening their public contract.
- [x] Verify that simulator fixtures do not guess missing `definition_id` outside storage and instead consume storage-backed path resolution or persisted fixture paths.
- [x] Verify that simulator fixtures and adapters do not manufacture `CheckRoot` from arbitrary 32-byte values outside the storage-owned root-provider path.
- [x] Verify that simulator fixtures and adapters consume the storage-owned canonical witness-proof codec and reject proof bytes whose embedded root or path mismatches the typed fixture state.

## ✅ Phase 10. Storage-Spec Closure And Acceptance

### 🔑 10.1 Mandatory Behavior Matrix

**📌 Acceptance must prove that the direct backend cutover closes the mandatory storage-spec gaps that are supposed to be handled by the migration workflow.**

Mandatory acceptance buckets:

- root typing and root separation
- terminal `asset_id` stability
- namespace resolution and definition binding
- auxiliary helper-index containment and collision rejection
- type integrity and identity cleanup
- physical namespace isolation
- bottom-up write, delete, prune, and rollback behavior
- shared version coordination
- aggregate proof shape and verifier ordering
- scan compatibility and witness bridge
- public facade containment inside `z00z_storage`
- claim reject-class precision for proof and fee failures
- benchmark evidence for baseline-versus-nested multi-tree behavior

Checklist:

- [x] Add or update one acceptance test bucket for each mandatory storage-spec topic owned by this migration.
- [x] Verify that every bucket is tied to concrete files and not only to prose.
- [x] Verify that no mandatory bucket still requires a new planning decision after tests are green.
- [x] Verify that the implementation still matches the definition-tree -> serial-tree -> asset-tree contract.
- [x] Verify that no first-party crate outside `z00z_storage` imports raw `jmt` types.
- [x] Verify that one shared transition version remains the only external version contract for all logical trees touched in one state transition.
- [x] Verify that claim-verifier tests still report proof and fee failures in their own reject classes rather than collapsing them into later digest-mismatch failures.
- [x] Verify that benchmark acceptance distinguishes Phase-1 baseline capture from final nested multi-tree acceptance evidence.

Current acceptance evidence:

- Root typing, root separation, namespace isolation, delete/prune/rollback semantics, caller-defined `apply_ops` ordering, and shared transition version:
    `crates/z00z_storage/src/assets/{store.rs,tests.rs}`
    Evidence: `cargo check -p z00z_storage` green; `cargo test -p z00z_storage --release` green; release coverage includes `assets::store::tests_basic::{test_get_rejects_same_asset_wrong_path,test_path_resolution_uses_asset_binding,test_del_item_rejects_wrong_path}` and `assets::store::tests_phase8::{test_batch_dup_path,test_batch_path_conflict,test_batch_one_ver,test_noop_keeps_ver,test_del_last_det,test_parent_prune,test_rollback_clears_path}`.
- Terminal `asset_id` stability, definition-binding, helper-index containment, duplicate terminal-id rejection, scan compatibility, witness bridge, and wallet/simulator root ownership:
    `crates/z00z_wallets/src/adapters/rpc/methods/asset_impl.rs`, `crates/z00z_wallets/src/core/tx/{witness_gate.rs,state_update.rs,claim_tx_tests.rs}`, and `crates/z00z_simulator/src/{claim_pkg_consumer.rs,scenario_1/stage_4.rs,scenario_1/stage_6.rs}`
    Evidence: wallet receive tests cover `asset_receive_rejects_definition_id_query` and `asset_receive_exact_asset_id_survives_definition_collision`; targeted wallet gates `cargo test -p z00z_wallets --release --features test-fast --features wallet_debug_dump --test test_tx_spent_gate --test test_phase24_gate --test test_tx_wrong_root` green; targeted simulator gate `cargo test -p z00z_simulator --release --features test-fast --features wallet_debug_dump --test test_claim_tx_pipeline` green.
- Public facade containment, proof-shape ownership, and reject-class precision for proof and fee failures:
    `crates/z00z_storage/src/assets/{mod.rs,types.rs,proof.rs,store.rs}` and `crates/z00z_wallets/src/core/tx/claim_tx_tests.rs`
    Evidence: source-only audit found no raw `jmt` imports under `crates/z00z_core/src`, `crates/z00z_wallets/src`, or `crates/z00z_simulator/src`; reject-class coverage lives in `test_definition_id_rejected_as_asset_id`, `test_proof_beats_digest_mismatch`, and `test_fee_beats_digest_mismatch`; final acceptance command `cargo test --release --features test-fast --features wallet_debug_dump` green.

### ✅ 10.2 Required Test And Command Gates

**📌 Release acceptance must use the command gates already defined by the workflow.**

Required commands:

```bash
cargo check -p z00z_storage
cargo test -p z00z_storage --release
cargo test -p z00z_simulator --release --features test-fast --features wallet_debug_dump --test test_claim_tx_pipeline
cargo test -p z00z_wallets --release --features test-fast --features wallet_debug_dump --test test_tx_spent_gate --test test_phase24_gate --test test_tx_wrong_root
cargo test --release --features test-fast --features wallet_debug_dump
```

**📌 Benchmark acceptance must remain phase-owned instead of being collapsed into the fixed command block above.**

Phase-1 baseline capture command shape after the benchmark harness exists:

```bash
cargo bench -p z00z_storage --bench assets_shard -- --save-baseline current_single_jmt
```

**⚠️ That command is baseline-capture evidence only. It is not, by itself, the final benchmark acceptance gate.**

**📌 Final benchmark acceptance additionally requires the implemented nested-mode selector and one published comparison report.**

Verified command shapes:

```bash
Z00Z_ASSET_BENCH_MODE=nested_jmt_serial cargo bench -p z00z_storage --bench assets_shard -- --save-baseline nested_jmt_serial
Z00Z_ASSET_BENCH_MODE=nested_jmt_parallel cargo bench -p z00z_storage --bench assets_shard -- --save-baseline nested_jmt_parallel
```

Required artifacts:

- `crates/z00z_storage/outputs/assets/jmt-refactor-baseline.md`
- `crates/z00z_storage/outputs/assets/jmt-refactor-bench.md`

**⚠️ The published benchmark report currently records a blocked shard-performance conclusion rather than a confirmed speedup claim.**

Checklist:

- [x] Run the storage compile gate again after the port is complete.
- [x] Run `cargo test -p z00z_storage --release` and require reference-model parity to pass.
- [x] Run the targeted simulator claim pipeline test and require canonical `asset_id` and typed root semantics to pass.
- [x] Run the targeted wallet tests and require wrong-root rejection to pass.
- [x] Run the final release-wide test gate only after the targeted storage, wallet, and simulator gates are green.
- [x] Require the benchmark harness to expose explicit mode selection for `current_single_jmt`, `nested_jmt_serial`, and `nested_jmt_parallel` before final benchmark acceptance is marked green.
- [x] Require final benchmark acceptance to include the nested serialized and shard-parallel runs plus the published report; do not accept a re-run of only `current_single_jmt` baseline capture as closure.

### 🚨 10.3 Negative Acceptance And Stop Conditions

**📌 Acceptance is not complete if any of the following remain true:**

- a mandatory storage-spec section still needs new migration planning
- a deferred question still changes phase order, public API shape, root binding, witness format, or terminal-key semantics
- a caller still requires tx-digest substitution for typed storage roots
- the backend cutover leaks raw `jmt` assumptions into public storage semantics
- the auxiliary reverse-lookup helper index leaks into public or consensus storage semantics
- duplicate terminal `asset_id` mappings across different canonical paths can still commit or resolve ambiguously
- benchmark closure still relies only on the `current_single_jmt` baseline capture or still lacks explicit nested benchmark mode selection and the published comparison report

Checklist:

- [x] Fail acceptance if any mandatory section in `jmt-storage-spec-gaps.md` still lacks code ownership or tests.
- [x] Fail acceptance if any unresolved deferred question still affects implementation order or public API shape.
- [x] Fail acceptance if any first-party caller still substitutes tx digest for typed storage roots.
- [x] Fail acceptance if any wallet or simulator path still treats `definition.id` as interchangeable with terminal `asset_id`.
- [x] Fail acceptance if the auxiliary reverse-lookup helper index appears in the public storage contract or affects consensus-visible root or proof semantics.
- [x] Fail acceptance if duplicate terminal `asset_id` mappings across different canonical paths are not rejected before commit or if resolution can still succeed on serial mismatch.
- [x] Fail acceptance if `apply_ops` ordering is backend-defined instead of caller-defined or if same-batch duplicate `AssetPath` conflicts are not rejected before commit.
- [x] Fail acceptance if mixed per-tree local version strategies remain reachable in the first implementation or if proofs and replay can still observe cross-tree version skew.
- [x] Fail acceptance if canonical delete can leave zero-child serial or definition root leaves behind or can silently no-op against the wrong `AssetPath`.
- [x] Fail acceptance if parent roots can commit after a failed child-tree write or if public APIs can mutate parent root leaves directly.
- [x] Fail acceptance if any child-tree batch can commit independently before the final shared transition commit assembles the whole tree update.
- [x] Fail acceptance if any wallet or simulator adapter can still manufacture `CheckRoot` from arbitrary raw bytes instead of sourcing it from the storage-owned root-provider conversion path.
- [x] Fail acceptance if witness-proof bytes are not owned by one storage-side canonical codec or if wallet and simulator adapters can reinterpret proof bytes without checking embedded root and path agreement.
- [x] Fail acceptance if any proof-verification negative case is missing.
- [x] Fail acceptance if benchmark closure is marked green without the nested serialized and shard-parallel runs plus the published comparison report.

## ♨️ Phase 11. Cleanup And Lock

### ♨️ 11.1 Code Cleanup And Dependency Lock

**📌 Cleanup must remove migration-only scaffolding without weakening the public storage contract.**

Required cleanup targets:

- transitional wrappers that only existed to bridge old backend API differences
- obsolete first-party `jmt` manifest entries left from the old alias setup
- stale comments claiming the repository must remain on vendored JMT first

Required preserved surfaces:

- typed storage roots
- `AssetPath`, `StoreItem`, `ProofItem`, `RootApi`
- Tari cryptography exports through `z00z_crypto`
- storage-neutral public operation names; backend-branded public names such as `JmtOp` must not survive cleanup

Current cleanup evidence:

- Private backend compatibility remains inside `crates/z00z_storage/src/assets/store.rs`; no separate legacy shim module such as `jmt_compat.rs` and no public backend-branded operation surface remain.
- `crates/z00z_core/Cargo.toml` contains no direct `jmt` dependency, while `crates/z00z_storage/Cargo.toml` depends on `jmt = "0.12.0"` directly from crates.io.
- The workspace `tari_jellyfish` entry is now documented explicitly as a vendor-only exception for the read-only Tari subtree.
- Neighboring migration docs now mark the direct cutover as accepted state rather than as pending rollout work.

Checklist:

- [x] Remove private adapter shims that are no longer needed after the port stabilizes.
- [x] Remove first-party `jmt` dependency from `crates/z00z_core/Cargo.toml` if  proved it is unused.
- [x] Remove obsolete comments or TODOs that still describe the vendored-first backend path as active.
- [x] Keep any `tari_jellyfish` dependency only inside the read-only vendored Tari subtree and document it explicitly as a vendor-only exception.
- [x] Reject cleanup as incomplete if any first-party crate manifest, code path, or workflow text still permits `tari_jellyfish`, a vendored `jmt` alias, or a first-party fallback away from crates.io `jmt`.

### 🔔 11.2 Documentation Lock After Implementation

**📌 Cleanup is incomplete until the neighboring documents describe the post-migration repository state correctly.**

Target files:

- `specs/014-z00z-storage/jmt-storage-spec-gaps.md`
- `specs/014-z00z-storage/jmt-migration-plan.md`

Checklist:

- [x] Update `specs/014-z00z-storage/jmt-storage-spec-gaps.md` so sections closed by the migration are marked closed and stale extraction or milestone assumptions are removed from active planning text.
- [x] Remove stale references to temporary migration workflow notes that no longer exist in the workspace.
- [x] Keep `specs/014-z00z-storage/jmt-migration-plan.md` aligned with the final accepted implementation state.
- [x] Record that production first-party storage now runs on `crates.io jmt`.
- [x] Record that typed roots, terminal `asset_id`, and path semantics remained backend-agnostic across the cutover.

## 🚨 Phase 12. Blockers And Stop Rules

### 🛑 12.1 Hard Stop Conditions During Port

**📌 Stop implementation immediately if the backend cannot preserve required storage semantics without changing the semantic contract.**

Hard stop cases:

- `crates.io jmt` cannot reproduce required value-hash behavior
- `crates.io jmt` cannot support the required batch-update or stale-node hooks without patching vendor code
- shared version behavior diverges in a way that breaks deterministic rebuild or proof lookup guarantees
- any first-party caller can stay green only by using tx-digest substitution instead of typed roots
- the port requires public backend-specific types outside `z00z_storage`
- the port can stay green only by preserving backend-branded public types such as `JmtOp` in downstream crates
- the port can stay green only by promoting the auxiliary reverse-lookup helper index into the public or consensus contract
- the port can stay green only by allowing parent roots to commit after failed child-tree writes or by exposing direct parent-root mutation in public APIs
- shared-version coordination cannot be preserved without exposing mixed per-tree local versions that make proofs or replay observe cross-tree skew

Conditional guardrails:

- Stop work if value-hash behavior cannot be matched without changing committed semantics.
- Stop work if stale-node recording cannot be preserved through the available backend hooks.
- Stop work if version semantics diverge enough to break proof lookup or deterministic rebuild guarantees.
- Stop work if the first implementation cannot keep one shared transition version across all modified logical trees without introducing observable proof or replay skew.
- Stop work if downstream callers can only be kept green through raw digest-root substitution.
- Stop work if deterministic terminal-id resolution can only be preserved by exposing the auxiliary reverse-lookup helper index outside `z00z_storage` or by making it consensus-visible.
- Stop work if parent-child atomicity can only be approximated by allowing partially committed parent roots or public direct parent-root mutation.
- Write a decision record before resuming if any hard stop condition triggers.

### 🔔 12.2 Recovery Path After A Stop

**📌 Recovery after a stop must be explicit and written. Do not patch forward ad hoc.**

Allowed recovery decisions:

- adapt the private compatibility boundary while preserving public semantics
- extend the private adapter layer inside `z00z_storage`
- formally change the semantic contract in `jmt-storage-spec-gaps.md`
- abandon the direct backend migration

Conditional recovery steps:

- Revert to the last green rollback boundary before evaluating recovery options.
- Write the exact mismatch that triggered the stop, including affected files and tests.
- Choose one recovery path and record it in the active migration docs before restarting implementation.
- Reject untracked ad-hoc fixes that bypass the written recovery decision.

## ⭐ Phase 13. Decision Summary

### 💯 13.1 Final Repository Contract After Migration

**📌 The direct migration is successful only if the repository ends in one stable shape:**

- first-party asset storage runs on `crates.io jmt`
- Tari cryptography stays unchanged
- hierarchy semantics remain anchored in `AssetPath`, `StoreItem`, `ProofItem`, `AssetStateRoot`, `CheckRoot`, `RootApi`, and `AssetModel`
- auxiliary reverse lookup remains private, non-consensus, and outside the public storage contract
- wallet and simulator code consume typed storage APIs from `z00z_storage`
- acceptance evidence is strong enough that `jmt-storage-spec-gaps.md` becomes the semantic source of truth and acceptance checklist, not a source of new migration planning

Current decision evidence:

- `crates/z00z_storage/Cargo.toml` now depends on `jmt = "0.12.0"` directly from crates.io, `crates/z00z_core/Cargo.toml` contains no direct `jmt` dependency, and the workspace `Cargo.toml` documents `tari_jellyfish` only as a vendor-only exception for the read-only Tari subtree.
- Tari cryptography remains exported through `crates/z00z_crypto/src/lib.rs`, while the migration work stayed inside first-party storage, wallet, simulator, and spec files without repurposing vendored Tari sources.
- `crates/z00z_storage/src/assets/mod.rs` and `crates/z00z_storage/src/lib.rs` still expose the typed storage facade, and downstream wallet and simulator code continue to import typed storage APIs through `z00z_storage::assets`.
- Neighboring documents now describe the accepted final state directly: `specs/014-z00z-storage/jmt-storage-spec-gaps.md` records the current first-party storage contract and remaining real gaps, while this plan records the surviving workflow and acceptance closure state.
- The active document split is now stable: `jmt-storage-spec-gaps.md` is the semantic source of truth and this plan remains the surviving workflow and implementation record. No additional migration-planning document is required before executing or accepting the remaining semantic work.

Checklist:

- [x] Verify that first-party storage is fully backed by `crates.io jmt`.
- [x] Verify that Tari cryptography dependencies and exports were not repurposed during the migration.
- [x] Verify that typed storage semantics remained stable across storage, wallet, and simulator code.
- [x] Verify that all neighboring docs describe the final state accurately.
- [x] Verify that no further migration-planning document is needed before executing or accepting the remaining semantic work from `jmt-storage-spec-gaps.md`.
