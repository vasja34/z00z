# Snapshot Storage Plan

[TOC]

**📌 This plan rewrites the current snapshot-storage workflow into one implementation-ready execution document for introducing canonical snapshot storage without changing snapshot meaning.**

**🎯 The plan must extend the live codebase first: Stage 4 remains the current producer, Stage 6 remains the current consumer, wallet replay remains path-bound, and `z00z_storage` becomes the owner of the canonical snapshot artifact and validation boundary.**

**🔑 The plan is anchored to verified code structures, not to greenfield design:**

- `crates/z00z_simulator/src/scenario_1/stage_4.rs`
- `crates/z00z_simulator/src/scenario_1/stage_6.rs`
- `crates/z00z_wallets/src/core/tx/state_update.rs`
- `crates/z00z_storage/src/assets/types.rs`
- `crates/z00z_storage/src/assets/proof.rs`
- `crates/z00z_storage/src/assets/store_internal/proof_help.rs`
- `crates/z00z_storage/src/snapshot/`
- `crates/z00z_storage/src/lib.rs`

> [!Important]
> This plan covers canonical snapshot storage only. It must not expand into checkpoint final-artifact storage, checkpoint proof production, or simulator UX cleanup outside the changes required to land one canonical snapshot path.

## 📌 Verified Scope

### 🔑 Verified Codebase Facts

**📌 The current codebase already fixes the following semantics and the plan must preserve them without reinterpretation:**

- Stage 4 writes `checkpoint_prep.json` with `prev_root_hex` and per-entry `member_wit_hex`
- Stage 4 builds roots from storage-backed state rather than from tx digest placeholders
- Stage 6 consumes the prep artifact, keys replay lookup by `CheckRoot`, and currently rebuilds proof context through `prep_store(rows)?.proof_item(&path)` before constructing `ResolvedInput`
- wallet replay correctness is already path-bound through `ResolvedInput`, `MemberWit`, and `ProofItem`
- `z00z_storage::assets::proof::chk_blob(...)` is already the storage-owned witness verification boundary
- `z00z_storage::assets::types::SnapItem` already exists as a snapshot-facing `path + leaf + wit` record
- `z00z_storage/src/snapshot/` exists as an insertion point but is currently empty
- `z00z_storage/src/lib.rs` still exports only `assets`

**📌 The plan must therefore reuse existing path, root, leaf, and witness semantics and only relocate ownership, persistence, and validation into one canonical snapshot API.**

### ❓ Assumptions And Open Decisions

**📌 Assumption 1: the first safe milestone may keep the persisted Stage 4 artifact stable until the atomic writer-reader cut-over phase lands.**

**📌 Assumption 2: the first canonical witness payload is the existing `ProofBlob::encode()` byte format already emitted by Stage 4 and checked by `MemberWit` plus `ProofItem`.**

**📌 Assumption 3: the first rollout keeps `PrepSnapshot.prev_root` on `CheckRoot`, because the live producer, Stage 6 replay index, and wallet checkpoint-side contracts are already keyed on `CheckRoot`. Embedded witness proof context still carries `AssetStateRoot`, and validation must enforce `CheckRoot::from(proof_item.root()) == snapshot.prev_root` rather than inventing a reverse root conversion.**

**📌 Open decision 1 is now resolved: the canonical persisted snapshot codec is binary `BincodeCodec` in `z00z_storage`. JSON may remain adapter-only for simulator-facing compatibility, but canonical ids and canonical persistence bytes are derived from binary bytes only.**

**❓ Open decision 2: non-canonical audit metadata may stay simulator-local or move into `z00z_storage`, but that ownership must be fixed before any persistent audit wrapper is introduced.**

> [!Warning]
> This plan must not reopen tx-digest root substitution, asset-id-only witness binding, or any path-free replay shortcut. Those paths are already closed by the live code and tests.

## 🚩 Plan Structure

```mermaid
flowchart TD
    A[Phase 1 Freeze Baseline] --> B[Phase 2 Introduce Types and IDs]
    B --> C[Phase 3 Add Codec and Validator]
    C --> D[Phase 4 Build Canonical Snapshot In Memory]
    D --> E[Phase 5 Cut Over Stage 4 and Stage 6]
    E --> F[Phase 6 Land Test Matrix and CI Gates]
    F --> G[Phase 7 Close Rollout and Sign Off]
```

```mermaid
sequenceDiagram
    participant S4 as Stage 4 Producer
    participant SNAP as z00z_storage Snapshot API
    participant PROOF as Storage Proof Boundary
    participant WLT as Wallet Replay Types
    participant S6 as Stage 6 Consumer

    S4->>SNAP: build typed snapshot entries from live prep data
    SNAP->>PROOF: validate witness bytes against root and path
    PROOF-->>SNAP: verified storage snapshot
    SNAP-->>S4: canonical bytes plus PrepSnapshotId
    S4->>SNAP: persist canonical snapshot
    S6->>SNAP: load canonical snapshot
    SNAP-->>WLT: replay-ready path, leaf, and proof context
    WLT-->>S6: ResolvedInput-compatible replay data
```

## ⚙️ Phase 1. Freeze Baseline Semantics

### Add the canonical source-of-truth matrix

Objective:

**📌 Capture the exact current semantics for root source, path source, leaf source, witness source, replay consumer, and ordering before any storage-layer type is introduced. This unit exists to prevent the plan from drifting away from the live code.**

Target Files And Structures:

- `crates/z00z_simulator/src/scenario_1/stage_4.rs`
- `crates/z00z_simulator/src/scenario_1/stage_6.rs`
- `crates/z00z_wallets/src/core/tx/state_update.rs`
- `crates/z00z_storage/src/assets/proof.rs`
- `crates/z00z_storage/src/assets/store_internal/proof_help.rs`

Implementation Steps:

- Read Stage 4 preparation flow in execution order and record which helper owns each prep field.
- Read Stage 6 replay reconstruction flow in execution order and record how prep rows become `ResolvedInput` values.
- Read wallet witness and replay types to lock the path-bound contract for `MemberWit` and `ResolvedInput`.
- Read storage proof helpers to lock the storage-owned witness-verification boundary.
- Build one matrix that maps each canonical snapshot field to its current source of truth and one matrix that maps each current transport field to either a canonical replacement or a non-canonical audit destination.
- Treat any mismatch between the current workflow and the live code as a blocker that must be resolved before new snapshot types are planned further.

Invariants And Constraints:

- `prev_root` must remain storage-derived
- witness bytes must remain storage-owned proof bytes
- replay input must remain path-bound
- no tx-digest-derived root or placeholder witness digest may re-enter the plan

Validation Strategy:

- run the simulator gate commands in `--release`, because Stage 4 range-proof generation is disabled for these production-path tests in debug builds
- run `stage4_prep_root_tracks_storage_not_compat_root` to reconfirm root-source behavior
- run `prep_bad_blob`, `prep_root_mix_member`, and `prep_path_mix_member` to reconfirm storage-owned witness-byte semantics and root/path binding on the wallet boundary
- run `test_cp_` to reconfirm current prep consumption and replay expectations through the Stage 6 checkpoint gate set

Completion Criteria:

**📌 This unit is complete only when one baseline matrix exists and every later phase can point to it for root, path, leaf, witness, and ordering semantics.**

**✔️ Implementation Checklist:**

- [x] Read `crates/z00z_simulator/src/scenario_1/stage_4.rs` and capture the current producer field mapping.
- [x] Read `crates/z00z_simulator/src/scenario_1/stage_6.rs` and capture the current consumer and replay mapping.
- [x] Read `crates/z00z_wallets/src/core/tx/state_update.rs` and document the `MemberWit` plus `ResolvedInput` invariants.
- [x] Read `crates/z00z_storage/src/assets/proof.rs` and `crates/z00z_storage/src/assets/store_internal/proof_help.rs` and document the witness verification boundary.
- [x] Write one source-of-truth matrix for root, path, leaf, witness, ordering, and replay ownership.
- [x] Write one field-migration matrix from current prep transport fields to canonical snapshot fields or non-canonical audit fields.
- [x] Run `cargo test --release -p z00z_simulator --features test-fast --test test_stage4_digest stage4_prep_root_tracks_storage_not_compat_root -- --nocapture`.
- [x] Run `cargo test --release -p z00z_wallets --features test-fast --features wallet_debug_dump prep_bad_blob -- --nocapture`.
- [x] Run `cargo test --release -p z00z_wallets --features test-fast --features wallet_debug_dump prep_root_mix_member -- --nocapture`.
- [x] Run `cargo test --release -p z00z_wallets --features test-fast --features wallet_debug_dump prep_path_mix_member -- --nocapture`.
- [x] Run `cargo test --release -p z00z_simulator --features test-fast --test test_stage6_checkpoint test_cp_ -- --nocapture`.
- [x] Stop the plan if any matrix row conflicts with the live code.

📌 Baseline Source-Of-Truth Matrix:

| Semantic | Live producer source | Current prep transport | Live consumer or owner | Frozen Phase 1 rule |
| --- | --- | --- | --- | --- |
| `prev_root` | `build_prep_file(...) -> prep_store(...) -> check_root()` and `prep_root(&prep.rows)` in `stage_4.rs` | `PrepFile.prev_root_hex` | `stage_6.rs` rechecks `prep_root(&prep.rows)`, keys `PrepIdx` by `CheckRoot`, and passes that root into `prepare_tx_sum(...)` | Root stays storage-derived `CheckRoot`; no tx-digest or compat-root substitute may re-enter the flow |
| Path | `prep_path(row)` rebuilds `AssetPath` from `definition_id_hex + serial_id + asset_id_hex` | `PrepRow.definition_id_hex`, `PrepRow.asset_id_hex`, `PrepRow.serial_id` | `stage_6.rs` rebuilds the same `AssetPath` and `ResolvedInput::new(...)` enforces leaf/path compatibility | Replay stays path-bound on canonical storage path fields |
| Leaf | `prep_leaf(wire, input_ref)` derives the leaf from `asset_wire_to_leaf(wire)` and then rebinds `asset_id` from the input ref | `PrepRow.leaf` | `build_target_frag(...)` hashes `prep_row.leaf`, and `PrepIdx::new(...)` clones the same leaf into `ResolvedInput` | The prep leaf is the pre-state semantic leaf; serial and asset identity must stay aligned with the input ref |
| Witness bytes | `prep_wit_hex(store, row)` uses `store.proof_blob(&path)?.encode()` | `PrepRow.member_wit_hex` | `stage_6.rs` decodes the bytes and passes them into `MemberWit::new(bytes, proof_item)` | Witness bytes stay storage-owned `ProofBlob` bytes, not simulator-defined payloads |
| Proof context | `proof_help.rs` builds `ProofItem` and `ProofBlob` from the storage-backed `AssetStore` | No separate transport field; Stage 4 serializes only proof bytes | `PrepIdx::new(...)` reconstructs `proof_item` with `store.proof_item(&path)` and pairs it with the decoded proof bytes | Typed proof context remains storage-owned and path-bound even before the later snapshot accessor cut-over |
| Ordering | `build_prep_file(...)` preserves `selected.iter().zip(tx_inputs.iter())` order when building `rows` | `PrepFile.rows` array order | `build_target_frag(...)`, `build_target_cp(...)`, and `prepare_tx_sum(...)` all consume the producer order without re-sorting | Canonical snapshot entries must preserve producer order exactly |
| Replay ownership | Stage 4 only emits transport data; it does not build replay-ready wallet inputs | `prev_root_hex + rows[*]` | Stage 6 currently owns replay reconstruction through `PrepIdx::new(...)`, `MemberWit::new(...)`, and `ResolvedInput::new(...)` | The plan may move replay materialization into `z00z_storage`, but it may not weaken the current path-bound wallet contract |

📌 Field-Migration Matrix:

| Current prep transport field | Current meaning | Canonical snapshot destination | Non-canonical audit destination | Phase 1 freeze |
| --- | --- | --- | --- | --- |
| `prev_root_hex` | Hex form of the storage-derived pre-state root | `PrepSnapshot.prev_root: CheckRoot` | None required | Keep the root semantic and drop the JSON hex wrapper once the storage codec owns serialization |
| `rows[*].definition_id_hex` | Definition component of the canonical asset path | `SnapItem.path.definition_id` | None required | Keep as path material only; do not duplicate it as a second semantic field |
| `rows[*].asset_id_hex` | Asset-id component of the canonical asset path and replay lookup key | `SnapItem.path.asset_id` | Optional rollout-only mirror if legacy JSON must stay readable | Keep the canonical asset-id meaning; do not downgrade to digest-only linkage |
| `rows[*].serial_id` | Serial component of the canonical asset path and leaf-match gate | `SnapItem.path.serial_id` | None required | Keep serial on the path and retain leaf-match checks |
| `rows[*].leaf` | Typed pre-state asset leaf | `SnapItem.leaf` | None required | Keep as the semantic pre-state leaf payload |
| `rows[*].member_wit_hex` | Hex wrapper around encoded `ProofBlob` bytes | `SnapItem.wit` or equivalent typed witness-byte field | Optional rollout-only mirror if legacy JSON stays on disk temporarily | Keep the bytes, remove only the transport encoding layer |
| `rows[*]` order | Producer order from `selected.zip(tx_inputs)` | `PrepSnapshot.entries` order | None required | Preserve order exactly; do not sort or normalize entries during rollout |
| Reconstructed `ProofItem` | Storage proof context rebuilt from path and store state, not serialized directly today | Storage-owned replay-entry accessor derived from canonical snapshot bytes | None required | Keep proof-context reconstruction out of simulator-owned semantics |

**📌 Phase 1 conflict check:** no matrix row conflicts with the live code inspected in `stage_4.rs`, `stage_6.rs`, wallet replay types, or storage proof helpers, so the plan remains unblocked for later phases.

### Lock the baseline regression gate set

Objective:

**📌 Convert the baseline semantics into named regression gates so later phases cannot silently weaken root, witness, or replay rules.**

Target Files And Structures:

- `crates/z00z_simulator/tests/test_stage4_digest.rs`
- `crates/z00z_simulator/tests/test_stage6_checkpoint.rs`
- `crates/z00z_wallets/tests/proof_blob_fix.rs`
- `crates/z00z_wallets/src/core/tx/state_update.rs`

Implementation Steps:

- Define one named gate for root-source correctness.
- Define one named gate for witness-byte correctness.
- Define one named gate for replay consumer correctness.
- Record what must fail loudly if any of those gates regress during later storage cut-over phases.

Invariants And Constraints:

- gates must track behavior, not document intention only
- later phases must reference the gate names directly in their validation sections

Validation Strategy:

- confirm that each gate already maps to at least one existing regression test
- record any missing direct gate as a blocker for Phase 6 test work

Completion Criteria:

**📌 This unit is complete only when later phases can cite named baseline gates instead of vague “preserve current behavior” language.**

**✔️ Implementation Checklist:**

- [x] Name the root-source regression gate and map it to `test_stage4_digest`.
- [x] Name the witness-byte regression gate and map it to the `proof_blob_fix` fixture source plus executable wallet `state_update.rs` tests.
- [x] Name the replay-consumer regression gate and map it to `test_stage6_checkpoint`.
- [x] Record what each gate protects and what exact failure class it should catch.
- [x] Mark any uncovered baseline invariant as a blocker for the later test-matrix phase.

📌 Named Baseline Gates:

| Gate | Existing test anchor | What it protects | Failure class that must fail loudly |
| --- | --- | --- | --- |
| `Gate Root Source` | `crates/z00z_simulator/tests/test_stage4_digest.rs`, especially `stage4_prep_root_tracks_storage_not_compat_root` | Stage 4 must persist the storage-derived `CheckRoot` and not fall back to `CompatRoot` or any digest-like placeholder | `prev_root_hex` diverges from storage root, or Stage 4 starts serializing a non-storage root |
| `Gate Witness Bytes` | `crates/z00z_wallets/tests/proof_blob_fix.rs` as the fixture source, plus `crates/z00z_wallets/src/core/tx/state_update.rs` tests `prep_bad_blob`, `prep_root_mix_member`, and `prep_path_mix_member` | Canonical witness bytes must remain encoded `ProofBlob` bytes that can be paired with typed `ProofItem` context and verified by wallet-side gates | witness bytes decode but fail storage checks, or path/root binding weakens and `MemberWit` no longer rejects bad membership data |
| `Gate Replay Consumer` | `crates/z00z_simulator/tests/test_stage6_checkpoint.rs`, especially `test_cp_prev_root`, `test_cp_root_delta`, and `test_cp_frag_links` | Stage 6 must consume the exact Stage 4 pre-state root and preserve typed fragment/checkpoint linkage across replay preparation | Stage 6 stops consuming the emitted prep root, loses typed delta linkage, or breaks fragment-to-checkpoint replay expectations |

⚠️ Uncovered Baseline Invariant:

- `PrepFile.rows` ordering is exercised indirectly by the current Stage 6 fragment and checkpoint tests, but there is no single-purpose regression named only for entry ordering yet. Phase 6 must add one direct ordering gate if later storage cut-over work starts re-materializing or re-sorting canonical snapshot entries.

## ⚙️ Phase 2. Introduce Canonical Snapshot Types And IDs

### Introduce the canonical snapshot record around existing storage types

Objective:

**📌 Add one canonical snapshot artifact shape inside `z00z_storage` without changing Stage 4 or Stage 6 behavior yet. This unit exists to create a storage-owned artifact surface while reusing the existing semantic types already present in the codebase.**

Target Files And Structures:

- existing insertion point: `crates/z00z_storage/src/snapshot/`
- existing semantic types: `crates/z00z_storage/src/assets/types.rs`
- existing facade target: `crates/z00z_storage/src/lib.rs`
- proposed new file: `crates/z00z_storage/src/snapshot/mod.rs`
- proposed new file: `crates/z00z_storage/src/snapshot/types.rs`

Implementation Steps:

- Use the empty `z00z_storage/src/snapshot/` directory as the insertion point for the canonical snapshot module.
- Reuse `CheckRoot`, `AssetPath`, `AssetId`, `DefinitionId`, `SerialId`, and `StoreItem`-compatible path semantics from `z00z_storage::assets`.
- Reuse the existing `SnapItem` shape in `assets/types.rs` as the canonical entry payload or as the direct internal payload of `PrepEntry`; do not create a second path-plus-leaf-plus-witness record with the same meaning.
- Introduce `PrepSnapshot` as the outer artifact record containing version, `prev_root`, and ordered entries.
- Introduce a typed witness-byte container if needed, but keep it as a thin wrapper over canonical proof bytes rather than a second witness semantics layer.
- Keep proof-context reconstruction out of simulator code by planning one storage-owned replay-entry accessor that decodes embedded `ProofBlob` bytes and surfaces typed `ProofItem` context for later wallet bridging.
- Keep `PrepSnapshotId` external to the serialized payload.
- Keep the public surface narrow and storage-owned.

Canonical Data Shape:

```rust
pub struct PrepSnapshot {
    pub version: PrepSnapshotVersion,
    pub prev_root: CheckRoot,
    pub entries: Vec<SnapItem>,
}
```

Invariants And Constraints:

- no checkpoint output fields in the snapshot artifact
- no tx-proof bytes in the snapshot artifact
- no simulator-local metadata in the canonical payload
- no duplicate type that already exists in `z00z_storage::assets`
- no simulator ownership of canonical snapshot bytes
- no reverse `CheckRoot -> AssetStateRoot` conversion invented only for snapshot rollout

Validation Strategy:

- compile the new snapshot module without touching simulator crates
- review all new types against `SnapItem`, `AssetPath`, `CheckRoot`, and wallet replay types to confirm there is no duplicate semantics

Completion Criteria:

**📌 This unit is complete only when one canonical snapshot artifact shape compiles under `z00z_storage` and does not duplicate existing path-plus-leaf-plus-witness semantics.**

**✔️ Implementation Checklist:**

- [x] Create `crates/z00z_storage/src/snapshot/mod.rs` as the new module entry point.
- [x] Create `crates/z00z_storage/src/snapshot/types.rs` for `PrepSnapshot`, version type, id type, and any thin witness-byte wrapper.
- [x] Reuse `SnapItem` from `crates/z00z_storage/src/assets/types.rs` instead of creating a second equivalent entry record.
- [x] Reuse `CheckRoot`, `AssetPath`, `AssetId`, `DefinitionId`, and `SerialId` from `z00z_storage::assets`.
- [x] Define `PrepSnapshotId` as an external content-addressed identifier.
- [x] Keep canonical fields limited to version, `prev_root`, ordered entries, and typed witness bytes.
- [x] Keep simulator-only metadata out of the canonical payload.
- [x] Update `crates/z00z_storage/src/lib.rs` only when the module surface is stable enough to export.
- [x] Confirm no new type duplicates `SnapItem`, `MemberWit`, or `ResolvedInput` meaning.
- [x] Add one storage-owned replay-entry type or accessor that can surface decoded `ProofItem` context without importing wallet types into `z00z_storage` public APIs.

### Define the storage-owned snapshot facade and error contract

Objective:

**📌 Define one narrow storage-facing API for snapshot build, save, load, and validate operations. This unit exists to prevent generic payload-shape inference and to keep later writer-reader cut-over on one storage-owned boundary.**

Target Files And Structures:

- proposed new file: `crates/z00z_storage/src/snapshot/store.rs`
- proposed new file: `crates/z00z_storage/src/snapshot/error.rs`
- existing facade target: `crates/z00z_storage/src/lib.rs`

Implementation Steps:

- Define one `PrepSnapshotStore`-style trait or concrete facade.
- Separate `save_snapshot`, `load_snapshot`, `validate_snapshot`, `derive_snapshot_id`, and replay-entry materialization responsibilities.
- Keep audit linkage out of the canonical facade until the audit ownership decision is fixed.
- Use `z00z_utils::codec` and `z00z_utils::io` abstractions rather than direct `serde_json` or `std::fs` calls.

Canonical API Surface:

```rust
pub trait PrepSnapshotStore {
    fn save_snapshot(&mut self, snapshot: &PrepSnapshot) -> Result<PrepSnapshotId, PrepSnapshotError>;
    fn load_snapshot(&self, snapshot_id: &PrepSnapshotId) -> Result<PrepSnapshot, PrepSnapshotError>;
    fn validate_snapshot(&self, snapshot: &PrepSnapshot) -> Result<(), PrepSnapshotError>;
    fn derive_snapshot_id(&self, snapshot: &PrepSnapshot) -> Result<PrepSnapshotId, PrepSnapshotError>;
    fn replay_entries(&self, snapshot: &PrepSnapshot) -> Result<Vec<PrepReplayEntry>, PrepSnapshotError>;
}
```

Invariants And Constraints:

- public boundaries must accept typed roots and typed entries only
- no generic save or load that infers artifact meaning from payload shape
- no simulator transport structs in canonical module imports
- replay-entry materialization must stay storage-owned so Stage 6 does not re-derive `ProofItem` from simulator-local helper stores

Validation Strategy:

- ensure all planned later phases can point to this one facade rather than invent their own persistence path

Completion Criteria:

**📌 This unit is complete only when one storage-owned facade and one explicit error taxonomy cover canonical snapshot build, save, load, validate, and replay-entry materialization operations.**

**✔️ Implementation Checklist:**

- [x] Create `crates/z00z_storage/src/snapshot/store.rs`.
- [x] Create `crates/z00z_storage/src/snapshot/error.rs`.
- [x] Define one narrow storage-facing facade with explicit `save`, `load`, `validate`, and id-derivation responsibilities.
- [x] Define one storage-owned replay-entry accessor that surfaces canonical entry data plus decoded proof context for later wallet bridging.
- [x] Define one explicit error taxonomy for root mismatch, path mismatch, witness decode failure, id mismatch, version failure, and backend failure.
- [x] Require `z00z_utils::codec` for serialization.
- [x] Require `z00z_utils::io` for persistence.
- [x] Keep audit-wrapper handling outside the canonical facade until the audit ownership decision is resolved.

## ⚙️ Phase 3. Add Canonical Codec And Validation Boundary

### Add the canonical snapshot codec and id derivation boundary

Objective:

**📌 Implement one storage-owned canonical codec and one `PrepSnapshotId` derivation rule. This unit exists so Stage 4 writes and Stage 6 reads later share the same artifact bytes and the same identity contract.**

Target Files And Structures:

- `crates/z00z_storage/src/snapshot/types.rs`
- `crates/z00z_storage/src/snapshot/store.rs`
- proposed new file: `crates/z00z_storage/src/snapshot/codec.rs`

Implementation Steps:

- Resolve the codec decision before writing codec code.
- Implement one canonical encode and decode path for `PrepSnapshot`.
- Implement one canonical id derivation function from canonical bytes only.
- Require save to write bytes and then reload through the same loader before accepting persistence.
- Require load to recompute `PrepSnapshotId` from bytes and reject backend-key mismatch.

Invariants And Constraints:

- malformed transport values must fail before semantic validation
- unsupported versions must fail before witness verification
- snapshot identity must stay external to the payload

Validation Strategy:

- round-trip encode and decode tests
- id stability tests across repeated encode and load cycles
- backend-key mismatch rejection tests

Completion Criteria:

**📌 This unit is complete only when one canonical byte format and one canonical `PrepSnapshotId` rule exist for both current and future callers.**

**✔️ Implementation Checklist:**

- [x] Resolve open decision 1 for codec strategy before codec implementation begins.
- [x] Create `crates/z00z_storage/src/snapshot/codec.rs`.
- [x] Implement canonical encode and decode for `PrepSnapshot`.
- [x] Implement `PrepSnapshotId` derivation from canonical bytes only.
- [x] Require save to reload persisted bytes through the canonical loader.
- [x] Require load to reject backend-key mismatch against recomputed id.
- [x] Add id round-trip and re-encode stability tests.
- [x] Add malformed transport and unsupported-version tests.

### Add the storage-owned validator for root, path, leaf, witness, and ordering

Objective:

**📌 Implement one canonical validator in `z00z_storage` that owns semantic checks for roots, paths, leaves, witnesses, duplicates, and ordering. This unit exists to stop validation from fragmenting across adapters and simulator code.**

Target Files And Structures:

- `crates/z00z_storage/src/snapshot/store.rs`
- `crates/z00z_storage/src/snapshot/error.rs`
- existing reuse: `crates/z00z_storage/src/assets/proof.rs`
- existing reuse: embedded `ProofBlob` and `ProofItem` semantics carried in witness bytes

Implementation Steps:

- Validate in fixed order: decode, version gate, single-root check, per-entry path check, per-entry leaf check, witness decode and witness binding, duplicate-path reject, duplicate terminal-id reject, ordering-preservation checks, id derivation.
- Reuse `chk_blob(...)`, `ProofBlob`, and embedded `ProofItem` semantics rather than adding a second witness verifier or depending on `AssetStore`-only helpers during persisted snapshot validation.
- Reject wrong root, wrong path, wrong serial, wrong asset id, leaf mismatch, wrong leaf hash, malformed witness bytes, duplicate path, and duplicate terminal-id reuse with distinct errors.
- Keep validation read-only from the caller point of view.

Critical Flow:

```rust
fn validate_snapshot(snapshot: &PrepSnapshot) -> Result<(), PrepSnapshotError> {
    ensure_supported_version(snapshot.version)?;
    ensure_single_root(snapshot.prev_root, &snapshot.entries)?;

    for entry in &snapshot.entries {
        validate_entry_path(entry)?;
        validate_entry_leaf(entry)?;
        validate_entry_witness(snapshot.prev_root, entry)?;
    }

    reject_duplicate_paths(&snapshot.entries)?;
    reject_duplicate_terminal_ids(&snapshot.entries)?;
    Ok(())
}
```

Invariants And Constraints:

- validation must live in one storage-owned function
- witness validation must stay storage-owned
- no adapter may partially validate and then continue on storage trust
- root agreement must be checked as `CheckRoot::from(decoded_blob.item().root()) == snapshot.prev_root`, not by inventing a reverse conversion for `CheckRoot`

Validation Strategy:

- direct targeted tests for each reject reason
- positive witness tests reused from current fixtures
- deterministic ordering checks for repeated identical input sets
- direct tests for `CheckRoot` and embedded `AssetStateRoot` agreement

Completion Criteria:

**📌 This unit is complete only when one storage-owned validator can reject semantically wrong snapshots without simulator help.**

**✔️ Implementation Checklist:**

- [x] Implement one canonical validation function in `crates/z00z_storage/src/snapshot/store.rs` or its dedicated validator module.
- [x] Reuse `chk_blob(...)` from `crates/z00z_storage/src/assets/proof.rs`.
- [x] Treat decoded `ProofBlob` plus its embedded `ProofItem` as the persisted source of truth for witness meaning.
- [x] Add distinct error variants for root, path, serial, asset-id, leaf, witness, duplicate-path, duplicate-terminal-id, and version failures.
- [x] Add positive validation tests from existing witness fixtures.
- [x] Add negative tests for wrong root, wrong path, wrong serial, wrong terminal asset id, wrong leaf bytes, malformed witness bytes, duplicate path, and duplicate terminal id reuse.
- [x] Add ordering tests proving identical canonical input order yields identical bytes and identical ids.
- [x] Add tests proving `CheckRoot::from(proof_item.root())` must match `snapshot.prev_root` for every entry.
- [x] Fail the phase if validation logic spreads into simulator adapters instead of one storage-owned function.

## ⚙️ Phase 4. Build Canonical Snapshot In Memory From Stage 4 Data

### Add the Stage 4 to canonical snapshot builder

Objective:

**📌 Prove that current Stage 4 data can be mapped into one validated canonical snapshot without changing the persisted artifact yet. This unit exists to de-risk the later writer-reader cut-over.**

Target Files And Structures:

- existing producer: `crates/z00z_simulator/src/scenario_1/stage_4.rs`
- `crates/z00z_storage/src/snapshot/types.rs`
- `crates/z00z_storage/src/snapshot/store.rs`

Implementation Steps:

- Add one builder path that maps Stage 4 prep facts into `PrepSnapshot` in memory.
- Keep the builder order fixed: root load, path resolution, leaf load, witness decode, entry assembly, validation, id derivation.
- Reuse current Stage 4 helper semantics for `prep_leaf`, `prep_path`, `prep_store`, `prep_wit_hex`, and `prep_root`.
- Convert split transport fields into one canonical `AssetPath` and one canonical `SnapItem` entry.
- Derive the canonical snapshot root from the live `prep_root(...)` `CheckRoot` contract and separately require every decoded witness blob to agree with that root via `CheckRoot::from(blob.item().root())`.
- Reject report-file, filename, row-number, or debug-metadata field sources.
- Preserve canonical input order exactly, including flattened multi-tx ordering if one snapshot spans more than one package.

Invariants And Constraints:

- no second Stage 4 pipeline
- no second proof generation path
- no persisted format change in this phase
- no root-source fork between `prep_root(...)` and decoded witness proof context

Validation Strategy:

- compare the in-memory canonical snapshot against current Stage 4 root, path, leaf, and witness facts
- rerun Stage 4 and Stage 6 regressions without persisted cut-over yet

Completion Criteria:

**📌 This unit is complete only when Stage 4 can build one validated canonical snapshot in memory from the current prep data with no root drift and no semantic loss.**

**✔️ Implementation Checklist:**

- [x] Add one in-memory builder path from Stage 4 prep data to `PrepSnapshot`.
- [x] Reuse current Stage 4 helper semantics in their current order.
- [x] Convert split prep transport fields into canonical `AssetPath` plus `SnapItem` entries.
- [x] Decode `member_wit_hex` into canonical witness bytes before validation.
- [x] Run the storage-owned validator and id derivation on the in-memory snapshot.
- [x] Assert `prep_root(...)` matches `CheckRoot::from(decoded ProofBlob root)` for every entry.
- [x] Compare the result against current Stage 4 root, path, leaf, and witness facts.
- [x] Preserve canonical input ordering exactly.
- [x] Reject report-file, filename, row-number, and display-only metadata sources.
- [ ] Run `cargo test -p z00z_simulator --features test-fast test_stage4_digest -- --nocapture`.
- [ ] Run `cargo test -p z00z_simulator --features test-fast test_stage6_checkpoint -- --nocapture`.

⚠️ Review note: the exact debug integration commands above remain blocked by the existing project rule that Stage 4 production-path range-proof generation is disabled in debug builds and requires `--release`. Phase 4 code was validated with the relevant release-scope commands instead:

- `cargo test --release -p z00z_simulator --features test-fast --features wallet_debug_dump --test test_stage4_digest -- --nocapture`
- `cargo test --release -p z00z_simulator --features test-fast --features wallet_debug_dump --test test_stage6_checkpoint -- --nocapture`

📌 Phase 4 implementation cut-in:

- Stage 4 keeps `build_prep_file(...)` as the only producer of transport facts.
- The new in-memory builder runs after `build_prep_file(...)` and `prep_root(...)`, before any persisted format cut-over.
- The builder reuses `prep_path(...)` for canonical path materialization, decodes `member_wit_hex` into proof bytes, assembles ordered `SnapItem` entries, and calls the storage-owned snapshot validator plus id derivation.
- The builder compares the resulting canonical snapshot back against `PrepFile.prev_root_hex` and every `PrepRow` field, so root, path, leaf, witness bytes, and row order must stay identical to the current Stage 4 facts.
- The builder accepts only semantic fields already owned by the prep artifact. Report names, filenames, row indexes, display strings, and other audit-only metadata are excluded by construction.

### Record the field migration and ordering contract

Objective:

**📌 Make the Stage 4 transport-to-canonical mapping explicit so the later writer-reader cut-over does not guess which fields persist, which fields disappear, and which fields move to audit-only storage.**

Target Files And Structures:

- `specs/014-z00z-storage/snapshot-storage-plan.md`
- `crates/z00z_simulator/src/scenario_1/stage_4.rs`
- `crates/z00z_storage/src/snapshot/types.rs`

Implementation Steps:

- Create one table mapping `PrepFile` and `PrepRow` fields to canonical snapshot fields or audit-only fields.
- Record the canonical ordering contract for entries and flattened multi-tx input order.
- Record which Stage 4 fields disappear after cut-over because canonical structure owns the meaning directly.

Invariants And Constraints:

- no hidden field migration
- no silent field dropping without classification

Validation Strategy:

- use the table during Phase 5 to confirm both Stage 4 writer and Stage 6 reader consume the same artifact meaning

Completion Criteria:

**📌 This unit is complete only when there is one explicit migration table and one explicit ordering contract for the cut-over phase.**

**✔️ Implementation Checklist:**

- [x] Map `PrepFile.prev_root_hex` to canonical `prev_root`.
- [x] Map each `PrepRow` field to canonical snapshot fields or audit-only destinations.
- [x] Record canonical ordering rules for entries and flattened input order.
- [x] Record which fields disappear from canonical payloads after cut-over.
- [x] Use this table as a required input for Phase 5 writer-reader cut-over.

📌 Phase 4 field-migration table:

| Stage 4 transport field | Current meaning | Canonical Phase 4 in-memory field | Audit-only or dropped status after cut-over |
| --- | --- | --- | --- |
| `PrepFile.prev_root_hex` | storage-derived pre-state root encoded as hex | `PrepSnapshot.prev_root: CheckRoot` | Hex wrapper disappears once canonical storage bytes become the persisted artifact |
| `PrepRow.definition_id_hex` | definition branch of the canonical asset path | `SnapItem.path.definition_id` | No audit mirror required |
| `PrepRow.asset_id_hex` | terminal asset id branch of the canonical asset path | `SnapItem.path.asset_id` | No audit mirror required |
| `PrepRow.serial_id` | serial bucket branch of the canonical asset path | `SnapItem.path.serial_id` | No audit mirror required |
| `PrepRow.leaf` | pre-state terminal leaf payload | `SnapItem.leaf` | No audit mirror required |
| `PrepRow.member_wit_hex` | hex wrapper over encoded `ProofBlob` bytes | `SnapItem.wit` after hex decode | Hex wrapper disappears once canonical storage bytes become the persisted artifact |
| `PrepFile.rows[*]` position | producer order from `selected.iter().zip(tx_inputs.iter())` | `PrepSnapshot.entries[*]` position | Order remains canonical and is not recomputed from any display or file metadata |

📌 Phase 4 ordering contract:

- Entry order is the exact `selected.iter().zip(tx_inputs.iter())` producer order used by `build_prep_file(...)`.
- Canonical snapshot build must preserve that order through `PrepRow` iteration with no sorting, de-dup normalization, or path regrouping.
- If Stage 4 later spans more than one tx package, the canonical snapshot order must be the flattened producer order in which those prep rows were assembled before persistence.
- `prep_root(...)`, path resolution, leaf cloning, witness decode, entry assembly, validation, and id derivation must run in that same ordered flow.

📌 Fields that disappear from the canonical payload after cut-over:

- JSON hex wrappers such as `prev_root_hex` and `member_wit_hex` disappear because canonical bytes own serialization directly.
- The split transport path fields stop existing as standalone top-level transport strings because their meaning is owned by canonical `AssetPath`.
- No filename, report label, row number, stage-local display text, or other debug metadata enters the canonical payload.

## ⚙️ Phase 5. Cut Over Stage 4 Writes And Stage 6 Reads

### Route Stage 4 writes through the storage-owned snapshot facade

Objective:

**📌 Move Stage 4 persistence to the canonical storage-owned write path. This unit exists so Stage 4 stops owning canonical field layout and encoding rules.**

Target Files And Structures:

- `crates/z00z_simulator/src/scenario_1/stage_4.rs`
- `crates/z00z_storage/src/snapshot/store.rs`
- `crates/z00z_storage/src/snapshot/codec.rs`

Implementation Steps:

- replace direct simulator ownership of canonical prep serialization with the storage-owned save path
- keep file naming stable only if needed for the external workflow, but move field layout and codec ownership into `z00z_storage`
- require write-through validation and canonical id derivation before the artifact is accepted

Invariants And Constraints:

- Stage 4 must not own canonical serde structs after cut-over
- no mixed writer mode may remain active beside the canonical path

Validation Strategy:

- confirm Stage 4 writes canonical bytes only through the storage facade
- rerun Stage 4 digest regression

Completion Criteria:

**📌 This unit is complete only when Stage 4 persists the canonical snapshot through the storage-owned boundary and no simulator-local canonical snapshot schema remains active on the write side.**

**✔️ Implementation Checklist:**

- [x] Update `crates/z00z_simulator/src/scenario_1/stage_4.rs` to call the storage-owned snapshot writer.
- [x] Remove simulator ownership of canonical snapshot field layout on the write path.
- [x] Keep file naming stable only as transport, not as canonical schema ownership.
- [x] Require validation and id derivation before write acceptance.
- [ ] Run `cargo test -p z00z_simulator --features test-fast test_stage4_digest -- --nocapture`.

### Route Stage 6 reads and replay reconstruction through the same canonical accessor

Objective:

**📌 Move Stage 6 read flow, fragment assembly input, and replay reconstruction onto the same storage-owned snapshot accessor in one atomic cut-over. This unit exists to eliminate the second snapshot interpretation.**

Target Files And Structures:

- `crates/z00z_simulator/src/scenario_1/stage_6.rs`
- `crates/z00z_wallets/src/core/tx/state_update.rs`
- `crates/z00z_storage/src/snapshot/store.rs`
- `crates/z00z_storage/src/assets/proof.rs`

Implementation Steps:

- replace Stage 6 direct prep transport decoding with storage-owned snapshot load
- rebuild `PrepIdx` and replay inputs from canonical entries through one storage-owned accessor
- keep `MemberWit::new(...)` and `ResolvedInput::new(...)` as the only bridge into wallet replay logic
- keep proof-context reconstruction storage-owned; Stage 6 must not rebuild `ProofItem` semantics on its own from `prep_store(rows)` or other simulator-local helper stores
- remove row-based prep lookup helpers once the canonical accessor is live
- remove any remaining non-canonical read path so only one snapshot meaning remains reachable

Invariants And Constraints:

- writer and reader cut-over must land together
- no public API may accept filename identity, split path tuples, or path-free witness semantics after the cut-over
- snapshot validation must remain separate from full checkpoint replay

Validation Strategy:

- confirm Stage 6 fragment assembly and replay reconstruction both use the same canonical snapshot accessor
- rerun Stage 6 checkpoint regression
- confirm snapshot verification can run without ordered execution input while full checkpoint replay still requires it elsewhere

Completion Criteria:

**📌 This unit is complete only when Stage 6 reads canonical snapshot bytes through the storage-owned boundary, rebuilds replay inputs through canonical entries, and no alternate snapshot interpretation remains active.**

**✔️ Implementation Checklist:**

- [x] Update `crates/z00z_simulator/src/scenario_1/stage_6.rs` to load snapshots through the storage-owned reader.
- [x] Route both fragment assembly input and replay reconstruction through the same canonical snapshot accessor.
- [x] Rebuild `PrepIdx` from canonical entries only.
- [x] Source replay proof context from the storage-owned replay-entry accessor rather than `prep_store(rows)?.proof_item(&path)`.
- [x] Keep `MemberWit::new(...)` and `ResolvedInput::new(...)` as the only replay bridge into wallet logic.
- [x] Keep proof-context reconstruction storage-owned.
- [x] Remove row-based prep lookup helpers once the canonical accessor is live.
- [x] Remove any remaining non-canonical snapshot read path.
- [x] Verify snapshot validation stays separate from full checkpoint replay.
- [ ] Run `cargo test -p z00z_simulator --features test-fast test_stage6_checkpoint -- --nocapture`.

⚠️ Phase 5 validation note: the debug integration commands above remain blocked by the existing Stage 4 production-path restriction and were replaced with the required release-scope commands instead:

- `cargo test --release -p z00z_simulator --features test-fast --features wallet_debug_dump --test test_stage4_digest -- --nocapture`
- `cargo test --release -p z00z_simulator --features test-fast --features wallet_debug_dump --test test_stage6_checkpoint -- --nocapture`

📌 Phase 5 cut-over contract:

- Stage 4 persists canonical snapshot bytes only through `PrepFsStore::save_snapshot(...)` rooted at the transaction output directory.
- `checkpoint_prep.json` remains only a thin transport reference carrying `PrepSnapshotId`; it no longer owns canonical root, path, leaf, or witness layout.
- Stage 6 resolves that reference into `PrepSnapshot` plus `PrepReplayEntry` values through the same storage-owned accessor and no longer rebuilds `ProofItem` semantics from simulator-local prep rows.
- Fragment assembly reads canonical entries directly, while replay reconstruction still bridges into wallet logic only through `MemberWit::new(...)` and `ResolvedInput::new(...)`.

## ⚙️ Phase 6. Land Test Matrix And CI Gates

### Add storage-level invariant tests for snapshot semantics

Objective:

**📌 Translate the canonical snapshot contract into direct storage-level tests for roots, paths, leaves, witnesses, ids, versions, ordering, and persistence failures. This unit exists so correctness stops depending on prose.**

Target Files And Structures:

- proposed: `crates/z00z_storage/tests/snapshot_root_binding.rs`
- proposed: `crates/z00z_storage/tests/snapshot_path_binding.rs`
- proposed: `crates/z00z_storage/tests/snapshot_witness_decode.rs`
- proposed: `crates/z00z_storage/tests/snapshot_leaf_hash.rs`
- proposed: `crates/z00z_storage/tests/snapshot_ordering.rs`
- proposed: `crates/z00z_storage/tests/snapshot_ids.rs`
- proposed: `crates/z00z_storage/tests/snapshot_versions.rs`
- proposed: `crates/z00z_storage/tests/snapshot_persistence.rs`
- proposed: `crates/z00z_storage/tests/snapshot_replay_boundary.rs`

Implementation Steps:

- create one explicit bucket per invariant family
- add both positive and negative cases per bucket
- reuse existing witness and root fixtures where possible
- add persistence corruption and key-mismatch tests
- add version-gate tests that fail before witness verification

Invariants And Constraints:

- each invariant needs direct targeted coverage, not only indirect integration coverage
- CI must be able to fail on root substitution, path transplant, witness drift, id drift, and persistence corruption directly

Validation Strategy:

- run all storage snapshot tests as a dedicated package test target

Completion Criteria:

**📌 This unit is complete only when every snapshot invariant maps to at least one direct positive test and one direct negative test.**

**✔️ Implementation Checklist:**

- [x] Create storage-level test files for root binding, path binding, witness decode, leaf hash, ordering, ids, versions, persistence, and replay boundary.
- [x] Add positive and negative cases for each invariant bucket.
- [x] Validate witness success cases against the wallet proof-blob regression anchors.
- [x] Validate root-source coverage against the `test_stage4_digest` runtime semantics.
- [x] Add negative tests for wrong root, wrong path, wrong serial, wrong terminal asset id, wrong leaf bytes, malformed witness bytes, duplicate path, and duplicate terminal id reuse.
- [x] Add version-gate tests that fail before witness verification.
- [x] Add persistence corruption and backend-key mismatch tests.
- [x] Add ordering tests for canonical bytes and `PrepSnapshotId` stability.
- [x] Add direct tests for `CheckRoot` to embedded `AssetStateRoot` agreement.

### Add integration and boundary tests for Stage 4, Stage 6, and replay accessors

Objective:

**📌 Prove that the canonical snapshot path is the only active integration path for producer, consumer, and replay accessors. This unit exists to catch reintroduction of simulator-owned canonical semantics or replay shortcuts.**

Target Files And Structures:

- existing: `crates/z00z_simulator/tests/test_stage6_checkpoint.rs`
- existing: `crates/z00z_simulator/tests/test_stage4_digest.rs`
- existing: `crates/z00z_wallets/tests/proof_blob_fix.rs`
- CI manifest or equivalent workspace test gate

Implementation Steps:

- add tests proving only canonical snapshot input is accepted at the storage boundary
- add tests proving Stage 4 and Stage 6 share one storage-owned codec boundary
- add tests proving filenames, stage ids, and report references do not affect canonical bytes or `PrepSnapshotId`
- add replay-boundary tests proving snapshot verification succeeds without execution input while full checkpoint replay still requires extra artifacts elsewhere
- add module-boundary checks proving canonical snapshot modules do not import simulator transport types directly

Invariants And Constraints:

- no duplicate encode/decode logic across simulator files
- no public API path may accept more than one snapshot meaning

Validation Strategy:

- run simulator and wallet regression tests together with storage tests
- add code-search or review gates for duplicated codec semantics if needed

Completion Criteria:

**📌 This unit is complete only when CI can fail on simulator-owned canonical semantics, replay-boundary violations, or reintroduced duplicate codec logic.**

**✔️ Implementation Checklist:**

- [x] Add integration tests proving only canonical snapshot input is accepted.
- [x] Add integration tests proving Stage 4 and Stage 6 share one storage-owned codec boundary.
- [x] Add wrapper-boundary tests proving prep sidecars, stage ids, and report references do not affect canonical bytes or `PrepSnapshotId`.
- [x] Add replay-boundary tests proving snapshot validation succeeds without execution input while full checkpoint replay still requires transaction package inputs elsewhere.
- [x] Add module-boundary checks proving canonical snapshot modules do not import simulator-only transport structs.
- [x] Run `cargo test -p z00z_storage --tests`.
- [x] Run `cargo test -p z00z_simulator --features test-fast test_stage4_digest -- --nocapture`.
- [x] Run `cargo test -p z00z_simulator --features test-fast test_stage6_checkpoint -- --nocapture`.
- [x] Run `cargo test -p z00z_wallets --features test-fast proof_blob_fix -- --nocapture`.

⚠️ Phase 6 validation note: the storage suite and simulator regressions were executed with the required release-scope commands:

- `cargo test --release -p z00z_storage --tests -- --nocapture`
- `cargo test --release -p z00z_simulator --features test-fast --features wallet_debug_dump --test test_stage4_digest -- --nocapture`
- `cargo test --release -p z00z_simulator --features test-fast --features wallet_debug_dump --test test_stage6_checkpoint -- --nocapture`

📌 The `proof_blob_fix` filter command resolves to zero executable tests in this workspace, so the witness-boundary gate was also validated through the concrete release-scope wallet anchors:

- `cargo test --release -p z00z_wallets --lib --features test-fast --features wallet_debug_dump prep_bad_blob -- --nocapture`
- `cargo test --release -p z00z_wallets --lib --features test-fast --features wallet_debug_dump prep_root_mix_member -- --nocapture`
- `cargo test --release -p z00z_wallets --lib --features test-fast --features wallet_debug_dump prep_path_mix_member -- --nocapture`

## ⚙️ Phase 7. Close Rollout And Sign Off

### Remove the alternate snapshot interpretation from active callers

Objective:

**📌 Close the rollout by making the canonical snapshot path the only reachable path from active callers. This unit exists to end gray-zone behavior.**

Target Files And Structures:

- `crates/z00z_simulator/src/scenario_1/stage_4.rs`
- `crates/z00z_simulator/src/scenario_1/stage_6.rs`
- `crates/z00z_storage/src/snapshot/`

Implementation Steps:

- verify all moved callers now use canonical snapshot APIs first
- remove alternate snapshot interpretation from active caller paths
- record which caller moved from prep transport semantics to canonical `PrepSnapshot` semantics
- keep any remaining audit-only wrapper fields out of canonical APIs and canonical ids

Invariants And Constraints:

- no prolonged dual-path rollout
- no non-canonical snapshot meaning reachable from public APIs

Validation Strategy:

- final regression pass across storage, simulator, and wallet tests
- manual review of active caller list against the migration table

Completion Criteria:

**📌 This unit is complete only when no alternate snapshot interpretation remains active beside the canonical path.**

**✔️ Implementation Checklist:**

- [x] Verify all active callers use canonical snapshot APIs first.
- [x] Remove alternate snapshot interpretation from active caller paths.
- [x] Record each caller moved from transport prep semantics to canonical snapshot semantics.
- [x] Keep audit-only wrapper fields outside canonical ids and canonical bytes.
- [x] Run the full regression set after caller cleanup.

📌 Phase 7 active-caller closure:

| Caller | Previous prep-facing meaning | Canonical meaning after rollout | Closure status |
| --- | --- | --- | --- |
| `crates/z00z_simulator/src/scenario_1/stage_4.rs` | Stage 4 owned the prep transport layout and wrote prep semantics directly into `checkpoint_prep.json` | Stage 4 builds the canonical `PrepSnapshot`, persists it through `PrepFsStore::save_snapshot(...)`, and writes `checkpoint_prep.json` only as a thin `PrepSnapshotId` reference | Closed |
| `crates/z00z_simulator/src/scenario_1/stage_6.rs` | Stage 6 decoded prep transport fields and rebuilt replay semantics from simulator-local prep rows | Stage 6 resolves `PrepSnapshotId`, loads `PrepSnapshot` through `PrepFsStore::load_snapshot(...)`, and materializes replay input through storage-owned replay entries before bridging into `MemberWit::new(...)` and `ResolvedInput::new(...)` | Closed |
| `crates/z00z_simulator/tests/test_stage4_digest.rs` | Stage 4 regression coverage could still observe simulator-owned prep layout semantics | The regression now validates the canonical stored snapshot by loading it through `PrepFsStore` and comparing the canonical artifact state | Closed |
| `crates/z00z_simulator/tests/test_stage6_checkpoint.rs` | Stage 6 regression coverage could still observe transport prep semantics directly | The regression now resolves the thin prep reference and loads the canonical stored snapshot through the storage facade | Closed |

📌 Alternate-snapshot interpretation closure note:

- The only persisted snapshot meaning is now the storage-owned `PrepSnapshot` binary payload plus external `PrepSnapshotId`.
- `checkpoint_prep.json` no longer carries canonical root, path, leaf, or witness fields; it carries only the external snapshot id reference used to locate the canonical bytes.
- Stage 4 internal transport helpers remain local compatibility scaffolding for producer-side comparison and audit checks only; they are no longer a reachable canonical API or persisted snapshot schema.
- Canonical ids continue to derive from storage-owned binary snapshot bytes only, so no audit-only or transport-only field can alter `PrepSnapshotId`.

📌 Phase 7 final regression pass:

- `cargo test --release -p z00z_storage --tests -- --nocapture`
- `cargo test --release -p z00z_simulator --features test-fast --features wallet_debug_dump --test test_stage4_digest -- --nocapture`
- `cargo test --release -p z00z_simulator --features test-fast --features wallet_debug_dump --test test_stage6_checkpoint -- --nocapture`
- `cargo test --release -p z00z_wallets --lib --features test-fast --features wallet_debug_dump prep_bad_blob -- --nocapture`
- `cargo test --release -p z00z_wallets --lib --features test-fast --features wallet_debug_dump prep_root_mix_member -- --nocapture`
- `cargo test --release -p z00z_wallets --lib --features test-fast --features wallet_debug_dump prep_path_mix_member -- --nocapture`

### Record unresolved decisions, blocker closure, and sign-off evidence

Objective:

**📌 Leave one deterministic sign-off record for what was landed, what remains unresolved, and why those unresolved items do not block correctness. This unit exists to make acceptance auditable.**

Target Files And Structures:

- `specs/014-z00z-storage/snapshot-storage-plan.md`
- sign-off record location chosen by the implementation owner

Implementation Steps:

- record which files introduced canonical snapshot types, validator, codec, id derivation, builder, and accessor path
- record which test files close each invariant bucket
- record which blocker items were closed
- record unresolved decisions in the required order and why they do not block correctness

Invariants And Constraints:

- unresolved decisions must stay explicitly labeled
- no material ambiguity may be hidden in sign-off prose

Validation Strategy:

- compare the final sign-off record against the Phase 1 matrix, Phase 4 migration table, and Phase 6 test buckets

Completion Criteria:

**📌 This unit is complete only when another engineer can identify the canonical entry points, closed blockers, remaining open decisions, and accepted commit or tag without guessing.**

**✔️ Implementation Checklist:**

- [x] Record which file introduced canonical snapshot types.
- [x] Record which file introduced canonical validator and id derivation.
- [x] Record which file performs the direct Stage 4 to canonical snapshot build.
- [x] Record which files route canonical Stage 4 writes and Stage 6 reads.
- [x] Record which test files close each invariant bucket.
- [x] Record which blocker items were closed in this rollout.
- [x] Record unresolved open decisions and why they do not block correctness.
- [x] Record the accepted commit or tag for the rollout.

📌 Phase 7 sign-off record:

| Sign-off item | Verified location |
| --- | --- |
| Canonical snapshot types, versioning, and ids | `crates/z00z_storage/src/snapshot/types.rs` |
| Canonical snapshot module surface | `crates/z00z_storage/src/snapshot/mod.rs` |
| Canonical codec boundary | `crates/z00z_storage/src/snapshot/codec.rs` |
| Canonical validator, replay-entry materialization, and id-backed persistence rules | `crates/z00z_storage/src/snapshot/store.rs` and `crates/z00z_storage/src/snapshot/error.rs` |
| Direct Stage 4 to canonical snapshot build | `crates/z00z_simulator/src/scenario_1/stage_4.rs` |
| Canonical Stage 4 write route | `crates/z00z_simulator/src/scenario_1/stage_4.rs` |
| Canonical Stage 6 read and replay route | `crates/z00z_simulator/src/scenario_1/stage_6.rs` and `crates/z00z_simulator/src/scenario_1/prep_ref.rs` |

📌 Invariant bucket closure map:

| Invariant bucket | Closing tests |
| --- | --- |
| Root binding | `crates/z00z_storage/tests/snapshot/root_bind.rs` and `crates/z00z_simulator/tests/test_stage4_digest.rs` |
| Path binding | `crates/z00z_storage/tests/snapshot/path_bind.rs` |
| Witness decode and witness boundary | `crates/z00z_storage/tests/snapshot/fix.rs` plus wallet anchors `prep_bad_blob`, `prep_root_mix_member`, and `prep_path_mix_member` |
| Leaf-hash and terminal-leaf agreement | `crates/z00z_storage/tests/snapshot/leaf_hash.rs` |
| Ordering and id determinism | `crates/z00z_storage/tests/snapshot/ordering.rs` and `crates/z00z_storage/tests/snapshot/ids.rs` |
| Version gating | `crates/z00z_storage/tests/snapshot/versions.rs` |
| Persistence and backend-key mismatch | `crates/z00z_storage/tests/snapshot/persist.rs` |
| Replay boundary and module boundary | `crates/z00z_storage/tests/snapshot/replay_bound.rs` and `crates/z00z_simulator/tests/test_stage6_checkpoint.rs` |

📌 Closed blocker inventory:

- Closed: tx-digest root substitution remains excluded; canonical `prev_root` stays storage-derived `CheckRoot`.
- Closed: placeholder witness digests remain excluded; persisted witness bytes stay storage-owned encoded `ProofBlob` bytes.
- Closed: simulator-owned canonical snapshot layout is removed from the active write and read paths.
- Closed: filename-based canonical identity is removed; canonical persistence uses external `PrepSnapshotId` derived from binary bytes only.
- Closed: path-free replay reconstruction is removed from active callers; replay context is now materialized through the storage-owned accessor before wallet bridging.

📌 Remaining open decision and non-blocking status:

- Open decision 2 remains unresolved: whether non-canonical audit metadata should stay simulator-local or move into `z00z_storage` later. This does not block correctness because the canonical snapshot payload, canonical persistence path, and canonical id derivation already exclude audit-only fields.

📌 Accepted rollout commit:

- Accepted rollout tag and commit for the canonical snapshot rollout: `v1.738.0` at `d0092d45d555f0c2554bafd63a309f23192dca27` on branch `z00z-simul`.

## ✅ Acceptance Summary

### 🔔 Acceptance Conditions

**📌 The plan is successfully executed only when all of the following are true:**

- canonical snapshot types and ids exist in `z00z_storage`
- one storage-owned validator enforces root, path, leaf, witness, duplicate, and ordering rules
- Stage 4 writes canonical snapshot bytes through the storage facade
- Stage 6 reads canonical snapshot bytes through the same storage facade
- wallet replay still rebuilds through `MemberWit` and `ResolvedInput`
- no alternate snapshot meaning remains reachable from public snapshot APIs
- the full snapshot test matrix passes in CI
- remaining ambiguity is explicitly labeled as an assumption, blocker, or open decision

### 🚫 Non-Goals

**📌 The implementation covered by this plan must not do any of the following:**

- implement checkpoint final-artifact storage
- redesign Stage 5 or Stage 6 business behavior
- introduce a second proof format beside the current `ProofBlob` bridge
- move simulator reporting or UX cleanup into the snapshot correctness milestone
- widen public APIs to accept more than one snapshot meaning
