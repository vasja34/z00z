# Checkpoint Artifact Storage Specification For z00z_storage

[TOC]

## 1. Scope

### 1.1 Scope Contract

This document specifies the storage contract for the post-state checkpoint artifact that sits above the asset JMT layer.

The goal is to keep the checkpoint artifact fully aligned with the hierarchical asset-state model defined in `specs/014-z00z-storage/jmt-storage-spec-gaps.md` and with the pre-state snapshot contract defined in `specs/014-z00z-storage/snapshot-storage-spec.md`.

This document is intentionally strict about the difference between current simulator JSON wrappers, current wallet-side canonical state-update types, and the target storage contract for a future `z00z_storage` checkpoint layer.

In the current repository, the implemented checkpoint types are still the wallet-side `Checkpoint` and `CheckpointPubIn` in `crates/z00z_wallets/src/core/tx/state_update.rs`, plus the simulator JSON wrapper in `crates/z00z_simulator/src/scenario_1/stage_6.rs`.

Names such as `CheckpointArtifact`, `CheckpointDraft`, `CheckpointStore`, `CheckpointExecInput`, and `CheckpointLink` in the later sections of this document are proposed storage-layer types. They are not current code symbols yet.

Implementation checklist:

- [ ] Freeze the scope of this document to post-state checkpoint artifacts, linkage metadata, and deterministic replay inputs only; do not fold unrelated subsystems into the first checkpoint storage contract.
- [ ] Require every implementation task derived from this spec to declare whether it changes canonical checkpoint payloads, non-consensus wrappers, replay helpers, or migration adapters.
- [ ] Keep the proof-production boundary and the replay/audit boundary separate from the start; do not let one storage record serve both roles implicitly.
- [ ] Require all downstream documents and tasks to treat this spec as subordinate to the JMT storage semantics and dependent on the snapshot pre-state contract.
- [ ] Block implementation kickoff until the team agrees that the canonical artifact is the final proved checkpoint output and not a simulator-friendly JSON approximation.

### 1.2 Non-Goals And Scope Boundaries

This document does not authorize redesign of snapshot semantics, JMT leaf identity, or tx-level ownership logic. Those remain governed by the adjacent snapshot and JMT contracts.

Implementation checklist:

- [ ] Reject any implementation task that attempts to redefine the current Stage-4 prep artifacts (`PrepFile` and `PrepRow`), the future snapshot contract (`PrepSnapshot`), or terminal `asset_id` semantics from inside checkpoint work.
- [ ] Treat simulator UX improvements, reporting changes, and operator dashboards as out of scope unless they are required to preserve canonical checkpoint meaning.
- [ ] Require any proposed new field in `CheckpointArtifact` to name the exact consensus need it serves and the adjacent spec it depends on.
- [ ] Fail review if replay-helper convenience fields are proposed for the canonical artifact instead of separate helper records.

## 2. Current Repository State

### 2.1 Current State Inventory

The current canonical checkpoint state-update types already exist in `crates/z00z_wallets/src/core/tx/state_update.rs`.

The canonical typed checkpoint output is:

- `Checkpoint { height, prev_root, new_root, spent_delta, created_delta, cp_proof }`
- `CheckpointPubIn { prev_root, new_root, spent_delta, created_delta }`
- `SpentEnt { asset_id }`
- `CreatedEnt { asset_id, leaf_hash }`

The current simulator wrapper in `crates/z00z_simulator/src/scenario_1/stage_6.rs` defines a reduced JSON checkpoint object:

- `Checkpoint { prev_root_hex, new_root_hex, spent_delta, created_delta, fragment_ids }`

This simulator wrapper is not the canonical checkpoint contract because it omits `height` and `cp_proof`, and it adds `fragment_ids`, which are audit metadata rather than consensus checkpoint public inputs.

The current simulator does not derive Stage 6 `prev_root_hex` from `input_tx_digest_hex`. Stage 6 loads `prep.prev_root_hex` from Stage 4, rebuilds `prep_root(&prep.rows)`, and rejects any mismatch before checkpoint apply.

The current placeholder is different: Stage 6 decodes `pkg.tx_digest_hex` and temporarily reuses those bytes as `tx_proof` input to `prepare_tx_sum(...)`. That placeholder proof source must not be frozen into the final checkpoint proof contract.

The pre-state side is specified separately in `specs/014-z00z-storage/snapshot-storage-spec.md`. In current code, Stage 6 still consumes the Stage-4 `PrepFile` and `PrepRow` bundle rather than a persisted `PrepSnapshot` type. This checkpoint spec must therefore treat the current prep file as the implemented input dependency and `PrepSnapshot` as the target storage name, not as an already-existing payload.

Implementation checklist:

- [ ] Inventory every producer and consumer of checkpoint fields in `z00z_wallets`, `z00z_simulator`, and any reports or scenario files before changing artifact semantics.
- [ ] Record the exact source of truth for `height`, `prev_root`, `new_root`, `spent_delta`, `created_delta`, and `cp_proof`, and reject any implementation that derives them from simulator wrappers instead of canonical typed state-update results.
- [ ] Mark every current reuse of `tx_digest_hex` as checkpoint proof material as a correctness gap that must be removed before final artifact wiring.
- [ ] Identify every simulator-only field such as `fragment_ids` and keep a clear list of fields that must never enter canonical checkpoint payloads.
- [ ] Require one migration map that links current simulator wrapper fields to their target canonical equivalents or to audit-only wrappers.

### 2.2 Current Mismatch Map

The repository currently mixes two implemented checkpoint layers and one proposed storage layer:

- one typed wallet-side state-update result in `z00z_wallets`
- one simulator JSON wrapper with audit fields in `z00z_simulator`
- one not-yet-implemented storage-layer design described later in this document

The wallet-side `Checkpoint` currently acts as a proofless local apply result because `apply_batch_checkpoint(...)` still returns `cp_proof: Vec::new()` and there is no separate concrete `CheckpointDraft` type yet.

Implementation checklist:

- [ ] Write down one mismatch matrix mapping current typed fields, simulator wrapper fields, and target canonical artifact fields one-to-one.
- [ ] Distinguish which current fields are missing, which are wrongly sourced, and which are wrapper-only so migration tasks do not conflate them.
- [ ] Add one migration note per mismatch explaining whether it is solved by field addition, field removal, source correction, or type split.
- [ ] Refuse implementation if any current field can still map to more than one target meaning after the matrix is written.

## 3. Current Design Limits

### 3.1 Current Gaps That Block Final Checkpoint Storage

The current repository therefore contains three different checkpoint-related layers that are not yet fully aligned:

1. Canonical typed checkpoint application in `z00z_wallets`
2. Simulator JSON wrappers in `z00z_simulator`
3. The hierarchical asset-state model described in `jmt-storage-spec-gaps.md`

The first major limit is that the current simulator checkpoint wrapper omits `height` and `cp_proof`, even though both belong to the canonical typed checkpoint output.

The second major limit is that the current simulator still reuses `tx_digest_hex` bytes as a stand-in for `tx_proof` when it builds `TxPkgSum`. That is explicitly incompatible with the target storage model, where checkpoint proof material must come from a real checkpoint-proof producer rather than from a transaction digest placeholder.

The third major limit is that the current simulator wrapper does not clearly separate consensus checkpoint fields from audit-only fields such as `fragment_ids`.

The fourth major limit is that the current typed `Checkpoint` produced by `apply_batch_checkpoint(...)` still returns `cp_proof: Vec::new()`. That value is useful as a local state-transition draft, but it is not a final proved checkpoint artifact.

The fifth major limit is that the repository does not yet implement concrete storage-layer types such as `CheckpointArtifact`, `CheckpointDraft`, `CheckpointStore`, `CheckpointExecInput`, or `CheckpointLink`. Those names remain design targets only.

Implementation checklist:

- [ ] Treat each limit in this section as a blocking implementation gap with an explicit owner and removal criteria.
- [ ] Add one failing test or failing validation rule per gap before implementing the final fix so progress is measurable and regressions are obvious.
- [ ] Prohibit partial rollout where canonical artifacts are introduced but draft outputs, audit fields, or tx-digest roots remain silently accepted.
- [ ] Add an explicit migration risk note for any place where a structurally valid checkpoint object can still carry semantically wrong root or proof data.
- [ ] Reject any implementation plan that solves serialization only and leaves replay linkage or draft-versus-final semantics ambiguous.

### 3.2 Blocker Enforcement Rules

Design limits in this section are not documentation warnings. They are release blockers for canonical checkpoint storage.

Implementation checklist:

- [ ] Convert each blocker into one tracked validation gate in tests, runtime checks, or migration feature flags.
- [ ] Require every blocker to have one “how it fails today” example and one “what success looks like” acceptance rule.
- [ ] Do not mark the checkpoint artifact rollout complete while any blocker can still produce a structurally valid but semantically wrong artifact.
- [ ] Add a release checklist item requiring explicit sign-off that all blockers here are eliminated or kept behind isolated non-production paths.

## 4. Required Target Model

### 4.1 Target Artifact Contract

The corrected target model, which is not yet implemented in the repository, is one canonical `CheckpointArtifact` contract built on top of a validated snapshot artifact and one canonical JMT state root.

The checkpoint artifact records the deterministic state transition from `prev_root` to `new_root`, including typed spent and created deltas and the opaque checkpoint proof bytes.

The intended lifecycle is:

1. Resolve transaction inputs under one canonical asset-state root.
2. Persist that resolved input set under the snapshot contract. In current code the equivalent bundle is the Stage-4 `PrepFile` plus `PrepRow` set; the future storage-layer name is `PrepSnapshot`.
3. Apply the checkpoint transition against the same root.
4. Attach checkpoint proof bytes.
5. Persist the resulting typed checkpoint output as `CheckpointArtifact`.

This design keeps pre-state resolution separate from post-state transition output, which matches the existing split between membership material and checkpoint public inputs in `z00z_wallets`, even though the current repository still materializes the pre-state side as Stage-4 prep JSON rather than as a persisted `PrepSnapshot` object.

Implementation checklist:

- [ ] Define one canonical artifact lifecycle from validated `PrepSnapshot` to state-apply draft to final proved `CheckpointArtifact` and forbid shortcut flows that skip any stage.
- [ ] Require `CheckpointArtifact` to be the only canonical final output type and treat any proofless state-apply result as a separate draft type.
- [ ] Add tests proving that checkpoint artifacts cannot be built without a validated pre-state snapshot tied to the same `prev_root`.
- [ ] Keep the checkpoint artifact payload minimal and separate from replay execution inputs, audit notes, and source-file metadata.
- [ ] Require the final artifact to be content-addressable from canonical bytes only and forbid identity schemes based on filenames or wrapper metadata.

### 4.2 Final Artifact Boundary

The final artifact boundary begins only after deterministic apply has completed and non-empty proof bytes have been attached.

In current code there is no separate final-artifact type yet. The implemented wallet-side `Checkpoint` still carries empty `cp_proof` bytes and therefore behaves as a proofless local apply result rather than as a final proved artifact.

Implementation checklist:

- [ ] Treat pre-proof apply output as `CheckpointDraft` everywhere, including persistence and export paths, until proof bytes are attached.
- [ ] Forbid any API named or typed as a final checkpoint artifact from accepting empty `cp_proof` bytes.
- [ ] Add tests proving that proof attachment is the only step that upgrades draft status to final artifact status.
- [ ] Ensure content-addressed `CheckpointId` is computed only from final artifact bytes and never from the draft.

## 5. Root Semantics Separation

### 5.1 Checkpoint Root Binding Contract

The new checkpoint storage design must preserve the same root-semantics separation already required by `jmt-storage-spec-gaps.md`.

The following values are distinct and must never be silently substituted for one another:

1. Asset-state root produced by the hierarchical JMT storage layer
2. `prev_root` of a checkpoint transition
3. `new_root` of a checkpoint transition
4. `tx_digest_hex` or any other transaction-envelope digest

The required contract is:

- `CheckpointArtifact.prev_root` is an asset-state root only
- `CheckpointArtifact.new_root` is an asset-state root only
- `tx_digest_hex` is a transaction digest only

The forbidden equivalences are:

- `prev_root == tx_digest_hex`
- `new_root == tx_digest_hex`
- `CheckpointArtifact.prev_root == build_tx_package_digest(...)`

No current simulator path should derive `prev_root` from `input_tx_digest_hex`. Stage 6 already derives `prev_root_hex` from the Stage-4 prep file and rejects mismatches. The remaining placeholder in current code is `tx_digest_hex` reused as temporary `tx_proof` bytes, and that placeholder must be treated as compatibility-only behavior.

Implementation checklist:

- [ ] Introduce or reuse typed root wrappers so `prev_root`, `new_root`, and tx digests cannot be mixed at public storage boundaries without explicit conversion.
- [ ] Remove all code paths that source checkpoint roots from tx-digest placeholders before canonical checkpoint verification is enabled anywhere outside isolated migration tests.
- [ ] Require checkpoint build code to read `prev_root` and `new_root` only from validated storage/apply results, never from transport or scenario wrapper fields.
- [ ] Add negative tests proving that a valid tx digest cannot pass checkpoint root validation or proof verification as if it were a state root.
- [ ] Add migration assertions around simulator adapters so tx-digest root placeholders fail loudly once typed asset-state root inputs are available.

### 5.2 Root Source Enforcement

Typed root wrappers are necessary but not sufficient. The implementation must also enforce which subsystem is allowed to produce each root value.

Implementation checklist:

- [ ] Restrict checkpoint root production to validated apply results and storage APIs; do not allow arbitrary callers to supply roots as free-form bytes.
- [ ] Add adapter-level assertions that scenario wrappers and test fixtures can only pass roots through typed constructors fed from canonical sources.
- [ ] Add tests proving that transport-local root strings and tx-digest-derived values are rejected even if their byte length matches the expected root length.
- [ ] Require code review to flag any new function that accepts a checkpoint root without documenting its source of truth.

## 6. Proposed Artifact Layout

### 6.0 Layout Invariants

The storage contract should define one canonical persisted checkpoint record plus optional non-consensus wrappers around it.

Implementation checklist:

- [ ] Keep the canonical artifact, audit wrapper, linkage wrapper, and execution-input helper as distinct storage concepts with separate codecs and separate validity rules.
- [ ] Reject any payload proposal that mixes consensus public inputs with fragment traces, filenames, row numbers, or operator notes.
- [ ] Define exactly which record types are consensus-relevant and which are replay-only or operator-facing before implementation starts.
- [ ] Add tests proving that changing audit-only or linkage-only wrapper fields does not alter canonical checkpoint artifact bytes.

### 6.1 Checkpoint Artifact

The canonical post-state artifact should be named `CheckpointArtifact`.

This is a proposed storage-layer name. The current repository still exposes `z00z_wallets::core::tx::Checkpoint` as the implemented typed checkpoint value, and Stage 6 serializes a separate JSON wrapper around selected fields from that value.

Recommended fields:

- `version`
- `height`
- `prev_root`
- `new_root`
- `spent_delta`
- `created_delta`
- `cp_proof`

- `height` is checkpoint metadata under the current repository contract
- `prev_root`, `new_root`, `spent_delta`, and `created_delta` are the current typed public inputs

Under the current wallet contract, `height` is checkpoint metadata and is not part of `CheckpointPubIn`. If future proof systems promote `height` into public inputs, that must be treated as an explicit proof-contract revision rather than assumed retroactively.

The canonical `CheckpointArtifact` must be a final proved artifact. Therefore `cp_proof` must not be empty in the final storage contract.

A local state-apply result with `cp_proof = []` should be treated as a `CheckpointDraft`, not as a final `CheckpointArtifact`.

Recommended draft shape:

- `CheckpointDraft { version, height, prev_root, new_root, spent_delta, created_delta }`

`CheckpointDraft` should preserve exactly the same typed public-input fields as the final artifact, but it must not claim finality and must not be stored or transported as if it already carried a valid checkpoint proof.

Reference type sketch:

```rust
pub struct CheckpointDraft {
    pub version: CheckpointVersion,
    pub height: CheckpointHeight,
    pub prev_root: AssetStateRoot,
    pub new_root: AssetStateRoot,
    pub spent_delta: Vec<SpentEnt>,
    pub created_delta: Vec<CreatedEnt>,
}

pub struct CheckpointArtifact {
    pub version: CheckpointVersion,
    pub height: CheckpointHeight,
    pub prev_root: AssetStateRoot,
    pub new_root: AssetStateRoot,
    pub spent_delta: Vec<SpentEnt>,
    pub created_delta: Vec<CreatedEnt>,
    pub cp_proof: CheckpointProofBytes,
}

pub struct SpentEnt {
    pub asset_id: AssetId,
}

pub struct CreatedEnt {
    pub asset_id: AssetId,
    pub leaf_hash: AssetLeafHash,
}
```

Reference finalization rule:

```rust
pub fn finalize_checkpoint(
    draft: CheckpointDraft,
    cp_proof: CheckpointProofBytes,
) -> Result<CheckpointArtifact, CheckpointStorageError> {
    if cp_proof.is_empty() {
        return Err(CheckpointStorageError::EmptyCheckpointProof);
    }

    Ok(CheckpointArtifact {
        version: draft.version,
        height: draft.height,
        prev_root: draft.prev_root,
        new_root: draft.new_root,
        spent_delta: draft.spent_delta,
        created_delta: draft.created_delta,
        cp_proof,
    })
}
```

Implementation checklist:

- [ ] Define canonical `CheckpointArtifact` and `CheckpointDraft` structs with stable field order and fixed semantics for every field.
- [ ] Require `CheckpointDraft` to be proofless by construction and forbid APIs that allow empty `cp_proof` bytes inside the final artifact type.
- [ ] Add finalization logic that transforms `CheckpointDraft` into `CheckpointArtifact` without altering `height`, roots, or deltas.
- [ ] Add tests proving that the same draft finalized with the same proof bytes always yields identical canonical artifact bytes and identical `CheckpointId`.
- [ ] Reject any implementation that allows draft artifacts to be mistaken for final artifacts during export, load, or verification.
- [ ] Implement `CheckpointDraft` and `CheckpointArtifact` as separate concrete types, not as one struct with a boolean flag, so draft-versus-final confusion is impossible at the type boundary.
- [ ] Freeze the field-copy rule during finalization: `version`, `height`, `prev_root`, `new_root`, `spent_delta`, and `created_delta` must be byte-for-byte preserved from the draft, and only `cp_proof` may be attached.
- [ ] Add one canonical serializer test that encodes the same draft twice, finalizes it twice with the same proof bytes, and proves the final bytes and `CheckpointId` are identical across runs.
- [ ] Add one corruption test that swaps `spent_delta`, `created_delta`, or `height` during finalization and proves the finalizer rejects or the verifier catches the mutation immediately.

### 6.2 Optional Audit And Link Wrappers

Audit-only metadata such as `fragment_ids`, source file names, operator notes, or replay traces should not be mixed into the canonical checkpoint payload.

If the simulator needs them, they should live in a wrapper such as:

- `CheckpointAuditView { checkpoint, fragment_ids, trace_meta }`

This keeps consensus checkpoint public inputs clean while preserving simulator debuggability.

The binding between one `CheckpointArtifact` and the `PrepSnapshot` it was built from should also remain outside the canonical checkpoint payload unless the protocol later chooses to commit it explicitly.

Recommended non-consensus linkage shape:

- `CheckpointLink { checkpoint_id, prep_snapshot_id, exec_input_id }`

`CheckpointId` should be a content-addressed identity of the canonical serialized final checkpoint artifact body. It should remain outside the self-serialized canonical checkpoint payload for the same reason `PrepSnapshotId` remains external in the snapshot contract: embedding a self-derived id into the hashed payload makes the identity recursively self-referential.

For replay-safe linkage, all three identifiers should be content-addressed artifact identities or canonical digests of the serialized artifacts they reference. Mutable filenames, row numbers, or transport-local handles are not sufficient linkage keys because they do not survive export, replay, or cross-node verification safely.

A second non-consensus helper record is also needed for local deterministic re-apply and simulator execution, because the final checkpoint artifact does not contain output leaves or per-tx proof bytes.

Recommended execution-input shape:

- `CheckpointExecInput { exec_input_id, prep_snapshot_id, ordered_tx_inputs }`

`CheckpointExecInputId` should be a content-addressed identity of the canonical serialized execution-input body and should remain external to any self-hashed payload for the same reason `PrepSnapshotId` and `CheckpointId` remain external.

Where `ordered_tx_inputs` is either:

- a canonical `TxPkgSum`-equivalent bundle carrying outputs and `tx_proof` bytes, or
- deterministic references to external tx packages plus the rules required to reconstruct the same ordered `TxPkgSum` set

The first safe implementation should prefer persisting the canonical execution-input bytes directly, not only references plus reconstruction logic. Reconstruction-only designs are too fragile at the current stage because ordering drift, missing side artifacts, or codec changes can silently break deterministic replay while still leaving the final checkpoint artifact well-formed.

Replay-safe linkage must also be injective at the artifact layer: one `CheckpointExecInput` must identify one canonical ordered execution-input body, and a final checkpoint linkage should not rely on `prep_snapshot_id` alone when distinguishing between multiple candidate transitions built from the same pre-state snapshot.

This execution-input helper is not a consensus public-input object. It exists so that local builders, simulators, and auditors can re-run deterministic apply without pretending that `CheckpointArtifact` alone contains all witness material.

Implementation checklist:

- [ ] Define separate typed records for `CheckpointAuditView`, `CheckpointLink`, and `CheckpointExecInput`, each with a canonical codec and explicit non-consensus status.
- [ ] Require linkage to include `checkpoint_id`, `prep_snapshot_id`, and `exec_input_id` together and reject any caller that tries to identify a transition with only one of them.
- [ ] Define `CheckpointId` and `CheckpointExecInputId` as content-addressed identities derived from canonical bytes only and keep them outside self-hashed payloads.
- [ ] Prefer persisting canonical execution-input bytes directly for the first safe implementation and reject reconstruction-only linkage as the only replay path.
- [ ] Add tests proving that two different execution-input bodies for the same snapshot cannot be linked ambiguously to one final checkpoint artifact.

## 7. Why Checkpoint Artifact Must Stay Separate From Prep Snapshot

### 7.1 Artifact Separation Contract

The prep snapshot and the checkpoint artifact should not be collapsed into one record.

In current code this separation already exists operationally as Stage-4 prep JSON plus Stage-4 tx package on the pre-state side, and wallet/simulator checkpoint results on the post-state side.

The prep snapshot records resolved pre-state material. The checkpoint artifact records the executed transition result.

The existing wallet-side checkpoint application already encodes this separation operationally:

- input leaves and `MemberWit` are needed before apply
- spent and created deltas are known only after apply
- checkpoint proof bytes are output material, not pre-state material

Keeping these artifacts separate also prevents a subtle correctness bug: a node must be able to reject a checkpoint transition because the prep material is inconsistent with `prev_root`, before it ever trusts the post-state output.

Implementation checklist:

- [ ] Keep `PrepSnapshot` and `CheckpointArtifact` as distinct persisted types with distinct codecs, ids, and load paths.
- [ ] Forbid APIs that accept one merged pre-state-plus-post-state record as the canonical checkpoint representation.
- [ ] Add validation rules that require snapshot verification to succeed before checkpoint finalization or replay validation continues.
- [ ] Add tests proving that invalid prep material causes checkpoint construction or audit to fail even when the post-state artifact is otherwise well-formed.
- [ ] Reject any implementation that duplicates pre-state witness data inside final checkpoint payloads for convenience.

### 7.2 Enforced Consequences Of Separation

Artifact separation is not only a modeling choice. It changes allowed control flow in builders, validators, and auditors.

Implementation checklist:

- [ ] Make checkpoint builders consume snapshot identity explicitly rather than discovering or reconstructing snapshot context implicitly.
- [ ] Require replay and audit code to load snapshot and checkpoint artifacts independently and cross-check them by linkage metadata.
- [ ] Add tests proving that deleting or mutating snapshot artifacts does not rewrite checkpoint artifact meaning, only replay eligibility.
- [ ] Reject any future convenience wrapper that collapses snapshot, replay input, and checkpoint result into one canonical record.

## 8. Where Canonical Fields Come From

### 8.1 Field Source Of Truth Contract

The field origins must be fixed explicitly so there is no ambiguity at the storage boundary.

For the current repository, the typed checkpoint field origins are:

- `height`: the `height` argument passed into `apply_batch_checkpoint(...)`; Stage 6 currently uses the scenario stage number
- `prev_root`: the state root before batch apply, sourced from Stage-4 prep material and rechecked via `prep_root(&prep.rows)`
- `new_root`: the state root after `apply_batch_checkpoint(...)`
- `spent_delta`: consumed canonical `asset_id` values returned by `apply_batch_checkpoint(...)` in apply order
- `created_delta`: created `(asset_id, leaf_hash)` pairs returned by `apply_batch_checkpoint(...)` in apply order
- `cp_proof`: currently empty proof bytes from `apply_batch_checkpoint(...)`; Stage 6 omits them from its JSON wrapper entirely

Here `CreatedEnt.leaf_hash` is the checkpoint-layer name for the same canonical JMT terminal value hash that `jmt-storage-spec-gaps.md` maps to `ProofBlob.asset_leaf_hash` in the current code-backed proof contract. The checkpoint layer must not introduce a second hash meaning for the same inserted leaf.

The target checkpoint artifact also depends on one validated snapshot artifact, but the prep fields themselves belong to the separate snapshot contract and should not be duplicated inside the canonical checkpoint artifact.

Current Stage 6 also depends on Stage-4 tx package data because the repository does not yet persist a dedicated `CheckpointExecInput` artifact.

The following fields must not be promoted to canonical checkpoint storage fields:

- `fragment_ids`
- source tx file paths
- report file names
- local logger step ids

Implementation checklist:

- [ ] Define one source-of-truth mapping for every canonical artifact field and require builders to populate fields only from those sources.
- [ ] Compute `CreatedEnt.leaf_hash` from the same canonical terminal leaf-hash rule used by the JMT proof layer and reject any second hash meaning.
- [ ] Ensure `spent_delta` and `created_delta` are populated from deterministic apply results, not from simulator wrapper order or report artifacts.
- [ ] Add tests proving that audit-only metadata changes do not affect canonical artifact bytes or `CheckpointPubIn` reconstruction.
- [ ] Fail builders that attempt to source canonical fields from filenames, row numbers, or non-typed debug records.

### 8.2 Forbidden Field Sources

Some field sources are invalid even if they are convenient during simulation or debugging.

Implementation checklist:

- [ ] Forbid sourcing canonical roots from tx digests, report files, or scenario-local placeholders.
- [ ] Forbid sourcing canonical delta order from JSON row order unless that order is itself the deterministic apply order produced by typed execution.
- [ ] Forbid sourcing `leaf_hash` from wrapper caches or debug reports instead of canonical JMT leaf-hash computation.
- [ ] Add tests proving that builders reject artifacts assembled from debug or wrapper data when canonical typed inputs are unavailable.

## 9. Type Integrity And Domains

### 9.1 Typed Checkpoint Domain Contract

The storage contract should use strong semantic types, just as `jmt-storage-spec-gaps.md` already requires for the JMT layer.

Recommended semantic wrappers:

- `AssetStateRoot`
- `CheckpointHeight`
- `AssetId`
- `SerialId`
- `CheckpointProofBytes`

`MemberWitnessBytes` is only a proposed storage-level name. In the current codebase, the implemented witness carrier is `MemberWit`, and it belongs to the snapshot/pre-state side rather than to the checkpoint artifact payload.

The checkpoint layer should never accept free-form string roots internally. Hex encoding is an external transport encoding only.

The checkpoint layer must consume membership material only through validated prep snapshots. It must not reintroduce witness-themed placeholder digests into the checkpoint artifact itself.

Implementation checklist:

- [ ] Introduce or reuse strong types for asset-state roots, checkpoint height, asset ids, and proof bytes in all public checkpoint storage APIs.
- [ ] Forbid raw string roots and generic byte arrays at public boundaries except inside explicit codec modules.
- [ ] Keep membership witness bytes out of the canonical checkpoint payload and reject any proposal that embeds snapshot proof material into `CheckpointArtifact` for convenience.
- [ ] Add negative tests proving that wrong root type, wrong id type, or wrong proof byte container cannot cross the checkpoint boundary silently.
- [ ] Require adapters to convert external transport encodings into typed values before checkpoint validation begins.

### 9.2 Transport Conversion Boundary

Transport formats may still use hex strings or JSON fields, but conversion into typed checkpoint values must happen before any canonical validation.

Implementation checklist:

- [ ] Keep all string and hex decoding logic inside codec or adapter modules and out of canonical artifact validation logic.
- [ ] Require decoders to fail before validation starts if external data cannot be converted into typed checkpoint fields.
- [ ] Add tests proving that malformed transport encodings cannot reach artifact verification or replay logic as partially decoded values.
- [ ] Forbid storing transport-local field names as internal semantic identifiers inside checkpoint code.

## 10. Consistency Contract With JMT Storage

### 10.1 Checkpoint Consistency Invariants

The checkpoint storage layer is valid only if it is cryptographically and structurally consistent with `jmt-storage-spec-gaps.md`.

The mandatory target invariants are:

1. `CheckpointArtifact.prev_root` must equal the `PrepSnapshot.prev_root` from the validated snapshot used for that apply.
2. Every `SpentEnt.asset_id` must refer to one terminal leaf removed from the JMT state.
3. Every `CreatedEnt.asset_id` must refer to one terminal leaf inserted into the JMT state.
4. Every `CreatedEnt.leaf_hash` must equal the canonical JMT terminal value hash of the inserted `AssetLeaf`.
5. `CheckpointArtifact.new_root` must equal the resulting JMT root after all deletes and inserts.
6. `spent_delta` must preserve deterministic apply order.
7. `created_delta` must preserve deterministic apply order.
8. `spent_delta` must not contain duplicate terminal `asset_id` values.
9. `created_delta` must not contain duplicate terminal `asset_id` values.
10. Final `CheckpointArtifact.cp_proof` must be non-empty.

Current code does not yet satisfy invariant 10 because `apply_batch_checkpoint(...)` still emits empty `cp_proof` bytes and Stage 6 omits proof bytes from its JSON wrapper.

The storage contract must also preserve the identity split already fixed by `jmt-storage-spec-gaps.md`:

- `definition_id` is the logical asset namespace identity
- `asset_id` is the terminal leaf identity

Therefore checkpoint deltas must carry terminal `asset_id` values only. They must not carry `definition_id` as a substitute.

Implementation checklist:

- [ ] Implement one validation function that checks every invariant in this section against the artifact, snapshot, and apply result before the artifact is accepted or exported.
- [ ] Add distinct failure cases for root mismatch, duplicate spent ids, duplicate created ids, wrong leaf hash, empty final proof bytes, and identity substitution.
- [ ] Verify `CreatedEnt.leaf_hash` against canonical JMT leaf-hash logic rather than trusting serialized values blindly.
- [ ] Add tests proving that `definition_id` appearing where terminal `asset_id` is required causes a hard reject.
- [ ] Reject final artifacts whose `prev_root` is not exactly the validated snapshot root used for the apply.

### 10.2 Delta Order And Identity Enforcement

Checkpoint consistency is not only about roots. It also depends on exact delta ordering and correct terminal identity usage.

Implementation checklist:

- [ ] Preserve deterministic order of `spent_delta` and `created_delta` from typed apply execution without post-processing or sorting.
- [ ] Add tests proving that duplicate `asset_id` values in either delta are rejected even when all roots are otherwise consistent.
- [ ] Add tests proving that substituting `definition_id` for terminal `asset_id` fails before proof verification or replay comparison.
- [ ] Require replay comparison to use exact ordered delta equality rather than set equality.

## 11. Storage Abstractions For z00z_storage

### 11.1 Public Checkpoint Facade Contract

The new crate should expose checkpoint-side abstractions that sit one layer above the asset hierarchy store.

These abstractions are proposed API surfaces. None of `CheckpointStore`, `CheckpointId`, `CheckpointExecInputId`, `CheckpointArtifact`, or `CheckpointLink` currently exists as a concrete storage API in the repository.

Recommended public abstractions:

- `CheckpointStore`
- `CheckpointId`
- `CheckpointExecInputId`
- `CheckpointArtifact`
- `CheckpointLink`
- `CheckpointStorageError`

Recommended responsibilities:

- persist and load canonical checkpoint artifacts
- bind a checkpoint artifact to the prep snapshot it was built from through non-consensus linkage metadata
- optionally persist and load ordered execution input for local deterministic re-apply
- assign or verify content-addressed identities for both final checkpoint artifacts and execution-input helpers
- enforce that checkpoint, snapshot, and execution-input linkage stays one-to-one for one canonical transition artifact set
- expose typed public inputs for validator verification
- distinguish checkpoint drafts from final proved checkpoint artifacts
- expose optional audit views separately from consensus payloads

The JMT storage layer remains the source of truth for state roots and leaf hashes. The checkpoint storage layer is a typed artifact layer above that state.

Reference facade sketch:

```rust
pub trait CheckpointStore {
    fn save_draft(
        &mut self,
        draft: &CheckpointDraft,
    ) -> Result<CheckpointDraftId, CheckpointStorageError>;

    fn finalize_artifact(
        &mut self,
        draft_id: &CheckpointDraftId,
        proof: CheckpointProofBytes,
        link: &CheckpointLink,
    ) -> Result<CheckpointId, CheckpointStorageError>;

    fn load_artifact(
        &self,
        checkpoint_id: &CheckpointId,
    ) -> Result<CheckpointArtifact, CheckpointStorageError>;

    fn load_exec_input(
        &self,
        exec_input_id: &CheckpointExecInputId,
    ) -> Result<CheckpointExecInput, CheckpointStorageError>;

    fn validate_artifact(
        &self,
        artifact: &CheckpointArtifact,
    ) -> Result<CheckpointPubIn, CheckpointStorageError>;
}
```

Reference ownership split:

```mermaid
flowchart TD
    JMT[JMT Asset State]
    SNAP[PrepSnapshot Store]
    EXEC[CheckpointExecInput Store]
    CSTORE[CheckpointStore]
    AUDIT[CheckpointAuditView]

    JMT --> CSTORE
    SNAP --> CSTORE
    EXEC --> CSTORE
    CSTORE --> AUDIT
```

Implementation checklist:

- [ ] Define a narrow public `CheckpointStore` API that exposes only canonical artifact operations, linkage operations, and replay-helper operations needed by callers.
- [ ] Keep checkpoint persistence, linkage persistence, and execution-input persistence explicit rather than hiding them behind one ambiguous save method.
- [ ] Define one explicit error taxonomy for proofless final artifacts, linkage mismatch, replay-input mismatch, bad root binding, codec failure, and backend failure.
- [ ] Add adapter modules for simulator and wallet integration rather than leaking checkpoint storage internals into those crates.
- [ ] Add API tests proving callers can verify artifacts and replay inputs without depending on simulator-local JSON wrappers.
- [ ] Separate `save_draft`, `finalize_artifact`, `save_link`, and `save_exec_input` into distinct entry points and reject facade designs where artifact class is inferred from payload shape.
- [ ] Require the public facade to accept typed ids and typed link records only; do not accept loose tuples like `(checkpoint_id, snapshot_id, exec_id)` at unrelated call sites.
- [ ] Add one API conformance test proving that a caller can validate a final artifact without being able to mutate stored replay helpers through the same handle.
- [ ] Add one adapter test proving simulator code can consume audit wrappers without importing canonical checkpoint modules directly.

### 11.2 Persistence Surface Rules

Persistence methods must make artifact class explicit so callers cannot accidentally store drafts, finals, links, and replay inputs through one ambiguous interface.

Implementation checklist:

- [ ] Provide distinct save/load operations or distinct typed handles for drafts, final artifacts, linkage records, and execution-input helpers.
- [ ] Require API naming to reflect artifact class and reject generic methods that infer meaning from payload shape alone.
- [ ] Add tests proving that callers cannot accidentally load a draft through a final-artifact API or a replay helper through a canonical-artifact API.
- [ ] Keep backend paths and content-addressed ids consistent across save/load operations so artifact identity does not depend on caller-selected filenames.

## 12. Build Algorithm

### 12.1 Replay Input Validation

Checkpoint artifact construction must happen after deterministic apply against the same root and after the corresponding snapshot artifact has already been validated under the separate snapshot contract.

This section describes the target storage build path. The current Stage-6 path instead loads `checkpoint_prep.json`, rebuilds `prep_root(&prep.rows)`, loads the Stage-4 tx package, reconstructs `TxPkgSum`, and then runs `apply_batch_checkpoint(...)` directly.

1. Load `PrepSnapshot`.
2. Assert that all entries bind to the same `prev_root`.
3. Load ordered checkpoint execution input containing output leaves and per-tx proof bytes.
4. Assert that the execution input is the one linked to the same prep snapshot through replay-safe content-addressed linkage metadata.
5. Assert that the resolved execution-input identity is the one associated with the checkpoint draft or final artifact being built or audited.

Reference validation flow:

```mermaid
sequenceDiagram
    participant Builder as Checkpoint Builder
    participant Snap as PrepSnapshot Store
    participant Exec as ExecInput Store
    participant Link as Link Store

    Builder->>Snap: load(prep_snapshot_id)
    Snap-->>Builder: PrepSnapshot
    Builder->>Exec: load(exec_input_id)
    Exec-->>Builder: CheckpointExecInput
    Builder->>Link: load(checkpoint_id or draft_id)
    Link-->>Builder: CheckpointLink
    Builder->>Builder: assert same prep_snapshot_id
    Builder->>Builder: assert same exec_input_id
    Builder->>Builder: assert same prev_root
```

Reference validator sketch:

```rust
pub fn validate_replay_inputs(
    snapshot: &PrepSnapshot,
    exec_input: &CheckpointExecInput,
    link: &CheckpointLink,
) -> Result<(), CheckpointStorageError> {
    if snapshot.id() != link.prep_snapshot_id {
        return Err(CheckpointStorageError::SnapshotLinkMismatch);
    }
    if exec_input.exec_input_id != link.exec_input_id {
        return Err(CheckpointStorageError::ExecInputLinkMismatch);
    }
    if exec_input.prep_snapshot_id != link.prep_snapshot_id {
        return Err(CheckpointStorageError::ExecInputSnapshotMismatch);
    }
    if exec_input.prev_root != snapshot.prev_root {
        return Err(CheckpointStorageError::PrevRootMismatch);
    }
    Ok(())
}
```

Implementation checklist:

- [ ] Load and validate `PrepSnapshot` before any checkpoint apply or artifact finalization logic runs.
- [ ] Decode and validate `CheckpointExecInput` as a separate artifact before building the typed apply summary.
- [ ] Reject the build if snapshot identity, snapshot root, or execution-input identity does not match the linked transition set exactly.
- [ ] Add tests for mismatched `prep_snapshot_id`, mismatched `exec_input_id`, and execution-input bodies that are structurally valid but linked to the wrong pre-state snapshot.
- [ ] Forbid builders from reconstructing replay input from mutable filenames or simulator-local handles once canonical execution-input artifacts exist.
- [ ] Run replay-input validation in one fixed order: snapshot decode, snapshot verification, exec-input decode, link load, id cross-check, then root cross-check; do not let callers reorder these checks ad hoc.
- [ ] Emit distinct errors for snapshot-id mismatch, exec-input-id mismatch, snapshot-root mismatch, and malformed ordered inputs so failed builds are diagnosable and testable.
- [ ] Add a negative test where all ids match but `prev_root` differs, proving linkage alone is insufficient without root agreement.
- [ ] Reject any builder path that fetches tx packages or outputs before snapshot and exec-input linkage are proven consistent.

### 12.2 State Apply And Draft Construction

1. Build the typed state-update summary expected by `apply_batch_checkpoint(...)`.
2. Apply deletes and inserts against the JMT-backed state.
3. Record `spent_delta` in apply order.
4. Record `created_delta` in apply order.
5. Record `new_root`.
6. Treat the result as a `CheckpointDraft` until checkpoint proof bytes are attached.

Reference apply flow:

```mermaid
flowchart TD
    A[Validated PrepSnapshot] --> B[Validated CheckpointExecInput]
    B --> C[Build Typed Apply Summary]
    C --> D[Apply Deletes To JMT]
    D --> E[Apply Inserts To JMT]
    E --> F[Collect spent_delta and created_delta]
    F --> G[Capture new_root]
    G --> H[Emit CheckpointDraft]
```

Reference builder sketch:

```rust
pub fn build_checkpoint_draft(
    height: CheckpointHeight,
    snapshot: &PrepSnapshot,
    exec_input: &CheckpointExecInput,
    state: &mut dyn AssetHierarchyApply,
) -> Result<CheckpointDraft, CheckpointStorageError> {
    let apply_summary = build_apply_summary(snapshot, exec_input)?;
    let apply_result = state.apply_checkpoint(snapshot.prev_root, &apply_summary)?;

    Ok(CheckpointDraft {
        version: CheckpointVersion::V1,
        height,
        prev_root: snapshot.prev_root,
        new_root: apply_result.new_root,
        spent_delta: apply_result.spent_delta,
        created_delta: apply_result.created_delta,
    })
}
```

Implementation checklist:

- [ ] Build one canonical typed apply summary from validated snapshot plus validated execution input and forbid ad-hoc simulator-specific apply paths.
- [ ] Apply the state transition exactly once against the validated `prev_root` and capture `spent_delta`, `created_delta`, and `new_root` from that one execution result.
- [ ] Preserve deterministic apply order in both deltas and reject any builder that re-sorts or groups entries after apply.
- [ ] Create `CheckpointDraft` immediately from typed apply results and forbid temporary draft shapes that drop `height`, mutate order, or rename fields.
- [ ] Add tests proving that identical pre-state plus identical execution input always yields identical draft bytes and identical public inputs.
- [ ] Freeze the apply order contract in code: deletes must be derived from snapshot inputs, inserts must be derived from ordered execution inputs, and the resulting deltas must be recorded in the exact sequence returned by typed apply.
- [ ] Add one deterministic fixture that runs the same snapshot plus exec-input pair twice and proves the draft bytes, public inputs, and `new_root` are identical.
- [ ] Add one negative fixture where helper code tries to sort `spent_delta` or `created_delta` after apply, and prove that replay comparison or canonical encoding rejects the mutated order.
- [ ] Reject any draft builder that rehydrates deltas from logs, reports, or simulator wrappers instead of the one typed apply result.

### 12.3 Finalization And Artifact Identity

1. Attach non-empty `cp_proof` bytes.
2. Compute external content-addressed `CheckpointId` from the canonical serialized final artifact body.
3. Persist `CheckpointArtifact` together with that external identity.

The storage layer must reject any attempt to apply a checkpoint artifact against a different `prev_root` than the one committed by the prep snapshot.

The storage layer must also reject any attempt to finalize a checkpoint artifact with empty `cp_proof` bytes.

The storage layer must not claim that `CheckpointArtifact` alone is sufficient for local deterministic re-apply. Local re-apply also needs ordered execution input that carries outputs and tx-proof material.

The storage layer should also reject replay-critical linkage that is based only on mutable external names rather than artifact digests or other canonical content-addressed identities.

The storage layer should also reject any checkpoint identity scheme that hashes a payload already embedding that same `CheckpointId`, because that makes the artifact id recursively self-referential.

The storage layer should also reject any replay linkage scheme where `prep_snapshot_id` alone is treated as sufficient to identify ordered execution input, because one pre-state snapshot can theoretically be paired with multiple candidate transition attempts during local build or audit flows.

Reference finalization flow:

```mermaid
sequenceDiagram
    participant Draft as CheckpointDraft
    participant Prover as Proof Producer
    participant Store as CheckpointStore
    participant Link as CheckpointLink Store

    Draft->>Prover: build proof over CheckpointPubIn
    Prover-->>Draft: cp_proof
    Draft->>Store: finalize_artifact(draft_id, cp_proof, link)
    Store->>Store: rebuild CheckpointArtifact
    Store->>Store: derive CheckpointId from canonical bytes
    Store->>Link: persist linkage by ids
    Store-->>Draft: CheckpointId
```

Implementation checklist:

- [ ] Finalize a `CheckpointDraft` into `CheckpointArtifact` only through one explicit function that attaches non-empty proof bytes and re-encodes the full final artifact.
- [ ] Compute `CheckpointId` from canonical artifact bytes only and keep it outside the self-serialized payload.
- [ ] Reject finalization when `cp_proof` is empty, linkage is incomplete, artifact bytes are not canonical, or `prev_root` does not match the validated snapshot root.
- [ ] Add tests proving that finalization does not alter `height`, roots, or deltas and changes only the proof-carrying final artifact layer.
- [ ] Add tests proving that two different proof byte payloads over the same draft yield different final artifact bytes and different `CheckpointId` values.
- [ ] Reconstruct `CheckpointPubIn` from the draft immediately before proof attachment and reject finalization if the proof was produced over a different public-input set.
- [ ] Persist linkage only after the final artifact bytes and `CheckpointId` are fixed, so link records cannot point at mutable or draft-stage payloads.
- [ ] Add one negative test where a valid proof is paired with the wrong `CheckpointLink`, proving finalization rejects id-consistent but transition-inconsistent linkage.
- [ ] Add one round-trip test that stores a final artifact, reloads it, recomputes `CheckpointId`, and proves the persisted link still points to the exact same artifact bytes.

## 13. Versioning Strategy

### 13.1 Artifact Version Contract

The prep snapshot and checkpoint artifact schemas should use independent artifact schema versions.

Recommended initial artifact types:

- `PrepSnapshot`
- `CheckpointArtifact`

The artifact schema version is not the same thing as JMT tree version and not the same thing as checkpoint height.

The version split is therefore:

- JMT tree version: state-store progression
- checkpoint height: chain progression
- artifact schema version: serialization contract progression

Under the current contract, `CheckpointArtifact.version` must determine the public-input schema and proof verification rule for `cp_proof`. If multiple proof systems or proof encodings must coexist under one artifact version, a later artifact revision must add an explicit proof-system discriminator.

Implementation checklist:

- [ ] Define artifact version semantics explicitly and keep them separate from checkpoint height and JMT state version in both code and docs.
- [ ] Make `CheckpointArtifact.version` the single source of truth for artifact schema and proof-verification expectations.
- [ ] Reject any implementation that infers artifact schema from height, transport wrapper version, or simulator stage number.
- [ ] Add tests proving that artifacts with unsupported versions fail before proof verification or replay logic begins.
- [ ] Reopen proof-system discrimination only through a later explicit artifact revision with migration tests and compatibility rules.

### 13.2 Version Compatibility Rules

Artifact versioning must control upgrade and reject behavior, not only codec selection.

Implementation checklist:

- [ ] Define explicit behavior for older supported versions, newer unsupported versions, and malformed version tags.
- [ ] Require loaders to reject unknown versions before any proof verification, replay linkage, or draft/final casting begins.
- [ ] Add compatibility tests proving that supported-version artifacts round-trip without implicit upgrade or silent field rewriting.
- [ ] Forbid artifact version branching logic from leaking into simulator wrappers as an alternative source of truth.

## 14. Proof Model

### 14.1 Final Artifact Proof Verification

The checkpoint storage layer does not redefine the proof model. It serializes the proof boundary already implied by `z00z_wallets` and by the ECC material.

The prep snapshot stores membership material under the separate snapshot contract.

The checkpoint artifact stores checkpoint proof output and typed public inputs.

The canonical verifier contract is:

1. Deserialize `CheckpointArtifact`.
2. Extract `CheckpointPubIn` from its typed fields.
3. Verify `cp_proof` against those public inputs.
4. Accept the transition only if the proof verifies and the roots match the storage layer expectations.

Under the current wallet contract, `CheckpointPubIn` consists of `prev_root`, `new_root`, `spent_delta`, and `created_delta`. It does not include `height`.

Reference verifier sketch:

```rust
pub fn verify_checkpoint_artifact(
    artifact: &CheckpointArtifact,
) -> Result<CheckpointPubIn, CheckpointStorageError> {
    let pub_in = CheckpointPubIn {
        prev_root: artifact.prev_root,
        new_root: artifact.new_root,
        spent_delta: artifact.spent_delta.clone(),
        created_delta: artifact.created_delta.clone(),
    };

    verify_checkpoint_proof(&artifact.cp_proof, &pub_in)
        .map_err(CheckpointStorageError::ProofVerifyFailed)?;

    Ok(pub_in)
}
```

Implementation checklist:

- [ ] Implement one canonical verifier entry point that reconstructs `CheckpointPubIn` from artifact fields and verifies `cp_proof` against that exact public input set.
- [ ] Add distinct reject reasons for bad proof bytes, bad public-input reconstruction, and root expectation mismatch.
- [ ] Add tests proving that valid proof bytes fail if any one of `prev_root`, `new_root`, `spent_delta`, or `created_delta` is tampered with in the artifact.
- [ ] Add tests proving that proof verification never consumes simulator-only metadata or replay-only helper fields.
- [ ] Keep the proof verification path independent from local deterministic replay so consensus acceptance does not depend on replay helpers being present.
- [ ] Freeze verifier order in code: decode artifact, rebuild public inputs, verify proof, then compare external root expectations; do not allow caller-specific reordering that can hide the real failure class.
- [ ] Add one tamper test per canonical public-input field so the verifier suite proves exact binding to both roots, both deltas, and proof bytes independently.
- [ ] Add one regression test proving that attaching audit metadata wrappers or replay helpers around the same artifact does not change verifier input or verifier result.
- [ ] Reject any verifier helper that accepts prebuilt `CheckpointPubIn` from callers instead of reconstructing it from the artifact being verified.

### 14.2 Separation From Snapshot Proof Material

The prep snapshot is not itself a consensus proof object. It is the persisted pre-state witness package needed to construct or audit the checkpoint transition.

Local deterministic re-apply remains an audit and debugging tool. It is not the consensus oracle. The final consensus decision comes from checkpoint proof verification over typed public inputs.

Implementation checklist:

- [ ] Keep snapshot witness material outside the canonical checkpoint artifact payload and reject any artifact codec that embeds `MemberWit` or snapshot proof bytes directly.
- [ ] Ensure consensus verification of `CheckpointArtifact` can run without loading replay execution input, while local audit flows still require that extra material explicitly.
- [ ] Add tests proving that removing replay helpers does not change final proof-verification results, only replay capability.
- [ ] Add tests proving that malformed or missing snapshot witness material causes replay failure but does not redefine the meaning of the final checkpoint artifact proof.
- [ ] Document in code and spec that snapshot validation and checkpoint proof verification are complementary but distinct acceptance checks.

## 15. Replay And Audit Semantics

### 15.1 Consensus Acceptance Versus Local Replay

Replay semantics split into two different categories.

Consensus replay safety depends on the final checkpoint artifact plus proof verification.

Local deterministic re-apply depends on three inputs:

1. snapshot-side pre-state material
2. checkpoint-side post-state artifact
3. ordered checkpoint execution input carrying outputs and tx-proof material

In the target storage design, `PrepSnapshot` is the pre-state replay anchor.

In the target storage design, `CheckpointArtifact` is the executed transition replay anchor.

In current code, the effective replay anchor set is Stage-4 `PrepFile`/`PrepRow`, the Stage-4 tx package, and the wallet `CheckpointPubIn`-equivalent data serialized into the Stage-6 checkpoint JSON wrapper.

A local deterministic re-apply must be able to:

1. Load `PrepSnapshot`.
2. Load ordered checkpoint execution input.
3. Reconstruct the typed tx summary.
4. Re-apply against `prev_root`.
5. Recover the same `new_root`, `spent_delta`, and `created_delta`.
6. Compare the re-applied public inputs against the stored `CheckpointArtifact`.

`CheckpointArtifact` alone is sufficient for proof verification, but not for local deterministic re-apply.

Replay consistency is useful for audit and testing, but proof verification over `cp_proof` remains the final acceptance rule.

Implementation checklist:

- [ ] Keep consensus verification and local replay as two distinct APIs with two distinct preconditions and error surfaces.
- [ ] Require replay tooling to load all three artifacts: `PrepSnapshot`, `CheckpointArtifact`, and `CheckpointExecInput`.
- [ ] Reject any replay request that tries to proceed from `CheckpointArtifact` alone without ordered execution input.
- [ ] Add tests proving that proof verification can succeed while replay intentionally fails on missing or mismatched replay helpers.
- [ ] Add tests proving that replay output must match stored public inputs exactly or the transition is flagged as locally inconsistent.

### 15.2 Audit Metadata Boundary

Audit metadata may additionally record fragment traces, simulator stage ids, or report references, but those must not alter the canonical replay result.

Implementation checklist:

- [ ] Keep audit metadata in separate wrappers or reports and forbid it from changing canonical artifact bytes, ids, or reconstructed public inputs.
- [ ] Add tests proving that fragment traces, stage ids, and report references can change without affecting `CheckpointId` or proof verification.
- [ ] Require audit tooling to consume canonical artifacts plus optional wrappers, not the other way around.
- [ ] Add review gates that reject any future attempt to promote audit-only fields into canonical checkpoint payloads without an explicit spec revision.

## 16. Migration From Current Simulator Wrappers

### 16.1 Pre-Migration Blockers

The simulator wrappers should be treated as useful prototypes, not as final contracts.

Before the canonical checkpoint storage rollout begins, the following blockers must be removed:

- `tx_digest_hex` must stop acting as placeholder checkpoint proof material
- proofless `Checkpoint` outputs must stop being treated as final artifacts
- simulator wrapper fields such as `fragment_ids` must stop being candidates for canonical payload fields
- the storage-layer checkpoint artifact types and linkage records described in this document must actually exist rather than remaining design-only names

Implementation checklist:

- [ ] Make these blockers explicit release blockers and fail rollout if any one remains active outside isolated migration tests.
- [ ] Add temporary assertions or feature-gated hard rejects at each blocker call site so stale flows fail loudly.
- [ ] Land one regression test per blocker proving it is gone before canonical checkpoint artifacts are enabled in non-test paths.
- [ ] Record the owning files and removal tasks for every blocker so shim removal can be tracked to completion.

### 16.2 Migration Phase Order

The clean migration path is:

1. Keep the current JSON artifact files for scenario debugging.
2. Introduce canonical artifact types in `z00z_storage` or a checkpoint module adjacent to it.
3. Keep prep witness migration inside the separate snapshot contract rather than duplicating it in the checkpoint payload.
4. Replace `tx_digest_hex` as placeholder proof material with real checkpoint-proof bytes.
5. Extend the simulator checkpoint wrapper to include `height` and `cp_proof` or wrap the canonical checkpoint record instead of redefining it.
6. Treat current `cp_proof = []` outputs as drafts, not final checkpoint artifacts.
7. Introduce ordered execution-input storage for local deterministic re-apply instead of overloading the final checkpoint artifact.
8. Move `fragment_ids` into an audit-only wrapper or report artifact.
9. Prefer content-addressed linkage records over mutable filename-based or row-based references.
10. Introduce external content-addressed `CheckpointId` rather than relying on filenames or self-embedded ids.
11. Introduce external content-addressed `CheckpointExecInputId` rather than treating `prep_snapshot_id` alone as the execution-input identity.

The minimum acceptance criteria for migration are:

1. No checkpoint artifact binds `prev_root` under `tx_digest_hex`.
2. No final checkpoint artifact omits the canonical `height` or carries empty `cp_proof` bytes.
3. No checkpoint delta uses `definition_id` as a substitute for `asset_id`.
4. No audit metadata is mixed into typed checkpoint public inputs.
5. No code path claims local deterministic re-apply from `CheckpointArtifact` alone without ordered execution input.
6. No replay-critical checkpoint linkage relies only on mutable filenames, row indices, or transport-local ids.
7. No checkpoint identity is defined recursively by hashing a payload that already embeds that same identity.
8. No replay-critical execution-input linkage treats `prep_snapshot_id` alone as a sufficient execution-input identity.

Reference migration sequence:

```text
Phase A: Introduce CheckpointDraft and CheckpointArtifact types with separate codecs.
Phase B: Replace tx-digest proof placeholders with real checkpoint-proof bytes and keep asset-state roots sourced only from storage/apply APIs.
Phase C: Introduce CheckpointExecInput and injective CheckpointLink records.
Phase D: Make simulator wrappers wrap canonical artifacts instead of redefining them.
Phase E: Enforce non-empty cp_proof for final artifacts and remove proofless-final paths.
Phase F: Remove filename-based linkage and legacy wrapper semantics from public APIs.
```

Implementation checklist:

- [ ] Convert the numbered migration path into named phases with immutable entry criteria, scope, exit criteria, and explicit canonical versus compatibility APIs.
- [ ] Do not overlap root-source repair, draft-versus-final separation, and replay-linkage redesign unless the earlier phase exit tests are already green.
- [ ] Require each phase to document the expected root source, expected artifact type, expected linkage rule, and expected replay inputs so later phases cannot regress them.
- [ ] Add one integration test suite that is rerun after every migration phase and proves both supported legacy behavior and new canonical checkpoint behavior.
- [ ] Mark the migration incomplete until every minimum acceptance criterion in this section is enforced by code or tests rather than comments alone.
- [ ] Treat each migration phase as blocked until one fixture from the previous phase is re-run unchanged and still passes under the new canonical APIs.
- [ ] Require each phase to name the exact simulator wrapper fields that remain compatibility-only and the exact canonical fields that replace them.
- [ ] Add one migration audit table mapping every legacy root source, proofless artifact path, filename-based link, and audit-only field to its removal phase and replacement API.
- [ ] Reject any migration step that introduces new wrapper-only checkpoint semantics instead of shrinking the wrapper surface.

### 16.3 Compatibility Shim Removal

Implementation checklist:

- [ ] Introduce every compatibility shim with an owning file, list of callers, explicit removal condition, and target removal phase.
- [ ] Forbid long-lived generic fallback paths that silently accept both legacy and canonical checkpoint semantics.
- [ ] Remove legacy root placeholders and proofless-final-artifact paths before final checkpoint verification is wired into non-test flows.
- [ ] Add tests proving that once a shim is removed, legacy callers fail loudly rather than being auto-mapped into canonical semantics.
- [ ] Close the migration only when shim inventory is empty and no legacy wrapper semantics remain reachable from public checkpoint APIs.

## 17. Suggested Crate Layout

### 17.1 Module Boundary Contract

A practical first layout for checkpoint-side storage is:

```text
crates/z00z_storage/
├── src/
│   ├── lib.rs
│   ├── error.rs
│   ├── root.rs
│   ├── checkpoint/
│   │   ├── mod.rs
│   │   ├── ids.rs
│   │   ├── artifact.rs
│   │   ├── audit.rs
│   │   ├── exec_input.rs
│   │   ├── link.rs
│   │   ├── codec.rs
│   │   └── store.rs
│   └── assets/
│       └── ...
```

The public facade should export only typed checkpoint-side contracts, not raw JSON helper records from the simulator.

Implementation checklist:

- [ ] Keep artifact codecs, ids, linkage, replay input, and audit wrappers in separate checkpoint modules with one source of truth per responsibility.
- [ ] Keep simulator wrapper adapters outside the canonical artifact modules so simulator concerns cannot leak into consensus-facing codecs.
- [ ] Restrict public re-exports in `lib.rs` to typed checkpoint-side contracts and keep helper modules `pub(crate)` unless cross-crate adapters require them.
- [ ] Add module-level documentation stating whether each module is consensus-facing, replay-facing, or audit-only.
- [ ] Prevent downstream crates from depending on internal checkpoint modules directly when a facade or adapter API exists.

### 17.2 Dependency Direction Rules

Checkpoint storage modules must depend downward on asset-state and codec primitives, not sideways on simulator-local wrapper code.

Implementation checklist:

- [ ] Keep simulator adapters at the outer boundary and forbid canonical checkpoint modules from importing simulator wrapper types directly.
- [ ] Ensure checkpoint artifact modules depend on typed ids, roots, codecs, and asset-state abstractions only.
- [ ] Add review checks that reject cyclic dependencies between canonical checkpoint modules and replay or audit wrappers.
- [ ] Keep dependency direction documented so future persistent backends do not force simulator concerns into canonical modules.

## 18. Minimal First Milestone

### 18.1 First Milestone Scope

The first milestone should avoid over-design and focus on structural correctness.

Recommended scope:

1. Define `CheckpointArtifact`, `CheckpointDraft`, `CheckpointLink`, and `CheckpointExecInput`.
1. Add canonical JSON and binary codecs for the final artifact and draft forms.
1. Add adapters from `z00z_wallets::core::tx::Checkpoint` into `CheckpointDraft`.
1. Add a finalization step that attaches non-empty `cp_proof` bytes to produce `CheckpointArtifact`.
1. Add tests proving that final checkpoint artifacts round-trip canonically.
1. Add tests proving that `PrepSnapshot.prev_root == CheckpointArtifact.prev_root` for the same apply through linkage metadata.
1. Add tests proving that `CreatedEnt.leaf_hash` matches the JMT leaf hash contract.
1. Add tests proving that `fragment_ids` remain audit-only and do not affect `CheckpointPubIn`.
1. Add tests proving that empty `cp_proof` bytes are rejected for final checkpoint artifacts.
1. Add tests proving that local deterministic re-apply requires ordered execution input and cannot be reconstructed from final checkpoint artifact alone.
1. Add tests proving that linkage survives export and reload because it is based on canonical artifact ids or digests rather than mutable filenames.
1. Add tests proving that finalization from `CheckpointDraft` to `CheckpointArtifact` does not alter `prev_root`, `new_root`, `spent_delta`, or `created_delta`.
1. Add tests proving that `CheckpointId` is stable across export and reload because it is computed from canonical artifact bytes only.
1. Add tests proving that `CheckpointExecInputId` is stable across export and reload because it is computed from canonical execution-input bytes only.
1. Add tests proving that two candidate execution-input bodies for the same `PrepSnapshotId` cannot be linked ambiguously to one final checkpoint artifact.
1. Add tests proving that `CheckpointLink` is invalid unless `checkpoint_id`, `prep_snapshot_id`, and `exec_input_id` refer to one consistent transition artifact set.

Implementation checklist:

- [ ] Freeze the first milestone to canonical artifact shape, canonical linkage shape, canonical execution-input helper shape, and structural validation only.
- [ ] Keep the first milestone independent of simulator UX improvements, persistent storage optimization, and alternate proof-system support.
- [ ] Require milestone code to expose only the minimum artifact operations needed to create, finalize, persist, load, and validate checkpoint artifacts and replay helpers.
- [ ] Produce deterministic fixtures covering at least one valid transition, one proofless draft, one wrong-root transition, and one ambiguous-linkage attempt.
- [ ] Reject milestone sign-off if any required artifact, linkage, replay, or proof-boundary test remains missing.

### 18.2 Mandatory Test Matrix

Implementation checklist:

- [ ] Group milestone tests into explicit buckets: draft-versus-final separation, root consistency, leaf-hash consistency, linkage injectivity, replay-input necessity, and artifact-id stability.
- [ ] Provide at least one positive and one negative test for every bucket so each invariant is covered in both directions.
- [ ] Add golden fixtures for canonical `CheckpointArtifact`, `CheckpointDraft`, `CheckpointLink`, and `CheckpointExecInput` bytes so future migrations can detect codec drift.
- [ ] Add replay tests proving that the same final artifact cannot be paired with the wrong execution-input body or wrong snapshot linkage.
- [ ] Require CI to fail if any test bucket is skipped, filtered out, or left without negative coverage.

Reference test layout:

```text
tests/
    checkpoint_draft_final.rs
    checkpoint_root_binding.rs
    checkpoint_leaf_hash.rs
    checkpoint_link_injective.rs
    checkpoint_replay_inputs.rs
    checkpoint_ids.rs
    fixtures/
        checkpoint_valid.json
        checkpoint_draft.json
        checkpoint_wrong_root.json
        checkpoint_wrong_link.json
        checkpoint_exec_input.json
```

Reference test buckets:

```rust
#[test]
fn final_artifact_rejects_empty_cp_proof() {}

#[test]
fn artifact_prev_root_must_match_snapshot_prev_root() {}

#[test]
fn created_leaf_hash_must_match_canonical_jmt_leaf_hash() {}

#[test]
fn checkpoint_link_requires_all_three_content_ids() {}

#[test]
fn replay_requires_exec_input_even_when_proof_verifies() {}

#[test]
fn checkpoint_id_is_stable_across_roundtrip() {}
```

- [ ] Split each bucket into fixed case names, fixture inputs, expected reject reasons, and acceptance criteria so coverage cannot be satisfied by vague integration tests.
- [ ] Require one end-to-end fixture family where the same logical transition is replayed as valid, wrong-root, wrong-link, wrong-leaf-hash, proofless-final, and wrong-exec-input variants.
- [ ] Add one regression fixture derived from current simulator-style checkpoint JSON and prove canonical loaders reject it until migration adapters normalize missing `height`, empty `cp_proof`, and audit-only fields.
- [ ] Track the checkpoint test matrix in CI through a stable manifest so any new invariant must add both positive and negative rows before merge.

### 18.3 Milestone Exit Criteria

Implementation checklist:

- [ ] Mark the milestone complete only when all test buckets pass and no blocker from sections `5`, `10`, `12`, `14`, or `16` remains unresolved.
- [ ] Require one review pass focused only on root aliasing, proofless-final-artifact rejection, and replay-linkage injectivity before acceptance.
- [ ] Document exactly which canonical artifacts and helpers the milestone produces and which simulator wrappers remain compatibility-only.
- [ ] Do not start persistent backend expansion or richer simulator integration until this exit checklist is fully checked off.

## 19. Concrete Recommendation

### 19.1 Implementation Direction Contract

The correct implementation strategy is not to invent a new checkpoint format from scratch.

The correct strategy is:

- reuse the canonical typed checkpoint model already present in `z00z_wallets`
- treat the prep side as a separate snapshot contract instead of duplicating it here
- distinguish local state-apply drafts from final proved checkpoint artifacts
- keep audit metadata separate from canonical checkpoint public inputs
- bind the checkpoint artifact to real JMT asset-state roots only

Today the repository only implements the first and fourth bullets fully, implements the fifth bullet at the root-binding level, and still leaves the second and third bullets as storage-layer follow-up work.

In practical terms, the current-versus-target split should be:

- current Stage-4 `PrepFile`/`PrepRow` plus Stage-4 tx package for resolved pre-state material and replay inputs
- current wallet `Checkpoint` for local post-apply but not-yet-proved output
- future `CheckpointDraft` and `CheckpointArtifact` for explicit draft-versus-final storage semantics
- future optional `CheckpointAuditView` for simulator and operator-facing metadata

This stays fully aligned with `jmt-storage-spec-gaps.md`, preserves the terminal `asset_id` contract, and gives the simulator a clean path from placeholders to real checkpoint storage.

Implementation checklist:

- [ ] Use this section as the architecture guardrail for code review and reject any patch that changes canonical artifact shape, replay linkage semantics, and simulator UX all in one step.
- [ ] Keep the implementation sequence aligned with this recommendation: reuse typed checkpoint model first, add canonical wrappers next, then migrate simulator and replay paths.
- [ ] Reject any proposal that duplicates snapshot witness material or audit metadata into final checkpoint artifacts for convenience.
- [ ] Require canonical artifact ids and replay-link ids before treating simulator exports as durable storage artifacts.
- [ ] Keep optimization work out of the first correctness milestone unless it is proven semantics-preserving.

### 19.2 Explicit Non-Goals

The recommended implementation direction excludes several tempting but unsafe shortcuts.

Implementation checklist:

- [ ] Do not redesign checkpoint public inputs and artifact storage shape in the same milestone.
- [ ] Do not collapse snapshot, execution-input, and checkpoint result into one canonical artifact.
- [ ] Do not infer durable artifact identity from simulator filenames, branch-local counters, or export order.
- [ ] Do not add audit metadata to canonical checkpoint payloads without an explicit spec revision and new proof-boundary tests.

## 20. Compliance And Open Questions

### 20.1 Compliance Gates

This specification is compliant with `jmt-storage-spec-gaps.md` only under the following required interpretations:

1. `prev_root` and `new_root` are real asset-state roots.
2. `spent_delta` and `created_delta` carry terminal `asset_id` values only.
3. the prep side is validated under the separate snapshot contract before checkpoint finalization.
4. final checkpoint artifacts carry non-empty `cp_proof` bytes.
5. audit metadata is not part of the canonical checkpoint public input set.
6. local deterministic re-apply is treated as a separate builder/audit concern and not as an intrinsic property of the final checkpoint artifact payload.

Implementation checklist:

- [ ] Turn every required interpretation in this section into one tracked validation rule or test before production wiring begins.
- [ ] Require code review for every consensus-affecting checkpoint change to state which compliance gate it satisfies and which gates remain open.
- [ ] Fail milestone sign-off if any gate about root identity, terminal asset identity, proof bytes, or replay separation remains only partially addressed.
- [ ] Keep checkpoint compliance checks synchronized with the snapshot and JMT specs so weaker semantics cannot slip in through wrapper code.

### 20.2 Deferred Questions And Resolution Order

The main open questions are:

1. Whether the first storage codec should be JSON-only for debugging or dual JSON plus binary from day one.
2. Whether final checkpoint artifacts should include an explicit proof-system identifier or infer it from outer versioning.
3. Whether checkpoint audit wrappers should live in `z00z_storage` or remain simulator-local.

None of these open questions should block one central decision: checkpoint storage must be rooted in the same JMT asset-state semantics as the storage hierarchy itself.

Implementation checklist:

- [ ] Resolve these open questions in the exact order listed here and record the chosen answer in the spec before implementation begins in the affected area.
- [ ] Do not let individual developers choose locally between JSON-only and dual-codec storage, implicit and explicit proof-system discrimination, or storage-local versus simulator-local audit wrappers.
- [ ] After each open question is resolved, replace it in the document with a fixed contract statement and corresponding validation tasks.
- [ ] Keep the central decision in this section immutable unless a later explicit spec revision reopens it with migration rules and new tests.
