# 🔑 Incremental Semantic Root Implementation Plan

> [!Important]
> This plan rewrites `specs/014-z00z-storage/jmt-incremental-workflow.md` into an implementation-ready document for `crates/z00z_storage/src/assets/`.

**📌 This plan covers only the semantic root optimization path in `z00z_storage`.**

**📌 The exported `AssetStateRoot` must keep its current semantic meaning and must not be replaced with the physical JMT root.**

**📌 The rollout must preserve two internal calculation modes until parity and performance gates allow the default switch.**

## 🎯 Scope And Verified Anchors

**📌 The implementation must stay inside the existing assets storage architecture and must extend the current codebase instead of introducing a parallel design.**

Verified codebase anchors:

- `crates/z00z_storage/src/assets/store.rs`
- `crates/z00z_storage/src/assets/model.rs`
- `crates/z00z_storage/src/assets/proof.rs`
- `crates/z00z_storage/src/assets/types.rs`
- `crates/z00z_storage/src/assets/store_internal/tx_plan.rs`
- `crates/z00z_storage/src/assets/store_internal/tree_id.rs`
- `crates/z00z_storage/src/assets/store_internal/whitebox_help.rs`
- `crates/z00z_storage/src/assets/store_internal/whitebox_state.rs`
- `crates/z00z_storage/src/assets/store_internal/whitebox_proofs.rs`
- `crates/z00z_storage/tests/assets/store_api.rs`
- `crates/z00z_storage/tests/assets_suite.rs`
- `crates/z00z_storage/benches/assets_shard.rs`
- `crates/z00z_storage/benches/common/fixture.rs`
- `crates/z00z_storage/Cargo.toml`

Verified behavioral facts that this plan must preserve:

- `AssetStore::root()` currently delegates to `self.model.root()?`
- `impl RootApi for AssetStore::asset_root()` currently delegates to `self.model.root()`
- `ShardPlan.root` is currently computed from `next.model.root()?`
- `TreeRoots` already stores intermediate subtree roots, but not a fully incremental exported semantic root
- `root_by_ver` and `model_by_ver` already exist and must remain valid after the refactor
- `ProofItem` and `ProofBlob` are already coupled to the semantic root contract
- `assets_shard` is the only registered storage benchmark target

> [!Warning]
> This plan must not widen the public API, must not expose raw `jmt` types outside `z00z_storage`, and must not create a second public root API.

## ❓ Assumptions And Open Decisions

**📌 The preferred implementation path is to extend `TreeRoots` first.**

**📌 A new private cache module is allowed only if `TreeRoots` cannot absorb top-level semantic root state, touched-path invalidation, and rollback metadata without mixing unrelated responsibilities.**

**📌 The public API surface in `types.rs` must stay unchanged unless a verified codebase blocker appears during implementation.**

Open decisions that remain explicit in this plan:

- whether the semantic cache can live entirely inside `TreeRoots`
- whether the root-mode benchmark should extend `assets_shard.rs` or use a proposed `benches/semantic_root.rs`
- whether versioned cache state should be stored directly in snapshots or reconstructed deterministically from existing versioned artifacts

```mermaid
flowchart TD
  A[Freeze semantic contract] --> B[Bootstrap root benchmark path]
  B --> C[Define semantic cache contract]
  C --> D[Integrate shared root helpers]
  D --> E[Add parity and rollback tests]
  E --> F[Run root-mode benchmarks]
  F --> G{Incremental mode wins and stays correct}
  G -->|Yes| H[Switch private default helper]
  G -->|No| I[Keep full recompute default]
  H --> J[Run final acceptance]
  I --> J
```

## ⚙️ Phase 1. Freeze The Semantic Contract And Bootstrap Benchmarks

### 🔒 Lock The Public Semantic Root Contract

Required behavior:

The implementation must preserve the semantic meaning of `AssetStateRoot`, `CheckRoot`, `ProofItem.root()`, and `ProofBlob` before any cache work starts.

Exact API surface:

The following public APIs must keep their current signatures:

- `AssetStore::root()`
- `RootApi::asset_root()`
- `RootApi::check_root()`

Target files:

- `crates/z00z_storage/src/assets/store.rs`
- `crates/z00z_storage/src/assets/model.rs`
- `crates/z00z_storage/src/assets/proof.rs`
- `crates/z00z_storage/src/assets/types.rs`
- `crates/z00z_storage/src/assets/README.md`

Acceptance conditions:

The contract section is complete only when the document and code comments make it explicit that the exported root remains the semantic hierarchy commitment and not the physical storage root.

**✔️ Implementation Checklist:**

- [x] Update `crates/z00z_storage/src/assets/README.md` so it explicitly states that `AssetStateRoot` remains a semantic commitment over `definition_id -> serial_id -> asset_id`.
- [x] Confirm in `crates/z00z_storage/src/assets/store.rs` and `crates/z00z_storage/src/assets/types.rs` that no public signature changes are required for `root()`, `asset_root()`, or `check_root()`.
- [x] Update `crates/z00z_storage/src/assets/README.md` so it explicitly states that `ProofItem.root()` and `ProofBlob` remain bound to the semantic root contract.
- [x] Add one public-contract regression target in `crates/z00z_storage/tests/assets/store_api.rs` that keeps the exported semantic root aligned with the semantic model root for representative state.

### 🔔 Bootstrap A Live Full-Recompute Root Benchmark Path

Required behavior:

The benchmark surface must be able to run a live full-recompute root measurement before incremental cache code is introduced.

Write flow:

Use the existing benchmark fixture source in `benches/common/fixture.rs`, then extend the benchmark harness so the full recompute root path is runnable instead of exiting early for the baseline mode.

Target files:

- `crates/z00z_storage/benches/assets_shard.rs`
- `crates/z00z_storage/benches/common/fixture.rs`
- `crates/z00z_storage/Cargo.toml`
- proposed `crates/z00z_storage/benches/semantic_root.rs`

> [!Caution]
> Do not add a second benchmark target unless `assets_shard.rs` cannot isolate root-cost measurement cleanly.

Acceptance conditions:

This unit is complete only when one benchmark command can execute the full recompute root path on live fixture data.

**✔️ Implementation Checklist:**

- [x] Choose one benchmark host shape: either extend `crates/z00z_storage/benches/assets_shard.rs` or add proposed `crates/z00z_storage/benches/semantic_root.rs`.
- [x] Record the chosen benchmark host shape in proposed `crates/z00z_storage/outputs/assets/jmt-incremental-bench.md` before storing baseline numbers.
- [x] Keep `crates/z00z_storage/benches/common/fixture.rs` as the single fixture source for all root-mode measurements.
- [x] Add an explicit runtime mode selector for the full recompute semantic-root path in the benchmark harness.
- [x] Keep the runtime mode selector separate from Criterion baseline labels such as `--save-baseline`; a baseline name must not be treated as proof that the intended root path was actually executed.
- [x] Ensure the benchmark harness no longer exits early for the full recompute baseline mode once benchmark bootstrap lands.
- [x] Register any new benchmark target in `crates/z00z_storage/Cargo.toml` only if a separate bench file is required.

### 📈 Capture The Pre-Cache Baseline Artifact

Required behavior:

The plan must capture a reproducible baseline before cache integration starts.

Output artifact:

Use proposed `crates/z00z_storage/outputs/assets/jmt-incremental-bench.md` to record exact commands, mode selectors, fixture shape, and observed numbers.

Acceptance conditions:

The baseline artifact is complete only when another engineer can rerun the same full-recompute benchmark command without guessing flags or fixture assumptions.

**✔️ Implementation Checklist:**

- [x] Create proposed `crates/z00z_storage/outputs/assets/jmt-incremental-bench.md` after the live full-recompute benchmark path exists.
- [x] Record the exact full-recompute benchmark command line in the report, including any required environment variables.
- [x] Record the exact runtime mode selector inputs in the report.
- [x] Record any Criterion baseline label separately from the runtime mode selector when both are used in the same command.
- [x] Record the fixture source and fixture shape in the report.
- [x] Store the measured baseline result in the report before any cache-path benchmark result is added.

## ⚙️ Phase 2. Define The Incremental Semantic Cache Contract

### 🧱 Select The Private Cache Host Structure

Required behavior:

The implementation must choose one private host for incremental semantic cache state and must not split the source of truth across parallel abstractions.

Canonical data shape:

The chosen private cache host must be able to represent:

- asset bucket root per `(DefinitionId, SerialId)`
- serial aggregate root per `DefinitionId`
- top semantic `AssetStateRoot`

Target files:

- `crates/z00z_storage/src/assets/store.rs`
- `crates/z00z_storage/src/assets/store_internal/tree_id.rs`
- `crates/z00z_storage/src/assets/store_internal/tx_plan.rs`
- proposed `crates/z00z_storage/src/assets/store_internal/semantic_cache.rs`

Acceptance conditions:

This unit is complete only when one private structure is chosen and its ownership boundary is explicit.

**✔️ Implementation Checklist:**

- [x] Review `TreeRoots` in `crates/z00z_storage/src/assets/store.rs` as the first candidate cache host.
- [x] Verify whether `TreeRoots` can hold top semantic root state and touched invalidation state without mixing unrelated responsibilities.
- [x] If `TreeRoots` is sufficient, document it as the sole private semantic cache host.
- [x] `TreeRoots` proved sufficient, so no `crates/z00z_storage/src/assets/store_internal/semantic_cache.rs` companion cache was needed.
- [x] Document one primary mutable owner for semantic root state before introducing any companion cache structure.

### ♻️ Define Touched-Path Update And Delete Rules

Required behavior:

The cache contract must define deterministic updates for insert, update, delete, empty bucket collapse, empty serial collapse, and top-root recomputation.

Verifier flow:

Every touched update must remain comparable against `AssetModel.root()` for parity.

Invariants and rejection rules:

- canonical ordering must remain deterministic
- top semantic root must never depend on hash-map iteration order
- delete transitions must remove empty child aggregates correctly

Acceptance conditions:

This unit is complete only when put and delete transitions can be described as one deterministic touched-chain recomputation path.

**✔️ Implementation Checklist:**

- [x] Define the touched scope as `(definition_id, serial_id, asset_id)` derived from `apply_ops()` precheck results.
- [x] Specify how asset bucket roots are recomputed for touched `(DefinitionId, SerialId)` pairs.
- [x] Specify how serial aggregate roots are recomputed for touched `DefinitionId` values.
- [x] Specify how empty asset buckets are removed after delete transitions.
- [x] Specify how empty serial aggregates are removed after delete transitions.
- [x] Specify how the top semantic `AssetStateRoot` is rebuilt from canonical definition ordering only.

### 🧾 Define Snapshot, Rollback, And Version Rules

Required behavior:

The semantic cache must participate in the same atomic snapshot and rollback flow as `model`, `path_by_id`, `root_by_ver`, and `model_by_ver`.

Target files:

- `crates/z00z_storage/src/assets/store_internal/tx_plan.rs`
- `crates/z00z_storage/src/assets/store.rs`

Acceptance conditions:

This unit is complete only when the plan states exactly how current-state rollback and historical-version checks remain valid.

**✔️ Implementation Checklist:**

- [x] Extend the documented `StoreSnap` responsibility so it includes semantic cache state.
- [x] Define whether versioned cache state is stored directly or reconstructed deterministically from existing historical artifacts.
- [x] Keep `root_by_ver` and `model_by_ver` as verified acceptance anchors for historical parity.
- [x] State that rollback must restore cache state together with `model`, `path_by_id`, `flat_root`, and `flat_version`.
- [x] Verify that the chosen cache host can be cloned into snapshot state and restored through one atomic restore path before wiring it into `commit_stage()`.

## ⚙️ Phase 3. Integrate Shared Root Helpers Into AssetStore

### 🧠 Extract Private Full And Incremental Semantic-Root Helpers

Required behavior:

The runtime must expose one shared internal semantic-root dispatch point backed by two private implementations: full recompute and incremental cache.

The reusable computation routine must accept explicit state inputs needed by both committed-store reads and planner-time `NextState` evaluation. The plan must not assume that `plan_ops()` can call a helper that only sees committed `self` state.

Exact API surface:

The helper APIs must stay private to `store.rs`.

Target files:

- `crates/z00z_storage/src/assets/store.rs`

Acceptance conditions:

This unit is complete only when both internal root paths exist and no second public root API was added.

**✔️ Implementation Checklist:**

- [x] Add one private helper in `crates/z00z_storage/src/assets/store.rs` for full semantic recompute through `AssetModel.root()`.
- [x] Add one private helper in `crates/z00z_storage/src/assets/store.rs` for incremental semantic-root calculation from the chosen cache host.
- [x] Add one reusable private computation routine whose inputs are explicit enough to support both committed-store reads and planner-time `NextState` evaluation.
- [x] Add one shared private dispatch helper in `crates/z00z_storage/src/assets/store.rs` that wraps the reusable computation routine for committed store state.
- [x] Keep the helper names private and implementation-oriented; do not expose them through `types.rs`.
- [x] Verify during helper extraction that no new public root method or trait entry is added in `store.rs` or `types.rs`.

### 🔗 Route Planning And Public Root Calls Through The Shared Helper

Required behavior:

`plan_ops()`, `AssetStore::root()`, and `RootApi::asset_root()` must converge on the same internal semantic-root dispatch point.

Write flow:

The planner must compute `ShardPlan.root` through the same underlying computation routine used by the committed-store helper, but with explicit next-state inputs. The public entrypoints must reuse the committed-store wrapper for the same root semantics.

Target files:

- `crates/z00z_storage/src/assets/store.rs`
- `crates/z00z_storage/src/assets/store_internal/tx_plan.rs`

Acceptance conditions:

This unit is complete only when both public semantic-root entrypoints remain behaviorally identical and `ShardPlan.root` no longer hard-codes `next.model.root()?`.

**✔️ Implementation Checklist:**

- [x] Update `crates/z00z_storage/src/assets/store_internal/tx_plan.rs` so `ShardPlan.root` is derived from the shared underlying semantic-root computation routine instead of direct `next.model.root()?`.
- [x] If planner-time root calculation needs projected cache state, add one private planner-local cache projection step in `crates/z00z_storage/src/assets/store_internal/tx_plan.rs` before `ShardPlan` is constructed.
- [x] Update `AssetStore::root()` in `crates/z00z_storage/src/assets/store.rs` to use the shared private helper.
- [x] Update `impl RootApi for AssetStore` in `crates/z00z_storage/src/assets/store.rs` to use the same shared private helper.
- [x] Preserve the existing `RootErr` mapping behavior in the trait implementation.
- [x] Keep `RootApi` in `crates/z00z_storage/src/assets/types.rs` unchanged unless a verified blocker appears.

### 🧪 Add Private Test Hooks For Dual-Path Assertions

Required behavior:

Tests must be able to force both root paths without widening production visibility.

Target files:

- `crates/z00z_storage/src/assets/store_internal/whitebox_help.rs`
- `crates/z00z_storage/src/assets/store.rs`

Acceptance conditions:

This unit is complete only when test code can compare both modes directly through `#[cfg(test)]` helpers.

**✔️ Implementation Checklist:**

- [x] Add private `#[cfg(test)]` helpers in `crates/z00z_storage/src/assets/store_internal/whitebox_help.rs` for the full recompute root path.
- [x] Add private `#[cfg(test)]` helpers in `crates/z00z_storage/src/assets/store_internal/whitebox_help.rs` for the incremental root path.
- [x] Ensure the helpers can exercise the same store state without mutating public API shape.
- [x] Keep benchmark mode selection able to force both runtime paths without relying on test-only visibility.

## ⚙️ Phase 4. Add Deterministic Parity, Rollback, And Proof Tests

### ✅ Add Root Parity Coverage For CRUD And Historical Versions

Required behavior:

The tests must prove byte-identical semantic roots for both calculation modes across CRUD transitions and historical version lookups.

Target files:

- `crates/z00z_storage/src/assets/model_tests.rs`
- `crates/z00z_storage/src/assets/store_internal/whitebox_help.rs`
- `crates/z00z_storage/src/assets/store_internal/whitebox_state.rs`
- `crates/z00z_storage/tests/assets/store_api.rs`

Test expectations:

The parity suite must cover empty state, single insert, multi-definition insert, multi-serial insert, mixed put and delete, repeated equivalent updates, and historical version comparison.

Acceptance conditions:

This unit is complete only when both root paths return exact byte equality for all planned scenarios.

**✔️ Implementation Checklist:**

- [x] Add empty-state parity coverage.
- [x] Add single-insert parity coverage.
- [x] Add multi-definition parity coverage.
- [x] Add multi-serial parity coverage under one definition.
- [x] Add mixed put and delete parity coverage in one `apply_ops()` call.
- [x] Add repeated equivalent update parity coverage.
- [x] Add historical-version parity coverage that compares current root and `root_by_ver` outputs after more than one committed version.

### 🚨 Add Rollback And Failure-Recovery Coverage

Required behavior:

Injected commit failures must restore semantic cache state together with the existing store snapshot state.

Target files:

- `crates/z00z_storage/src/assets/store_internal/whitebox_state.rs`
- `crates/z00z_storage/src/assets/store_internal/tx_plan.rs`

Acceptance conditions:

This unit is complete only when a failed commit leaves both root paths and versioned state consistent with the pre-failure snapshot.

**✔️ Implementation Checklist:**

- [x] Add a rollback test that injects failure through the existing commit-failure path.
- [x] Verify that model state is restored after the injected failure.
- [x] Verify that semantic cache state is restored after the injected failure.
- [x] Verify that `root_by_ver` and `model_by_ver` remain consistent after rollback.
- [x] Verify that the public semantic root after rollback matches the pre-failure root.

### 🔐 Add Proof-Path Parity Coverage

Required behavior:

Proof generation and proof verification semantics must remain unchanged after the root-path refactor.

Target files:

- `crates/z00z_storage/src/assets/store_internal/whitebox_proofs.rs`
- `crates/z00z_storage/tests/assets/store_api.rs`
- `crates/z00z_storage/src/assets/proof.rs`

Acceptance conditions:

This unit is complete only when `ProofItem.root()` and `ProofBlob` remain identical in meaning across both calculation paths.

**✔️ Implementation Checklist:**

- [x] Add a proof-generation parity test that compares the root embedded in `ProofItem` across both modes.
- [x] Add a proof-blob parity test that verifies semantic-root equivalence across both modes.
- [x] Preserve existing replay-rejection expectations for wrong path, wrong root, and wrong leaf hash.
- [x] Keep proof-path parity green in both forced root modes before allowing the rollout to proceed past this phase.

### 🐞 Add One Property-Style Determinism Test

Required behavior:

At least one property-style test must randomize operation order and still prove convergence of both root modes for equivalent final state.

Target files:

- `crates/z00z_storage/src/assets/model_tests.rs`
- `crates/z00z_storage/src/assets/store_internal/whitebox_state.rs`

Acceptance conditions:

This unit is complete only when randomized equivalent states converge to identical semantic roots in both modes.

**✔️ Implementation Checklist:**

- [x] Add one property-style scenario using the existing `proptest` dev-dependency.
- [x] Randomize operation order while preserving equivalent final state.
- [x] Compare full and incremental semantic roots by exact bytes.
- [x] Use deterministic ordering or explicit sorting in the test harness so helper comparison never depends on map iteration order.

## ⚙️ Phase 5. Implement Reproducible Root-Mode Benchmarks

### ⏱️ Add Explicit Full And Incremental Benchmark Modes

Required behavior:

The benchmark harness must be able to force full recompute and incremental cache modes explicitly, independent of the runtime default path.

The root-mode selector must stay distinct from `Z00Z_ASSET_PLAN_MODE`, which currently controls planner parallelism, so benchmark commands cannot accidentally measure a planner mode while leaving the semantic-root path unchanged.

#### 📌 Target files

- `crates/z00z_storage/benches/assets_shard.rs`
- proposed `crates/z00z_storage/benches/semantic_root.rs`
- `crates/z00z_storage/Cargo.toml`

#### 📌 Acceptance conditions

This unit is complete only when both root-mode commands are explicit, reproducible, and runnable without editing code between runs.

**✔️ Implementation Checklist:**

- [x] Add an explicit benchmark selector for the full recompute semantic-root path.
- [x] Add an explicit benchmark selector for the incremental semantic-cache path.
- [x] Keep the selector independent of whichever mode is the runtime default.
- [x] Keep the root-mode selector distinct from planner parallelism selectors so one command cannot silently benchmark the wrong dimension.
- [x] If a dedicated benchmark target is needed, register it in `crates/z00z_storage/Cargo.toml` and label it as proposed until created.

### 📊 Measure Representative Transition Families

#### 📌 Required behavior

The benchmark suite must measure both modes on the same fixture source and the same transition families.

Scenario families:

- one-asset update in a large state
- one-serial bucket update
- one-definition fanout update
- mixed put and delete batch
- no-op equivalent update

Acceptance conditions:

This unit is complete only when both modes are measured on identical fixture data for all required scenario families.

**✔️ Implementation Checklist:**

- [x] Reuse `crates/z00z_storage/benches/common/fixture.rs` for every root-mode measurement.
- [x] Add the one-asset update scenario.
- [x] Add the one-serial bucket update scenario.
- [x] Add the one-definition fanout scenario.
- [x] Add the mixed put and delete batch scenario.
- [x] Add the no-op equivalent update scenario.
- [x] Keep existing non-root operation benches intact.

### 📝 Record Benchmark Evidence And Decision Inputs

Required behavior:

The benchmark report must capture enough detail to support the default-path decision without rerunning discovery work.

Output artifact:

Use proposed `crates/z00z_storage/outputs/assets/jmt-incremental-bench.md` as the single decision artifact.

Acceptance conditions:

This unit is complete only when the report captures exact commands, exact mode selectors, fixture shape, and measured deltas for both modes.

**✔️ Implementation Checklist:**

- [x] Record the exact full-recompute benchmark command in proposed `crates/z00z_storage/outputs/assets/jmt-incremental-bench.md`, including environment-variable selectors.
- [x] Record the exact incremental benchmark command in proposed `crates/z00z_storage/outputs/assets/jmt-incremental-bench.md`, including environment-variable selectors.
- [x] Record the exact runtime mode-selector inputs in proposed `crates/z00z_storage/outputs/assets/jmt-incremental-bench.md`.
- [x] Record any Criterion baseline labels separately from the runtime mode-selector inputs in proposed `crates/z00z_storage/outputs/assets/jmt-incremental-bench.md`.
- [x] Record fixture shape and scenario families in proposed `crates/z00z_storage/outputs/assets/jmt-incremental-bench.md`.
- [x] Record observed timing deltas for both modes in proposed `crates/z00z_storage/outputs/assets/jmt-incremental-bench.md`.
- [x] State clearly whether the benchmark lived in `assets_shard.rs` or a dedicated `semantic_root` benchmark.

> [!Important]
> If the benchmark shows no defensible improvement, the implementation must keep the full recompute helper as the runtime default.

```mermaid
sequenceDiagram
  participant Bench as Benchmark Harness
  participant Full as Full Recompute Helper
  participant Inc as Incremental Helper
  participant Report as Benchmark Report
  participant Gate as Default Switch Gate

  Bench->>Full: run exact full-root command
  Bench->>Inc: run exact incremental-root command
  Full-->>Report: timings and fixture metadata
  Inc-->>Report: timings and fixture metadata
  Report-->>Gate: decide keep-default or switch-default
```

## ⚙️ Phase 6. Switch The Private Default Root Path Only If Gates Pass

### 🚦 Promote The Incremental Helper To Private Default

Required behavior:

The shared private semantic-root helper may switch from full recompute to incremental cache only if parity and benchmark gates are both green.

Target files:

- `crates/z00z_storage/src/assets/store.rs`
- `crates/z00z_storage/src/assets/README.md`

Acceptance conditions:

This unit is complete only when the runtime default is switched privately and all public API semantics stay unchanged.

**✔️ Implementation Checklist:**

- [x] Verify that all parity tests are green before changing the default helper.
- [x] Verify that benchmark evidence shows a defensible improvement before changing the default helper.
- [x] Switch the shared private semantic-root helper in `crates/z00z_storage/src/assets/store.rs` from full recompute to incremental cache.
- [x] Keep the full recompute helper available privately for audits and regression checks.
- [x] Update `crates/z00z_storage/src/assets/README.md` so the runtime source of truth is documented accurately.

### 🔍 Re-Verify Public Root Entry Points After The Switch

Required behavior:

After the private default switch, both public semantic-root entrypoints must still return identical bytes.

Target files:

- `crates/z00z_storage/src/assets/store.rs`
- `crates/z00z_storage/tests/assets/store_api.rs`
- `crates/z00z_storage/src/assets/store_internal/whitebox_state.rs`

Acceptance conditions:

This unit is complete only when post-switch tests prove that `AssetStore::root()` and `RootApi::asset_root()` remain behaviorally identical.

**✔️ Implementation Checklist:**

- [x] Add or keep one regression test that compares `AssetStore::root()` and `RootApi::asset_root()` after the default switch.
- [x] Keep one regression test that forces parity against the full recompute oracle after the default switch.
- [x] Add one post-switch regression that fails if the two public semantic-root entrypoints diverge in bytes or error mapping.

## ⚙️ Phase 7. Run Final Acceptance And Recovery Gates

### ✅ Execute Final Build, Test, And Bench Gates

Required behavior:

The final acceptance sequence must run in one deterministic order so correctness gates block performance and rollout decisions correctly.

Acceptance command order:

```bash
cargo fmt --all
cargo clippy --workspace --release --all-targets -- -D warnings
cargo test -p z00z_storage --lib
cargo test -p z00z_storage --test assets_suite
cargo bench -p z00z_storage --bench assets_shard --no-run
./scripts/full_verify.sh --max-safe-run
```

> [!Note]
> Run `cargo bench -p z00z_storage --bench semantic_root --no-run` only if a dedicated `semantic_root` benchmark target was added and registered.
>
> [!Important]
> Final acceptance must also run the two exact benchmark commands recorded in `crates/z00z_storage/outputs/assets/jmt-incremental-bench.md`. Bench compilation alone is not a valid performance gate, and Criterion baseline labels must not be used as a substitute for runtime root-mode selection.

Acceptance conditions:

This unit is complete only when build, test, verify, and benchmark gates all finish with reproducible outputs and the rollout result is explicit.

**✔️ Implementation Checklist:**

- [x] Run `cargo fmt --all`.
- [x] Run `cargo clippy --workspace --release --all-targets -- -D warnings`.
- [x] Run `cargo test -p z00z_storage --lib`.
- [x] Run `cargo test -p z00z_storage --test assets_suite`.
- [x] Run `cargo bench -p z00z_storage --bench assets_shard --no-run`.
- [x] Run `cargo bench -p z00z_storage --bench semantic_root --no-run` only if a dedicated benchmark target was added.
- [x] Run the exact full-recompute benchmark command recorded in `crates/z00z_storage/outputs/assets/jmt-incremental-bench.md`.
- [x] Run the exact incremental benchmark command recorded in `crates/z00z_storage/outputs/assets/jmt-incremental-bench.md`.
- [x] Run `./scripts/full_verify.sh --max-safe-run`.
- [x] Record the final decision as either `incremental default enabled` or `full recompute default retained`.

### 🛑 Apply Recovery Rules If Any Gate Fails

Required behavior:

Failure handling must stop at the earliest invalid gate and must not allow a partial rollout to masquerade as accepted.

Recovery rules:

- parity failure keeps full recompute as runtime default
- rollback failure blocks benchmark work
- benchmark infrastructure failure can ship correctness-only work only if the performance decision is labeled blocked
- post-switch correctness regression must revert only the private default selector, not the full diagnostic dual-path implementation

Acceptance conditions:

This unit is complete only when the failure path is explicit enough that another engineer can stop safely without inventing rollback behavior.

**✔️ Implementation Checklist:**

- [x] Stop the rollout immediately if any parity test fails.
- [x] Stop benchmark work if rollback restoration fails.
- [x] Mark the performance decision as blocked if benchmark infrastructure cannot run after correctness work is green.
- [x] Revert only the private default selector if incremental mode regresses after the default switch.
- [x] Preserve the dual-path implementation for diagnosis if the private default selector must be reverted.

## ✅ Completion Summary

**📌 This plan is complete only when every phase above is executable without hidden design choices and every open decision remains explicitly labeled.**

**📌 The final state must end in exactly one of two accepted outcomes: incremental mode becomes the private runtime default, or full recompute remains the private runtime default with parity and benchmark evidence recorded.**
