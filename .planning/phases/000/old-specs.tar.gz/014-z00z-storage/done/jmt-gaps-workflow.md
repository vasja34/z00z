# JMT Storage Gaps Workflow

> [!Important]
> This workflow rewrites the remaining JMT storage gaps into one executable sequence for the current repository state.
> It is grounded in `specs/014-z00z-storage/tmp/jmt-storage-gaps.md` plus verified code anchors in `z00z_storage`, `z00z_wallets`, `z00z_simulator`, and `z00z_core`.

## 🎯 Scope And Goal

**🎯 This workflow must close the remaining first-party storage gaps without reopening already accepted storage semantics.**

**📌 The canonical storage contract is already fixed as `definition_id -> serial_id -> asset_id` with typed roots, typed paths, and storage-owned proof records.**

**📌 The work covered here is limited to the remaining gaps that are still visible in executable code:**

- storage does not yet own the terminal `AssetLeaf` contract
- wallet checkpoint APIs still erase hierarchical path semantics
- wallet witness handling is still byte-oriented
- simulator Stage 4 still reconstructs `prev_root` through `CompatRoot`
- simulator Stage 6 witness lookup is still root-agnostic
- semantic key wrapper types are still undecided
- backend abstraction is still undecided
- strong `chk_blob(...)` validation is not yet the universal downstream rule

**📌 This workflow must extend the current codebase. It must not introduce a greenfield storage stack, duplicate proof logic, or replace existing typed root and path APIs.**

## 👁️‍🗨️ Verified Inputs And Code Anchors

**👁️‍🗨️ The source spec for this workflow is readable and was used directly:**

- `specs/014-z00z-storage/tmp/jmt-storage-gaps.md`

**👁️‍🗨️ The following code anchors were verified before writing this workflow:**

- `crates/z00z_storage/src/assets/types.rs`
- `crates/z00z_storage/src/assets/store.rs`
- `crates/z00z_storage/src/assets/proof.rs`
- `crates/z00z_storage/src/assets/keys.rs`
- `crates/z00z_storage/tests/assets/store_api.rs`
- `crates/z00z_wallets/src/core/tx/state_update.rs`
- `crates/z00z_wallets/tests/test_tx_spent_gate.rs`
- `crates/z00z_wallets/tests/test_tx_wrong_root.rs`
- `crates/z00z_wallets/tests/test_phase24_gate.rs`
- `crates/z00z_simulator/src/scenario_1/stage_4.rs`
- `crates/z00z_simulator/src/scenario_1/stage_6.rs`
- `crates/z00z_core/src/assets/leaf.rs`

**📌 The following existing structures must be reused before any new structure is proposed:**

- `AssetPath`
- `AssetStateRoot`
- `CheckRoot`
- `ProofItem`
- `ProofBlob`
- `chk_item(...)`
- `chk_blob(...)`
- `AssetStore`
- `MemberIdx`
- `AssetState`
- `TxPkgSum`

```mermaid
flowchart TD
  A[Phase 1<br/>Lock remaining scope] --> B[Phase 2<br/>Introduce storage leaf surface]
  B --> C[Phase 3<br/>Preserve full AssetPath at wallet boundary]
    C --> D[Phase 4<br/>Make ProofBlob mandatory downstream]
    D --> E[Phase 5<br/>Remove simulator compatibility-root path]
    E --> F[Phase 6<br/>Resolve optional hardening decisions]
    F --> G[Phase 7<br/>Run final validation and spec sync]
```

## ❓ Assumptions, Blockers, And Open Decisions

**❓ The following decisions materially affect implementation, but they must not block the first functional migration phases longer than necessary:**

1. whether `z00z_storage` becomes the canonical owner of `AssetLeaf` or owns a storage-facing adapter plus a compatibility re-export
2. whether `MemberWit` remains bytes or becomes a typed storage-proof wrapper
3. whether `DefinitionKey` and `SerialKey` wrappers remain in scope after the functional gaps are closed
4. whether backend abstraction remains in scope after the functional gaps are closed

> [!Warning]
> Phase order must not be inverted around these decisions. Core semantic adoption must land before optional key-wrapper or backend-generalization work, otherwise the workflow creates artificial blockers.

**📌 If any of the optional hardening items remain undecided after the functional phases, this workflow must explicitly freeze them as out of scope for the current pass rather than leaving parallel half-migrations in the tree.**

```mermaid
sequenceDiagram
    participant Store as z00z_storage
    participant Wallet as state_update.rs
    participant Sim4 as scenario_1/stage_4.rs
    participant Sim6 as scenario_1/stage_6.rs

    Store->>Wallet: Export path-bound root and proof contract
    Wallet->>Wallet: Resolve inputs with full AssetPath
    Wallet->>Wallet: Decode and validate canonical ProofBlob
    Wallet->>Sim4: Consume storage root directly
    Sim4->>Sim6: Hand off root-bound witness data
    Sim6->>Sim6: Enforce get_wit(prev_root, asset_id)
```

## ⚙️ Phase 1. Lock Remaining Scope And Acceptance Targets

### 1.1 Intent

**🔔 This phase must lock what is still in scope so later phases do not reopen closed storage semantics.**

### 1.2 Entry Conditions

- `tmp/jmt-storage-gaps.md` is readable
- current storage path, root, and proof contracts remain unchanged in code

### 1.3 Serialized Steps

1. Read `specs/014-z00z-storage/tmp/jmt-storage-gaps.md` in full and translate each remaining gap into one tracked implementation bucket.
2. Mark `AssetPath`, `AssetStateRoot`, `CheckRoot`, `ProofItem`, and `ProofBlob` as closed baseline contracts.
3. Record one short decision note for each open decision listed above.
4. Freeze the acceptance target for this workflow as: no remaining first-party byte-only witness boundary, no remaining compatibility-root witness preparation path, and no remaining path erasure before checkpoint apply.

### 1.4 Required Output

- one workflow document with explicit phase ownership and validation gates
- one open-decisions section that names optional work instead of hiding it inside functional phases

### 1.5 Exit Condition

**✅ Later phases no longer need to guess whether hierarchy design, root semantics, or proof-container design are still negotiable.**

## ⚙️ Phase 2. Introduce One Storage-Owned Leaf Surface

### 2.1 Intent

**🔔 This phase must introduce one storage-owned terminal leaf surface that unblocks later wallet and simulator migration work without forcing a broad crate-wide ownership move first.**

### 2.2 Target Files

- `crates/z00z_storage/src/assets/types.rs`
- `crates/z00z_storage/src/assets/model.rs`
- `crates/z00z_storage/src/assets/store.rs`
- `crates/z00z_storage/src/assets/proof.rs`
- `crates/z00z_storage/src/assets/mod.rs`
- proposed `crates/z00z_storage/src/assets/leaf.rs`
- `crates/z00z_core/src/assets/leaf.rs`

### 2.3 Serialized Steps

1. Introduce one storage-owned terminal leaf surface in `z00z_storage`, either as the canonical leaf definition or as the only allowed storage-facing wrapper if a direct move is not yet safe.
2. Replace storage-internal imports of `z00z_core::assets::AssetLeaf` with the storage-owned surface.
3. If compatibility is required, keep one compatibility re-export or adapter in `z00z_core` instead of duplicating leaf definitions.
4. Keep the terminal key invariant unchanged: terminal identity remains `asset_id`.
5. Keep the leaf wire payload unchanged unless a separate migration spec is written.
6. If full ownership migration would block Phase 3 or Phase 4, stop at the storage-owned compatibility surface and defer complete ownership cut-over to Phase 6.

### 2.4 Critical Rules

- must not change the meaning of `asset_id`, `serial_id`, or the canonical leaf hash
- must not duplicate `AssetLeaf` semantics in parallel modules
- must reuse existing storage proof and store code paths

### 2.5 Validation Gate

Run:

```bash
cargo test -p z00z_storage --lib
cargo test -p z00z_storage --test assets_suite
```

### 2.6 Exit Condition

**✅ Storage-facing code in `z00z_storage` now uses one storage-owned terminal leaf surface, and later phases no longer depend on direct `z00z_core` leaf ownership.**

## ⚙️ Phase 3. Preserve Full AssetPath Across Wallet Checkpoint Preparation

### 3.1 Intent

**🔔 This phase must stop erasing `definition_id` and `serial_id` before checkpoint preparation completes.**

### 3.2 Target Files

- `crates/z00z_wallets/src/core/tx/state_update.rs`
- `crates/z00z_wallets/tests/test_tx_spent_gate.rs`
- `crates/z00z_wallets/tests/test_tx_wrong_root.rs`
- `crates/z00z_wallets/tests/test_phase24_gate.rs`

### 3.3 Required API Surface Decisions

1. `ResolvedInput` must become explicitly path-bound.
2. `TxPkgSum` must either carry path-bound inputs directly or carry a storage-owned resolved-input type that retains full `AssetPath` semantics.
3. If `AssetState` remains keyed by terminal `asset_id`, that lookup must be treated only as a state-loading helper and must not remain the final verifier identity boundary.
4. `MemberIdx` must either accept `AssetPath` directly or consume a path-bound resolved-input record before witness verification completes.

### 3.4 Serialized Steps

1. Extend the wallet checkpoint preparation path so resolved inputs retain full path semantics instead of only terminal `asset_id`.
2. Rework `ResolvedInput`, `TxPkgSum`, or an equivalent existing type so path-bound state and witness data travel together.
3. Keep `TxInputWire` compact if needed, but require the resolved internal record to carry full `AssetPath` data.
4. Update `AssetState` and `MemberIdx` call sites so path erasure is no longer the default preparation contract.
5. Make `prepare_tx_sum(...)` the explicit boundary where path-bound resolution becomes complete and later checkpoint code stops guessing missing path data.

### 3.5 Critical Pseudocode

```text
prepare_tx_sum(prev_root, state, inputs, outputs, tx_proof, member_idx):
  resolve each input into one path-bound record
  require path.serial_id == input.serial_id
  require state leaf matches path.asset_id
  collect path + leaf + witness as one canonical resolved input set
  build TxPkgSum from resolved path-bound inputs
```

### 3.6 Parallelization Boundary

- type refactors and wallet test rewrites may run in parallel after the target internal record shape is fixed
- public trait shape changes must stay serialized

### 3.7 Validation Gate

Run:

```bash
cargo test -p z00z_wallets --tests
```

### 3.8 Exit Condition

**✅ Wallet checkpoint preparation no longer depends on a flat `asset_id`-only internal contract.**

## ⚙️ Phase 4. Make ProofBlob The Mandatory First-Party Witness Boundary

### 4.1 Intent

**🔔 This phase must replace byte-oriented witness acceptance with canonical storage-proof validation.**

### 4.2 Target Files

- `crates/z00z_storage/src/assets/proof.rs`
- `crates/z00z_wallets/src/core/tx/state_update.rs`
- `crates/z00z_storage/tests/assets/store_api.rs`
- `crates/z00z_wallets/tests/test_tx_spent_gate.rs`
- `crates/z00z_wallets/tests/test_tx_wrong_root.rs`
- `crates/z00z_wallets/tests/test_phase24_gate.rs`

### 4.3 Serialized Steps

1. Decide whether `MemberWit` becomes a typed wrapper over canonical `ProofBlob` bytes or is replaced by a storage-owned witness type.
2. Require downstream witness ingestion to decode canonical proof bytes inside `resolve_inputs(...)` before `prepare_tx_sum(...)` returns success.
3. Reuse `chk_blob(...)` as the semantic and backend-proof validator instead of introducing a second verifier.
4. Replace placeholder `vec![1u8]` witness fixtures with canonical proof-blob fixtures or fixture builders.

### 4.4 Critical Rules

- must not create a wallet-local proof format
- must not weaken `chk_blob(...)` to match existing placeholder tests
- must reject malformed or non-canonical witness bytes before any state-apply logic runs

### 4.5 Validation Gate

Run:

```bash
cargo test -p z00z_storage --test assets_suite
cargo test -p z00z_wallets --tests
```

### 4.6 Exit Condition

**✅ The first downstream witness boundary is now canonical, storage-proof-aware, and no longer byte-only.**

## ⚙️ Phase 5. Remove Compatibility-Root Reconstruction From Simulator Paths

### 5.1 Intent

**🔔 This phase must make `scenario_1` consume storage-produced roots and root-bound witness lookup semantics directly.**

### 5.2 Target Files

- `crates/z00z_simulator/src/scenario_1/stage_4.rs`
- `crates/z00z_simulator/src/scenario_1/stage_6.rs`
- `crates/z00z_simulator/tests/test_stage4_digest.rs` for the required Stage 4 root-parity gate
- `crates/z00z_simulator/tests/test_stage4_gates.rs`
- `crates/z00z_simulator/tests/test_stage6_checkpoint.rs`
- `crates/z00z_simulator/tests/test_pipeline_genesis_tx.rs`
- `crates/z00z_simulator/tests/test_scenario1_unified_gate.rs`

### 5.3 Serialized Steps

1. Add one parity gate that proves the storage-produced root and the current compatibility-root path agree for the same Stage 4 rows before deleting compatibility-root wiring.
2. Change Stage 4 witness preparation to source `prev_root` from storage-owned root providers instead of `CompatRoot::new(rows)?.check_root()`.
3. Remove `ProofBlob::rebind(...)` from simulator witness preparation unless a separate compatibility-only adapter is explicitly kept and documented.
4. Change Stage 6 witness indexing so `get_wit(prev_root, asset_id)` actually enforces root binding.
5. Keep any root-agnostic witness cache strictly internal and only after prior root-bound validation.

### 5.4 Critical Rules

- must reuse the existing `PrepRow.definition_id_hex` field instead of inventing a second Stage 4 namespace field
- must prove root parity before deleting the compatibility-root path
- must implement that parity proof in an executable simulator test, preferably by extending `test_stage4_digest.rs`, rather than leaving it as an unchecked code comment or one-off debug assertion
- must not keep `ProofBlob::rebind(...)` as a silent semantic rewrite step after storage-root adoption lands

### 5.5 Critical Pseudocode

```text
stage4_prep(rows):
  build AssetStore from rows
  assert store.check_root() == compat_root(rows) before deleting compat path
  prev_root = store.check_root()
  for each row:
    blob = store.proof_blob(path)
    emit canonical blob bytes without semantic rebind

stage6_lookup(prev_root, asset_id):
  key = (prev_root, asset_id)
  return canonical witness only for that exact key
```

### 5.6 Parallelization Boundary

- Stage 4 root-source changes and Stage 6 root-bound index changes may be developed in parallel
- final simulator acceptance tests must stay serialized after both changes land

### 5.7 Validation Gate

Run:

```bash
cargo test -p z00z_simulator --test test_stage4_digest --release --features test-fast --features wallet_debug_dump
cargo test -p z00z_simulator --test test_stage4_gates --release --features test-fast --features wallet_debug_dump
cargo test -p z00z_simulator --test test_stage6_checkpoint --release --features test-fast --features wallet_debug_dump
cargo test -p z00z_simulator --test test_pipeline_genesis_tx --release --features test-fast --features wallet_debug_dump
cargo test -p z00z_simulator --test test_scenario1_unified_gate --release --features test-fast --features wallet_debug_dump
```

### 5.8 Exit Condition

**✅ Simulator witness preparation and lookup no longer depend on compatibility-root reconstruction or root-agnostic lookup.**

## ⚙️ Phase 6. Resolve Optional Type Hardening And Backend Scope

### 6.1 Intent

**🔔 This phase must finish the remaining optional architecture decisions without blocking the earlier functional migration.**

### 6.2 Target Files

- `crates/z00z_storage/src/assets/keys.rs`
- `crates/z00z_storage/src/assets/types.rs`
- `crates/z00z_storage/src/assets/store.rs`
- `crates/z00z_storage/src/assets/store_internal/tree_store.rs`

### 6.3 Serialized Steps

1. Decide whether `DefinitionKey` and `SerialKey` wrappers are still required.
2. If required, add them as semantic wrappers over existing derivation outputs without changing path or root semantics.
3. Decide whether backend abstraction remains in scope for the current pass.
4. If backend abstraction remains in scope, define one explicit trait boundary between hierarchy logic and backend operations.
5. If backend abstraction is out of scope, record the in-memory backend as the accepted current milestone endpoint.

### 6.4 Critical Rules

- must not let optional key-wrapper work block the wallet and simulator adoption phases
- must not introduce a backend trait before the hierarchy-facing semantics are stable
- must label any unverified new type or trait as proposed until it exists in code

### 6.5 Exit Condition

**✅ Optional hardening items are either implemented or explicitly frozen out of scope for the current pass.**

## ⚙️ Phase 7. Final Validation, Spec Sync, And Acceptance

### 7.1 Intent

**🔔 This phase must prove that all remaining storage gaps covered by this workflow are either closed or explicitly deferred.**

### 7.2 Serialized Steps

1. Run all phase gates again on one consistent revision.
2. Update `specs/014-z00z-storage/jmt-storage-gaps.md` so each closed gap is moved out of the remaining-gap set.
3. Update adjacent storage specs only if any accepted public contract wording changed.
4. Record any deferred optional hardening item in an explicit follow-up note instead of leaving mixed partial code in place.

### 7.3 Final Validation Gate

Run:

```bash
cargo test -p z00z_storage --lib
cargo test -p z00z_storage --test assets_suite
cargo test -p z00z_wallets --tests
cargo test -p z00z_simulator --test test_stage4_digest --release --features test-fast --features wallet_debug_dump
cargo test -p z00z_simulator --test test_stage4_gates --release --features test-fast --features wallet_debug_dump
cargo test -p z00z_simulator --test test_stage6_checkpoint --release --features test-fast --features wallet_debug_dump
cargo test -p z00z_simulator --test test_pipeline_genesis_tx --release --features test-fast --features wallet_debug_dump
cargo test -p z00z_simulator --test test_scenario1_unified_gate --release --features test-fast --features wallet_debug_dump
./scripts/full_verify.sh --max-safe-run
```

### 7.4 Acceptance Conditions

**✅ No first-party boundary still accepts opaque witness bytes without canonical proof validation.**

**✅ No first-party checkpoint preparation path still erases `AssetPath` semantics before validation and apply.**

**✅ No simulator witness preparation path still reconstructs `prev_root` from `CompatRoot` rows.**

**✅ Any remaining optional item is explicitly documented as deferred, not silently half-implemented.**

## 🚨 Stop Rules And Recovery Guidance

**🚨 Stop the workflow immediately if any phase causes one of the following regressions:**

- terminal `asset_id` no longer stays the canonical terminal key
- `AssetStateRoot`, `CheckRoot`, and `TxDigest` start mixing again
- a wallet or simulator layer introduces a second proof format beside `ProofBlob`
- simulator and wallet acceptance paths disagree on root-bound witness semantics

> [!Warning]
> A migration that compiles but reintroduces flat identity, root substitution, or byte-only proof acceptance is a failed migration.

**📌 Recovery order must be:**

1. revert only the failing phase changes
2. rerun the last green phase gate
3. keep the last valid proof and simulator fixtures
4. record the blocker before starting another branch of work

## ✅ Completion Definition

**✅ This workflow is complete only when all H2 and H3 sections still match the real execution order and all of the following are true:**

- storage owns the terminal storage-facing contract or one explicit storage-owned compatibility surface
- wallet preparation preserves full path semantics through checkpoint preparation
- canonical `ProofBlob` validation is mandatory at the first downstream witness boundary
- simulator root preparation and lookup are root-bound and no longer compatibility-root-driven
- optional hardening items are either finished or explicitly frozen
- final validation gates pass on one consistent revision
