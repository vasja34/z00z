# Snapshot Storage Workflow

[TOC]

📌 This workflow defines the execution order for reworking snapshot storage around the current `specs/014-z00z-storage/snapshot-storage-spec.md` contract and the already-implemented Stage 4, wallet, and storage proof paths.

🎯 The goal is to move the repository to one canonical `PrepSnapshot` artifact owned by `z00z_storage` without breaking the verified Stage 4 to Stage 6 preparation flow.

🔑 The workflow must reuse verified repository anchors first:

- `crates/z00z_simulator/src/scenario_1/stage_4.rs` for current `PrepFile`, `PrepRow`, `prep_path`, `prep_store`, `prep_wit_hex`, and `prep_root`
- `crates/z00z_simulator/src/scenario_1/stage_6.rs` for the current prep consumer, `read_prep(...)`, `PrepIdx`, and `ResolvedInput` replay wiring
- `crates/z00z_wallets/src/core/tx/state_update.rs` for `MemberWit`, `ResolvedInput`, `InputResolver`, and current path-bound validation rules
- `crates/z00z_storage/src/assets/store_internal/proof_help.rs` plus `crates/z00z_storage/src/assets/proof.rs` for `proof_item()`, `proof_blob()`, and `chk_blob(...)`
- `crates/z00z_simulator/tests/test_stage4_digest.rs`, `crates/z00z_simulator/tests/test_stage6_checkpoint.rs`, and `crates/z00z_wallets/tests/proof_blob_fix.rs` for current root and witness invariants

⚠️ This workflow does not authorize checkpoint finalization, checkpoint proof production, or simulator UX refactors beyond what is strictly required to introduce canonical snapshot storage.

## Verified Starting Point

✅ The current repository already enforces the following facts and the workflow must preserve them:

- Stage 4 builds `prev_root_hex` from `AssetStore::check_root()` rather than from `tx_digest_hex`
- Stage 4 writes `member_wit_hex` from `AssetStore::proof_blob(&path).encode()`
- `MemberWit::new(...)` binds proof bytes to `ProofItem`
- `ResolvedInput::new(...)` binds `AssetPath`, `AssetLeaf`, and `MemberWit`
- the active checkpoint-preparation path prefers `InputResolver::resolve(prev_root, asset_id, serial_id)` over path-free witness handling

📌 The canonical snapshot rollout must therefore preserve existing root, path, leaf, and witness semantics and only lift them into a dedicated storage-owned API.

## Assumptions And Open Decisions

📌 Assumption 1: the first milestone may introduce canonical snapshot types and validation in `z00z_storage` while keeping the persisted Stage 4 artifact unchanged until an explicit cut-over phase.

📌 Assumption 2: the first safe canonical witness payload is the existing binary `ProofBlob::encode()` output already written into `member_wit_hex` and consumed through `MemberWit` plus `ProofItem` checks.

❓ Open decision 1: the codebase does not settle whether the first canonical snapshot codec should be JSON-only or dual JSON plus binary. The workflow isolates that choice behind one storage-owned codec boundary.

❓ Open decision 2: the codebase does not settle whether non-canonical audit metadata belongs in `z00z_storage` or should remain simulator-local. That decision must not block canonical correctness.

🚫 No phase may silently reopen tx-digest root substitution, placeholder witness digests, or asset-id-only witness semantics. Those paths are already closed by the live code and tests.

## Implementation Anchors

📌 The workflow must target the following verified modules first.

| Area | Existing file | Role in workflow |
| --- | --- | --- |
| Current prep export | `crates/z00z_simulator/src/scenario_1/stage_4.rs` | Source of current `PrepFile` and `PrepRow` semantics |
| Current prep replay consumer | `crates/z00z_simulator/src/scenario_1/stage_6.rs` | Existing consumer that must move both replay reconstruction and fragment assembly to canonical snapshot input |
| Typed witness and input model | `crates/z00z_wallets/src/core/tx/state_update.rs` | Canonical path-bound witness and resolved-input invariants |
| Storage proof bridge | `crates/z00z_storage/src/assets/store_internal/proof_help.rs` | Existing `proof_item()` and `proof_blob()` source of truth |
| Proof codec and verifier | `crates/z00z_storage/src/assets/proof.rs` | Existing proof-byte verification contract |
| Existing root gate | `crates/z00z_simulator/tests/test_stage4_digest.rs` | Guards root-source semantics |
| Existing replay regression | `crates/z00z_simulator/tests/test_stage6_checkpoint.rs` | Guards Stage 6 prep consumption |
| Existing witness fixture | `crates/z00z_wallets/tests/proof_blob_fix.rs` | Reusable witness fixture anchor |

📌 Proposed new storage-layer files, if needed, are listed below. These are proposed targets, not current code facts.

- `crates/z00z_storage/src/checkpoint/prep.rs`
- `crates/z00z_storage/src/checkpoint/codec.rs`
- `crates/z00z_storage/src/checkpoint/ids.rs`
- `crates/z00z_storage/src/checkpoint/store.rs`
- `crates/z00z_storage/tests/snapshot_*.rs`

## Execution Guardrails

📌 The workflow must preserve the following spec-level boundaries while phases are executed:

- canonical snapshot APIs stay separate from checkpoint final artifacts and ordered execution input
- canonical snapshot verification stays separate from full checkpoint replay
- simulator adapters stay outside canonical storage modules
- transport decoding and version gating must complete before canonical validation begins
- persistence must use explicit canonical snapshot save and load operations rather than generic payload-shape inference
- snapshot persistence and audit linkage must converge on `PrepSnapshotId` rather than filenames, stage ids, or row numbers
- replay correctness must remain bound to `prev_root`, canonical path, leaf, and witness validation rather than to snapshot storage identity alone
- only one canonical path may remain by rollout completion; no second snapshot meaning may remain reachable
- deterministic entry order must follow canonical input order, and when one snapshot spans multiple tx packages it must follow the same flattened input order that checkpoint preparation later consumes

## Dependency Map

```mermaid
flowchart TD
    A[Phase 1 Baseline Freeze] --> B[Phase 2 Types and IDs]
    B --> C[Phase 3 Validation and Codec]
    C --> D[Phase 4 Builder from Stage 4 Data]
    D --> E[Phase 5 Atomic Writer Reader Cut-Over]
    E --> F[Phase 6 Test Matrix and CI Gates]
    F --> G[Phase 7 Rollout and Acceptance]
```

```mermaid
sequenceDiagram
    participant S4 as Stage 4 Builder
    participant SB as Storage Snapshot Builder
    participant SC as Storage Codec and Validator
    participant W as Wallet Types
    participant S6 as Stage 6 Consumer

    Note over S4,SC: Phase 4 builds canonical snapshot in memory from current Stage 4 facts
    S4->>SB: map current prep facts into PrepSnapshot entries
    SB->>SC: validate root, path, leaf, witness, ordering
    SC-->>SB: validated PrepSnapshot plus PrepSnapshotId
    SC-->>W: typed entries preserve ResolvedInput semantics

    Note over S4,S6: Phase 5 is one atomic writer-reader cut-over
    S4->>SC: persist canonical snapshot through storage-owned writer
    S6->>SC: read canonical snapshot through storage-owned reader
    SC-->>S6: canonical snapshot input only
```

## ⚙️ Phase 1. Freeze Current Semantics

### Phase 1 Intent

📌 Lock the current repository behavior before any canonical storage type is introduced.

### Phase 1 Entry Conditions

- `snapshot-storage-spec.md` remains the source intent document
- current Stage 4 and wallet proof-path behavior is understood from code

### Phase 1 Execution Steps

1. Reconfirm the live semantics in `crates/z00z_simulator/src/scenario_1/stage_4.rs`.
1. Reconfirm the typed witness invariants in `crates/z00z_wallets/src/core/tx/state_update.rs`.
1. Reconfirm the storage proof bridge in `crates/z00z_storage/src/assets/proof.rs` and `proof_help.rs`.
1. Record one invariant matrix covering root source, path source, witness byte source, resolved leaf source, and current replay consumer.
1. Treat any mismatch between spec and code as a blocker to implementation sequencing.

### Phase 1 Parallelization Rules

- steps 1 to 3 may run in parallel
- the invariant matrix must wait until all verification reads are complete

### Phase 1 Validation Gate

```bash
cargo test -p z00z_simulator --features test-fast test_stage4_digest -- --nocapture
cargo test -p z00z_wallets --features test-fast proof_blob_fix -- --nocapture
cargo test -p z00z_simulator --features test-fast test_stage6_checkpoint -- --nocapture
```

### Phase 1 Exit Conditions

- one verified baseline matrix exists
- no later phase contradicts the live code

### Phase 1 Rollback Rule

🛑 If any baseline claim does not match the code, stop and update the workflow inputs before creating storage types.

## ⚙️ Phase 2. Introduce Canonical Snapshot Types And IDs

### Phase 2 Intent

📌 Create the minimum canonical storage-layer shape inside `z00z_storage` only. This phase must not change persisted Stage 4 output or Stage 6 input.

### Phase 2 Target Files

- proposed: `crates/z00z_storage/src/checkpoint/prep.rs`
- proposed: `crates/z00z_storage/src/checkpoint/ids.rs`
- proposed: `crates/z00z_storage/src/checkpoint/mod.rs`
- existing facade update: `crates/z00z_storage/src/lib.rs`

### Phase 2 Execution Steps

1. Define `PrepSnapshot` and `PrepEntry` as canonical typed records.
1. Reuse existing storage types rather than inventing parallel identifiers: `AssetStateRoot`, `AssetPath`, `DefinitionId`, `SerialId`, and `AssetId`.
1. Define `PrepSnapshotId` as an external content-addressed identifier derived from canonical bytes.
1. Define a version type for snapshot schema evolution.
1. Keep witness bytes as a dedicated typed container over canonical proof bytes.
1. Define the public snapshot facade split explicitly around `build_snapshot`, `save_snapshot`, `load_snapshot`, and `validate_snapshot` responsibilities even if the exact trait name lands later. The first acceptable public shape is a narrow `PrepSnapshotStore`-style facade that accepts typed roots and typed input references only.
1. Keep simulator adapters outside canonical storage modules and keep canonical helper modules `pub(crate)` unless a cross-crate facade requires export.

### Phase 2 Required Constraints

- the canonical type must not embed checkpoint outputs, tx-proof bytes, or simulator metadata
- the canonical type must not duplicate structures already present in `z00z_storage::assets` or `z00z_wallets::core::tx`
- the canonical type must stay path-bound and root-bound by construction
- this phase must not introduce simulator-local canonical serde structs or direct simulator ownership of canonical snapshot bytes
- public snapshot boundaries must accept typed roots and typed input references only
- canonical modules must not import simulator-only transport structs directly
- simulator consumers must not reconstruct `ProofItem` semantics outside `z00z_storage`; the storage boundary must own the bridge from canonical bytes to replay-ready proof context
- `PrepSnapshotId` must stay external to the self-serialized canonical payload so identity does not become recursively self-referential
- the public facade must define one explicit error taxonomy for root mismatch, path mismatch, witness decode failure, leaf mismatch, id derivation failure, and backend persistence failure

### Phase 2 Critical Sketch

```rust
pub struct PrepSnapshot {
    pub version: PrepSnapshotVersion,
    pub prev_root: AssetStateRoot,
    pub entries: Vec<PrepEntry>,
}

pub struct PrepEntry {
    pub path: AssetPath,
    pub leaf: AssetLeaf,
    pub member_wit: PrepWitnessBytes,
}
```

📌 The persisted canonical shape above is not, by itself, the replay boundary. Before Stage 6 can rebuild `ResolvedInput`, `z00z_storage` must either return replay-ready validated entries or provide one storage-owned path for rebuilding the typed proof context required by `MemberWit::new(...)`.

### Phase 2 Parallelization Rules

- ID type design and record type design may run in parallel
- public re-export wiring must wait until both are stable

### Phase 2 Validation Gate

- code review confirms that no new type duplicates `ResolvedInput` or `MemberWit` semantics incorrectly
- `cargo test -p z00z_storage --lib` passes once the new module compiles

### Phase 2 Exit Conditions

- canonical snapshot types compile behind the storage layer
- no simulator file imports the new canonical modules directly yet
- no persisted artifact format changes have occurred yet

### Phase 2 Rollback Rule

🛑 If the new types require altering Stage 4 or Stage 6 behavior immediately, the phase is ordered incorrectly and must be split again before merge.

## ⚙️ Phase 3. Add Canonical Validation And Codec Boundary

### Phase 3 Intent

📌 Turn the new types into a validated storage contract rather than a passive DTO.

### Phase 3 Target Files

- proposed: `crates/z00z_storage/src/checkpoint/codec.rs`
- proposed: `crates/z00z_storage/src/checkpoint/store.rs`
- existing reuse: `crates/z00z_storage/src/assets/proof.rs`
- existing reuse: `crates/z00z_storage/src/assets/store_internal/proof_help.rs`

### Phase 3 Execution Steps

1. Implement canonical encode and decode logic.
1. Implement `PrepSnapshotId` derivation from canonical bytes only.
1. Implement one canonical validator with fixed order: decode artifact, enforce supported version, enforce single-root invariant, validate each entry path, validate each entry leaf, validate each entry witness binding, reject duplicate paths, reject duplicate terminal-id reuse, then derive or verify the canonical id.
1. Reuse `chk_blob(...)`, `ProofItem`, and canonical `AssetPath` semantics instead of introducing a second witness verifier.
1. Expose one storage-owned read and write boundary for canonical snapshot bytes so later simulator cut-over uses the same codec on both ends.
1. Keep canonical snapshot persistence and any future audit-wrapper persistence as distinct operations or distinct typed handles so callers cannot load wrapper content through canonical snapshot APIs.
1. Fail transport decoding before semantic validation starts when roots, ids, witness bytes, or version tags cannot be converted into typed values.
1. Add one explicit version-acceptance table or equivalent fixed gate so unsupported and malformed versions fail before witness decode or replay logic begins.
1. Require canonical save to write bytes, reload them through the canonical loader, and fail if the reloaded artifact yields a different `PrepSnapshotId`.
1. Require canonical load to recompute `PrepSnapshotId` from persisted bytes and reject backend-key or handle mismatches before replay logic begins.

### Phase 3 Critical Pseudocode

```rust
fn validate_snapshot(snapshot: &PrepSnapshot) -> Result<(), PrepSnapshotError> {
    ensure_supported_version(snapshot.version)?;
    ensure_single_root(snapshot.prev_root, &snapshot.entries)?;

    for entry in &snapshot.entries {
        validate_entry_path(entry)?;
        validate_entry_leaf(entry)?;
        validate_entry_witness(snapshot.prev_root, entry)?;
    }

    reject_duplicate_paths(snapshot.entries.as_slice())?;
    reject_duplicate_terminal_ids(snapshot.entries.as_slice())?;
    Ok(())
}
```

### Phase 3 Parallelization Rules

- codec implementation and validator test scaffolding may run in parallel
- final validator semantics must remain serialized behind one source-of-truth implementation

### Phase 3 Validation Gate

The phase must add and pass tests for:

- wrong root
- wrong path
- wrong serial
- wrong terminal asset id
- `leaf.asset_id` mismatch against `path.asset_id`
- `path.serial_id` mismatch against `leaf.serial_id`
- wrong leaf bytes
- duplicate path
- duplicate terminal id reuse
- unsupported version
- malformed version tag
- supported-version round-trip without silent field rewriting
- id drift after canonical re-encode
- reader and writer round-trip through the same storage-owned codec facade
- decoded witness with wrong leaf hash
- decoded witness with `definition_id` substituted for terminal `asset_id`
- wrapper content rejected by canonical load APIs
- stored snapshot validation through a read-only validation handle that cannot mutate backend state

### Phase 3 Exit Conditions

- the storage layer can reject semantically wrong snapshots without simulator help
- the canonical verifier path no longer depends on transport field names
- one storage-owned codec boundary exists for both future Stage 4 writes and Stage 6 reads
- load and save semantics are explicit enough that no non-canonical artifact can be mistaken for a canonical snapshot through the same API surface

### Phase 3 Rollback Rule

🛑 If validation is spread across adapters instead of one canonical storage-layer function, stop and consolidate before continuing.

## ⚙️ Phase 4. Build Canonical Snapshot From Stage 4 Data

### Phase 4 Intent

📌 Prove that the current Stage 4 producer can build a canonical `PrepSnapshot` from live preparation data without changing the persisted Stage 4 artifact yet. The persisted writer-reader cut-over belongs to Phase 5.

### Phase 4 Target Files

- existing Stage 4 producer: `crates/z00z_simulator/src/scenario_1/stage_4.rs`
- proposed canonical builder module in `z00z_storage`

### Phase 4 Execution Steps

1. Add one builder path that maps current Stage 4 preparation data into canonical `PrepEntry` values.
1. Reuse the existing Stage 4 helper order: `prep_leaf(...)`, `prep_path(...)`, `prep_store(...)`, `prep_wit_hex(...)`, and `prep_root(...)`.
1. Convert split fields into one canonical `AssetPath`.
1. Decode `member_wit_hex` into canonical witness bytes before canonical validation.
1. Build `PrepSnapshot` in memory and run it through the storage-owned validator and codec boundary.
1. Compare the canonical snapshot output against current Stage 4 root, path, leaf, and witness semantics before any persisted file-format changes are allowed.
1. Keep builder order fixed as: root load, path resolution, leaf load, witness load, entry assembly, validation, id derivation, then persistence.
1. Reject builder paths that source fields from report files, filenames, row numbers, cached wallet objects, or display-only metadata.
1. Preserve canonical input order exactly, and if one snapshot spans multiple tx packages preserve the same flattened batch input order used by later checkpoint preparation.
1. Record one migration table that maps each legacy `PrepFile` and `PrepRow` field to either its canonical replacement field or its non-canonical wrapper destination before persisted cut-over begins.

### Phase 4 Integration Constraint

🚫 The builder integration must evolve the current architecture. It must not create a second Stage 4 pipeline or a second proof generation path.

### Phase 4 Parallelization Rules

- canonical builder wiring and Phase 5 cut-over planning may be developed in parallel
- persisted reader and writer changes must stay serialized until the builder is stable

### Phase 4 Validation Gate

```bash
cargo test -p z00z_simulator --features test-fast test_stage4_digest -- --nocapture
cargo test -p z00z_simulator --features test-fast test_stage6_checkpoint -- --nocapture
```

The gate passes only if:

- canonical snapshot creation adds no root drift
- canonical snapshot bytes preserve path, leaf, and witness semantics
- the in-memory canonical snapshot maps one-to-one from the current Stage 4 facts before persisted cut-over starts
- builder failures remain distinct for unresolved path, missing leaf, serial mismatch, missing witness, and non-canonical root source

### Phase 4 Exit Conditions

- Stage 4 can produce one validated canonical snapshot from one verified source
- no duplicate proof generation path exists
- persisted Stage 4 output remains unchanged until Phase 5

### Phase 4 Rollback Rule

🛑 If Stage 6 must change before Stage 4 can build canonical snapshot data safely, revert to Phase 3 and fix the canonical builder boundary first.

## ⚙️ Phase 5. Cut Over Consumers To Canonical Snapshot Input

### Phase 5 Intent

📌 Perform one atomic writer-reader cut-over: Stage 4 must persist canonical snapshot bytes through the storage-owned codec, and Stage 6 must read the same artifact through that same boundary in the same change set.

### Phase 5 Target Files

- existing Stage 4 producer: `crates/z00z_simulator/src/scenario_1/stage_4.rs`
- existing Stage 6 consumer: `crates/z00z_simulator/src/scenario_1/stage_6.rs`
- existing wallet contract anchor: `crates/z00z_wallets/src/core/tx/state_update.rs`
- proposed storage codec boundary: `crates/z00z_storage/src/checkpoint/codec.rs`
- proposed storage snapshot facade: `crates/z00z_storage/src/checkpoint/store.rs`

### Phase 5 Execution Steps

1. Update Stage 4 to persist canonical snapshot bytes through the storage-owned write boundary.
1. Update Stage 6 to read canonical snapshot bytes through the same storage-owned read boundary in the same merge unit.
1. Move both Stage 6 fragment assembly and replay reconstruction onto the same storage-owned snapshot accessor in the same cut-over.
1. Rebuild `PrepIdx` from canonical entries so `ResolvedInput::new(...)` and `MemberWit::new(...)` stay the only typed replay bridge into wallet state-update logic.
1. Keep simulator code out of typed proof-context reconstruction. `z00z_storage` must either return replay-ready validated entries or expose one verified bridge that provides the `ProofItem` context required by `MemberWit::new(...)`.
1. Remove simulator ownership of canonical snapshot schema from `stage_4.rs` and `stage_6.rs`; file names may remain stable, but canonical field layout and codec ownership must move to `z00z_storage`.
1. Remove any public-facing path-free witness APIs from the snapshot boundary.
1. Keep `MemberIdx::get_wit(...)` out of the new canonical snapshot store API. This workflow does not require deleting the trait from wallet internals.
1. Keep non-canonical audit metadata outside canonical ids and bytes.
1. Keep snapshot validation and full checkpoint replay as separate public entry points so callers cannot pull execution input into pure snapshot verification.
1. Make checkpoint and audit callers link to snapshots by `PrepSnapshotId` rather than by mutable filenames or local transport handles. This linkage is for persistence and audit only; replay semantics must stay rooted in canonical entry validation.
1. Remove Stage 6 row-based prep lookup helpers once the canonical accessor is live so fragment generation cannot keep a second snapshot interpretation alive beside replay reconstruction.
1. Remove any remaining non-canonical adapter path so only the canonical snapshot path remains reachable.
1. Keep canonical snapshot APIs and any audit-wrapper APIs as separate artifact classes after cut-over; no generic save or load method may infer artifact meaning from payload shape.

### Phase 5 Parallelization Rules

- documentation updates may run in parallel with code changes
- Stage 4 writer changes, Stage 6 reader changes, and simulator-local schema removal must land together
- public API removal must stay serialized with test updates

### Phase 5 Validation Gate

- all snapshot callers use canonical types first
- Stage 4 and Stage 6 share one storage-owned codec boundary
- no simulator-local canonical serde schema remains active in `stage_4.rs` or `stage_6.rs`
- no Stage 6 helper still resolves prep rows through a legacy row map or asset-id-only lookup path
- no canonical API accepts filename-derived ids, split path tuples, or asset-id-only witness binding
- canonical save and load paths reject non-canonical artifact substitution, backend key mismatch, and caller-selected filename identity
- pure snapshot validation can run without ordered execution input, while full checkpoint replay still requires that extra artifact explicitly

### Phase 5 Exit Conditions

- all active snapshot consumers use canonical semantics
- Stage 4 and Stage 6 no longer own canonical snapshot field layout or encode/decode rules
- no secondary snapshot interpretation remains in the execution path
- no secondary adapter path remains active after the phase closes

### Phase 5 Rollback Rule

🛑 If a public API still accepts more than one snapshot meaning silently, reject the phase as incomplete.

## ⚙️ Phase 6. Land Test Matrix And CI Gates

### Phase 6 Intent

📌 Make the workflow enforceable by tests instead of by prose.

### Phase 6 Target Test Files

- proposed: `crates/z00z_storage/tests/snapshot_root_binding.rs`
- proposed: `crates/z00z_storage/tests/snapshot_path_binding.rs`
- proposed: `crates/z00z_storage/tests/snapshot_witness_decode.rs`
- proposed: `crates/z00z_storage/tests/snapshot_leaf_hash.rs`
- proposed: `crates/z00z_storage/tests/snapshot_ordering.rs`
- proposed: `crates/z00z_storage/tests/snapshot_ids.rs`
- proposed: `crates/z00z_storage/tests/snapshot_versions.rs`
- proposed: `crates/z00z_storage/tests/snapshot_persistence.rs`
- proposed: `crates/z00z_storage/tests/snapshot_replay_boundary.rs`
- existing simulator regression: `crates/z00z_simulator/tests/test_stage6_checkpoint.rs`

### Phase 6 Required Test Buckets

1. root consistency
1. path consistency
1. terminal asset identity binding
1. witness decode correctness
1. witness and proof-context coupling
1. leaf-hash binding
1. deterministic ordering
1. id stability
1. direct-canonical-consumer enforcement
1. shared codec ownership across Stage 4 and Stage 6
1. version gate behavior
1. persistence corruption and key mismatch handling
1. snapshot replay boundary versus full checkpoint replay boundary

### Phase 6 Execution Steps

1. Reuse `proof_blob_fix.rs`-style fixtures for positive witness cases.
1. Reuse `test_stage4_digest.rs` semantics for root-source regression coverage.
1. Add a negative matrix covering wrong root, wrong path, wrong asset id, wrong serial, wrong leaf bytes, duplicate path, duplicate terminal id, malformed witness bytes, and valid witness bytes paired with the wrong storage-derived proof context.
1. Add round-trip tests for canonical encode plus id derivation.
1. Add consumer tests proving that only canonical snapshot input is accepted at the storage boundary.
1. Add one enforcement check, test, or code-search gate proving that canonical snapshot encode and decode logic is not duplicated across simulator files.
1. Add persistence tests for truncated bytes, non-canonical artifact substitution, duplicate writes under different names, and backend key versus derived id mismatch.
1. Add replay-boundary tests proving snapshot verification succeeds without execution input while full checkpoint replay fails cleanly until execution input is provided.
1. Add dependency-direction checks or review gates proving canonical snapshot modules compile without simulator-only transport imports.
1. Add ordering tests proving that identical resolved inputs and identical flattened batch inputs yield identical canonical bytes and identical `PrepSnapshotId` values with no convenience re-sort.
1. Add version tests proving supported versions round-trip without implicit upgrade or silent field rewriting.
1. Add explicit replay and accessor tests proving that the same `prev_root` with the wrong terminal `asset_id` fails before replay can bind a resolved input successfully.
1. Add explicit boundary tests proving corrupted witness bytes and valid witness bytes paired with the wrong `ProofItem` or wrong storage-derived proof context both fail through the same storage-owned accessor used by Stage 6 assembly and replay reconstruction.
1. Add wrapper-boundary tests proving that filenames, stage ids, and report references can change without affecting canonical snapshot bytes, validation, or `PrepSnapshotId`.
1. Add facade tests proving callers can validate stored snapshots without importing simulator-local types and without receiving a mutable backend handle through the same validation entry point.
1. Add module-boundary checks or docs review gates proving canonical snapshot modules are documented as canonical, replay-facing, or audit-only and that internal helper modules are not consumed directly when a facade exists.

### Phase 6 Validation Gate

```bash
cargo test -p z00z_storage --tests
cargo test -p z00z_wallets --features test-fast test_tx_wrong_root -- --nocapture
cargo test -p z00z_wallets --features test-fast test_tx_spent_gate -- --nocapture
cargo test -p z00z_simulator --features test-fast test_stage6_checkpoint -- --nocapture
```

### Phase 6 Exit Conditions

- every invariant in the snapshot spec maps to at least one positive and one negative test
- CI can fail on root substitution, path transplant, or witness drift without relying on manual review
- CI or a documented review gate can fail when simulator code tries to own canonical snapshot codec semantics again
- CI can fail when version-gate, persistence-surface, replay-boundary, or dependency-direction rules regress

### Phase 6 Rollback Rule

🛑 If one invariant is only covered indirectly by integration tests, add a direct targeted test before the phase closes.

## ⚙️ Phase 7. Rollout, Recovery, And Acceptance

### Phase 7 Intent

📌 Define when the canonical snapshot path is ready for general use and how to recover if rollout fails.

### Phase 7 Execution Steps

1. Keep rollout blocked until canonical snapshot creation, validation, consumer cut-over, and id stability are green in CI.
1. Record which callers were moved from `PrepFile` semantics to canonical `PrepSnapshot` semantics.
1. Move new snapshot-facing integrations to canonical storage APIs first.
1. Remove alternate snapshot interpretation from the workflow once the canonical path is green.
1. Capture unresolved decisions explicitly: JSON-only versus dual codec, and audit-metadata location.
1. Record the blocker closure table for root identity, terminal asset identity, witness bytes, and snapshot purity.
1. Resolve open questions only in this order: codec choice first, then audit-metadata location.
1. Record which simulator wrapper fields remain compatibility-only after each rollout step and which canonical fields replace them, until the compatibility inventory is empty.
1. Leave one sign-off record naming the verified fixtures, the exact invariant buckets closed, and the exact commit or tag where milestone invariants were accepted.

### Phase 7 Recovery Rules

- if canonical validation rejects live Stage 4 outputs unexpectedly, stop rollout and fix the canonical builder rather than weakening the invariant
- if id derivation or ordering is unstable, freeze rollout and fix canonical encoding before widening callers
- if Stage 6 breaks during cut-over, roll back the Stage 4 writer and the Stage 6 reader together so no mixed writer-reader pair becomes active
- if a resolved question is reopened informally in non-canonical transport code or review comments, stop rollout and require an explicit spec amendment before continuing

### Phase 7 Final Acceptance Gate

The workflow is complete only when all of the following are true:

1. canonical snapshot types and ids exist in the storage layer
1. one canonical validator enforces root, path, leaf, witness, duplicate, and ordering rules
1. Stage 4 can produce canonical snapshot data without changing current root semantics
1. no alternate snapshot meaning remains active beside the canonical path
1. the full snapshot test matrix passes in CI
1. open decisions are labeled and isolated behind stable boundaries instead of blocking correctness
1. public APIs expose canonical snapshot operations only and do not leak placeholder-witness, tx-digest-root, or non-canonical identity semantics
1. no secondary adapter path is reachable from production snapshot APIs
1. no compatibility-only wrapper field remains undocumented, and no unresolved compliance gate for root identity, terminal asset identity, witness bytes, or snapshot purity remains open

## Acceptance Flow

1. Run baseline regression gates.
1. Run storage snapshot unit and integration tests.
1. Run simulator Stage 4 and Stage 6 regression tests.
1. Verify that canonical snapshot ids are stable across round-trip serialization.
1. Verify that no public snapshot API accepts tx digests, filename ids, or path-free witness semantics.
1. Record any remaining ambiguity as an explicit blocker or deferred decision.

🔔 The workflow must prefer one explicit canonical path over a prolonged dual-path rollout. Canonical correctness and consumer cut-over must close together.

## Non-Goals During This Workflow

- do not implement checkpoint final artifact storage in the same rollout
- do not redesign Stage 5 or Stage 6 business behavior
- do not introduce a second proof format beside the current `ProofBlob` bridge
- do not move simulator reporting or UX cleanup into the snapshot correctness milestone
- do not widen public APIs to accept more than one snapshot meaning

## Completion Record

📌 The implementation owner must leave one completion record that states:

- which file introduced canonical snapshot types
- which file introduced the validator and id derivation
- which file performs the direct Stage 4 to canonical snapshot build
- which test files close each invariant bucket
- which open decisions remain unresolved and why they do not block correctness
- which persistence and replay entry points are canonical
- which blocker items were closed in this rollout
