# JMT Storage Contract And Remaining Gaps

📌 This document is the replacement semantic source for first-party JMT asset storage in `specs/014-z00z-storage/`.

📌 It is intentionally code-first. Every contract statement and every remaining gap below is derived from the real current repository state in `crates/z00z_storage`, `crates/z00z_wallets`, and `crates/z00z_simulator`.

📌 It supersedes the legacy `specs/014-z00z-storage/jmt-storage-spec.md` file. That legacy file mixed accepted semantics, historical rollout notes, and stale checklist state. This document keeps only the parts still supported by the codebase plus the remaining gaps that still exist.

📌 Adjacent storage specs should treat this file as the semantic reference for path semantics, root semantics, proof semantics, identity separation, and remaining first-party integration work.

[TOC]

## 1. Scope And Status

### 1.1 Scope Contract

📌 The scope of this document is the first-party asset-storage subtree implemented in `z00z_storage`.

📌 The canonical storage deliverable in the current codebase is one semantic asset-state commitment over the hierarchy:

```text
definition_id -> serial_id -> asset_id
```

📌 The storage contract covered here includes:

- typed asset addressing
- typed storage and checkpoint root semantics
- committed definition and serial root-leaf payloads
- storage-owned proof records and witness blobs
- remaining first-party integration gaps at wallet and simulator boundaries

📌 This document does not redefine wallet scan cryptography, checkpoint proof systems, or non-storage business semantics except where the current storage integration boundary still leaks into them.

### 1.2 Analysis Method

📌 The analysis was limited to the active first-party implementation in `crates/z00z_storage`, `crates/z00z_wallets`, and `crates/z00z_simulator`.

📌 Historical rollout notes, retired migration phases, and stale plan wording were excluded unless a historical assumption is still visible in executable code.

## 2. Current Code-Backed Semantic Contract

### 2.1 Canonical Path And Hierarchy

📌 The current storage contract is path-aware and hierarchical.

📌 The canonical public address is `AssetPath { definition_id, serial_id, asset_id }` as implemented in `crates/z00z_storage/src/assets/types.rs`.

📌 The hierarchy committed by storage is:

1. one global definition tree
2. one serial tree per `definition_id`
3. one asset tree per `(definition_id, serial_id)`

📌 The consensus namespace key at the top level is `definition_id`, not display `symbol`, `AssetClass`, or registry order.

### 2.2 Terminal Payload Contract

📌 The current terminal committed payload is `AssetLeaf`.

📌 Storage today still consumes `z00z_core::assets::AssetLeaf`, but the semantic rule already enforced by storage is that the terminal committed value is the leaf payload and the terminal key is `asset_id`.

📌 Path integrity is enforced at the storage boundary through `StoreItem` and `ProofItem` construction.

### 2.3 Root Semantics Contract

📌 The current code distinguishes three root-like domains:

1. `AssetStateRoot`: canonical storage state commitment
2. `CheckRoot`: checkpoint-facing root type
3. `TxDigest`: transaction-envelope digest type

📌 These types exist today in `crates/z00z_storage/src/assets/types.rs`.

📌 `RootApi` is the current storage-owned root provider interface. `check_root()` derives `CheckRoot` from `asset_root()` rather than relabeling transaction digest bytes.

📌 `AssetStateRoot` is the only exported semantic storage state commitment. Child roots remain encapsulated through `DefinitionRootLeaf` and `SerialRootLeaf`.

### 2.4 Root-Leaf Payload Contract

📌 The current committed parent leaves are minimal and code-backed:

- `DefinitionRootLeaf { definition_id, definition_root }`
- `SerialRootLeaf { definition_id, serial_id, serial_root }`

📌 The current implementation does not commit counters, operator labels, timestamps, or audit summaries inside these parent leaves.

### 2.5 Key And Namespace Contract

📌 The current storage implementation centralizes key derivation in `crates/z00z_storage/src/assets/keys.rs`.

📌 The current derivations are:

- `def_key(definition_id)`
- `ser_key(definition_id, serial_id)`
- `asset_key(asset_id)`

📌 Equal `serial_id` values under different `definition_id` namespaces remain distinct because serial keys are namespaced by `definition_id`.

### 2.6 Proof And Witness Contract

📌 The current storage implementation owns two proof-facing contracts:

1. `ProofItem`: typed semantic proof record
2. `ProofBlob`: encoded witness payload that binds the semantic proof record to backend branch-proof bytes

📌 `ProofItem` currently carries the semantic root, exact path, committed parent leaves, and terminal `AssetLeaf`.

📌 `ProofBlob` currently carries the typed `ProofItem`, terminal `asset_leaf_hash`, `backend_root`, and serialized branch proofs for definition, serial, and asset trees.

📌 `chk_item(...)` validates semantic binding of root, path, parent leaves, and terminal leaf.

📌 `chk_blob(...)` validates semantic binding, terminal leaf hash binding, and backend proof validity for all three tree levels.

### 2.7 Historical Term Mapping For Adjacent Specs

📌 Adjacent specs sometimes use earlier names that no longer map one-to-one to current code symbols. For the current repository state, the correct semantic mapping is:

- historical aggregate storage proof contract -> `ProofItem` plus `ProofBlob`
- historical `asset_leaf_hash` proof field -> `ProofBlob.asset_leaf_hash`
- historical asset-state root contract -> `AssetStateRoot`
- checkpoint-facing root contract -> `CheckRoot`

📌 When an adjacent spec refers to `AssetCommitProof`, it should be read against the current codebase as the combined semantic-plus-byte witness contract implemented by `ProofItem` and `ProofBlob`.

### 2.8 Current Public Storage Facade

📌 The current first-party storage facade is `AssetStore`.

📌 The current public operations include `put_item(...)`, `get_item(...)`, `del_item(...)`, `apply_ops(...)`, `root()`, `proof_item(...)`, and `proof_blob(...)`.

📌 The current implementation stages hierarchical updates bottom-up and commits all touched logical trees through one shared batched store transition.

### 2.9 Closed Baseline Questions

📌 The following questions are closed by the current codebase and should not be reopened by a new remaining-work spec unless the code changes again:

- the canonical path is `definition_id -> serial_id -> asset_id`
- the top namespace key is `definition_id`
- the terminal key is `asset_id`
- parent root leaves are minimal
- typed root types exist and are distinct from tx digests
- proof ownership lives in `z00z_storage`
- storage is no longer a flat semantic tree keyed only by terminal `asset_id`

## 3. Remaining Gaps

📌 The functional migration gaps tracked by the earlier rollout are now closed on the accepted milestone revision.

📌 Closed on the current revision:

- `z00z_storage` now exposes one explicit storage-owned compatibility surface for `AssetLeaf`, and storage-facing internals compile against that surface instead of depending on a second write-authoritative leaf contract.
- wallet checkpoint preparation preserves full `AssetPath` semantics through resolved inputs and `TxPkgSum` rather than collapsing identity to terminal `asset_id` before verification.
- the first downstream wallet witness boundary now validates canonical `ProofBlob` payloads through the storage-owned `chk_blob(...)` validator instead of accepting opaque non-empty bytes.
- simulator Stage 4 now persists storage-produced root semantics directly and no longer depends on the accepted-path `CompatRoot` reconstruction flow or silent `ProofBlob::rebind(...)` rewriting.
- simulator Stage 6 witness lookup is root-bound for the accepted path and rejects mismatched `prev_root` lookups instead of using root-agnostic witness retrieval.
- storage, wallet, and simulator now agree on one first-party proof boundary, and the final unified validation pass is green on one revision.

### 3.1 Deferred Optional Hardening

📌 No required functional gap remains open for this migration slice.

📌 The only remaining items are explicit deferred follow-ups from Phase 6:

- `DefinitionKey` and `SerialKey` wrapper types remain deferred because `DefinitionId`, `SerialId`, `AssetId`, and the existing `def_key(...)`, `ser_key(...)`, and `asset_key(...)` helpers already provide the accepted semantic boundary for this milestone.
- broader backend abstraction remains deferred because the current accepted milestone keeps `MemTreeStore` as the backend endpoint behind the private `TreeStore` namespace multiplexer, and no hierarchy-facing semantic code requires a new backend trait to preserve correctness.

📌 Any future spec that reopens one of those items should treat it as optional follow-up architecture work, not as an unfinished migration blocker.

## 4. Recommended Shape For The Next Spec

📌 A new remaining-work spec should not reopen hierarchy design, root-leaf payload design, root-type separation, or proof-container design. Those parts already exist in code.

📌 Any next spec should focus only on explicitly deferred optional work, not on reopening the closed migration path.

📌 The only live follow-up themes left after this milestone are:

- optional decision on semantic key wrapper types
- optional decision on whether backend abstraction should ever move beyond the current `MemTreeStore` milestone endpoint

📌 Everything else should be treated as closed unless new code evidence reopens it.

## 5. Replacement Rule For Neighboring Specs

📌 All documents under `specs/014-z00z-storage/` that previously treated the deleted legacy `jmt-storage-spec.md` file as the semantic source of truth must now treat this file as the semantic source of truth instead.

📌 References to path semantics, root semantics, proof semantics, identity split, and remaining first-party integration work should all resolve to this document.
