# Checkpoint Storage Plan

[TOC]

**📌 This plan rewrites the current checkpoint-storage workflow into one implementation-ready execution document that extends the live wallet and simulator checkpoint path without freezing current Stage 6 placeholders into long-term storage semantics.**

**🎯 The implementation goal is to make `z00z_storage` own one canonical checkpoint draft, final artifact, linkage, and replay-input boundary above the asset JMT layer while preserving the current typed wallet state-update contract.**

**🔑 The plan is anchored to verified code facts, not to greenfield design:**

- `crates/z00z_wallets/src/core/tx/state_update.rs`
- `crates/z00z_simulator/src/scenario_1/stage_6.rs`
- `crates/z00z_storage/src/assets/types.rs`
- `crates/z00z_storage/src/lib.rs`
- `crates/z00z_simulator/tests/test_stage6_checkpoint.rs`
- `crates/z00z_wallets/tests/test_tx_wrong_root.rs`
- `crates/z00z_wallets/tests/test_tx_spent_gate.rs`
- `specs/014-z00z-storage/done/snapshot-storage-spec.md`

> [!Important]
> This plan rewrites execution work only. It does not authorize code implementation, snapshot redesign, proof-system redesign, or simulator UX work beyond what is required to remove placeholder checkpoint storage behavior.

## 🔑 Verified Scope

### 📌 Verified Codebase Facts

**📌 The current codebase already fixes the following semantics and the plan must preserve them exactly:**

- `z00z_wallets::core::tx::Checkpoint` already carries `height`, `prev_root`, `new_root`, `spent_delta`, `created_delta`, and `cp_proof`
- `CheckpointPubIn` is reconstructed from checkpoint fields through `Checkpoint::as_pub_in()` and currently excludes `height`
- `apply_batch_checkpoint(...)` currently returns `cp_proof: Vec::new()`, so the wallet-side typed checkpoint output behaves as a proofless draft rather than a final proved artifact
- `prepare_tx_sum(...)` is the existing typed entry point for compact input references plus resolved pre-state membership
- Stage 6 currently persists a local JSON wrapper named `Checkpoint` with `prev_root_hex`, `new_root_hex`, `spent_delta`, `created_delta`, and `fragment_ids`
- Stage 6 loads the pre-state through `PrepFsStore`, then uses `replay_entries(...)` plus `PrepIdx::new(...)` to reconstruct `ResolvedInput`
- Stage 6 still decodes `pkg.tx_digest_hex` and reuses those bytes as placeholder `tx_proof` input to `prepare_tx_sum(...)`
- `z00z_storage::assets::types` already exports `AssetId`, `SerialId`, `AssetStateRoot`, and `CheckRoot`
- `z00z_storage/src/lib.rs` still exports only `assets` and `snapshot`, so checkpoint storage has no canonical public surface yet

**📌 The plan must therefore preserve the wallet-side state-apply contract, split drafts from finals at the type boundary, and remove `tx_digest_hex` placeholder semantics instead of codifying them.**

### ❓ Assumptions, Blockers, And Resolved Decisions

**📌 Assumption 1: the first safe storage milestone may introduce canonical checkpoint types and persistence boundaries before a real checkpoint proof producer lands, but all proofless outputs must remain explicitly typed as drafts.**

**📌 Assumption 2: the pre-state dependency remains the accepted snapshot contract in `specs/014-z00z-storage/done/snapshot-storage-spec.md`. Checkpoint storage must consume validated snapshot artifacts and must not duplicate snapshot semantics.**

**📌 Decision 1: canonical checkpoint storage must support dual JSON plus binary from day one. Binary bytes must be the canonical identity source, and JSON must remain an explicit transport or debug codec rather than an alternate identity source.**

**📌 Decision 2: the final artifact must carry an explicit proof-system discriminator. Proof-system identity must not be inferred only from artifact versioning.**

**📌 Decision 3: an audit wrapper such as `CheckpointAuditView` must live in `z00z_storage`. Persistent audit-only records must not remain simulator-local once canonical checkpoint storage lands.**

**🚩 Blocker rule: no phase may silently keep `tx_digest_hex` as the Stage 6 placeholder `tx_proof` input in the canonical checkpoint build path, treat `cp_proof: []` as a final artifact, or allow `fragment_ids` to enter canonical checkpoint bytes or canonical public inputs.**

> [!Warning]
> If any later code proposal requires checkpoint replay, proof verification, or root validation to trust simulator-local wrapper fields, the proposal conflicts with the verified starting point and must be rejected or rewritten.

## 📌 Plan Structure

```mermaid
flowchart TD
    A[Phase 1 Freeze Baseline] --> B[Phase 2 Introduce Types and IDs]
    B --> C[Phase 3 Add Facade and Codec]
    C --> D[Phase 4 Build Drafts from Snapshot and Exec Input]
    D --> E[Phase 5 Finalize Artifact and Link]
    E --> F[Phase 6 Cut Over Simulator and Public APIs]
    F --> G[Phase 7 Land Test Matrix and Sign Off]
```

```mermaid
sequenceDiagram
    participant SNAP as PrepSnapshot Store
    participant EXEC as CheckpointExecInput Store
    participant BUILD as Draft Builder
    participant PROVE as Proof Producer
    participant CP as Checkpoint Store

    SNAP->>BUILD: load validated PrepSnapshot
    EXEC->>BUILD: load ordered execution input
    BUILD->>BUILD: validate root and linkage invariants
    BUILD->>BUILD: call prepare_tx_sum and apply_batch_checkpoint once
    BUILD-->>CP: save CheckpointDraft
    BUILD->>PROVE: reconstruct CheckpointPubIn
    PROVE-->>CP: attach non-empty cp_proof
    CP->>CP: derive CheckpointId and persist CheckpointLink
    CP-->>BUILD: load final CheckpointArtifact and replay handles
```

## 🔔 Test Taxonomy And Ownership

**📌 This plan must land checkpoint coverage through three explicit test layers instead of relying on one generic Phase 7 bucket:**

- unit tests must live next to new checkpoint modules when they validate one pure type, codec rule, id rule, or finalization rule in isolation
- storage integration tests must live under `crates/z00z_storage/tests/` when they validate persistence surfaces, loader rejection, linkage, or replay-input contracts across module boundaries
- simulator integration or e2e checkpoint tests must live under `crates/z00z_simulator/tests/` when they validate Stage 6 cut-over, draft-only gating, or canonical-storage ownership through scenario execution
- the existing wallet and simulator regression anchors remain mandatory baseline integration tests and must not be treated as replacements for the new checkpoint unit-test surface

**📌 Every phase below must therefore name which test layer proves its new behavior. If a phase adds only prose-level invariants and does not name unit, integration, or simulator coverage where required, the phase is not execution-ready.**

## ⚙️ Phase 1. Freeze Baseline Checkpoint Semantics

### Add the source-of-truth mismatch matrix

Objective:

**📌 Capture the exact current meaning of wallet checkpoint fields, Stage 6 wrapper fields, placeholder proof inputs, and missing storage identities before any checkpoint storage type is introduced. This unit exists to stop the plan from drifting away from the current code.**

Target Files And Structures:

- `crates/z00z_wallets/src/core/tx/state_update.rs`
- `crates/z00z_simulator/src/scenario_1/stage_6.rs`
- `crates/z00z_storage/src/assets/types.rs`
- `crates/z00z_storage/src/snapshot/store.rs`
- `crates/z00z_storage/src/lib.rs`

Implementation Steps:

- Read `Checkpoint`, `CheckpointPubIn`, `prepare_tx_sum(...)`, and `apply_batch_checkpoint(...)` in execution order and record which fields already exist and which semantics they enforce.
- Read the Stage 6 local `Checkpoint` wrapper and record which fields are canonical candidates, which fields are audit-only, and which fields are placeholders that must be removed.
- Read `PrepSnapshotStore::replay_entries(...)` in `crates/z00z_storage/src/snapshot/store.rs` and freeze it as the existing storage-owned replay-entry seam that later phases must reuse.
- Record one mismatch matrix with four columns: current wallet checkpoint field, current Stage 6 wrapper field, proposed canonical storage field, and classification.
- Use only the classifications `canonical`, `draft-only`, `final-only`, `audit-only`, `transport-only`, or `blocked`.
- Add one blocker row for every field or behavior that currently maps to more than one target meaning.

Invariants And Constraints:

- `height` already exists on the wallet checkpoint and must remain separate from artifact schema version
- `CheckpointPubIn` currently excludes `height`; any change to that fact must be explicit and phase-scoped
- `fragment_ids` must stay outside canonical artifact bytes
- `tx_digest_hex` placeholder `tx_proof` input bytes must be tracked as a removal target, not as a preserved behavior

Validation Strategy:

- Reconfirm root mismatch behavior through `test_tx_wrong_root`
- Reconfirm spent-path rejection through `test_tx_spent_gate`
- Reconfirm Stage 6 wrapper expectations through `test_stage6_checkpoint`
- Treat any uncovered semantic row as a blocker for Phase 2

Dependencies:

- None

Completion Criteria:

**📌 This unit is complete only when every current checkpoint field and wrapper field has one unambiguous classification and every blocker has one owning file plus one removal phase.**

Recorded Baseline Mismatch Matrix:

| Wallet checkpoint field | Stage 6 wrapper field | Proposed canonical storage target | Classification |
| --- | --- | --- | --- |
| `height` | missing | `CheckpointDraft.height` and `CheckpointArtifact.height` | canonical |
| `prev_root` | `prev_root_hex` | typed canonical previous root in draft and final artifact | canonical |
| `new_root` | `new_root_hex` | typed canonical next root in draft and final artifact | canonical |
| `spent_delta: Vec<SpentEnt>` | `spent_delta: Vec<String>` | canonical spent delta keyed by terminal `asset_id` only | canonical |
| `created_delta: Vec<CreatedEnt>` | `created_delta: Vec<MadeEnt>` | canonical created delta keyed by terminal `asset_id` plus `leaf_hash` | canonical |
| `cp_proof: Vec<u8>` | missing | draft omits proof bytes, final artifact carries explicit proof bytes | draft-only |
| missing external identity | missing external identity | `CheckpointId` derived from canonical final bytes | blocked |
| missing replay-input identity | thin prep reference only | `CheckpointExecInputId` derived from canonical execution-input bytes | blocked |
| storage-owned replay seam | local Stage 6 replay use of `PrepReplayEntry` | reuse `PrepSnapshotStore::replay_entries(...)` as the only replay-entry boundary | canonical |
| missing public checkpoint module export | missing public checkpoint module export | `z00z_storage::checkpoint` added and re-exported only after the contract stabilizes | blocked |
| missing audit-only storage surface | `fragment_ids` persisted only in Stage 6 wrapper | storage-owned audit record kept outside canonical artifact bytes | audit-only |
| placeholder tx proof input | `pkg.tx_digest_hex` decoded into Stage 6 `tx_proof` input | removal-only placeholder that must not survive into canonical build or final proof semantics | blocked |

Recorded Phase 1 Blocker Table:

| Blocker | Current source | Why it is blocked | Owning file | Removal phase |
| --- | --- | --- | --- | --- |
| Proofless wallet output still carries `cp_proof: []` | `apply_batch_checkpoint(...)` emits `cp_proof: Vec::new()` | current typed output is a draft and must not be treated as a final artifact | `crates/z00z_wallets/src/core/tx/state_update.rs` | Phase 2 for type split, Phase 5 for explicit finalization |
| Stage 6 reuses `pkg.tx_digest_hex` as placeholder `tx_proof` input | `build_target_cp(...)` decodes `pkg.tx_digest_hex` before `prepare_tx_sum(...)` | canonical checkpoint semantics must not inherit transaction-digest placeholder proof bytes | `crates/z00z_simulator/src/scenario_1/stage_6.rs` | Phase 6 |
| `fragment_ids` are persisted in the Stage 6 checkpoint wrapper | Stage 6 local `Checkpoint.fragment_ids` | fragment provenance is audit data and must not enter canonical checkpoint bytes or public inputs | `crates/z00z_simulator/src/scenario_1/stage_6.rs` | Phase 6 |
| Canonical checkpoint identities do not exist yet | no checkpoint id types in storage | replay linkage and final artifact identity are still implicit | proposed `crates/z00z_storage/src/checkpoint/ids.rs` | Phase 2 |
| `z00z_storage` has no checkpoint public surface | `crates/z00z_storage/src/lib.rs` exports only `assets` and `snapshot` | callers cannot depend on one canonical storage-owned checkpoint boundary yet | `crates/z00z_storage/src/lib.rs` | Phase 2 for insertion, Phase 6 for stable re-export |

Recorded Replay Seam Freeze:

**📌 `PrepSnapshotStore::replay_entries(...)` in `crates/z00z_storage/src/snapshot/store.rs` is the existing storage-owned replay-entry boundary. Later phases must reuse this seam and must not introduce a second replay-entry abstraction unless the snapshot contract itself changes.**

**✔️ Implementation Checklist:**

- [x] Read `Checkpoint`, `CheckpointPubIn`, `prepare_tx_sum(...)`, and `apply_batch_checkpoint(...)` in `crates/z00z_wallets/src/core/tx/state_update.rs`.
- [x] Read the local `Checkpoint` wrapper and `build_target_cp(...)` in `crates/z00z_simulator/src/scenario_1/stage_6.rs`.
- [x] Record one mismatch matrix for `height`, `prev_root`, `new_root`, `spent_delta`, `created_delta`, `cp_proof`, `fragment_ids`, and the placeholder `tx_proof` input bytes derived from `pkg.tx_digest_hex`.
- [x] Record one blocker table entry for `cp_proof: []` on proofless outputs.
- [x] Record one blocker table entry for `pkg.tx_digest_hex` reused as the Stage 6 placeholder `tx_proof` input.
- [x] Record one blocker table entry for `fragment_ids` in the Stage 6 wrapper.
- [x] Record one blocker table entry for the missing checkpoint identities and missing checkpoint module export in `crates/z00z_storage/src/lib.rs`.
- [x] Run `cargo test --release -p z00z_wallets --features test-fast --features wallet_debug_dump --test test_tx_wrong_root -- --nocapture` as the root-source baseline gate.
- [x] Run `cargo test --release -p z00z_wallets --features test-fast --features wallet_debug_dump --test test_tx_spent_gate -- --nocapture` as the spent-path baseline gate.
- [x] Run `cargo test --release -p z00z_simulator --features test-fast --features wallet_debug_dump --test test_stage6_checkpoint -- --nocapture` as the Stage 6 wrapper baseline gate.
- [x] Stop the plan if any field cannot be classified without introducing a second meaning.

### Lock the baseline gate set and fail-loud rules

Objective:

**📌 Convert the baseline semantics into named regression gates so later phases can reference explicit behavior checks instead of vague preservation language.**

Target Files And Structures:

- `crates/z00z_wallets/tests/test_tx_wrong_root.rs`
- `crates/z00z_wallets/tests/test_tx_spent_gate.rs`
- `crates/z00z_simulator/tests/test_stage6_checkpoint.rs`

Implementation Steps:

- Define one named baseline gate for root-source correctness.
- Define one named baseline gate for spent-path rejection.
- Define one named baseline gate for Stage 6 wrapper linkage and typed delta shape.
- For each gate, record the exact failure class or observable behavior that must fail loudly if a later phase regresses it.

Invariants And Constraints:

- named gates must reference existing tests first
- no later phase may replace an existing regression gate with prose-only sign-off
- fail-loud rules must be tied to exact test targets or new targeted tests
- the existing baseline anchors are integration-style regression gates and do not remove the need for later checkpoint unit tests in `z00z_storage`

Validation Strategy:

- confirm that each named gate maps to at least one executable test target
- classify `test_tx_wrong_root`, `test_tx_spent_gate`, and `test_stage6_checkpoint` explicitly as baseline integration or e2e-style regression anchors
- mark any semantic invariant without a direct gate as a Phase 7 test debt item

Dependencies:

- requires the mismatch matrix from the previous unit

Completion Criteria:

**📌 This unit is complete only when every later phase can cite a named baseline gate for root correctness, spent-path rejection, and Stage 6 wrapper behavior.**

Recorded Named Baseline Gates:

- `CP_GATE_ROOT_SRC`: root-source correctness must reject any checkpoint batch whose declared `prev_root` diverges from the state root, and the reject class must remain `StateErr::PrevRoot` through `test_tx_wrong_root`
- `CP_GATE_SPENT_PATH`: spent-path rejection must reject interval-spent inputs without mutating state, and the reject class must remain `StateErr::SpentAfter` through `test_tx_spent_gate`
- `CP_GATE_STAGE6_WRAP`: Stage 6 wrapper behavior must preserve typed `prev_root_hex` or `new_root_hex`, typed `created_delta` rows, and fragment linkage in the legacy wrapper until the canonical storage cut-over is complete, as enforced by `test_stage6_checkpoint`

Recorded Baseline Gate Layers:

- `CP_GATE_ROOT_SRC` is a `wallet integration` baseline gate owned by `crates/z00z_wallets/tests/test_tx_wrong_root.rs`
- `CP_GATE_SPENT_PATH` is a `wallet integration` baseline gate owned by `crates/z00z_wallets/tests/test_tx_spent_gate.rs`
- `CP_GATE_STAGE6_WRAP` is a `simulator integration` baseline gate owned by `crates/z00z_simulator/tests/test_stage6_checkpoint.rs`

Recorded Fail-Loud Rules:

- wrong-root substitution or reuse must fail as `StateErr::PrevRoot` before any state mutation
- spent-path or duplicate-spend reuse must fail as `StateErr::SpentAfter` or `StateErr::SpentBatch` before any output insertion
- Stage 6 wrapper regression must fail loudly if `prev_root_hex`, `new_root_hex`, `created_delta`, `spent_delta`, or `fragment_ids` drift from the current wrapper contract before canonical storage cut-over replaces that wrapper

Recorded Phase 7 Test Debt Handoff:

- Phase 7 must add one explicit regression row proving proofless draft material with `cp_proof: []` is rejected as a final artifact class even when other fields are well formed
- Phase 7 must add one explicit regression row proving canonical loaders reject any artifact or proof-input path that still depends on `pkg.tx_digest_hex` placeholder bytes
- Phase 7 must add one explicit regression row proving audit-only `fragment_ids` never enter canonical artifact bytes, canonical ids, or canonical public inputs
- Phase 7 must add one explicit regression row proving `CheckpointPubIn` stays distinct from checkpoint metadata such as `height` until a later phase changes that contract intentionally

**✔️ Implementation Checklist:**

- [x] Name one gate for root-source correctness and map it to `test_tx_wrong_root`.
- [x] Name one gate for spent-path rejection and map it to `test_tx_spent_gate`.
- [x] Name one gate for Stage 6 wrapper shape and linkage and map it to `test_stage6_checkpoint`.
- [x] Record the test-layer classification for each baseline gate as `wallet integration`, `wallet integration`, and `simulator integration` respectively.
- [x] Record one fail-loud rule for root substitution or wrong-root reuse.
- [x] Record one fail-loud rule for spent-path or duplicate-spend reuse.
- [x] Record one fail-loud rule for Stage 6 wrapper regression affecting `prev_root_hex`, `created_delta`, `spent_delta`, or `fragment_ids`.
- [x] Add uncovered invariants to the Phase 7 test-matrix backlog instead of leaving them implicit.

## ⚙️ Phase 2. Introduce Canonical Checkpoint Types, IDs, And Error Taxonomy

### Add draft and final artifact records inside storage

Objective:

**📌 Introduce the minimum canonical checkpoint data model in `z00z_storage` so the repository has explicit draft and final artifact classes before any persistence cut-over begins. This unit exists to remove the current gray zone where the wallet-side `Checkpoint` looks final but behaves like a draft.**

Target Files And Structures:

- proposed: `crates/z00z_storage/src/checkpoint/mod.rs`
- proposed: `crates/z00z_storage/src/checkpoint/artifact.rs`
- proposed: `crates/z00z_storage/src/checkpoint/ids.rs`
- proposed: `crates/z00z_storage/src/error.rs`
- proposed: `crates/z00z_storage/tests/checkpoint_draft_final.rs`
- existing: `crates/z00z_storage/src/assets/types.rs`
- existing: `crates/z00z_storage/src/lib.rs`

Implementation Steps:

- Add `CheckpointDraft` as a proofless record with `version`, `height`, `prev_root`, `new_root`, `spent_delta`, and `created_delta`.
- Add `CheckpointArtifact` as a final record with the same semantic fields plus dedicated proof bytes.
- Reuse storage-side semantic wrappers such as `CheckRoot`, `AssetId`, and `SerialId` where they already match checkpoint meaning.
- Keep any new checkpoint-local wrappers minimal and add them only where the current assets module has no semantic type.
- Add one adapter contract from wallet `Checkpoint` into `CheckpointDraft` so migration reuses the current typed apply result instead of duplicating semantics.
- Keep helper modules `pub(crate)` until a cross-crate facade actually needs export.

Invariants And Constraints:

- `CheckpointDraft` must be proofless by construction
- `CheckpointArtifact` must not model proof bytes as optional
- snapshot witness bytes, filenames, `fragment_ids`, and report metadata must not appear in either canonical record
- artifact schema version, checkpoint height, and JMT progression must remain distinct concepts

Validation Strategy:

- compile the new storage module behind the existing crate boundary
- confirm that draft and final classes cannot be confused through one shared optional proof field
- review imports and keep the module tree within the repository depth conventions
- add unit tests in `crates/z00z_storage/src/checkpoint/artifact.rs` for draft-versus-final type invariants
- add storage integration tests in proposed `crates/z00z_storage/tests/checkpoint_draft_final.rs` for wrong-class persistence and proofless-draft versus final-artifact separation

Dependencies:

- requires Phase 1 blocker classification

Completion Criteria:

**📌 This unit is complete only when the repository contains explicit canonical draft and final checkpoint types and no new API still uses one record with optional proof semantics.**

Recorded Phase 2 Draft Contract:

- `crates/z00z_storage/src/checkpoint/artifact.rs` now defines `CheckpointVer`, `CheckpointDraft`, `CheckpointArtifact`, `SpentEnt`, and `CreatedEnt`
- `CheckpointDraft` is proofless by construction because the draft type has no proof field
- `CheckpointArtifact` rejects empty proof bytes through `CheckpointArtifact::new(...)` and `CheckpointArtifact::from_draft(...)`
- `WalletDraft` is the wallet-to-storage adapter contract so later migration can map wallet `Checkpoint` into one canonical storage draft without duplicating simulator-local semantics
- `CheckRoot` and `AssetId` are reused from `crates/z00z_storage/src/assets/types.rs`; no duplicate root or asset-id wrapper was introduced
- `crates/z00z_storage/src/checkpoint/store.rs` now provides `load_draft(...)` and `load_artifact(...)` so wrong-class loader rejection is expressed as `CheckpointError::WrongClass` instead of raw codec text
- `crates/z00z_storage/src/lib.rs` now compiles the checkpoint contract through `pub mod checkpoint;` and `pub mod error;` without adding transport-local names or optional-proof semantics

**✔️ Implementation Checklist:**

- [x] Create `crates/z00z_storage/src/checkpoint/mod.rs` as the checkpoint insertion point.
- [x] Create `crates/z00z_storage/src/checkpoint/artifact.rs` with `CheckpointDraft` and `CheckpointArtifact`.
- [x] Reuse `CheckRoot` and existing asset wrappers from `crates/z00z_storage/src/assets/types.rs` where semantics already match.
- [x] Add one checkpoint artifact version type that is not reused as height or JMT state version.
- [x] Define one wallet-to-storage draft adapter contract rather than duplicating `Checkpoint` semantics in simulator code.
- [x] Keep helper modules `pub(crate)` unless a real facade requires export.
- [x] Update `crates/z00z_storage/src/lib.rs` only when the typed checkpoint contract is stable enough for re-export.
- [x] Compile-check the storage crate after the new module tree is introduced.
- [x] Add unit tests in `crates/z00z_storage/src/checkpoint/artifact.rs` proving `CheckpointDraft` is proofless by construction and `CheckpointArtifact` cannot model optional proof bytes.
- [x] Add proposed storage integration tests in `crates/z00z_storage/tests/checkpoint_draft_final.rs` for draft-versus-final loader rejection.

### Define external identities and one error taxonomy

Objective:

**📌 Define stable content-addressed identities and one checkpoint-specific error contract before persistence code or simulator adapters are allowed to depend on checkpoint storage.**

Target Files And Structures:

- proposed: `crates/z00z_storage/src/checkpoint/ids.rs`
- proposed: `crates/z00z_storage/src/error.rs`
- proposed: `crates/z00z_storage/src/checkpoint/store.rs`
- proposed: `crates/z00z_storage/tests/checkpoint_ids.rs`

Implementation Steps:

- Add `CheckpointId` as an external content-addressed identifier derived from canonical final artifact bytes only.
- Add `CheckpointExecInputId` as an external content-addressed identifier derived from canonical execution-input bytes only.
- Keep both ids external to self-serialized payloads so identity hashing is not recursive.
- Define one checkpoint-specific error taxonomy that distinguishes proofless-final rejection, linkage mismatch, replay-input mismatch, root mismatch, codec failure, and backend failure.
- Reserve error variants for unsupported versions and wrong artifact class so transport failures can fail before semantic validation begins.

Invariants And Constraints:

- ids must remain stable across round-trip serialization of unchanged canonical bytes
- ids must not be derived from filenames, report paths, row numbers, or `prep_snapshot_id` alone
- error classes must remain precise enough to support fail-loud migration tests

Validation Strategy:

- review id derivation inputs and confirm they use canonical bytes only
- review error taxonomy against the blocker table from Phase 1
- reserve test targets for wrong-class loads and backend key mismatches in Phase 3 and Phase 7
- add unit tests in `crates/z00z_storage/src/checkpoint/ids.rs` for stable id derivation over identical canonical bytes
- add storage integration tests in proposed `crates/z00z_storage/tests/checkpoint_ids.rs` for wrong-class identity inputs, unsupported versions, and backend-key mismatch propagation

Dependencies:

- requires the draft and final record definitions from the previous unit

Completion Criteria:

**📌 This unit is complete only when checkpoint identities are external, content-addressed, and paired with one explicit checkpoint error contract.**

Recorded Phase 2 Id And Error Contract:

- `crates/z00z_storage/src/checkpoint/ids.rs` now defines external `CheckpointId` and `CheckpointExecInputId`
- `CheckpointId` hashes canonical final artifact bytes only; `CheckpointExecInputId` hashes canonical execution-input bytes only
- forbidden identity inputs are now recorded as filenames, report paths, row numbers, `fragment_ids`, and `prep_snapshot_id` taken without canonical bytes
- `crates/z00z_storage/src/error.rs` now defines `CheckpointError` with `ProoflessFinal`, `LinkMix`, `ReplayMix`, `RootMix`, `Codec`, `VersionMix`, `WrongClass`, `KeyMix`, and `Backend`
- Phase 1 blocker cross-check: proofless output maps to `ProoflessFinal`, placeholder proof or replay drift maps to `ReplayMix`, root drift maps to `RootMix`, missing final-artifact identity maps to `WrongClass` or `VersionMix` before semantic validation, and backend key mismatch propagates through `KeyMix`
- Phase 3 carry-forward gate: wrong-class and unsupported-version negative cases must remain explicit in the later codec validation gate

**✔️ Implementation Checklist:**

- [x] Define `CheckpointId` in `crates/z00z_storage/src/checkpoint/ids.rs`.
- [x] Define `CheckpointExecInputId` in `crates/z00z_storage/src/checkpoint/ids.rs`.
- [x] Specify the exact canonical bytes each id hashes and list the forbidden identity inputs.
- [x] Add checkpoint-specific error variants for proofless final artifacts, linkage mismatch, replay-input mismatch, root mismatch, codec failure, unsupported version, wrong artifact class, and backend failure.
- [x] Cross-check the error taxonomy against each Phase 1 blocker row.
- [x] Carry the wrong-class and unsupported-version cases forward into the Phase 3 validation gate.
- [x] Add unit tests in `crates/z00z_storage/src/checkpoint/ids.rs` for stable id derivation and forbidden identity inputs.
- [x] Add proposed integration tests in `crates/z00z_storage/tests/checkpoint_ids.rs` for wrong-class identity paths and backend-key mismatch handling.

## ⚙️ Phase 3. Add The Checkpoint Facade, Codec Boundary, And Persistence Taxonomy

### Resolve codec strategy and add typed codecs

Objective:

**📌 Resolve codec strategy before any persistence implementation starts, then add typed codecs that stop raw strings and transport-local names at the storage boundary.**

Target Files And Structures:

- proposed: `crates/z00z_storage/src/checkpoint/codec.rs`
- proposed: `crates/z00z_storage/src/checkpoint/artifact.rs`
- proposed: `crates/z00z_storage/src/checkpoint/exec_input.rs`
- proposed: `crates/z00z_storage/tests/checkpoint_codec.rs`
- existing abstraction source: `z00z_utils::codec`

Implementation Steps:

- Use the resolved dual-codec contract from Decision 1 and record binary bytes as the canonical identity source before writing codec code.
- Implement canonical encode and decode paths for `CheckpointDraft`, `CheckpointArtifact`, `CheckpointLink`, and `CheckpointExecInput`.
- Keep string and hex decoding inside codec or adapter modules only.
- Fail closed on malformed transport values before they can reach semantic validation, replay logic, or proof verification.
- Define explicit behavior for supported versions, unsupported newer versions, and malformed version tags.

Invariants And Constraints:

- codecs must use `z00z_utils::codec` abstractions instead of direct `serde_json` calls in canonical storage code
- transport-local field names such as `prev_root_hex` must not appear in canonical semantic modules
- decoder output must be fully typed or rejected; partially decoded values must not cross the pre-validation gate

Validation Strategy:

- add round-trip coverage for each artifact class once the codec exists
- add negative coverage for malformed roots, malformed ids, malformed version tags, and wrong artifact classes
- check that supported-version loads do not silently rewrite fields
- keep pure codec-edge coverage as unit tests in `crates/z00z_storage/src/checkpoint/codec.rs`
- keep cross-artifact encode-decode rejection coverage in proposed `crates/z00z_storage/tests/checkpoint_codec.rs`

Dependencies:

- requires Phase 2 ids and artifact classes

Completion Criteria:

**📌 This unit is complete only when canonical checkpoint decoding produces fully typed values or fails before semantic validation begins.**

**✔️ Implementation Checklist:**

- [x] Record the resolved dual-codec contract in this file and state that binary bytes are the canonical identity source.
- [x] Create `crates/z00z_storage/src/checkpoint/codec.rs`.
- [x] Add typed binary and JSON codec paths for `CheckpointDraft`, `CheckpointArtifact`, `CheckpointLink`, and `CheckpointExecInput`.
- [x] Keep all string and hex parsing inside codec or adapter modules only.
- [x] Add decode failures for malformed roots, malformed ids, malformed versions, and wrong artifact class payloads.
- [x] Add explicit supported-version and unsupported-version handling.
- [x] Verify that canonical storage code uses `z00z_utils::codec` instead of direct `serde_json` in the new checkpoint module.
- [x] Add unit tests in `crates/z00z_storage/src/checkpoint/codec.rs` for malformed root, malformed id, and malformed version rejection.
- [x] Add proposed integration tests in `crates/z00z_storage/tests/checkpoint_codec.rs` covering binary and JSON round-trip plus wrong-class payload rejection.

### Add one narrow checkpoint store facade and persistence layout

Objective:

**📌 Introduce one explicit storage-owned checkpoint facade that keeps drafts, finals, links, execution inputs, and audit wrappers on separate persistence surfaces.**

Target Files And Structures:

- proposed: `crates/z00z_storage/src/checkpoint/store.rs`
- proposed: `crates/z00z_storage/src/checkpoint/link.rs`
- proposed: `crates/z00z_storage/src/checkpoint/exec_input.rs`
- proposed: `crates/z00z_storage/src/checkpoint/audit.rs`
- proposed: `crates/z00z_storage/tests/checkpoint_store_api.rs`
- existing abstraction source: `z00z_utils::io`

Implementation Steps:

- Add one narrow `CheckpointStore`-style facade with explicit save and load operations for drafts, finals, links, and execution inputs.
- Keep link persistence separate from final artifact persistence.
- Keep execution-input persistence separate from both draft and final artifact persistence.
- Define wrong-class loader behavior so draft loaders reject finals and final loaders reject drafts.
- Recompute ids from canonical bytes on load and reject backend key mismatches before replay or verification begins.
- Keep any audit wrapper on a separate path that cannot be mistaken for a consensus-facing artifact.

Invariants And Constraints:

- canonical storage code must use `z00z_utils::io` abstractions instead of direct `std::fs`
- no artifact class may be inferred from filename or payload shape alone
- `CheckpointLink` must be the only canonical place where `checkpoint_id`, `prep_snapshot_id`, and `exec_input_id` are paired

Validation Strategy:

- add tests for wrong-class loads, incomplete links, id drift after re-encode, and backend key mismatch
- add one loader test that rejects wrapper-shaped content even if field names look familiar
- add one review pass confirming that audit wrappers cannot affect canonical artifact bytes
- keep single-module helper behavior in local unit tests where possible
- add storage integration coverage in proposed `crates/z00z_storage/tests/checkpoint_store_api.rs` for save-load separation, wrong-class loaders, incomplete links, and backend-key mismatch rejection

Dependencies:

- requires the codec boundary from the previous unit

Completion Criteria:

**📌 This unit is complete only when one storage-owned checkpoint facade exists and callers cannot confuse drafts, finals, links, and execution inputs through one generic API.**

**✔️ Implementation Checklist:**

- [x] Create `crates/z00z_storage/src/checkpoint/store.rs` with an explicit checkpoint facade.
- [x] Create `crates/z00z_storage/src/checkpoint/link.rs` for canonical link records.
- [x] Create `crates/z00z_storage/src/checkpoint/exec_input.rs` for replay input records.
- [x] Create `crates/z00z_storage/src/checkpoint/audit.rs` as the storage-owned home for persistent audit wrappers.
- [x] Define save and load operations that keep drafts, finals, links, and exec inputs separate.
- [x] Recompute ids from canonical bytes on load and reject backend key mismatches.
- [x] Reject draft payloads through final loaders and final payloads through draft or replay-only loaders.
- [x] Use `z00z_utils::io` for persistence code inside the checkpoint module.
- [x] Add proposed integration tests in `crates/z00z_storage/tests/checkpoint_store_api.rs` for draft-final loader separation, incomplete links, wrapper-shaped payload rejection, and backend-key mismatch rejection.

## ⚙️ Phase 4. Build Canonical Drafts From Validated Snapshot And Execution Input

### Add the canonical execution-input record and linkage checks

Objective:

**📌 Define the replay input that checkpoint storage actually requires, then force draft construction to start from validated snapshot plus validated execution input instead of Stage 6 local wrapper state.**

Target Files And Structures:

- proposed: `crates/z00z_storage/src/checkpoint/exec_input.rs`
- proposed: `crates/z00z_storage/src/checkpoint/link.rs`
- proposed: `crates/z00z_storage/src/checkpoint/store.rs`
- proposed: `crates/z00z_storage/tests/checkpoint_replay_inputs.rs`
- existing upstream dependency: `crates/z00z_storage/src/snapshot/store.rs`

Implementation Steps:

- Define `CheckpointExecInput` as the ordered execution input required to rebuild one checkpoint draft from snapshot state.
- Reuse `PrepSnapshotStore::replay_entries(...)` as the existing replay-entry boundary and forbid a second replay-entry abstraction unless the snapshot contract itself changes.
- Cross-check `prep_snapshot_id`, execution-input identity, and declared `prev_root` before any apply logic begins.
- Persist one field-source inventory that states whether each canonical checkpoint field comes from validated snapshot state, typed apply output, or the later proof layer.
- Explicitly list forbidden field sources such as filenames, row numbers, report caches, fragment ids, and Stage 6 wrapper-only values.

Invariants And Constraints:

- replay linkage must not rely on `prep_snapshot_id` alone
- execution input must preserve order, because the current typed apply path is order-sensitive
- root agreement must be established before any state mutation or proof work begins

Validation Strategy:

- add one negative test for snapshot-id mismatch
- add one negative test for exec-input-id mismatch
- add one negative test for `prev_root` mismatch between snapshot and execution input
- add one positive test showing that identical snapshot plus identical execution input yields identical draft bytes
- keep pure field-shape rules in local unit tests for `CheckpointExecInput`
- add storage integration tests in proposed `crates/z00z_storage/tests/checkpoint_replay_inputs.rs` for snapshot-id mismatch, exec-input-id mismatch, root mismatch, and deterministic replay input loading

Dependencies:

- requires Phase 3 storage facade and link model

Completion Criteria:

**📌 This unit is complete only when draft construction has one canonical input triple: validated snapshot, validated execution input, and validated link agreement.**

Recorded Canonical Field Source Inventory:

| Canonical checkpoint field | Source of truth | Notes |
| --- | --- | --- |
| `CheckpointDraft.height` | typed wallet apply output | copied from the one-pass apply result used to build the draft |
| `CheckpointDraft.prev_root` | validated snapshot plus validated exec input agreement | `check_exec_root(...)` and link agreement must succeed before apply |
| `CheckpointDraft.new_root` | typed wallet apply output | derived only from `apply_batch_checkpoint(...)` |
| `CheckpointDraft.spent_delta` | typed wallet apply output | order preserved exactly as emitted by wallet apply |
| `CheckpointDraft.created_delta` | typed wallet apply output | order preserved exactly as emitted by wallet apply |
| `CreatedEnt.leaf_hash` | canonical typed state leaf rule | rebuilt from the same leaf-hash rule used by the typed state layer |
| `CheckpointLink.prep_snapshot_id` | validated snapshot identity | cross-checked against the exec input before apply |
| `CheckpointLink.exec_input_id` | canonical execution-input bytes | derived from canonical binary bytes rather than transport metadata |
| `CheckpointArtifact.cp_proof` | later proof layer only | remains absent from Phase 4 drafts |

Recorded Forbidden Field Sources:

- filenames
- row numbers
- report caches
- Stage 6 wrapper-only values
- `fragment_ids`
- simulator-local traces
- transport wrapper metadata
- placeholder bytes derived from `pkg.tx_digest_hex`

**✔️ Implementation Checklist:**

- [x] Define `CheckpointExecInput` in `crates/z00z_storage/src/checkpoint/exec_input.rs`.
- [x] Define the exact fields required for ordered replay and draft construction.
- [x] Cross-check `prep_snapshot_id`, `exec_input_id`, and `prev_root` before apply begins.
- [x] Record one source-of-truth inventory for all canonical checkpoint fields.
- [x] Record the explicit forbidden sources list for filenames, report caches, wrapper traces, and fragment ids.
- [x] Add positive and negative validation cases for snapshot mismatch, exec-input mismatch, and root mismatch.
- [x] Add proposed integration tests in `crates/z00z_storage/tests/checkpoint_replay_inputs.rs` for snapshot-id mismatch, exec-input-id mismatch, and `prev_root` mismatch.

### Route draft building through the existing wallet apply path once

Objective:

**📌 Evolve the existing `prepare_tx_sum(...)` plus `apply_batch_checkpoint(...)` path into the canonical draft builder instead of creating a second simulator-only apply path.**

Target Files And Structures:

- existing anchor: `crates/z00z_wallets/src/core/tx/state_update.rs`
- existing adapter anchor: `crates/z00z_simulator/src/scenario_1/stage_6.rs`
- proposed: `crates/z00z_storage/src/checkpoint/store.rs`
- proposed: `crates/z00z_storage/tests/checkpoint_root_binding.rs`
- proposed: `crates/z00z_storage/tests/checkpoint_leaf_hash.rs`
- proposed: `crates/z00z_storage/tests/checkpoint_draft_build.rs`

Implementation Steps:

- Load replay-ready resolved inputs from the snapshot-owned replay boundary produced by `PrepSnapshotStore::replay_entries(...)`.
- Build the typed `TxPkgSum` through `prepare_tx_sum(...)`.
- Apply the batch exactly once through `apply_batch_checkpoint(...)`.
- Convert the wallet checkpoint output into `CheckpointDraft` immediately after apply.
- Capture `spent_delta`, `created_delta`, and `new_root` from that one apply result only.
- Compute `CreatedEnt.leaf_hash` from the same canonical leaf-hash rule used by the typed state layer.
- Preserve delta order exactly and reject any code path that sorts deltas after apply.

Invariants And Constraints:

- no second simulator-only checkpoint apply path may be introduced
- duplicate `asset_id` values in either delta must remain rejectable
- any `definition_id` substitution where terminal `asset_id` is required must fail before proof verification or replay comparison begins

Validation Strategy:

- keep the wrong-root and spent-gate tests green
- add one canonical-draft determinism test using identical snapshot and execution input
- add one negative test for duplicate delta ids
- add one negative test for wrong leaf hash or `definition_id` substitution
- add storage integration tests in proposed `crates/z00z_storage/tests/checkpoint_draft_build.rs` for one-pass draft construction and deterministic draft bytes
- add focused integration tests in proposed `crates/z00z_storage/tests/checkpoint_root_binding.rs` and `crates/z00z_storage/tests/checkpoint_leaf_hash.rs` for root binding and canonical leaf-hash consistency

Dependencies:

- requires the execution-input contract from the previous unit

Completion Criteria:

**📌 This unit is complete only when one storage-owned draft builder uses the existing wallet apply contract once, preserves delta order, and emits a proofless `CheckpointDraft` rather than a pseudo-final artifact.**

📌 Recorded Ownership Resolution:

- the canonical `build_cp_draft(...)` entrypoint now lives on the storage boundary under `crates/z00z_storage/src/checkpoint/build.rs` and is re-exported from `crates/z00z_storage/src/checkpoint/mod.rs`
- `crates/z00z_wallets/src/core/tx/state_update.rs` keeps a compatibility wrapper so existing wallet callers continue to work without owning the canonical implementation
- storage tests and the Stage 6 simulator path now call the storage boundary directly, so draft construction ownership matches the completion criteria without introducing a crate cycle

**✔️ Implementation Checklist:**

- [x] Keep the canonical draft-build entrypoint on a storage-owned checkpoint boundary instead of exporting it only from `z00z_wallets`.
- [x] Load replay-ready resolved inputs from the snapshot-owned boundary rather than Stage 6 local wrapper state.
- [x] Build `TxPkgSum` through `prepare_tx_sum(...)`.
- [x] Apply the batch through `apply_batch_checkpoint(...)` exactly once.
- [x] Convert the typed wallet checkpoint output into `CheckpointDraft` immediately after apply.
- [x] Preserve `spent_delta` and `created_delta` order exactly as emitted by the apply result.
- [x] Validate duplicate-id rejection and forbid `definition_id` substitution where terminal `asset_id` is required.
- [x] Add one determinism test for identical snapshot plus identical execution input.
- [x] Keep the existing wrong-root and spent-path regression tests passing through the migration.
- [x] Add proposed integration tests in `crates/z00z_storage/tests/checkpoint_draft_build.rs` for one-pass canonical draft building and duplicate-id rejection.
- [x] Add proposed integration tests in `crates/z00z_storage/tests/checkpoint_root_binding.rs` and `crates/z00z_storage/tests/checkpoint_leaf_hash.rs` for root-binding and leaf-hash invariants.

## ⚙️ Phase 5. Finalize Checkpoint Artifacts, Proof Boundary, And External Identities

### Add explicit finalization from draft to final artifact

Objective:

**📌 Upgrade proofless drafts into final checkpoint artifacts only through one explicit finalization step that attaches non-empty proof bytes without mutating semantic checkpoint fields.**

Target Files And Structures:

- proposed: `crates/z00z_storage/src/checkpoint/artifact.rs`
- proposed: `crates/z00z_storage/src/checkpoint/store.rs`
- existing semantic source: `crates/z00z_wallets/src/core/tx/state_update.rs`
- proposed: `crates/z00z_storage/tests/checkpoint_finalization.rs`

Implementation Steps:

- Use the resolved explicit proof-system discriminator from Decision 2 before wiring proof verification behavior.
- Reconstruct `CheckpointPubIn` from the draft fields at finalization time.
- Attach proof bytes only through one explicit finalization function.
- Preserve `height`, `prev_root`, `new_root`, `spent_delta`, and `created_delta` byte-for-byte from the draft.
- Persist the proof-system discriminator in the final artifact and require verification to check it before selecting the proof verifier branch.
- Reject empty proof bytes before final artifact construction.
- Reject any path that tries to derive final `cp_proof` bytes from `tx_digest_hex` or from the Stage 6 placeholder `tx_proof` shim used during draft construction.

Invariants And Constraints:

- finalization must not mutate checkpoint semantics
- proof bytes must be carried in a dedicated type for final artifacts only
- proof-system identity must be explicit in the final artifact rather than implicit in artifact version alone
- proof verification inputs must come from typed artifact fields, not from caller-supplied parallel structures

Validation Strategy:

- add one negative test for empty final proof bytes
- add one negative test for field tampering between draft and final artifact
- add one positive test proving identical draft plus identical proof yields identical final bytes
- add one negative test proving two different proofs over the same draft produce different final bytes and different `CheckpointId` values
- keep finalization helper invariants in local unit tests where possible
- add storage integration tests in proposed `crates/z00z_storage/tests/checkpoint_finalization.rs` for empty-proof rejection, tampering rejection, deterministic finalization, and proof differentiation

Dependencies:

- requires the draft builder from Phase 4

Completion Criteria:

**📌 This unit is complete only when proofless outputs remain drafts and every final artifact must pass through one non-empty proof attachment step.**

Recorded Phase 5 Proof Identity Contract:

- `crates/z00z_storage/src/checkpoint/artifact.rs` now defines storage-owned `CheckpointPubIn`, `CheckpointProofSys`, and `CheckpointProof`
- the resolved proof-identity contract is an explicit `CheckpointProofSys` discriminator persisted inside `CheckpointArtifact` instead of inferring proof identity from `CheckpointVer`
- `CheckpointDraft::finalize(...)` is the explicit finalization step from proofless `CheckpointDraft` to final `CheckpointArtifact`
- finalization reconstructs `CheckpointPubIn` from draft fields and rejects any proof payload whose typed public inputs diverge from the draft boundary
- finalization preserves `height`, `prev_root`, `new_root`, `spent_delta`, and `created_delta` byte-for-byte from the draft and attaches proof bytes only through `CheckpointProof`
- no storage finalization helper accepts `tx_digest_hex` or the Stage 6 placeholder `tx_proof` shim as a typed source; callers must provide explicit checkpoint proof payloads bound to `CheckpointPubIn`

**✔️ Implementation Checklist:**

- [x] Record the resolved proof-identity contract in this file and require an explicit proof-system discriminator in the final artifact.
- [x] Add one explicit finalization function from `CheckpointDraft` to `CheckpointArtifact`.
- [x] Reconstruct `CheckpointPubIn` from draft fields at finalization time.
- [x] Persist and validate the explicit proof-system discriminator before proof verification dispatch.
- [x] Preserve all non-proof fields byte-for-byte from the draft.
- [x] Reject empty `cp_proof` for final artifact creation.
- [x] Reject any finalization path that derives final `cp_proof` bytes from `tx_digest_hex` or from another placeholder transaction-proof shim.
- [x] Add positive and negative finalization tests for determinism, tampering, and proof differentiation.
- [x] Add proposed integration tests in `crates/z00z_storage/tests/checkpoint_finalization.rs` for empty-proof rejection, finalization determinism, and proof differentiation.

### Persist canonical links after final bytes and ids are fixed

Objective:

**📌 Persist `CheckpointLink` only after canonical final bytes and canonical ids are fixed, so replay linkage is injective and auditable.**

Target Files And Structures:

- proposed: `crates/z00z_storage/src/checkpoint/link.rs`
- proposed: `crates/z00z_storage/src/checkpoint/store.rs`
- proposed: `crates/z00z_storage/src/checkpoint/ids.rs`
- proposed: `crates/z00z_storage/tests/checkpoint_link_injective.rs`

Implementation Steps:

- Derive `CheckpointId` from canonical final artifact bytes only.
- Pair `checkpoint_id`, `prep_snapshot_id`, and `exec_input_id` in one canonical link record.
- Persist the link only after final artifact bytes and both content-addressed ids are fixed.
- Reject incomplete links, duplicate links, and ambiguous reuse of one execution input for conflicting final artifacts.
- Keep link loading and validation separate from artifact loading.

Invariants And Constraints:

- linkage must be injective across `checkpoint_id`, `prep_snapshot_id`, and `exec_input_id`
- link validation must happen before replay or local re-apply claims are made
- final artifact ids and execution-input ids must not be inferred from filenames or local counters

Validation Strategy:

- add one positive link round-trip test
- add one negative test for incomplete link fields
- add one negative test for wrong-link reuse against the same `CheckpointId`
- add one negative test proving two different execution-input bodies cannot both claim the same canonical linkage
- keep pure link-shape and helper checks in local unit tests where they stay single-module
- add storage integration tests in proposed `crates/z00z_storage/tests/checkpoint_link_injective.rs` for link round-trip, incomplete links, wrong-link reuse, and injectivity

Dependencies:

- requires final artifact bytes from the previous unit

Completion Criteria:

**📌 This unit is complete only when canonical linkage is explicit, injective, and persisted after final artifact identity is fixed.**

Recorded Phase 5 Link Contract:

- `CheckpointId` remains derived from canonical final artifact bytes only through `derive_art_id(...)`
- `CheckpointStore::seal_artifact(...)` now finalizes one draft, persists the final artifact, derives the fixed `CheckpointId`, then persists `CheckpointLink`
- `CheckpointFsStore::save_link(...)` rejects links whose referenced final artifact is not already persisted
- `CheckpointFsStore::save_link(...)` rejects conflicting reuse of one `checkpoint_id` or one `exec_input_id`, so linkage stays injective across stored final artifacts

**✔️ Implementation Checklist:**

- [x] Derive `CheckpointId` from final artifact bytes only.
- [x] Pair `checkpoint_id`, `prep_snapshot_id`, and `exec_input_id` in one canonical `CheckpointLink`.
- [x] Persist links only after final artifact bytes and ids are fixed.
- [x] Reject incomplete links and ambiguous link reuse.
- [x] Add positive and negative linkage tests for round-trip, wrong-link reuse, and injectivity.
- [x] Add proposed integration tests in `crates/z00z_storage/tests/checkpoint_link_injective.rs` for incomplete links, wrong-link reuse, and injective linkage.

## ⚙️ Phase 6. Cut Over Simulator Wrappers And Public Storage APIs

### Route Stage 6 through canonical draft storage first and gate final artifacts on proof availability

Objective:

**📌 Move Stage 6 from local checkpoint semantics to canonical storage-owned draft semantics first, and enable final artifact persistence only after the proof producer and Phase 5 finalization path exist. This unit exists to preserve the proofless draft milestone without letting Stage 6 claim final-artifact semantics too early.**

Target Files And Structures:

- existing: `crates/z00z_simulator/src/scenario_1/stage_6.rs`
- proposed: `crates/z00z_storage/src/checkpoint/store.rs`
- proposed: `crates/z00z_storage/src/checkpoint/link.rs`
- proposed: `crates/z00z_storage/src/checkpoint/audit.rs`
- existing baseline anchor: `crates/z00z_simulator/tests/test_stage6_checkpoint.rs`
- proposed: `crates/z00z_simulator/tests/test_stage6_checkpoint_storage_bridge.rs`
- proposed: `crates/z00z_simulator/tests/test_stage6_checkpoint_final_gate.rs`

Implementation Steps:

- Replace direct local checkpoint construction with calls into the storage-owned draft builder.
- Gate any Stage 6 final-artifact persistence behind the availability of the Phase 5 proof producer and the explicit finalization path.
- Move persistent audit-only fields such as `fragment_ids` into a storage-owned audit wrapper in `crates/z00z_storage/src/checkpoint/audit.rs`, and keep only transient report rendering local to Stage 6.
- Remove any code path that claims final checkpoint semantics while still omitting `height` or final `cp_proof` bytes.
- Remove the placeholder `pkg.tx_digest_hex` to `tx_proof` shim from the canonical build path before Stage 6 is allowed to emit final artifacts.
- Keep report rendering and human-readable output separate from canonical checkpoint bytes and checkpoint identities.

Invariants And Constraints:

- Stage 6 may keep transient report fields, but persistent audit-only fields must be stored through `z00z_storage::checkpoint::audit` and must not influence canonical draft bytes, canonical final artifact bytes, or `CheckpointPubIn`
- Stage 6 must not redefine checkpoint semantics locally after canonical storage is introduced
- the cut-over must prefer one canonical path over a prolonged dual-path rollout
- if the proof producer is still unavailable, Stage 6 must persist canonical drafts plus canonical linkage inputs and must not emit a pseudo-final artifact

Validation Strategy:

- keep `test_stage6_checkpoint` green during the migration
- add at least one new Stage 6 integration test that proves canonical storage is now the owner of the draft path
- add one fail-loud test that proves Stage 6 cannot emit a final artifact while the proof producer is unavailable
- add one fail-loud test that proves the placeholder `tx_digest_hex` shim no longer reaches the canonical build path once final artifacts are enabled
- treat the existing `test_stage6_checkpoint` file as the baseline simulator integration suite and keep new cut-over coverage in dedicated simulator integration tests instead of overloading one monolithic regression file

Dependencies:

- requires Phase 4 draft building and linkage
- requires Phase 5 finalization only for the sub-step that enables Stage 6 final-artifact persistence

Completion Criteria:

**📌 This unit is complete only when Stage 6 uses canonical storage for checkpoint draft semantics, keeps only audit or report data locally, and cannot claim final-artifact emission before the proof path exists.**

**✔️ Implementation Checklist:**

- [x] Replace local Stage 6 checkpoint construction with storage-owned draft-builder calls.
- [x] Gate Stage 6 final-artifact persistence on the availability of the Phase 5 proof producer and finalization path.
- [x] Move persistent `fragment_ids` handling into `crates/z00z_storage/src/checkpoint/audit.rs` and keep it outside canonical checkpoint bytes.
- [x] Remove the placeholder `pkg.tx_digest_hex` to `tx_proof` shim from the canonical build path before allowing Stage 6 final-artifact emission.
- [x] Preserve Stage 6 report output without letting report fields affect canonical artifact bytes.
- [x] Add one Stage 6 integration test proving the storage-owned draft path is active.
- [x] Add one fail-loud Stage 6 test proving draft-only mode cannot be mistaken for final-artifact mode.
- [x] Add one fail-loud Stage 6 test for placeholder shim removal once final artifacts are enabled.
- [x] Keep existing assertions in `crates/z00z_simulator/tests/test_stage6_checkpoint.rs` green as the baseline simulator regression suite.
- [x] Add proposed `crates/z00z_simulator/tests/test_stage6_checkpoint_storage_bridge.rs` for the storage-owned draft-path cut-over.
- [x] Add proposed `crates/z00z_simulator/tests/test_stage6_checkpoint_final_gate.rs` for proof-availability gating and placeholder-shim removal.

### Expose only canonical public APIs from storage

Objective:

**📌 Finalize the public storage API so cross-crate callers can use canonical checkpoint types without importing simulator wrappers or audit-only records.**

Target Files And Structures:

- existing: `crates/z00z_storage/src/lib.rs`
- proposed: `crates/z00z_storage/src/checkpoint/mod.rs`
- proposed: `crates/z00z_storage/src/checkpoint/audit.rs`

Implementation Steps:

- Re-export only the typed checkpoint contracts that cross-crate callers genuinely need.
- Keep storage-owned audit modules private or narrowly scoped so they do not leak into consensus-facing APIs.
- Remove or forbid any public path that accepts filename-derived identities, row-based linkage, or wrapper-local checkpoint meaning.
- Document which module is consensus-facing, which is replay-facing, and which is audit-only.

Invariants And Constraints:

- canonical checkpoint modules must not import simulator-only wrapper structs directly
- public APIs must expose root source-of-truth expectations explicitly
- helper modules should remain `pub(crate)` where possible

Validation Strategy:

- review the final `lib.rs` surface for simulator leakage
- add one compile-level or review-level check that no public API depends on Stage 6 wrapper types
- add one negative test or lint-style review item for filename-derived identity acceptance

Dependencies:

- requires the Stage 6 cut-over unit

Completion Criteria:

**📌 This unit is complete only when `z00z_storage` exposes canonical checkpoint contracts and no simulator wrapper semantics leak through the public facade.**

Recorded Phase 6 Public API Contract:

- `crates/z00z_storage/src/checkpoint/mod.rs` now documents the main checkpoint facade as the consensus-facing surface for drafts, final artifacts, ids, typed execution inputs, links, and the store contract
- audit-only records remain available through the narrower `z00z_storage::checkpoint::audit` module instead of the broad checkpoint prelude so wrapper-local `fragment_ids` do not leak into the default canonical API
- the public checkpoint store surface accepts typed ids (`CheckpointId`, `CheckpointDraftId`, `CheckpointExecInputId`, `PrepSnapshotId`) rather than filename-derived or row-derived checkpoint identity
- no public checkpoint API imports simulator-local Stage 6 wrapper structs

**✔️ Implementation Checklist:**

- [x] Re-export only canonical checkpoint contracts from `crates/z00z_storage/src/lib.rs`.
- [x] Keep storage-owned audit-only modules private unless one narrower public audit facade is explicitly justified.
- [x] Remove or forbid public APIs that accept filename-derived or row-derived checkpoint identity.
- [x] Document module roles as consensus-facing, replay-facing, or audit-only.
- [x] Verify that no public checkpoint API imports simulator-local wrapper structs.

## ⚙️ Phase 7. Land The Test Matrix, Rollout Gates, And Acceptance Record

### Add the checkpoint storage test matrix

Objective:

**📌 Turn the canonical checkpoint rollout into code-enforced invariants by adding a stable positive-and-negative test matrix that tracks artifact class, root identity, proof boundaries, linkage, and replay separation.**

Target Files And Structures:

- proposed: `crates/z00z_storage/tests/checkpoint_draft_final.rs`
- proposed: `crates/z00z_storage/tests/checkpoint_root_binding.rs`
- proposed: `crates/z00z_storage/tests/checkpoint_leaf_hash.rs`
- proposed: `crates/z00z_storage/tests/checkpoint_link_injective.rs`
- proposed: `crates/z00z_storage/tests/checkpoint_replay_inputs.rs`
- proposed: `crates/z00z_storage/tests/checkpoint_ids.rs`
- proposed: `crates/z00z_storage/tests/checkpoint_codec.rs`
- proposed: `crates/z00z_storage/tests/checkpoint_store_api.rs`
- proposed: `crates/z00z_storage/tests/checkpoint_draft_build.rs`
- proposed: `crates/z00z_storage/tests/checkpoint_finalization.rs`
- proposed shared fixtures: `crates/z00z_storage/tests/checkpoint/fixtures.rs`
- existing: `crates/z00z_wallets/tests/test_tx_wrong_root.rs`
- existing: `crates/z00z_wallets/tests/test_tx_spent_gate.rs`
- existing: `crates/z00z_simulator/tests/test_stage6_checkpoint.rs`
- proposed: `crates/z00z_simulator/tests/test_stage6_checkpoint_storage_bridge.rs`
- proposed: `crates/z00z_simulator/tests/test_stage6_checkpoint_final_gate.rs`

Implementation Steps:

- Group the checkpoint invariants into explicit buckets with at least one positive and one negative case per bucket.
- Split new checkpoint coverage explicitly into unit, storage integration, and simulator integration or e2e groups so the rollout does not rely on one test layer only.
- Add fixture coverage for draft-versus-final separation, root consistency, terminal asset identity, created leaf-hash consistency, linkage injectivity, replay-input necessity, artifact-id stability, proof verification boundary, audit-wrapper boundary, transport pre-validation boundary, blocker-enforcement regressions, and migration fail-loud behavior.
- Add one regression fixture derived from the current Stage 6 wrapper and prove canonical loaders reject it until adapters normalize the missing semantics.
- Add one deterministic finalization test showing that identical draft plus identical proof bytes yields identical final bytes and identical `CheckpointId`.
- Add one replay test proving proof verification can succeed while local replay still fails when ordered execution input is missing.
- Add one migration test proving Stage 6 draft-only mode remains explicit until the proof producer is available.

Invariants And Constraints:

- every bucket must include at least one negative case
- CI tracking must remain stable enough that new invariants extend the matrix instead of replacing earlier rows
- wrong-class, wrong-root, wrong-link, and proofless-final behavior must remain distinct rejection classes

Validation Strategy:

- run storage, wallet, and simulator tests together at the end of the phase
- record which tests close which invariant bucket
- treat any invariant without a direct test row as an incomplete rollout
- require one named owner file for each unit-test bucket, one named owner file for each storage integration bucket, and one named owner file for each simulator cut-over or e2e bucket

Dependencies:

- requires Phases 2 through 6 to define the canonical model

Completion Criteria:

**📌 This unit is complete only when the checkpoint rollout is enforceable by executable tests rather than by planning prose.**

Recorded Phase 7 Test Matrix:

| Invariant bucket | Positive owner | Negative owner |
| --- | --- | --- |
| draft-versus-final separation | `crates/z00z_storage/tests/checkpoint_draft_final.rs::draft_and_final_stay_distinct` | `crates/z00z_storage/tests/checkpoint_draft_final.rs::draft_persist_rejects_final_load`, `final_persist_rejects_draft_load`, `proofless_final_rejects` |
| root consistency and baseline root gate | `crates/z00z_storage/tests/checkpoint_root_binding.rs` via successful build path in `checkpoint_draft_build.rs::one_pass_draft_is_deterministic` | `crates/z00z_storage/tests/checkpoint_root_binding.rs::prev_root_bind_rejects`, `crates/z00z_wallets/tests/test_tx_wrong_root.rs` |
| terminal asset identity and duplicate-id rejection | `crates/z00z_storage/tests/checkpoint_draft_build.rs::one_pass_draft_is_deterministic` | `crates/z00z_storage/tests/checkpoint_draft_build.rs::dup_out_rejects` |
| created leaf-hash consistency | `crates/z00z_storage/tests/checkpoint_leaf_hash.rs::leaf_hash_changes_with_leaf` | `crates/z00z_storage/tests/checkpoint_draft_build.rs::dup_out_rejects` keeps wrong output shape rejectable before any proof path |
| linkage injectivity | `crates/z00z_storage/tests/checkpoint_link_injective.rs::seal_artifact_persists_roundtrip_link` | `crates/z00z_storage/tests/checkpoint_link_injective.rs::conflicting_checkpoint_link_rejects`, `conflicting_exec_reuse_rejects` |
| replay-input necessity and replay separation | `crates/z00z_storage/tests/checkpoint_replay_inputs.rs` with matching snapshot plus exec ids | `crates/z00z_storage/tests/checkpoint_replay_inputs.rs::snap_id_mismatch_rejects`, `exec_id_mismatch_rejects`, `prev_root_mismatch_rejects`, `crates/z00z_storage/tests/checkpoint_store_api.rs::proof_ok_without_exec_replay` |
| artifact-id stability | `crates/z00z_storage/tests/checkpoint_ids.rs::art_id_is_stable_for_same_bytes` | `crates/z00z_storage/tests/checkpoint_ids.rs::draft_wrong_class_rejects_art_id`, `unsupported_version_rejects_art_id`, `backend_key_mismatch_is_precise` |
| proof boundary and finalization determinism | `crates/z00z_storage/tests/checkpoint_finalization.rs::finalization_is_deterministic` | `crates/z00z_storage/tests/checkpoint_finalization.rs::empty_proof_rejects`, `tampered_pub_in_rejects`, `proof_difference_changes_final_id` |
| transport pre-validation and legacy wrapper rejection | `crates/z00z_storage/tests/checkpoint_codec.rs::json_roundtrip_keeps_types`, `bin_roundtrip_keeps_types` | `crates/z00z_storage/tests/checkpoint_codec.rs::malformed_transport_rejects`, `wrong_class_payload_rejects`, `legacy_stage6_wrapper_rejects` |
| audit-wrapper boundary | `crates/z00z_storage/tests/checkpoint_store_api.rs::file_store_keeps_surfaces_separate` | `crates/z00z_storage/tests/checkpoint_store_api.rs::wrapper_shaped_payload_rejects`, `crates/z00z_simulator/tests/test_stage6_checkpoint_final_gate.rs::opaque_final_mode_ignores_tx_digest_placeholder` |
| Stage 6 draft-only migration gate | `crates/z00z_simulator/tests/test_stage6_checkpoint_storage_bridge.rs::stage6_uses_storage_owned_draft_path` | `crates/z00z_simulator/tests/test_stage6_checkpoint_storage_bridge.rs::stage6_keeps_final_surfaces_off_in_draft_only_mode`, `crates/z00z_simulator/tests/test_stage6_checkpoint_final_gate.rs::draft_only_mode_cannot_emit_final_artifact`, `draft_only_failure_text_stays_proof_gate_not_tx_digest` |

Recorded Phase 7 Shared Fixtures:

- `crates/z00z_storage/tests/checkpoint/fixtures.rs` is now the shared integration-test fixture source for canonical draft, final artifact, execution input, link, audit, and legacy Stage 6 wrapper payloads
- `crates/z00z_storage/tests/checkpoint_codec.rs` and `crates/z00z_storage/tests/checkpoint_store_api.rs` now consume the shared fixture module instead of duplicating local builders

Recorded Phase 7 Blocker-to-Test Mapping:

- proofless wallet output remains fail-loud through `crates/z00z_storage/tests/checkpoint_draft_final.rs::proofless_final_rejects`
- placeholder `pkg.tx_digest_hex` shim removal remains fail-loud through `crates/z00z_simulator/tests/test_stage6_checkpoint_final_gate.rs::opaque_final_mode_ignores_tx_digest_placeholder` and `draft_only_failure_text_stays_proof_gate_not_tx_digest`
- `fragment_ids` stay audit-only through `crates/z00z_storage/tests/checkpoint_store_api.rs::wrapper_shaped_payload_rejects` and `crates/z00z_simulator/tests/test_stage6_checkpoint_final_gate.rs::opaque_final_mode_ignores_tx_digest_placeholder`
- missing external identities and missing canonical replay linkage remain fail-loud through `crates/z00z_storage/tests/checkpoint_ids.rs`, `checkpoint_link_injective.rs`, and `checkpoint_store_api.rs::proof_ok_without_exec_replay`

**✔️ Implementation Checklist:**

- [x] Create storage tests for draft-final separation, root binding, leaf-hash consistency, linkage injectivity, replay-input necessity, and id stability.
- [x] Create unit tests next to new checkpoint modules for pure artifact, id, codec, and finalization rules that do not require persistence or scenario execution.
- [x] Create shared fixtures in proposed `crates/z00z_storage/tests/checkpoint/fixtures.rs` so positive and negative storage tests reuse one canonical draft, final artifact, link, and execution-input fixture set.
- [x] Add positive and negative cases for each required invariant bucket.
- [x] Add one regression fixture derived from the current Stage 6 wrapper and prove canonical loaders reject it until adapters normalize the wrapper.
- [x] Add one determinism test for identical draft plus identical proof bytes.
- [x] Add one replay test proving proof verification and local replay remain separate concerns.
- [x] Add one migration test proving Stage 6 draft-only mode remains explicit until the proof producer is available.
- [x] Map each Phase 1 blocker row to at least one fail-loud regression test.
- [x] Keep the existing wallet and simulator regression tests active in the final gate.
- [x] Add proposed simulator integration tests in `crates/z00z_simulator/tests/test_stage6_checkpoint_storage_bridge.rs` and `crates/z00z_simulator/tests/test_stage6_checkpoint_final_gate.rs` so Stage 6 cut-over and final-artifact gating are covered beyond the legacy wrapper suite.

### Write the rollout sign-off record and unresolved-decision report

Objective:

**📌 Close the workflow with one auditable acceptance record that names the landed files, the invariant buckets, and any remaining open decisions that do not block correctness.**

Target Files And Structures:

- `specs/014-z00z-storage/checkpoint-storage-plan.md`
- proposed completion record section in the final implementation PR or rollout document

Implementation Steps:

- Record which file introduced canonical draft and final checkpoint types.
- Record which file introduced finalization and `CheckpointId` derivation.
- Record which file introduced canonical linkage and replay-input helpers.
- Record which tests close each invariant bucket.
- Record which Stage 6 wrapper fields were removed and which were kept as audit-only data.
- Record which open decisions remain unresolved and why they do not block correctness.

Invariants And Constraints:

- unresolved decisions must be explicit, not silently deferred
- acceptance must name exact files, exact tests, and exact commit or tag
- no open compliance gate for root identity, terminal asset identity, proof bytes, or replay separation may remain hidden in prose

Validation Strategy:

- review the final acceptance record against the Phase 1 blocker table and the Phase 7 test matrix
- reject sign-off if any claimed invariant cannot be traced to code or tests

Dependencies:

- requires the test matrix from the previous unit

Completion Criteria:

**📌 This unit is complete only when the rollout can be audited from files, tests, and one exact acceptance reference instead of from memory or review comments.**

Recorded Phase 7 Acceptance Record:

- canonical draft and final checkpoint types were introduced in `crates/z00z_storage/src/checkpoint/artifact.rs`
- finalization and `CheckpointId` derivation were introduced in `crates/z00z_storage/src/checkpoint/artifact.rs` and `crates/z00z_storage/src/checkpoint/ids.rs`
- canonical linkage and replay-input helpers were introduced in `crates/z00z_storage/src/checkpoint/link.rs`, `crates/z00z_storage/src/checkpoint/exec_input.rs`, and `crates/z00z_storage/src/checkpoint/store.rs`
- the executable acceptance matrix is owned by `crates/z00z_storage/tests/checkpoint_draft_final.rs`, `checkpoint_root_binding.rs`, `checkpoint_leaf_hash.rs`, `checkpoint_link_injective.rs`, `checkpoint_replay_inputs.rs`, `checkpoint_ids.rs`, `checkpoint_codec.rs`, `checkpoint_store_api.rs`, `checkpoint_draft_build.rs`, `checkpoint_finalization.rs`, `crates/z00z_wallets/tests/test_tx_wrong_root.rs`, `crates/z00z_wallets/tests/test_tx_spent_gate.rs`, `crates/z00z_simulator/tests/test_stage6_checkpoint.rs`, `test_stage6_checkpoint_storage_bridge.rs`, and `test_stage6_checkpoint_final_gate.rs`
- Stage 6 wrapper fields removed from canonical bytes are `prev_root_hex`, `new_root_hex`, `spent_delta`, `created_delta`, and `fragment_ids` as transport names or wrapper-local semantics; the typed root and delta semantics remain canonical through storage types, while `fragment_ids` moved into `crates/z00z_storage/src/checkpoint/audit.rs` and report rendering remains local to Stage 6
- no open ownership gap remains: the canonical `build_cp_draft(...)` entrypoint is storage-owned, while the wallet module only keeps a compatibility wrapper over the same implementation
- checkpoint storage rollout acceptance was committed on branch `z00z-simul` at commit `f58e98d99c598e1ccff017b20acdf88bd3cf8e6d` and tagged as `v1.743.0` via `./scripts/version-manager.sh`
- the current working tree additionally includes the Phase 4 storage-owned draft-builder ownership alignment; if this delta is kept, the recorded acceptance reference should be refreshed in the next explicit repository workflow

**✔️ Implementation Checklist:**

- [x] Record the file that introduced canonical draft and final checkpoint types.
- [x] Record the file that introduced finalization and `CheckpointId` derivation.
- [x] Record the file that introduced canonical linkage and replay-input helpers.
- [x] Record the tests that close each invariant bucket.
- [x] Record which Stage 6 wrapper fields were removed, which remained local, and which moved into audit-only scope.
- [x] Record any remaining open decisions explicitly and explain why they do not block correctness.
- [x] Record the exact commit or tag where checkpoint storage invariants were accepted.

## 🔔 Final Validation Gate

```bash
cargo test -p z00z_storage --tests
cargo test -p z00z_wallets --features test-fast test_tx_wrong_root -- --nocapture
cargo test -p z00z_wallets --features test-fast test_tx_spent_gate -- --nocapture
cargo test -p z00z_simulator --features test-fast test_stage6_checkpoint -- --nocapture
```

**🔔 The rollout is complete only when all of the following are true:**

- canonical `CheckpointDraft`, `CheckpointArtifact`, `CheckpointLink`, and `CheckpointExecInput` types exist in `z00z_storage`
- one canonical storage facade distinguishes drafts, finals, links, and execution inputs explicitly
- no final-artifact path accepts empty `cp_proof`
- no final-artifact path derives `cp_proof` bytes from `tx_digest_hex` or from the Stage 6 placeholder `tx_proof` shim
- `CheckpointId` and `CheckpointExecInputId` are stable across canonical round-trip serialization and remain external to payloads
- proof verification reconstructs `CheckpointPubIn` from artifact fields rather than from caller-supplied parallel inputs
- local replay stays separate from consensus proof verification and still requires ordered execution input
- artifact schema version, checkpoint height, and JMT progression remain distinct concepts
- no non-canonical wrapper field remains reachable from canonical public APIs

## 🚫 Non-Goals

- do not redesign snapshot semantics inside checkpoint storage work
- do not collapse snapshot, replay input, and checkpoint result into one artifact class
- do not treat simulator filenames or stage-local counters as durable checkpoint identities
- do not add audit metadata to canonical checkpoint payloads without an explicit spec update
- do not mix checkpoint correctness work with unrelated simulator reporting polish

## ✅ Planning Notes

**📌 Mermaid diagrams were added to lock the execution order and data flow.**

**📌 The previously open decisions are now resolved in this plan: dual JSON plus binary from day one, an explicit proof-system discriminator in final artifacts, and storage-owned audit wrappers in `z00z_storage`. Any later deviation must be treated as a spec change, not as an implementation choice.**
