# TODO: What Blocks 100% Completion of 4_Asset_Model.md

📌 This document tracks objective blockers that currently prevent formal 100% completion of specs/009-z00z-ecc-spec-4/4_Asset_Model.md.

## Current Status

✅ Completed checklist items: 928

⚠️ Open checklist items: 136





**Что мешает закрыть 100%**

- В спецификации много пунктов помечены как PROPOSED/FUTURE/DO NOT IMPLEMENT, их нельзя безопасно внедрять без отдельного архитектурного решения (например, миграции SerialId/LeafAd/EncryptedPack): [4_Asset_Model.md:1172-1178](vscode-file://vscode-app/usr/share/code/resources/app/out/vs/code/electron-browser/workbench/workbench.html), [4_Asset_Model.md:7655-7663](vscode-file://vscode-app/usr/share/code/resources/app/out/vs/code/electron-browser/workbench/workbench.html).
- Есть зависимость от OWF/circuit ветки и будущей Poseidon2-AEAD миграции, это межкомандный/межмодульный этап, не локальный фикс: [4_Asset_Model.md:5095-5103](vscode-file://vscode-app/usr/share/code/resources/app/out/vs/code/electron-browser/workbench/workbench.html), [4_Asset_Model.md:5303-5317](vscode-file://vscode-app/usr/share/code/resources/app/out/vs/code/electron-browser/workbench/workbench.html).
- Часть открытых пунктов — governance/CI требования, а не прямой код в wallet (например fuzz budget, глобальная уникальность label-ов): [4_Asset_Model.md:3371](vscode-file://vscode-app/usr/share/code/resources/app/out/vs/code/electron-browser/workbench/workbench.html), [4_Asset_Model.md:4317-4325](vscode-file://vscode-app/usr/share/code/resources/app/out/vs/code/electron-browser/workbench/workbench.html).
- `secret_tag` больше не рассматривается как альтернативный JMT key; публичный state/proof path закреплён за `asset_id`, а открытые пункты относятся к circuit/AEAD и process-гейтам.
- Дополнительно: в самом spec много markdown-диагностик, это шум качества документа, но не блокер крипто-корректности кода.

**Ответ кратко**

- Да, блокировки есть.
- Полное закрытие возможно только после явного одобрения PROPOSED-миграций и выполнения зависимых circuit/OWF этапов.
- Текущий кодовый стек закрывает исполнимую “реальную” часть, но не все стратегические пункты спецификации.



## Blocker Groups

### 1) PROPOSED/FUTURE API Migrations (Not Approved Yet)

🚫 Several open items explicitly describe future APIs and are marked as PROPOSED, DO NOT IMPLEMENT, or FUTURE. Implementing them now would violate current architecture constraints and compatibility assumptions.

- SerialId newtype migration chain (`u32` -> `SerialId` across core structs)
- `LeafAd` newtype and `LeafAdError` migration
- `EncryptedPack` wrapper migration from direct `ZkPackEncrypted`

### 2) Cross-Team OWF/Circuit Dependencies

⚠️ A non-trivial subset of open items requires OWF circuit parity work and shared vectors verification outside wallet-only scope.

- Circuit constraints C1..C7 and parity gates
- Wallet-to-circuit golden vector parity workflow
- CI gates that depend on circuit implementation readiness

### 3) Governance/Process Requirements

⚙️ Some items are process gates, not local code edits, and require team policy decisions or CI budget changes.

- Fuzz budget minimum in CI
- Global domain-label uniqueness policy cleanup across all crates
- Prohibited-label cleanup in legacy/non-runtime paths

### 4) Specification Quality Debt (Markdown/Lint)

⚠️ The spec file includes many markdown lint diagnostics. They are documentation-quality issues and do not necessarily represent cryptographic/runtime defects, but they affect “formal completeness” if treated as mandatory quality gates.

## Unblocked Next Actions

🎯 The following can be executed immediately without waiting for architecture approvals:

1. Close all wallet/core items that are not tagged as PROPOSED/FUTURE.
2. Keep vectors in crate-local tests directories only (already migrated in this cycle).
3. Add/expand deterministic tests where checklist intent is clear and current API supports it.
4. Maintain release verification runs with `--release --features test-fast`.

## Decision Needed for 100%

🔔 To reach formal 100% completion, the team must explicitly approve or defer-with-waiver:

- PROPOSED migration tracks (SerialId/LeafAd/EncryptedPack)
- OWF circuit synchronization milestones and acceptance criteria
- CI/process-only checklist items that are not code-local
