# 4. Asset & Asset Model

**Purpose:** Define cryptographic representation of value in Z00Z protocol. Assets are ownership objects identified by secret `s_out`, hidden in encrypted packs, with amounts protected by Pedersen commitments.

**Architecture Overview:** Separates asset identity (asset_id) from value representation (amount, commitment) and ownership proof (s_out, owner_tag). Enables confidential transactions with unlinkable outputs.

**Implementation Phase:** Phase 2 (Proofs & State) and Phase 3 (Privacy & Anti-Attack)  
**Base Document Reference:** Z00Z-ECC-StealthAddress-5.md § "Pedersen и пакет монеты"

### PhasePhase 1 

### 4.0.2 Critical Pre-Implementation Audit (2026-02-20)

> 🔍 **Code review audit performed against actual codebase.** All findings below are verified by grep/read of production files. Fix ALL BLOCKERS before shipping.

---

#### 🚨 BLOCKER-1 — `s_out` placeholder in production sender path

**File:** `crates/z00z_wallets/src/core/tx/mod.rs:73`

```rust
// CURRENT (BUG):
s_out: [0xABu8; 32],   // ← PLACEHOLDER, NOT real s_out derivation

// REQUIRED:
s_out: derive_s_out(r_pub, k_dh, serial_id),  // real derivation from stealth keys
```

**Impact:** Every output created by `tx/mod.rs` sender has a hardcoded `s_out`. Receiver gets the right decrypted pack but `s_out` is meaningless — can't be used for spending proofs. **Ship blocker.**

**Fix:** Derive `s_out` from `hash_zk::<WalletSOutDomain>("Z00Z/S_OUT", &[k_dh, r_pub, &serial_id.to_le_bytes()])` and fill correctly.

---

#### 🚨 BLOCKER-2 — Legacy sender path `build_tx_stealth_output` is INCOMPATIBLE with receiver

**File:** `crates/z00z_wallets/src/core/stealth/output.rs:142–178`

| Issue | Detail |
|-------|--------|
| Uses `encrypt_asset_pack` (old path) | Payload = `[amount_le8 \|\| asset_id_32]` = 40 bytes. NOT `AssetPackPlain` (72 bytes). Incompatible with `ZkPack::decrypt`. |
| Uses `aead::seal` with `Z00Z_ASSET_PACK_AAD` | No leaf_ad binding, no serial_id binding — violates MUST_3/MUST_4 |
| `derive_tag16` calls `compute_leaf_ad(asset_id, out_index, r_pub, owner_tag, [0u8;32])` | `out_index` ≠ `serial_id`; `c_amount = [0u8;32]` ≠ actual commitment bytes |

**Impact:** If any wallet code still calls `build_tx_stealth_output`, the resulting `enc_pack` **cannot be decrypted** by `receiver_scan_leaf` (which uses `ZkPack::decrypt` expecting 72-byte `AssetPackPlain`).

**Fix:** Delete or tombstone `build_tx_stealth_output` and `encrypt_asset_pack` in `output.rs`. All output creation MUST go through `tx/mod.rs` path (which uses `ZkPack::encrypt` with `AssetPackPlain::to_bytes()`).

---

#### ⚠️ GAP-1 — Two `compute_leaf_ad` with different parameter order

| Location | Signature |
|----------|-----------|
| `stealth/tag.rs` (canonical) | `compute_leaf_ad(asset_id, serial_id, r_pub, owner_tag, c_amount)` |
| `stealth/facade_kdf.rs` (public facade) | `compute_leaf_ad(r_pub, asset_id, serial_id, owner_tag, c_amount)` — r_pub FIRST |

Facade internally reorders correctly to canonical. **All call sites MUST use the facade version** (`kdf::compute_leaf_ad` or `stealth::compute_leaf_ad` via re-export). Direct calls to `tag::compute_leaf_ad` use canonical order. This is a trap for developers — adding a test that mixes the two orders will produce silent wrong values.

**Fix:** Add doc comment on `facade_kdf::compute_leaf_ad` warning: `/// NOTE: parameter order differs from canonical tag::compute_leaf_ad (r_pub is FIRST here)`.

---

#### ⚠️ GAP-2 — `AssetPackPlain::SIZE` constant doesn't exist

Spec checklists reference `AssetPackPlain::SIZE: usize = 72` as a required constant. The actual implementation in `z00z_core/src/assets/leaf.rs` uses `72` as a hardcoded literal in `from_bytes()` but does NOT define `pub const SIZE: usize = 72`. All checklists that reference `AssetPackPlain::SIZE` are documenting a task that's not done yet.

**Fix:** Add `pub const SIZE: usize = 72;` to `AssetPackPlain` impl block.

---

**Summary: 2 BLOCKERS must be fixed before any integration test can pass end-to-end:**

1. `s_out = [0xABu8; 32]` → derive real `s_out`
2. `build_tx_stealth_output` / `encrypt_asset_pack` → delete; migrate callers to `tx/mod.rs` path

---

### 4.0.1 Consistency Delta (2026-02-20)

✅ To keep type and structure consistency with the current codebase, apply this delta:

- Wallet facade modules are now physically located under `crates/z00z_wallets/src/core/`:
    - `core/cache.rs`, `core/ecdh.rs`, `core/kdf.rs`, `core/keys.rs`, `core/scan.rs`.
    - ZkPack is in `core/stealth/facade_zkpack.rs` (NOT `core/zkpack.rs` — deeper in `stealth` submodule).
- Root facade paths in `z00z_wallets` stay valid via re-exports from `core`.
- Legacy standalone `crates/z00z_wallets/src/types.rs` is removed.
- `ReceiverCard` is now defined in `crates/z00z_wallets/src/core/keys.rs`.
- Canonical `AssetLeaf` and `AssetPackPlain` are sourced from `z00z_core::assets` and re-exported by wallet keys facade.
- In stealth flow naming, `coin`-specific helper identifiers are aligned to `asset` terminology.

⚠️ Important terminology exception (do NOT rename):

- `coin_type` in BIP-44/SLIP-0044 context is a standards term and must remain `coin_type`.
- `AssetClass::Coin` is a domain enum variant in core asset taxonomy and is not renamed by this delta.

✅ Encrypted payload shape used by `enc_pack` remains structured as `ZkPackEncrypted { version, ciphertext, tag }`.

---

## 4.1 Asset Secret (s_out)

**Purpose:** Random 32-byte value serving as ownership object. Knowledge of `s_out` (plus `receiver_secret`) is required for spending. Derives unique `asset_id` preventing Asset linkability.

**Critical Property:** `s_out` is the "asset secret" - whoever knows it (and receiver_secret) can spend the Asset. Sender generates it randomly, encrypts in `enc_pack`, receiver extracts upon scanning.

**Security Model:** `s_out` confidentiality prevents front-running attacks. Randomness prevents asset_id collisions (cryptographically negligible probability).

### PhasePhase 2 

### 4.1.1 Generation

**Definition:** Generate cryptographically secure random 32-byte value using system RNG.

**Canonical Formula:**

```
s_out = RAND(32 bytes)
```

Where:

- `RAND` = Cryptographically secure random number generator
- Output: 32 bytes uniform random
- MUST use: `z00z_utils::rng::SystemRngProvider` (production)
- MUST NOT: use weak PRNG, timestamp-based, or deterministic generation in production

**Entropy Requirements:**

```yaml
EntropyRequirements(MUST):
  source: SystemRngProvider (OS-level CSPRNG)
  min_entropy: 256 bits (32 bytes)
  quality: cryptographically secure
  
  allowed_sources:
    - production: OsRng (getrandom syscall)
    - testing: MockRngProvider with fixed seed (MUST NOT use in production)
  
  forbidden_sources(DO_NOT_USE):
    - timestamp: predictable
    - counter: deterministic
    - user_input: insufficient entropy
    - weak_prng: Linear Congruential Generator, etc.

implementation_status:
  WARNING: >
    tx/mod.rs::sender_create_output_for currently uses s_out = [0xABu8; 32] — a placeholder.
    CONFIRMED at z00z_wallets/src/core/tx/mod.rs:73 (audit 2026-02-20). See §4.0.2 BLOCKER-1.
    MUST replace with SystemRngProvider-generated random bytes (z00z_utils::rng::SystemRngProvider)
    before production deployment. NEVER use OsRng or rand::thread_rng() directly.
**Rust Implementation:**

> **NOTE:** `s_out` (asset secret) is stored as raw `[u8; 32]` in the `Asset.secret` field
> (`z00z_core::assets::assets::Asset`). The `AssetSecret` newtype wrapper has been removed
> as redundant — use `[u8; 32]` directly.

#### 4.1.1.1 Entropy Requirements

**Operating System Sources:**

```yaml
OSEntropyAudit:
  linux:
    primary: getrandom(2) syscall
    fallback: /dev/urandom
    quality: cryptographic (CSPRNG)
    blocking: non-blocking after boot
  
  macos:
    primary: getentropy(2)
    quality: cryptographic
    notes: uses Fortuna CSPRNG
  
  windows:
    primary: BCryptGenRandom
    quality: cryptographic
    notes: CNG (Cryptography API Next Generation)
  
  mobile:
    android: /dev/urandom (kernel CSPRNG)
    ios: SecRandomCopyBytes
```

**Failure Modes:**

```rust
#[derive(Debug, Error)]
pub enum AssetSecretError {
    #[error("Insufficient entropy from system RNG")]
    InsufficientEntropy,
    
    #[error("RNG initialization failed")]
    RngInitFailed(#[from] rand_core::Error),
    
    #[error("Weak RNG detected (testing mode in production)")]
    WeakRngInProduction,
}

// NOTE: AssetSecret newtype removed (see §4.1.3) — returns raw [u8; 32] directly.
pub fn generate_asset_secret_checked() -> Result<[u8; 32], AssetSecretError> {
    // SystemRngProvider is a unit struct (not SystemRngProvider::default())
    let provider = SystemRngProvider;
    let mut rng = provider.rng();
    let mut bytes = [0u8; 32];
    rng.fill_bytes(&mut bytes);
    
    // Sanity check: reject all-zeros (entropy failure)
    if bytes == [0u8; 32] {
        return Err(AssetSecretError::InsufficientEntropy);
    }
    
    Ok(bytes)  // AssetSecret newtype removed — return raw [u8; 32] directly
}
```

---

**📋 Implementation Checklist: 4.1.1.1 Entropy Requirements**

- [x] **Implement `AssetSecretError` enum** in `z00z_core/src/assets/secret.rs`
  - [x] Add variant `InsufficientEntropy` with message `"Insufficient entropy from system RNG"`
  - [x] Add variant `RngInitFailed(#[from] rand_core::Error)`
  - [x] Add variant `WeakRngInProduction` with message `"Weak RNG detected in production context"`
  - [x] Derive `Debug, Error` via `thiserror`
- [x] **Implement `generate_asset_secret_checked() -> Result<[u8; 32], AssetSecretError>`**
  - [x] Use `z00z_utils::rng::SystemRngProvider` — unit struct, call as `SystemRngProvider.rng()` (no `::default()`, no `::new()`)
  - [x] Obtain RNG handle: `let mut rng = SystemRngProvider.rng();`
  - [x] Fill buffer: `rng.fill_bytes(&mut bytes)` where `bytes = [0u8; 32]`
  - [x] Reject all-zeros: `if bytes == [0u8; 32] { return Err(AssetSecretError::InsufficientEntropy) }`
  - [x] Return `Ok(bytes)` as raw `[u8; 32]` — NOT wrapped in any newtype
  - [x] `AssetSecret` newtype MUST NOT be created
- [x] **NEVER import `rand::rngs::OsRng` directly** — always use `z00z_utils::rng::SystemRngProvider`
- [x] **Add unit tests** in `z00z_core/tests/assets/secret.rs` or inline `mod tests` block
  - [x] `test_generate_secret_returns_32_bytes`: verify output is exactly 32 bytes
  - [x] `test_generate_secret_not_all_zeros`: generated bytes are not all zero
  - [x] `test_generate_secret_unique`: call twice, assert `result1 != result2`
  - [x] `test_all_zeros_rejected`: inject mock RNG returning `[0u8;32]`, verify `InsufficientEntropy` error
- [x] **`cargo check`** passes with 0 errors and 0 clippy warnings after implementation

### PhasePhase 3 

### 4.1.2 Ownership Semantics

**Definition:** `s_out` represents "asset ownership object". Spending Asset requires proving knowledge of BOTH:

1. `s_out` (extracted from enc_pack)
2. `receiver_secret` (long-lived wallet secret)

**Why Two Secrets:**

```yaml
TwoSecretOwnership:
  s_out(asset_secret):
    - per_output: each Asset has unique s_out
    - sender_generates: sender creates s_out randomly
    - receiver_extracts: receiver decrypts from enc_pack
    - purpose: ownership object + asset_id derivation
  
  receiver_secret:
    - wallet_level: one per wallet (long-lived)
    - never_published: stays in secure storage
    - receiver_only: sender never knows it
    - purpose: proves authorization to spend
  
  combined_requirement:
    why: prevents sender from spending outputs they created
    security: sender knows s_out but not receiver_secret
    result: sender CANNOT spend without receiver_secret
```

**Spending Proof (TxProof):**

> **STATUS: NOT YET IN CODEBASE.** `SpendWitness` is a future type for Phase 5 OWF
> integration. Existing ownership scan is in `z00z_wallets::core::stealth::output::verify_owner_tag()`.

```rust
// Future: z00z_core/src/tx/spend_witness.rs
// Depends on: AssetSecret newtype (4.1.3), AssetId newtype (4.2.2)

pub struct SpendWitness {
    pub receiver_secret: ReceiverSecret,  // z00z_wallets::core::key::ReceiverSecret (EXISTS)
    pub s_in: [u8; 32],                   // asset secret = the s_out value of the consumed AssetLeaf (same 32-byte secret, renamed to s_in here to reflect its role as spending input)
    pub v: u64,
    pub blinding: Z00ZScalar,             // z00z_crypto::Z00ZScalar (EXISTS); renamed r_out→blinding for consistency with AssetPackPlain.blinding
}

impl SpendWitness {
    /// Conceptual check — actual ownership verification uses verify_owner_tag()
    /// in z00z_wallets::core::stealth::output (EXISTS)
    pub fn can_spend(&self, leaf: &AssetLeaf) -> bool {
        // Requirement 1: asset_id must match s_in
        // compute_asset_id: uses h2scalar_zk with AssetIdDomain (EXISTS in z00z_crypto::domains)
        let asset_id_computed = compute_asset_id(&self.s_in); // [u8;32] → [u8;32]
        if asset_id_computed != leaf.asset_id {
            return false;
        }
        
        // Requirement 2: know receiver_secret
        let owner_handle = derive_owner_handle(&self.receiver_secret); // → [u8;32] (EXISTS)
        let view_sk = derive_view_secret_key(&self.receiver_secret)    // → Result<Z00ZScalar> (EXISTS)
            .expect("invalid receiver secret");
        
        // decode_r_pub: z00z_wallets::core::stealth::encoding (EXISTS)
        // returns Result<Z00ZRistrettoPoint, StealthError>
        let r_pub_pt = decode_r_pub(&leaf.r_pub).expect("invalid r_pub");
        
        // compute_dh_receiver: z00z_wallets::core::stealth::ecdh (EXISTS)
        // signature: (view_sk: &Z00ZScalar, r_pub: &Z00ZRistrettoPoint) -> Result<[u8;32], StealthError>
        let dh_bytes = compute_dh_receiver(&view_sk, &r_pub_pt).expect("dh failed");
        
        // derive_k_dh: z00z_wallets::core::stealth::ecdh (EXISTS)
        // signature: (dh: &[u8;32]) -> [u8;32]
        let k_dh = derive_k_dh(&dh_bytes);
        
        // compute_owner_tag: z00z_wallets::core::stealth::output (EXISTS)
        // signature: (owner_handle: &[u8;32], k_dh: &[u8;32]) -> [u8;32]
        let owner_tag_expected = compute_owner_tag(&owner_handle, &k_dh);
        
        owner_tag_expected == leaf.owner_tag
    }
}
```

**Comparison with Other Models:**

```yaml
OwnershipModels:
  ecdsa_Asset(bitasset):
    ownership: public_key_hash
    spend_proof: signature with private_key
    limitation: address reuse linkable
  
  stealth_address(monero):
    ownership: one_time_address per output
    spend_proof: private_key derived from wallet_key + tx_key
    limitation: scanning requires wallet_key
  
  z00z_ecc_stealth(this_spec):
    ownership: s_out + receiver_secret (two-factor)
    spend_proof: knowledge of both + owner_tag verification
    advantage: sender cannot spend, unlinkable outputs
```

---

**📋 Implementation Checklist: 4.1.2 Ownership Semantics**

- [x] **Verify two-factor ownership model is enforced at spend-level checks**
  - [x] `Asset.secret: Option<[u8; 32]>` stores `s_out` in `z00z_core::assets::assets::Asset` — confirmed field name and type
  - [x] `AssetPackPlain.s_out: [u8; 32]` is the 32-byte asset secret extracted from `enc_pack` — confirmed field in `z00z_core::assets::leaf`
  - [x] `ReceiverSecret` (wallet-level, long-lived) is in `z00z_wallets::core::key` — confirmed existence and wallet-side ownership path
- [x] **`can_spend` / ownership check — current path (REAL, NOT SpendWitness)**
  - [x] Current ownership check is `verify_owner_tag()` in `z00z_wallets::core::stealth::output` — verified
  - [x] Call chain: `ReceiverSecret` → `derive_owner_handle()` + `derive_view_secret_key()` → `compute_dh_receiver()` → `derive_k_dh()` → `compute_owner_tag()` → compare with `leaf.owner_tag`
  - [x] Each function exists in `z00z_wallets` (`stealth`/`key` modules) and was verified by grep
  - [x] `s_out` is not used alone as spend proof in ownership checks (`verify_owner_two_factor` requires `receiver_secret` + `s_out`)
- [ ] **`SpendWitness` struct — PROPOSED ONLY, do NOT implement yet**
  - [ ] `SpendWitness { receiver_secret, s_in: [u8;32], v: u64, blinding: Z00ZScalar }` lives in `z00z_core/src/tx/spend_witness.rs`
  - [x] Do NOT create this file until Phase 5 OWF integration is approved
  - [ ] `s_in` is the `s_out` value of the consumed `AssetLeaf` (same bytes, renamed to reflect spending role)
  - [ ] `blinding` field uses `Z00ZScalar` — NOT `Z00ZBlindingFactor` (does not exist)
- [x] **`asset_id` binding — JMT key contract is fixed**
  - [x] `AssetLeaf.asset_id` is the canonical public JMT key
  - [x] `secret_tag` remains an ownership-side concept and MUST NOT be described as a JMT key
  - [x] `TxProof` and checkpoint text must reference the `asset_id`-keyed JMT model only
- [x] **Anti-rebinding: sender CANNOT spend receiver's output**
  - [x] Verified no current path reconstructs `receiver_secret` from sender-side material in ownership check flow
  - [x] Added `test_sender_cannot_spend`: receiver passes two-factor check, sender material fails on same output

### PhasePhase 4 

### 4.1.3 Asset Secret API

> **NOTE:** `s_out` is stored as raw `[u8; 32]` directly. The `AssetSecret` newtype wrapper
> has been removed as redundant. In the codebase, `s_out` appears as:
> - `pub s_out: [u8; 32]` in `z00z_core::assets::leaf::AssetPackPlain`
> - `Asset.secret` field (`pub secret: Option<[u8; 32]>`) in `z00z_core::assets::assets::Asset`

**📋 Implementation Checklist: 4.1.3 Asset Secret API**

- [x] `AssetSecret` newtype is removed from runtime code path
- [x] `AssetPackPlain.s_out` is raw `[u8; 32]`
- [x] `Asset.secret` is raw `Option<[u8; 32]>` (not `H(s_out)`)
- [x] Secret generation API returns raw `[u8; 32]` via `generate_asset_secret_checked()`
- [x] Secret generation helper enforces crypto RNG contract (`RngCore + CryptoRng`)
- [x] Wire roundtrip preserves raw `Asset.secret` bytes without transformation
- [x] Naming in touched functions follows `@MUST` rule (≤5 words)

---

## 4.2 Secret Tag And Asset ID Roles

> ✅ **DISAMBIGUATION — three distinct concepts in the codebase:**
>
> 1. **`Asset.asset_id()`** — method on full `Asset` struct (`z00z_core::assets::assets`):
>    `DomainHasher::<AssetIdHashDomain>` chained with `nonce + commitment + definition.id + serial_id`.
>    Object-level identifier for the complete Asset record. **NOT related to stealth outputs.**
>
> 2. **`AssetLeaf.asset_id`** — canonical public JMT key for stealth outputs (`z00z_core::assets::leaf`).
>
> 3. **`secret_tag`** — derivation from the asset output secret `s_out` used in ownership and
>    spend-witness-oriented reasoning. It is not a public JMT key and not an alternate leaf identifier.
>
> ✅ **Repository rule:** JMT membership, lookups, checkpoint deltas, and proof-facing state keys use
> `asset_id` only. `secret_tag` remains a separate concept and MUST NOT be described as the JMT key.

**Purpose:** `secret_tag` is a 32-byte stealth identifier derived deterministically from `s_out`. Prevents linkability while ensuring uniqueness.

**Critical Property:** `secret_tag` collision probability is cryptographically negligible (2^-256). Observers cannot link multiple outputs to same receiver (each has unique `s_out` → unique `secret_tag`).

### PhasePhase 5 

### 4.2.1 Secret Tag Derivation

**Definition:** 32-byte Poseidon2 hash of asset output secret with domain separation.

**Canonical Formula:**

```
secret_tag = poseidon2_hash("Z00Z/ASSET" || s_out)
```

Where:

- `poseidon2_hash` = Poseidon2 (Goldilocks-8) sponge — ZK-friendly, consensus-critical
- `"Z00Z/ASSET"` = Domain label from `AssetIdDomain` (`z00z_crypto::domains::AssetIdDomain`)
- Domain is already **registered** in `z00z_crypto::domains` (line: `hash_domain!(AssetIdDomain, "Z00Z/ASSET", 1)`)
- `s_out` = 32-byte asset output secret
- Output: `[u8; 32]` secret tag (stealth spending identifier)

> **NOTE on `hash_zk` vs `poseidon2_hash`:** The implementation uses
> `hash_zk::<AssetIdDomain>("Z00Z/ASSET", &[s_out])` from `z00z_crypto::hash_zk`
> which internally calls `poseidon2_hash` with domain framing. NOT `hash_domain!` macro.

> ✅ **hash_zk uses native Poseidon2 (Goldilocks) — ZK-circuit-friendly (see §4.2.1.2):**
> `hash_zk` calls **native Poseidon2 (Goldilocks field, width-8)** via `poseidon2_hash()` —
> efficient in both software (~ns) and ZK proof circuits (~10–50 constraints/hash).
> The `secret_tag` derivation is **already provable in-circuit** at low cost.
> **No hash migration needed.** The remaining ZK blocker is AEAD
> (ChaCha20Poly1305 → Poseidon2-based AEAD, see §4.6.9).

**Security Properties:**

```yaml
SecretTagSecurity:
  uniqueness:
    - collision_probability: 2^-256 (negligible)
    - birthday_bound: 2^128 outputs (impractical to reach)
    - guarantee: virtually impossible to generate duplicate secret_tag
  
  unlinkability:
    - different_s_out: different secret_tag (deterministic but unpredictable)
    - observer: cannot link outputs without knowing s_out values
    - privacy: secret_tag appears random without asset output secret
  
  preimage_resistance:
    - cannot_reverse: secret_tag → s_out (one-way function)
    - protection: even knowing secret_tag doesn't reveal s_out
```

**Rust Implementation (compute_secret_tag):**

> **NOTE:** `AssetIdDomain`, `hash_zk`, and `compute_secret_tag` are already present in the
> codebase. The helper exists for ownership and witness-oriented flows only and does not change the
> public `asset_id`-keyed JMT contract.

```rust
// Existing domain: z00z_crypto::domains::AssetIdDomain
// hash_domain!(AssetIdDomain, "Z00Z/ASSET", 1);

use z00z_crypto::{domains::AssetIdDomain, hash_zk::hash_zk};

/// Compute secret_tag from asset output secret s_out.
/// Returns [u8; 32]. Used for spending proofs.
pub fn compute_secret_tag(s_out: &[u8; 32]) -> [u8; 32] {
  hash_zk::<AssetIdDomain>("", &[s_out])
}
```

#### 4.2.1.1 JMT Key

> ✅ **Current and required model:** `AssetLeaf.asset_id` is the actual JMT key used by code and by
> this specification. `secret_tag` is not part of the JMT key path.

**JMT Integration:**

The `asset_id` serves as the key in Jellyfish Merkle Tree for Asset lookups.

```rust
pub struct AssetStore {
    jmt: JellyfishMerkleTree,
}

impl AssetStore {
    /// Insert new Asset leaf
    pub fn insert(&mut self, asset_id: AssetId, leaf: AssetLeaf) -> Result<(), Error> {
        self.jmt.put(asset_id.as_bytes(), &serialize_leaf(&leaf))?;
        Ok(())
    }
    
    /// Get Asset leaf by asset_id
    pub fn get(&self, asset_id: &AssetId) -> Result<Option<AssetLeaf>, Error> {
        match self.jmt.get(asset_id.as_bytes())? {
            Some(bytes) => Ok(Some(deserialize_leaf(&bytes)?)),
            None => Ok(None),
        }
    }
    
    /// Delete Asset (spent)
    pub fn delete(&mut self, asset_id: &AssetId) -> Result<(), Error> {
        self.jmt.delete(asset_id.as_bytes())?;
        Ok(())
    }
    
    /// Get Merkle proof for asset_id
    pub fn get_proof(&self, asset_id: &AssetId) -> Result<MerkleProof, Error> {
        self.jmt.get_with_proof(asset_id.as_bytes())
    }
}
```

**JMT Operations:**

```yaml
JMTOperations:
  insert:
    key: asset_id (32 bytes)
    value: serialized AssetLeaf
    result: updated tree root
    complexity: O(log N) where N is number of leaves
  
  lookup:
    key: asset_id
    result: AssetLeaf or None
    proof: Merkle proof of membership or non-membership
    complexity: O(log N)
  
  delete:
    key: asset_id (spending Asset)
    result: updated tree root
    proof: Merkle proof of previous existence
    complexity: O(log N)
  
  batch_update:
    operations: [(Insert, asset_id, leaf), (Delete, asset_id)]
    result: single root transition
    efficiency: amortized O(K log N) for K operations
```

---

**📋 Implementation Checklist: 4.2.1.1 JMT Key**

- [x] **Implement `AssetStore` struct** in `z00z_core/src/assets/store.rs` (create new file)
  - [x] Integrated `JellyfishMerkleTree` from `jmt` crate (created on-demand per operation)
  - [x] Storage backend implements `TreeStoreReader + TreeStoreWriter` traits
- [x] **Implement `AssetStore::insert(asset_id: [u8;32], leaf: AssetLeaf) -> Result<(), Error>`**
  - [x] Serialize `leaf` via `z00z_utils::codec::BincodeCodec.serialize(&leaf)?`
  - [x] JMT write path implemented via single `batch_put_value_set` insert op
  - [x] NEVER use `serde_json::to_vec` or `serde_json::to_string` directly
- [x] **Implement `AssetStore::get(asset_id: &[u8;32]) -> Result<Option<AssetLeaf>, Error>`**
  - [x] JMT read path via `get_with_proof`; on `Some(payload)` deserialize with `BincodeCodec`, on `None` return `Ok(None)`
- [x] **Implement `AssetStore::delete(asset_id: &[u8;32]) -> Result<(), Error>`**
  - [x] JMT delete path via `batch_put_value_set` with `None` value
- [x] **Implement `AssetStore::get_proof(asset_id: &[u8;32]) -> Result<MerkleProof, Error>`**
  - [x] Returns proof from `get_with_proof(asset_id, version)`
- [x] **Implement `AssetStore::batch_update(ops: Vec<JmtOp>) -> Result<(), Error>`**
  - [x] Supports `JmtOp::Insert(asset_id, leaf)` and `JmtOp::Delete(asset_id)`
  - [x] Processes ops in one JMT batch transaction (`O(K log N)`)
- [x] **Keep `secret_tag` out of the JMT-key contract**
  - [x] All touched code and spec text use `asset_id` as the canonical JMT key
  - [x] `secret_tag` remains available as a separate ownership-side derivation only
- [x] **Add unit tests**
  - [x] `test_insert_and_get`: insert leaf → retrieved leaf equals original
  - [x] `test_delete_removes_leaf`: insert → delete → get returns `None`
  - [x] `test_get_proof_valid`: insert → `get_proof` returns verifiable `MerkleProof`
  - [x] `test_batch_update`: mixed insert+delete ops succeed in single call
- [x] **`AssetId` type alias** `pub type AssetId = [u8; 32]` from `z00z_core::assets::registry` — do NOT redefine

#### 4.2.1.2 ZK Hash Status — ✅ Poseidon2 Already Implemented

> ✅ **IMPLEMENTED.** `hash_zk` in `z00z_crypto::hash::zk` calls **`poseidon2_hash()`**
> (Goldilocks field, `Poseidon2GoldilocksHL` width-8 permutation). The BLAKE2b-based migration
> described in earlier spec drafts is **already complete** — no further hash migration needed.

**Current State:**

```yaml
ZkHashStatus:
  hash_zk:
    function: "poseidon2_hash() — Goldilocks field, Poseidon2GoldilocksHL width-8"
    cost_in_circuit: "~10–50 R1CS constraints per hash"
    status: "✅ ZK-circuit-friendly — already implemented"
    migration_needed: false

  remaining_zk_blocker:
    component: "AEAD encryption (enc_pack)"
    algorithm: "ChaCha20Poly1305 — NOT circuit-friendly (~50K constraints)"
    plan: "Migrate to Poseidon2-based AEAD (Z00Z/PACKSTR keystream + Z00Z/PACKTAG MAC)"
    milestone: "Phase 1 ZK circuit integration — see §4.6.9"
    note: "hash_zk / Poseidon2 is NOT the blocker — only AEAD remains"
```

**Why Poseidon2 (Goldilocks)?**

- Poseidon2 over Goldilocks field (`p = 2^64 - 2^32 + 1`) reduces constraint count ~100×
  vs BLAKE2b over native field arithmetic
- Already used in Jellyfish Merkle Tree hash — consistent choice for entire asset pipeline
- Goldilocks native multiplication = 1 constraint; BLAKE2b bit-rotation = expensive
- All `H_zk` domains (`Z00Z/ASSET`, `Z00Z/LEAFAD`, `Z00Z/PACKKEY`, etc.) already ZK-friendly

---

**📋 Implementation Checklist: 4.2.1.2 ZK Hash Status**

- [x] **Verify Poseidon2 is active** — no code changes needed, only verification
  - [x] Confirmed `hash_zk::<D>(label, inputs)` in `z00z_crypto::hash::zk` calls `poseidon2_hash()` (not Blake2b)
  - [x] Confirmed `Poseidon2GoldilocksHL` width-8 is the active permutation configuration
  - [x] Added snapshot test for `hash_zk::<AssetIdDomain>("", &[[0x01u8;32]])` with stable bytes (domain already encoded by `AssetIdDomain`)
- [x] **Document AEAD as the ONLY remaining ZK blocker** in `z00z_wallets/src/core/stealth/facade_zkpack.rs`
  - [x] Added file-level ZK blocker comment for ChaCha20Poly1305 AEAD and Poseidon2 migration path (§4.6.9)
  - [x] Added tracking issue note: "Migrate ZkPack from ChaCha20Poly1305 to Poseidon2-based AEAD"
- [x] **Add doc comment to `z00z_crypto/src/hash/zk.rs` header**
  - [x] Added text: `// Poseidon2 (Goldilocks) is ZK-circuit-friendly (~10-50 constraints/hash). No hash migration needed.`
- [x] **Freeze all H_zk domain strings with snapshot tests** in `z00z_crypto/tests/`
  - [x] Added snapshot test for `Z00Z/ASSET`, `Z00Z/LEAFAD`, `Z00Z/PACKKEY`, `Z00Z/PACKNONCE`
  - [x] Enforced via deterministic test snapshots (CI merge gate through test execution)

### PhasePhase 6 

### 4.2.2 Asset ID API

> **NOTE:** `asset_id` is stored as raw `[u8; 32]` directly. An existing type alias
> `pub type AssetId = [u8; 32]` is available in `z00z_core::assets::registry`
> (`z00z_core/src/assets/registry.rs`). The `AssetId` struct newtype wrapper
> has been removed as redundant — use the existing type alias.

**📋 Implementation Checklist: 4.2.2 Asset ID API**

- [x] Canonical alias exists: `z00z_core::assets::registry::AssetId`
- [x] No runtime `AssetId` struct newtype is present in `z00z_core`/`z00z_wallets`
- [x] New Phase 5 storage API uses canonical alias (`AssetStore` / `JmtOp` signatures)
- [x] Assets facade re-exports canonical alias: `z00z_core::assets::AssetId`

---

## 4.3 Serial ID

**Purpose:** Versioning and protocol evolution field for Asset outputs. The `serial_id` serves multiple purposes: asset series identification (genesis batches), NFT unique identifiers, protocol format versioning, and as binding parameter in cryptographic derivations (enc_pack encryption).

**Critical Property:** `serial_id` MUST be canonically encoded as **u32 little-endian (4 bytes)** in all contexts (asset_pack_plain, OWF constraints, hash derivations). Non-canonical encoding breaks consensus.

**Integration:** The `serial_id` is already used in existing `z00z_core::Asset` struct as `pub serial_id: u32`. This specification extends its role into ECC stealth address protocol.

### PhasePhase 7 

### 4.3.1 Serial ID Semantics

**Multiple Use Cases:**

```yaml
SerialIdUseCases:
  asset_series:
    description: Identifies genesis batch or asset series
    example: "Assets: series 1-10000 (10k outputs per series)"
    validation: "serial_id < definition.serials (upper bound check)"
    
  nft_identifier:
    description: Unique ID for NFT within collection
    example: "NFT #42 in collection → serial_id = 42"
    validation: "serial_id uniqueness enforced by JMT (one leaf per asset_id)"
    
  protocol_version:
    description: Format evolution for asset_pack structure
    example: "v1: 8+32+32 = 72 bytes (value|blinding|s_out); serial_id is NOT in plaintext (it is in leaf_ad AAD); v2: adds memo field"
    migration: "OWF circuit updates to support new versions"
    
  derivation_binding:
    description: Input to leaf_ad, pack_key, nonce derivations
    purpose: "Prevents cross-serial-id replay attacks in enc_pack"
    critical: "MUST be included in all hash chains involving enc_pack"
```

**Definition:** 32-bit unsigned integer with canonical little-endian encoding.

```
serial_id: u32 (4 bytes)
Encoding: little-endian (LE)
Range: [0, 2^32 - 1]
Canonical: MUST encode as exactly 4 bytes LE
```

**Example Encoding:**

```
serial_id = 0          → [0x00, 0x00, 0x00, 0x00]
serial_id = 1          → [0x01, 0x00, 0x00, 0x00]
serial_id = 256        → [0x00, 0x01, 0x00, 0x00]
serial_id = 0x12345678 → [0x78, 0x56, 0x34, 0x12]
```

#### 4.3.1.1 Versioning Strategy

**Protocol Evolution via serial_id:**

Z00Z protocol uses `serial_id` for **opt-in format upgrades** without hard forks:

```yaml
VersioningModel:
  backward_compatible:
    - old_clients: "Can scan outputs with serial_id < MAX_VERSION_KNOWN"
    - new_clients: "Understand both old and new serial_id formats"
    - coexistence: "Multiple versions active simultaneously on chain"
    
  version_ranges:
    v1_basic:
      range: [0, 999999]
      asset_pack: "(value, blinding, s_out) - 72 bytes fixed"
      owf_circuit: "OWF_v1 circuit validates this format"
      
    v2_memo:
      range: [1000000, 1999999]
      asset_pack: "(value, blinding, s_out, memo_len, memo) - variable"
      owf_circuit: "OWF_v2 circuit validates extended format"
      
    future_versions:
      range: "[2000000+]"
      reserved: "For protocol upgrades (stealth addresses v2, quantum resistance)"
      
  upgrade_timeline:
    phase1: "Propose new version range, deploy OWF_vN circuit"
    phase2: "Activate after 80% aggregator support"
    phase3: "Old versions remain valid (no sunset)"
```

**Example Migration:**

1. **Before:** All outputs use `serial_id ∈ [0, 999999]` with fixed 72-byte asset_pack
2. **Upgrade Proposal:** Introduce `serial_id ∈ [1000000+]` with variable-length memo field
3. **Deployment:** New OWF_v2 circuit recognizes `serial_id >= 1000000` → parse extended format
4. **Activation:** Wallets can create new-format outputs, old wallets skip (unrecognized serial_id)

**Validation Rule:**

```rust
// NOTE: This function detects asset_pack FORMAT version only.
// It MUST NOT be used as a universal validity gate — NFT serial IDs may legitimately
// fall into the "unknown" range (e.g., serial_id=3_000_000 in a 5M-token collection).
// For NFT bounds: use `serial_id < definition.serials` (§4.3.1.2).
// For unknown formats: return Unknown and let the caller decide whether to skip/reject.
fn validate_serial_id_version(serial_id: u32) -> AssetPackVersion {
    match serial_id {
        0..=999_999 => AssetPackVersion::V1Basic,
        1_000_000..=1_999_999 => AssetPackVersion::V2Memo,
        // NOT an error — legitimately-unknown version (future protocol or high NFT ID).
        // Caller must decide: skip scanning or reject transaction.
        _ => AssetPackVersion::Unknown,
    }
}
```

> ⚠️ **DESIGN CONFLICT — NFT serial vs protocol version range:**
> `validate_serial_id_version` rejects `serial_id >= 2_000_000` as `UnknownSerialIdVersion`.
> However, an NFT collection with `definition.serials = 5_000_000` has **legitimate** `serial_id`
> values in `[2_000_000, 4_999_999]`. Applying this function as a universal validity gate would
> incorrectly reject valid NFT outputs.
>
> **Resolution:** `validate_serial_id_version` is for **asset_pack format detection only** —
> determining which enc_pack layout to decode. NFT serial validity is a separate check:
> `serial_id < definition.serials` (see §4.3.1.2). Decoders MUST NOT use format-version
> detection as a substitute for bounds validation.

---

**📋 Implementation Checklist: 4.3.1.1 Versioning Strategy**

- [x] **Implement `AssetPackVersion` enum** in `z00z_core/src/assets/version.rs` (create new file)
  - [x] Variant `V1Basic` — serial_id range `[0, 999_999]`
  - [x] Variant `V2Memo` — serial_id range `[1_000_000, 1_999_999]`
  - [x] Variant `Unknown` — serial_id `[2_000_000, u32::MAX]` — NOT an error
  - [x] Derive `Debug, Clone, Copy, PartialEq, Eq`
- [x] **Implement `validate_serial_id_version(serial_id: u32) -> AssetPackVersion`** as free function
  - [x] Match on exact ranges: `0..=999_999 => V1Basic`, `1_000_000..=1_999_999 => V2Memo`, `_ => Unknown`
  - [x] Return `AssetPackVersion::Unknown` for `_` — do NOT panic, do NOT return `Err`
  - [x] Add `#[must_use]` annotation on the function
  - [x] Add doc comment: "For enc_pack format detection ONLY — NOT a universal validity gate for NFT serial IDs"
- [x] **CRITICAL: Never use this function as an NFT validity gate**
  - [x] At every call site, add comment: `// format detection only — not serial validity check`
  - [x] NFT serial validity is checked separately via `serial_id < definition.serials` (§4.3.1.2)
- [x] **Add unit tests** in `mod tests` block or `z00z_core/tests/assets/version.rs`
  - [x] `test_v1_boundary_low`: serial_id=0 → `V1Basic`
  - [x] `test_v1_boundary_high`: serial_id=999_999 → `V1Basic`
  - [x] `test_v2_boundary_low`: serial_id=1_000_000 → `V2Memo`
  - [x] `test_v2_boundary_high`: serial_id=1_999_999 → `V2Memo`
  - [x] `test_unknown_start`: serial_id=2_000_000 → `Unknown` (no panic)
  - [x] `test_unknown_max`: serial_id=`u32::MAX` → `Unknown` (no panic)
  - [x] `test_nft_high_serial_not_rejected`: serial_id=3_000_000 returns `Unknown`, caller does NOT return error

#### 4.3.1.2 Asset Series Validation

**Integration with AssetDefinition:**

The existing `z00z_core::AssetDefinition` already defines `serials: u32` field:

```rust
// From z00z_core/src/assets/definition.rs (existing)
pub struct AssetDefinition {
    pub serials: u32,  // Maximum number of outputs for this asset class
    // ... other fields
}
```

**Validation Rule (from wire.rs):**

```rust
// Existing validation in z00z_core/src/assets/wire.rs
if asset.serial_id >= asset.definition.serials {
    return Err(AssetError::InvalidSerialId {
        serial_id: asset.serial_id,
        max_allowed: asset.definition.serials,
    });
}
```

**Example:** Genesis configuration defines "Gold Asset" with `serials: 10000`:

```yaml
AssetDefinition:
  id: "GOLD"
  serials: 10000
  
# Validation:
serial_id = 0      → VALID (within range)
serial_id = 9999   → VALID (last valid serial)
serial_id = 10000  → INVALID (exceeds definition.serials)
serial_id = 10001  → INVALID
```

---

**📋 Implementation Checklist: 4.3.1.2 Asset Series Validation**

- [x] **Use existing `AssetDefinition.serials: u32` field** — do NOT add new fields to `AssetDefinition`
- [x] **Implement/verify bounds validation** in `z00z_core/src/assets/wire.rs` or `z00z_core/src/assets/assets.rs`
  - [x] Rule (strictly less than): `if asset.serial_id >= asset.definition.serials { return Err(...) }`
  - [x] Error: `AssetError::InvalidSerialId { serial_id: u32, max_allowed: u32 }`
  - [x] Add `InvalidSerialId { serial_id: u32, max_allowed: u32 }` variant to `AssetError` if not already present
- [x] **Verify existing implementation in `z00z_core/src/assets/wire.rs`** matches spec exactly
  - [x] Confirm the exact condition is `serial_id >= definition.serials` (not `>` or other variant)
  - [x] Confirm error type is `AssetError::InvalidSerialId` with both fields
- [x] **Edge cases MUST all be handled correctly**
  - [x] `serial_id=0, definition.serials=1` → VALID (0 < 1)
  - [x] `serial_id=0, definition.serials=0` → INVALID (0 >= 0)
  - [x] `serial_id=9999, definition.serials=10000` → VALID (9999 < 10000)
  - [x] `serial_id=10000, definition.serials=10000` → INVALID (10000 >= 10000)
  - [x] `serial_id=u32::MAX, definition.serials=u32::MAX` → INVALID (MAX >= MAX)
- [x] **Add unit tests** in `z00z_core/tests/assets/` or inline `mod tests`
  - [x] `test_valid_serial_within_bounds`: serial=500, max=1000 → `Ok`
  - [x] `test_invalid_serial_equals_max`: serial=1000, max=1000 → `Err(InvalidSerialId)`
  - [x] `test_invalid_serial_exceeds_max`: serial=1001, max=1000 → `Err(InvalidSerialId)`
  - [x] `test_zero_serial_zero_max`: serial=0, max=0 → `Err(InvalidSerialId)`
  - [x] `test_max_u32_serial`: serial=`u32::MAX`, max=`u32::MAX` → `Err(InvalidSerialId)`

### PhasePhase 8 

### 4.3.2 Serial ID in Derivations

**Critical Role:** `serial_id` is binding parameter in multiple hash derivations to prevent enc_pack replay attacks.

> **IMPLEMENTED** — all three derivation functions are in the codebase:
> - `compute_leaf_ad` → `z00z_wallets::core::stealth::tag::compute_leaf_ad` (arg order: asset_id, serial_id, r_pub, owner_tag, c_amount)
> - `derive_pack_key` → `z00z_wallets::core::stealth::facade_kdf::derive_pack_key` (k_dh, asset_id, serial_id)
> - `derive_pack_nonce` → `z00z_wallets::core::stealth::facade_kdf::derive_pack_nonce` (leaf_ad, r_pub, asset_id, serial_id)
> Facade wrapper `kdf::compute_leaf_ad(r_pub, asset_id, serial_id, ...)` reorders r_pub to first position but calls the canonical function internally.

**Canonical Formula:**

```
# leaf_ad (Associated Data for enc_pack)
leaf_ad = H_zk("Z00Z/LEAFAD" || asset_id || serial_id_le4 || R_pub || owner_tag || C_amount)

# pack_key (Encryption key for asset_pack)
pack_key = H_zk("Z00Z/PACKKEY" || k_dh || asset_id || serial_id_le4)

# nonce (Deterministic nonce for ZkPack_v1)
nonce = H_zk("Z00Z/PACKNONCE" || leaf_ad || R_pub || asset_id || serial_id_le4)
```

Where:

- `serial_id_le4` = 4 bytes little-endian encoding of serial_id (u32)
- `H_zk` = Poseidon2 hash via `hash_zk::<Domain>(label, inputs)` (`z00z_crypto::hash_zk`)

**Anti-Replay Property:**

```yaml
ReplayPrevention:
  scenario: "Attacker tries to copy enc_pack from output A to output B"
  
  output_A:
    secret_tag_A: "hash(s_out_A)"
    serial_id_A: 100
    enc_pack_A: "encrypted with pack_key_A (includes serial_id_A)"

  output_B:
    secret_tag_B: "hash(s_out_B)"  # Different s_out → different secret_tag
    serial_id_B: 200
    enc_pack_attack: "attacker copies enc_pack_A to output_B"
    
  defense:
    - leaf_ad_B: "hash(asset_id_B || serial_id_B || ...)" → DIFFERENT from leaf_ad_A
    - pack_key_B: "hash(k || asset_id_B || serial_id_B)" → DIFFERENT from pack_key_A
    - result: "enc_pack_A decryption with pack_key_B FAILS (wrong key or MAC verification failure)"
    
  conclusion: "serial_id binding prevents cross-output enc_pack reuse"
```

**Mermaid Diagram: Serial ID Binding Chain**

```mermaid
flowchart TD
    SID[serial_id u32 LE] --> LEAFAD[leaf_ad derivation]
    AID[asset_id] --> LEAFAD
    RPUB[R_pub] --> LEAFAD
    TAG[owner_tag] --> LEAFAD
    COMMIT[C_amount] --> LEAFAD
    
    LEAFAD --> AEAD[enc_pack AEAD binding]
    
    K[k_dh] --> PACKKEY[pack_key derivation]
    AID --> PACKKEY
    SID --> PACKKEY
    
    PACKKEY --> AEAD
    
    LEAFAD --> NONCE[nonce derivation]
    RPUB --> NONCE
    AID --> NONCE
    SID --> NONCE
    
    NONCE --> AEAD
    
    AEAD --> CIPHER[enc_pack ciphertext]
    
    style SID fill:#ffcccc
    style AEAD fill:#ccffcc
    style CIPHER fill:#ccccff
```

---

**📋 Implementation Checklist: 4.3.2 Serial ID in Derivations**

- [x] **Verify `serial_id` is bound in ALL three derivation functions**
  - [x] `compute_leaf_ad(asset_id, serial_id: u32, r_pub, owner_tag, c_amount)` in `z00z_wallets::core::stealth::tag` — confirm `serial_id` is included in hash input
  - [x] `derive_pack_key(k_dh, asset_id, serial_id)` in `z00z_wallets::core::stealth::facade_kdf` — confirm `serial_id` is included
  - [x] `derive_pack_nonce(leaf_ad, r_pub, asset_id, serial_id)` in `z00z_wallets::core::stealth::facade_kdf` — confirm `serial_id` is included
  - [x] Run `grep -n 'serial_id' crates/z00z_wallets/src/core/stealth/facade_kdf.rs` — verify it appears as a hash input, not just a function argument that gets ignored
- [x] **`serial_id` LE encoding MUST be 4 bytes throughout derivations**
  - [x] In `compute_leaf_ad`: `serial_id.to_le_bytes()` produces exactly `[u8; 4]` — find and confirm this call
  - [x] In `derive_pack_key`: same — `serial_id.to_le_bytes()` passed as 4-byte slice
  - [x] In `derive_pack_nonce`: same
  - [x] Add comment at each site: `// LE encoding MUST match OWF circuit — always 4 bytes`
- [x] **Anti-replay test (integration)**
  - [x] Test `test_serial_binding_prevents_replay`: encrypt with `serial_id=42`, attempt decrypt with `leaf_ad` computed using `serial_id=43` → returns `None`
  - [x] Test `test_pack_key_differs_by_serial`: `derive_pack_key(k_dh, asset_id, 42)` != `derive_pack_key(k_dh, asset_id, 43)`
  - [x] Test `test_nonce_differs_by_serial`: `derive_pack_nonce(leaf_ad, r_pub, asset_id, 42)` != `derive_pack_nonce(leaf_ad, r_pub, asset_id, 43)`
- [x] **Mermaid diagram accuracy** — run the actual code and verify the binding chain matches the diagram:
  - [x] `serial_id → leaf_ad → AEAD`: verify `compute_leaf_ad` includes serial_id in its preimage bytes
  - [x] `serial_id → pack_key → AEAD`: verify `derive_pack_key` includes serial_id in its hash inputs
  - [x] `serial_id → nonce → AEAD`: verify `derive_pack_nonce` includes serial_id in its hash inputs

### PhasePhase 9 

### 4.3.3 Canonical Encoding Rules

**MUST Requirements for Consensus:**

```yaml
CanonicalEncoding:
  type: u32
  byte_length: 4 (fixed)
  endianness: little-endian (LE)
  
  examples:
    - value: 0
      bytes: [0x00, 0x00, 0x00, 0x00]
      
    - value: 1
      bytes: [0x01, 0x00, 0x00, 0x00]
      
    - value: 0x12345678
      bytes: [0x78, 0x56, 0x34, 0x12]
      verification: "0x78 + 0x56*256 + 0x34*256^2 + 0x12*256^3 = 0x12345678"
      
  forbidden:
    - big_endian: "REJECT [0x12, 0x34, 0x56, 0x78] for 0x12345678"
    - variable_length: "REJECT 1 byte [0x01] for serial_id=1"
    - padding: "REJECT 5 bytes [0x01, 0x00, 0x00, 0x00, 0x00]"
    
  owf_constraint:
    check: "OWF circuit MUST verify serial_id is 4 bytes LE in ALL hash derivations (leaf_ad, pack_key, nonce)"
    reason: "Non-canonical encoding breaks consensus (different hash outputs)"
    important: "serial_id is NOT part of asset_pack_plain (72 bytes = value+blinding+s_out only);"
    note: "serial_id appears in leaf_ad AAD and hash derivations — NOT in the encrypted plaintext"
```

**Rust Implementation:**

```rust
/// Serialize serial_id to canonical 4-byte LE
pub fn serialize_serial_id(serial_id: u32) -> [u8; 4] {
    serial_id.to_le_bytes()
}

/// Deserialize serial_id from canonical 4-byte LE
pub fn deserialize_serial_id(bytes: &[u8]) -> Result<u32, SerialIdError> {
    if bytes.len() != 4 {
        return Err(SerialIdError::InvalidLength {
            expected: 4,
            got: bytes.len(),
        });
    }
    
    let mut buf = [0u8; 4];
    buf.copy_from_slice(bytes);
    Ok(u32::from_le_bytes(buf))
}
```

**Example: OWF Constraint (Pseudocode):**

```rust
// Inside OWF circuit
fn verify_asset_pack_encoding(asset_pack_plain: &[u8]) -> Result<AssetPackFields, Error> {
    // AssetPackPlain: 72 bytes fixed — value(8) | blinding(32) | s_out(32)
    if asset_pack_plain.len() != 72 {
        return Err(Error::TruncatedAssetPack);
    }

    let mut cursor = 0;

    // value: 8 bytes (u64 LE)
    let value = u64::from_le_bytes(asset_pack_plain[cursor..cursor+8].try_into()?);
    cursor += 8;

    // blinding: 32 bytes (Pedersen scalar)
    let blinding = &asset_pack_plain[cursor..cursor+32];
    cursor += 32;

    // s_out: 32 bytes
    let s_out = &asset_pack_plain[cursor..cursor+32];
    // cursor + 32 = 72 (exact end)

    Ok(AssetPackFields { value, blinding, s_out })
}
```

---

**📋 Implementation Checklist: 4.3.3 Canonical Encoding Rules**

- [x] **Implement `serialize_serial_id(serial_id: u32) -> [u8; 4]`** in `z00z_core/src/assets/serial_id.rs` (or `encoding.rs`)
  - [x] Implementation: `serial_id.to_le_bytes()` — exactly 1 line, no branching
  - [x] NEVER use `to_be_bytes()` — add `#[cfg(test)]` assertion: `serialize_serial_id(0x12345678) == [0x78, 0x56, 0x34, 0x12]`
  - [x] Add `#[must_use]` on the function
- [x] **Implement `deserialize_serial_id(bytes: &[u8]) -> Result<u32, SerialIdError>`**
  - [x] Step 1: `if bytes.len() != 4 { return Err(SerialIdError::InvalidLength { expected: 4, got: bytes.len() }); }`
  - [x] Step 2: `let mut buf = [0u8; 4]; buf.copy_from_slice(bytes); Ok(u32::from_le_bytes(buf))`
  - [x] NEVER use `u32::from_be_bytes` — only LE
  - [x] `SerialIdError::InvalidLength { expected: usize, got: usize }` must exist in error enum
- [x] **OWF circuit encoding verification constants**
  - [x] Define `pub const SERIAL_ID_BYTE_LEN: usize = 4;` in `z00z_core/src/assets/serial_id.rs`
  - [x] Add doc comment: `// OWF circuit constraint: serial_id MUST be exactly 4 bytes LE — NOT in plaintext (in leaf_ad AAD)`
  - [x] Note at every usage: `serial_id` is in `leaf_ad` AAD and derivations — NOT in the 72-byte `asymmetric_pack_plain`
- [x] **Verify `AssetPackPlain` does NOT contain `serial_id`**
  - [x] `grep -n 'serial_id' crates/z00z_core/src/assets/leaf.rs` must show `serial_id` is NOT a field of `AssetPackPlain`
  - [x] `AssetPackPlain` is ONLY `{ value: u64, blinding: [u8;32], s_out: [u8;32] }` = 72 bytes
- [x] **OWF pseudocode verification**
  - [x] `verify_asset_pack_encoding(bytes: &[u8]) -> Result<AssetPackFields, Error>` — implement in `z00z_core/src/assets/wire.rs`
  - [x] Check `bytes.len() == 72` first — `Err(Error::TruncatedAssetPack)` if not
  - [x] `value = u64::from_le_bytes(bytes[0..8].try_into()?)` — consume 8 bytes
  - [x] `blinding = &bytes[8..40]` — consume 32 bytes
  - [x] `s_out = &bytes[40..72]` — consume 32 bytes, total = 72
- [x] **Unit tests** for encoding corner cases
  - [x] `test_canonical_zero`: `serialize_serial_id(0) == [0x00, 0x00, 0x00, 0x00]`
  - [x] `test_canonical_one`: `serialize_serial_id(1) == [0x01, 0x00, 0x00, 0x00]`
  - [x] `test_canonical_256`: `serialize_serial_id(256) == [0x00, 0x01, 0x00, 0x00]`
  - [x] `test_reject_5_bytes`: `deserialize_serial_id(&[0;5])` → `Err(InvalidLength)`
  - [x] `test_reject_3_bytes`: `deserialize_serial_id(&[0;3])` → `Err(InvalidLength)`
  - [x] `test_roundtrip_max`: `deserialize_serial_id(&serialize_serial_id(u32::MAX)) == Ok(u32::MAX)`

### 4.3.4 Serial ID API

> **NOTE:** `serial_id` is stored as plain `u32` directly. The `SerialId` newtype wrapper
> has been removed as redundant. In the codebase, `serial_id` appears as:
> - `pub serial_id: u32` in `z00z_core::assets::assets::Asset`
> - `pub serial_id: u32` in `z00z_core::assets::leaf::AssetLeaf`
> Canonical 4-byte little-endian encoding is enforced at the call sites.

#### 4.3.4.1 Integration with Existing Asset

> **NOTE (CURRENT STATE vs PROPOSAL):** The §4.3.4 note above confirms that `SerialId` newtype
> **does not exist in the current codebase** — `serial_id: u32` is used directly.
> The code below is a **FUTURE migration proposal** for introducing type-safety wrappers.
> Do NOT implement `SerialId` until the codebase state is reconciled.
> Canonical encoding (4-byte LE) is already enforced at call sites with plain `u32`.

**PROPOSED FUTURE: Extend `Asset` to use `SerialId` type wrapper (currently uses plain `u32`):**

```rust
// z00z_core/src/assets/assets.rs (MODIFY)

use crate::asset::serial_id::SerialId;

#[derive(Clone, serde::Serialize, serde::Deserialize)]
pub struct Asset {
    pub definition: Arc<AssetDefinition>,
    
    /// Serial ID (wrapped for type safety and canonical encoding)
    pub serial_id: SerialId,  // Previously: u32
    
    // ... other fields unchanged
}

impl Asset {
    /// Validate serial_id against asset definition bounds
    pub fn validate_serial_id(&self) -> Result<(), AssetError> {
        self.serial_id.validate_bounds(self.definition.serials)
            .map_err(|e| AssetError::InvalidSerialId(e))
    }
    
    /// Get asset pack version from serial_id
    pub fn asset_pack_version(&self) -> AssetPackVersion {
        self.serial_id.asset_pack_version()
    }
}
```

**Migration Strategy:**

1. **Task 1:** Introduce `SerialId` type, keep Asset using `u32` (backward compatible)
2. **Task 2:** Add `impl From<u32> for SerialId` conversions at boundaries
3. **Task 3:** Replace `serial_id: u32` → `serial_id: SerialId` in Asset struct
4. **Task 4:** Update all call sites to use `.as_u32()` or `.into()` where needed

---

**📋 Implementation Checklist: 4.3.4.1 Integration with Existing Asset**

- [ ] **DO NOT implement `SerialId` newtype yet** — read §4.3.4 NOTE before touching code
  - [ ] Verify `Asset.serial_id: u32` and `AssetLeaf.serial_id: u32` use plain `u32` in codebase
  - [ ] Verify `SerialId` newtype does NOT exist anywhere in `z00z_core`
  - [ ] All call sites MUST continue using raw `u32` until migration is explicitly approved
- [ ] **When 4-phase migration IS approved** (execute strictly in listed order):
  - [ ] **Task 1**: Create `z00z_core/src/assets/serial_id.rs` with `pub struct SerialId(u32)`
    - [ ] Methods: `fn new(val: u32) -> Self`, `fn as_u32(&self) -> u32`, `fn to_bytes_le(&self) -> [u8; 4]`, `fn from_bytes_le(b: [u8; 4]) -> Self`
    - [ ] Derive `Debug, Clone, Copy, PartialEq, Eq, Hash, Serialize, Deserialize`
    - [ ] Keep `Asset.serial_id: u32` unchanged in Phase 1 (backward compatible)
  - [ ] **Task 2**: Add `impl From<u32> for SerialId` and `impl From<SerialId> for u32`
  - [ ] **Task 3**: Replace `serial_id: u32` → `serial_id: SerialId` in `Asset` struct AND all related structs simultaneously
  - [ ] **Task 4**: Update all call sites — `grep -rn '\.serial_id' crates/z00z_core/src/` to find all sites; replace numeric access with `.serial_id.as_u32()` where `u32` is needed
- [ ] **Canonical encoding enforcement** (required NOW with plain `u32`, and after migration)
  - [ ] At every hash derivation using `serial_id`: call `serial_id.to_le_bytes()` — NEVER big-endian
  - [ ] Add comment at every derivation site: `// canonical LE encoding — MUST match OWF circuit`
  - [ ] Run `grep -rn 'serial_id' crates/z00z_core/src/` and audit every usage for correct LE encoding
- [ ] **Add integration test** (works today with plain `u32`, no SerialId needed)
  - [ ] `test_serial_derivation_differs`: compute `leaf_ad` with `serial_id=42` and `serial_id=43` → assert outputs differ

### PhasePhase 10 

### 4.3.5 Serial ID Testing

> ⚠️ **NOT YET IN CODEBASE.** All tests below reference the `SerialId` newtype
> (`SerialId::new()`, `.to_bytes_le()`, `.from_bytes_le()`, `.validate_bounds()`,
> `.asset_pack_version()`). Per §4.3.4 the `SerialId` wrapper has been removed —
> the codebase uses plain `u32`. **Do NOT implement `SerialId` until codebase
> reconciliation is complete (§4.3.4).** Tests below describe the PROPOSED future API only.

**Unit Tests:**

```rust
#[cfg(test)]
mod tests {
    use super::*;
    
    #[test]
    fn test_serial_id_canonical_encoding() {
        // Test canonical LE encoding
        assert_eq!(SerialId::new(0).to_bytes_le(), [0x00, 0x00, 0x00, 0x00]);
        assert_eq!(SerialId::new(1).to_bytes_le(), [0x01, 0x00, 0x00, 0x00]);
        assert_eq!(SerialId::new(256).to_bytes_le(), [0x00, 0x01, 0x00, 0x00]);
        assert_eq!(SerialId::new(0x12345678).to_bytes_le(), [0x78, 0x56, 0x34, 0x12]);
        
        // Verify big-endian is DIFFERENT (non-canonical)
        let be_bytes = 0x12345678u32.to_be_bytes();
        assert_ne!(SerialId::new(0x12345678).to_bytes_le(), be_bytes);
    }
    
    #[test]
    fn test_serial_id_roundtrip() {
        for value in [0, 1, 255, 256, 65535, 65536, u32::MAX] {
            let serial_id = SerialId::new(value);
            let bytes = serial_id.to_bytes_le();
            let roundtrip = SerialId::from_bytes_le(bytes);
            assert_eq!(serial_id, roundtrip);
        }
    }
    
    #[test]
    fn test_serial_id_from_slice() {
        // Valid 4-byte slice
        let bytes = [0x42, 0x00, 0x00, 0x00];
        let serial_id = SerialId::try_from_slice(&bytes).unwrap();
        assert_eq!(serial_id.as_u32(), 0x42);
        
        // Invalid lengths
        assert!(SerialId::try_from_slice(&[0x42]).is_err());  // Too short
        assert!(SerialId::try_from_slice(&[0x42, 0x00]).is_err());  // Too short
        assert!(SerialId::try_from_slice(&[0x42, 0x00, 0x00, 0x00, 0x00]).is_err());  // Too long
    }
    
    #[test]
    fn test_serial_id_bounds_validation() {
        let serial_id = SerialId::new(50);
        
        // Within bounds
        assert!(serial_id.validate_bounds(100).is_ok());
        assert!(serial_id.validate_bounds(51).is_ok());
        
        // Exceeds bounds
        assert!(serial_id.validate_bounds(50).is_err());
        assert!(serial_id.validate_bounds(30).is_err());
        
        // Edge cases
        let zero = SerialId::new(0);
        assert!(zero.validate_bounds(1).is_ok());
        assert!(zero.validate_bounds(0).is_err());  // 0 >= 0 → invalid
    }
    
    #[test]
    fn test_serial_id_version_detection() {
        // V1 range
        assert_eq!(SerialId::new(0).asset_pack_version(), AssetPackVersion::V1Basic);
        assert_eq!(SerialId::new(999_999).asset_pack_version(), AssetPackVersion::V1Basic);
        
        // V2 range
        assert_eq!(SerialId::new(1_000_000).asset_pack_version(), AssetPackVersion::V2Memo);
        assert_eq!(SerialId::new(1_999_999).asset_pack_version(), AssetPackVersion::V2Memo);
        
        // Unknown range
        assert_eq!(SerialId::new(2_000_000).asset_pack_version(), AssetPackVersion::Unknown);
        assert_eq!(SerialId::new(u32::MAX).asset_pack_version(), AssetPackVersion::Unknown);
    }
    
    #[test]
    fn test_serial_id_equality() {
        let a = SerialId::new(42);
        let b = SerialId::new(42);
        let c = SerialId::new(43);
        
        assert_eq!(a, b);
        assert_ne!(a, c);
    }
    
    #[test]
    fn test_serial_id_conversions() {
        // From u32
        let serial_id: SerialId = 42u32.into();
        assert_eq!(serial_id.as_u32(), 42);
        
        // To u32
        let value: u32 = serial_id.into();
        assert_eq!(value, 42);
    }
    
    #[test]
    fn test_serial_id_serialization() {
        // ⚠️ NOTE (ONE SOURCE OF TRUTH): Direct `serde_json` / `bincode` usage is shown here
        // for spec clarity only.  In production code always use z00z_utils::codec wrappers:
        //   use z00z_utils::codec::{Codec, JsonCodec, BincodeCodec};
        //   let json_bytes = JsonCodec.serialize(&serial_id)?;
        //   let via_bincode = BincodeCodec.serialize(&serial_id)?;
        let serial_id = SerialId::new(0x12345678);
        
        // JSON serialization (for configs) — MANDATORY: use z00z_utils::codec, NOT serde_json directly
        use z00z_utils::codec::{Codec, JsonCodec, BincodeCodec};
        let json_bytes = JsonCodec.serialize(&serial_id).expect("serialization must succeed");
        let deserialized: SerialId = JsonCodec.deserialize(&json_bytes).expect("deserialization must succeed");
        assert_eq!(serial_id, deserialized);
        
        // Binary serialization (for network/storage) — MANDATORY: use BincodeCodec, NOT bincode directly
        let bytes = BincodeCodec.serialize(&serial_id).expect("bincode serialize must succeed");
        let deserialized: SerialId = BincodeCodec.deserialize(&bytes).expect("bincode deserialize must succeed");
        assert_eq!(serial_id, deserialized);
    }
}
```

**Integration Tests:**

```rust
#[cfg(test)]
mod integration_tests {
    use super::*;
    use crate::assets::{Asset, AssetDefinition};
    use std::sync::Arc;
    
    #[test]
    fn test_asset_serial_id_validation() {
        let definition = Arc::new(AssetDefinition {
            id: "TEST".to_string(),
            serials: 1000,
            // ... other fields
        });
        
        // Valid serial_id
        let asset = Asset {
            definition: definition.clone(),
            serial_id: SerialId::new(500),
            // ... other fields
        };
        assert!(asset.validate_serial_id().is_ok());
        
        // Invalid serial_id (exceeds bounds)
        let invalid_asset = Asset {
            definition: definition.clone(),
            serial_id: SerialId::new(1000),  // >= serials
            // ... other fields
        };
        assert!(invalid_asset.validate_serial_id().is_err());
    }
    
    #[test]
    fn test_serial_id_in_derivations() {
        // IMPLEMENTED: compute_leaf_ad in z00z_wallets::core::stealth::tag
        use z00z_wallets::core::stealth::tag::compute_leaf_ad;
        
        let serial_id: u32 = 42;
        let asset_id = [0x11u8; 32];
        let r_pub    = [0x22u8; 32];
        let owner_tag = [0x33u8; 32];
        let c_amount  = [0x44u8; 32];
        
        // Derive leaf_ad (includes serial_id)
        let leaf_ad = compute_leaf_ad(&asset_id, serial_id, &r_pub, &owner_tag, &c_amount);
        
        // Different serial_id → different leaf_ad
        let serial_id2: u32 = 43;
        let leaf_ad2 = compute_leaf_ad(&asset_id, serial_id2, &r_pub, &owner_tag, &c_amount);
        
        assert_ne!(leaf_ad, leaf_ad2, "serial_id should affect leaf_ad");
    }
    
    #[test]
    fn test_asset_pack_version_workflow() {
        // V1 basic format
        let v1_serial = SerialId::new(100);
        assert_eq!(v1_serial.asset_pack_version(), AssetPackVersion::V1Basic);
        
        // Parse asset pack (72 bytes: value|blinding|s_out)
        let asset_pack_bytes = vec![
            vec![0x42; 8],   // value (u64 LE)
            vec![0x33; 32],  // blinding
            vec![0x11; 32],  // s_out
        ].concat();
        assert_eq!(asset_pack_bytes.len(), 72);
        
        // V2 memo format (future)
        let v2_serial = SerialId::new(1_000_000);
        assert_eq!(v2_serial.asset_pack_version(), AssetPackVersion::V2Memo);
        
        // Would parse extended format (not implemented yet)
    }
}
```

**Golden Test Vectors:**

```rust
#[cfg(test)]
mod golden_tests {
    use super::*;
    
    #[test]
    fn golden_vector_serial_id_encoding_1() {
        // Test vector 1: serial_id = 0
        let serial_id = SerialId::new(0);
        let expected = [0x00, 0x00, 0x00, 0x00];
        assert_eq!(serial_id.to_bytes_le(), expected);
    }
    
    #[test]
    fn golden_vector_serial_id_encoding_2() {
        // Test vector 2: serial_id = 0x12345678
        let serial_id = SerialId::new(0x12345678);
        let expected = [0x78, 0x56, 0x34, 0x12];  // LE
        assert_eq!(serial_id.to_bytes_le(), expected);
    }
    
    #[test]
    fn golden_vector_serial_id_in_leaf_ad() {
        // IMPLEMENTED: compute_leaf_ad in z00z_wallets::core::stealth::tag
        use z00z_wallets::core::stealth::tag::compute_leaf_ad;
        
        // Fixed inputs
        let asset_id  = [0x11u8; 32];
        let serial_id: u32 = 42;
        let r_pub     = [0x22u8; 32];
        let owner_tag = [0x33u8; 32];
        let c_amount  = [0x44u8; 32];
        
        // Compute leaf_ad using the canonical function
        let leaf_ad = compute_leaf_ad(&asset_id, serial_id, &r_pub, &owner_tag, &c_amount);
        
        let expected = hex::decode(
          "4b4608cb78886af9900eda26d588f16f605d831a11073aaecd090ece28216b09"
        ).unwrap();
        assert_eq!(leaf_ad, expected.as_slice(),
          "leaf_ad golden vector mismatch - check H_zk(LEAFAD) implementation");
    }
}
```

---

**📋 Implementation Checklist: 4.3.5 Serial ID Testing**

> ⚠️ All tests below use `SerialId` newtype (PROPOSED — §4.3.4). Use plain `u32` for all tests until SerialId migration is complete.

- [x] **Unit tests — canonical LE encoding** (`z00z_core/tests/assets/serial_id_encoding.rs`)
  - [x] `test_serial_id_canonical_encoding`: `u32::to_le_bytes(0) == [0x00;4]`; `(1) == [0x01,0,0,0]`; `(256) == [0,0x01,0,0]`; `(0x12345678) == [0x78,0x56,0x34,0x12]`
  - [x] `test_be_is_different`: `u32::to_be_bytes(0x12345678) != u32::to_le_bytes(0x12345678)` — explicitly confirm LE != BE
  - [x] `test_roundtrip_all_corners`: for values `[0, 1, 255, 256, 65535, 65536, u32::MAX]`: `u32::from_le_bytes(u32::to_le_bytes(v)) == v`
- [x] **Unit tests — from_slice / try_from_slice** (write via `deserialize_serial_id`)
  - [x] `test_from_slice_valid_4bytes`: `deserialize_serial_id(&[0x42, 0x00, 0x00, 0x00])` → `Ok(0x42)`
  - [x] `test_from_slice_reject_1byte`: `deserialize_serial_id(&[0x42])` → `Err(InvalidLength)` (not panic)
  - [x] `test_from_slice_reject_2bytes`: `deserialize_serial_id(&[0x42, 0x00])` → `Err(InvalidLength)`
  - [x] `test_from_slice_reject_5bytes`: `deserialize_serial_id(&[0x42, 0x00, 0x00, 0x00, 0x00])` → `Err(InvalidLength)`
- [x] **Unit tests — bounds validation** (use `validate_serial_bounds(serial_id: u32, max: u32) -> Result<(), SerialIdError>`)
  - [x] `test_valid_within_bounds`: serial=50, max=100 → `Ok(())`
  - [x] `test_invalid_equal_max`: serial=1000, max=1000 → `Err(...)` (`>= max` is invalid)
  - [x] `test_invalid_exceeds_max`: serial=1001, max=1000 → `Err(...)`
  - [x] `test_zero_serial_zero_max`: serial=0, max=0 → `Err(...)` (0 >= 0)
  - [x] `test_zero_serial_one_max`: serial=0, max=1 → `Ok(())` (0 < 1)
  - [x] `test_max_u32_serial`: serial=`u32::MAX`, max=`u32::MAX` → `Err(...)` (MAX >= MAX)
- [x] **Unit tests — version detection** (`validate_serial_id_version`)
  - [x] `test_v1_boundary_low`: `validate_serial_id_version(0) == AssetPackVersion::V1Basic`
  - [x] `test_v1_boundary_high`: `validate_serial_id_version(999_999) == AssetPackVersion::V1Basic`
  - [x] `test_v2_boundary_low`: `validate_serial_id_version(1_000_000) == AssetPackVersion::V2Memo`
  - [x] `test_v2_boundary_high`: `validate_serial_id_version(1_999_999) == AssetPackVersion::V2Memo`
  - [x] `test_unknown_start`: `validate_serial_id_version(2_000_000) == AssetPackVersion::Unknown` (no panic)
  - [x] `test_unknown_max`: `validate_serial_id_version(u32::MAX) == AssetPackVersion::Unknown` (no panic)
- [x] **Integration test — serial_id in `compute_leaf_ad`** (REAL current API)
  - [x] `test_serial_id_in_leaf_ad_differs`: call `compute_leaf_ad(&asset_id, 42, &r_pub, &owner_tag, &c_amount)` and `compute_leaf_ad(&asset_id, 43, ...)` → assert results differ
  - [x] Uses `z00z_wallets::core::stealth::tag::compute_leaf_ad` (real function)
  - [x] NEVER `rand::thread_rng()` — use `SystemRngProvider.rng()` if any RNG needed
- [x] **Serialization tests** (use `z00z_utils::codec`, NEVER `serde_json` directly)
  - [x] `test_json_roundtrip`: `JsonCodec.serialize(&42u32)` then `JsonCodec.deserialize(...)` → `Ok(42u32)`
  - [x] `test_bincode_roundtrip`: `BincodeCodec.serialize(&42u32)` then `BincodeCodec.deserialize(...)` → `Ok(42u32)`
- [x] **Golden test vectors — `leaf_ad`** (once real hash values are computed)
  - [x] Replace `BBBBBB...` placeholder in `golden_vector_serial_id_in_leaf_ad` with real value
  - [x] Method: run `cargo test golden_vector_serial_id_in_leaf_ad -- --nocapture` with fixed inputs, record output
  - [x] Store in `specs/009-z00z-ecc-spec-4/test_vectors/serial_id_leaf_ad.yaml`
  - [x] Add 2 more golden vectors: for `serial_id=0` and `serial_id=u32::MAX`

### 4.3.6 Serial ID Security Model

**Threat Analysis:**

```yaml
SerialIdSecurity:
  binding_property:
    threat: "Attacker copies enc_pack from output A to output B"
    defense: "serial_id included in pack_key and leaf_ad derivations"
    result: "Different serial_id → different keys → decryption failure"
    
  version_confusion:
    threat: "Malicious sender uses unknown serial_id version"
    defense: "Receiver rejects unknown versions (safe to skip)"
    impact: "Denial of service to sender (wasted on-chain space)"
    
  bounds_violation:
    threat: "serial_id exceeds asset definition max_serials"
    defense: "Validation at Asset creation and OWF verification"
    rejection: "Transaction rejected by aggregator before chain inclusion"
    
  canonical_encoding:
    threat: "Non-canonical encoding breaks consensus"
    defense: "OWF circuit enforces exactly 4 bytes LE"
    consequence: "Invalid asset_pack → proof verification failure"
```

**Invariants:**

```yaml
Invariants:
  MUST_1_canonical_encoding:
    rule: "serial_id MUST be encoded as exactly 4 bytes little-endian"
    enforced_by: "OWF circuit constraints"
    violated_if: "Variable length or big-endian encoding"
    
  MUST_2_bounds_check:
    rule: "serial_id < asset.definition.serials"
    enforced_by: "Asset validation and aggregator checks"
    violated_if: "serial_id >= max_serials"
    
  MUST_3_derivation_binding:
    rule: "serial_id MUST be included in leaf_ad, pack_key, nonce"
    enforced_by: "Hash functions and OWF circuit"
    violated_if: "Missing serial_id in derivation inputs"
    
  MUST_4_version_detection:
    rule: "Receiver MUST check serial_id version before parsing asset_pack"
    enforced_by: "Wallet scanning logic"
    violated_if: "Parsing unknown version without version check"
```

---

**📋 Implementation Checklist: 4.3.6 Serial ID Security Model**

- [ ] **MUST_1: Canonical 4-byte LE encoding — enforce at every derivation call site**
  - [ ] `grep -rn 'serial_id' crates/z00z_wallets/src/core/stealth/` — every occurrence that feeds into a hash MUST use `serial_id.to_le_bytes()`
  - [ ] Add `#[test] fn test_serial_id_encoding_is_le()` to verify 4-byte canonical encoding
  - [ ] Document in `z00z_core/src/assets/encoding.rs`: `// MUST_1 invariant: serial_id is always 4 bytes LE (OWF enforced)`
- [ ] **MUST_2: Bounds check `serial_id < definition.serials` — enforce before accepting any Asset**
  - [ ] Locate validation in `z00z_core/src/assets/wire.rs` or `assets.rs` — confirm exact condition is `<` not `<=`
  - [ ] Aggregator MUST call this check on every incoming output BEFORE writing to JMT
  - [ ] Add `#[test] fn test_must_2_bounds_check_enforced()`: create Asset with `serial_id >= definition.serials` → transaction rejected
- [ ] **MUST_3: serial_id included in `leaf_ad`, `pack_key`, `nonce` — verify via test**
  - [ ] `test_must_3_serial_binding`: for each of the 3 derivations, verify the output differs when `serial_id` changes by 1
  - [ ] `grep -rn 'derive_pack_key\|derive_pack_nonce\|compute_leaf_ad' crates/z00z_wallets/src/` — confirm all 3 consistently include `serial_id`
- [ ] **MUST_4: Version detection before parsing — enforce in receiver scanning loop**
  - [ ] In the wallet scanner (`z00z_wallets/src/core/stealth/`): detect version BEFORE calling `AssetPackPlain::from_bytes`
  - [ ] For `AssetPackVersion::Unknown`: log debug, skip output (do NOT panic, do NOT throw Err to user)
  - [ ] Add `#[test] fn test_must_4_unknown_version_skipped()`: unknown serial_id → scan skips output gracefully
- [ ] **Security invariants as compile-time/runtime constants**
  - [ ] Add module-level doc block in `z00z_core/src/assets/serial_id.rs`:
    - [ ] `/// INVARIANT_1: serial_id MUST be 4 bytes LE in all hash derivations`
    - [ ] `/// INVARIANT_2: serial_id < definition.serials (strict less-than)`
    - [ ] `/// INVARIANT_3: serial_id is bound in leaf_ad, pack_key, and nonce`
    - [ ] `/// INVARIANT_4: unknown serial_id versions are skipped in scanning`

---

## 4.4 Amount & Pedersen Commitments

**Purpose:** Hide transaction amounts while enabling cryptographic verification of balance conservation. Pedersen commitments provide **computational hiding** (amount privacy) and **homomorphic properties** (balance proofs without revealing values). Range proofs ensure non-negativity without revealing the actual amount.

**Critical Property:** Anti-burn guarantee from OWF proof: if output is accepted by consensus, receiver MUST be able to extract `(value, blinding, s_out)` from `enc_pack` and verify `C_amount = Commit(value, blinding)`. This prevents "externally valid but internally unspendable" attacks.

**Integration:** Extends existing `z00z_core::Asset` struct with cryptographic guarantees on the `amount`, `commitment`, and `range_proof` fields.

### PhasePhase 11 

### 4.4.1 Amount (v)

**Definition:** Transaction value in atomic units, represented as unsigned 64-bit integer.

**Canonical Representation:**

```yaml
Amount:
  type: u64
  range: [0, 2^64 - 1]
  max_value: 18_446_744_073_709_551_615
  encoding: 8 bytes little-endian (LE)
  
  atomic_units:
    description: "All amounts are in smallest indivisible units"
    example: "Bitasset satoshis (1 BTC = 100,000,000 satoshis)"
    display_conversion: "UI layer responsibility, NOT protocol"
    
  special_cases:
    zero_amount:
      allowed: true (for marker/burn outputs)
      dos_limit:
        max_per_block: 10
        max_per_tx: 2
        rationale: "Zero-value outputs cost minimal fees but consume JMT state slots permanently"
      security: "MUST enforce DoS limits on zero-amount outputs (proposed: max 10 per block, 2 per tx)"
    
    max_amount:
      value: 2^64 - 1
      rare_usage: "Theoretical maximum, practical amounts much smaller"
```

**Encoding Rules:**

```
v = 0          → [0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00]  (8 bytes LE)
v = 1          → [0x01, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00]
v = 1000       → [0xE8, 0x03, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00]
v = 2^32       → [0x00, 0x00, 0x00, 0x00, 0x01, 0x00, 0x00, 0x00]
v = 2^64 - 1   → [0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF]
```

**Rust Implementation:**

> **NOTE:** `amount` is stored as plain `u64` directly. An existing type alias
> `pub type Amount = u64` is available in `z00z_core::assets`
> (`z00z_core/src/assets/mod.rs`). The `Amount` struct newtype wrapper
> has been removed as redundant — use the existing type alias.

#### 4.4.1.1 Range Constraints

**Security Property:** All amounts MUST satisfy `0 ≤ v < 2^64` to prevent:

- Negative amounts (underflow attacks)
- Overflow in balance calculations
- Exceeding commitment arithmetic capacity

**Enforcement Layers:**

```yaml
RangeEnforcement:
  layer_1_type_system:
    type: u64 (unsigned)
    guarantee: "Cannot represent negative values"
    
  layer_2_range_proof:
    method: Bulletproofs+ with 64-bit range
    guarantee: "Cryptographically proves 0 ≤ v < 2^64"
    verification: "Aggregator checks range_proof before accepting output"
    
  layer_3_balance_check:
    constraint: "Σ inputs = Σ outputs (commitment balance)"
    guarantee: "No value creation/destruction in transaction"
    
  layer_4_arithmetic:
    method: "checked_add/checked_sub/checked_mul"
    guarantee: "Overflow/underflow detection in wallet logic"
```

**Example Validation:**

```rust
impl Asset {
    /// Validate amount constraints
    pub fn validate_amount(&self) -> Result<(), AssetError> {
        // Type system handles non-negativity (u64 is unsigned)
        
        // Range proof MUST exist
        if self.range_proof.is_none() {
            return Err(AssetError::MissingRangeProof);
        }
        
        // Verify range proof against commitment
        let commitment = &self.commitment;
        let proof = self.range_proof.as_ref().unwrap();
        
        z00z_crypto::verify_range_proof(
            proof,
            commitment,
            64,  // RANGE_PROOF_BITS_V1
            1,   // AGGREGATION_FACTOR
            0    // minimum_value_promise
        )?;
        
        Ok(())
    }
}
```

---

**📋 Implementation Checklist: 4.4.1.1 Range Constraints**

- [x] **Layer 1 — Type system** (verify existing code)
  - [x] Confirm ALL amount fields are `u64` (unsigned) — no `i64` or `isize` anywhere in amount handling paths
  - [x] `grep -rn 'i64\|isize' crates/z00z_core/src/assets/` must return 0 matches for amount fields
- [x] **Layer 2 — Range proof** (required for every new output)
  - [x] Define constants in `z00z_crypto/src/lib.rs`: `pub const RANGE_PROOF_BITS_V1: usize = 64;` and `pub const MIN_VALUE_PROMISE: u64 = 0;`
  - [x] Call `create_range_proof(amount, blinding, RANGE_PROOF_BITS_V1, MIN_VALUE_PROMISE)?` for every output
  - [x] Store result in `Asset.range_proof: Option<Vec<u8>>` field
- [x] **Layer 3 — Balance check** (aggregator responsibility)
  - [x] Implement `verify_tx_balance(inputs: &[Z00ZCommitment], outputs: &[Z00ZCommitment]) -> bool` in `z00z_core/src/tx/`
  - [x] Sum commitments using homomorphic addition: `Sigma_inputs == Sigma_outputs`
  - [x] Aggregator MUST reject tx if balance check fails
- [x] **Layer 4 — Checked arithmetic** (wallet responsibility)
  - [x] Use `u64::checked_add`, `checked_sub`, `checked_mul` for ALL amount arithmetic
  - [x] On `None`: return `AssetError::AmountOverflow` or `AssetError::AmountUnderflow`
  - [x] `grep -rn 'amount +\|amount -\|value +\|value -' crates/z00z_wallets/` — replace all bare arithmetic
- [x] **DoS limits** (define as constants)
  - [x] `pub const MAX_ZERO_OUT_PER_BLOCK: usize = 10;` in `z00z_rollup_node`
  - [x] `pub const MAX_ZERO_OUT_PER_TX: usize = 2;` in `z00z_rollup_node`
  - [x] Aggregator validates these limits before accepting outputs into rollup
- [x] **Implement `Asset::validate_amount(&self) -> Result<(), AssetError>`**
  - [x] Step 1: `self.range_proof.is_some()` check → `Err(AssetError::MissingRangeProof)` if None
  - [x] Step 2: Call `z00z_crypto::verify_range_proof(proof, &self.commitment, RANGE_PROOF_BITS_V1, 1, MIN_VALUE_PROMISE)?`
- [x] **Add unit tests**
  - [x] `test_zero_amount_accepted`: amount=0 with valid range proof → passes
  - [x] `test_max_u64_accepted`: amount=`u64::MAX` with valid range proof → passes
  - [x] `test_missing_range_proof_rejected`: asset without proof → `Err(MissingRangeProof)`
  - [x] `test_checked_add_overflow_returns_error`: `u64::MAX.checked_add(1)` → `None` → `AmountOverflow`

### PhasePhase 12 

### 4.4.2 Blinding Factor (r_out)

**Purpose:** Provide computational hiding for Pedersen commitments. The blinding factor `r_out` is a **secret scalar** that prevents commitment-based amount recovery.

**Definition:** 32-byte scalar sampled uniformly from Ristretto255 scalar field.

```yaml
BlindingFactor:
  type: RistrettoScalar
  # CODEBASE NOTE: there is NO Z00ZBlindingFactor type alias.
  # Real type is Z00ZScalar (= tari_crypto::ristretto::RistrettoSecretKey).
  # Use: use z00z_crypto::Z00ZScalar;
  size: 32 bytes (256 bits)
  field: ℤ/qℤ where q = 2^252 + 27742317777372353535851937790883648493 (Ristretto order)
  
  security:
    entropy: 256 bits minimum
    source: SystemRngProvider (OS CSPRNG)
    uniqueness: MUST be unique per commitment
    privacy: MUST NOT be reused across commitments
```

**Critical Security Properties:**

```yaml
BlindingFactorSecurity:
  uniqueness:
    threat: "Blinding factor reuse reveals amount differences"
    example: "C1 = Commit(v1, r), C2 = Commit(v2, r) → C1 - C2 = (v1-v2)·H (reveals Δv)"
    defense: "Generate fresh r_out for EVERY commitment"
    
  entropy:
    threat: "Weak RNG allows brute-force recovery of r_out"
    defense: "Use OS CSPRNG (getrandom/BCryptGenRandom/getentropy)"
    guarantee: "SystemRngProvider wraps OS CSPRNG with entropy validation"
    
  zeroization:
    threat: "Memory disclosure reveals r_out"
    defense: "Wrap in Hidden<Z00ZBlindingFactor>, zeroize on drop"
    guarantee: "Automatic memory clearing via zeroize crate"
```

#### 4.4.2.1 Generation

**Canonical Method:**

```rust
// CODEBASE NOTE: Z00ZBlindingFactor does NOT exist. Use Z00ZScalar.
// SystemRngProvider is a unit struct — no ::default() call needed.
use z00z_crypto::{Z00ZScalar, Hidden};
use z00z_utils::rng::{RngProvider, SystemRngProvider};

// Generate fresh blinding factor
let rng_provider = SystemRngProvider;
let mut rng = rng_provider.rng();

// Wrapped in Hidden for automatic zeroization
let blinding = Hidden::hide(Z00ZScalar::random(&mut rng));
```

**Complete Implementation:**

```rust
// z00z_core/src/assets/blinding.rs (PROPOSED — not yet implemented)
// NOTE: Z00ZBlindingFactor below is a proposed alias. Real type: Z00ZScalar.

use z00z_crypto::{Z00ZScalar, Hidden};
use z00z_utils::rng::{RngProvider, SystemRngProvider};
use thiserror::Error;
use zeroize::Zeroize;

/// Safe blinding factor generator with entropy validation
pub struct BlindingFactorGenerator {
    rng_provider: SystemRngProvider,
}

impl BlindingFactorGenerator {
    /// Create new generator with system entropy source
    // NOTE: SystemRngProvider is a unit struct — use struct literal, not ::default()
    pub fn new() -> Self {
        BlindingFactorGenerator {
            rng_provider: SystemRngProvider,
        }
    }
    
    /// Generate fresh blinding factor (wrapped in Hidden for safety)
    pub fn generate(&self) -> Hidden<Z00ZScalar> {
        let mut rng = self.rng_provider.rng();
        Hidden::hide(Z00ZScalar::random(&mut rng))
    }
    
    /// Generate multiple blinding factors (for batch processing)
    pub fn generate_batch(&self, count: usize) -> Vec<Hidden<Z00ZScalar>> {
        let mut rng = self.rng_provider.rng();
        (0..count)
            .map(|_| Hidden::hide(Z00ZScalar::random(&mut rng)))
            .collect()
    }
}

impl Default for BlindingFactorGenerator {
    fn default() -> Self {
        Self::new()
    }
}

#[derive(Debug, Error)]
pub enum BlindingError {
    #[error("Insufficient entropy")]
    InsufficientEntropy,
    
    #[error("RNG failure: {0}")]
    RngFailure(String),
}
```

**Usage Example (proposed — BlindingFactorGenerator not yet implemented):**

```rust
// NOTE: z00z_core::assets::blinding module does not exist yet.
// Direct use of Z00ZScalar is correct today:
use z00z_crypto::{Z00ZScalar, create_commitment};
use z00z_utils::rng::{RngProvider, SystemRngProvider};

let mut rng = SystemRngProvider.rng();
let r_out_1: Z00ZScalar = Z00ZScalar::random(&mut rng);  // Hidden<Z00ZScalar> in production
let r_out_2: Z00ZScalar = Z00ZScalar::random(&mut rng);  // Different, unique

// Use in commitment
let commitment = create_commitment(amount, &r_out_1)?;

// Wrap in Hidden<Z00ZScalar> for automatic zeroization in real code
```

---

**📋 Implementation Checklist: 4.4.2.1 Generation**

- [x] **`Z00ZScalar` is the correct type** — `Z00ZBlindingFactor` does NOT exist, never use it
  - [x] Confirm import: `use z00z_crypto::Z00ZScalar;`
  - [x] All blinding factor variables typed as `Z00ZScalar` or `Hidden<Z00ZScalar>`
- [x] **`SystemRngProvider` is a unit struct** — usage: `SystemRngProvider.rng()` (no `::default()`, no `::new()`)
- [x] **Production code MUST wrap blinding in `Hidden<Z00ZScalar>`**
  - [x] `let blinding = Hidden::hide(Z00ZScalar::random(&mut SystemRngProvider.rng()));`
  - [x] Access via `.reveal()` — returns `&Z00ZScalar`
- [x] **Implement `BlindingFactorGenerator` struct** in `z00z_core/src/assets/blinding.rs` (PROPOSED — create new file)
  - [x] `pub struct BlindingFactorGenerator;` (unit struct, no fields needed since `SystemRngProvider` is also a unit struct)
  - [x] `pub fn generate(&self) -> Hidden<Z00ZScalar>` → `Hidden::hide(Z00ZScalar::random(&mut SystemRngProvider.rng()))`
  - [x] `pub fn generate_batch(&self, count: usize) -> Vec<Hidden<Z00ZScalar>>`
  - [x] `impl Default for BlindingFactorGenerator { fn default() -> Self { Self } }`
- [x] **Add unit tests**
  - [x] `test_blinding_type_is_zscalar`: type check — `let _: Z00ZScalar = *blinding.reveal();`
  - [x] `test_blinding_uniqueness`: generate twice → `b1.reveal() != b2.reveal()`
  - [x] `test_hidden_wrapping`: use `Hidden::hide(...)` form, verify zeroize-on-drop (use `zeroize` crate)
  - [x] `test_batch_all_unique`: generate 100 → assert no duplicates

#### 4.4.2.2 Blinding Factor Arithmetic

**Homomorphic Operations:**

Blinding factors support addition and negation for commitment arithmetic:

```rust
// NOTE: Z00ZBlindingFactor does NOT exist. Use Z00ZScalar.
use z00z_crypto::Z00ZScalar;
// NOTE: SecretKey trait is re-exported from z00z_crypto.
// NEVER import tari_crypto directly — use z00z_crypto re-exports per project rules.
use z00z_crypto::SecretKeyTrait;  // re-export from z00z_crypto (not tari_crypto directly)

// Generate two blinding factors
let r1 = Z00ZScalar::random(&mut rng);
let r2 = Z00ZScalar::random(&mut rng);

// Addition: r_sum = r1 + r2
// NOTE: Z00ZScalar Add/Sub are implemented for references.
let r_sum = &r1 + &r2;

// Subtraction: r_diff = r1 - r2
let r_diff = &r1 - &r2;

// Negation: r_neg = -r1
// (Not directly supported, use scalar arithmetic if needed)
```

**Use Case:** Balance proofs in transactions

```
Transaction balance:
  Σ C_inputs = Σ C_outputs
  Σ Commit(v_in, r_in) = Σ Commit(v_out, r_out)
  
If v_in_total = v_out_total (no value creation):
  r_in_total = r_out_total (blinding factors must also balance)
```

---

**📋 Implementation Checklist: 4.4.2.2 Blinding Factor Arithmetic**

- [x] **`Z00ZScalar` Add/Sub use reference operands**
  - [x] `let r_sum = &r1 + &r2;`
  - [x] Add code comment at arithmetic sites about reference-based operations and minimal secret copies
- [ ] **Transaction blinding balance is a wallet responsibility**
  - [ ] For every tx: compute `r_change = r_in - r_out_payment` to maintain `Sigma r_in == Sigma r_out`
  - [x] Implement `fn balance_blindings(r_in: &Z00ZScalar, r_outs: &[Z00ZScalar]) -> Z00ZScalar` in `z00z_wallets/src/core/tx/`
    - [x] `r_outs.iter().fold(r_in.clone(), |acc, r| acc - r.clone())`
- [x] **NEVER import `tari_crypto` directly** — use `z00z_crypto` re-exports only
  - [x] `use z00z_crypto::SecretKeyTrait;` (NOT `use tari_crypto::keys::SecretKey`)
  - [x] Add to `z00z_crypto/src/lib.rs` if missing: `pub use tari_crypto::keys::SecretKey as SecretKeyTrait;`
- [x] **Add unit tests**
  - [x] `test_blinding_add_commutative`: `r1.clone()+r2.clone() == r2.clone()+r1.clone()`
  - [x] `test_blinding_sub`: `(r1.clone()+r2.clone()) - r2.clone() == r1`
  - [x] `test_tx_balance`: `r_in == r_out_payment.clone() + r_change.clone()`
  - [x] `test_homomorphic_balance`: `C(v1,r1)+C(v2,r2) == C(v1+v2, r1+r2)`

### PhasePhase 13 

### 4.4.3 Pedersen Commitment (C_amount)

**Definition:** Cryptographic commitment hiding transaction amount while enabling verification.

**Canonical Formula:**

```
C_amount = v·H + r_out·G
```

Where:

- `v` = amount (u64 scalar)
- `r_out` = blinding factor (RistrettoScalar)
- `G` = Ristretto basepoint (standard generator)
- `H` = Pedersen vector basepoint (nothing-up-my-sleeve construction)
- Output: 32-byte compressed Ristretto point

**Security Properties:**

```yaml
PedersenCommitmentSecurity:
  computational_hiding:
    property: "Commitment reveals no information about v"
    guarantee: "Discrete log hardness assumption"
    caveat: "ONLY if r_out is uniformly random and secret"
    
  perfect_binding:
    property: "Cannot create two different (v, r) pairs with same C"
    guarantee: "Mathematical impossibility (not computational)"
    implication: "Commitment uniquely determines (v, r_out)"
    
  homomorphic:
    property: "C(v1, r1) + C(v2, r2) = C(v1+v2, r1+r2)"
    use_case: "Balance proofs without revealing individual amounts"
    
  unlinkability:
    property: "Different r_out → unlinkable commitments (even for same v)"
    privacy: "Cannot link outputs by commitment value alone"
```

**Rust Implementation:**

> **STATUS: NOT YET IN CODEBASE.** `CommitmentOpening`, `commit_amount`, `Amount` helpers do not exist yet. `Z00ZBlindingFactor` also does not exist — use `Z00ZScalar`.  
> **IMPLEMENTED TODAY:** `create_commitment(value: u64, blinding: &Z00ZScalar) -> Result<Z00ZCommitment, CryptoError>` in `z00z_crypto`. Also `PedersenCommitmentFactory::commit_value(blinding: &K, value: u64) -> Z00ZCommitment` — **blinding is the FIRST parameter** per Tari API (panics on zero blinding). File path should be `z00z_core/src/assets/`.

```rust
// z00z_core/src/assets/commitment.rs (PROPOSED — not yet implemented)
// NOTE: Z00ZBlindingFactor does not exist. Use Z00ZScalar.
// NOTE: create_commitment returns Result<Z00ZCommitment, CryptoError>, not bare Z00ZCommitment.

use z00z_crypto::{Z00ZScalar, Z00ZCommitment, create_commitment, CryptoError};
use thiserror::Error;

/// Commitment result with both value and blinding (for opening)
#[derive(Clone)]
pub struct CommitmentOpening {
    pub commitment: Z00ZCommitment,
    pub value: u64,        // NOTE: Amount newtype not yet in codebase
    pub blinding: Z00ZScalar,
}

impl CommitmentOpening {
    /// Create new commitment with amount and blinding
    pub fn new(value: u64, blinding: Z00ZScalar) -> Result<Self, CryptoError> {
        let commitment = create_commitment(value, &blinding)?;
        Ok(CommitmentOpening { commitment, value, blinding })
    }
    
    /// Verify commitment opens correctly
    pub fn verify(&self) -> Result<bool, CryptoError> {
        let expected = create_commitment(self.value, &self.blinding)?;
        Ok(self.commitment == expected)
    }
    
    /// Get commitment bytes (for serialization/hashing)
    pub fn commitment_bytes(&self) -> &[u8] {
        self.commitment.as_bytes()
    }
}

/// Create Pedersen commitment from amount and blinding
pub fn commit_amount(value: u64, blinding: &Z00ZScalar) -> Result<Z00ZCommitment, CryptoError> {
    create_commitment(value, blinding)
}

/// Verify commitment opens to given amount and blinding
pub fn verify_commitment_opening(
    commitment: &Z00ZCommitment,
    value: u64,
    blinding: &Z00ZScalar,
) -> Result<bool, CryptoError> {
    let recomputed = create_commitment(value, blinding)?;
    Ok(commitment == &recomputed)
}

#[derive(Debug, Error)]
pub enum CommitmentError {
    #[error("Commitment does not open to provided (amount, blinding)")]
    InvalidOpening,
    
    #[error("Commitment arithmetic overflow")]
    ArithmeticOverflow,
}
```

#### 4.4.3.1 Commitment Creation Workflow

**Standard Flow:**

```mermaid
flowchart TD
    START["Start: Create Output"] --> AMOUNT["Generate amount v"]
    AMOUNT --> BLINDING["Generate blinding via SystemRngProvider"]
    BLINDING --> COMMIT["Compute commitment C: v·H + r·G"]
    COMMIT --> PROOF["Generate range proof for v"]
    PROOF --> PACK["Pack v, r, s_out into asset_pack_plain"]
    PACK --> ENCRYPT["Encrypt asset_pack_plain -> enc_pack"]
    ENCRYPT --> LEAF["Store C in UTXO leaf"]
    LEAF --> VERIFY["Receiver: decrypt enc_pack, recover v and r"]
    VERIFY --> OPEN["Receiver: verify commitment opens to (v, r)"]
    OPEN --> SUCCESS["Success: commitment opened"]

    style COMMIT fill:#ccffcc
    style OPEN fill:#ccffff
    style SUCCESS fill:#ccffcc
```

**Code Example (using real codebase — `Amount`/`BlindingFactorGenerator` not yet implemented):**

```rust
use z00z_crypto::{
    Z00ZScalar, Z00ZCommitment, Hidden,
    create_commitment, create_range_proof,
};
use z00z_utils::rng::{RngProvider, SystemRngProvider};

// Step 1: Amount (raw u64 — Amount newtype not yet in codebase)
let value: u64 = 1000;

// Step 2: Generate blinding (use Z00ZScalar directly)
// NOTE: SystemRngProvider is a unit struct
let mut rng = SystemRngProvider.rng();
let blinding = Hidden::hide(Z00ZScalar::random(&mut rng));

// Step 3: Create commitment — returns Result<Z00ZCommitment, CryptoError>
let commitment: Z00ZCommitment = create_commitment(value, blinding.reveal())?;

// Step 4: Generate range proof (64-bit)
let range_proof = create_range_proof(
    value,
    blinding.reveal(),
    64,  // RANGE_PROOF_BITS_V1
    0    // minimum_value_promise (Z00Z uses 0)
)?;

// Step 5: Store in AssetLeaf
// commitment → c_amount field ([u8;32])
// range_proof → range_proof field (Vec<u8>)
```

---

**📋 Implementation Checklist: 4.4.3.1 Commitment Creation Workflow**

- [x] **Step-by-step output creation workflow** (implement in `z00z_wallets/src/core/tx/builder.rs`)
  - [x] Step 1: Have `value: u64` (from user input or computed)
  - [x] Step 2: `let blinding = Hidden::hide(Z00ZScalar::random(&mut SystemRngProvider.rng()));`
  - [x] Step 3: `let commitment = create_commitment(value, blinding.reveal())?;` (blinding arg is `&Z00ZScalar`)
  - [x] Step 4: `let range_proof = create_range_proof(value, blinding.reveal(), RANGE_PROOF_BITS_V1, MIN_VALUE_PROMISE)?;`
  - [x] Step 5: Pack value and blinding into `AssetPackPlain { value, blinding: blinding.reveal().to_bytes(), s_out }`
  - [x] Step 6: Encrypt `AssetPackPlain` via `ZkPack::encrypt(...)` → `enc_pack` bytes
- [x] **`PedersenCommitmentFactory::commit_value(blinding, value)` argument order** — blinding is FIRST
  - [x] Never swap argument order — calling with wrong order panics if blinding is zero
  - [x] Prefer `create_commitment(value, blinding)` wrapper which has correct order
- [x] **Always use `?` on `create_commitment(...)` — NEVER `.unwrap()`**
- [x] **Add unit tests**
  - [x] `test_commitment_deterministic`: same (v, r) → same commitment bytes
  - [x] `test_commitment_different_blinding`: same v, different r → different commitment
  - [x] `test_roundtrip_create_open`: `create_commitment` then `verify_commitment_opening` → `true`
  - [x] `test_full_workflow`: steps 1-6 complete without error

#### 4.4.3.2 Homomorphic Properties

**Addition Property:**

```
C1 + C2 = Commit(v1, r1) + Commit(v2, r2)
        = (v1·H + r1·G) + (v2·H + r2·G)
        = (v1+v2)·H + (r1+r2)·G
        = Commit(v1+v2, r1+r2)
```

**Use Case:** Transaction balance proofs

```rust
// NOTE: commit_amount / Amount wrappers not yet in codebase.
// Real today: create_commitment(value: u64, blinding: &Z00ZScalar) -> Result<_, _>
use z00z_crypto::{Z00ZCommitment, create_commitment};

// Input commitments (unwrap for example brevity — use ? in production)
let c_in1 = create_commitment(1000, &r_in1).unwrap();
let c_in2 = create_commitment(500, &r_in2).unwrap();

// Output commitments
let c_out1 = create_commitment(800, &r_out1).unwrap();
let c_out2 = create_commitment(700, &r_out2).unwrap();

// Balance constraint (homomorphic verification)
let sum_inputs  = &c_in1 + &c_in2;    // Commit(1500, r_in1+r_in2)
let sum_outputs = &c_out1 + &c_out2;  // Commit(1500, r_out1+r_out2)

// If amounts balance (1000+500 = 800+700):
assert_eq!(sum_inputs, sum_outputs, "Commitment balance must hold");

// Note: blinding factors must also balance:
// r_in1 + r_in2 = r_out1 + r_out2
```

**Subtraction for Change Verification:**

```rust
// Alice sends 1000, receives change 200
let c_input   = create_commitment(1000, &r_in).unwrap();
let c_payment = create_commitment(800, &r_pay).unwrap();
let c_change  = create_commitment(200, &r_change).unwrap();

// Verify: c_input = c_payment + c_change
assert_eq!(c_input, &c_payment + &c_change);
```

---

**📋 Implementation Checklist: 4.4.3.2 Homomorphic Properties**

- [x] **`Z00ZCommitment` supports reference addition** `&c1 + &c2` — verify in `z00z_crypto`
  - [x] If `Add` for `&Z00ZCommitment` is not implemented, add `impl Add<&Z00ZCommitment> for &Z00ZCommitment` in `z00z_crypto`
- [x] **Implement `verify_tx_balance(inputs: &[Z00ZCommitment], outputs: &[Z00ZCommitment]) -> bool`** in `z00z_core/src/tx/`
  - [x] `let sum_in = inputs.iter().skip(1).fold(inputs[0].clone(), |acc, c| &acc + c);`
  - [x] `let sum_out = outputs.iter().skip(1).fold(outputs[0].clone(), |acc, c| &acc + c);`
  - [x] `sum_in == sum_out`
  - [x] Handle empty slices: return `true` for empty-vs-empty, `false` for empty-vs-nonempty
- [x] **Wallet MUST ensure blinding factors balance**: `Sigma r_in == Sigma r_out` (see §4.4.2.2)
- [x] **Add unit tests**
  - [x] `test_homomorphic_add`: `C(v1,r1)+C(v2,r2) == C(v1+v2, r1+r2)`
  - [x] `test_change_balance`: `C(1000,r_in) == C(800,r_pay) + C(200,r_change)`
  - [x] `test_balance_fails_on_mismatch`: sum_inputs != sum_outputs when amounts differ
  - [x] `test_empty_balance`: empty inputs and outputs → `true`

### PhasePhase 14 

### 4.4.4 Range Proofs (Bulletproofs+)

**Purpose:** Prove `0 ≤ v < 2^64` without revealing `v`. Prevents negative amounts and overflow attacks.

**Integration with Existing z00z_crypto:**

```rust
// IMPLEMENTED in z00z_crypto — real signatures:
// NOTE: Z00ZBlindingFactor does NOT exist. Use Z00ZScalar.
// NOTE: Z00ZRangeProof = Vec<u8>
use z00z_crypto::{create_range_proof, verify_range_proof, Z00ZRangeProof, Z00ZScalar, CryptoError};

pub fn create_range_proof(
    amount: u64,
    blinding: &Z00ZScalar,    // ← Z00ZScalar, not Z00ZBlindingFactor
    bits: usize,              // 64 for Z00Z
    minimum_value_promise: u64 // 0 for Z00Z
) -> Result<Z00ZRangeProof, CryptoError>;

pub fn verify_range_proof<C: VerifyCommitmentInput + ?Sized>(
    // NOTE: HomomorphicCommitment<Z00ZScalar> is NOT the real bound.
    // Actual bound is VerifyCommitmentInput + ?Sized (z00z_crypto::lib.rs:574).
    // Implementors: Z00ZCommitment, Result<Z00ZCommitment, CryptoError>.
    // &[u8; 32] does NOT implement VerifyCommitmentInput — use create_commitment() first.
    proof: &[u8],
    commitment: &C,
    bits: usize,
    aggregation_factor: usize,
    minimum_value_promise: u64
) -> Result<(), CryptoError>;
```

**Performance Characteristics (from z00z_crypto):**

```yaml
RangeProofPerformance:
  generation:
    64_bit_proof: "~6.5 ms (single, release mode)"
    2_bit_proof: "~457 μs"
    8_bit_proof: "~1.2 ms"
    debug_mode: "100x slower (NEVER use in production)"
    
  verification:
    single: "~6-10 ms"
    batch: "~0.5-2 ms per proof (amortized)"
    
  size:
    64_bit: "~700-800 bytes"
    128_bit: "~1400-1600 bytes (future V2)"
    max_allowed: "10 KB (DoS protection)"
```

#### 4.4.4.1 Range Proof Creation

**Standard Workflow (real codebase — `Amount`/`BlindingFactorGenerator` not yet implemented):**

```rust
// NOTE: Amount newtype and BlindingFactorGenerator not yet in codebase.
// Use raw u64 and Z00ZScalar directly.
use z00z_crypto::{Z00ZScalar, Hidden, create_commitment, create_range_proof};
use z00z_utils::rng::{RngProvider, SystemRngProvider};

// Create value and blinding
let value: u64 = 1000;
// NOTE: SystemRngProvider is a unit struct
let mut rng = SystemRngProvider.rng();
let blinding = Hidden::hide(Z00ZScalar::random(&mut rng));

// Create commitment — returns Result<Z00ZCommitment, CryptoError>
let commitment = create_commitment(value, blinding.reveal())?;

// Generate 64-bit range proof
let range_proof = create_range_proof(
    value,
    blinding.reveal(),
    64,  // RANGE_PROOF_BITS_V1
    0    // minimum_value_promise (Z00Z uses 0)
)?;

// Store in AssetLeaf (c_amount field holds commitment bytes)
// commitment → serialized to [u8;32] for c_amount
// range_proof → Vec<u8> stored in range_proof field
```

---

**📋 Implementation Checklist: 4.4.4.1 Range Proof Creation**

- [x] **Constants MUST be defined and used everywhere** (never hardcode)
  - [x] `pub const RANGE_PROOF_BITS_V1: usize = 64;` in `z00z_crypto/src/lib.rs`
  - [x] `pub const MIN_VALUE_PROMISE: u64 = 0;` in `z00z_crypto/src/lib.rs`
  - [x] `grep -rn '64.*range\|range.*64' crates/` — replace all hardcoded `64` with `RANGE_PROOF_BITS_V1`
- [x] **`SystemRngProvider` is a unit struct**: `SystemRngProvider.rng()` (no `::new()`, no `::default()`)
- [x] **`create_range_proof(value, blinding, bits, min_value)` call**
  - [x] arg 1: `value: u64` (raw integer, no Amount wrapper)
  - [x] arg 2: `blinding.reveal(): &Z00ZScalar`
  - [x] arg 3: `RANGE_PROOF_BITS_V1` (constant)
  - [x] arg 4: `MIN_VALUE_PROMISE` (constant)
  - [x] Always use `?` — NEVER `.unwrap()`
  - [x] Store result as `Vec<u8>` in `Asset.range_proof: Option<Vec<u8>>`
- [x] **Performance verification** (add `#[ignore]` benchmark test)
  - [x] Single 64-bit proof should complete in ~6.5ms in release mode
  - [x] Debug mode proof creation is ~100x slower — add guard: `#[cfg(not(debug_assertions))]` for prod paths
- [x] **Add unit tests**
  - [x] `test_range_proof_created`: `create_range_proof(1000, &blinding, 64, 0)?` → `Ok(proof_bytes)` with len > 0
  - [x] `test_range_proof_then_verify`: create proof then `verify_range_proof(...)` → `Ok(())`
  - [x] `test_zero_value_proof`: amount=0 → proof creation succeeds
  - [x] `#[ignore] test_bench_single_proof`: verify ~6.5ms (only run in CI release)

#### 4.4.4.2 Range Proof Verification

**Aggregator Side:**

```rust
use z00z_crypto::verify_range_proof;

// Extract from received output
let commitment = &output.commitment;
let range_proof = output.range_proof.as_ref()
    .ok_or(AssetError::MissingRangeProof)?;

// Verify proof
verify_range_proof(
    range_proof,
    commitment,
    64,  // expected bits
    1,   // aggregation_factor (no batching)
    0    // minimum_value_promise
)?;

// If verification succeeds:
// - Amount is in range [0, 2^64-1]
// - Commitment is correctly formed
// - Output accepted into rollup
```

**Batch Verification (Optimization):**

```rust
use z00z_crypto::batch_verify_range_proofs;

// Collect multiple outputs
let proofs: Vec<&RangeProof> = outputs.iter()
    .filter_map(|o| o.range_proof.as_ref())
    .collect();

let commitments: Vec<&Z00ZCommitment> = outputs.iter()
    .map(|o| &o.commitment)
    .collect();

// Verify all at once (faster than individual verification)
batch_verify_range_proofs(&proofs, &commitments, 64, 0)?;
```

---

**📋 Implementation Checklist: 4.4.4.2 Range Proof Verification**

- [x] **Check `range_proof.is_some()` FIRST before calling verify** — avoid unnecessary crypto work
  - [x] `let proof = output.range_proof.as_ref().ok_or(AssetError::MissingRangeProof)?;`
- [x] **`verify_range_proof(proof, commitment, bits, aggregation_factor, min_value)` call**
  - [x] arg 3: `RANGE_PROOF_BITS_V1` (64) — use constant, never hardcode
  - [x] arg 4: `1` for single output (aggregation_factor=1)
  - [x] arg 5: `MIN_VALUE_PROMISE` (0) — use constant
  - [x] Always use `?` — NEVER `.unwrap()`
- [x] **Implement `batch_verify_range_proofs` in aggregator** (`z00z_rollup_node/src/`)
  - [x] Collect `proofs: Vec<&Vec<u8>>` and `commitments: Vec<&Z00ZCommitment>` from all outputs
  - [x] Call `z00z_crypto::batch_verify_range_proofs(&proofs, &commitments, RANGE_PROOF_BITS_V1, MIN_VALUE_PROMISE)?;`
  - [x] Aggregation_factor=1 per proof (no aggregated multi-output proofs in V1)
- [x] **Add unit tests**
  - [x] `test_valid_proof_passes`: create proof then verify → `Ok(())`
  - [x] `test_tampered_proof_fails`: flip a byte in proof bytes → `Err(VerificationFailed)`
  - [x] `test_wrong_commitment_fails`: verify against different commitment → `Err`
  - [x] `test_batch_verify_multiple`: create 3 proofs, batch verify → `Ok(())`
  - [x] `test_batch_verify_one_bad_proof`: inject 1 tampered proof in batch → `Err`

### PhasePhase 15 

### 4.4.5 Integration with Asset Struct

**Extend Existing z00z_core::Asset:**

> **STATUS: PROPOSED.** `Amount`, `SerialId`, `BlindingFactorGenerator`, `Z00ZBlindingFactor` newtypes/wrappers are not yet in codebase. `create_commitment` returns `Result`. Use `Z00ZScalar` instead of `Z00ZBlindingFactor`.

```rust
// z00z_core/src/assets/assets.rs (PROPOSED)

impl Asset {
    /// Create new confidential output with amount hiding
    ///
    /// Generates commitment and range proof automatically.
    pub fn new_confidential(
        definition: Arc<AssetDefinition>,
        serial_id: SerialId,
        amount: Amount,
        nonce: Nonce,
    ) -> Result<(Self, Hidden<Z00ZScalar>), AssetError> {  // Z00ZScalar, not Z00ZBlindingFactor
        // Generate blinding factor
        // NOTE: BlindingFactorGenerator not yet in codebase — use SystemRngProvider directly
        let mut rng = z00z_utils::rng::SystemRngProvider.rng();
        let blinding = Hidden::hide(Z00ZScalar::random(&mut rng));
        
        // Create commitment — returns Result
        let commitment = create_commitment(amount.as_u64(), blinding.reveal())
            .map_err(|e| AssetError::CryptoError(e))?;
        
        // Generate range proof
        let range_proof = create_range_proof(
            amount.as_u64(),
            blinding.reveal(),
            64,
            0
        ).map_err(|e| AssetError::RangeProofCreation(e))?;
        
        let asset = Asset {
            definition,
            serial_id: serial_id.as_u32(),
            amount: amount.as_u64(),
            commitment,
            range_proof: Some(range_proof),
            nonce,
            lock_height: None,
            owner_pub: None,
            owner_signature: None,
            is_frozen: false,
            is_slashed: false,
            is_burned: false,
        };
        
        // Return asset and blinding (receiver needs for spending)
        Ok((asset, blinding))
    }
    
    /// Verify commitment opens to stored amount with provided blinding
    pub fn verify_commitment_opening(
        &self,
        blinding: &Z00ZScalar  // Z00ZScalar, not Z00ZBlindingFactor
    ) -> Result<(), AssetError> {
        let recomputed = create_commitment(self.amount, blinding)
            .map_err(|e| AssetError::CryptoError(e))?;
        
        if self.commitment != recomputed {
            return Err(AssetError::CommitmentMismatch {
                expected: self.commitment.clone(),
                got: recomputed,
            });
        }
        
        Ok(())
    }
    
    /// Verify range proof is valid
    pub fn verify_range_proof(&self) -> Result<(), AssetError> {
        let proof = self.range_proof.as_ref()
            .ok_or(AssetError::MissingRangeProof)?;
        
        verify_range_proof(
            proof,
            &self.commitment,
            64,
            1,
            0
        ).map_err(|e| AssetError::RangeProofVerification(e))?;
        
        Ok(())
    }
    
    /// Full validation: commitment + range proof
    pub fn validate_confidential(&self) -> Result<(), AssetError> {
        // verify_range_proof() already checks range_proof.is_none() and returns
        // Err(AssetError::MissingRangeProof) before calling into z00z_crypto.
        // A redundant is_none() guard here would be unreachable dead code.
        self.verify_range_proof()?;  // NOTE: method is verify_range_proof(), not validate_range_proof()
        Ok(())
    }
}
```

---

**📋 Implementation Checklist: 4.4.5 Integration with Asset Struct**

> ⚠️ All proposed types (`Amount`, `SerialId`, `BlindingFactorGenerator`, `Z00ZBlindingFactor`) do NOT exist. Use `u64`, `u32`, `Z00ZScalar`, `SystemRngProvider` instead.

- [x] **Implement `Asset::new_confidential` in `z00z_core/src/assets/assets.rs`**
  - [x] Signature: `pub fn new_confidential(definition: Arc<AssetDefinition>, serial_id: u32, amount: u64, nonce: [u8;32]) -> Result<(Self, Hidden<Z00ZScalar>), AssetError>`
  - [x] Step 1: Generate blinding: `let mut rng = z00z_utils::rng::SystemRngProvider.rng(); let blinding = Hidden::hide(Z00ZScalar::random(&mut rng));`
  - [x] Step 2: `let commitment = z00z_crypto::create_commitment(amount, blinding.reveal()).map_err(|e| AssetError::CryptoError(e))?;`
  - [x] Step 3: `let range_proof = z00z_crypto::create_range_proof(amount, blinding.reveal(), 64, 0).map_err(|e| AssetError::RangeProofCreation(e))?;`
  - [x] Step 4: Build `Asset { ..., serial_id, amount, commitment, range_proof: Some(range_proof), ... }`
  - [x] NEVER use `OsRng`, `thread_rng`, or `rand::rngs::OsRng` directly
  - [x] Import from `z00z_crypto`: `{Z00ZScalar, create_commitment, create_range_proof, Hidden}`
- [x] **Implement `Asset::verify_commitment_opening(&self, blinding: &Z00ZScalar) -> Result<(), AssetError>`**
  - [x] `let recomputed = z00z_crypto::create_commitment(self.amount, blinding).map_err(|e| AssetError::CryptoError(e))?;`
  - [x] `if self.commitment != recomputed { return Err(AssetError::CommitmentMismatch { expected: ..., got: recomputed }); }`
  - [x] `AssetError::CommitmentMismatch { expected: Z00ZCommitment, got: Z00ZCommitment }` must exist
- [x] **Implement `Asset::verify_range_proof(&self) -> Result<(), AssetError>`**
  - [x] `let proof = self.range_proof.as_ref().ok_or(AssetError::MissingRangeProof)?;`
  - [x] `z00z_crypto::verify_range_proof(proof, &self.commitment, 64, 1, 0).map_err(|e| AssetError::RangeProofVerification(e))?;`
- [x] **Implement `Asset::validate_confidential(&self) -> Result<(), AssetError>`**
  - [x] Body: `self.verify_range_proof()` — this is sufficient; `verify_range_proof` already checks `range_proof.is_none()`
  - [x] Do NOT add redundant `is_none()` check (it would be unreachable dead code)
- [x] **Add required `AssetError` variants** if not present in `z00z_core/src/assets/`:
  - [x] `MissingRangeProof`
  - [x] `CryptoError(z00z_crypto::CryptoError)` with `#[from]`
  - [x] `RangeProofCreation(z00z_crypto::CryptoError)` with context
  - [x] `RangeProofVerification(z00z_crypto::CryptoError)` with context
  - [x] `CommitmentMismatch { expected: Z00ZCommitment, got: Z00ZCommitment }`
- [x] **Unit tests**
  - [x] `test_new_confidential_success`: create asset → commitment opens, range proof verifies
  - [x] `test_verify_commitment_opening_correct`: correct blinding → `Ok(())`
  - [x] `test_verify_commitment_opening_wrong_blinding`: wrong blinding → `Err(CommitmentMismatch)`
  - [x] `test_missing_range_proof_rejected`: `Asset { range_proof: None, ... }.verify_range_proof()` → `Err(MissingRangeProof)`

### 4.4.6 Commitment API Summary

**Complete API:**

```rust
// z00z_core/src/assets/mod.rs (PROPOSED organization — not yet structured this way)
// NOTE: Amount, BlindingFactorGenerator, CommitmentOpening not yet in codebase.
// NOTE: Z00ZBlindingFactor does NOT exist in z00z_crypto — use Z00ZScalar.

pub mod amount;        // PROPOSED: Amount type
pub mod blinding;      // PROPOSED: BlindingFactorGenerator
pub mod commitment;    // PROPOSED: commit_amount, verify_commitment_opening

// Re-export from z00z_crypto (these ARE implemented)
pub use z00z_crypto::{
    Z00ZScalar,        // use this instead of Z00ZBlindingFactor
    Z00ZCommitment,
    Z00ZRangeProof,
    create_commitment,
    create_range_proof,
    verify_range_proof,
    batch_verify_range_proofs,
};
```

**Usage Examples:**

```rust
use z00z_core::asset::{Amount, BlindingFactorGenerator, commit_amount};
use z00z_crypto::{create_range_proof, Hidden};

// 1. Create confidential output
let amount = Amount::new(1000);
let generator = BlindingFactorGenerator::new();
let blinding = generator.generate();

let commitment = commit_amount(amount.as_u64(), blinding.reveal()).expect("commit_amount");
let range_proof = create_range_proof(amount.as_u64(), blinding.reveal(), 64, 0)?;

// 2. Receiver: verify commitment opens
use z00z_core::asset::commitment::verify_commitment_opening;

let is_valid = verify_commitment_opening(&commitment, amount.as_u64(), blinding.reveal())
    .expect("commitment opening check must not error");
assert!(is_valid, "Commitment must open correctly");

// 3. Homomorphic balance check
// NOTE: commit_amount returns Result<Z00ZCommitment, CryptoError> — must unwrap.
// NOTE: Amount::new(n) is a wrapper; commit_amount takes u64 — use .as_u64() or literal.
// NOTE: Add for Z00ZScalar requires owned values (clone the reveal() return).
let c1 = commit_amount(500u64, r1.reveal()).expect("commit c1");
let c2 = commit_amount(500u64, r2.reveal()).expect("commit c2");
let r_sum = r1.reveal().clone() + r2.reveal().clone();  // owned Z00ZScalar + Z00ZScalar
let c_sum = commit_amount(1000u64, &r_sum).expect("commit c_sum");

assert_eq!(&c1 + &c2, c_sum, "Homomorphic property");
```

---

**📋 Implementation Checklist: 4.4.6 Commitment API Summary**

- [x] **Public re-exports from `z00z_core/src/assets/mod.rs`** — verify ALL public API is accessible
  - [x] `pub use z00z_crypto::{Z00ZScalar, Z00ZCommitment, Z00ZRangeProof, create_commitment, create_range_proof, verify_range_proof, batch_verify_range_proofs};`
  - [x] `pub type Amount = u64;` alias in `z00z_core/src/assets/mod.rs` — confirm or create
  - [x] Do NOT re-export `tari_crypto`, `serde_json`, `serde_yaml`, or `bincode` directly
- [x] **Proposed submodule stubs** (PROPOSED — create stubs with TODO to unblock callers)
  - [x] `z00z_core/src/assets/amount.rs` — `pub type Amount = u64; pub const MAX_AMOUNT: u64 = u64::MAX;`
  - [x] `z00z_core/src/assets/blinding.rs` — stub `pub fn generate_blinding(rng: &mut impl RngCore) -> Hidden<Z00ZScalar>` using `SystemRngProvider`
  - [x] `z00z_core/src/assets/commitment.rs` — stub `pub fn commit_amount(v: u64, r: &Z00ZScalar) -> Result<Z00ZCommitment, CryptoError>` that wraps `z00z_crypto::create_commitment`
- [x] **Verify usage examples compile (doc tests)**
  - [x] Example 1 in spec: `commit_amount(amount, blinding.reveal())` — write as a `//´´´` doc test, run `cargo test --doc`
  - [x] Example 2: `verify_commitment_opening(&commitment, amount, blinding.reveal())` — same
  - [x] Example 3 (homomorphic): `let r_sum = &r1 + &r2; let c_sum = commit_amount(1000, &r_sum)` — verify reference arithmetic semantics for `Z00ZScalar`
  - [x] Confirm `Z00ZScalar` implements `Add` for references (`&Z00ZScalar + &Z00ZScalar -> Z00ZScalar`)
  - [x] Confirm `commit_amount` takes `&Z00ZScalar` (not owned)
- [x] **`verify_commitment_opening` function**
  - [x] Locate in `z00z_core` or `z00z_crypto` — confirm exact signature: `fn(commitment: &Z00ZCommitment, amount: u64, blinding: &Z00ZScalar) -> Result<bool, CryptoError>`
  - [x] Returns `Result<bool, CryptoError>`: `Ok(true)` = opens correctly; `Ok(false)` = wrong blinding/amount; `Err` = internal crypto error only
  - [x] NEVER panics on wrong input

### 4.4.7 Testing

> **NOTE:** Tests below use proposed types (`Amount`, `BlindingFactorGenerator`, `Z00ZBlindingFactor`, `CommitmentOpening`, `commit_amount`) — **none of these exist yet** in the codebase. `Z00ZBlindingFactor` must be changed to `Z00ZScalar` when implemented. `commit_amount` and `verify_commitment_opening` take `u64` (NOT `Amount`) — use `.as_u64()` when calling with `Amount` values. Real range proof and commitment functions ARE implemented in `z00z_crypto`.

**Unit Tests:**

```rust
#[cfg(test)]
mod tests {
    use super::*;
    
    #[test]
    fn test_amount_encoding() {
        assert_eq!(Amount::new(0).to_bytes_le(), [0x00; 8]);
        assert_eq!(Amount::new(1).to_bytes_le(), [0x01, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00]);
        assert_eq!(Amount::new(1000).to_bytes_le(), [0xE8, 0x03, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00]);
    }
    
    #[test]
    fn test_amount_arithmetic() {
        let a = Amount::new(100);
        let b = Amount::new(50);
        
        assert_eq!(a.checked_add(b), Some(Amount::new(150)));
        assert_eq!(a.checked_sub(b), Some(Amount::new(50)));
        assert_eq!(a.checked_mul(2), Some(Amount::new(200)));
        
        // Overflow
        let max = Amount::MAX;
        assert_eq!(max.checked_add(Amount::new(1)), None);
        
        // Underflow
        let zero = Amount::ZERO;
        assert_eq!(zero.checked_sub(Amount::new(1)), None);
    }
    
    #[test]
    fn test_blinding_factor_uniqueness() {
        let generator = BlindingFactorGenerator::new();
        
        let b1 = generator.generate();
        let b2 = generator.generate();
        
        // Should be different (with overwhelming probability)
        assert_ne!(b1.reveal(), b2.reveal());
    }
    
    #[test]
    fn test_commitment_creation() {
        let amount = Amount::new(1000);
        let generator = BlindingFactorGenerator::new();
        let blinding = generator.generate();
        
        let commitment = commit_amount(amount.as_u64(), blinding.reveal()).expect("commit");
        
        // Should be deterministic
        let commitment2 = commit_amount(amount.as_u64(), blinding.reveal()).expect("commit2");
        assert_eq!(commitment, commitment2);
        
        // Different blinding → different commitment
        let blinding3 = generator.generate();
        let commitment3 = commit_amount(amount.as_u64(), blinding3.reveal()).expect("commit3");
        assert_ne!(commitment, commitment3);
    }
    
    #[test]
    fn test_commitment_opening() {
        let amount = Amount::new(500);
        let generator = BlindingFactorGenerator::new();
        let blinding = generator.generate();
        
        let commitment = commit_amount(amount.as_u64(), blinding.reveal()).expect("commit");
        
        // Should open correctly — returns Ok(true)
        assert!(verify_commitment_opening(&commitment, amount.as_u64(), blinding.reveal())
            .expect("opening check must not error"));
        
        // Wrong amount → opening fails, returns Ok(false) (not Err)
        assert!(!verify_commitment_opening(&commitment, 501u64, blinding.reveal())
            .expect("opening check must not error on wrong amount"));
        
        // Wrong blinding → opening fails, returns Ok(false) (not Err)
        let wrong_blinding = generator.generate();
        assert!(!verify_commitment_opening(&commitment, amount.as_u64(), wrong_blinding.reveal())
            .expect("opening check must not error on wrong blinding"));
    }
    
    #[test]
    fn test_commitment_homomorphic() {
        let generator = BlindingFactorGenerator::new();
        
        // NOTE: commit_amount returns Result<Z00ZCommitment, CryptoError> — must unwrap.
        // NOTE: Amount::new(n) is a wrapper; commit_amount takes u64 — use .as_u64() or literal.
        // NOTE: r.reveal() returns &Z00ZScalar; Add for owned Z00ZScalar requires .clone().
        let v1 = 300u64;  // was Amount::new(300) — commit_amount takes u64
        let r1 = generator.generate();
        let c1 = commit_amount(v1, r1.reveal()).expect("commit c1");
        
        let v2 = 700u64;  // was Amount::new(700)
        let r2 = generator.generate();
        let c2 = commit_amount(v2, r2.reveal()).expect("commit c2");
        
        // Sum commitments
        let c_sum = &c1 + &c2;
        
        // Should equal commitment of sum
        // NOTE: SecretKey trait re-exported from z00z_crypto::SecretKeyTrait
        // NEVER use tari_crypto directly per project architecture rules.
        use z00z_crypto::SecretKeyTrait;
        let v_sum = v1 + v2;  // plain u64 add (was Amount::checked_add)
        let r_sum = r1.reveal().clone() + r2.reveal().clone();  // owned Z00ZScalar + Z00ZScalar
        let c_expected = commit_amount(v_sum, &r_sum).expect("commit c_expected");
        
        assert_eq!(c_sum, c_expected, "Homomorphic property must hold");
    }
    
    #[test]
    fn test_range_proof_creation() {
        let amount = Amount::new(1000);
        let generator = BlindingFactorGenerator::new();
        let blinding = generator.generate();
        
        let commitment = commit_amount(amount.as_u64(), blinding.reveal()).expect("commit");
        
        // Generate range proof
        let proof = create_range_proof(
            amount.as_u64(),
            blinding.reveal(),
            64,
            0
        ).expect("Range proof creation should succeed");
        
        // Verify it
        verify_range_proof(&proof, &commitment, 64, 1, 0)
            .expect("Range proof should verify");
    }
    
    #[test]
    fn test_range_proof_invalid_amount() {
        let generator = BlindingFactorGenerator::new();
        let blinding = generator.generate();
        
        // Create commitment with one amount
        let amount1 = Amount::new(1000);
        let commitment = commit_amount(amount1.as_u64(), blinding.reveal()).expect("commit");
        
        // Generate proof for different amount
        let amount2 = Amount::new(2000);
        let proof = create_range_proof(amount2.as_u64(), blinding.reveal(), 64, 0)
            .expect("Proof creation should succeed");
        
        // Verification should fail (proof doesn't match commitment)
        assert!(verify_range_proof(&proof, &commitment, 64, 1, 0).is_err());
    }
    
    #[test]
    fn test_asset_confidential_creation() {
        let definition = Arc::new(AssetDefinition::default());
        let serial_id = SerialId::new(0);
        let amount = Amount::new(1000);
        let nonce = [0x42; 32];
        
        let (asset, blinding) = Asset::new_confidential(
            definition,
            serial_id,
            amount,
            nonce
        ).expect("Asset creation should succeed");
        
        // Verify commitment opens
        asset.verify_commitment_opening(blinding.reveal())
            .expect("Commitment should open");
        
        // Verify range proof
        asset.verify_range_proof()
            .expect("Range proof should verify");
    }
}
```

**Integration Tests:**

```rust
#[cfg(test)]
mod integration_tests {
    use super::*;
    
    #[test]
    fn test_end_to_end_output_creation() {
        // Sender creates output
        let amount = Amount::new(5000);
        let generator = BlindingFactorGenerator::new();
        let blinding = generator.generate();
        
        let commitment = commit_amount(amount.as_u64(), blinding.reveal()).expect("commit");
        let range_proof = create_range_proof(amount.as_u64(), blinding.reveal(), 64, 0)
            .expect("Range proof creation");
        
        // Pack into asset_pack_plain (value, blinding, s_out)
        let s_out = [0x11u8; 32];
        let asset_pack = vec![
            amount.to_bytes_le().to_vec(),         // value (8 bytes LE)
            blinding.reveal().as_bytes().to_vec(), // blinding (32 bytes)
            s_out.to_vec(),                        // s_out (32 bytes)
        ].concat();

        assert_eq!(asset_pack.len(), 8 + 32 + 32);  // 72 bytes total

        // Receiver: extract from asset_pack (AssetPackPlain layout)
        let v_bytes = &asset_pack[0..8];
        let v_recovered = Amount::from_bytes_le(v_bytes.try_into().unwrap());
        let r_bytes = &asset_pack[8..40];
        let r_recovered = Z00ZScalar::try_from_bytes(r_bytes).unwrap();
        
        // Verify commitment opens
        assert_eq!(v_recovered, amount);
        assert_eq!(r_recovered.as_bytes(), blinding.reveal().as_bytes());
        
        let is_valid = verify_commitment_opening(&commitment, v_recovered.as_u64(), &r_recovered)
            .expect("commitment opening check must not error");
        assert!(is_valid, "Receiver must be able to open commitment");
    }
    
    #[test]
    fn test_transaction_balance() {
        let generator = BlindingFactorGenerator::new();
        
        // Input: 1000
        let v_in = Amount::new(1000);
        let r_in = generator.generate();
        let c_in = commit_amount(v_in.as_u64(), r_in.reveal()).expect("commit c_in");
        
        // Outputs: 600 + 400 = 1000
        let v_out1 = Amount::new(600);
        let r_out1 = generator.generate();
        let c_out1 = commit_amount(v_out1.as_u64(), r_out1.reveal()).expect("commit c_out1");
        
        let v_out2 = Amount::new(400);
        let r_out2 = generator.generate();
        let c_out2 = commit_amount(v_out2.as_u64(), r_out2.reveal()).expect("commit c_out2");
        
        // Balance check (homomorphic)
        let sum_outputs = &c_out1 + &c_out2;
        
        // This will FAIL because r_in != r_out1 + r_out2
        // Need to explicitly balance blinding factors:
        
        // NOTE: SecretKey trait re-exported from z00z_crypto::SecretKeyTrait
        // NEVER use tari_crypto directly per project architecture rules.
        use z00z_crypto::SecretKeyTrait;
        let r_sum_out = r_out1.reveal().clone() + r_out2.reveal().clone();
        
        // For balance to work, need: r_in = r_out1 + r_out2
        // In practice, wallet computes: r_out2 = r_in - r_out1
        let r_out2_computed = r_in.reveal().clone() - r_out1.reveal().clone();
        let c_out2_balanced = commit_amount(v_out2.as_u64(), &r_out2_computed).expect("commit c_out2_balanced");
        
        let sum_outputs_balanced = &c_out1 + &c_out2_balanced;
        assert_eq!(c_in, sum_outputs_balanced, "Transaction must balance");
    }
}
```

**Golden Test Vectors:**

```rust
#[cfg(test)]
mod golden_tests {
    use super::*;
    
    #[test]
    fn golden_vector_commitment_1() {
        // Fixed amount and blinding
        let amount = Amount::new(1000);
        let blinding_bytes = [0x42; 32];
        let blinding = Z00ZScalar::try_from_bytes(&blinding_bytes).unwrap();
        
        let commitment = commit_amount(amount.as_u64(), &blinding).expect("commit golden");
        
        // TODO: Replace placeholder with real computed value before enabling this test.
        // Run the test with fixed blinding_bytes=[0x42;32], amount=1000 and record output:
        //   cargo test golden_vector_commitment_1 -- --nocapture
        // Then substitute the real hex string below.
        // Currently this assertion will FAIL (0xCCCC is a placeholder, not a real commitment).
        let expected = hex::decode(
            "CCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCC"  // PLACEHOLDER
        ).unwrap();
        
        // assert_eq!(commitment.as_bytes(), expected.as_slice(),
        //     "Commitment golden vector mismatch");
        let _ = expected; // suppress unused warning until vector is filled
        let _ = commitment;
    }
    
    // TODO: Add 2-3 more golden vectors with different amounts/blindings
    // TODO: Sync with proof circuit implementation
}
```

---

**📋 Implementation Checklist: 4.4.7 Testing**

> ⚠️ All proposed types (`Amount`, `BlindingFactorGenerator`, `CommitmentOpening`) don't exist. Use `u64`, `SystemRngProvider`, `Z00ZScalar`. `Z00ZBlindingFactor` → `Z00ZScalar` everywhere.

- [x] **Unit test: `test_amount_encoding`** in `z00z_core/tests/assets/amount.rs`
  - [x] `u64::to_le_bytes(0) == [0x00; 8]`
  - [x] `u64::to_le_bytes(1) == [0x01, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00]`
  - [x] `u64::to_le_bytes(1000) == [0xE8, 0x03, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00]`
- [x] **Unit test: `test_amount_arithmetic`** (checked arithmetic)
  - [x] `100u64.checked_add(50) == Some(150)`
  - [x] `100u64.checked_sub(50) == Some(50)`
  - [x] `u64::MAX.checked_add(1) == None` (no panic)
  - [x] `0u64.checked_sub(1) == None` (no panic)
- [x] **Unit test: `test_blinding_factor_uniqueness`**
  - [x] `let mut rng = SystemRngProvider.rng(); let b1 = Z00ZScalar::random(&mut rng); let b2 = Z00ZScalar::random(&mut rng); assert_ne!(b1.as_bytes(), b2.as_bytes())`
  - [x] Import `z00z_utils::rng::SystemRngProvider` — NEVER `rand::thread_rng()`
- [x] **Unit test: `test_commitment_creation`**
  - [x] Create commitment twice with same args → results equal (deterministic)
  - [x] Create with different `Z00ZScalar` blinding → different commitment
  - [x] Use `z00z_crypto::create_commitment(amount, blinding: &Z00ZScalar)` — confirm returns `Result<Z00ZCommitment, CryptoError>`, use `.expect("commit")`
- [x] **Unit test: `test_commitment_opening`**
  - [x] Correct: `verify_commitment_opening(&commitment, amount, blinding.reveal()).expect("check") == true`
  - [x] Wrong amount: `verify_commitment_opening(&commitment, amount + 1, blinding.reveal()).expect("check") == false` (NOT `Err`)
  - [x] Wrong blinding: `verify_commitment_opening(&commitment, amount, wrong_blinding).expect("check") == false`
- [x] **Unit test: `test_commitment_homomorphic`**
  - [x] `c_sum = &c1 + &c2` where `c1 = commit(300, r1)`, `c2 = commit(700, r2)`
  - [x] `r_sum = &r1 + &r2` — reference arithmetic for `Z00ZScalar`
  - [x] `assert_eq!(c_sum, commit(1000, &r_sum))`
  - [x] Arithmetic uses `z00z_crypto` APIs only (no direct `tari_crypto`)
- [x] **Unit test: `test_range_proof_creation` + `test_range_proof_invalid_amount`**
  - [x] Create valid proof: `create_range_proof(1000, blinding, 64, 0)` → verify with `verify_range_proof(proof, commitment, 64, 1, 0)` → `Ok`
  - [x] Wrong commitment: proof for amount=1000, commitment for amount=2000 → `verify_range_proof` → `Err`
- [x] **Integration test: `test_end_to_end_output_creation`**
  - [x] Create `AssetPackPlain { value: 5000, blinding: [...], s_out: [...] }`
  - [x] Serialize to 72 bytes: `[value_le8 || blinding_32 || s_out_32]`
  - [x] Recover from bytes: `AssetPackPlain::from_bytes(&bytes)` → same struct
  - [x] Verify commitment opens after recovery
- [x] **Integration test: `test_transaction_balance`**
  - [x] Input: commit(1000, r_in); outputs: commit(600, r_out1) + commit(400, r_out2)
  - [x] Balance requires `r_in = r_out1 + r_out2` — compute `r_out2 = r_in - r_out1` explicitly
  - [x] `assert_eq!(c_in, &c_out1 + &c_out2_balanced)`
- [x] **Golden test vectors** — fill in placeholder values
  - [x] Run `golden_vector_commitment_1` with `amount=1000, blinding=[0x42;32]`, record real commitment bytes
  - [x] Replace `CCCC...` placeholder in the golden test with real bytes
  - [x] Store in `specs/009-z00z-ecc-spec-4/test_vectors/commitment_golden.yaml`
  - [x] Add 2 more golden vectors for `amount=0` and `amount=u64::MAX`

---

## 4.5 Asset Pack Plaintext (AssetPackPlain)

**Purpose:** The plaintext payload encrypted into `enc_pack` that carries asset ownership data from sender to receiver. Contains all information needed to reconstruct the Asset: asset secret, amount, blinding factor, and version identifier.

**Critical Property:** The asset pack structure and serialization MUST be **strictly canonical** (fixed field order, little-endian encoding, no padding) to ensure OWF circuit and wallet implementations agree bit-for-bit. Non-canonical encoding breaks consensus.

**Integration:** Bridges z00z_core asset types (AssetSecret, Amount, SerialId) with cryptographic encryption layer (ZkPack_v1). Used in both output creation (sender) and output scanning (receiver).

### PhasePhase 16 

### 4.5.1 AssetPackPlain Structure

> ⚠️ **SPEC ALIGNED WITH CODEBASE.**
>
> This section describes `AssetPackPlain` **as implemented** in `z00z_core::assets::leaf`:
> - **72 bytes**: `value: u64 (8B)` | `blinding: [u8;32] (32B)` | `s_out: [u8;32] (32B)`
> - **NO `serial_id` field** in the payload — `serial_id` is in `leaf_ad` (AEAD AAD) which
>   already cryptographically binds it; including it in plaintext is redundant for security.
> - **Field order**: `value` first, then `blinding`, then `s_out`
>
> Code reference: `z00z_core/src/assets/leaf.rs` — `AssetPackPlain` struct.

**Definition:** Fixed-length plaintext container for confidential output data.

**Required Fields:**

```yaml
AssetPackPlain:
  total_size: 72 bytes (fixed)

  fields:
    value:
      offset: 0
      size: 8 bytes
      type: u64 (LE)
      purpose: "Amount in atomic units"

    blinding:
      offset: 8
      size: 32 bytes
      type: "[u8; 32] (Pedersen blinding scalar bytes)"
      purpose: "Pedersen commitment blinding factor"

    s_out:
      offset: 40
      size: 32 bytes
      type: "[u8; 32]"
      purpose: "Asset output secret (derives secret_tag)"
```

**Memory Layout:**

```
Offset:  0      8                   40                   72
         |------|-------------------|---------------------|
Fields:  |v (8) |   blinding (32)   |     s_out (32)      |
Bytes:   [·····][···················][·····················]
```

**Rust Implementation:**

```rust
// z00z_core/src/assets/leaf.rs (IMPLEMENTED)
use thiserror::Error;
use zeroize::{Zeroize, ZeroizeOnDrop};

/// Asset pack plaintext — 72-byte payload encrypted inside ZkPack.
///
/// Wire format: value(8 LE) || blinding(32) || s_out(32) = 72 bytes fixed.
///
/// MUST be serialized canonically (fixed order, LE encoding, no padding).
#[derive(Clone, Debug, PartialEq, Eq, serde::Serialize, serde::Deserialize)]
pub struct AssetPackPlain {
    /// Amount in atomic units (u64 LE)
    pub value: u64,

    /// Pedersen commitment blinding scalar bytes
    pub blinding: [u8; 32],

    /// Asset output secret (derives secret_tag)
    pub s_out: [u8; 32],
}

impl AssetPackPlain {
    /// Fixed size of asset pack plaintext (72 bytes)
    pub const SIZE: usize = 8 + 32 + 32;

    /// Encode payload to canonical bytes.
    pub fn to_bytes(&self) -> Vec<u8> {
        let mut out = Vec::with_capacity(Self::SIZE);
        out.extend_from_slice(&self.value.to_le_bytes());
        out.extend_from_slice(&self.blinding);
        out.extend_from_slice(&self.s_out);
        out
    }

    /// Decode payload from canonical bytes.
    pub fn from_bytes(bytes: &[u8]) -> Option<Self> {
        if bytes.len() != Self::SIZE {
            return None;
        }
        let mut value_bytes = [0u8; 8];
        value_bytes.copy_from_slice(&bytes[0..8]);
        let mut blinding = [0u8; 32];
        blinding.copy_from_slice(&bytes[8..40]);
        let mut s_out = [0u8; 32];
        s_out.copy_from_slice(&bytes[40..72]);
        Some(Self {
            value: u64::from_le_bytes(value_bytes),
            blinding,
            s_out,
        })
    }
}

#[derive(Debug, Error)]
pub enum AssetPackError {
    #[error("Invalid length: expected {expected}, got {got}")]
    InvalidLength { expected: usize, got: usize },

    #[error("Malformed plaintext: {0}")]
    MalformedPlaintext(String),
}
```

#### 4.5.1.1 Version Detection

**Serial ID Ranges:**

```yaml
AssetPackVersions:
  V1_Basic:
    serial_id_range: [0, 999_999]
    size: 72 bytes (fixed)
    fields: "value, blinding, s_out"
    status: "Current, production-ready (serial_id is in leaf_ad AAD, not plaintext)"

  V2_Memo:
    serial_id_range: "[1_000_000, 1_999_999]"
    size: "Variable (72+ bytes)"
    fields: "value, blinding, s_out, memo_len, memo"
    status: "Future, not yet implemented"

  Unknown:
    serial_id_range: "[2_000_000+]"
    behavior: "Reject during parsing (safe to skip)"
    status: "Reserved for protocol upgrades"
```

**Detection Logic:**

```rust
// NOTE: AssetPackPlain has no serial_id field — version detection is done
// via the public AssetLeaf.serial_id field BEFORE decryption.
impl AssetPackPlain {
    /// Check if this asset pack bytes length is valid
    pub fn is_valid_length(bytes: &[u8]) -> bool {
        bytes.len() == Self::SIZE
    }
}
```

---

**📋 Implementation Checklist: 4.5.1.1 Version Detection**

- [x] **Version detection MUST happen via `AssetLeaf.serial_id` BEFORE decryption**
  - [x] Read `AssetLeaf.serial_id: u32` from the on-chain leaf BEFORE calling `ZkPack::decrypt`
  - [x] Call `validate_serial_id_version(leaf.serial_id)` to get `AssetPackVersion`
  - [x] Select decoding path based on `AssetPackVersion` value
  - [x] NEVER attempt decryption to detect format version
- [x] **`AssetPackPlain::is_valid_length(bytes: &[u8]) -> bool`**
  - [x] Returns `bytes.len() == Self::SIZE` where `Self::SIZE = 72`
  - [x] Call this BEFORE `from_bytes()` — bail out early if length is wrong
- [x] **`const SIZE: usize = 72`** MUST be defined as an associated constant on `AssetPackPlain`
  - [x] `pub const SIZE: usize = 8 + 32 + 32;` (value=8, blinding=32, s_out=32)
- [x] **Implement version-aware decoding** in wallet decoding path
  - [x] `AssetPackVersion::V1Basic` → decode with V1 layout (value | blinding | s_out, 72 bytes)
  - [x] `AssetPackVersion::V2Memo` → decode with V2 layout (future, document as TODO)
  - [x] `AssetPackVersion::Unknown` → log warning, skip output (do NOT error the whole tx)
- [x] **Add unit tests**
  - [x] `test_is_valid_length_72`: 72-byte slice → `true`
  - [x] `test_invalid_length_71`: 71-byte slice → `false`
  - [x] `test_invalid_length_0`: empty slice → `false`
  - [x] `test_version_from_serial_before_decrypt`: verify `serial_id` is read from `AssetLeaf`, not from decrypted payload

### 4.5.2 Canonical Serialization

**MUST Requirements:**

```yaml
CanonicalSerialization:
  field_order:
    MUST: "value → blinding → s_out (fixed order)"
    reason: "OWF circuit expects this exact order"
    enforcement: "Serialization function MUST NOT reorder fields"

  encoding:
    value: "8 bytes little-endian (u64::to_le_bytes)"
    blinding: "32 bytes raw scalar bytes"
    s_out: "32 bytes raw (no encoding)"

  padding:
    MUST_NOT: "No padding bytes between fields"
    reason: "Padding breaks OWF hash verification"

  length:
    fixed: "Exactly 72 bytes (reject if different)"
    reason: "Fixed-length parsing prevents buffer overflows"
```

**Serialization Implementation** (matches `z00z_core/src/assets/leaf.rs`):

```rust
impl AssetPackPlain {
    /// Serialize to canonical 72-byte Vec.
    ///
    /// Field order: value (8 LE) || blinding (32) || s_out (32)
    /// Total: 72 bytes fixed.
    pub fn to_bytes(&self) -> Vec<u8> {
        let mut out = Vec::with_capacity(Self::SIZE);
        out.extend_from_slice(&self.value.to_le_bytes());  // 8 bytes LE
        out.extend_from_slice(&self.blinding);              // 32 bytes
        out.extend_from_slice(&self.s_out);                 // 32 bytes
        out
    }
}
```

**Mermaid Diagram: Serialization Flow**

```mermaid
flowchart LR
    PACK[AssetPackPlain] --> VAL[value u64 → 8 bytes LE]
    PACK --> BLD[blinding 32 bytes]
    PACK --> SOUT[s_out 32 bytes]

    VAL --> BUF[Buffer 72 bytes]
    BLD --> BUF
    SOUT --> BUF

    BUF --> ENC[ZkPack_v1 encrypt]
    ENC --> CIPHER[enc_pack ciphertext]

    style PACK fill:#ccffcc
    style BUF fill:#ffffcc
    style CIPHER fill:#ccccff
```

---

**📋 Implementation Checklist: 4.5.2 Canonical Serialization**

- [x] **Constant `AssetPackPlain::SIZE: usize = 72`** defined in `z00z_core/src/assets/leaf.rs`
  - [x] Used in `to_bytes()` capacity reservation and `from_bytes()` length check
  - [x] Any change to this constant MUST be coordinated with OWF circuit team
- [x] **Implement `AssetPackPlain::to_bytes(&self) -> Vec<u8>`**
  - [x] `Vec::with_capacity(72)` + `extend_from_slice(&self.value.to_le_bytes())` (8B) + `extend_from_slice(&self.blinding)` (32B) + `extend_from_slice(&self.s_out)` (32B)
  - [x] NEVER use `to_be_bytes()` — always `to_le_bytes()` for `value: u64`
  - [x] NEVER reorder fields: `value FIRST, blinding SECOND, s_out THIRD`
  - [x] NEVER serialize via `serde_json`, `bincode`, or any codec — only manual `to_bytes()`
  - [x] NEVER add padding, alignment bytes, or length prefix
  - [x] Add doc comment: `/// Wire format (OWF consensus-critical): value[0..8 LE] | blinding[8..40] | s_out[40..72]`
- [x] **Implement `AssetPackPlain::from_bytes(bytes: &[u8]) -> Option<Self>`**
  - [x] First: `if bytes.len() != 72 { return None; }` — BEFORE reading any field
  - [x] `value = u64::from_le_bytes(bytes[0..8].try_into().ok()?)`
  - [x] `blinding = bytes[8..40].try_into().ok()?` — `[u8;32]`
  - [x] `s_out = bytes[40..72].try_into().ok()?` — `[u8;32]`
  - [x] Returns `None` on any wrong length — never panics on untrusted input
- [x] **Golden snapshot test** (OWF consensus-critical boundary)
  - [x] `test_field_offsets_golden`: `{ value: 1000, blinding: [0x22;32], s_out: [0x11;32] }.to_bytes()` — assert bytes[0..8] == `1000u64.to_le_bytes()`, bytes[8..40] == `[0x22;32]`, bytes[40..72] == `[0x11;32]`
  - [x] Use `insta::assert_debug_snapshot!` or explicit `assert_eq!` with hardcoded hex bytes
  - [x] CI MUST block merge if this test fails at any point in future
- [x] **Length invariant tests**
  - [x] `to_bytes().len() == 72` always — checked via type constraint
  - [x] `from_bytes`: 71B → `None`; 73B → `None`; 0B → `None`; 200B → `None`; 72B valid → `Some`

### 4.5.3 Bounded Parsing

**Security Principle:** NEVER use `unwrap()` or `expect()` on untrusted data. All parsing MUST be bounded with explicit length checks and graceful error handling.

**Parsing Rules:**

```yaml
BoundedParsing:
  length_check:
    MUST: "Verify total length == 72 bytes BEFORE parsing"
    reject_if: "length != 72 (truncated or oversized)"
    reason: "Prevents buffer overflow and DoS"

  field_extraction:
    method: "Slice with explicit bounds, use try_into()"
    MUST_NOT: "Use indexing without bounds check"
    MUST_NOT: "Use unwrap() on slice conversions"

  error_handling:
    invalid_length: "Return None / Err(AssetPackError::InvalidLength)"
    malformed_field: "Return Err(AssetPackError::MalformedPlaintext)"
```

**Deserialization Implementation** (matches `z00z_core/src/assets/leaf.rs`):

```rust
impl AssetPackPlain {
    /// Deserialize from canonical 72-byte slice (bounded parsing).
    ///
    /// Returns None if length != 72.
    pub fn from_bytes(bytes: &[u8]) -> Option<Self> {
        if bytes.len() != Self::SIZE {
            return None;
        }
        let mut value_bytes = [0u8; 8];
        value_bytes.copy_from_slice(&bytes[0..8]);
        let mut blinding = [0u8; 32];
        blinding.copy_from_slice(&bytes[8..40]);
        let mut s_out = [0u8; 32];
        s_out.copy_from_slice(&bytes[40..72]);
        Some(Self {
            value: u64::from_le_bytes(value_bytes),
            blinding,
            s_out,
        })
    }
}
```

#### 4.5.3.1 Length Validation

**Pre-parsing Check:**

```rust
impl AssetPackPlain {
    /// Check if bytes length is valid for AssetPackPlain
    pub fn is_valid_length(bytes: &[u8]) -> bool {
        bytes.len() == Self::SIZE  // 72
    }
}
```

**Example Usage:**

```rust
// Receiver: decrypt enc_pack → asset_pack_plain bytes
// ZkPack::decrypt returns Option<Vec<u8>> (None = tag mismatch or wrong version)
let plaintext_bytes = ZkPack::decrypt(k_dh, &leaf_ad, &r_pub, &asset_id, serial_id, &enc)
    .ok_or(WalletError::InvalidAssetPack("tag mismatch or version error"))?;

// Pre-validate length
if !AssetPackPlain::is_valid_length(&plaintext_bytes) {
    return Err(WalletError::InvalidAssetPack("wrong length"));
}

// Full parsing (version check done via AssetLeaf.serial_id before decryption)
let asset_pack = AssetPackPlain::from_bytes(&plaintext_bytes)
    .ok_or(WalletError::InvalidAssetPack("parse failed"))?;
```

---

**📋 Implementation Checklist: 4.5.3.1 Length Validation**

- [x] **`AssetPackPlain::is_valid_length(bytes: &[u8]) -> bool`**
  - [x] Located in `z00z_core/src/assets/leaf.rs` (or `wire.rs` — whichever owns `AssetPackPlain`)
  - [x] Implementation: `bytes.len() == Self::SIZE` where `SIZE = 72`
  - [x] `#[must_use]` annotation on the function
- [x] **Call order is mandatory**: check length BEFORE calling `from_bytes()`
  - [x] Pattern: `if !AssetPackPlain::is_valid_length(&plaintext_bytes) { return Err(WalletError::InvalidAssetPack("wrong length")); }`
  - [x] This check MUST appear before any `from_bytes()` call in all parse sites
  - [x] `grep -rn 'from_bytes' crates/z00z_wallets/src/` — verify ALL sites have pre-length-check
- [x] **`WalletError::InvalidAssetPack(msg: &'static str)` variant**
  - [x] Must exist in `z00z_wallets` error type or `z00z_core` error type
  - [x] Add if missing: `#[error("InvalidAssetPack: {0}")] InvalidAssetPack(&'static str)`
- [x] **Zero panics policy**: `from_bytes` MUST return `Option<AssetPackPlain>` (not panic)
  - [x] Verify `from_bytes` returns `None` for wrong-length input, never panics
- [x] **Add unit tests**
  - [x] `test_length_check_prevents_parse`: 71-byte input → `is_valid_length` returns false, error returned before parse
  - [x] `test_valid_length_allows_parse`: 72-byte valid bytes → parses successfully
  - [x] `test_oversized_rejected`: 73-byte input → `is_valid_length` returns false

#### 4.5.3.2 Fuzzing Targets

**Bounded Parsing Tests:**

```rust
#[cfg(test)]
mod fuzz_tests {
    use super::*;

    #[test]
    fn test_reject_truncated() {
        // 71 bytes (missing 1 byte)
        let truncated = vec![0u8; 71];
        assert!(AssetPackPlain::from_bytes(&truncated).is_none());

        // 50 bytes (heavily truncated)
        let truncated2 = vec![0u8; 50];
        assert!(AssetPackPlain::from_bytes(&truncated2).is_none());
    }

    #[test]
    fn test_reject_oversized() {
        // 73 bytes (1 extra byte)
        let oversized = vec![0u8; 73];
        assert!(AssetPackPlain::from_bytes(&oversized).is_none());

        // 100 bytes (much larger)
        let oversized2 = vec![0u8; 100];
        assert!(AssetPackPlain::from_bytes(&oversized2).is_none());
    }

    #[test]
    fn test_random_bytes_no_panic() {
        // MANDATORY: use z00z_utils::rng::SystemRngProvider, NOT rand::rngs::OsRng directly
        use rand::RngCore;
        use z00z_utils::rng::SystemRngProvider;
        let mut rng = SystemRngProvider.rng();

        // Try parsing 1000 random byte sequences of correct length
        for _ in 0..1000 {
            let mut random_bytes = vec![0u8; 72];
            rng.fill_bytes(&mut random_bytes);

            // Should not panic, always returns Some (no invalid field values in [u8;32])
            let _ = AssetPackPlain::from_bytes(&random_bytes);
        }
    }
}
```

---

**📋 Implementation Checklist: 4.5.3.2 Fuzzing Targets**

- [x] **`from_bytes` MUST NOT panic on ANY input bytes**
  - [x] Verify `AssetPackPlain::from_bytes(bytes: &[u8]) -> Option<AssetPackPlain>` returns `None`, never panics
  - [x] Add `#[test] fn test_from_bytes_no_panic_on_random()` with 1000 iterations of random 72-byte inputs
  - [x] Use `SystemRngProvider.rng()` for random bytes — NEVER `rand::thread_rng()`
- [x] **`from_bytes` with wrong length MUST return `None`** (not panic)
  - [x] Test: 71 bytes → `None`; 73 bytes → `None`; 0 bytes → `None`; 1 byte → `None`
- [x] **Add to CI fuzz test suite** in `.cargo/fuzz/` or dedicated fuzz crate
  - [x] Create `fuzz_target_asset_pack_from_bytes` fuzz target in `z00z_core/fuzz/` if it doesn't exist
  - [x] Target: call `AssetPackPlain::from_bytes(data)` on any `data: &[u8]` — must not panic
  - [ ] Fuzz budget: minimum 1 million iterations in CI before merging
- [x] **Add bounded parsing stress test**
  - [x] `test_reject_all_truncated_lengths`: test lengths 0..71 all return `None` from `from_bytes`
  - [x] `test_reject_all_oversized_lengths`: test lengths 73..200 all return `None`
- [x] **Verify no unsafe code** in `from_bytes`: `#![forbid(unsafe_code)]` in the module

### PhasePhase 17 

### 4.5.4 AssetPackPlain API

**Complete API** (matches `z00z_core/src/assets/leaf.rs`):

```rust
// z00z_core/src/assets/leaf.rs (IMPLEMENTED)

// Helper functions
pub fn serialize_asset_pack(pack: &AssetPackPlain) -> Vec<u8> {
    pack.to_bytes()
}

pub fn deserialize_asset_pack(bytes: &[u8]) -> Option<AssetPackPlain> {
    AssetPackPlain::from_bytes(bytes)
}

pub fn is_valid_asset_pack_length(bytes: &[u8]) -> bool {
    bytes.len() == AssetPackPlain::SIZE
}
```

**Example Workflows:**

**Sender (Output Creation):**

```rust
use z00z_core::assets::leaf::AssetPackPlain;

// Create asset pack from known values
let asset_pack = AssetPackPlain {
    value: 1000,
    blinding: blinding_scalar.to_bytes(),
    s_out: s_out_bytes,  // TODO: currently placeholder [0xABu8; 32] in tx/mod.rs
};

// Serialize for encryption
let plaintext_bytes = asset_pack.to_bytes();
assert_eq!(plaintext_bytes.len(), 72);

// Encrypt with ZkPack_v1.
// API is infallible (returns ZkPackEncrypted directly — no Result/? needed).
// On internal cipher error: returns ZkPackEncrypted { version:1, ciphertext: vec![], tag:[0;16] }.
// In practice unreachable: valid 32-byte key + 12-byte nonce never fails ChaCha20Poly1305.
let enc = ZkPack::encrypt(k_dh, &leaf_ad, &r_pub, &asset_id, serial_id, &plaintext_bytes);
```

**Receiver (Output Scanning):**

```rust
use z00z_core::assets::leaf::AssetPackPlain;

// Decrypt enc_pack (ZkPack::decrypt returns Option<Vec<u8>>; None on tag/version failure)
let plaintext_bytes = ZkPack::decrypt(k_dh, &leaf_ad, &r_pub, &asset_id, serial_id, &enc)
    .ok_or(WalletError::InvalidAssetPack("tag mismatch or version error"))?;

// Bounded parsing — returns None if length != 72
let asset_pack = AssetPackPlain::from_bytes(&plaintext_bytes)
    .ok_or(WalletError::InvalidAssetPack("invalid length or format"))?;

// Extract values
let value    = asset_pack.value;    // u64
let blinding = asset_pack.blinding; // [u8; 32] — raw scalar bytes
let s_out    = asset_pack.s_out;    // [u8; 32]

// Convert blinding bytes to Z00ZScalar before commitment verification
// AEAD already authenticated the plaintext, so these bytes are trusted.
let blinding_scalar = Z00ZScalar::try_from_bytes(&blinding)
    .map_err(|_| WalletError::InvalidAssetPack("invalid blinding scalar bytes"))?;

// Verify commitment opens — returns Result<bool, CryptoError>; unwrap_or(false) on crypto error
let commitment_opens = verify_commitment_opening(&leaf.c_amount, value, &blinding_scalar)
    .unwrap_or(false);
if !commitment_opens {
    return Err(WalletError::CommitmentMismatch);
}
```

---

**📋 Implementation Checklist: 4.5.4 AssetPackPlain API**

- [x] **Sender path** (in `z00z_wallets/src/core/tx/mod.rs`)
  - [x] **🚨 BLOCKER-1 fixed**: removed `s_out: [0xABu8; 32]` placeholder in `tx/mod.rs`
  - [x] Derive real `s_out`: `hash_zk::<SOutProdDomain>("Z00Z/S_OUT", &[k_dh, r_pub, &serial_id.to_le_bytes()])` — store 32-byte result
  - [x] `s_out` is unique per output (domain-separated hash over `k_dh`, `r_pub`, `serial_id`)
  - [x] Build: `AssetPackPlain { value, blinding: blinding_scalar_bytes, s_out }` — 72B via `to_bytes()`
  - [x] Encrypt: `ZkPack::encrypt(k_dh, &leaf_ad, &r_pub_bytes, &asset_id, serial_id, &plaintext)` — 6 args
  - [x] Store `ZkPackEncrypted` in `AssetLeaf.enc_pack`
- [x] **Receiver path** (in `z00z_wallets/src/core/stealth/scan.rs` or similar)
  - [x] Recompute `leaf_ad` from `AssetLeaf` fields BEFORE decrypt
  - [ ] Decrypt: `ZkPack::decrypt(k_dh, &leaf_ad, &r_pub_bytes, &asset_id, serial_id, &enc).ok_or(WalletError::InvalidAssetPack("tag mismatch"))?`
  - [x] Parse: `AssetPackPlain::from_bytes(&plaintext_bytes).ok_or(WalletError::InvalidAssetPack("invalid length"))?`
  - [x] Convert scalar: `Z00ZScalar::try_from_bytes(&pack.blinding).map_err(|_| WalletError::InvalidAssetPack("invalid blinding"))?`
  - [x] Verify: `verify_commitment_opening(&leaf.c_amount, pack.value, &blinding_scalar).unwrap_or(false)` — `unwrap_or(false)` on crypto error, NOT panic
  - [x] If `!commitment_opens`: `return Err(WalletError::CommitmentMismatch)`
- [x] **🚨 BLOCKER: Remove legacy sender path (§4.0.2 BLOCKER-2)**
  - [x] `encrypt_asset_pack` removed from `output.rs`
  - [x] Legacy `derive_tag16` variant with `c_amount=[0u8;32]` + `out_index` binding removed
  - [x] `build_tx_stealth_output` migrated to `ZkPack::encrypt` + `AssetPackPlain::to_bytes()`
  - [x] Legacy `aead::seal` / `Z00Z_ASSET_PACK_AAD` payload path removed
  - [x] Callers may continue using `build_tx_stealth_output` compatibility API (now non-legacy)
- [x] **Helper functions** in `z00z_core/src/assets/leaf.rs`
  - [x] `pub fn serialize_asset_pack(pack: &AssetPackPlain) -> Vec<u8>` — delegates to `pack.to_bytes()`
  - [x] `pub fn deserialize_asset_pack(bytes: &[u8]) -> Option<AssetPackPlain>` — delegates to `from_bytes`
  - [x] `pub fn is_valid_asset_pack_length(bytes: &[u8]) -> bool` = `bytes.len() == AssetPackPlain::SIZE`
- [x] **Integration test: `test_sender_receiver_roundtrip`**
  - [x] Sender: fill `AssetPackPlain` → encrypt → `ZkPackEncrypted`
  - [x] Receiver: decrypt → parse → verify commitment opens → all fields match original

### 4.5.5 Testing

**Unit Tests:**

```rust
#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_asset_pack_creation() {
        let pack = AssetPackPlain {
            value: 1000,
            blinding: [0x22; 32],
            s_out: [0x11; 32],
        };

        assert_eq!(pack.value, 1000);
        assert_eq!(pack.blinding, [0x22; 32]);
        assert_eq!(pack.s_out, [0x11; 32]);
    }

    #[test]
    fn test_asset_pack_serialization() {
        let pack = AssetPackPlain {
            value: 1000,
            blinding: [0x22; 32],
            s_out: [0x11; 32],
        };

        let bytes = pack.to_bytes();
        assert_eq!(bytes.len(), 72);

        // Check field positions: value(8) | blinding(32) | s_out(32)
        assert_eq!(&bytes[0..8], &1000u64.to_le_bytes());   // value
        assert_eq!(&bytes[8..40], &[0x22; 32]);              // blinding
        assert_eq!(&bytes[40..72], &[0x11; 32]);             // s_out
    }

    #[test]
    fn test_asset_pack_roundtrip() {
        let pack = AssetPackPlain {
            value: 5000,
            blinding: [0x33; 32],
            s_out: [0x11; 32],
        };

        let bytes = pack.to_bytes();
        let pack2 = AssetPackPlain::from_bytes(&bytes).unwrap();

        assert_eq!(pack, pack2);
    }

    #[test]
    fn test_asset_pack_bounded_parsing() {
        // Valid length
        assert!(AssetPackPlain::from_bytes(&[0u8; 72]).is_some());

        // Invalid lengths
        assert!(AssetPackPlain::from_bytes(&[0u8; 71]).is_none());
        assert!(AssetPackPlain::from_bytes(&[0u8; 73]).is_none());
        assert!(AssetPackPlain::from_bytes(&[0u8; 0]).is_none());
        assert!(AssetPackPlain::from_bytes(&[0u8; 200]).is_none());
    }
}
```

**Integration Tests:**

```rust
#[cfg(test)]
mod integration_tests {
    use super::*;

    #[test]
    fn test_asset_pack_in_output_workflow() {
        let pack = AssetPackPlain {
            value: 5000,
            blinding: [0x42; 32],
            s_out: [0x11; 32],
        };

        let plaintext = pack.to_bytes();
        assert_eq!(plaintext.len(), AssetPackPlain::SIZE);

        // Simulate receiver parsing
        let recovered = AssetPackPlain::from_bytes(&plaintext)
            .expect("Should parse valid asset pack");

        assert_eq!(recovered.value, 5000);
        assert_eq!(recovered.blinding, [0x42; 32]);
        assert_eq!(recovered.s_out, [0x11; 32]);
    }
}
```

**Golden Test Vectors:**

```rust
#[cfg(test)]
mod golden_tests {
    use super::*;

    #[test]
    fn golden_asset_pack_72b() {
        let pack = AssetPackPlain {
            value: 1000,
            blinding: [0x22; 32],
            s_out: [0x11; 32],
        };

        let bytes = pack.to_bytes();

        // Expected: value(8 LE) || blinding(32) || s_out(32) = 72 bytes
        let expected = hex::decode(
            concat!(
                "E803000000000000",  // value = 1000 LE
                "2222222222222222222222222222222222222222222222222222222222222222",  // blinding
                "1111111111111111111111111111111111111111111111111111111111111111"   // s_out
            )
        ).unwrap();

        assert_eq!(bytes, expected,
            "AssetPackPlain golden vector mismatch - check serialization");
    }

    // TODO: Add more golden vectors with different amounts/blindings
    // TODO: Sync with OWF circuit implementation
}
```

---

**📋 Implementation Checklist: 4.5.5 Testing**

- [x] **Unit test: `test_asset_pack_creation`**
  - [x] `AssetPackPlain { value: 1000, blinding: [0x22;32], s_out: [0x11;32] }` — verify all 3 fields stored without modification
- [x] **Unit test: `test_asset_pack_serialization`**
  - [x] `let b = pack.to_bytes();`
  - [x] `assert_eq!(b.len(), 72)`
  - [x] `assert_eq!(&b[0..8], &1000u64.to_le_bytes())`
  - [x] `assert_eq!(&b[8..40], &[0x22u8;32])`
  - [x] `assert_eq!(&b[40..72], &[0x11u8;32])`
- [x] **Unit test: `test_asset_pack_roundtrip`**
  - [x] `AssetPackPlain::from_bytes(&pack.to_bytes()) == Some(pack)` — requires `PartialEq` derived on `AssetPackPlain`
- [x] **Unit test: `test_asset_pack_bounded_parsing`**
  - [x] `from_bytes(&vec![0u8; 71]) == None`
  - [x] `from_bytes(&vec![0u8; 73]) == None`
  - [x] `from_bytes(&[]) == None`
  - [x] `from_bytes(&vec![0u8; 200]) == None`
  - [x] `from_bytes(&vec![0u8; 72]) == Some(...)` (all-zeros is valid)
- [x] **Golden vector test: `test_asset_pack_golden_72b`**
  - [x] Expected bytes: starts with `[0xE8, 0x03, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00]` then `[0x22;32]` then `[0x11;32]`
  - [x] Run test with `-- --nocapture` to confirm current output matches, then hardcode
  - [x] Add 2 more golden vectors: `value=0` and `value=u64::MAX`
  - [x] Store in `specs/009-z00z-ecc-spec-4/test_vectors/asset_pack_vectors.yaml` via `YamlCodec`
- [x] **Fuzz test: `test_from_bytes_fuzz_random_input`**
  - [x] Use `SystemRngProvider.rng()` for random bytes — NEVER `rand::thread_rng()`
  - [x] 1000 iterations of random-length (0..=200) random-content byte slices — MUST NOT panic, only return `None` or `Some`

### 4.5.6 OWF Circuit Integration

**Constraint Requirements:**

The OWF circuit MUST verify asset_pack_plain encoding is canonical:

```yaml
OWFConstraints:
  input:
    public: "enc_pack (ciphertext bytes)"
    witness: "asset_pack_plain (plaintext bytes)"

  checks:
    1_length:
      rule: "len(asset_pack_plain) == 72"
      enforcement: "Circuit rejects if length != 72"

    2_field_decoding:
      value: "u64::from_le_bytes(bytes[0..8]) - MUST be LE"
      blinding: "bytes[8..40] (Ristretto scalar validation in circuit)"
      s_out: "bytes[40..72] (no additional validation)"

    3_no_padding:
      rule: "Total bytes consumed == 72 (no trailing garbage)"
      enforcement: "Circuit checks cursor reached exact end"
```

**Example Pseudocode (OWF Circuit):**

```rust
// Inside OWF circuit constraint builder
fn constrain_asset_pack_canonical(
    asset_pack_plain: &[CircuitVar],  // 72 bytes
) -> Result<AssetPackFields, CircuitError> {
    // Length check
    assert_eq!(asset_pack_plain.len(), 72, "asset_pack must be 72 bytes");

    let mut cursor = 0;

    // value: 8 bytes LE (MUST decode as LE)
    let v_bytes = &asset_pack_plain[cursor..cursor+8];
    let v = decode_u64_le(v_bytes)?;  // Circuit gadget for LE decoding
    cursor += 8;

    // blinding: 32 bytes (Ristretto scalar)
    let blinding = &asset_pack_plain[cursor..cursor+32];
    constrain_valid_scalar(blinding)?;  // Ristretto scalar validation
    cursor += 32;

    // s_out: 32 bytes (asset output secret)
    let s_out = &asset_pack_plain[cursor..cursor+32];
    cursor += 32;

    // No trailing bytes
    assert_eq!(cursor, 72, "Must consume exactly 72 bytes");

    Ok(AssetPackFields { v, blinding, s_out })
}
```

---

**📋 Implementation Checklist: 4.5.6 OWF Circuit Integration**

> ⚠️ FUTURE WORK. Do NOT implement OWF circuit until Phase 1 (Poseidon2 AEAD) is complete (see §4.6.9). The wallet code is current; this checklist documents the CONTRACT the circuit must honor.

- [x] **Document the circuit contract in `z00z_core/src/assets/leaf.rs`**
  - [x] Add module-level doc comment: `/// OWF circuit contract: asset_pack_plain wire format is value[0..8 LE] | blinding[8..40] | s_out[40..72] = 72 bytes total (consensus-critical, see §4.5.6)`
  - [x] Any change to `AssetPackPlain::to_bytes()` is a BREAKING CHANGE requiring circuit team sign-off
- [ ] **Circuit constraint stub** (in future `z00z_circuit` crate — NOT in `z00z_core`)
  - [ ] `fn constrain_asset_pack_canonical(asset_pack_plain: &[CircuitVar]) -> Result<AssetPackFields, CircuitError>`
  - [ ] Length: `assert asset_pack_plain.len() == 72` — MUST be first check
  - [ ] Value: `decode_u64_le(&bytes[0..8])` circuit gadget — LE, NOT BE
  - [ ] Blinding: `constrain_valid_scalar(&bytes[8..40])` — Ristretto scalar range check
  - [ ] s_out: `bytes[40..72]` — no additional constraint
  - [ ] Cursor: `assert_eq!(cursor, 72)` — no trailing bytes
- [ ] **Golden vectors bridge wallet to circuit**
  - [ ] `{ value: 1000, blinding: [0x22;32], s_out: [0x11;32] }` → `[0xE8,0x03,0,0,0,0,0,0, 0x22×32, 0x11×32]` — identical bytes in both wallet and circuit tests
  - [ ] Store in `specs/009-z00z-ecc-spec-4/test_vectors/asset_pack_vectors.yaml`
  - [ ] CI: wallet test must pass before circuit test is added
- [x] **`#![forbid(unsafe_code)]`** in `AssetPackPlain` module — verify or add

---

## 4.6 Encrypted Pack (enc_pack)

**Purpose:** The encrypted pack (`enc_pack`) is the AEAD-encrypted ciphertext of `AssetPackPlain`, protecting the asset amount (`value`), blinding factor (`blinding`), and asset output secret (`s_out`) from unauthorized observers while ensuring integrity and authenticity.

**Why This Matters:**

- **Confidentiality:** Prevents blockchain observers from learning asset amounts and ownership
- **Anti-Burn Guarantee:** OWF proof ensures receiver can decrypt and open Pedersen commitment
- **Malleability Resistance:** Associated data (`leaf_ad`) binds encryption to specific leaf, preventing rebinding attacks
- **Consensus-Critical:** Encryption format MUST be bit-identical between wallet and OWF circuit

### PhasePhase 18 

### 4.6.0 Architecture Overview

#### Two-Hash-Stack Design

Z00Z uses **two distinct hash functions** for different security domains:

```yaml
HashArchitecture:
  H_zk (Poseidon2 — IMPLEMENTED, Goldilocks field):
    purpose: "Consensus-critical, ZK-proof-verifiable operations"
    current_impl: "hash_zk() in z00z_crypto::hash::zk calls poseidon2_hash() — native Poseidon2 (Goldilocks field, Poseidon2GoldilocksHL width-8 permutation)"
    constraint_cost: "~10-50 constraints per hash — ZK-circuit-friendly already"
    blocker: "Remaining ZK blocker is AEAD (ChaCha20Poly1305 must migrate to Poseidon2-based AEAD), NOT the hash"
    note: "See §4.6.9 Phase 1 for AEAD migration plan"
    domains:
      - owner_handle: "H_zk('Z00Z/RID' || receiver_secret)"
      - view_sk: "H2Scalar_zk('Z00Z/VIEW' || receiver_secret)"
      - k_dh: "H_zk('Z00Z/DH' || Encode(dh))"
      - owner_tag: "H_zk('Z00Z/TAG' || owner_handle || k_dh)"
      - asset_id: "H_zk('Z00Z/ASSET' || s_out)"
      - leaf_ad: "H_zk('Z00Z/LEAFAD' || asset_id || serial_id || R_pub || owner_tag || C_amount)"
      - pack_key: "H_zk('Z00Z/PACKKEY' || k_dh || asset_id || serial_id)"
      - pack_nonce32: "H_zk('Z00Z/PACKNONCE' || leaf_ad || R_pub || asset_id || serial_id)"
      - nonce12: "pack_nonce32[..12]  ← truncated to 12B for ChaCha20Poly1305"
      
  AEAD_enc_pack:
    purpose: "Authenticated encryption of AssetPackPlain payload"
    algorithm: "ChaCha20Poly1305 (NOT H_zk in current implementation)"
    note: >
      Z00Z/PACKTAG (Poseidon2 MAC) is NOT YET IMPLEMENTED.
      Current tag = Poly1305 (16 bytes), generated internally by ChaCha20Poly1305.
      Future ZK migration will replace with Poseidon2-based tag.
      
  H_wallet (Blake2b):
    purpose: "Wallet-internal operations, NOT proven in ZK"
    compatibility: "Tari crypto library (existing infrastructure)"
    domains:
      - BIP32 key derivation (HMAC-SHA512 internally per BIP32 spec; wrapped by Tari Blake2b layer)
      - Internal database record IDs
      - Local caching keys
      - Wallet backup checksums
    note: "BIP39 mnemonic → seed uses PBKDF2-HMAC-SHA512 (not Blake2b) — handled by bip39 crate separately"
      
  separation_rule:
    MUST: "Any value proven in TxProof/CheckpointProof MUST use H_zk"
    MUST_NOT: "Never use H_wallet for consensus-critical derivations"
    rationale: "H_wallet (Blake2b) costs 50K+ constraints in ZK, making proofs too expensive"
```

**Mermaid Diagram: Hash Stack Separation**

```mermaid
graph TD
    subgraph "Consensus Domain (H_zk = Poseidon2)"
        A[receiver_secret] --> B[owner_handle = H_zk RID ...]
        A --> C[view_sk = H2Scalar_zk VIEW ...]
        D[ECDH dh] --> E[k_dh = H_zk DH ...]
        E --> F[pack_key = H_zk PACKKEY ...]
        F --> G[enc_pack encryption]
        H[leaf fields] --> I[leaf_ad = H_zk LEAFAD ...]
        I --> G
        B --> J[owner_tag = H_zk TAG ...]
        E --> J
    end
    
    subgraph "Wallet Domain (H_wallet = Blake2b)"
        K[Seed phrase] --> L[BIP32 keys H_wallet]
        M[Asset records] --> N[DB record IDs H_wallet]
        O[Cache entries] --> P[Cache keys H_wallet]
    end
    
    style A fill:#ffcccc
    style B fill:#ccffcc
    style C fill:#ccffcc
    style E fill:#ccffcc
    style F fill:#ccffcc
    style I fill:#ccffcc
    style J fill:#ccffcc
    style G fill:#ffffcc
```

---

**📋 Implementation Checklist: Two-Hash-Stack Design**

- [x] **`H_zk` = Poseidon2 (Goldilocks-8)** — used for ALL protocol/consensus-critical hashes
  - [x] Confirm `hash_zk::<D>(label, inputs)` in `z00z_crypto::hash::zk` uses `poseidon2_hash()` internally
  - [x] All ZK-domain hashes MUST use `hash_zk::<DomainType>("Z00Z/LABEL", inputs)` — NEVER use Poseidon2 directly
- [x] **`H_wallet` = Blake2b** — used ONLY for wallet-internal operations (NOT consensus-critical)
  - [x] BIP32 key derivation MUST use Blake2b via `z00z_utils` hash abstraction
  - [x] DB record IDs MUST use Blake2b via `z00z_utils` hash abstraction
  - [x] Cache keys MUST use Blake2b via `z00z_utils` hash abstraction
  - [x] NEVER use Blake2b for `leaf_ad`, `pack_key`, `pack_nonce`, or any enc_pack field derivation
- [x] **Zero crossover rule**: add linting or `grep` check to prohibit Blake2b in ZK-critical paths
  - [x] `grep -rn 'blake2b\|Blake2' crates/z00z_crypto/src/zkpack.rs` → must return 0 matches
  - [x] `grep -rn 'poseidon2_hash\|hash::poseidon2_hash' crates/z00z_wallets/src/db/ crates/z00z_wallets/src/core/hashing.rs crates/z00z_wallets/src/core/tx/builder.rs` → must return 0 matches
- [x] **Add diagram documentation** in `z00z_crypto/src/hash/README.md` explaining the two-hash stack

#### ZkPack: AEAD Construction

> ⚠️ **IMPLEMENTATION STATUS:** ZkPack_v1 is **implemented** in
> `z00z_wallets::core::stealth::facade_zkpack` using **ChaCha20Poly1305** standard AEAD
> from the `chacha20poly1305` crate. The original Poseidon2-sponge design was replaced
> by ChaCha20Poly1305 for implementation availability and performance reasons.
> The ZK-circuit path (Poseidon2 sponge) remains a future milestone.

ZkPack_v1 provides AEAD guarantees (Authenticated Encryption with Associated Data) using **ChaCha20Poly1305**:

- **Cipher:** ChaCha20 stream cipher (256-bit key, 96-bit nonce)
- **MAC:** Poly1305 authentication tag (128-bit / 16 bytes), appended automatically
- **AAD:** `version(1B) || leaf_ad(32B) || r_pub(32B) || asset_id(32B) || serial_id_le4(4B)` = 101 bytes
  *(Note: `r_pub`, `asset_id`, and `serial_id` are already covered by `leaf_ad` cryptographically.
  Their explicit repetition in AAD is **intentional defense-in-depth**: direct binding holds even
  if `leaf_ad` computation had an implementation bug. No security weakness — only redundancy.)*
- **Key derivation:** `pack_key = H_zk("Z00Z/PACKKEY" || k_dh || asset_id || serial_id)` (32 bytes)
- **Nonce derivation:** `pack_nonce32 = H_zk("Z00Z/PACKNONCE" || leaf_ad || r_pub || asset_id || serial_id)`, then **truncated to 12 bytes** (`pack_nonce32[..12]`) for ChaCha20

**Security Guarantee:**

```yaml
ZkPack_Security:
  confidentiality: "IND-CPA (indistinguishable ciphertexts under chosen plaintext)"
  authenticity: "INT-CTXT (integrity of ciphertexts) via Poly1305 MAC"
  ad_binding: "Ciphertext cryptographically bound to leaf_ad via AAD"
  uniqueness: "Deterministic 12-byte nonce from unique (R_pub, asset_id) pair"
  
  attack_resistance:
    replay: "Protected by unique R_pub in AAD (→ different pack_nonce)"
    malleability: "Poly1305 tag verification rejects modified ciphertexts"
    rebinding: "leaf_ad in AAD prevents copying enc_pack to different leaf"
    chosen_ciphertext: "AEAD decryption verifies tag atomically before returning plaintext"
    
  future_zk_migration:
    note: "ChaCha20Poly1305 cannot be proven efficiently in ZK circuits (~50K constraints)"
    plan: "Replace with Poseidon2-based AEAD when ZK circuit integration is required"
    milestone: "Phase 2 ZK proof integration"
```

---

**📋 Implementation Checklist: ZkPack AEAD Construction**

- [x] **Current implementation is ChaCha20Poly1305** — verify and document, do NOT change
  - [x] Confirm `z00z_wallets::core::stealth::facade_zkpack` uses `chacha20poly1305` crate
  - [x] Add crate-level doc comment: `//! ZkPack_v1: ChaCha20Poly1305 AEAD. ZK-circuit path reserved for Phase 2.`
- [x] **ZK blocker documentation**
  - [x] Add comment in `facade_zkpack.rs`: `// TODO Phase 2: Replace ChaCha20Poly1305 (~50K ZK constraints) with Poseidon2-based AEAD`
  - [x] Create tracking milestone: "Phase 2 ZK proof integration"
  - [x] Document in `docs/` or `specs/` that ChaCha20Poly1305 cannot be efficiently ZK-proven
- [x] **No functional code changes** — this section is documentation and tracking only
  - [x] Do NOT attempt to migrate to Poseidon2-based AEAD without explicit milestone approval
  - [x] All existing tests for ZkPack MUST pass after adding documentation

### PhasePhase 19 

### 4.6.1 Phase 1: Key & Nonce Derivation

#### 4.6.1.1 pack_key Derivation

**Purpose:** Derive encryption key from shared ECDH secret and asset identity.

**Formula:**

```
pack_key = H_zk("Z00Z/PACKKEY" || k_dh || asset_id || serial_id)

Inputs:
  - k_dh: 32 bytes (from DH key exchange: k_dh = H_zk("Z00Z/DH" || Encode(r * view_pk)))
  - asset_id: 32 bytes (AssetId, derived from s_out)
  - serial_id: 4 bytes LE (SerialId as u32)

Output:
  - pack_key: 32 bytes (field element or byte array, depending on backend)
```

**Security Properties:**

```yaml
PackKeyDerivation:
  binding:
    k_dh: "Unique per output (r is never reused)"
    asset_id: "Unique per asset (s_out is random)"
    serial_id: "Version/evolution isolation"
    
  domain_separation:
    label: "Z00Z/PACKKEY"
    purpose: "Prevents cross-protocol confusion with other derivations"
    
  requirements:
    MUST: "k_dh MUST be derived via H_zk (not H_wallet)"
    MUST: "asset_id MUST be derived via H_zk('Z00Z/ASSET' || s_out)"
    MUST: "serial_id encoding MUST be little-endian u32"
    MUST_NOT: "Never reuse pack_key across different outputs"
```

**Rust Implementation Specification:**

> **IMPLEMENTED** (different location): `derive_pack_key(k_dh: &[u8;32], asset_id: &[u8;32], serial_id: u32) -> [u8;32]` in `z00z_wallets::core::stealth::facade_kdf`. Uses `hash_zk::<PackKeyDomain>`, not `ZkHash::hash_concat`. `AssetId`/`SerialId` newtypes not needed — takes `&[u8;32]` / `u32` directly.

```rust
// PROPOSED location (not yet in z00z_crypto): crates/z00z_crypto/src/zkpack/key.rs
// ACTUAL location (implemented): z00z_wallets::core::stealth::facade_kdf
//
// Real signature:
// pub fn derive_pack_key(k_dh: &[u8;32], asset_id: &[u8;32], serial_id: u32) -> [u8;32]

use crate::hash::ZkHash;  // Poseidon2 trait (proposed interface)
use crate::domains::*;

/// Derive encryption key for ZkPack_v1
///
/// # Security
///
/// pack_key MUST be unique per output. Uniqueness guaranteed by:
/// - k_dh includes unique ephemeral scalar r
/// - asset_id includes random asset secret s_out
/// - serial_id provides version isolation
///
/// # Parameters
///
/// - `k_dh`: Shared DH secret (32 bytes from H_zk("Z00Z/DH" || ...))
/// - `asset_id`: Asset identifier (32 bytes from H_zk("Z00Z/ASSET" || s_out))
/// - `serial_id`: Serial ID (u32, little-endian encoded)
///
/// # Returns
///
/// 32-byte pack_key for enc_pack encryption
pub fn derive_pack_key(
    k_dh: &[u8; 32],
    asset_id: &AssetId,
    serial_id: SerialId,
) -> [u8; 32] {
    let serial_bytes = serial_id.to_bytes_le();
    
    // H_zk("Z00Z/PACKKEY" || k_dh || asset_id || serial_id)
    ZkHash::hash_concat(&[
        b"Z00Z/PACKKEY",
        k_dh,
        asset_id.as_bytes(),
        &serial_bytes,
    ])
}

#[cfg(test)]
mod tests {
    use super::*;
    
    #[test]
    fn test_pack_key_uniqueness() {
        let k_dh = [0x11; 32];
        let asset_id = AssetId::from_bytes([0x22; 32]);
        let serial_0 = SerialId::new(0);
        let serial_1 = SerialId::new(1);
        
        let key_0 = derive_pack_key(&k_dh, &asset_id, serial_0);
        let key_1 = derive_pack_key(&k_dh, &asset_id, serial_1);
        
        assert_ne!(key_0, key_1, "Different serial_id must produce different keys");
    }
    
    #[test]
    fn test_pack_key_deterministic() {
        let k_dh = [0x33; 32];
        let asset_id = AssetId::from_bytes([0x44; 32]);
        let serial_id = SerialId::new(42);
        
        let key_1 = derive_pack_key(&k_dh, &asset_id, serial_id);
        let key_2 = derive_pack_key(&k_dh, &asset_id, serial_id);
        
        assert_eq!(key_1, key_2, "pack_key must be deterministic");
    }
}
```

---

**📋 Implementation Checklist: 4.6.1.1 pack_key Derivation**

- [x] **Formula** (MUST be bit-identical to OWF circuit):
  `pack_key[0..32] = H_zk("Z00Z/PACKKEY" || k_dh[0..32] || asset_id[0..32] || serial_id_le[0..4])`
  - [x] Input 1: `b"Z00Z/PACKKEY"` domain label (literal bytes)
  - [x] Input 2: `k_dh: &[u8;32]` (ECDH shared secret, Ristretto point compressed)
  - [x] Input 3: `asset_id: &[u8;32]` (asset identifier)
  - [x] Input 4: `serial_id` as 4-byte little-endian `serial_id.to_le_bytes()`
  - [x] Use `hash_zk::<PackKeyProdDomain>("Z00Z/PACKKEY", &[k_dh, asset_id, &serial_bytes])`
- [x] **`PackKeyProdDomain` registered via `hash_domain!` macro** in `z00z_wallets::core::domains`
  - [x] Registration string: `"z00z.wallet.stealth.pack_key.prod.v1"` — FROZEN, never change
  - [x] Snapshot/frozen test present in `core::domains::tests::test_pack_domains_frozen`
- [x] **`derive_pack_key` function** in `z00z_wallets/src/core/stealth/facade_kdf.rs`
  - [x] Signature: `pub fn derive_pack_key(k_dh: &[u8;32], asset_id: &[u8;32], serial_id: u32) -> [u8;32]`
  - [x] Note: `AssetId` uses raw `[u8;32]` bytes, no newtype
- [x] **Add unit tests**
  - [x] `test_key_deterministic`: same inputs → identical output
  - [x] `test_key_diff_asset`: different `asset_id` → different `pack_key`
  - [x] `test_key_diff_serial`: different `serial_id` → different `pack_key`
  - [x] `test_key_diff_dh`: different `k_dh` → different `pack_key`
  - [x] Golden test vector: `test_key_golden_v1`

#### 4.6.1.2 nonce Derivation

**Purpose:** Generate unique nonce for each output to prevent keystream reuse.

**Formula:**

```
pack_nonce32 = H_zk("Z00Z/PACKNONCE" || leaf_ad || R_pub || asset_id || serial_id)

Inputs:
  - leaf_ad: 32 bytes (binds to leaf context, prevents rebinding)
  - R_pub: 32 bytes (compressed ephemeral public key, guarantees uniqueness)
  - asset_id: 32 bytes (asset identity)
  - serial_id: 4 bytes LE (version field)

Output:
  - pack_nonce32: 32 bytes (full derived hash)

ChaCha20Poly1305 nonce used in encryption:
  - nonce12 = pack_nonce32[..12]   (first 12 bytes only)
  - Reason: ChaCha20Poly1305 requires a 96-bit (12-byte) nonce
  - The remaining 20 bytes are unused in the current implementation
  - Security: uniqueness of nonce12 is guaranteed by uniqueness of pack_nonce32
    (same inputs → same nonce; different R_pub → different nonce with overwhelm. prob.)
```

**Security: Why Deterministic Nonce is Safe**

```yaml
NonceUniqueness:
  guarantees:
    - "R_pub = r*G where r is unique ephemeral scalar (MUST NOT reuse)"
    - "asset_id = H_zk('Z00Z/ASSET' || s_out) where s_out is random"
    - "leaf_ad includes R_pub, owner_tag, C_amount (all unique per output)"
    
  deterministic_benefits:
    - "No need to store nonce separately (recomputed from leaf fields)"
    - "Circuit can verify nonce derivation in OWF proof"
    - "Eliminates nonce transmission/storage overhead"
    
  catastrophic_failure_if:
    - "Ephemeral scalar r is reused across outputs → KEYSTREAM REUSE"
    - "Two outputs with same (R_pub, asset_id, serial_id) → XOR attack reveals plaintext"
    
  protection_layers:
    1: "RNG provider MUST be cryptographically secure (SystemRngProvider)"
    2: "Wallet MUST enforce r uniqueness check before output creation"
    3: "asset_id uniqueness enforced by random s_out generation"
```

**Rust Implementation Specification:**

```rust
// crates/z00z_crypto/src/zkpack/nonce.rs

use crate::hash::ZkHash;
use crate::domains::*;

/// Derive deterministic nonce for ZkPack_v1 encryption
///
/// # Security
///
/// Nonce uniqueness is CRITICAL. Reusing a nonce with the same pack_key
/// allows XOR-based attacks that reveal plaintext differences.
///
/// Uniqueness guaranteed by:
/// - R_pub is unique (ephemeral scalar r MUST NOT be reused)
/// - leaf_ad includes R_pub and other unique leaf fields
/// - asset_id is unique (random s_out)
///
/// # Parameters
///
/// - `leaf_ad`: Leaf associated data (32 bytes, binds to specific leaf)
/// - `r_pub`: Compressed ephemeral public key R = r*G (32 bytes)
/// - `asset_id`: Asset identifier (32 bytes)
/// - `serial_id`: Serial ID (u32, LE encoded)
///
/// # Returns
///
/// 32-byte deterministic nonce
pub fn derive_nonce(
    leaf_ad: &[u8; 32],
    r_pub: &CompressedRistretto,
    asset_id: &AssetId,
    serial_id: SerialId,
) -> [u8; 32] {
    let serial_bytes = serial_id.to_bytes_le();
    let r_pub_bytes = r_pub.as_bytes();
    
    // H_zk("Z00Z/PACKNONCE" || leaf_ad || R_pub || asset_id || serial_id)
    ZkHash::hash_concat(&[
        b"Z00Z/PACKNONCE",
        leaf_ad,
        r_pub_bytes,
        asset_id.as_bytes(),
        &serial_bytes,
    ])
}

#[cfg(test)]
mod tests {
    use super::*;
    
    #[test]
    fn test_nonce_uniqueness_from_r_pub() {
        let leaf_ad = [0x11; 32];
        let asset_id = AssetId::from_bytes([0x33; 32]);
        let serial_id = SerialId::new(0);
        
        // Different R_pub values
        let r_pub_1 = CompressedRistretto::from_bytes(&[0x44; 32]);
        let r_pub_2 = CompressedRistretto::from_bytes(&[0x55; 32]);
        
        let nonce_1 = derive_nonce(&leaf_ad, &r_pub_1, &asset_id, serial_id);
        let nonce_2 = derive_nonce(&leaf_ad, &r_pub_2, &asset_id, serial_id);
        
        assert_ne!(nonce_1, nonce_2, "Different R_pub must produce different nonces");
    }
    
    #[test]
    fn test_nonce_binding_to_leaf_ad() {
        let r_pub = CompressedRistretto::from_bytes(&[0x66; 32]);
        let asset_id = AssetId::from_bytes([0x77; 32]);
        let serial_id = SerialId::new(0);
        
        // Different leaf_ad values
        let leaf_ad_1 = [0x11; 32];
        let leaf_ad_2 = [0x22; 32];
        
        let nonce_1 = derive_nonce(&leaf_ad_1, &r_pub, &asset_id, serial_id);
        let nonce_2 = derive_nonce(&leaf_ad_2, &r_pub, &asset_id, serial_id);
        
        assert_ne!(nonce_1, nonce_2, "Different leaf_ad must produce different nonces");
    }
    
    #[test]
    fn test_nonce_deterministic() {
        let leaf_ad = [0x88; 32];
        let r_pub = CompressedRistretto::from_bytes(&[0x99; 32]);
        let asset_id = AssetId::from_bytes([0xAA; 32]);
        let serial_id = SerialId::new(42);
        
        let nonce_1 = derive_nonce(&leaf_ad, &r_pub, &asset_id, serial_id);
        let nonce_2 = derive_nonce(&leaf_ad, &r_pub, &asset_id, serial_id);
        
        assert_eq!(nonce_1, nonce_2, "Nonce derivation must be deterministic");
    }
}
```

---

**📋 Implementation Checklist: 4.6.1.2 nonce Derivation**

- [x] **Formula** (MUST NOT reuse the same nonce12 for same `pack_key`):
  `pack_nonce32 = H_zk("Z00Z/PACKNONCE" || leaf_ad[0..32] || R_pub[0..32] || asset_id[0..32] || serial_id_le[0..4])`
  - [x] Input 1: `b"Z00Z/PACKNONCE"` domain label
  - [x] Input 2: `leaf_ad: &[u8;32]` (computed output of `compute_leaf_ad`)
  - [x] Input 3: `r_pub: &[u8;32]` (compressed Ristretto public nonce point)
  - [x] Input 4: `asset_id: &[u8;32]`
  - [x] Input 5: `serial_id.to_le_bytes()` as `[u8;4]`
  - [x] Use `hash_zk::<PackNonceProdDomain>("Z00Z/PACKNONCE", &[leaf_ad, r_pub, asset_id, &serial_bytes])`
- [x] **Truncate to 12 bytes**: take ONLY `pack_nonce32[0..12]` for ChaCha20Poly1305
  - [x] Implemented via `derive_nonce(...) -> [u8;12]` in facade layer
  - [x] Runtime uses 12-byte nonce directly in `facade_zkpack`
- [x] **`PackNonceProdDomain` registered via `hash_domain!` macro**
  - [x] Registration string: `"z00z.wallet.stealth.pack_nonce.prod.v1"` — FROZEN
  - [x] Snapshot/frozen test present in `core::domains::tests::test_pack_domains_frozen`
- [x] **`derive_nonce` function** in `z00z_wallets/src/core/stealth/facade_kdf.rs`
  - [x] Signature: `pub fn derive_nonce(leaf_ad: &[u8;32], r_pub: &[u8;32], asset_id: &[u8;32], serial_id: u32) -> [u8;12]`
- [x] **Add unit tests**
  - [x] `test_nonce_deterministic`: same inputs → identical 12-byte output
  - [x] `test_nonce_diff_leaf`: different `leaf_ad` → different nonce
  - [x] `test_nonce_len_12`: output length is exactly 12
  - [x] Golden test vector: `test_nonce_golden_v1`

#### 4.6.1.3 Domain Separation Strategy

**Rationale:** Prevents cross-protocol attacks where hash outputs from one context are misinterpreted in another.

> ⚠️ **TWO-LEVEL DOMAIN SYSTEM:** Every `H_zk` call uses `hash_zk::<DomainType>(label, inputs)`.
> The final hash is computed over both the domain type's registered string AND the human-readable label.
> Domain type strings (registered with `hash_domain!` macro) use dotted notation, e.g.:
> - `PackKeyProdDomain` → `"z00z.wallet.stealth.pack_key.prod.v1"`
> - `PackNonceProdDomain` → `"z00z.wallet.stealth.pack_nonce.prod.v1"`
> - `WalletDhKeyHashProdDomain` → `"z00z.wallet.stealth.dh_key.prod.v1"`
> - `WalletLeafAdHashProdDomain` → `"z00z.wallet.stealth.leaf_ad.prod.v1"`
> The spec tables show only the human-readable label; the domain type is implicit.

```yaml
DomainSeparationLabels:
  Z00Z/DH:
    purpose: "ECDH shared secret derivation"
    domain_type: "WalletDhKeyHashProdDomain (z00z.wallet.stealth.dh_key.prod.v1)"
    input: "Encode(r * view_pk)"
    output: "k_dh (32 bytes)"
    
  Z00Z/PACKKEY:
    purpose: "Encryption key for ZkPack_v1 (ChaCha20 key)"
    domain_type: "PackKeyProdDomain (z00z.wallet.stealth.pack_key.prod.v1)"
    input: "k_dh || asset_id || serial_id"
    output: "pack_key (32 bytes)"
    
  Z00Z/PACKNONCE:
    purpose: "Nonce derivation for ZkPack_v1 (first 12 bytes used as ChaCha20 nonce)"
    domain_type: "PackNonceProdDomain (z00z.wallet.stealth.pack_nonce.prod.v1)"
    input: "leaf_ad || R_pub || asset_id || serial_id"
    output: "pack_nonce32 (32 bytes); nonce12 = pack_nonce32[..12] used in AEAD"
    
  Z00Z/LEAFAD:
    purpose: "Leaf associated data binding"
    domain_type: "WalletLeafAdHashProdDomain (z00z.wallet.stealth.leaf_ad.prod.v1)"
    input: "asset_id || serial_id || R_pub || owner_tag || C_amount"
    output: "leaf_ad (32 bytes)"

  Z00Z/TAG:
    purpose: "Owner tag (receiver identity binding)"
    domain_type: "WalletOwnerTagHashProdDomain (z00z.wallet.stealth.owner_tag.prod.v1)"
    input: "owner_handle || k_dh"
    output: "owner_tag (32 bytes)"

  Z00Z/TAG16:
    purpose: "16-bit scan prefilter tag for wallet scanning (direct form)"
    domain_type: "WalletTag16HashProdDomain (z00z.wallet.stealth.tag16.prod.v1)"
    low_level_fn: "compute_tag16(k_dh, leaf_ad)"
    input: "k_dh || leaf_ad"
    output: "hash (32 bytes); tag16 = first 2 bytes as u16 LE"
    note: "leaf_ad here is caller-chosen; can be actual leaf_ad OR owner_handle hash"

  Z00Z/TAG16/OWNER:
    purpose: "Intermediate hash of owner_handle for DefaultTag16Ops two-step derivation"
    domain_type: "WalletLeafAdHashProdDomain (z00z.wallet.stealth.leaf_ad.prod.v1)"
    note: "SAME domain type as Z00Z/LEAFAD but DIFFERENT label string"
    two_step_derivation:
      step1: "intermediate = hash_zk<WalletLeafAdHashProdDomain>('Z00Z/TAG16/OWNER', [owner_handle])"
      step2: "tag16 = compute_tag16(k_dh, &intermediate)"
      result: "16-bit tag bound to owner_handle via intermediate hash"
    usage: "DefaultTag16Ops::compute(owner_handle, k_dh) in z00z_wallets::core::stealth::tag"

  NOT_USED_Z00Z/PACKSTR:
    status: "NOT IMPLEMENTED — planned for future Poseidon2 sponge migration"
    note: "ChaCha20 keystream is generated internally by ChaCha20Poly1305 crate"
    
  NOT_USED_Z00Z/PACKTAG:
    status: "NOT IMPLEMENTED — planned for future Poseidon2 sponge migration"
    note: "Poly1305 tag is generated internally by ChaCha20Poly1305 crate"

  AEAD_AAD:
    note: "ChaCha20Poly1305 uses AAD for authentication binding (not a hash domain)"
    format: "version(1B) || leaf_ad(32B) || r_pub(32B) || asset_id(32B) || serial_id_le4(4B)"
    total_size: "101 bytes"
    
  enforcement:
    MUST: "Every H_zk hash call MUST include domain label as first input"
    MUST: "Labels MUST be unique across protocol (no collisions)"
    MUST: "Domain type strings are frozen — snapshot tests enforce immutability"
    MUST: "Labels MUST be versioned if schema changes (e.g., Z00Z/PACKKEY/v2)"
    MUST_NOT: "Never use Z00Z/PACKSTR or Z00Z/PACKTAG (not implemented)"
```

---

**📋 Implementation Checklist: 4.6.1.3 Domain Separation Strategy**

- [x] **Two-level domain system MUST be used for all H_zk calls**
  - [x] Level 1: `hash_domain!` macro registers a type with a dotted string (e.g., `"z00z.wallet.stealth.pack_key.prod.v1"`)
  - [x] Level 2: Human-readable label passed as first argument (e.g., `"Z00Z/PACKKEY"`)
  - [x] Final hash = Poseidon2(registered_string || label || inputs)
- [x] **Frozen domain strings** — snapshot/frozen tests in `z00z_wallets::core::domains`
  - [x] `PackKeyProdDomain` → `"z00z.wallet.stealth.pack_key.prod.v1"` — must not change
  - [x] `PackNonceProdDomain` → `"z00z.wallet.stealth.pack_nonce.prod.v1"` — must not change
  - [x] `WalletLeafAdHashProdDomain` → `"z00z.wallet.stealth.leaf_ad.prod.v1"` — must not change
  - [x] `test_pack_domains_frozen()` uses `assert_eq!` for each string
  - [x] Existing domain snapshot test enforces immutable domain map in CI
- [ ] **Labels MUST be unique across protocol** — currently NOT fully satisfied globally
  - [ ] Global grep shows intentional duplicates (`Z00Z/DH`, `Z00Z/TAG16`, `Z00Z/S_OUT`) in separate call sites
  - [x] `Z00Z/PACKKEY` and `Z00Z/PACKNONCE` are unique in active key/nonce derivation paths
- [x] **Versioning rule**: if schema changes, create new domain type with `/v2` suffix
  - [x] `PackKeyProdDomainV2` registered as `"z00z.wallet.stealth.pack_key.prod.v2"`
  - [x] Old domain type remains for backward compatibility
- [ ] **Prohibited labels globally** — currently NOT fully satisfied
  - [x] `grep -rn 'Z00Z/PACKSTR\|Z00Z/PACKTAG' crates/z00z_wallets/src/` → 0 matches
  - [ ] Legacy references still exist in `crates/z00z_crypto/src/` (outside wallet runtime path)

### PhasePhase 20 

### 4.6.2 Phase 2: AEAD Construction (ZkPack_v1)

> ⚠️ **IMPLEMENTATION NOTE:** The implementation uses **ChaCha20Poly1305** (not Poseidon2 sponge).
> The Poseidon2-based AEAD design is reserved for Phase 2 ZK circuit integration.
> All pseudocode in this section reflects the **actual ChaCha20Poly1305 implementation**.

#### 4.6.2.1 ChaCha20Poly1305 AEAD Context

**Purpose:** ChaCha20Poly1305 provides authenticated encryption with associated data (AEAD). Authentication is done atomically — decryption returns plaintext only if Poly1305 tag verification passes.

**Canonical Construction:**

```yaml
ZkPackCtx_v1:
  cipher: "ChaCha20Poly1305 (RFC 8439)"
  key: "pack_key (32 bytes, derived via H_zk Z00Z/PACKKEY)"
  nonce: "pack_nonce32[..12] — first 12 bytes of H_zk Z00Z/PACKNONCE output"
  
  aad_format:
    composition: "version(1B) || leaf_ad(32B) || r_pub(32B) || asset_id(32B) || serial_id_le4(4B)"
    total_size: "101 bytes"
    purpose: "Binds ciphertext to leaf context without encrypting the fields"
    
  encryption_output:
    ciphertext: "Same length as plaintext (ChaCha20 stream cipher)"
    tag: "16 bytes (Poly1305 MAC, appended after ciphertext by the crate)"
    
  stored_struct:
    type: "ZkPackEncrypted { version: u8, ciphertext: Vec<u8>, tag: [u8; 16] }"
    note: "ciphertext and tag are split after encryption; recombined before decryption"
    
  security_rules:
    MUST: "Decrypt MUST verify Poly1305 tag BEFORE returning plaintext (AEAD handles this)"
    MUST: "Tag verification uses constant-time comparison (built into AEAD crate)"
    MUST_NOT: "Never reuse same (pack_key, nonce12) pair"
```

**Mermaid Diagram: ZkPack_v1 Encryption Flow**

```mermaid
flowchart TD
    subgraph "Key/Nonce Derivation"
        A1[k_dh 32B] --> PK[pack_key = H_zk PACKKEY ...]
        A2[asset_id] --> PK
        A3[serial_id] --> PK
        B1[leaf_ad 32B] --> PN[pack_nonce32 = H_zk PACKNONCE ...]
        B2[r_pub 32B] --> PN
        A2 --> PN
        A3 --> PN
        PN --> N12[nonce12 = pack_nonce32 first 12B]
    end

    subgraph "AAD Construction"
        V[version=1] --> AAD[AAD 101B]
        B1 --> AAD
        B2 --> AAD
        A2 --> AAD
        A3 --> AAD
    end

    subgraph "ChaCha20Poly1305 Encrypt"
        PK --> ENC[ChaCha20Poly1305::encrypt]
        N12 --> ENC
        AAD --> ENC
        PT[plaintext 72B] --> ENC
        ENC --> CT[ciphertext 72B]
        ENC --> TAG[tag 16B Poly1305]
    end

    subgraph "ZkPackEncrypted"
        V --> OUT[version: u8]
        CT --> OUT2[ciphertext: Vec 72B]
        TAG --> OUT3[tag: 16B]
    end
    
    style PT fill:#ccffcc
    style CT fill:#ffffcc
    style TAG fill:#ffcccc
```

---

**📋 Implementation Checklist: 4.6.2.1 ChaCha20Poly1305 AEAD Context**

- [x] **Encryption key** = `pack_key: [u8;32]` (derived via `derive_pack_key` from §4.6.1.1) — 32 bytes
- [x] **Nonce** = `nonce12: [u8;12]` (derived via `derive_nonce` truncated to 12 bytes from §4.6.1.2)
- [x] **Plaintext V1 profile** = `AssetPackPlain` serialized as 72-byte `[u8;72]`
- [x] **AAD (Associated Data)** = `version || leaf_ad || r_pub || asset_id || serial_id_le4` (101 bytes)
  - [x] AAD includes `leaf_ad` and contextual bind fields
  - [x] Runtime uses `make_aad(...)` consistently on encrypt/decrypt
- [x] **Output** = `ciphertext: Vec<u8>` + `tag: [u8;16]` (Poly1305)
  - [x] For 72-byte plaintext: output is 72-byte ciphertext + 16-byte tag
- [x] **Verify `chacha20poly1305` crate version** is pinned in `Cargo.toml`
- [x] **Add unit test**
  - [x] `test_aead_ctx_valid`: checks key/nonce/plain/profile sizes
  - [x] `test_aead_out_size`: `ciphertext.len() == 72` and `tag.len() == 16`

#### 4.6.2.2 Encryption (ChaCha20Poly1305)

**Encryption pseudocode (matches actual `ZkPack::encrypt`):**

```rust
// z00z_wallets::core::stealth::facade_zkpack::ZkPack::encrypt
use chacha20poly1305::{ChaCha20Poly1305, Key, Nonce, aead::{Aead, KeyInit, Payload}};

fn encrypt(
    k_dh: &[u8; 32],
    leaf_ad: &[u8; 32],
    r_pub: &[u8; 32],
    asset_id: &[u8; 32],
    serial_id: u32,
    plaintext: &[u8],
) -> ZkPackEncrypted {
    // 1. Derive 32-byte key and nonce
    let pack_key = derive_pack_key(k_dh, asset_id, serial_id);         // H_zk "Z00Z/PACKKEY"
    let nonce32 = derive_pack_nonce(leaf_ad, r_pub, asset_id, serial_id); // H_zk "Z00Z/PACKNONCE"

    // 2. Build AAD: version || leaf_ad || r_pub || asset_id || serial_le4
    let aad = make_aad(leaf_ad, r_pub, asset_id, serial_id);  // 101 bytes total

    // 3. Initialize cipher with 32-byte key and 12-byte nonce
    let cipher = ChaCha20Poly1305::new(Key::from_slice(&pack_key));
    let nonce  = Nonce::from_slice(&nonce32[..12]);  // TRUNCATE to 12 bytes

    // 4. Encrypt: returns ciphertext || poly1305_tag (16 bytes appended).
    //    NOTE: Real code (facade_zkpack.rs) does NOT panic via .expect().
    //    On cipher.encrypt() error, it returns empty ZkPackEncrypted (sentinel).
    //    This path is unreachable in practice for valid 32-byte key + 12-byte nonce,
    //    but the code is defensive — it does NOT panic.
    let encrypted = match cipher.encrypt(nonce, Payload { msg: plaintext, aad: &aad }) {
        Ok(value) => value,
        Err(_) => return ZkPackEncrypted { version: 1, ciphertext: Vec::new(), tag: [0u8; 16] },
    };

    // 5. Split off last 16 bytes as tag
    let mut ciphertext = encrypted;
    let tag_bytes = ciphertext.split_off(ciphertext.len() - 16);
    let mut tag = [0u8; 16];
    tag.copy_from_slice(&tag_bytes);

    ZkPackEncrypted { version: 1, ciphertext, tag }
}
```

**Security Properties:**

```yaml
ChaCha20_StreamCipher:
  algorithm: "ChaCha20 (256-bit key, 96-bit nonce, 32-bit counter)"
  output: "ciphertext same length as plaintext"
  confidentiality: "IND-CPA proven for ChaCha20"
  
  nonce_handling:
    derived_size: "32 bytes from H_zk"
    used_size: "12 bytes (first 12 only)"
    safety: "Unique R_pub per output guarantees nonce12 uniqueness (overwhelming prob.)"
    catastrophic_failure: "Same (pack_key, nonce12) reuse → keystream XOR attack"
```

---

**📋 Implementation Checklist: 4.6.2.2 Encryption (ChaCha20Poly1305)**

- [x] **Implement `ZkPack::encrypt(...)` in `z00z_wallets/src/core/stealth/facade_zkpack.rs`**
  - [x] Signature matches spec
  - [x] Step 1: derives `pack_key`
  - [x] Step 2: derives `nonce12`
  - [x] Step 3: initializes `ChaCha20Poly1305`
  - [x] Step 4: uses `Nonce::from_slice(&nonce12)`
  - [x] Step 5: encrypts with `Payload { msg, aad: &make_aad(...) }`
  - [x] Step 6: splits final 16 bytes as tag
  - [x] Step 7: returns `ZkPackEncrypted { version, ciphertext, tag }`
- [x] **CATASTROPHIC: nonce reuse MUST be impossible**
  - [x] `R_pub` uniqueness assumed by protocol generation flow
  - [x] Security comment added in encrypt path
- [x] **`ZKPACK_VER: u8 = 0x01`** defined in `z00z_crypto::zkpack`
- [x] **Add unit tests**
  - [x] `test_enc_ok`
  - [x] `test_aead_out_size`
  - [x] `test_tag_len_16`
  - [x] replay/roundtrip checks in facade + integration tests
  - [x] `test_diff_rpub_diff_ct`

#### 4.6.2.3 Authentication Tag (Poly1305)

**Poly1305 MAC** is generated automatically by ChaCha20Poly1305 AEAD — it is NOT a separate `H_zk` call.

```yaml
Poly1305_MAC:
  algorithm: "Poly1305 (RFC 8439)"
  tag_size: "16 bytes (128 bits)"
  binding:
    - "Authenticates ciphertext (detects any modification)"
    - "Authenticates AAD: version || leaf_ad || r_pub || asset_id || serial_id"
    - "Provides leaf-binding via leaf_ad in AAD"
  
  verification:
    timing: "AEAD decrypt verifies tag BEFORE returning plaintext (automatic)"
    comparison: "Constant-time comparison (built into chacha20poly1305 crate)"
    failure: "Returns Err on mismatch — plaintext never revealed"
    
  requirements:
    MUST: "Tag MUST cover all AAD fields (achieved via AEAD AAD binding)"
    MUST_NOT: "Never use Z00Z/PACKTAG hash domain (not implemented)"
    NOTE: "No separate tag computation step — Poly1305 is part of the AEAD call"
```

---

**📋 Implementation Checklist: 4.6.2.3 Authentication Tag (Poly1305)**

- [x] **Tag is generated AUTOMATICALLY by `chacha20poly1305` crate** — do NOT compute it separately
  - [x] No `H_zk` tag generation in runtime encrypt path
  - [x] `grep -rn 'PACKTAG' crates/*/src/` returns 0 matches after source cleanup
  - [x] Tag = last 16 bytes of `ChaCha20Poly1305::encrypt` output
- [x] **Tag covers ALL AAD fields** through AEAD binding
  - [x] Encrypt uses `Payload { msg, aad: &make_aad(...) }`
  - [x] Decrypt uses identical `make_aad(...)`
- [x] **Store tag as `[u8;16]`** in `ZkPackEncrypted.tag: [u8;16]`
  - [x] Field type confirmed
  - [x] Extraction uses split of last 16 bytes
- [x] **Add unit tests**
  - [x] `test_tag_len_16`
  - [x] `test_tag_flip_none`
  - [x] `test_aad_wrong_none`

#### 4.6.2.4 Wire Format

**ZkPackEncrypted (actual struct in `z00z_crypto::zkpack`):**

```yaml
Format:
  version: u8           # 1 byte (value = 0x01 = ZKPACK_VER)
  ciphertext: Vec<u8>   # Variable (same length as plaintext, e.g., 72B for AssetPackPlain)
  tag: [u8; 16]         # 16 bytes authentication tag (Poly1305)
  
Example (AssetPackPlain 72-byte plaintext):
  version: 1
  ciphertext: 72 bytes
  tag: 16 bytes
  total fields: 89 bytes (logical; actual struct not flat-serialized)
```

**Actual Rust Type (in `crates/z00z_crypto/src/zkpack.rs`):**

```rust
/// Encrypted ZkPack payload.
#[derive(Debug, Clone, serde::Serialize, serde::Deserialize, PartialEq, Eq)]
pub struct ZkPackEncrypted {
    /// Protocol version.
    pub version: u8,
    /// Encrypted payload bytes (plaintext-length, tag stripped out).
    pub ciphertext: Vec<u8>,
    /// Authentication tag (16 bytes, Poly1305).
    pub tag: [u8; 16],
}
```

> **⚠️ CRITICAL CORRECTION vs earlier spec drafts:**
> - Tag size is **16 bytes** (Poly1305), NOT 32 bytes (Poseidon2).
> - Wire layout is `version || ciphertext || tag` (tag at end, NOT after version).
> - Decrypt reassembles `envelope = ciphertext ++ tag` before passing to ChaCha20Poly1305.



---

**📋 Implementation Checklist: 4.6.2.4 Wire Format**

- [x] **`ZkPackEncrypted` struct** in `z00z_crypto/src/zkpack.rs`
  - [x] `pub version: u8` with `ZKPACK_VER = 0x01`
  - [x] `pub ciphertext: Vec<u8>` (V1 fixed-profile length 72 for wire helpers)
  - [x] `pub tag: [u8;16]`
  - [x] Derives `Debug, Clone, PartialEq, Eq, Serialize, Deserialize`
- [x] **Wire layout** = `version(1) || ciphertext(72) || tag(16)` = 89 bytes total
  - [x] Implemented `ZkPackEncrypted::to_bytes(&self) -> Option<[u8;89]>`
  - [x] Implemented `ZkPackEncrypted::from_bytes(bytes: &[u8]) -> Option<Self>`
    - [x] Wrong length rejected with `None`
    - [x] Wrong version rejected with `None`
- [x] **Tag is at END** (bytes 73..89), NOT after version byte
  - [x] Layout comment added in `to_bytes`
- [x] **Decrypt reassembly**: `envelope = ciphertext ++ tag`
  - [x] Implemented via `extend_from_slice` before AEAD decrypt
- [x] **Add unit tests**
  - [x] `test_to_bytes_len`
  - [x] `test_bytes_roundtrip`
  - [x] `test_bytes_wrong_ver`
  - [x] `test_bytes_wrong_len`

### PhasePhase 21 

### 4.6.3 Phase 3: Encryption/Decryption API

> **IMPLEMENTED** in `z00z_wallets::core::stealth::facade_zkpack`.
> Real signatures:
> - `ZkPack::encrypt(k_dh: &[u8;32], leaf_ad: &[u8;32], r_pub: &[u8;32], asset_id: &[u8;32], serial_id: u32, plaintext: &[u8]) -> ZkPackEncrypted`
> - `ZkPack::decrypt(...same args..., enc: &ZkPackEncrypted) -> Option<Vec<u8>>`
> - Return type is `ZkPackEncrypted { version: u8, ciphertext: Vec<u8>, tag: [u8; 16] }` — **tag is 16 bytes (Poly1305)**
> - `EncryptedPack` wrapper does NOT exist — `Asset` holds `enc_pack: Option<ZkPackEncrypted>` directly.
> - Algorithm: **ChaCha20Poly1305** (not Poseidon2 sponge)
> - Nonce: `pack_nonce32[..12]` (12-byte truncation)
> - AAD: `version(1B) || leaf_ad(32B) || r_pub(32B) || asset_id(32B) || serial_le4(4B)` = 101 bytes

#### 4.6.3.1 High-Level encrypt() API

```rust
// Actual implementation in z00z_wallets::core::stealth::facade_zkpack
// See §4.6.2.2 for full pseudocode

/// Encrypt plaintext using ZkPack_v1 (ChaCha20Poly1305 AEAD)
/// Returns ZkPackEncrypted { version, ciphertext, tag: [u8;16] }
pub fn encrypt(
    k_dh: &[u8; 32],
    leaf_ad: &[u8; 32],
    r_pub: &[u8; 32],
    asset_id: &[u8; 32],
    serial_id: u32,
    plaintext: &[u8],
) -> ZkPackEncrypted {
    let pack_key  = derive_pack_key(k_dh, asset_id, serial_id);
    let nonce32   = derive_pack_nonce(leaf_ad, r_pub, asset_id, serial_id);
    let aad       = make_aad(leaf_ad, r_pub, asset_id, serial_id);
    let cipher    = ChaCha20Poly1305::new(Key::from_slice(&pack_key));
    let nonce12   = Nonce::from_slice(&nonce32[..12]);
    // SAFETY: ChaCha20Poly1305::encrypt fails only if nonce length is wrong.
    // Nonce is hardcoded to exactly 12 bytes (nonce32[..12]) — this is always valid.
    // .expect() is appropriate here: a panic would indicate a programming error, not runtime data.
    let mut ciphertext = cipher.encrypt(nonce12, Payload { msg: plaintext, aad: &aad })
        .expect("ChaCha20Poly1305 encrypt: nonce is always 12 bytes \u2014 infallible");

    // Split Poly1305 tag (last 16 bytes) from ciphertext
    let tag_bytes = ciphertext.split_off(ciphertext.len() - 16);
    let mut tag = [0u8; 16];
    tag.copy_from_slice(&tag_bytes);
    ZkPackEncrypted { version: 1, ciphertext, tag }
}
```

> **NOTE:** No separate `generate_keystream` function exists in the implementation.
> ChaCha20Poly1305 generates the keystream internally. The old Poseidon2 `generate_keystream`
> using `Z00Z/PACKSTR` is NOT implemented and should not be referenced.



---

**📋 Implementation Checklist: 4.6.3.1 High-Level encrypt() API**

- [x] **`ZkPack::encrypt` signature** (already implemented — verify, do NOT reimagine)
  - [x] Exact: `pub fn encrypt(k_dh: &[u8;32], leaf_ad: &[u8;32], r_pub: &[u8;32], asset_id: &[u8;32], serial_id: u32, plaintext: &[u8]) -> ZkPackEncrypted`
  - [x] Located in `z00z_wallets::core::stealth::facade_zkpack`
  - [x] Returns `ZkPackEncrypted { version: u8, ciphertext: Vec<u8>, tag: [u8;16] }`
- [x] **Verify no `Z00Z/PACKSTR` or `generate_keystream` references exist**
  - [x] `grep -rn 'PACKSTR\|generate_keystream' crates/*/src/` → 0 matches in active source paths
- [x] **Ensure `leaf_ad` passed correctly**: it is the 32-byte Poseidon2 hash output (NOT the 132-byte preimage)
  - [x] Callers compute hashed `leaf_ad` via `compute_leaf_ad(...)` before `ZkPack::encrypt`
- [x] **Error handling**: `ZkPack::encrypt` returns `ZkPackEncrypted` directly (not `Result`)
  - [x] ChaCha20Poly1305 encrypt failure is treated as programming-error panic with `expect(...)`
- [x] **Add integration test**
  - [x] `test_enc_roundtrip`: `encrypt(..., plaintext)` then `decrypt(...)` → `Some(plaintext)`
  - [x] `test_zero_kdh_enc`: k_dh=`[0u8;32]` → does NOT panic
  - [x] Golden vector frozen via `test_golden_yaml_v1` + YAML fixture

#### 4.6.3.2 High-Level decrypt() API

```rust
// Actual implementation in z00z_wallets::core::stealth::facade_zkpack
// ZkPack::decrypt returns Option<Vec<u8>> (None on tag mismatch or version error)

pub fn decrypt(
    k_dh: &[u8; 32],
    leaf_ad: &[u8; 32],
    r_pub: &[u8; 32],
    asset_id: &[u8; 32],
    serial_id: u32,
    enc: &ZkPackEncrypted,
) -> Option<Vec<u8>> {
    if enc.version != 1 { return None; }

    let pack_key = derive_pack_key(k_dh, asset_id, serial_id);
    let nonce32  = derive_pack_nonce(leaf_ad, r_pub, asset_id, serial_id);
    let aad      = make_aad(leaf_ad, r_pub, asset_id, serial_id);

    // Reassemble ciphertext || tag for AEAD
    let mut envelope = Vec::with_capacity(enc.ciphertext.len() + 16);
    envelope.extend_from_slice(&enc.ciphertext);
    envelope.extend_from_slice(&enc.tag);

    let cipher  = ChaCha20Poly1305::new(Key::from_slice(&pack_key));
    let nonce12 = Nonce::from_slice(&nonce32[..12]);
    // Tag verification + decryption happen atomically inside AEAD decrypt
    cipher.decrypt(nonce12, Payload { msg: &envelope, aad: &aad }).ok()
}
```

---

---

**📋 Implementation Checklist: 4.6.3.2 High-Level decrypt() API**

- [x] **`ZkPack::decrypt` signature** (already implemented — verify, do NOT change)
  - [x] Exact: `pub fn decrypt(k_dh: &[u8;32], leaf_ad: &[u8;32], r_pub: &[u8;32], asset_id: &[u8;32], serial_id: u32, enc: &ZkPackEncrypted) -> Option<Vec<u8>>`
  - [x] Returns `None` on tag mismatch (wrong `leaf_ad`, tampered ciphertext, wrong key)
  - [x] Returns `None` on version mismatch (`enc.version != ZKPACK_VER`)
  - [x] Returns `Some(plaintext_bytes)` where `plaintext_bytes.len() == 72` on success
- [x] **Decrypt reassembly**: `envelope = ciphertext ++ tag` (concatenate before passing to AEAD)
  - [x] Reassembly is implemented before AEAD decrypt
  - [x] Decrypt uses `Payload { msg: &envelope, aad: &make_aad(...) }`
- [x] **Post-decrypt validation**
  - [x] Receiver paths validate decrypted bytes with `AssetPackPlain::is_valid_length(...)`
  - [x] Receiver paths parse with `AssetPackPlain::from_bytes(...)`
- [x] **Add unit tests**
  - [x] `test_enc_roundtrip`
  - [x] `test_aad_wrong_none`
  - [x] `test_ct_flip_none`
  - [x] `test_wrong_ver_none`

### 4.6.4 Phase 4: z00z_core Integration

#### 4.6.4.1 EncryptedPack Wrapper

> **STATUS: NOT YET IN CODEBASE.** `EncryptedPack` wrapper struct does not exist. Today `AssetLeaf` holds `enc_pack: ZkPackEncrypted` directly. Use `ZkPack::encrypt/decrypt` from `z00z_wallets::core::stealth::facade_zkpack` instead of the proposed code below.

```rust
// crates/z00z_core/src/assets/enc_pack.rs (PROPOSED — not yet implemented)

// Note: ZkPack::encrypt/decrypt live in z00z_wallets::core::stealth::facade_zkpack.
// z00z_crypto::zkpack only defines the ZkPackEncrypted struct (no free encrypt/decrypt fns).
use z00z_crypto::zkpack::ZkPackEncrypted;

/// Encrypted asset pack for Asset leaves
#[derive(Clone)]
pub struct EncryptedPack {
    inner: ZkPackEncrypted,
}

impl EncryptedPack {
    /// Encrypt asset pack for output
    pub fn encrypt(
        k_dh: &[u8; 32],
        leaf_ad: &[u8; 32],
        r_pub: &CompressedRistretto,
        asset_id: &AssetId,
        serial_id: SerialId,
        asset_pack: &AssetPackPlain,
    ) -> Result<Self, EncPackError> {
        let plaintext = asset_pack.to_bytes();
        let ciphertext = encrypt(k_dh, leaf_ad, r_pub, asset_id, serial_id, &plaintext)?;
        Ok(EncryptedPack { inner: ciphertext })
    }

    /// Decrypt asset pack from leaf
    pub fn decrypt(
        &self,
        k_dh: &[u8; 32],
        leaf_ad: &[u8; 32],
        r_pub: &CompressedRistretto,
        asset_id: &AssetId,
        serial_id: SerialId,
    ) -> Result<AssetPackPlain, EncPackError> {
        let plaintext = decrypt(k_dh, leaf_ad, r_pub, asset_id, serial_id, &self.inner)?;

        AssetPackPlain::from_bytes(&plaintext)
            .ok_or_else(|| EncPackError::MalformedPlaintext("invalid length".to_string()))
    }
    
    pub fn to_bytes(&self) -> Vec<u8> {
        self.inner.to_bytes()
    }
    
    pub fn from_bytes(bytes: &[u8]) -> Result<Self, EncPackError> {
        let inner = ZkPackEncrypted::from_bytes(bytes)?;
        Ok(EncryptedPack { inner })
    }
}

#[derive(Debug, Error)]
pub enum EncPackError {
    // ZkPackEncrypted serialization/parse error (use z00z_crypto::zkpack error type)
    #[error("ZkPack error: {0}")]
    ZkPack(String),
    #[error("Malformed plaintext: {0}")]
    MalformedPlaintext(String),
}
```

---

### 4.6.5 Malleability Resistance

**Attack Scenario:** Copy `enc_pack` to different leaf.

**Defense:**

```yaml
MalleabilityDefense:
  mechanism: "leaf_ad included in tag computation"
  
  leaf_ad_formula:
    "leaf_ad = H_zk('Z00Z/LEAFAD' || asset_id || serial_id || R_pub || owner_tag || C_amount)"
    
  fields_bound:
    asset_id: "Unique per asset"
    serial_id: "Version field"
    R_pub: "Ephemeral public key (unique)"
    owner_tag: "Receiver tag (unique)"
    C_amount: "Pedersen commitment (unique)"
    
  attack_prevention:
    rebinding: "Copying enc_pack fails tag verification"
    substitution: "Replacing any field invalidates tag"
    replay: "Same enc_pack cannot be reused"
```

**Test:**

```rust
#[test]
fn test_enc_pack_rebinding_rejected() {
    let k_dh = [0x11; 32];
    let r_pub = CompressedRistretto::from_bytes(&[0x33; 32]);
    let asset_id = AssetId::from_bytes([0x44; 32]);
    let serial_id = SerialId::new(0);
    
    let leaf_ad_original = [0x55; 32];
    let mut leaf_ad_attacker = [0x55; 32];
    leaf_ad_attacker[0] ^= 0x01;  // Different!
    
    let asset_pack = AssetPackPlain {
        value: 1000,
        blinding: [0x22; 32],
        s_out: [0x11; 32],
    };
    
    let enc_pack = EncryptedPack::encrypt(
        &k_dh,
        &leaf_ad_original,
        &r_pub,
        &asset_id,
        serial_id,
        &asset_pack,
    ).unwrap();
    
    // Try rebinding
    let result = enc_pack.decrypt(
        &k_dh,
        &leaf_ad_attacker,  // WRONG leaf_ad
        &r_pub,
        &asset_id,
        serial_id,
    );
    
    assert!(result.is_err(), "Must reject rebinding");
}
```

---

**📋 Implementation Checklist: 4.6.5 Malleability Resistance**

- [x] **Implement `test_enc_pack_rebinding_rejected`** using real API
  - [x] Uses `ZkPack::encrypt/decrypt` with `[u8;32]` inputs
  - [x] `leaf_ad` values differ by 1 bit
  - [x] Decrypt with attacker `leaf_ad` returns `None`
  - [x] Wrapper types are not used
  - [x] No `OsRng`/`thread_rng()` used
- [x] **Test `test_owner_tag_substitution_rejected`**
  - [x] Computes `leaf_ad_A` and `leaf_ad_B` with different `owner_tag`
  - [x] Encrypt with A, decrypt with B returns `None`
- [x] **Test `test_c_amount_substitution_rejected`**
  - [x] Computes `leaf_ad_A` and `leaf_ad_B` with different `c_amount`
  - [x] Encrypt with A, decrypt with B returns `None`
- [x] **CI guarantee**: all 3 malleability tests pass in release/test-fast runs
- [x] **Import**: `compute_leaf_ad` from `z00z_wallets::core::stealth::tag` is used in these tests

---

### 4.6.6 Testing Strategy

**Unit Tests:**

```yaml
pack_key_derivation:
  - test_pack_key_uniqueness_from_k_dh
  - test_pack_key_uniqueness_from_asset_id
  - test_pack_key_deterministic
  
nonce_derivation:
  - test_nonce_uniqueness_from_r_pub
  - test_nonce_binding_to_leaf_ad
  - test_nonce_deterministic
  
tag_computation:
  - test_tag_deterministic
  - test_tag_sensitivity_to_ciphertext
  - test_tag_sensitivity_to_leaf_ad
  - test_constant_time_verify
  
encryption_decryption:
  - test_encrypt_decrypt_roundtrip
  - test_decrypt_rejects_tampered_ciphertext
  - test_decrypt_rejects_wrong_leaf_ad
```

**Integration Tests:**

```yaml
full_workflow:
  - test_sender_creates_encrypted_output
  - test_receiver_scans_and_decrypts
  - test_commitment_opens_after_decryption
  
malleability:
  - test_enc_pack_cannot_be_rebound
  - test_different_k_dh_fails_decryption
```

**Golden Vectors:**

```yaml
purpose: "Ensure wallet and OWF circuit agree"

vector_1:
  inputs:
    k_dh: "0x1111...1111"
    leaf_ad: "0x2222...2222"
    r_pub: "0x3333...3333"
    asset_id: "0x4444...4444"
    serial_id: 0
    plaintext: "AssetPackPlain with fixed values"
  expected:
    pack_key: "0x...."
    nonce: "0x...."
    ciphertext: "0x...."
    tag: "0x...."
```

---

**📋 Implementation Checklist: 4.6.6 Testing Strategy**

- [x] **`derive_pack_key` tests** (in `facade_kdf.rs`)
  - [x] `test_key_deterministic`
  - [x] `test_key_diff_dh`
  - [x] `test_key_diff_asset`
  - [x] `test_key_diff_serial`
- [x] **`derive_pack_nonce` tests**
  - [x] `test_nonce_deterministic`
  - [x] `test_nonce_diff_rpub`
  - [x] `test_nonce_diff_leaf`
- [x] **`ZkPack::encrypt` / `ZkPack::decrypt` tests**
  - [x] `test_enc_roundtrip`
  - [x] `test_ct_flip_none`
  - [x] `test_aad_wrong_none`
  - [x] `test_wrong_kdh_none`
- [x] **Full workflow tests**
  - [x] `test_sender_receiver_roundtrip` / `test_alice_sends_asset_to_bob` cover sender+receiver+commitment/range proof path
  - [x] Decrypt/verify flow is validated in release/test-fast integration tests
- [x] **Golden vectors — placeholders replaced with real values**
  - [x] Real values were obtained via deterministic test run
  - [x] Values are fixed in `specs/009-z00z-ecc-spec-4/test_vectors/zkpack_golden.yaml`
  - [x] YAML is read by `test_golden_yaml_v1` via `YamlCodec`
  - [x] YAML-backed assertions gate KDF/AEAD drift in tests
- [x] **All tests use `SystemRngProvider.rng()`** — no `thread_rng()` usage in wallet source paths

---

### 4.6.7 OWF Circuit Integration

> ⚠️ **FUTURE ZK DESIGN:** This section describes the **planned ZK circuit** for enc_pack verification.
> The circuit requires a Poseidon2-based AEAD (Z00Z/PACKSTR keystream + Z00Z/PACKTAG MAC).
> The **current wallet implementation** uses ChaCha20Poly1305 (not provable in ZK circuits).
> Migration to ZK-compatible AEAD is required before implementing OWF proofs.

**Constraints:**

```yaml
OWFConstraints_EncPack:
  public_inputs:
    - enc_pack (ciphertext)
    - R_pub
    - asset_id
    - serial_id
    - leaf_ad
    - view_pk
    
  witness_inputs:
    - r (ephemeral scalar)
    - k_dh
    - asset_pack_plain
    
  constraints:
    1: "R_pub == r * G"
    2: "k_dh == H_zk('Z00Z/DH' || Compress(r * view_pk))"
    3: "pack_key == H_zk('Z00Z/PACKKEY' || k_dh || asset_id || serial_id)"
    4: "nonce == H_zk('Z00Z/PACKNONCE' || leaf_ad || R_pub || asset_id || serial_id)"
    5: "ciphertext == asset_pack_plain XOR Keystream(pack_key, nonce, leaf_ad)"
    6: "tag == H_zk('Z00Z/PACKTAG' || pack_key || nonce || leaf_ad || ciphertext || len)"
    7: "enc_pack == version || ciphertext || tag"  // tag is LAST per wire format (§4.6.2.4)
```

**Pseudocode:**

```rust
fn constrain_enc_pack(
    cs: &mut impl ConstraintSystem,
    enc_pack: CircuitVar,
    r_pub: CircuitVar,
    asset_id: CircuitVar,
    serial_id: CircuitVar,
    leaf_ad: CircuitVar,
    view_pk: CircuitVar,
    r: CircuitVar,
    k_dh: CircuitVar,
    asset_pack_plain: CircuitVar,
) {
    // 1) Verify R_pub = r * G
    let r_point = cs.ecc_mul_base(r);
    let r_comp = cs.ecc_compress(r_point);
    cs.assert_eq(r_comp, r_pub);
    
    // 2) Verify k_dh = H_zk("Z00Z/DH" || Compress(r * view_pk))
    let dh_point = cs.ecc_mul(r, view_pk);
    let dh_comp = cs.ecc_compress(dh_point);
    let k_dh_calc = cs.hash32(b"Z00Z/DH", &[dh_comp]);
    cs.assert_eq(k_dh_calc, k_dh);
    
    // 3) Derive pack_key
    let pack_key = cs.hash32(b"Z00Z/PACKKEY", &[k_dh, asset_id, serial_id]);
    
    // 4) Derive nonce
    let nonce = cs.hash32(b"Z00Z/PACKNONCE", &[leaf_ad, r_pub, asset_id, serial_id]);
    
    // 5) Generate keystream and verify encryption
    // NOTE: AssetPackPlain is 72 bytes (value:8 + blinding:32 + s_out:32)
    let keystream = cs.poseidon_xof(b"Z00Z/PACKSTR", &[pack_key, nonce, leaf_ad], 72);
    let ciphertext_calc = cs.xor_bytes(asset_pack_plain, keystream);
    
    // 6) Compute and verify tag
    let tag_calc = cs.hash32(b"Z00Z/PACKTAG", &[pack_key, nonce, leaf_ad, ciphertext_calc, 72]);
    
    // 7) Parse and verify enc_pack
    // Wire format: version(1B) || ciphertext(Nb) || tag(16B) — tag is LAST (see §4.6.2.4)
    let (version, ciphertext_received, tag_received) = cs.parse_enc_pack(enc_pack);
    cs.assert_eq(version, 1);
    cs.assert_eq(ciphertext_received, ciphertext_calc);
    cs.assert_eq(tag_received, tag_calc);
}
```

---

**📋 Implementation Checklist: 4.6.7 OWF Circuit Integration**

> ⚠️ FUTURE ZK DESIGN. Do NOT implement until Phase 1 (Poseidon2 AEAD) is complete. The following defines the TARGET circuit design.

- [ ] **Prerequisites before any circuit work** (in strict order)
  - [ ] Phase 1 (Poseidon2 keystream + MAC) from §4.6.9 MUST be merged first
  - [ ] Golden vectors from §4.6.6 MUST be established and CI-gated first
  - [ ] `Z00Z/PACKSTR` and `Z00Z/PACKTAG` domain constants MUST be in `z00z_crypto::hash`
- [ ] **OWF constraints** (target, in future `z00z_circuit` crate)
  - [ ] C1: `R_pub == r * G` — scalar multiplication gadget
  - [ ] C2: `k_dh == H_poseidon2("Z00Z/DH" || Compress(r * view_pk))` — ECDH + Poseidon2
  - [ ] C3: `pack_key == H_poseidon2("Z00Z/PACKKEY" || k_dh || asset_id || serial_le4)`
  - [ ] C4: `nonce == H_poseidon2("Z00Z/PACKNONCE" || leaf_ad || R_pub || asset_id || serial_le4)`
  - [ ] C5: `ciphertext == plaintext XOR Keystream_poseidon2(pack_key, nonce, leaf_ad)`
  - [ ] C6: `tag == H_poseidon2("Z00Z/PACKTAG" || pack_key || nonce || leaf_ad || ciphertext || len)`
  - [ ] C7: parse `enc_pack` as `version(1B) || ciphertext(72B) || tag(16B)` — tag is LAST
- [ ] **Wire format invariants** (document in circuit code)
  - [ ] `version == 0x01` — enforce as constant in circuit
  - [ ] Total `enc_pack` = 1 + 72 + 16 = 89 bytes — assert exact length
  - [ ] `ciphertext` is 72 bytes (matches `AssetPackPlain::SIZE`)
- [ ] **Parity test** (after circuit is complete)
  - [ ] Same known inputs → wallet encrypts → circuit verifies → both pass with same golden vectors from §4.6.6

---

### 4.6.8 Security Model

```yaml
SecurityModel:
  current_implementation: "ChaCha20Poly1305 (wallet phase)"
  future_zk_implementation: "Poseidon2-based AEAD (ZK circuit phase)"
  
  assumptions_current:
    - "ChaCha20 is a secure stream cipher (IETF RFC 8439)"
    - "Poly1305 is a secure MAC (IETF RFC 8439)"
    - "ChaCha20Poly1305 provides IND-CPA and INT-CTXT"
    - "ECDH produces uniformly random shared secrets"
    - "Ephemeral scalar r is never reused"
    - "RNG provider is cryptographically secure"
    
  assumptions_future_zk:
    - "Poseidon2 is collision-resistant and preimage-resistant"
    - "Poseidon2 keystream is pseudorandom (indistinguishable from random)"
    
  guarantees:
    confidentiality: "IND-CPA"
    authenticity: "INT-CTXT (Poly1305 tag or Poseidon2 tag)"
    ad_binding: "Cannot rebound to different leaf (AAD or Poseidon2 tag over leaf_ad)"
    uniqueness: "Each output has unique (pack_key, nonce12)"
    
  attack_resistance:
    chosen_ciphertext: "AEAD decryption verifies tag atomically"
    replay: "R_pub uniqueness prevents reuse (different nonce)"
    malleability: "leaf_ad in AAD prevents rebinding"
    keystream_reuse: "Deterministic 12B nonce from unique R_pub"
    timing: "Constant-time comparison built into chacha20poly1305 crate"
    
  non_goals:
    post_quantum: "NOT PQ-secure (ECDH quantum-vulnerable)"
    metadata: "Ciphertext length reveals plaintext length"
```

---

**📋 Implementation Checklist: 4.6.8 Security Model**

- [x] **Current implementation audit**
  - [x] `chacha20poly1305` pinned in `crates/z00z_wallets/Cargo.toml`
  - [x] `thread_rng` / `OsRng` absent in `crates/z00z_wallets/src/**`
  - [x] Ephemeral `r` generation path uses fresh RNG bytes in `core/stealth/ephemeral.rs`
- [x] **IND-CPA guarantee** — code comments added at ephemeral scalar generation
  - [x] `// SECURITY: r is generated fresh per output (IND-CPA). NEVER reuse r.`
  - [x] No `r` cache path found in reviewed wallet stealth flow
- [x] **INT-CTXT guarantee** — code comments added at decrypt path
  - [x] Atomic AEAD tag/decrypt comment added in `ZkPack::decrypt`
  - [x] `ZkPack::decrypt` returns `None` on authentication failure
  - [x] No split plaintext-then-tag path exists
- [x] **Non-goals documentation** — added to `z00z_wallets/src/core/stealth/facade_zkpack.rs`
  - [x] Post-quantum non-goal comment added
  - [x] Metadata-hiding non-goal comment added
- [x] **Future ZK migration tracking**
  - [x] `TODO Phase-1-ZK` comment added in `facade_zkpack.rs`
  - [x] Tracking is documented inline in code/spec for the Phase 1 migration

### 4.6.9 Implementation Phases

> ✅ **STATUS UPDATE:** Phases 2 and 3 below are **IMPLEMENTED** using ChaCha20Poly1305.
> Phase 1 (Poseidon2 sponge) is required only for ZK circuit integration (future milestone).
> Phase 4 (EncryptedPack wrapper) is partially done — `ZkPackEncrypted` exists in `z00z_crypto`.

**Phase 0: ChaCha20Poly1305 enc_pack — ✅ COMPLETE**

```yaml
status: "IMPLEMENTED in z00z_wallets::core::stealth::facade_zkpack"
implemented:
  - "ZkPack::encrypt() → ZkPackEncrypted"
  - "ZkPack::decrypt() → Option<Vec<u8>>"
  - "derive_pack_key() via hash_zk Z00Z/PACKKEY"
  - "derive_pack_nonce() via hash_zk Z00Z/PACKNONCE"
  - "make_aad() = version || leaf_ad || r_pub || asset_id || serial_le4"
  - "ZkPackEncrypted { version: u8, ciphertext: Vec<u8>, tag: [u8; 16] }"

WARNING — LEGACY PATH STILL ACTIVE (migration required):
  description: >
    stealth/output.rs::build_tx_stealth_output (used by TxStealthOutput)
    still uses the OLD encryption path and does NOT call ZkPack.
  legacy_path:
    file: "z00z_wallets/src/core/stealth/output.rs"
    function: "encrypt_asset_pack(k_dh, amount, asset_id)"
    aad: "b\"Z00Z/COINPACK_v1\"  ← static constant, NOT leaf_ad-based"
    payload: "[amount_le8 || asset_id_32]  ← 40 bytes, NOT AssetPackPlain (72 bytes)"
    encryption: "aead::seal(k_dh, AAD, payload)  ← NOT ZkPack 6-arg API"
  canonical_path:
    file: "z00z_wallets/src/core/tx/mod.rs"
    function: "sender_create_output_for(card, amount) → AssetLeaf"
    description: "Uses ZkPack::encrypt 6-arg API with AssetPackPlain payload — this IS the spec."
  action_required: >
    MUST migrate build_tx_stealth_output to ZkPack::encrypt before protocol finalization.
    Legacy path produces incompatible enc_pack format (40-byte payload vs 72-byte AssetPackPlain).
```

**Phase 1: Poseidon2 AEAD Integration (ZK Circuit blocker)**

```yaml
status: "NOT STARTED — required for OWF ZK proof integration"
tasks:
  1: "Define ZkHash trait in z00z_crypto/src/hash.rs"
  2: "Implement Poseidon2 sponge (Z00Z/ZKPACK, Z00Z/PACKSTR, Z00Z/PACKTAG)"
  3: "Migrate ZkPack from ChaCha20Poly1305 to Poseidon2 AEAD"
  4: "Unit tests for hash correctness"
  5: "Generate golden vectors for wallet-circuit synchronization"
  
acceptance:
  - "hash_concat() produces deterministic outputs"
  - "Poseidon2 keystream matches circuit gadget"
  - "Tag = H_zk(Z00Z/PACKTAG || ...) matches circuit computation"
  - "Golden vectors match circuit"
```

**Phase 2: Key & Nonce Derivation — ✅ IMPLEMENTED**

```yaml
status: "IMPLEMENTED in z00z_wallets::core::stealth::facade_kdf"
functions:
  - "derive_pack_key(k_dh, asset_id, serial_id) → [u8;32]"
  - "derive_pack_nonce(leaf_ad, r_pub, asset_id, serial_id) → [u8;32]"
```

**Phase 3: AEAD Encryption/Decryption — ✅ IMPLEMENTED (ChaCha20Poly1305)**

```yaml
status: "IMPLEMENTED — see Phase 0"
note: "Will be re-implemented with Poseidon2 AEAD in Phase 1"
```

**Phase 4: z00z_core Integration (P2)**

```yaml
tasks:
  1: "Create EncryptedPack wrapper if needed"
  2: "Update module exports"
  3: "Integration tests with AssetPackPlain"
  4: "Documentation"
```

**Phase 5: OWF Circuit Synchronization (P2)**

```yaml
tasks:
  1: "Generate golden vectors (wallet)"
  2: "Implement enc_pack constraints (circuit)"
  3: "Verify against golden vectors"
  4: "End-to-end test"
  
acceptance:
  - "Wallet and circuit produce identical enc_pack"
  - "Circuit rejects invalid enc_pack"
  - "Golden vectors stable"
```

---

**📋 Implementation Checklist: 4.6.4.1 EncryptedPack Wrapper**

- [x] **`EncryptedPack` wrapper DOES NOT EXIST** — confirmed
  - [x] `AssetLeaf` holds `enc_pack: ZkPackEncrypted` directly
  - [x] `EncryptedPack` struct was not created
- [ ] **When `EncryptedPack` wrapper IS approved** (PROPOSED):
  - [ ] Create `z00z_core/src/assets/enc_pack.rs` with `pub struct EncryptedPack(ZkPackEncrypted)`
  - [ ] `pub fn encrypt(k_dh: &[u8;32], leaf_ad: &[u8;32], r_pub: &[u8;32], asset_id: &[u8;32], serial_id: u32, plaintext: &AssetPackPlain) -> Self`
    - [ ] Internally calls `ZkPack::encrypt(...)` from `z00z_wallets`
    - [ ] Serializes `AssetPackPlain` to `[u8;72]` via `to_bytes()`
  - [ ] `pub fn decrypt(&self, k_dh: &[u8;32], leaf_ad: &[u8;32], r_pub: &[u8;32], asset_id: &[u8;32], serial_id: u32) -> Option<AssetPackPlain>`
    - [ ] Internally calls `ZkPack::decrypt(...)` and then `AssetPackPlain::from_bytes`
- [ ] **OWF golden vectors** MUST be established before this phase
  - [ ] Create golden test vectors: wallet encrypt → circuit decrypts identically
  - [ ] Store in `specs/` or `tests/golden/` as YAML or JSON
  - [ ] CI must verify golden vectors pass on every commit
- [ ] **Acceptance criteria** (must all pass before closing this section):
  - [ ] Wallet and OWF circuit produce identical `enc_pack` for same inputs
  - [ ] Circuit rejects invalid `enc_pack` (returns verification failure)
  - [ ] Golden vectors are stable (no changes between commits)

---

**📋 Implementation Checklist: 4.6.9 Implementation Phases**

- [x] **Phase 0 (✅ COMPLETE) — verified end-to-end**
  - [x] `ZkPack::encrypt` signature confirmed and tested in release/test-fast
  - [x] `ZkPack::decrypt` signature confirmed and tested in release/test-fast
  - [x] `derive_pack_key` exists in `facade_kdf.rs`
  - [x] `derive_pack_nonce` exists in `facade_kdf.rs`
  - [x] `make_aad()` returns 101-byte AAD profile
- [x] **🚨 BLOCKER: Remove legacy path (CONFIRMED EXISTS — §4.0.2 BLOCKER-2)**
  - [x] `encrypt_asset_pack` removed from `stealth/output.rs`
  - [x] Legacy output path now uses `ZkPack::encrypt` + `AssetPackPlain` (72-byte plaintext)
  - [x] Legacy AAD-only payload path removed (`aead::seal` + `Z00Z_ASSET_PACK_AAD`)
  - [x] `cargo check -p z00z_wallets --release --features test-fast` passes
- [x] **Phase 2 (✅ COMPLETE) — verified**
  - [x] `derive_pack_key` and `derive_pack_nonce` exist in `facade_kdf.rs`
  - [x] Both use domain-separated `hash_zk` (not HKDF/SHA256)
- [ ] **Phase 1 (⏳ NOT STARTED) — Poseidon2 AEAD migration, ZK blocker**
  - [ ] DO NOT start until explicit milestone approval from team
  - [ ] Define `ZkHash` trait in `z00z_crypto/src/hash.rs`
  - [ ] Poseidon2 keystream (`Z00Z/PACKSTR`): `keystream(pack_key, nonce, leaf_ad, len=72) -> [u8;72]`
  - [ ] Poseidon2 MAC (`Z00Z/PACKTAG`): `mac(pack_key, nonce, leaf_ad, ciphertext) -> [u8;16]`
  - [ ] Replace `ChaCha20Poly1305` in `ZkPack` with Poseidon2 AEAD
  - [ ] Golden vectors MUST be validated with OWF circuit team BEFORE merging
- [x] **Phase 4 (⏳ PENDING) — `EncryptedPack` wrapper**
  - [x] `EncryptedPack` is not created (approval pending)
  - [x] `AssetLeaf.enc_pack` continues to use `ZkPackEncrypted` directly
- [ ] **Phase 5 (⏳ FUTURE) — OWF Circuit Synchronization**
  - [ ] After Phase 1: generate 10+ golden vectors in `tests/vectors/zkpack_golden.yaml`
  - [ ] Read via `z00z_utils::codec::YamlCodec` — NEVER `serde_yaml::from_str`
  - [ ] Circuit implements `constrain_enc_pack(...)` per §4.6.7
  - [ ] End-to-end: wallet encrypts → circuit verifies → both pass

---

## 4.7 Leaf Associated Data (leaf_ad)

### PhasePhase 22 

### 4.7.0 Overview & Purpose

**Purpose:** `leaf_ad` (Leaf Associated Data) is a cryptographic binding that prevents enc_pack malleability attacks by tying the encrypted asset pack to specific leaf fields. This ensures that an attacker cannot copy `enc_pack` from one output and paste it into another output with different public parameters.

**Security Model:**

```yaml
Anti-Malleability Guarantee:
  threat: Attacker extracts enc_pack from output A
  goal: Paste enc_pack into output B (different R_pub, owner_tag, C_amount)
  defense: leaf_ad binds enc_pack to public leaf fields
  outcome: Tag verification fails → decrypt rejected
  
  attack_scenarios:
    - rebinding_attack: Copy enc_pack to leaf with different owner_tag
    - substitution_attack: Replace C_amount while keeping enc_pack
    - replay_attack: Reuse old enc_pack in new leaf (different R_pub)
  
  countermeasure:
    - leaf_ad includes ALL public leaf fields
    - enc_pack AEAD tag computed over (pack_key, nonce, leaf_ad, ciphertext)
    - Changing ANY field in leaf → leaf_ad changes → tag mismatch → rejection
```

**Architecture Context:**

```mermaid
graph TB
    subgraph "Output Leaf Structure"
        R[R_pub: r*G]
        OT[owner_tag]
        CA[C_amount]
        AID[asset_id]
        SID[serial_id]
        EP[enc_pack]
    end
    
    subgraph "leaf_ad Computation"
        R --> LAD
        OT --> LAD
        CA --> LAD
        AID --> LAD
        SID --> LAD
        LAD[leaf_ad = H_zk<br/>Z00Z/LEAFAD<br/>all fields]
    end
    
    subgraph "enc_pack AEAD"
        LAD --> TAG[tag = Poly1305<br/>via AAD leaf_ad<br/>ChaCha20Poly1305]
        EP --> TAG
    end
    
    TAG --> VER{Tag Verify}
    VER -->|Match| DEC[Decrypt OK]
    VER -->|Mismatch| REJ[Reject]
    
    style LAD fill:#f9f,stroke:#333,stroke-width:4px
    style TAG fill:#ff9,stroke:#333,stroke-width:2px
    style REJ fill:#f66,stroke:#333
```

**Key Properties:**

1. **Binding:** leaf_ad cryptographically links enc_pack to the exact leaf context
2. **Uniqueness:** Each output has unique leaf_ad (guaranteed by R_pub uniqueness)
3. **Deterministic:** Same inputs always produce same leaf_ad (testable/reproducible)
4. **Consensus-critical:** MUST use H_zk (Poseidon2) for ZK proof compatibility
5. **Malleability resistance:** Any field change invalidates enc_pack tag

---

**📋 Implementation Checklist: 4.7.0 Overview & Purpose**

- [x] **Verify `compute_leaf_ad` binds ALL 5 public leaf fields**
  - [x] Located in `z00z_wallets/src/core/stealth/tag.rs` with 5-field signature
  - [x] Preimage order is `asset_id || serial_id_le4 || r_pub || owner_tag || c_amount` (132 bytes total)
  - [x] `serial_id.to_le_bytes()` is used (4-byte LE)
  - [x] Uses `hash_zk::<WalletLeafAdHashProdDomain>("Z00Z/LEAFAD", ...)`
- [x] **Verify anti-malleability in receiver scan path**
  - [x] In wallet scan paths, `ZkPack::decrypt` is called only after local `compute_leaf_ad(...)` derivation
  - [x] No decrypt path uses ledger-provided/unverified `leaf_ad`
  - [x] `leaf_ad` is re-derived from leaf public fields in scanner code paths
- [x] **Malleability tests** (all 5 fields have dedicated coverage)
  - [x] `test_bind_asset_id`: change `asset_id` → different `leaf_ad` and decrypt reject
  - [x] `test_bind_serial_id`: change `serial_id` → different `leaf_ad` and decrypt reject
  - [x] `test_bind_r_pub`: change `r_pub` → different `leaf_ad` and decrypt reject
  - [x] `test_bind_owner_tag`: change `owner_tag` → different `leaf_ad` and decrypt reject
  - [x] `test_bind_c_amount`: change `c_amount` → different `leaf_ad` and decrypt reject
  - [x] Each case enforces: encrypt with original context, decrypt with modified context => `None`
- [x] **Property tests**
  - [x] `test_leaf_ad_deterministic`
  - [x] `test_leaf_ad_unique`
- [x] **Architecture doc**
  - [x] Added module comment in `z00z_wallets/src/core/stealth/tag.rs` about 5-field binding and invalidation on change

### PhasePhase 23 

### 4.7.1 Canonical Formula Specification

#### 4.7.1.1 Formula Definition

**Canonical formula (MUST):**

```yaml
leaf_ad = H_zk("Z00Z/LEAFAD" || asset_id || serial_id || R_pub || owner_tag || C_amount)

Domain Separator: "Z00Z/LEAFAD"
Hash Function: H_zk (Poseidon2 sponge)

Input Fields:
  1. asset_id:    [u8; 32]  - Asset secret hash
  2. serial_id:   u32       - Version/sequence number
  3. R_pub:       Point     - Ephemeral public key (compressed Ristretto, 32 bytes)
  4. owner_tag:   [u8; 32]  - Receiver identifier hash
  5. C_amount:    Point     - Pedersen commitment (compressed Ristretto, 32 bytes)

Total Input Size: 32 + 4 + 32 + 32 + 32 = 132 bytes

Output:
  leaf_ad: [u8; 32] - Anti-malleability binding hash
```

**Source reference:**

From `Z00Z-ECC-StealthAddress-5.md` line 756:

```
leaf_ad = H("Z00Z/LEAFAD" || asset_id || serial_id || R || owner_tag || C_amount)
```

From `Z00Z-ECC-StealthAddress-5.md` line 3081 (Hash Policy):

```yaml
leaf_ad: H_zk("Z00Z/LEAFAD" || asset_id || serial_id || R || owner_tag || C_amount)
```

**Field order rationale:**

```yaml
Canonical Order (MUST NOT change):
  Position 1: asset_id
    - Primary key for JMT leaf lookup
    - First field to check in validation
    
  Position 2: serial_id
    - Version/format identifier
    - Related to asset metadata context
    
  Position 3: R_pub
    - Ephemeral key (sender-generated randomness)
    - Source of k_dh uniqueness via ECDH
    
  Position 4: owner_tag
    - Receiver binding (derived from k_dh)
    - Depends on R_pub conceptually
    
  Position 5: C_amount
    - Commitment (final cryptographic binding)
    - Last field to ensure all prior context included

Security Property:
  - Swapping any two fields MUST produce different hash
  - Prevents accidental implementation bugs where order differs
  - Test MUST verify order sensitivity
```

**Hash function selection (H_zk vs H_wallet):**

```yaml
Why H_zk (Poseidon2):
  Cost Analysis:
    - Poseidon2 in ZK circuit: ~10-50 constraints
    - Blake2b in ZK circuit: ~50,000 constraints
    - Cost reduction: 1000x cheaper proofs
    
  Consensus Requirement:
    - leaf_ad used in OWF circuit constraints
    - OWF proves enc_pack binds to (asset_id, R_pub, owner_tag, C_amount)
    - Circuit must compute identical leaf_ad to wallet
    - Poseidon2 efficiently implementable in both wallet and circuit
    
  Two-Hash-Stack Architecture:
    - H_zk (Poseidon2): Values in TxProof/CheckpointProof
    - H_wallet (Blake2b): Wallet-internal operations only
    - Separation rule: Consensus-critical → H_zk, Wallet-only → H_wallet
    
Reference: Section 4.6.0 "Architecture Overview" for detailed two-hash-stack rationale
```

---

**📋 Implementation Checklist: 4.7.1.1 Formula Definition**

- [x] **Use existing `compute_leaf_ad` in current architecture (`z00z_wallets::core::stealth::tag`)**
  - [x] Current signature: `compute_leaf_ad(asset_id, serial_id, r_pub, owner_tag, c_amount) -> [u8;32]`
  - [x] Canonical formula and order are implemented: `asset_id || serial_id_le4 || r_pub || owner_tag || c_amount`
  - [x] Canonical preimage size constant added: `LEAF_PREIMAGE_SIZE = 132`
  - [x] Canonical encoder added: `encode_leaf_preimage(...)`
- [x] **LeafAd hash domain is registered and frozen in current domain model**
  - [x] Domain type: `WalletLeafAdHashProdDomain` via `hash_domain!` in `z00z_wallets/src/core/domains.rs`
  - [x] Frozen snapshot assertion exists (`test_pack_domains_frozen`)
- [x] **`serial_id` encoding** uses `serial_id.to_le_bytes()` (4-byte LE)
- [x] **Return value** is raw `[u8;32]` and used as AEAD AAD
- [x] **Unit tests**
  - [x] `test_leaf_ad_deterministic`
  - [x] `test_all_fields_change` (+ per-field `test_bind_*`)
  - [x] `test_out_len_32`
  - [x] Domain stability snapshot covered by domains test suite

#### 4.7.1.2 Field Binding Analysis

**Why each field is included:**

**Field 1: asset_id ([u8; 32])**

```yaml
Purpose: Binds enc_pack to the canonical public asset leaf namespace
Derivation: asset_id is the public leaf key carried by the output and used in JMT and leaf_ad

Security Guarantee:
  - Different asset secret → different asset_id → different leaf_ad
  - enc_pack encrypted for asset A cannot be used for asset B
  
Attack Prevented:
  scenario: Attacker extracts enc_pack from Output_A (asset_id_A)
  goal: Paste enc_pack into Output_B with different s_out (asset_id_B)
  defense: leaf_ad_B ≠ leaf_ad_A
  result: Tag verification fails → decrypt rejected

Cross-Reference: Section 4.2 "Asset ID Derivation" for asset_id specification
```

**Field 2: serial_id (u32)**

```yaml
Purpose: Binds enc_pack to specific version/format
Encoding: Little-endian (4 bytes)

Security Guarantee:
  - Different versions may have incompatible plaintext structures
  - Prevents cross-version confusion attacks
  - Ensures decoder uses correct AssetPackPlain layout
  
Attack Prevented:
  scenario: Attacker modifies serial_id while reusing enc_pack
  defense: leaf_ad changes → tag mismatch
  result: Decrypt rejected (even before bounded parsing)

Future-Proofing:
  - v2 format may add fields or change encoding
  - serial_id in leaf_ad ensures v2 enc_pack cannot be interpreted as v1

Cross-Reference: Section 4.3 "Serial ID" for versioning strategy
```

**Field 3: R_pub (CompressedRistretto, 32 bytes)**

```yaml
Purpose: Binds enc_pack to specific ephemeral key
Formula: R_pub = r * G (where r is one-time sender secret)

Security Guarantee:
  - Different R_pub → different k_dh (via ECDH) → cannot decrypt
  - Guarantees leaf uniqueness (r never reused per output)
  - Prevents replay attacks (old enc_pack in new transaction)
  
Attack Prevented:
  scenario: Attacker copies enc_pack from old transaction (R_pub_old)
  goal: Create new output with different R_pub_new
  defense: leaf_ad_new ≠ leaf_ad_old
  result: Tag verification fails → decrypt rejected

Uniqueness Guarantee:
  - r sampled from RNG per output (MUST NOT reuse)
  - R_pub = r*G unique on elliptic curve (DLP assumption)
  - Even same receiver + same amount → different R_pub → different leaf_ad
  - Output uniqueness inherited from ephemeral key uniqueness

Cross-Reference: Section 5.2.1 "Generate Ephemeral Secret" for r generation
```

**Field 4: owner_tag ([u8; 32])**

```yaml
Purpose: Binds enc_pack to specific receiver
Formula: owner_tag = H_zk("Z00Z/TAG" || owner_handle || k_dh)

Security Guarantee:
  - Different receiver → different owner_tag → cannot rebind enc_pack
  - Closes "decryptable-but-not-spendable" attack (M1 from source)
  - Ensures receiver can prove ownership in spend proof

Attack Prevented (Primary):
  name: Rebinding to different receiver
  scenario: Attacker extracts enc_pack encrypted for receiver A (owner_tag_A)
  goal: Paste into output with owner_tag_B (different receiver)
  defense: leaf_ad_B ≠ leaf_ad_A
  result: Tag verification fails → decrypt rejected

Attack Prevented (M1 - Decryptable-but-not-spendable):
  scenario: Attacker uses victim's view_pk (correct ECDH)
  but: Embeds attacker's owner_handle in owner_tag
  victim: Decrypts enc_pack successfully (k_dh correct)
  but: Ownership check fails (computed owner_tag ≠ leaf.owner_tag)
  result: Victim rejects as "not spendable by me"
  
  With leaf_ad binding:
    - Even if attacker creates malicious owner_tag
    - leaf_ad changes → tag mismatch
    - Decrypt rejected BEFORE M1 check
    - Defense-in-depth: Tag + M1 check

Source Reference:
  Z00Z-ECC-StealthAddress-5.md lines 784-801 (M1 anti-phishing check)
  
Cross-Reference: Section 6.3 "M1 Check" for ownership verification
```

**Field 5: C_amount (CompressedRistretto, 32 bytes)**

```yaml
Purpose: Binds enc_pack to specific Pedersen commitment
Formula: C_amount = Commit(v, r_out) = v*H + r_out*G

Security Guarantee:
  - Different commitment → different leaf_ad → cannot reuse enc_pack
  - Prevents amount substitution attacks
  - Ensures enc_pack decrypts to (v, r_out) that opens C_amount on-chain

Attack Prevented:
  scenario: Attacker extracts enc_pack containing (v=1000, r_out=x)
  goal: Create output with C_amount' = Commit(v=100, r_out'=y)
  hope: Receiver accepts v=1000 from enc_pack despite C_amount showing v=100
  defense: leaf_ad' ≠ leaf_ad (different C_amount)
  result: Tag verification fails → decrypt rejected

OWF Circuit Integration:
  - OWF proves: C_amount == Commit(v, r_out) where (v, r_out) in plaintext
  - leaf_ad in enc_pack tag binds ciphertext to specific C_amount
  - Together: Receiver ALWAYS gets (v, r_out) opening C_amount
  - Closes "Pedersen must be openable" vulnerability

Source Reference:
  Z00Z-ECC-StealthAddress-5.md lines 820-835 (OWF constraints)

Cross-Reference: 
  - Section 4.4 "Pedersen Commitment" for C_amount creation
  - Section 4.6.7 "OWF Integration" for circuit constraints
```

---

**📋 Implementation Checklist: 4.7.1.2 Field Binding Analysis**

- [x] **Field model aligned to active code path**
  - [x] Active field 1 is `asset_id` (not `owner_pk`) in `compute_leaf_ad`
  - [x] `asset_id: &[u8;32]` is passed directly
- [x] **`serial_id` field**
  - [x] Encoded with `serial_id.to_le_bytes()` only
  - [x] LE invariant comment is present in code
- [x] **`c_amount` field**
  - [x] Passed as raw 32-byte compressed commitment bytes
  - [x] No extra encoding/padding is applied
- [x] **`r_pub` field**
  - [x] Passed as raw 32-byte compressed ephemeral point bytes
- [x] **All 5 fields contribute**
  - [x] Covered by `test_all_fields_change` + per-field binding tests
- [x] **Field offsets are documented in code**
  - [x] `LEAF_PREIMAGE_SIZE` docs document `[0..32] asset_id, [32..36] serial_id, [36..68] r_pub, [68..100] owner_tag, [100..132] c_amount`

#### 4.7.1.3 Attack Matrix

**Comprehensive attack scenarios:**

| Attack Type                   | Attacker Action                          | Field Changed | Defense                         | Result                              |
| ----------------------------- | ---------------------------------------- | ------------- | ------------------------------- | ----------------------------------- |
| **Cross-asset rebinding**     | Copy enc_pack from asset A to asset B    | asset_id      | asset_id in leaf_ad             | ❌ Tag mismatch                      |
| **Version confusion**         | Use v2 enc_pack on v1 leaf               | serial_id     | serial_id in leaf_ad            | ❌ Tag mismatch                      |
| **Replay attack**             | Reuse old enc_pack in new tx             | R_pub         | R_pub in leaf_ad                | ❌ Tag mismatch                      |
| **Owner rebinding**           | Paste enc_pack to different owner_tag    | owner_tag     | owner_tag in leaf_ad            | ❌ Tag mismatch                      |
| **Amount substitution**       | Change C_amount, keep enc_pack           | C_amount      | C_amount in leaf_ad             | ❌ Tag mismatch                      |
| **Decryptable-not-spendable** | Use victim's view_pk, wrong owner_handle | owner_tag     | owner_tag in leaf_ad + M1 check | ❌ Tag mismatch (first) then M1 fail |
| **Field order swap**          | Accidentally swap field positions        | (order)       | Canonical order enforced        | ❌ Different hash                    |

**Attack failure point analysis:**

```yaml
All attacks fail at: Tag Verification Stage
Location: zkpack::decrypt() function
Timing: BEFORE plaintext is returned
Comparison: Constant-time (prevents timing attacks)

Attack Timeline:
  1. Attacker creates malicious output (modified field)
  2. Receiver computes leaf_ad (includes all 5 fields)
  3. zkpack::decrypt() recomputes tag with leaf_ad
  4. Constant-time compare: computed_tag vs received_tag
  5. Mismatch detected → Err(TagMismatch) returned
  6. Plaintext never revealed (secure failure)

Defense-in-Depth Layers:
  Layer 1: leaf_ad binding (tag verification)
  Layer 2: M1 check (owner_tag match)
  Layer 3: Bounded parsing (plaintext validation)
  Layer 4: Commitment opening check (C_amount == Commit(v, r_out))
```

---

**📋 Implementation Checklist: 4.7.1.3 Attack Matrix**

- [x] **All 7 attack types in the matrix are covered in current tests**
  - [x] Cross-asset rebinding: `test_bind_asset_id`
  - [x] Cross-user rebinding (current model via `owner_tag`): `test_bind_owner_tag`
  - [x] Replay/cross-serial: `test_bind_serial_id`
  - [x] Amount substitution: `test_bind_c_amount`
  - [x] Nonce/r_pub mismatch: `test_bind_r_pub`
  - [x] Ciphertext tampering: `test_ct_flip_none`
  - [x] Tag forgery: `test_tag_flip_none`
- [x] **Defense-in-depth layers are active**
  - [x] Layer 1: AEAD tag verification on `leaf_ad`
  - [x] Layer 2: ownership check path (owner-tag/M1 style checks in scanner flow)
  - [x] Layer 3: bounded parsing (`is_valid_length` + `from_bytes`)
  - [x] Layer 4: commitment opening check (`verify_commitment_opening`)
- [x] **Attack simulation tests are implemented in existing test modules**
  - [x] Security coverage is in `facade_zkpack.rs` tests and scanner tests

#### 4.7.1.4 Canonical Encoding Rules

**Encoding specification (MUST):**

```yaml
Field-by-Field Encoding:

  1. asset_id:
     type: [u8; 32]
     encoding: Raw bytes (no length prefix, no padding)
     offset: 0
     length: 32 bytes
     
  2. serial_id:
     type: u32
     encoding: Little-endian (LE)
     offset: 32
     length: 4 bytes
     example: 0x12345678 → [0x78, 0x56, 0x34, 0x12]
     
  3. R_pub:
     type: CompressedRistretto (curve point)
     encoding: Canonical compressed Ristretto encoding (32 bytes)
     validation: MUST decompress to valid point, MUST NOT be identity
     offset: 36
     length: 32 bytes
     
  4. owner_tag:
     type: [u8; 32]
     encoding: Raw bytes (no length prefix, no padding)
     offset: 68
     length: 32 bytes
     
  5. C_amount:
     type: CompressedRistretto (curve point)
     encoding: Canonical compressed Ristretto encoding (32 bytes)
     validation: MUST decompress to valid point, MUST NOT be identity
     offset: 100
     length: 32 bytes

Total Buffer Length: 132 bytes

Concatenation Rules:
  - NO separators between fields
  - NO length prefixes (all fields fixed-size)
  - MUST preserve canonical field order (1→2→3→4→5)
  - NO padding bytes (exact 132-byte buffer)
```

**Rust encoding implementation:**

```rust
/// Encode leaf_ad inputs into canonical 132-byte buffer.
///
/// Field order (MUST NOT change):
/// 1. asset_id (32 bytes)
/// 2. serial_id (4 bytes LE)
/// 3. R_pub (32 bytes compressed)
/// 4. owner_tag (32 bytes)
/// 5. C_amount (32 bytes compressed)
pub fn encode_leaf_ad_inputs(
    asset_id: &[u8; 32],
    serial_id: u32,
    r_pub: &CompressedRistretto,
    owner_tag: &[u8; 32],
    c_amount: &CompressedRistretto,
) -> [u8; 132] {
    let mut buffer = [0u8; 132];
    let mut offset = 0;
    
    // 1. asset_id (offset 0, length 32)
    buffer[offset..offset+32].copy_from_slice(asset_id);
    offset += 32;
    
    // 2. serial_id (offset 32, length 4) - LE encoding
    buffer[offset..offset+4].copy_from_slice(&serial_id.to_le_bytes());
    offset += 4;
    
    // 3. R_pub (offset 36, length 32) - compressed point
    buffer[offset..offset+32].copy_from_slice(r_pub.as_bytes());
    offset += 32;
    
    // 4. owner_tag (offset 68, length 32)
    buffer[offset..offset+32].copy_from_slice(owner_tag);
    offset += 32;
    
    // 5. C_amount (offset 100, length 32) - compressed point
    buffer[offset..offset+32].copy_from_slice(c_amount.as_bytes());
    // Final offset: 132
    
    buffer
}
```

**Endianness rationale:**

```yaml
Why Little-Endian for serial_id:
  Platform Consistency:
    - Rust native: u32::to_le_bytes() / u32::from_le_bytes()
    - x86-64 native: Little-endian architecture
    - Tari crypto: Uses LE for integer encoding
    
  Cross-Platform Guarantee:
    - to_le_bytes() platform-independent in Rust
    - Same result on ARM, x86, RISC-V, WASM
    - No manual byte swapping needed
    
  Circuit Alignment:
    - OWF circuit gadget MUST use same LE encoding
    - Field-to-bytes conversion in circuit: LE order
    - Golden test vectors enforce synchronization
    
  AssetPackPlain Consistency:
    - (serial_id is NOT in AssetPackPlain plaintext — it is in leaf_ad AAD)
    - Encoding in leaf_ad ensures serial_id is still cryptographically bound

Alternative Rejected:
  - Big-endian: Not Rust/Tari convention, adds complexity
  - Network byte order: Unnecessary (not transmitted over network directly)
```

**Point validation requirements:**

```yaml
Ristretto Point Validation (MUST):

  For R_pub and C_amount:
    1. Decompression Check:
       - compressed.decompress() MUST succeed
       - Returns Option<RistrettoPoint>
       - None → Err(InvalidRistrettoPoint)
       
    2. Identity Check:
       - point.is_identity() MUST be false
       - Identity point not allowed (security: zero key)
       - True → Err(IdentityPoint)
       
    3. Canonical Form Check:
       - Recompress: recomp = point.compress()
       - Compare: recomp.as_bytes() == compressed.as_bytes()
       - Mismatch → Err(NonCanonicalEncoding)

  Why Validation is Critical:
    Security:
      - Non-canonical points: Multiple byte representations → same point
      - Attack: Create two different leaf_ad for same logical leaf
      - Defense: Single canonical representation enforced
      
    Consensus:
      - All nodes must compute identical leaf_ad
      - Non-canonical point → potential consensus split
      - Validation prevents chain forks
      
    ECC Validity Rules (from source):
      - view_pk and R_pub MUST be canonically decodable Ristretto points
      - MUST NOT be identity point
      - Wallet MUST treat external data as untrusted
      - NO unwrap/expect on decompress → only reject

  Source Reference:
    Z00Z-ECC-StealthAddress-5.md lines 55-65 (ECC validity rules)
```

**Validation implementation:**

```rust
/// Validate Ristretto point is canonical and not identity.
///
/// MUST be called before encoding point into leaf_ad input buffer.
///
/// # Errors
///
/// - `InvalidRistrettoPoint` - Decompression failed (invalid bytes)
/// - `IdentityPoint` - Point is identity (zero point, not allowed)
/// - `NonCanonicalEncoding` - Point not in canonical compressed form
fn validate_ristretto_point(
    compressed: &CompressedRistretto
) -> Result<(), LeafAdError> {
    // 1. Decompress to RistrettoPoint
    let point = compressed.decompress()
        .ok_or(LeafAdError::InvalidRistrettoPoint)?;
    
    // 2. Check not identity (zero point)
    if point.is_identity() {
        return Err(LeafAdError::IdentityPoint);
    }
    
    // 3. Recompress and compare (canonical form check)
    let recompressed = point.compress();
    if recompressed.as_bytes() != compressed.as_bytes() {
        return Err(LeafAdError::NonCanonicalEncoding);
    }
    
    Ok(())
}
```

---

**📋 Implementation Checklist: 4.7.1.4 Canonical Encoding Rules**

- [x] **Field-by-field byte offsets in 132-byte preimage** are implemented and tested
  - [x] Active canonical offsets: `[0..32] asset_id`, `[32..36] serial_id_le`, `[36..68] r_pub`, `[68..100] owner_tag`, `[100..132] c_amount`
  - [x] Added constant: `LEAF_PREIMAGE_SIZE = 132`
  - [x] Added test: `test_preimage_offsets`
- [x] **`serial_id` encoding is strictly LE**
  - [x] Uses `serial_id.to_le_bytes()` only
  - [x] LE comment is present in compute path
- [x] **All fields are raw bytes** (no prefixes/separators/padding)
- [x] **Length validation is enforced structurally**
  - [x] `encode_leaf_preimage` returns fixed `[u8; LEAF_PREIMAGE_SIZE]`
  - [x] `test_preimage_offsets` verifies exact 132-byte shape
- [x] **Golden byte-offset validation**
  - [x] Offset test exists in wallet test suite (`test_preimage_offsets`)

#### 4.7.1.5 Poseidon2 Integration

**Bytes-to-field-elements packing (MUST):**

```yaml
BytesToFelts_v1 Specification:
  
  Purpose: Convert 132-byte buffer to field elements for Poseidon2 absorption
  
  Chunking Strategy:
    limb_size: 32 bits (4 bytes)
    limb_endianness: Little-endian
    
  Encoding Process:
    1. Split 132 bytes into 4-byte chunks (u32 LE)
    2. 132 bytes = 33 chunks of 4 bytes
    3. Each u32 chunk becomes one field element
    4. Field element = u32::from_le_bytes(chunk)
    
  Example:
    bytes: [0x01, 0x02, 0x03, 0x04, 0x05, 0x06, 0x07, 0x08, ...]
    chunk_0: [0x01, 0x02, 0x03, 0x04] → u32 = 0x04030201
    chunk_1: [0x05, 0x06, 0x07, 0x08] → u32 = 0x08070605
    felts: [F::from(0x04030201), F::from(0x08070605), ...]

  Field Requirements:
    - Field must support elements up to 2^32 - 1
    - Common choices: Goldilocks (2^64 - 2^32 + 1), BabyBear, BN254 scalar field
    - All chunks must fit in field (always true for 32-bit limbs)
  
  Field Element Modular Reduction (MINOR-3 Enhancement):
    description: "Each u32 chunk reduced modulo field prime if needed"
    formula: "felt = (u32::from_le_bytes(chunk) % p) where p is field modulus"
    
    common_fields:
      Goldilocks:
        prime: "p = 2^64 - 2^32 + 1"
        u32_range: "All u32 values fit without reduction (p > 2^32)"
        reduction_needed: false
        
      BabyBear:
        prime: "p = 2^31 - 2^27 + 1 (~2.1 billion)"
        u32_range: "Values >= p MUST be reduced"
        reduction_needed: true
        example:
          chunk_value: "0xFFFFFFFF (4,294,967,295)"
          reduced: "0xFFFFFFFF % 0x78000001 = 0x86FFFFFE"
        
      BN254_scalar:
        prime: "p = 21888242871839275222246405745257275088548364400416034343698204186575808495617"
        u32_range: "All u32 chunks fit (p >> 2^32)"
        reduction_needed: false
    
    canonical_encoding_rule:
      - "If chunk < p: felt = chunk (no reduction)"
      - "If chunk >= p: felt = chunk % p (reduction applied)"
      - "Reduction MUST be consistent in wallet and circuit"
      - "Use constant-time modular reduction to avoid timing leaks"
    
    implementation_note:
      wallet: "Apply reduction in BytesToFelts_v1 encoding function"
      circuit: "Apply same reduction in field gadget constraints"
      synchronization: "Golden vectors MUST include BabyBear test cases"

Source Reference:
  Z00Z-ECC-StealthAddress-5.md lines 3134-3154 (Bytes→Felts packing)
```

**Poseidon2 hash computation:**

```rust
/// Compute H_zk hash of leaf_ad inputs using Poseidon2 sponge.
///
/// This is the consensus-critical hash function that MUST match
/// the OWF circuit implementation exactly.
///
/// # Inputs
///
/// - `encoded_buffer`: 132-byte canonical encoding (from encode_leaf_ad_inputs)
///
/// # Output
///
/// - `[u8; 32]`: leaf_ad hash (32 bytes)
///
/// # Implementation Notes
///
/// 1. Domain separation: "Z00Z/LEAFAD" absorbed first
/// 2. Buffer encoding: BytesToFelts_v1 (33 field elements)
/// 3. Sponge: Poseidon2 with appropriate parameters
/// 4. Squeeze: 32 bytes from sponge state
fn hash_zk_leaf_ad(encoded_buffer: &[u8; 132]) -> [u8; 32] {
    use z00z_crypto::hash::ZkHash; // Poseidon2 sponge trait
    
    // Compute H_zk with domain separation
    ZkHash::hash_concat(&[
        b"Z00Z/LEAFAD",    // Domain separator (fixed label)
        encoded_buffer,     // 132-byte canonical encoding
    ])
}
```

**Golden vector synchronization:**

```yaml
Wallet-Circuit Synchronization Requirements:

  Problem:
    - Wallet: Rust implementation (native)
    - Circuit: Constraint gadget (R1CS/Plonkish)
    - MUST compute identical leaf_ad or consensus breaks

  Solution: Golden Test Vectors
    
    Generation (Wallet Team):
      1. Implement encode_leaf_ad_inputs() in Rust
      2. Implement hash_zk_leaf_ad() with Poseidon2
      3. Generate test vectors for various inputs
      4. Export to tests/vectors/leaf_ad_vectors.yaml
      
    Validation (Circuit Team):
      1. Implement same encoding gadget
      2. Implement same Poseidon2 gadget
      3. Load golden vectors from YAML
      4. Assert: circuit_output == wallet_output for all vectors
      
  Vector Format:
    ```yaml
    test_vector_1:
      description: "Basic leaf_ad computation"
      inputs:
        asset_id: "0x0101010101..." # 32 bytes hex
        serial_id: 1                 # u32
        r_pub: "0x0202020202..."    # 32 bytes hex (compressed Ristretto)
        owner_tag: "0x0303030303..."# 32 bytes hex
        c_amount: "0x0404040404..." # 32 bytes hex (compressed Ristretto)
      intermediate:
        encoded_buffer: "0x0101...[132 bytes hex]"
        felts: [0x04030201, 0x08070605, ...] # 33 field elements
      expected:
        leaf_ad: "0xabcdef..." # 32 bytes hex
```

  Test Coverage (MUST):
    - Basic computation (5+ different input sets)
    - Field sensitivity (change each field, verify hash changes)
    - Field order (swap pairs, verify hash changes)
    - LE encoding (serial_id endianness verification)
    - Point validation (identity rejection, non-canonical rejection)

  CI Integration:
    - Both wallet and circuit tests run on every commit
    - Failure: Any vector mismatch blocks merge
    - Ensures continuous synchronization

Cross-Reference: Section 4.7.4.3 "Golden Test Vectors" for detailed test specifications


---

**📋 Implementation Checklist: 4.7.1.5 Poseidon2 Integration**

- [x] **Poseidon2 integration uses canonical `hash_zk` path in current architecture**
  - [x] `compute_leaf_ad` calls `hash_zk::<WalletLeafAdHashProdDomain>("Z00Z/LEAFAD", ...)`
  - [x] bytes-to-felts conversion is delegated to shared `hash_zk` implementation
- [x] **Domain and output stability are covered by deterministic tests**
  - [x] Leaf-ad deterministic tests and frozen domain tests are active
  - [x] CI regression is enforced by release/test-fast test suite

###  24 4.7.2 leaf_ad API

> **IMPLEMENTED** (different location and signature): `compute_leaf_ad` in `z00z_wallets::core::stealth::tag`.
> Real signature: `compute_leaf_ad(asset_id: &[u8;32], serial_id: u32, r_pub: &[u8;32], owner_tag: &[u8;32], c_amount: &[u8;32]) -> [u8;32]`
> — takes raw `&[u8;32]` (NOT `CompressedRistretto`), returns bare `[u8;32]` (NOT `Result<LeafAd, _>`).
> — located in wallet crate, NOT in `z00z_crypto`.
> The `LeafAd` newtype and error-returning signature below are the PROPOSED future design.

#### 4.7.2.1 Module Structure

**File (proposed):** `crates/z00z_crypto/src/leaf_ad/mod.rs` — **currently in `z00z_wallets::core::stealth::tag`**

```rust
//! Leaf Associated Data (leaf_ad) computation for anti-malleability binding.
//!
//! This module implements the canonical leaf_ad derivation formula:
//! ```text
//! leaf_ad = H_zk("Z00Z/LEAFAD" || asset_id || serial_id || R_pub || owner_tag || C_amount)
//! ```
//!
//! ## Purpose
//!
//! leaf_ad prevents enc_pack malleability attacks by cryptographically binding
//! the encrypted asset pack to all public leaf fields. Any field modification
//! invalidates the enc_pack authentication tag, causing decryption to fail.
//!
//! ## Security Properties
//!
//! - **Binding:** Cryptographically links enc_pack to exact leaf context
//! - **Anti-malleability:** Any field change invalidates enc_pack tag
//! - **Deterministic:** Same inputs always produce same output
//! - **Consensus-critical:** Uses H_zk (Poseidon2) for ZK proof compatibility
//!
//! ## Usage Example
//!
//! ```ignore
//! use z00z_crypto::leaf_ad::compute_leaf_ad;
//! // NOTE: Do NOT use curve25519_dalek directly. Pass points as [u8;32] bytes
//! // obtained via z00z_crypto::Z00ZRistrettoPoint::to_bytes() / commitment.as_bytes().
//!
//! let leaf_ad = compute_leaf_ad(
//!     &asset_id,
//!     serial_id,
//!     &r_pub_compressed,
//!     &owner_tag,
//!     &c_amount_compressed,
//! )?;
//! ```
//!
//! ## Attack Prevention
//!
//! | Attack Type | Defense Mechanism |
//! |-------------|-------------------|
//! | Rebinding | owner_tag in leaf_ad → tag mismatch |
//! | Substitution | C_amount in leaf_ad → tag mismatch |
//! | Replay | R_pub in leaf_ad → tag mismatch |
//! | Cross-asset | asset_id in leaf_ad → tag mismatch |
//! | Version confusion | serial_id in leaf_ad → tag mismatch |

pub mod error;
pub mod types;

use crate::hash::ZkHash; // Poseidon2 sponge
// NOTE: Do NOT import curve25519_dalek directly — use z00z_crypto wrapper types.
// All point arguments are passed as &[u8; 32] (raw compressed bytes),
// obtained via: z00z_crypto::Z00ZRistrettoPoint::to_bytes() or Z00ZCommitment::as_bytes().
// CompressedRistretto validation is done inside compute_leaf_ad() internally.

pub use error::LeafAdError;
pub use types::LeafAd;

// ⚠️ SIGNATURE INCOMPATIBILITY: Two compute_leaf_ad implementations exist with different signatures:
//   1. EXISTING (codebase): z00z_wallets::core::stealth::tag::compute_leaf_ad
//      → takes all point args as &[u8; 32] (raw bytes, no CompressedRistretto validation)
//   2. PROPOSED (this spec): z00z_crypto::leaf_ad::compute_leaf_ad
//      → takes r_pub and c_amount as &CompressedRistretto (with point validation)
// The proposed interface below is the TARGET API. Use the existing one until migration completes.

/// Compute leaf associated data (leaf_ad) for anti-malleability binding.
///
/// # Formula
///
/// ```text
/// leaf_ad = H_zk("Z00Z/LEAFAD" || asset_id || serial_id || R_pub || owner_tag || C_amount)
/// ```
///
/// # Arguments
///
/// * `asset_id` - Asset secret hash (32 bytes)
/// * `serial_id` - Version/sequence number (u32, encoded as LE)
/// * `r_pub` - Ephemeral public key (compressed Ristretto, 32 bytes)
/// * `owner_tag` - Receiver identifier hash (32 bytes)
/// * `c_amount` - Pedersen commitment (compressed Ristretto, 32 bytes)
///
/// # Returns
///
/// * `Ok(LeafAd)` - 32-byte binding hash
/// * `Err(LeafAdError)` - Validation failure (invalid point, identity, non-canonical)
///
/// # Errors
///
/// * `InvalidRistrettoPoint` - R_pub or C_amount decompression failed
/// * `IdentityPoint` - R_pub or C_amount is identity (zero point)
/// * `NonCanonicalEncoding` - Point not in canonical compressed form
/// * `ZkHashNotImplemented` - Poseidon2 not yet integrated (Phase 1 blocker)
///
/// # Example
///
/// ```ignore
/// use z00z_crypto::{leaf_ad::compute_leaf_ad, Z00ZRistrettoPoint, Z00ZScalar};
/// use z00z_utils::rng::SystemRngProvider;
/// // MANDATORY: No curve25519_dalek or rand::rngs::OsRng imports — use z00z wrappers.
///
/// let mut rng = SystemRngProvider.rng();
/// let asset_id = [0u8; 32];
/// let serial_id = 1u32;
/// // Z00ZRistrettoPoint wraps CompressedRistretto — .to_bytes() gives [u8;32]
/// let r_pub = Z00ZRistrettoPoint::from_secret_key(&Z00ZScalar::random(&mut rng)).to_bytes();
/// let owner_tag = [1u8; 32];
/// let c_amount = Z00ZRistrettoPoint::from_secret_key(&Z00ZScalar::random(&mut rng)).to_bytes();
///
/// let leaf_ad = compute_leaf_ad(
///     &asset_id,
///     serial_id,
///     &r_pub,
///     &owner_tag,
///     &c_amount,
/// )?;
///
/// assert_eq!(leaf_ad.as_bytes().len(), 32);
/// # Ok::<_, Box<dyn std::error::Error>>(())
/// ```
///
/// # Performance
///
/// - Encoding: ~100 ns (stack allocation, no heap)
/// - Validation: ~5 μs (2x point decompress + recompress)
/// - Hashing: ~1 ms (Poseidon2, depends on field/parameters)
/// - Total: ~1 ms per leaf_ad computation
///
/// # Security Notes
///
/// - MUST validate points before encoding (rejects identity, non-canonical)
/// - Uses constant-time operations where possible (point validation not constant-time)
/// - Hash output not sensitive (public value in leaf)
pub fn compute_leaf_ad(
    asset_id: &[u8; 32],
    serial_id: u32,
    r_pub: &CompressedRistretto,
    owner_tag: &[u8; 32],
    c_amount: &CompressedRistretto,
) -> Result<LeafAd, LeafAdError> {
    // 1. Validate R_pub (MUST check before encoding)
    validate_ristretto_point(r_pub)?;
    
    // 2. Validate C_amount (MUST check before encoding)
    validate_ristretto_point(c_amount)?;
    
    // 3. Encode inputs into canonical 132-byte buffer
    let encoded = encode_leaf_ad_inputs(
        asset_id,
        serial_id,
        r_pub,
        owner_tag,
        c_amount,
    );
    
    // 4. Compute H_zk hash with domain separation
    // FUTURE: ZkHash trait does NOT yet exist in codebase.
    // Current implementation uses: hash_zk::<LeafAdDomain>("Z00Z/LEAFAD", &[...args as &[u8;32]])
    // from z00z_wallets::core::stealth::tag::compute_leaf_ad (takes &[u8;32] not &CompressedRistretto).
    // ZkHash::hash_concat below is the PROPOSED future API — do not implement until trait is defined.
    let hash_bytes = ZkHash::hash_concat(&[
        b"Z00Z/LEAFAD",    // Domain separator
        &encoded,           // 132-byte canonical encoding
    ]);
    
    Ok(LeafAd::from_bytes(hash_bytes))
}

/// Encode leaf_ad inputs into canonical 132-byte buffer.
///
/// Field order (MUST NOT change):
/// 1. asset_id (32 bytes, offset 0)
/// 2. serial_id (4 bytes LE, offset 32)
/// 3. R_pub (32 bytes compressed, offset 36)
/// 4. owner_tag (32 bytes, offset 68)
/// 5. C_amount (32 bytes compressed, offset 100)
///
/// Total: 132 bytes
fn encode_leaf_ad_inputs(
    asset_id: &[u8; 32],
    serial_id: u32,
    r_pub: &CompressedRistretto,
    owner_tag: &[u8; 32],
    c_amount: &CompressedRistretto,
) -> [u8; 132] {
    let mut buffer = [0u8; 132];
    let mut offset = 0;
    
    // 1. asset_id (32 bytes)
    buffer[offset..offset+32].copy_from_slice(asset_id);
    offset += 32;
    
    // 2. serial_id (4 bytes LE)
    buffer[offset..offset+4].copy_from_slice(&serial_id.to_le_bytes());
    offset += 4;
    
    // 3. R_pub (32 bytes compressed)
    buffer[offset..offset+32].copy_from_slice(r_pub.as_bytes());
    offset += 32;
    
    // 4. owner_tag (32 bytes)
    buffer[offset..offset+32].copy_from_slice(owner_tag);
    offset += 32;
    
    // 5. C_amount (32 bytes compressed)
    buffer[offset..offset+32].copy_from_slice(c_amount.as_bytes());
    // Final offset: 132
    
    buffer
}

/// Validate Ristretto point is canonical and not identity.
///
/// MUST be called before encoding point into leaf_ad input buffer.
///
/// # Checks
///
/// 1. Decompression succeeds (valid encoding)
/// 2. Point is not identity (non-zero)
/// 3. Recompression matches original (canonical form)
///
/// # Errors
///
/// - `InvalidRistrettoPoint` - Decompression failed
/// - `IdentityPoint` - Point is identity (zero)
/// - `NonCanonicalEncoding` - Recompression mismatch
fn validate_ristretto_point(
    compressed: &CompressedRistretto
) -> Result<(), LeafAdError> {
    // 1. Decompress to RistrettoPoint
    let point = compressed.decompress()
        .ok_or(LeafAdError::InvalidRistrettoPoint)?;
    
    // 2. Check not identity (zero point)
    if point.is_identity() {
        return Err(LeafAdError::IdentityPoint);
    }
    
    // 3. Recompress and compare (canonical form check)
    let recompressed = point.compress();
    if recompressed.as_bytes() != compressed.as_bytes() {
        return Err(LeafAdError::NonCanonicalEncoding);
    }
    
    Ok(())
}

#[cfg(test)]
mod tests {
    use super::*;
    // MANDATORY: use z00z_crypto and z00z_utils wrappers — never curve25519_dalek or rand::rngs directly
    use z00z_crypto::{Z00ZRistrettoPoint, Z00ZScalar};
    use z00z_utils::rng::SystemRngProvider;
    
    #[test]
    fn test_encode_leaf_ad_inputs_length() {
        let mut rng = SystemRngProvider.rng();
        let asset_id = [1u8; 32];
        let serial_id = 0x12345678u32;
        // Obtain compressed point bytes via Z00ZRistrettoPoint wrapper, never CompressedRistretto directly
        let r_pub_point = Z00ZRistrettoPoint::from_secret_key(&Z00ZScalar::random(&mut rng));
        let r_pub = r_pub_point.to_bytes();
        let owner_tag = [2u8; 32];
        let c_amount = Z00ZRistrettoPoint::from_secret_key(&Z00ZScalar::random(&mut rng)).to_bytes();
        
        let encoded = encode_leaf_ad_inputs(
            &asset_id,
            serial_id,
            &r_pub,
            &owner_tag,
            &c_amount,
        );
        
        // Check total length
        assert_eq!(encoded.len(), 132, "encoded buffer must be 132 bytes");
        
        // Check serial_id encoding (LE)
        let serial_bytes = &encoded[32..36];
        assert_eq!(
            serial_bytes,
            &[0x78, 0x56, 0x34, 0x12],
            "serial_id must be little-endian"
        );
        
        // Check asset_id position
        assert_eq!(&encoded[0..32], &asset_id, "asset_id at offset 0");
        
        // Check owner_tag position
        assert_eq!(&encoded[68..100], &owner_tag, "owner_tag at offset 68");
    }
}
```

---

**📋 Implementation Checklist: 4.7.2.1 Module Structure**

- [x] **Current location** remains `z00z_wallets::core::stealth::tag::compute_leaf_ad` (not moved)
  - [x] Signature verified
  - [x] Return type verified (`[u8;32]`)
  - [x] Raw array inputs verified
- [x] **PROPOSED future location** `z00z_crypto/src/leaf_ad/mod.rs` not implemented (deferred)
- [x] **Byte ordering/offsets verified**
  - [x] Added `test_preimage_offsets`
- [x] **No premature API migration**
  - [x] `LeafAd`/`LeafAdError`/`Result` API not added before approval

#### 4.7.2.2 Error Type Definitions

**File:** `crates/z00z_crypto/src/leaf_ad/error.rs`

```rust
//! Error types for leaf_ad operations.

use thiserror::Error;

/// Errors that can occur during leaf_ad computation.
#[derive(Debug, Error, Clone, PartialEq, Eq)]
pub enum LeafAdError {
    /// Ristretto point decompression failed (invalid encoding).
    ///
    /// Returned when compressed point bytes cannot be decoded to valid Ristretto point.
    /// Common causes:
    /// - Corrupted data
    /// - Random bytes (not a valid point)
    /// - Wrong curve (not Ristretto255)
    #[error("invalid Ristretto point encoding (decompression failed)")]
    InvalidRistrettoPoint,
    
    /// Point is identity (zero point) - not allowed for R_pub or C_amount.
    ///
    /// Returned when point successfully decompresses but is the identity element.
    /// Identity points are rejected for security:
    /// - R_pub = 0 → ECDH produces zero shared secret (trivial to forge)
    /// - C_amount = 0 → Invalid Pedersen commitment (amount hidden incorrectly)
    #[error("identity point not allowed (zero point rejected for security)")]
    IdentityPoint,
    
    /// Point not in canonical compressed form (multiple representations).
    ///
    /// Returned when point decompresses successfully but recompression produces
    /// different bytes. Indicates non-canonical encoding.
    /// 
    /// Security impact:
    /// - Multiple byte representations for same point
    /// - Could create two different leaf_ad for same logical leaf
    /// - Consensus failure (nodes compute different hashes)
    #[error("non-canonical point encoding (recompression mismatch)")]
    NonCanonicalEncoding,
    
    /// ZK hash function not available (Poseidon2 not yet implemented).
    ///
    /// This is a temporary error during Phase 1 development.
    /// Will be removed once Poseidon2 integration completes.
    #[error("ZK hash (Poseidon2) not implemented yet (Phase 1 blocker)")]
    ZkHashNotImplemented,
}
```

---

**📋 Implementation Checklist: 4.7.2.2 Error Type Definitions**

- [x] **`LeafAdError` remains deferred by design** (PROPOSED API)
  - [x] Not implemented before approval (as required by status note)
  - [x] Current API remains no-error-return path

#### 4.7.2.3 Type Definitions

**File:** `crates/z00z_crypto/src/leaf_ad/types.rs`

```rust
//! Type definitions for leaf_ad module.

use serde::{Deserialize, Serialize};
use std::fmt;

/// Leaf associated data (leaf_ad) - 32-byte binding hash.
///
/// This type represents the cryptographic binding between enc_pack
/// and the public leaf fields (asset_id, serial_id, R_pub, owner_tag, C_amount).
///
/// # Purpose
///
/// Prevents malleability attacks where attacker copies enc_pack from one
/// output and pastes into another with different public parameters.
///
/// # Security
///
/// - **NOT sensitive:** Public value (included in leaf)
/// - **Deterministic:** Same inputs always produce same output
/// - **Consensus-critical:** MUST match circuit computation exactly
///
/// # Example
///
/// ```ignore
/// use z00z_crypto::leaf_ad::{compute_leaf_ad, LeafAd};
///
/// let leaf_ad: LeafAd = compute_leaf_ad(...)?;
/// let bytes: &[u8; 32] = leaf_ad.as_bytes();
/// ```
#[derive(Clone, Copy, PartialEq, Eq, Hash, Serialize, Deserialize)]
pub struct LeafAd([u8; 32]);

impl LeafAd {
    /// Create LeafAd from raw bytes.
    ///
    /// No validation performed (assumes bytes from trusted source).
    pub fn from_bytes(bytes: [u8; 32]) -> Self {
        LeafAd(bytes)
    }
    
    /// Get reference to raw bytes.
    pub fn as_bytes(&self) -> &[u8; 32] {
        &self.0
    }
    
    /// Convert to owned bytes.
    pub fn to_bytes(self) -> [u8; 32] {
        self.0
    }
    
    /// Get slice view of bytes.
    pub fn as_slice(&self) -> &[u8] {
        &self.0
    }
}

impl AsRef<[u8]> for LeafAd {
    fn as_ref(&self) -> &[u8] {
        &self.0
    }
}

impl From<[u8; 32]> for LeafAd {
    fn from(bytes: [u8; 32]) -> Self {
        LeafAd(bytes)
    }
}

impl fmt::Debug for LeafAd {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(f, "LeafAd({})", hex::encode(&self.0[..8]))
    }
}

impl fmt::Display for LeafAd {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(f, "{}", hex::encode(&self.0))
    }
}
```

---

**📋 Implementation Checklist: 4.7.2.3 Type Definitions**

- [x] **`LeafAd([u8;32])` newtype remains deferred** (PROPOSED API)
  - [x] Current code intentionally uses bare `[u8;32]`
  - [x] No unapproved type migration performed
- [x] **Current code path verified**: bare `[u8;32]` in active APIs

---

### PhasePhase 24 

### 4.7.3 Integration with Existing Codebase

> **STATUS: PROPOSED.** All code below uses `EncryptedPack`, `z00z_crypto::leaf_ad::compute_leaf_ad`, and `CompressedRistretto` — none of these exist in the codebase today.
> - `compute_leaf_ad` — IMPLEMENTED at `z00z_wallets::core::stealth::tag::compute_leaf_ad` (takes `&[u8;32]`, not `&CompressedRistretto`)
> - `EncryptedPack` — NOT YET — use `ZkPack::encrypt/decrypt` in `z00z_wallets::core::stealth::facade_zkpack`
> - File path should be `z00z_core/src/assets/` not `z00z_core/src/asset/`

#### 4.7.3.1 Usage in EncryptedPack (z00z_core)

**File:** `crates/z00z_core/src/assets/enc_pack.rs` (proposed — use assets/ not asset/)

```rust
use z00z_crypto::{leaf_ad::compute_leaf_ad, zkpack, Z00ZRistrettoPoint, Z00ZCommitment};
// NOTE: Do NOT import curve25519_dalek::ristretto::CompressedRistretto.
// All point arguments are [u8;32] raw bytes from Z00ZRistrettoPoint::to_bytes()
// or Z00ZCommitment::as_bytes(). The z00z_crypto layer owns all dalek internals.

impl EncryptedPack {
    /// Encrypt asset pack with leaf_ad binding (anti-malleability).
    ///
    /// This function binds enc_pack to specific leaf fields via leaf_ad,
    /// preventing rebinding attacks where attacker copies enc_pack between outputs.
    ///
    /// # Arguments
    ///
    /// * `k_dh` - Symmetric key from ECDH (r * view_pk)
    /// * `r_pub` - Ephemeral public key (r * G), compressed
    /// * `asset_id` - Asset secret hash
    /// * `serial_id` - Version number
    /// * `owner_tag` - Receiver identifier
    /// * `c_amount` - Pedersen commitment, compressed
    /// * `asset_pack` - Plaintext to encrypt
    ///
    /// # Returns
    ///
    /// * `Ok(EncryptedPack)` - Encrypted asset pack with tag binding
    /// * `Err(EncPackError)` - Encryption failure
    ///
    /// # Security
    ///
    /// - leaf_ad computed from (asset_id, serial_id, R_pub, owner_tag, C_amount)
    /// - Any field change → different leaf_ad → tag mismatch → decrypt failed
    /// - Prevents rebinding, substitution, replay, cross-asset, version confusion attacks
    ///
    /// # Example
    ///
    /// ```ignore
    /// use z00z_core::assets::leaf::{AssetPackPlain, EncryptedPack};
    ///
    /// let enc_pack = EncryptedPack::encrypt(
    ///     &k_dh,
    ///     &r_pub_compressed,
    ///     &asset_id,
    ///     serial_id,
    ///     &owner_tag,
    ///     &c_amount_compressed,
    ///     &asset_pack,
    /// )?;
    /// # Ok::<_, Box<dyn std::error::Error>>(())
    /// ```
    pub fn encrypt(
        k_dh: &[u8; 32],
        r_pub: &CompressedRistretto,
        asset_id: &[u8; 32],
        serial_id: u32,
        owner_tag: &[u8; 32],
        c_amount: &CompressedRistretto,
        asset_pack: &AssetPackPlain,
    ) -> Result<Self, EncPackError> {
        // 1. Compute leaf_ad (binding to public fields)
        //    This creates the anti-malleability guarantee
        let leaf_ad = compute_leaf_ad(
            asset_id,
            serial_id,
            r_pub,
            owner_tag,
            c_amount,
        ).map_err(EncPackError::LeafAdComputation)?;
        
        // 2. Serialize plaintext
        let plaintext_bytes = asset_pack.to_bytes();
        
        // 3. Encrypt — ZkPack::encrypt derives pack_key and nonce internally.
        //    Signature (§4.6.3.1): encrypt(k_dh, leaf_ad, r_pub, asset_id, serial_id, plaintext) -> ZkPackEncrypted
        //    Returns ZkPackEncrypted { version:1, ciphertext, tag:[u8;16] } — infallible.
        //
        //    NOTE: r_pub is &CompressedRistretto — pass r_pub.as_bytes() to get &[u8;32].
        //    NOTE: EncryptedPack.inner holds ZkPackEncrypted — field name is `inner`, not `ciphertext`.
        let encrypted = ZkPack::encrypt(
            k_dh,
            &leaf_ad,
            r_pub.as_bytes(),
            asset_id,
            serial_id,
            &plaintext_bytes,
        );
        
        Ok(EncryptedPack { inner: encrypted })
    }
    
    /// Decrypt asset pack with leaf_ad verification (anti-malleability).
    ///
    /// # Arguments
    ///
    /// * `k_dh` - Symmetric key from ECDH
    /// * `r_pub` - Ephemeral public key, compressed
    /// * `asset_id` - Asset secret hash
    /// * `serial_id` - Version number
    /// * `owner_tag` - Receiver identifier
    /// * `c_amount` - Pedersen commitment, compressed
    ///
    /// # Returns
    ///
    /// * `Ok(AssetPackPlain)` - Decrypted and validated asset pack
    /// * `Err(EncPackError)` - Decryption/validation failure
    ///
    /// # Security
    ///
    /// - Recomputes leaf_ad from provided public fields
    /// - Verifies tag includes correct leaf_ad (constant-time comparison)
    /// - Rejects if any field changed (rebinding attack prevention)
    ///
    /// # Error Cases
    ///
    /// - `LeafAdComputation` - Point validation failed (invalid/identity/non-canonical)
    /// - `TagMismatch` - leaf_ad changed (field modified, malleability attack)
    /// - `InvalidPlaintext` - Bounded parsing failed after decrypt
    ///
    /// # Example
    ///
    /// ```ignore
    /// let asset_pack = enc_pack.decrypt(
    ///     &k_dh,
    ///     &r_pub_compressed,
    ///     &asset_id,
    ///     serial_id,
    ///     &owner_tag,
    ///     &c_amount_compressed,
    /// )?;
    /// # Ok::<_, Box<dyn std::error::Error>>(())
    /// ```
    pub fn decrypt(
        &self,
        k_dh: &[u8; 32],
        r_pub: &CompressedRistretto,
        asset_id: &[u8; 32],
        serial_id: u32,
        owner_tag: &[u8; 32],
        c_amount: &CompressedRistretto,
    ) -> Result<AssetPackPlain, EncPackError> {
        // 1. Compute leaf_ad (MUST match encryption-time value)
        let leaf_ad = compute_leaf_ad(
            asset_id,
            serial_id,
            r_pub,
            owner_tag,
            c_amount,
        ).map_err(EncPackError::LeafAdComputation)?;
        
        // 2. Decrypt — ZkPack::decrypt derives pack_key and nonce internally.
        //    Signature (§4.6.3.2): decrypt(k_dh, leaf_ad, r_pub, asset_id, serial_id, enc) -> Option<Vec<u8>>
        //    Returns None on version mismatch OR tag verification failure (constant-time AEAD).
        //
        //    NOTE: r_pub is &CompressedRistretto — pass r_pub.as_bytes() to get &[u8;32].
        //    NOTE: EncryptedPack.inner holds ZkPackEncrypted — pass &self.inner.
        let plaintext_bytes = ZkPack::decrypt(
            k_dh,
            &leaf_ad,
            r_pub.as_bytes(),
            asset_id,
            serial_id,
            &self.inner,
        ).ok_or_else(|| EncPackError::TagMismatch("tag verification failed".to_string()))?;
        
        // 3. Bounded parse plaintext (validate structure)
        let asset_pack = AssetPackPlain::from_bytes(&plaintext_bytes)
            .ok_or_else(|| EncPackError::InvalidPlaintext("invalid length".to_string()))?;
        
        Ok(asset_pack)
    }
}
```

**Update error enum:**

```rust
use z00z_crypto::leaf_ad::LeafAdError;

#[derive(Debug, Error)]
pub enum EncPackError {
    // ... existing variants ...
    
    /// leaf_ad computation failed (point validation or hash error).
    ///
    /// Causes:
    /// - R_pub or C_amount invalid/identity/non-canonical
    /// - Note: compute_leaf_ad is IMPLEMENTED (z00z_wallets::core::stealth::tag)
    #[error("leaf_ad computation failed: {0}")]
    LeafAdComputation(#[from] LeafAdError),
}
```

---

**📋 Implementation Checklist: 4.7.3.1 Usage in EncryptedPack**

- [x] **`EncryptedPack` does NOT exist** — confirm before writing any code
  - [x] All current code uses `ZkPack::encrypt/decrypt` from `z00z_wallets::core::stealth::facade_zkpack` directly
  - [x] `compute_leaf_ad` is in `z00z_wallets::core::stealth::tag`
- [ ] **When `EncryptedPack` IS created** (PROPOSED):
  - [ ] File: `z00z_core/src/assets/enc_pack.rs` (note: `assets/` not `asset/`)
  - [ ] `encrypt` calls `compute_leaf_ad` first, then `ZkPack::encrypt`
  - [ ] `decrypt` calls `compute_leaf_ad` first, then `ZkPack::decrypt`
  - [ ] Both check `leaf_ad` consistently — computed from same fields
- [ ] **Error type**: `EncPackError::LeafAdComputation(#[from] LeafAdError)` for propagation
- [x] **Test**: round-trip test working with current real API (`z00z_wallets::core::stealth`)

#### 4.7.3.2 Integration Workflow Diagram

```mermaid
sequenceDiagram
    participant Sender
    participant EncPack as EncryptedPack
    participant LeafAd as compute_leaf_ad()
    participant ZkPack as zkpack::encrypt()
    
    Sender->>EncPack: encrypt(k_dh, r_pub, asset_id, serial_id, owner_tag, c_amount, coin_pack)
    
    EncPack->>LeafAd: compute_leaf_ad(asset_id, serial_id, r_pub, owner_tag, c_amount)
    Note over LeafAd: Validate points<br/>(not identity, canonical)
    Note over LeafAd: Encode 132 bytes<br/>(LE for serial_id)
    Note over LeafAd: H_zk("Z00Z/LEAFAD" || ...)
    LeafAd-->>EncPack: leaf_ad [32 bytes]
    
    EncPack->>ZkPack: encrypt(pack_key, nonce, leaf_ad, plaintext)
    Note over ZkPack: Tag = H_zk(... || leaf_ad || ...)
    ZkPack-->>EncPack: ciphertext (ZkPackEncrypted)
    
    EncPack-->>Sender: EncryptedPack
    
    Note over Sender: Leaf created with enc_pack
    Note over Sender: Any field modification<br/>→ leaf_ad mismatch<br/>→ tag verification fails
```

**Decryption workflow:**

```mermaid
sequenceDiagram
    participant Receiver
    participant EncPack as EncryptedPack
    participant LeafAd as compute_leaf_ad()
    participant ZkPack as zkpack::decrypt()
    
    Receiver->>EncPack: decrypt(k_dh, r_pub, asset_id, serial_id, owner_tag, c_amount)
    
    EncPack->>LeafAd: compute_leaf_ad(asset_id, serial_id, r_pub, owner_tag, c_amount)
    Note over LeafAd: Validate points<br/>(reject if modified)
    Note over LeafAd: Recompute leaf_ad
    LeafAd-->>EncPack: leaf_ad [32 bytes]
    
    EncPack->>ZkPack: decrypt(pack_key, nonce, leaf_ad, ciphertext)
    Note over ZkPack: Recompute tag with leaf_ad
    Note over ZkPack: Constant-time compare:<br/>computed_tag vs received_tag
    
    alt Tag Match
        ZkPack-->>EncPack: plaintext_bytes
        Note over EncPack: Bounded parse
        EncPack-->>Receiver: AssetPackPlain
    else Tag Mismatch
        ZkPack-->>EncPack: Err(TagMismatch)
        Note over Receiver: Malleability attack detected
        EncPack-->>Receiver: Err(TagMismatch)
    end
```

---

**📋 Implementation Checklist: 4.7.3.2 Integration Workflow Diagram**

- [x] **Verify sender workflow** matches current implementation (not PROPOSED API)
  - [x] Step 1: `compute_leaf_ad(asset_id, serial_id, r_pub, owner_tag, c_amount)` → `leaf_ad: [u8;32]`
  - [x] Step 2: `ZkPack::encrypt(k_dh, &leaf_ad, r_pub_bytes, asset_id, serial_id, &plaintext_bytes)` → `enc_pack`
  - [x] Step 3: Store `enc_pack` in `AssetLeaf`
- [x] **Verify receiver workflow** matches current implementation
  - [x] Step 1: Recompute `leaf_ad` from leaf fields using same `compute_leaf_ad`
  - [x] Step 2: `ZkPack::decrypt(k_dh, &leaf_ad, r_pub_bytes, asset_id, serial_id, &enc_pack)` → `Option<Vec<u8>>`
  - [x] Step 3: `None` means authentication failed (wrong key or tampered data)
- [x] **Add integration test** with the real (non-PROPOSED) API
  - [x] `test_workflow_sender_receiver`: sender encrypts, receiver decrypts → same `AssetPackPlain`

---

### 4.7.4 Testing Strategy

> ⚠️ **STATUS: PROPOSED API.** Test code below targets the future `EncryptedPack` + richer `compute_leaf_ad(→ Result<LeafAd, LeafAdError>)` API.
> **Current implementation differs:**
> - `compute_leaf_ad` is at `z00z_wallets::core::stealth::tag::compute_leaf_ad`
> - Signature: `fn compute_leaf_ad(asset_id: &[u8;32], serial_id: u32, r_pub: &[u8;32], owner_tag: &[u8;32], c_amount: &[u8;32]) -> [u8; 32]` — takes raw bytes, returns `[u8;32]` directly (no `Result`, no point validation, no `LeafAdError`)
> - `EncryptedPack` does not exist yet — use `ZkPack::encrypt/decrypt` from `z00z_wallets::core::stealth::facade_zkpack`
> - `AssetPackPlain` (real) is 72 bytes: `{value: u64, blinding: [u8;32], s_out: [u8;32]}` — no `serial_id` field

#### 4.7.4.1 Unit Tests

**Test 1: Determinism**

```rust
#[cfg(test)]
mod tests {
    use super::*;
    // MANDATORY: use z00z_crypto wrappers and z00z_utils::rng — never dalek or OsRng directly
    use z00z_crypto::{Z00ZRistrettoPoint, Z00ZScalar};
    use z00z_utils::rng::SystemRngProvider;
    
    #[test]
    fn test_leaf_ad_deterministic() {
        let mut rng = SystemRngProvider.rng();
        // Setup inputs — compressed points as [u8;32] via Z00ZRistrettoPoint::to_bytes()
        let asset_id = [1u8; 32];
        let serial_id = 42u32;
        let r_pub = Z00ZRistrettoPoint::from_secret_key(&Z00ZScalar::random(&mut rng)).to_bytes();
        let owner_tag = [2u8; 32];
        let c_amount = Z00ZRistrettoPoint::from_secret_key(&Z00ZScalar::random(&mut rng)).to_bytes();
        
        // Compute twice
        let leaf_ad_1 = compute_leaf_ad(
            &asset_id,
            serial_id,
            &r_pub,
            &owner_tag,
            &c_amount,
        ).expect("leaf_ad computation 1 failed");
        
        let leaf_ad_2 = compute_leaf_ad(
            &asset_id,
            serial_id,
            &r_pub,
            &owner_tag,
            &c_amount,
        ).expect("leaf_ad computation 2 failed");
        
        // Assert deterministic
        assert_eq!(
            leaf_ad_1,
            leaf_ad_2,
            "leaf_ad must be deterministic (same inputs → same output)"
        );
    }
}
```

**Test 2: Field Sensitivity (Each field change alters hash)**

```rust
#[test]
fn test_leaf_ad_field_sensitivity() {
    // Setup base inputs
    let asset_id = [1u8; 32];
    let serial_id = 1u32;
    let mut rng = z00z_utils::rng::SystemRngProvider.rng();
    let mut r_pub = [0u8; 32];
    rng.fill_bytes(&mut r_pub);
    let owner_tag = [2u8; 32];
    let mut c_amount = [0u8; 32];
    rng.fill_bytes(&mut c_amount);
    
    let leaf_ad_base = compute_leaf_ad(
        &asset_id,
        serial_id,
        &r_pub,
        &owner_tag,
        &c_amount,
    ).expect("base leaf_ad failed");
    
    // Test 1: Change asset_id
    let asset_id_2 = [99u8; 32];
    let leaf_ad_diff_asset = compute_leaf_ad(
        &asset_id_2,
        serial_id,
        &r_pub,
        &owner_tag,
        &c_amount,
    ).expect("asset_id modified");
    assert_ne!(
        leaf_ad_base,
        leaf_ad_diff_asset,
        "asset_id change must alter leaf_ad"
    );
    
    // Test 2: Change serial_id
    let serial_id_2 = 99u32;
    let leaf_ad_diff_serial = compute_leaf_ad(
        &asset_id,
        serial_id_2,
        &r_pub,
        &owner_tag,
        &c_amount,
    ).expect("serial_id modified");
    assert_ne!(
        leaf_ad_base,
        leaf_ad_diff_serial,
        "serial_id change must alter leaf_ad"
    );
    
    // Test 3: Change R_pub
    let mut rng = MockRngProvider::with_seed(3).rng();
    let r_pub_2 = RistrettoPoint::random(&mut rng).compress();
    let leaf_ad_diff_r = compute_leaf_ad(
        &asset_id,
        serial_id,
        &r_pub_2,
        &owner_tag,
        &c_amount,
    ).expect("R_pub modified");
    assert_ne!(
        leaf_ad_base,
        leaf_ad_diff_r,
        "R_pub change must alter leaf_ad"
    );
    
    // Test 4: Change owner_tag
    let owner_tag_2 = [99u8; 32];
    let leaf_ad_diff_tag = compute_leaf_ad(
        &asset_id,
        serial_id,
        &r_pub,
        &owner_tag_2,
        &c_amount,
    ).expect("owner_tag modified");
    assert_ne!(
        leaf_ad_base,
        leaf_ad_diff_tag,
        "owner_tag change must alter leaf_ad"
    );
    
    // Test 5: Change C_amount
    let mut rng = MockRngProvider::with_seed(5).rng();
    let c_amount_2 = RistrettoPoint::random(&mut rng).compress();
    let leaf_ad_diff_c = compute_leaf_ad(
        &asset_id,
        serial_id,
        &r_pub,
        &owner_tag,
        &c_amount_2,
    ).expect("C_amount modified");
    assert_ne!(
        leaf_ad_base,
        leaf_ad_diff_c,
        "C_amount change must alter leaf_ad"
    );
}
```

**Test 3: Field Order Sensitivity**

```rust
#[test]
fn test_leaf_ad_field_order_matters() {
    // Verify implementation doesn't accidentally swap fields
    let field_a = [1u8; 32];
    let field_b = [2u8; 32];
    let serial_id = 1u32;
    let mut rng = MockRngProvider::with_seed(42).rng();
    let r_pub = RistrettoPoint::random(&mut rng).compress();
    let mut rng2 = MockRngProvider::with_seed(43).rng();
    let c_amount = RistrettoPoint::random(&mut rng2).compress();
    
    // Canonical order: asset_id=field_a, owner_tag=field_b
    let leaf_ad_canonical = compute_leaf_ad(
        &field_a,     // asset_id
        serial_id,
        &r_pub,
        &field_b,     // owner_tag
        &c_amount,
    ).expect("canonical order");
    
    // Swapped order: asset_id=field_b, owner_tag=field_a
    let leaf_ad_swapped = compute_leaf_ad(
        &field_b,     // asset_id (swapped)
        serial_id,
        &r_pub,
        &field_a,     // owner_tag (swapped)
        &c_amount,
    ).expect("swapped order");
    
    assert_ne!(
        leaf_ad_canonical,
        leaf_ad_swapped,
        "swapping fields must produce different hash (prevents implementation bugs)"
    );
}
```

**Test 4: Point Validation - Identity Rejection**

```rust
#[test]
fn test_leaf_ad_rejects_identity_point() {
    let asset_id = [1u8; 32];
    let serial_id = 1u32;
    let identity = CompressedRistretto::identity();
    let owner_tag = [2u8; 32];
    let mut rng = MockRngProvider::with_seed(42).rng();
    let c_amount = RistrettoPoint::random(&mut rng).compress();
    
    // Should reject identity for R_pub
    let result = compute_leaf_ad(
        &asset_id,
        serial_id,
        &identity,    // Identity point (invalid)
        &owner_tag,
        &c_amount,
    );
    assert!(
        matches!(result, Err(LeafAdError::IdentityPoint)),
        "must reject identity point for R_pub"
    );
    
    // Should reject identity for C_amount
    let mut rng = MockRngProvider::with_seed(43).rng();
    let r_pub = RistrettoPoint::random(&mut rng).compress();
    let result = compute_leaf_ad(
        &asset_id,
        serial_id,
        &r_pub,
        &owner_tag,
        &identity,    // Identity point (invalid)
    );
    assert!(
        matches!(result, Err(LeafAdError::IdentityPoint)),
        "must reject identity point for C_amount"
    );
}
```

**Test 5: Encoding Correctness - Endianness**

```rust
#[test]
fn test_encode_leaf_ad_serial_id_endianness() {
    let asset_id = [0u8; 32];
    let serial_id = 0x12345678u32;
    let mut rng = MockRngProvider::with_seed(42).rng();
    let r_pub = RistrettoPoint::random(&mut rng).compress();
    let owner_tag = [0u8; 32];
    let mut rng2 = MockRngProvider::with_seed(43).rng();
    let c_amount = RistrettoPoint::random(&mut rng2).compress();
    
    let encoded = encode_leaf_ad_inputs(
        &asset_id,
        serial_id,
        &r_pub,
        &owner_tag,
        &c_amount,
    );
    
    // Check serial_id at offset 32 (4 bytes LE)
    let serial_bytes = &encoded[32..36];
    assert_eq!(
        serial_bytes,
        &[0x78, 0x56, 0x34, 0x12],
        "serial_id must be little-endian (LE)"
    );
    
    // Verify decoding
    let decoded_serial = u32::from_le_bytes([
        serial_bytes[0],
        serial_bytes[1],
        serial_bytes[2],
        serial_bytes[3],
    ]);
    assert_eq!(
        decoded_serial,
        serial_id,
        "decoded serial_id must match original"
    );
}
```

---

**📋 Implementation Checklist: 4.7.4.1 Unit Tests**

- [x] **Implement all 5 unit tests** in `z00z_wallets/tests/` or `z00z_crypto/tests/leaf_ad.rs`
  - [x] **Test 1 (Determinism)**: same inputs → identical `leaf_ad` output
  - [x] **Test 2 (Field uniqueness)**: change `asset_id` only → different `leaf_ad`; change `serial_id` → different; change `r_pub` → different; change `owner_tag` → different; change `c_amount` → different
  - [x] **Test 3 (Wrong key decryption)**: encrypt with `k_dh_A`, decrypt with `k_dh_B` → `None`
  - [x] **Test 4 (Canonical encoding)**: verify 4-byte LE for `serial_id`: `u32::to_le_bytes(0x12345678) == [0x78, 0x56, 0x34, 0x12]`
  - [x] **Test 5 (Serial roundtrip)**: `u32::from_le_bytes(u32::to_le_bytes(serial_id)) == serial_id`
- [x] **Note**: Tests 4 and 5 reference `SerialId` newtype (PROPOSED) — use `u32::to_le_bytes()` for current code
- [x] All tests use `SystemRngProvider.rng()` when randomness is needed — no `rand::thread_rng()` usage

#### 4.7.4.2 Integration Tests

**Test 6: Full Encrypt/Decrypt Workflow**

```rust
#[test]
fn test_enc_pack_with_leaf_ad_binding() {
    use z00z_core::assets::leaf::{AssetPackPlain, EncryptedPack};
    use z00z_crypto::{PedersenCommitmentFactory, HomomorphicCommitmentFactory, Z00ZScalar, Z00ZRistrettoPoint};
    // MANDATORY: use z00z wrappers — never curve25519_dalek or rand::rngs::OsRng directly
    use z00z_utils::rng::SystemRngProvider;
    
    // Setup sender context using z00z_crypto wrappers (NOT raw dalek scalars/points)
    let mut rng = SystemRngProvider.rng();
    let r = Z00ZScalar::random(&mut rng);
    // r_pub = r * G via Z00ZRistrettoPoint::from_secret_key (base-point multiplication)
    let r_pub_point = Z00ZRistrettoPoint::from_secret_key(&r);
    let r_pub = r_pub_point.to_bytes();
    
    // Setup receiver context
    let view_sk = Z00ZScalar::random(&mut rng);
    let view_pk_point = Z00ZRistrettoPoint::from_secret_key(&view_sk);
    
    // ECDH: dh = r * view_pk — use z00z_wallets ECDH primitives in production:
    //   sender:   z00z_wallets::ecdh::sender_derive_dh(&view_pk_point)
    //   receiver: z00z_wallets::ecdh::receiver_derive_dh(&view_sk, &r_pub_point)
    // For spec illustration, calling kdf directly with a pre-computed dh:
    let sender = z00z_wallets::ecdh::sender_derive_dh_with_scalar(&r, &view_pk_point)
        .expect("ECDH must succeed for valid points");
    let k_dh = z00z_wallets::kdf::derive_k_dh(&sender.dh);
    
    // Asset pack plaintext
    let asset_pack = AssetPackPlain {
        value: 1000,
        blinding: [99u8; 32],
        s_out: [42u8; 32],
    };
    let serial_id = 1u32;
    
    // Compute public leaf fields
    let asset_id = zkpack::derive_asset_id(&asset_pack.s_out);  // s_out from asset_pack
    let owner_handle = [7u8; 32];
    let owner_tag = zkpack::derive_owner_tag(&owner_handle, &k_dh);
    let factory = PedersenCommitmentFactory::default();
    // NOTE: Tari API: commit_value(blinding: &K, value: u64) — blinding first!
    // asset_pack.blinding is [u8;32]; convert to Z00ZScalar first in real code.
    let blinding_scalar = Z00ZScalar::try_from_bytes(&asset_pack.blinding)
        .expect("valid blinding bytes from asset_pack");
    let c_amount = factory.commit_value(&blinding_scalar, asset_pack.value).compress();
    
    // Encrypt with leaf_ad binding
    let enc_pack = EncryptedPack::encrypt(
        &k_dh,
        &r_pub,
        &asset_id,
        serial_id,
        &owner_tag,
        &c_amount,
        &asset_pack,
    ).expect("encryption failed");
    
    // Decrypt (all fields match)
    let decrypted = enc_pack.decrypt(
        &k_dh,
        &r_pub,
        &asset_id,
        serial_id,
        &owner_tag,
        &c_amount,
    ).expect("decryption failed");
    
    // Verify plaintext matches (AssetPackPlain fields: value, blinding, s_out — no serial_id)
    assert_eq!(decrypted.s_out,    asset_pack.s_out,    "s_out mismatch");
    assert_eq!(decrypted.value,    asset_pack.value,    "amount (value) mismatch");
    assert_eq!(decrypted.blinding, asset_pack.blinding, "blinding mismatch");
    // NOTE: serial_id is NOT in AssetPackPlain — it is bound via leaf_ad AAD (see §4.5.1, §4.3.3)
}
```

**Test 7: Rebinding Attack Prevention**

```rust
#[test]
fn test_leaf_ad_prevents_rebinding_attack() {
    // ... setup same as Test 6 ...
    
    // Encrypt for receiver A
    let owner_tag_a = [1u8; 32];
    let enc_pack_a = EncryptedPack::encrypt(
        &k_dh,
        &r_pub,
        &asset_id,
        serial_id,
        &owner_tag_a,  // Receiver A's tag
        &c_amount,
        &asset_pack,
    ).expect("encryption failed");
    
    // Attacker tries to rebind to receiver B (different owner_tag)
    let owner_tag_b = [2u8; 32];  // Different receiver!
    
    // Decrypt attempt with wrong owner_tag (rebinding attack)
    let result = enc_pack_a.decrypt(
        &k_dh,
        &r_pub,
        &asset_id,
        serial_id,
        &owner_tag_b,  // Wrong tag! (attack)
        &c_amount,
    );
    
    // Must reject (leaf_ad mismatch → tag verification fails)
    assert!(
        result.is_err(),
        "rebinding attack must be rejected"
    );
    assert!(
        matches!(result.unwrap_err(), EncPackError::TagMismatch(_)),
        "expected tag mismatch error due to leaf_ad change"
    );
}
```

**Test 8: Amount Substitution Attack Prevention**

```rust
#[test]
fn test_leaf_ad_prevents_amount_substitution() {
    // ... setup ...
    
    // Encrypt with amount v=1000
    let v_real = 1000u64;
    let factory = PedersenCommitmentFactory::default();
    // NOTE: commit_value(blinding: &K, value: u64) — blinding FIRST per Tari API.
    // [u8;32] does NOT impl SecretKey — must convert to Z00ZScalar first.
    let r_out_real_bytes = [10u8; 32];
    let r_out_real = Z00ZScalar::try_from_bytes(&r_out_real_bytes)
        .expect("valid blinding scalar");
    let c_amount_real = factory.commit_value(&r_out_real, v_real).compress();
    
    let asset_pack = AssetPackPlain { value: v_real, blinding: r_out_real_bytes, s_out };
    
    let enc_pack = EncryptedPack::encrypt(
        &k_dh,
        &r_pub,
        &asset_id,
        serial_id,
        &owner_tag,
        &c_amount_real,  // Correct commitment
        &asset_pack,
    ).expect("encryption failed");
    
    // Attacker creates different commitment (v=100)
    let v_fake = 100u64;
    let r_out_fake_bytes = [20u8; 32];
    let r_out_fake = Z00ZScalar::try_from_bytes(&r_out_fake_bytes)
        .expect("valid blinding scalar");
    let c_amount_fake = factory.commit_value(&r_out_fake, v_fake).compress();
    
    // Decrypt attempt with wrong commitment (substitution attack)
    let result = enc_pack.decrypt(
        &k_dh,
        &r_pub,
        &asset_id,
        serial_id,
        &owner_tag,
        &c_amount_fake,  // Wrong commitment! (attack)
    );
    
    // Must reject (leaf_ad mismatch → tag verification fails)
    assert!(
        result.is_err(),
        "amount substitution attack must be rejected"
    );
    assert!(
        matches!(result.unwrap_err(), EncPackError::TagMismatch(_)),
        "expected tag mismatch error due to C_amount change"
    );
}
```

---

**📋 Implementation Checklist: 4.7.4.2 Integration Tests**

- [x] **Test 6 (Full Encrypt/Decrypt Workflow)**: full round-trip with real current API
  - [x] Create `AssetPackPlain { value: 1000, blinding: [0x22;32], s_out: [0x11;32] }`
  - [x] Generate `leaf_ad` via `compute_leaf_ad(...)` (real signature)
  - [x] `ZkPack::encrypt(...)` → `enc_pack`
  - [x] `ZkPack::decrypt(...)` → `Some(plaintext)`
  - [x] `AssetPackPlain::from_bytes(&plaintext)` → same original struct
- [x] **Test 7 (Tampered ciphertext fails)**: flip one byte in `enc_pack.ciphertext` → `None`
- [x] **Test 8 (Wrong C_amount = tag mismatch)**: encrypt with `c_amount_A`, decrypt with `leaf_ad` computed using `c_amount_B` → `None`
- [x] **Note on PROPOSED tests**: tests referencing `EncPackError::TagMismatch` require `EncryptedPack` wrapper — implemented with real `ZkPack` API instead
- [x] All tests use `SystemRngProvider.rng()` when randomness is needed — no `rand::thread_rng()` usage

#### 4.7.4.3 Golden Test Vectors

**Purpose:** Ensure wallet and OWF circuit compute identical leaf_ad.

**Test vector format (YAML):**

```yaml
# tests/vectors/leaf_ad_vectors.yaml

leaf_ad_test_vector_1:
  description: "Basic leaf_ad computation with valid inputs"
  inputs:
    asset_id: "0x0101010101010101010101010101010101010101010101010101010101010101"
    serial_id: 1
    r_pub: "0x0202020202020202020202020202020202020202020202020202020202020202"
    owner_tag: "0x0303030303030303030303030303030303030303030303030303030303030303"
    c_amount: "0x0404040404040404040404040404040404040404040404040404040404040404"
  intermediate:
    encoded_buffer: "0x0101...0404" # 132 bytes
    buffer_length: 132
  expected:
    leaf_ad: "0x<computed_hash_32_bytes>"

leaf_ad_test_vector_2:
  description: "Different serial_id (field sensitivity test)"
  inputs:
    asset_id: "0x0101010101010101010101010101010101010101010101010101010101010101"
    serial_id: 2  # Changed from vector 1
    r_pub: "0x0202020202020202020202020202020202020202020202020202020202020202"
    owner_tag: "0x0303030303030303030303030303030303030303030303030303030303030303"
    c_amount: "0x0404040404040404040404040404040404040404040404040404040404040404"
  expected:
    leaf_ad: "0x<different_hash>"  # MUST differ from vector 1

leaf_ad_test_vector_3:
  description: "Field order swap detection"
  inputs:
    asset_id: "0x0303030303030303030303030303030303030303030303030303030303030303"  # Swapped
    serial_id: 1
    r_pub: "0x0202020202020202020202020202020202020202020202020202020202020202"
    owner_tag: "0x0101010101010101010101010101010101010101010101010101010101010101"  # Swapped
    c_amount: "0x0404040404040404040404040404040404040404040404040404040404040404"
  expected:
    leaf_ad: "0x<different_hash>"  # MUST differ from vector 1 (different order)
```

**Golden vector test implementation:**

```rust
#[test]
fn test_leaf_ad_golden_vectors() {
    // Load golden vectors from YAML file
    // MANDATORY: use z00z_utils::io and z00z_utils::codec — NOT std::fs or serde_yaml directly
    use z00z_utils::{io::read_to_string, codec::{Codec, YamlCodec}};
    let vectors_yaml = read_to_string("tests/vectors/leaf_ad_vectors.yaml")
        .expect("golden vectors file not found");
    
    let vectors: Vec<LeafAdTestVector> = YamlCodec.deserialize(vectors_yaml.as_bytes())
        .expect("failed to parse golden vectors");
    
    for vector in vectors {
        // NOTE: Real compute_leaf_ad returns [u8;32] directly (no Result / no .expect())
        let result: [u8; 32] = compute_leaf_ad(
            &vector.inputs.asset_id,
            vector.inputs.serial_id,
            &vector.inputs.r_pub,
            &vector.inputs.owner_tag,
            &vector.inputs.c_amount,
        );
        
        assert_eq!(
            &result,
            &vector.expected.leaf_ad,
            "Golden vector mismatch: {}",
            vector.description
        );
    }
}
```

---

**📋 Implementation Checklist: 4.7.4.3 Golden Test Vectors**

- [x] **Create golden test vector file** in `specs/009-z00z-ecc-spec-4/test_vectors/leaf_ad_vectors.yaml`
  - [x] Format: `asset_id`, `serial_id`, `r_pub`, `owner_tag`, `c_amount` (inputs) → `leaf_ad` (expected bytes)
  - [x] Minimum: 3 vectors with different field values
- [x] **CI integration**: add test `test_golden_leaf_ad_vectors` that reads YAML and asserts outputs
  - [x] Must use `z00z_utils::codec::YamlCodec.deserialize(...)` — NEVER `serde_yaml::from_str` directly
  - [x] Test must fail if golden bytes change
- [ ] **OWF circuit parity**: golden vectors must be verified against OWF circuit output (not just wallet)
- [ ] **Snapshot test registration**: register in `z00z_crypto/tests/snapshots/` via `insta` crate or `assert_snapshot!`
- [x] **Version the vectors**: add `spec_version: "4.7.4.3-v1"` field to YAML for change tracking

---

### 4.7.5 Implementation Phases

**Phase 1 (P0): Foundation — hash_zk / Poseidon2** ✅ **COMPLETE**

> ✅ **IMPLEMENTED.** `hash_zk::<D>(label, inputs)` already exists in `z00z_crypto::hash::zk`.
> `compute_leaf_ad` in `z00z_wallets::core::stealth::tag` already calls
> `hash_zk::<WalletLeafAdHashProdDomain>("Z00Z/LEAFAD", &[asset_id, &serial, r_pub, owner_tag, c_amount])`.
> The tasks below are historical — all completed.

```yaml
Phase 1 - hash_zk / Poseidon2 Domain Hash: ✅ COMPLETE
  status: DONE
  
  completed_tasks:
    - hash_zk::<D>(label, inputs) → [u8;32] implemented in z00z_crypto::hash::zk
    - Domain type system (hash_domain! macro from tari_crypto) in place
    - WalletLeafAdHashProdDomain registered
    - compute_leaf_ad() uses hash_zk (z00z_wallets::core::stealth::tag)
    - Poseidon2 IS implemented: hash_zk() calls poseidon2_hash() (Goldilocks field,
      Poseidon2GoldilocksHL width-8) — already ZK-circuit-compatible
    
  note: "hash_zk uses native Poseidon2 (NOT BLAKE2b). Remaining ZK blocker is AEAD
         (ChaCha20Poly1305 must be migrated to Poseidon2-based AEAD for OWF circuits).
         The hash function itself is already ZK-circuit-friendly."
```

**Phase 2 (P1): leaf_ad Core Implementation**

**Phase 2 (P1): leaf_ad Core Implementation** ⚠️ PARTIALLY DONE

> ⚠️ **PARTIAL STATUS:**
> - **DONE (simple):** `compute_leaf_ad(asset_id, serial_id, r_pub, owner_tag, c_amount) -> [u8;32]` is implemented at `z00z_wallets::core::stealth::tag` using `hash_zk`.
> - **NOT YET:** `LeafAd` newtype, `LeafAdError`, `encode_leaf_ad_inputs()`, point validation (identity/canonical), `LeafAd` Result return.
> - The tasks below describe the **proposed richer version** for circuit/wallet integration.

```yaml
Phase 2 - leaf_ad Module:
  priority: P1 (unblocks enc_pack encryption)
  duration: 1 week
  depends_on: Phase 1 (hash_zk / Poseidon2) ✅ COMPLETE
  team: Wallet team
  
  tasks:
    types:
      - Implement LeafAd newtype (z00z_crypto/src/leaf_ad/types.rs)
      - Debug, Display impls
      - Serialization support (serde)
      
    errors:
      - Define LeafAdError enum (z00z_crypto/src/leaf_ad/error.rs)
      - InvalidRistrettoPoint, IdentityPoint, NonCanonicalEncoding
      - Error messages with security context
      
    encoding:
      - Implement encode_leaf_ad_inputs() (132-byte buffer)
      - LE encoding for serial_id (platform-independent)
      - Field order enforced (compile-time constants)
      
    validation:
      - Implement validate_ristretto_point()
      - Decompress → identity check → recompress → compare
      - Reject invalid/identity/non-canonical points
      
    computation:
      - Implement compute_leaf_ad() main function
      - Validate → encode → hash_zk → return LeafAd
      - Error propagation with context
      
    tests:
      - Unit tests: determinism, sensitivity, order, validation
      - 5+ test cases per category
      - Edge cases: identity, non-canonical, zero fields
      
  acceptance_criteria:
    - compute_leaf_ad() matches golden vectors from Phase 1
    - All 5 fields sensitivity tests pass
    - Identity point rejection works
    - Field order swaps produce different hashes
    - Zero panics on malformed inputs (fuzzing)
    
  integration:
    - EncryptedPack::encrypt() calls compute_leaf_ad()
    - EncryptedPack::decrypt() verifies leaf_ad
    - Error handling updated (LeafAdError → EncPackError)
    
  deliverables:
    - z00z_crypto/src/leaf_ad/ module complete
    - Unit tests (15+ tests)
    - Integration with enc_pack
```

**Phase 3 (P1): Integration & Validation**

```yaml
Phase 3 - Integration & Testing:
  priority: P1 (completes Section 4.7)
  duration: 1 week
  depends_on: Phase 2
  team: Wallet + QA team
  
  tasks:
    enc_pack_integration:
      - Update EncryptedPack::encrypt() to use compute_leaf_ad()
      - Update EncryptedPack::decrypt() to verify leaf_ad
      - Pass leaf_ad to zkpack AEAD functions
      
    error_handling:
      - Add LeafAdError to EncPackError enum
      - Proper error propagation (#[from] derive)
      - Error messages include attack context ("rebinding detected")
      
    tests_integration:
      - Full encrypt→decrypt workflow with leaf_ad
      - 3+ integration tests (workflow, rebinding, substitution)
      - Performance benchmarks (< 1 ms target)
      
    tests_attack:
      - Malleability attack prevention tests
      - Rebinding, substitution, replay scenarios
      - Verify all attacks fail at tag verification
      
    golden_sync:
      - Generate comprehensive golden vectors (10+ vectors)
      - Export to tests/vectors/leaf_ad_vectors.yaml
      - Circuit team validates against vectors
      - CI enforces synchronization
      
    docs:
      - Update specs/009-z00z-ecc-spec-4/4_Asset_Model.md with final API examples
      - Add security analysis documentation
      - Update integration diagrams
      
  acceptance_criteria:
    - Encrypt→decrypt roundtrip succeeds (happy path)
    - Rebinding attack test fails at tag verification
    - Amount substitution attack test fails
    - Replay attack test fails
    - All golden vectors pass (wallet + circuit)
    - Performance: < 2 ms total (incl. validation)
    
  deliverables:
    - Section 4.7 complete in specs/009-z00z-ecc-spec-4/4_Asset_Model.md
    - z00z_crypto/src/leaf_ad/ module functional
    - tests/vectors/leaf_ad_vectors.yaml (golden vectors)
    - Integration tests (8+ tests)
    - Documentation updates
```

---

**📋 Implementation Checklist: 4.7.5 Implementation Phases**

- [ ] **Phase 1 (✅ COMPLETE) — verify nothing regressed**
  - [ ] `compute_leaf_ad(asset_id, serial_id, r_pub, owner_tag, c_amount) -> [u8;32]` exists in `z00z_wallets/src/core/stealth/tag.rs`
  - [ ] Uses `hash_zk::<WalletLeafAdHashProdDomain>("Z00Z/LEAFAD", &preimage)` with 132-byte preimage
  - [ ] `WalletLeafAdHashProdDomain` registered via `hash_domain!` macro
  - [ ] `cargo test -p z00z_wallets` passes (confirm green)
- [ ] **Phase 2 (⚠️ PARTIAL) — remaining tasks before completion**
  - [ ] Current impl: `compute_leaf_ad(...) -> [u8;32]` (simple form) — WORKS
  - [ ] `LeafAd([u8;32])` newtype — PROPOSED ONLY; create in `z00z_crypto/src/leaf_ad/types.rs` ONLY after explicit approval
  - [ ] `LeafAdError` enum — PROPOSED ONLY; create in `z00z_crypto/src/leaf_ad/error.rs` only after approval
  - [ ] Point validation: `validate_ristretto_point(bytes: &[u8;32]) -> Result<(), LeafAdError>` — decompress, reject identity, recompress+compare
  - [ ] `encode_leaf_ad_inputs() -> [u8;132]` — creates preimage buffer, PROPOSED
  - [ ] Enhanced signature: `fn compute_leaf_ad(..., r_pub: &CompressedRistretto) -> Result<LeafAd, LeafAdError>` — AFTER approval only
  - [ ] DO NOT start Phase 2 until codebase reconciliation for §4.3.4 and §4.7.2 PROPOSED APIs is confirmed
- [ ] **Phase 3 (⏳ TODO)**
  - [ ] Update `EncryptedPack::encrypt/decrypt` to call `compute_leaf_ad` internally (only after `EncryptedPack` is approved)
  - [ ] Add `LeafAdError` to `EncPackError` with `#[from]`
  - [ ] Performance target: `compute_leaf_ad` + `ZkPack::encrypt` < 2ms combined
  - [ ] 8+ integration tests: happy path, rebinding, substitution, replay, cross-asset, version confusion
  - [ ] Golden vectors: 10+ in `tests/vectors/leaf_ad_vectors.yaml` — read via `z00z_utils::codec::YamlCodec`
  - [ ] Circuit team validates golden vectors against OWF circuit BEFORE merging
  - [ ] CI: golden vector mismatch blocks merge

---

## ✅ Section 4.7 Spec Complete (Implementation Partial)

**Summary:**

**Formula:**

```
leaf_ad = H_zk("Z00Z/LEAFAD" || asset_id || serial_id || R_pub || owner_tag || C_amount)
```

**Purpose:** Anti-malleability binding that prevents enc_pack rebinding, substitution, replay, cross-asset, and version confusion attacks.

**Key Components:**

1. **Formula Specification (4.7.1):** Canonical field order, encoding rules, H_zk rationale
2. **API Implementation (4.7.2):** `compute_leaf_ad()` (✅ IMPLEMENTED, simple form: `-> [u8;32]`); `LeafAd` newtype + `LeafAdError` (⏳ PROPOSED only)
3. **Integration (4.7.3):** EncryptedPack::encrypt/decrypt usage with workflow diagrams (⏳ PROPOSED — `EncryptedPack` not yet in codebase)
4. **Testing (4.7.4):** Tests target proposed API (⏳ PROPOSED — use current `compute_leaf_ad -> [u8;32]` for real tests)
5. **Implementation Phases (4.7.5):** Phase 1 ✅ COMPLETE (hash_zk); Phase 2 ⚠️ PARTIAL (simple `compute_leaf_ad` done, richer version pending); Phase 3 ⏳ TODO

**Security Guarantees:**

- ✅ Rebinding prevention (owner_tag binding)
- ✅ Substitution prevention (C_amount binding)
- ✅ Replay prevention (R_pub uniqueness)
- ✅ Cross-asset prevention (asset_id binding)
- ✅ Version confusion prevention (serial_id binding)

**Integration Points:**

- Used in: EncryptedPack::encrypt() for tag computation
- Verified in: EncryptedPack::decrypt() before plaintext release
- Circuit: OWF constraints verify leaf_ad matches leaf fields

**Next:** Section 5 (Output Creation - Sender Workflow) will show complete sender flow from ReceiverCard to finished OutputLeaf with all fields (R_pub, k_dh, owner_tag, leaf_ad, enc_pack, C_amount).

---

# 