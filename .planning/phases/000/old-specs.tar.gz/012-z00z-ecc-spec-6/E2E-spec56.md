# Unified E2E Spec-5 And Spec-6 Plan

📌 This document is the self-contained E2E source of truth for the Spec-5 sender side, the post-Spec-5 closure boundaries, and the implemented Spec-6 receiver pipeline.

📌 It is intended to replace the planning role of these documents:

- `E2E-spec5-EXAMPLES.md`
- `E2E-spec6-EXAMPLES.md`
- `E2E-UNIFIED-EXECUTION-ORDER.md`

📌 The purpose of this file is not to redesign the protocol. The purpose of this file is to define one complete execution-ready E2E plan, in one dependency-safe order, with no overlap between sender-side proof obligations and receiver-side proof obligations.

📌 This file is intentionally test-oriented and implementation-oriented. Every scenario explains what must be proven, how it must be executed, what must be asserted, and which live boundaries own the behavior.

## Scope

📌 This unified plan covers the full E2E path from validated receiver input to explicit receiver claim persistence.

📌 The covered areas are:

- validated receiver input handling through `PaymentRequest` and `ReceiverCard`;
- TOFU trust and receiver identity pinning behavior;
- sender-side stealth output creation through `build_tx_stealth_output()`, `build_tx_stealth_output_validated()`, and canonical full `AssetLeaf` builders;
- cryptographic binding of `k_dh`, `owner_tag`, `leaf_ad`, `s_out`, `tag16`, `enc_pack`, and `c_amount`;
- publication and downstream record handling around `ReceiverCardRecordV1`;
- cross-spec bridge proof that valid and tampered sender-side artifacts reach the implemented Spec-6 receiver path with the correct semantics;
- canonical full-leaf detection via `receiver_scan_leaf()` and `receiver_scan_report()`;
- runtime asset scanning via `StealthOutputScanner::scan_leaf()` and `scan_leaf_tag_only()`;
- wallet receive surfaces `recv_one()`, `recv_range()`, and `recv_code()`;
- RPC receive surface `receive_asset()`;
- claim boundary via `recv_route()` and wallet-native persistence;
- restart-safe range progress via `ScanStatePayload`;
- post-Spec-5 transitional closure honesty for claim, authority, spend-proof, and fee-proof tracks.

📌 This document does not propose a second receiver architecture, a second sender architecture, new consensus rules, or new proof formats.

## Core Goals

📌 A complete E2E demonstration under this plan must prove all of the following together:

1. Sender input validation is strict and no invalid receiver material reaches a legitimate sender build path.
2. Sender output creation binds the encrypted payload to public leaf fields exactly as frozen by Spec-5.
3. Lightweight `TxStealthOutput` and full `AssetLeaf` creation remain related but not confused.
4. Publication and trust artifacts preserve receiver identity semantics instead of introducing shadow data.
5. A valid sender-built artifact is consumable by the implemented Spec-6 receiver path.
6. A tampered sender-built artifact is rejected by the implemented Spec-6 receiver path without false ownership.
7. Canonical and runtime receiver paths expose one stable receive taxonomy.
8. Detection and claim persistence remain separate until the explicit claim boundary is crossed.
9. Range scanning can pause, persist cursor state, restart, and continue without semantic drift.
10. Request-aware and tag16-aware runtime optimizations never bypass canonical cryptographic validation.
11. Transitional post-Spec-5 tracks remain documented honestly and are not mislabeled as protocol-complete.

## Execution Rules

📌 Every future E2E implementation derived from this plan must follow these discipline rules:

- use real implementations with deterministic fixture data rather than mock-only call-verification doubles;
- drive time, RNG, and persistence-sensitive setup through the canonical provider boundaries already used by the wallet stack;
- prefer canonical strict wrapper surfaces when they exist, especially `build_tx_stealth_output_validated()`, instead of re-implementing validation policy in test helpers;
- keep private keys, receiver secrets, `k_dh`, view secrets, and raw secret-derived material out of logs, snapshots, and test failure messages;
- keep correctness assertions separate from performance work, and move timing claims into benchmarks rather than E2E acceptance checks;
- keep claim persistence and report-only detection separate unless the current scenario explicitly owns the claim boundary;
- reuse earlier validated fixtures rather than rebuilding the same prerequisite with slightly different semantics in later phases.

## Ownership Rules

📌 This unified plan keeps one strict ownership split between upstream and downstream proof obligations:

- sender-side validation, TOFU, sender builders, publication records, and post-Spec-5 closure honesty are upstream responsibilities;
- the first positive and negative cross-spec bridge are the only scenarios allowed to prove the sender-to-receiver handoff itself;
- receiver-path parity, public taxonomy, claim gating, resume, request-aware runtime scanning, and tag16 runtime prefilter safety are downstream responsibilities;
- downstream receiver scenarios must not re-prove sender validation, request signing, card verification, publication-record correctness, or full-leaf construction policy;
- upstream sender scenarios must not absorb receive-only persistence, restart-safe cursor semantics, or downstream RPC taxonomy duties.

## No-Duplication Rules

📌 Apply these anti-overlap rules throughout the suite:

- the positive bridge enters only once, through `E2E-S5-T8`; later receiver scenarios start from that already-valid artifact;
- the negative bridge enters only once, through `E2E-S5-T9`; later receiver reject scenarios expand taxonomy on top of that known tamper harness instead of rebuilding sender corruption setup;
- the first cross-spec example enters only once, through `EX-S5-3`; later receiver examples assume the bridge is already understood;
- claim persistence belongs only to receiver-side phases and must not be silently pulled into sender-side bridge sections;
- request-aware receive scenarios may reuse a request fixture created by the request-validation stack, but they must not duplicate request-validation coverage already owned by `E2E-S5-T1`.

## Unified Test Execution Order

📌 Implement the E2E test suite in the exact order below unless a real code dependency changes.

## Phase 1. Sender Input Gates

📌 Goal: freeze every receiver-provided sender input before any sender output construction is trusted.

### Step 1. `E2E-S5-T1` PaymentRequest Strict Validation Gate

📌 Purpose: prove that signed request validation is the canonical sender-side gateway for request-bound sends.

📌 What to test:

- valid `PaymentRequest` on the current chain;
- expired request;
- wrong `chain_id`;
- invalid `view_pk`;
- invalid `identity_pk`;
- bad request signature;
- mismatched TOFU identity result.

📌 How to run:

- create one receiver fixture with canonical keys;
- derive one good signed `PaymentRequest`;
- mutate one field per negative subcase;
- call `ValidatePaymentRequest::validate_all()` with a mutable `PinnedReceiverCards` store;
- record `ValidationOutcome` or `PaymentRequestError`.

📌 Assertions:

- only the valid request passes strict validation;
- every negative subcase fails before sender build starts;
- chain mismatch is enforced only through the canonical validation surface;
- validation order remains strict enough that malformed requests do not look like trust-policy failures.

📌 Why it matters: Spec-5 explicitly says `build_tx_stealth_output()` does not perform full request validation internally. This test proves the real caller contract.

📌 Implementation checklist:

- [x] Implement the fixture builder around one canonical `ReceiverKeys` instance and derive exactly one signed `PaymentRequest` through the live request-generation path instead of hand-assembling request bytes.
- [x] Decode the request once through the untrusted parse surface before validation so the test proves the real ingress path and not an already-trusted in-memory struct shortcut.
- [x] Run `ValidatePaymentRequest::validate_all()` against a fresh mutable `PinnedReceiverCards` store with the correct `current_chain_id` and assert `ValidationOutcome::RequiresUserConfirmation` on first contact, then rerun with the same store and assert `ValidationOutcome::Approved`.
- [x] Add one negative case per mutation axis: unsupported version, wrong chain id, expired timestamp, malformed `view_pk`, malformed `identity_pk`, broken signature bytes, and identity drift against an already-pinned store.
- [x] Assert the exact live error/result taxonomy for every negative case by matching `PaymentRequestError::{UnsupportedVersion, WrongChainId, RequestExpired, InvalidPublicKey, IdentityPoint, InvalidSignature, VerifyFailed, PinRevoked}` or `ValidationOutcome::IdentityMismatch` instead of asserting generic failure.
- [x] Prove that no negative case reaches sender build by keeping all builder calls outside the negative branches and by failing the test immediately if a mutated request is ever passed into `build_tx_stealth_output()` or `build_tx_stealth_output_validated()`.
- [x] Keep the test log and snapshots free of raw request secret material, raw signature internals, and any receiver-secret-derived values beyond public fields already present in the request.

### Step 2. `E2E-S5-T2` ReceiverCard Export And Verification Journey

📌 Purpose: prove the canonical long-lived receiver card lifecycle from export to sender-side verification.

📌 What to test:

- card export through `ReceiverKeys::export_receiver_card()`;
- structural validation;
- ECC point validation;
- card signature validation;
- optional `valid_until` expiry behavior;
- transport encode and decode roundtrip.

📌 How to run:

- create a receiver wallet fixture;
- export one card through the canonical key owner path;
- serialize, transmit, and decode the compact card form through `encode_card_compact()` and `decode_card_compact()`;
- verify the card on the sender side;
- mutate signature, points, and validity metadata in separate negative cases.

📌 Assertions:

- exported card verifies successfully in its unmodified form;
- transport roundtrip preserves the signed content exactly;
- invalid signature or invalid points never pass as a trusted sender input;
- `valid_until` is treated as a real boundary when present.

📌 Why it matters: this is the full offline-mode sender entry story for Spec-5.

📌 Implementation checklist:

- [x] Build the receiver fixture from live `ReceiverSecret` or `ReceiverKeys` construction and export the card only through `ReceiverKeys::export_receiver_card()`.
- [x] Assert the exported card passes `ReceiverCard::verify()` and, where the test needs more granularity, also passes `validate_structure()`, `validate_ecc_points()`, and `validate_signature()` in that order.
- [x] Roundtrip the card through `encode_card_compact()` and `decode_card_compact()` and assert byte-for-byte equality of `canonical_encoding()` before any sender-side trust decision is evaluated.
- [x] Add negative subcases by mutating canonical bytes, reparsing through `ReceiverCard::from_untrusted_bytes()`, and then verifying that malformed points, malformed structure, or broken signatures fail through `ReceiverCardError` rather than by ad hoc panic or decode noise.
- [x] Include one expiry boundary case with `metadata.valid_until` set below current time and assert the failure is treated as a real card validity boundary during `verify_or_pin()` or the caller-side acceptance path.
- [x] Prove that sender-side acceptance uses the post-roundtrip verified card object and not a shadow DTO by passing only the verified decoded card into later builder stages.
- [x] Keep the example output limited to public card material and never print receiver secret, derived view secret, or identity secret in failure messages.

### Step 3. `E2E-S5-T3` TOFU Pinning And Identity Drift

📌 Purpose: prove that receiver identity trust is canonical, visible, and not bypassed by shadow stores or helper shortcuts.

📌 What to test:

- first-seen receiver card acceptance under TOFU policy;
- repeat acceptance of the same identity;
- identity drift with same logical receiver path;
- expired card rejection and revoked pin rejection as distinct boundaries;
- request validation against a pinned identity.

📌 How to run:

- create a fresh `PinnedReceiverCards` store;
- submit a valid card through `verify_or_pin()` once to establish pin state;
- resubmit the same identity;
- resubmit altered identity material for the same receiver flow;
- exercise request identity checks through `verify_request_identity()` separately from card verification;
- evaluate trust result enums and downstream sender eligibility.

📌 Assertions:

- first-seen and already-pinned paths are distinguishable as `VerifyResult::NewPin` and `VerifyResult::Verified`;
- identity drift is visible through the canonical `ViewKeyChanged`, `IdentityKeyChanged`, or `IdentityChanged` result paths rather than through ad hoc status aliases;
- revoked pin and expired card boundaries are not silently downgraded to normal acceptance;
- sender flow consumes the canonical TOFU result rather than bypassing it.

📌 Why it matters: trust pinning is one of the main sender-side policy gates frozen by Spec-5.

📌 Implementation checklist:

- [x] Initialize an empty `PinnedReceiverCards` store and prove the first valid card passes through `verify_or_pin()` as `VerifyResult::NewPin`.
- [x] Re-submit the exact same verified card and assert the second pass yields `VerifyResult::Verified` without mutating pinned identity state.
- [x] Create one drift variant with changed `view_pk` under the same `owner_handle` and assert `VerifyResult::ViewKeyChanged { requires_confirmation: true, .. }`.
- [x] Create one drift variant with stable `view_pk` but changed `identity_pk` and assert `VerifyResult::IdentityKeyChanged` from card pinning and `PinCheckResult::IdentityChanged` or `ValidationOutcome::IdentityMismatch` from request identity validation where applicable.
- [x] Exercise `verify_request_identity()` separately with the same store so the suite proves request trust and card trust are related but not conflated.
- [x] Revoke an existing pin through `revoke()` and assert later validation paths fail as revocation, not as malformed card or generic verification failure.
- [x] If a rotation-acceptance path is covered, require an explicit `confirm_rotation()` call before the changed card can be treated as verified; do not silently auto-accept rotations in test helpers.

## Phase 2. Sender Construction Contracts

📌 Goal: prove the sender output surfaces only after Phase 1 trust and validation gates are frozen.

### Step 4. `E2E-S5-T4` Lightweight Output Builder Correctness

📌 Purpose: prove the sender-side stealth creation path for `TxStealthOutput` under valid prevalidated input.

📌 What to test:

- `build_tx_stealth_output()` from a validated card or request/card pair;
- `build_tx_stealth_output_validated()` as the canonical strict wrapper for request-bound validation;
- deterministic hedged `r` behavior under stable inputs;
- stable `r_pub`, `owner_tag`, `enc_pack`, `c_amount`, and optional `tag16` production;
- request-bound and card-only tag16 derivation branches.

📌 How to run:

- validate receiver input first through the canonical surface;
- call `build_tx_stealth_output()` with stable sender secret salt, `tx_digest`, `amount`, and `out_index`;
- drive the validated path through `build_tx_stealth_output_validated()` for the strict request-bound case;
- recompute expected ECDH-derived values through canonical helper modules;
- compare the returned lightweight descriptor against recomputed expectations.

📌 Assertions:

- the output is reproducible for deterministic fixture inputs;
- `owner_tag` is bound to `owner_handle` and `k_dh`;
- `leaf_ad` and `tag16` semantics match the canonical helper logic;
- request-bound sends use request-aware `tag16` semantics;
- the validated wrapper rejects new-identity or wrong-chain request flows that the raw builder is not responsible for policing;
- builder output does not imply final `asset_id = H(...s_out...)` unless the selected path actually owns that contract.

📌 Why it matters: this is the direct sender-side contract proof for Spec-5.

📌 Implementation checklist:

- [x] Use a deterministic sender fixture with stable `secret_salt`, `tx_digest`, `out_index`, `amount`, and `asset_id`, plus one verified `ReceiverCard` and one validated `PaymentRequest` derived from the live request flow.
- [x] Call raw `build_tx_stealth_output()` only after the receiver input has already passed the canonical validation layer, and call `build_tx_stealth_output_validated()` for the strict request-bound path in a separate assertion block.
- [x] Recompute `dh`, `k_dh`, `owner_tag`, `leaf_ad`, and `tag16` exclusively through the live helper functions already exported by the stealth/kdf modules; do not paste formulas into the test body.
- [x] Assert that the card-only branch uses the card-bound tag mode and the request-bound branch uses `req_id`-aware derivation, with different expected `tag16` behavior when the same card is reused with different request ids.
- [x] Assert the builder returns only the lightweight contract fields `r_pub`, `owner_tag`, `tag16`, `enc_pack`, and `c_amount`, and explicitly document that this path does not by itself establish full-leaf `asset_id` or `range_proof` semantics.
- [x] Add negative strict-wrapper cases for wrong chain id, expired request, and non-approved identity outcome, and assert the wrapper rejects them before any lightweight output is accepted.
- [x] Add a duplicate-input reproducibility check for stable fixture inputs and a variation check showing that changing request binding or output index changes the derived public output surface.

### Step 5. `E2E-S5-T5` Full AssetLeaf Builder Correctness

📌 Purpose: prove the relationship between the lightweight sender path and the full confidential leaf builder path.

📌 What to test:

- build one full `AssetLeaf` through the canonical builder surface;
- verify that public fields bind to the encrypted payload consistently;
- verify canonical `u16` `tag16` and presence of `range_proof`;
- compare the leaf with the same logical lightweight sender fixture where applicable.

📌 How to run:

- start from the same validated receiver material and sender context;
- build once through `build_tx_stealth_output()` and once through `build_output_leaf()` or `sender_create_output_for()`, depending on whether the scenario is proving pure leaf construction or the legacy card-bound full path;
- compare overlapping fields and verify full-leaf-specific fields separately.

📌 Assertions:

- shared fields stay consistent across lightweight and full-leaf paths;
- full-leaf path produces canonical `AssetLeaf` layout and `AssetPackPlain` decryptability;
- lightweight `tag16: Option<u16>` is not confused with the canonical full-leaf `u16` field;
- `range_proof` exists only on the full builder path;
- the repository never treats lightweight output as a drop-in substitute for full `AssetLeaf` where full leaf semantics are required.

📌 Why it matters: this proves the exact split that Spec-5 says must stay visible.

📌 Implementation checklist:

- [x] Start from one verified receiver fixture and derive one shared sender context that can feed both the lightweight path and the full-leaf path without inventing test-only derivation code.
- [x] Build the lightweight output through `build_tx_stealth_output()` and the full leaf through either `build_output_leaf()` with explicitly derived `k_dh`/`r_pub`/`s_out` or `sender_create_output_for()` when the scenario is intentionally covering the legacy full sender path.
- [x] Compare only the overlapping semantic fields between the two outputs and keep the comparison explicit: `r_pub`, `owner_tag`, ciphertext binding expectations, and the meaning of `tag16` as prefilter data.
- [x] Assert that the full leaf owns `asset_id`, `serial_id`, `range_proof`, and canonical `AssetLeaf` layout responsibilities, while the lightweight output does not pretend to satisfy those contracts.
- [x] Decrypt the full leaf through the live receiver or pack-decryption path and assert the recovered `AssetPackPlain` matches the committed amount and `s_out` used during construction.
- [x] Assert the full leaf's `tag16` is the required on-leaf `u16` value, while the lightweight output keeps `Option<u16>` semantics and therefore cannot be substituted blindly in APIs that expect a full leaf.
- [x] Include one explicit regression assertion that fails if a helper or adapter tries to upgrade a lightweight output into an `AssetLeaf` without going through the canonical full-leaf builder.

### Step 6. `E2E-S5-T6` Caller Misuse Guard Example

📌 Purpose: prove and document the known caveat that sender builders rely on caller-side validation discipline.

📌 What to test:

- an unverified or bypassed `ReceiverCard` reaching the builder;
- the same scenario with proper prior validation;
- strict wrapper rejection through `build_tx_stealth_output_validated()` when validation policy is not satisfied;
- visibility of the difference in result interpretation.

📌 How to run:

- construct a deliberately invalid receiver card fixture;
- call the builder directly without canonical validation in one negative misuse scenario;
- call canonical validation first in the correct scenario;
- call `build_tx_stealth_output_validated()` in the strict scenario;
- compare the outcomes and document that misuse is a caller bug, not a proof of builder correctness.

📌 Assertions:

- the repository demonstrates that builder entry is not a substitute for receiver input validation;
- the raw builder is not described as a policy-complete acceptance surface when the validated wrapper is the strict canonical path;
- documentation and tests align on this caveat;
- the canonical example teaches the right integration order.

📌 Why it matters: Spec-5 makes this caveat explicit and it is easy for future callers to regress.

📌 Implementation checklist:

- [x] Prepare one deliberately invalid `ReceiverCard` fixture by mutating public bytes in a way that would fail the canonical card verification path.
- [x] Demonstrate the misuse path explicitly by calling the raw builder entry without prior validation and treating any resulting success as evidence of caller misuse rather than builder correctness.
- [x] In the same test module, run the correct flow where the identical receiver material is first subjected to canonical verification and then either rejected or replaced with a verified card before build.
- [x] Run the strict request-bound flow through `build_tx_stealth_output_validated()` and assert it rejects non-approved validation outcomes instead of allowing the test to continue with ambiguous state.
- [x] Keep the assertions narrative explicit: this is an integration-order guard, not a claim that the raw builder should absorb trust-policy responsibilities.
- [x] Ensure the test title, comments, and failure messages never describe the raw builder as a full acceptance gate; the wording itself is part of the contract being frozen.

## Phase 3. Publication And Closure Hygiene

📌 Goal: freeze upstream artifacts and keep transitional claims honest before receiver-side rollout expands.

### Step 7. `E2E-S5-T7` ReceiverCard Publication Record Flow

📌 Purpose: prove the Stage-2 publication slice around canonical receiver card records.

📌 What to test:

- creation of `ReceiverCardRecordV1`;
- canonical serialized card bytes as the record payload;
- verification through `verify_receiver_card_record(...)`;
- downstream compact artifact generation through `to_compact()`;
- revocation and epoch-related rejection cases.

📌 How to run:

- create one valid receiver card;
- package it into `ReceiverCardRecordV1`;
- verify the record;
- derive the compact downstream artifact;
- mutate record version, epoch, revocation state, and card bytes in separate negative cases.

📌 Assertions:

- record verification depends on canonical serialized card content;
- record format does not duplicate signed shadow fields;
- revoked or stale publication records fail as records, not as unrelated cryptographic noise;
- `to_compact()` only succeeds for a record that already passes canonical verification;
- downstream artifact source remains exactly the canonical record method.

📌 Why it matters: this is the publication bridge between sender input surfaces and downstream consumers.

📌 Implementation checklist:

- [x] Create one verified `ReceiverCard` and build `ReceiverCardRecordV1` only through `ReceiverCardRecordV1::new(&card, card.canonical_encoding(), card_epoch)`.
- [x] Assert `verify_receiver_card_record()` succeeds on the pristine record and returns a decoded card whose `canonical_encoding()` exactly matches `receiver_card_bytes` stored in the record.
- [x] Roundtrip the record through `to_compact()` and `ReceiverCardRecordV1::from_compact()` and assert the whole record, not just the card, remains byte-for-byte stable.
- [x] Add negative record cases for unsupported version, corrupted `receiver_card_bytes`, mismatched `registry_entry_id`, revoked state, and stale epoch, and match them against exact `CardRecordError` variants.
- [x] Prove that `to_compact()` is gated by verification by calling it only on records that already pass `verify_receiver_card_record()` and asserting malformed or revoked records never produce downstream compact artifacts.
- [x] If relabel protection is in scope for the suite, add a dedicated `check_relabel()` regression case so publication identity is not silently rebound across entry ids or owner identities.
- [x] Keep the publication-layer assertions limited to canonical serialized card bytes and epoch/revocation rules; do not add shadow fields to the record fixture to make tests easier.

### Step 8. `E2E-S5-T10` Post-Spec-5 Track Honesty Gate

📌 Purpose: prove that the repository does not over-claim protocol-complete closure for post-Spec-5 tracks that are still transitional.

📌 What to test:

- claim proof track remains distinct from protocol-complete public proof closure;
- chain authority remains blocked on verified Stage-1 artifact consumption;
- spend-proof and fee-proof tracks are not mislabeled as final public verifiers when acceptance still depends on transitional witness, formula, or placeholder-authority gates;
- subordinate notes stay descriptive and subordinate to `post-spec-5.md`.

📌 How to run:

- inspect live owner modules and available final-acceptance helpers;
- execute representative transitional acceptance and failure paths where runtime tests already exist;
- include the live `ZERO_ROOT` authority placeholder in the claim-authority review and the Stage-4 witness gate path in the spend-proof review;
- compare behavior and documentation language against `post-spec-5.md` closure rules.

📌 Assertions:

- documentation and code do not call a transitional helper a final public verifier;
- chain authority is not claimed complete without verified Stage-1 artifact flow;
- if a final public verifier does not yet exist as a live code surface, the suite says so explicitly instead of inventing one for closure symmetry;
- issue or milestone language remains honest under current code reality.

📌 Why it matters: this is the governance and closure-integrity side of E2E validation for post-Spec-5 work.

📌 Implementation checklist:

- [x] Inventory the live claim, authority, spend-proof, and fee-proof entry points directly from the current codebase before writing any test or example wording.
- [x] Mark every scenario as either protocol-complete or transitional based on the existence of a real final public verifier in code, not on naming symmetry or documentation expectations.
- [x] For chain authority review, include the live `ZERO_ROOT` or equivalent placeholder path and require the document to state explicitly that placeholder authority is not final authority closure.
- [x] For spend-proof and fee-proof review, include the current witness-gate or stage-gate dependency and state explicitly that transitional witness acceptance is not equivalent to final public verification.
- [x] Fail the documentation review if any section invents a missing verifier, renames a helper into something more final than the code supports, or collapses multiple transitional stages into one `done` label.
- [x] Keep the final wording subordinate to `post-spec-5.md` and to live code surfaces, with no standalone closure claims in this file.

## Phase 4. Cross-Spec Handoff

📌 Goal: prove the handoff between the sender world and the receiver world exactly once.

### Step 9. `E2E-S5-T8` Bridge To Spec-6 Receiver Success

📌 Purpose: prove the most important cross-spec story: a valid sender output produced under Spec-5 is consumable by the implemented Spec-6 receiver path.

📌 What to test:

- sender validates receiver material;
- sender builds a valid full output leaf;
- receiver consumes the resulting leaf through `receiver_scan_leaf()` and runtime scanner path;
- receiver report semantics remain `Detected` first, not implicitly claimed.

📌 How to run:

- create sender and receiver fixtures;
- use canonical Spec-5 sender path to build output material;
- materialize canonical `AssetLeaf` and runtime `Asset` forms;
- feed both forms to the implemented Spec-6 receiver surfaces;
- compare reports and decrypted business fields.

📌 Assertions:

- valid Spec-5 sender output is accepted by the canonical Spec-6 detect core;
- canonical and runtime receive reports stay aligned;
- decrypted amount and identifiers match sender intent;
- no bridging adapter rewrites cryptographic semantics between sender and receiver.

📌 Why it matters: this is the strongest proof that the upstream sender spec and the downstream receiver spec fit together as one pipeline.

📌 Implementation checklist:

- [x] Build one sender-side output from verified receiver material using the live sender path that actually produces the leaf artifact consumed downstream.
- [x] Materialize both the canonical `AssetLeaf` view and any runtime `Asset` hydration form through the repository's real conversion path instead of hand-assembling runtime structs.
- [x] Feed the canonical leaf through `receiver_scan_leaf()` and, where runtime orchestration matters, through the scanner/report path used by the wallet service or simulator flow.
- [x] Assert the first receive-stage semantic is detection or successful decryptability and keep claim persistence out of this test unless the scenario explicitly transitions into a claim module afterward.
- [x] Compare decrypted `value`, `s_out`, identifiers, and public ownership markers against sender intent and fail the test if any adapter normalizes or rewrites cryptographic fields between sender and receiver sides.
- [x] Add a regression assertion that the same valid leaf is consumable through both canonical leaf scanning and the runtime receive/report surface, with no semantic drift between the two.

### Step 10. `E2E-S5-T9` Negative Bridge To Spec-6 Reject Path

📌 Purpose: prove that sender-side tamper or publication corruption is rejected cleanly by the implemented Spec-6 receiver path.

📌 What to test:

- tampered `owner_tag`;
- tampered `tag16`;
- corrupted `enc_pack`;
- altered `c_amount` or commitment-open mismatch;
- inconsistent runtime hydration.

📌 How to run:

- begin from a valid sender fixture;
- mutate one field per test case after construction;
- feed the result through canonical and runtime receiver paths;
- compare public receive semantics.

📌 Assertions:

- receiver never produces false ownership on tampered sender artifacts;
- runtime outward receive vocabulary stays stable, while canonical-leaf parse or commitment failures are asserted first as typed errors at the leaf boundary;
- invalid sender material does not accidentally cross into claim persistence.

📌 Why it matters: this is the end-to-end integrity proof across the sender/receiver boundary.

📌 Implementation checklist:

- [x] Start from one pristine sender-built leaf that is already known to pass the positive bridge scenario.
- [x] Generate separate tamper fixtures for `owner_tag`, `tag16`, `enc_pack`, `c_amount`, and any runtime hydration boundary so each corruption class is isolated to one mutation.
- [x] Pass every mutated artifact through `receiver_scan_leaf()` first and assert the leaf-boundary outcome is either typed rejection, non-ownership, or failed decrypt/open semantics according to the exact corruption axis.
- [x] Where runtime wrappers are involved, assert the outward receive vocabulary remains stable and does not promote a corrupted artifact into detected ownership, accepted claim state, or ambiguous partial success.
- [x] Assert that `tag16` corruption alone never creates ownership, that `owner_tag` corruption fails M1 ownership checks, and that ciphertext or commitment corruption fails decrypt/open consistency rather than silently degrading into a claimable asset.
- [x] Add an explicit post-condition that no tampered case is persisted into claim-ready storage or emitted as a success report by downstream orchestration.

## Phase 5. Receiver Core Baseline

📌 Goal: prove the receiver core on top of already-validated bridge fixtures, not on ad hoc sender reconstruction.

### Step 11. `E2E-T1` Canonical And Runtime Path Parity

📌 Purpose: prove that canonical `AssetLeaf` reception and runtime `Asset` reception converge on the same receiver result semantics.

📌 What to test:

- one sender creates a valid stealth output for one receiver;
- the same logical output is represented as canonical `AssetLeaf` and as runtime `Asset`;
- `receiver_scan_report()` and `ScanResult::recv_report()` produce the same status contract;
- successful detection yields `Detected` and not `Claimed`.

📌 How to run:

- create sender and receiver fixtures;
- materialize one valid leaf with `r_pub`, `owner_tag`, `c_amount`, `enc_pack`, and `tag16`;
- scan once through `receiver_scan_leaf()` and `receiver_scan_report()`;
- scan once through `StealthOutputScanner::scan_leaf()`;
- compare reports and value-bearing fields.

📌 Assertions:

- canonical and runtime reports are identical;
- decrypted amount and `asset_id` match sender intent;
- resulting public state is `Detected`, not persistence-complete;
- no alternate detect stack or alternate status vocabulary appears.

📌 Why it matters: this is the most important Spec-6 proof that the shared detect core really replaced duplicated receiver logic.

📌 Implementation checklist:

- [x] Build one pristine sender-to-receiver fixture through the live sender path that already produces a valid canonical `AssetLeaf` and the corresponding runtime `Asset` representation, instead of hand-assembling stealth fields in the test body.
- [x] Run `receiver_scan_leaf()` first and assert it returns `Some(AssetPackPlain)` with the expected `value`, then run `receiver_scan_report()` on the same leaf and assert `status == ReceiveStatus::Detected` and `next == ReceiveNext::ReportOnly`.
- [x] Run `StealthOutputScanner::scan_leaf()` on the runtime `Asset`, convert the result through `ScanResult::recv_report()`, and assert that its `status`, `reject`, and `next` are byte-for-byte equivalent in meaning to the canonical report.
- [x] Compare the decrypted business fields across both paths: amount, `asset_id`, `serial_id`, `r_pub`, and `owner_tag`; fail immediately if runtime hydration changed any stealth field before scanning.
- [x] Assert that neither path persists anything into claimed wallet storage and that no helper in the scenario calls `recv_route(..., PersistClaim)` or `put_claimed_asset(...)`.
- [x] Reuse the exact stable public vocabulary exported by the codebase, namely `RECEIVE_DETECTED`, and reject any helper, snapshot, or example text that invents a parallel success label.

### Step 12. `E2E-T2` Tamper Classification And Reject Stability

📌 Purpose: prove that malformed or tampered outputs do not collapse into false ownership or ambiguous public statuses.

📌 What to test:

- tampered `asset_id` or mismatched `leaf_ad` path;
- tampered `tag16`;
- broken `enc_pack` payload;
- commitment mismatch after decrypt;
- runtime asset with invalid stealth tuple consistency.

📌 How to run:

- start from one valid sender-to-receiver fixture;
- mutate one field per subcase;
- run canonical leaf scan, runtime scan, and RPC receive where applicable;
- capture internal reject mapping and outward public status code.

📌 Assertions:

- malformed or tampered cases never return owned output data;
- tag and decrypt failures collapse into the stable public `InvalidProof` receive vocabulary;
- parse or commitment failures are asserted as typed canonical-leaf errors first, then as stable outward receive codes only after adapter-level mapping where applicable;
- runtime tuple inconsistency is rejected before scan pretends the asset is valid;
- no tampered case reaches claim persistence.

📌 Why it matters: this is the practical integrity proof that Spec-6 preserved validation layering and rejection taxonomy.

📌 Implementation checklist:

- [x] Start from one known-good baseline leaf and runtime asset that already pass `E2E-T1`, then clone that baseline into separate tamper fixtures so every corruption axis is isolated to one mutation.
- [x] Add dedicated mutation cases for `asset_id` or `leaf_ad` drift, `tag16` drift, corrupted `enc_pack`, and commitment-open mismatch, and execute canonical leaf scanning before any runtime wrapper is involved.
- [x] Assert canonical leaf outcomes at the real layer where they occur: `receiver_scan_report()` must map tag or decrypt failure to `ReceiveStatus::InvalidProof`, while `receiver_scan_leaf()` must surface parse failures as `WalletError::InvalidAssetPack` and commitment failures as `WalletError::CommitmentMismatch` instead of collapsing everything into one generic reject.
- [x] For malformed runtime assets, call `WalletService::recv_one()` and assert `validate_stealth_consistency()` fails early enough to produce `ReceiveReject::InvalidInput`, not `NotMine` and not `InvalidProof`.
- [x] Where the scenario needs outward mapping, drive the RPC receive surface only for cases that still represent a retrievable runtime asset, and compare the outward code against the stable receive taxonomy instead of asserting internal scanner details through RPC.
- [x] Verify after every negative subcase that claimed wallet state remains unchanged, `recv_route(..., PersistClaim)` is never entered, and no invalid asset reaches `.wlt` persistence.

## Phase 6. Receive State And Public Semantics

📌 Goal: prove user-visible receive behavior and persistence boundaries.

### Step 13. `E2E-T3` Receive Is Not Claim

📌 Purpose: prove that detection/report and wallet claim persistence remain separate milestones.

📌 What to test:

- RPC `receive_asset()` scans and reports owned output;
- the asset is not persisted to claimed wallet state after report-only receive;
- explicit claim boundary through `recv_route(..., PersistClaim)` persists the asset.

📌 How to run:

- seed one owned stealth asset into wallet-visible state;
- call RPC `receive_asset()`;
- inspect claimed wallet asset storage;
- then run the explicit persistence path;
- inspect claimed wallet asset storage again.

📌 Assertions:

- after `receive_asset()`, receive status is `Detected` and claimed list stays empty;
- after explicit claim boundary, claimed list contains the asset;
- the same asset is not claimed implicitly by report-only receive;
- logs and docs remain consistent with this split.

📌 Why it matters: this is the key behavioral contract that prevents the repository from silently equating detection with import completion.

📌 Implementation checklist:

- [x] Seed one wallet-visible owned runtime asset through the real wallet/service test fixture so the RPC receive path can discover it via the normal lookup flow instead of a fake direct injection into response structs.
- [x] Call the actual receive/report surface first and assert the returned outward status is `RECEIVE_DETECTED` while `list_claimed_assets()` remains empty for the target wallet.
- [x] Immediately inspect wallet-native claimed state after report-only receive and fail the test if any helper implicitly routed through `recv_route(..., PersistClaim)`.
- [x] Then call `WalletService::recv_route(wallet_id, asset, ReceiveNext::PersistClaim)` explicitly on the same owned asset and assert the function performs exactly one persistence step through `put_claimed_asset(...)`.
- [x] Re-read claimed wallet state and assert it now contains the asset exactly once, with the expected `asset_id`, and that a second persistence attempt does not create duplicates.
- [x] Keep the scenario wording and test names explicit that report-only receive is detection-only and that claim completion is a separate boundary owned by `recv_route()`.

### Step 14. `E2E-T6` Public API Taxonomy Sync

📌 Purpose: prove that wallet-facing and RPC-facing receive surfaces expose the same stable public semantics.

📌 What to test:

- one owned case;
- one not-mine case;
- one invalid-proof case;
- one invalid-input runtime case.

📌 How to run:

- drive the same logical assets through `recv_one()` and RPC `receive_asset()`;
- derive outward status strings through `ScanResult::recv_report()` plus `WalletService::recv_code(...)` rather than treating `recv_code()` as an independent receive surface;
- for applicable failure modes, compare outward RPC error codes and local service status mapping.

📌 Assertions:

- service and RPC surfaces map to the same stable vocabulary, even when RPC expresses rejected cases as error codes instead of success payloads;
- `NotMine` stays distinct from `InvalidProof`;
- runtime failures do not leak sensitive internal detail;
- no surface invents an extra public receive state.

📌 Why it matters: this is the acceptance proof that Spec-6 exposed one receive taxonomy instead of fragmented status models.

📌 Implementation checklist:

- [x] Prepare four deterministic cases: owned runtime asset, valid foreign asset, proof-invalid asset, and structurally invalid runtime asset that fails `validate_stealth_consistency()` before scan completion.
- [x] Drive the wallet-service path first by calling `recv_one()` and converting the result through `ScanResult::recv_report()` and `WalletService::recv_code(report.status)` so the service-side taxonomy is frozen from live code, not from hard-coded strings in the test.
- [x] Drive the RPC receive path on the corresponding retrievable assets and compare outward success codes or RPC error codes against the same stable vocabulary, allowing for the fact that RPC expresses some rejects as errors instead of payload statuses.
- [x] Assert explicitly that owned maps to `RECEIVE_DETECTED`, not-mine maps to `RECEIVE_NOT_MINE`, invalid proof maps to `RECEIVE_INVALID_PROOF`, and malformed runtime input never masquerades as either not-mine or invalid proof.
- [x] Fail the test if any adapter leaks internal scanner-only details, typed parse errors, or persistence internals into outward RPC semantics.
- [x] Keep the test matrix authoritative for public taxonomy by rejecting any new receive string or alternate status alias not exported through `ReceiveStatus::rpc_code()` or `ReceiveReject::rpc_code()`.

## Phase 7. Long-Running Receive Behavior

📌 Goal: cover receiver behaviors that depend on persistence, active requests, and optimization layers.

### Step 15. `E2E-T4` Range Scan Resume Across Restart

📌 Purpose: prove the full checkpoint-range receive flow, including persisted cursor behavior, restart, and continuation.

📌 What to test:

- a multi-checkpoint range with at least one owned output in later checkpoints;
- partial execution with `max_ckpt` limit;
- persisted `ScanStatePayload` cursor after the first segment;
- service restart using the same `.wlt` backing state;
- continuation from the next checkpoint instead of rescanning from zero.

📌 How to run:

- prepare checkpoint chunks with stable hashes and heights;
- open the wallet through the canonical owner session path backed by the same `.wlt` file;
- run `recv_range()` with a low checkpoint cap;
- close and reopen the wallet service instance;
- run `recv_range()` again without resetting state;
- verify final outputs and final cursor.

📌 Assertions:

- first run processes only the allowed checkpoint count;
- persisted cursor equals the last processed checkpoint;
- second run starts after the persisted checkpoint;
- final combined outputs equal the full-range expected set;
- restart does not duplicate claims or lose detected outputs.

📌 Why it matters: this is the strongest end-to-end proof for the Spec-6 resume substrate and restart discipline.

📌 Implementation checklist:

- [x] Build a checkpoint sequence with deterministic `height` and `hash` values and place at least one owned output after the first checkpoint so resume behavior is observable instead of vacuous.
- [x] Open the wallet through the canonical session path backed by one persistent `.wlt` file, run `recv_range()` with `max_ckpt = Some(1)`, and capture the returned `ScanRangeOut.stat.cursor` from the first pass.
- [x] Assert the first pass processes exactly one checkpoint, persists exactly the returned `ScanStatePayload`, and claims only the assets discovered in the processed segment.
- [x] Tear down the service instance completely, create a fresh service over the same `.wlt` path, and run `recv_range()` again with the same chunk list and no manual cursor override.
- [x] Assert the second pass starts strictly after the persisted checkpoint by comparing the resumed cursor and final counts against the expected checkpoint boundaries; do not accept a restart that rescans from origin.
- [x] Re-read claimed assets after restart and assert the combined claimed set equals the full expected owned-output set with no duplicate asset ids and no missing later-checkpoint detections.
- [x] Where deeper validation is needed, inspect the persisted cursor semantics through `ScanStatePayload::height()`, `is_origin()`, and chunk matching behavior instead of raw duplicated field checks in helper code.

### Step 16. `E2E-T5` Request-Aware Receive Flow

📌 Purpose: prove that active payment requests influence candidate derivation without replacing the canonical ownership checks.

📌 What to test:

- one output bound to an active request id;
- one output for the same receiver but with a different request id;
- scanner state with active request registration;
- explicit distinction between active-request registration and optional `Tag16Context` prefilter entries.

📌 How to run:

- create at least two request ids;
- produce outputs for the receiver with and without matching active request context;
- register only the intended request in the scanner;
- scan checkpoint and range paths;
- for strict tag-only coverage, add explicit `Tag16Context` entries instead of assuming `add_request()` alone materializes them.

📌 Assertions:

- matching request-bound output is still validated through full ownership checks;
- non-matching request context does not incorrectly claim ownership;
- request-aware acceleration never bypasses M1, decrypt, parse, or commitment verification;
- active request registration by itself remains best-effort metadata and not a substitute for cryptographic proof or full tag-context population.

📌 Why it matters: this proves Spec-6 request-awareness without allowing request tags to become a fake ownership oracle.

📌 Implementation checklist:

- [x] Create at least two live `PaymentRequest` fixtures for the same receiver with different `req_id` values so the suite can distinguish matching and non-matching request-bound outputs without inventing shadow request DTOs.
- [x] Build one output bound to the active request id and one output bound to a different request id, then scan both outputs with a `StealthOutputScanner` that has only the intended request registered through `add_request()`.
- [x] Assert the matching output is still accepted only after full canonical ownership checks succeed and that a non-matching request registration never upgrades a foreign output into `Mine`.
- [x] Add a strict tag-prefilter subcase by inserting explicit `Tag16Context` entries through `add_tag_context(tag16, Tag16Context { k_dh, req_id: Some(...) })`; do not pretend `add_request()` alone creates decrypt contexts.
- [x] Compare `scan_leaf()` and `scan_leaf_tag_only()` on the same fixtures to prove request metadata can accelerate candidate selection but cannot bypass M1 verification, decrypt, parse, or commitment consistency.
- [x] Keep one negative assertion showing that active request registration without matching tag context remains best-effort metadata and must not be described in docs or tests as proof of ownership.

### Step 17. `E2E-T7` Tag16 Prefilter Safety

📌 Purpose: prove that tag16 acceleration improves scan behavior but never becomes a false-positive ownership decision.

📌 What to test:

- valid output with matching preloaded tag context;
- valid output without tag16 context and fallback scanning;
- conflicting or collision-like tag16 contexts;
- intentionally wrong tag16 on an otherwise valid leaf.

📌 How to run:

- build scanner fixtures with and without explicit `Tag16Context` entries;
- scan the same assets under normal `scan_leaf()` fallback conditions and strict `scan_leaf_tag_only()` conditions;
- compare semantic outcomes, not just performance.

📌 Assertions:

- correct tag16 context can accelerate but not change the final receive semantics;
- missing tag16 context falls back under normal `scan_leaf()` but intentionally yields `NotMine` under strict `scan_leaf_tag_only()`;
- wrong tag16 does not pass ownership;
- collision-like setup still requires downstream cryptographic validation to succeed.

📌 Why it matters: this proves that the optimization layer remains subordinate to the canonical detect core.

📌 Implementation checklist:

- [x] Build one valid runtime asset and derive its real `k_dh` and `tag16` through the canonical sender/receiver helper flow so the prefilter scenario starts from a truly valid ownership case.
- [x] Register a matching context through `add_tag_context(...)` and prove that both `scan_leaf()` and `scan_leaf_tag_only()` end in the same successful semantic result for the valid asset.
- [x] Remove the tag context and rerun the same asset, asserting that ordinary `scan_leaf()` still reaches the canonical direct scan path while strict `scan_leaf_tag_only()` returns `NotMine` by design.
- [x] Add one wrong-tag or wrong-context case and assert that a tag16 match without downstream `owner_tag` plus decrypt success can never produce `Mine`.
- [x] Add one collision-style setup with multiple `Tag16Context` entries under the same tag and assert the scanner still requires the correct `owner_tag` and decrypt witness before declaring ownership.
- [x] Keep all performance claims out of this E2E case; the only accepted proof here is semantic safety under optimization, not speed.

## Phase 8. Final User Journey

📌 Goal: finish with one business-readable scenario after all lower layers are already frozen.

### Step 18. `E2E-T8` Full Wallet Journey Demo

📌 Purpose: show one understandable business-level demo that exercises the whole implemented Spec-6 path from sender output to receiver claim.

📌 What to test:

- sender creates stealth output for Bob;
- Bob first reports ownership through receive flow;
- Bob then explicitly persists the asset through the claim boundary;
- service restart still shows consistent final wallet state.

📌 How to run:

- create Alice and Bob fixtures;
- produce one stealth output package;
- ingest it into wallet-visible runtime state;
- run RPC receive for report-only proof;
- run the explicit claim path through `recv_route(..., PersistClaim)`;
- restart wallet service and re-read claimed assets.

📌 Assertions:

- receive report is `Detected`;
- claimed persistence occurs only after the explicit claim step;
- restart preserves the claimed result;
- no duplicate receiver semantics appear anywhere in the user-visible journey.

📌 Why it matters: this is the best demo scenario for stakeholders who want one complete story instead of isolated low-level tests.

📌 Implementation checklist:

- [x] Create one business-level Alice-to-Bob fixture using the live sender path and produce exactly one valid stealth output intended for Bob.
- [x] Hydrate that output into the wallet-visible runtime state used by the wallet service, then execute the report-only receive step first and record the outward status shown to the caller.
- [x] Assert the first visible receive state is `RECEIVE_DETECTED` and that claimed storage is still empty immediately afterward.
- [x] Execute the explicit claim boundary through `recv_route(..., PersistClaim)` on the owned asset and assert the claimed wallet state now contains exactly one persisted asset.
- [x] Restart the wallet service over the same wallet storage and assert the claimed asset survives restart without duplication, semantic drift, or downgrade back into detection-only state.
- [x] Keep this demo narrative limited to one canonical journey and forbid any alternate `auto-claim on receive` shortcut, because that would directly contradict the implemented Spec-6 boundary.

## Unified Example Execution Order

📌 The runnable examples below are ordered so each one teaches a new boundary rather than repeating an older one.

## Phase 9. Sender-Facing Examples

### Example 1. `EX-S5-1` Signed Request To Built Output

📌 Show one complete sender story from signed `PaymentRequest` validation to successful `TxStealthOutput` creation.

📌 This example should teach:

- why request validation must happen before sender build;
- how `req_id` changes `k_dh` and `tag16` behavior;
- why the validated wrapper is the correct strict entry point for request-bound sends;
- what data comes out of the lightweight output path.

📌 Implementation checklist:

- [x] Begin with live request creation, signing, decode-from-untrusted-bytes, and strict validation against a mutable `PinnedReceiverCards` store.
- [x] Use `build_tx_stealth_output_validated()` as the example's primary builder call and keep raw builder invocation out of the happy path.
- [x] Print or snapshot only public output fields returned by `TxStealthOutput` and never log derived secrets, `k_dh`, or receiver private material.
- [x] Recompute and display the request-bound `tag16` expectation through the live helper path so the example demonstrates why `req_id` changes sender output semantics.
- [x] End the example with one explicit sentence and one assertion showing that validation precedes build and that skipping validation would be an integration bug.

### Example 2. `EX-S5-2` Offline ReceiverCard Payment

📌 Show a sender paying a receiver using only a verified `ReceiverCard`.

📌 This example should teach:

- how offline mode differs from request-bound mode;
- what trust pinning contributes to sender safety;
- how card verification and sender build order should look in practice.

📌 Implementation checklist:

- [x] Export one live `ReceiverCard`, roundtrip it through compact transport encoding, and verify it before any sender call is shown.
- [x] Pass the verified card through `verify_or_pin()` so the example demonstrates TOFU semantics explicitly instead of assuming trust off-screen.
- [x] Call `build_tx_stealth_output()` with `payment_request = None` only after card verification and pin evaluation have already succeeded.
- [x] Include one short negative branch or comment block showing that an unverified card is not a valid integration input even though the raw builder itself does not enforce that policy.
- [x] Make the example's output fields clearly card-bound rather than request-bound, especially for `tag16` semantics.

### Example 3. `EX-S5-4` TOFU Drift And Rejection Demo

📌 Show first-seen pinning, then identity drift, then rejection.

📌 This example should teach:

- what TOFU remembers;
- what drift looks like;
- why a changed identity is not a harmless metadata difference.

📌 Implementation checklist:

- [x] Show the first card entering an empty `PinnedReceiverCards` store and becoming `NewPin`.
- [x] Show the unchanged card being accepted as `Verified` on the second pass.
- [x] Show one changed-card variant that triggers `ViewKeyChanged` or `IdentityKeyChanged` and stop the example at the rejection or needs-confirmation boundary.
- [x] If the example includes rotation acceptance, require an explicit `confirm_rotation()` step rather than silently mutating the store.
- [x] Keep the narrative tied to concrete `VerifyResult` values so future maintainers cannot rewrite the trust vocabulary informally.

### Example 4. `EX-S5-5` Publication Record Example

📌 Show how a valid `ReceiverCard` becomes `ReceiverCardRecordV1`, gets verified, and emits the compact downstream representation.

📌 This example should teach:

- what publication freezes actually protect;
- why the record stores canonical bytes rather than shadow fields;
- how revocation state and epoch boundaries should be interpreted.

📌 Implementation checklist:

- [x] Start from a verified `ReceiverCard` and construct `ReceiverCardRecordV1` only through `new()` with canonical bytes.
- [x] Verify the record before compact export and then roundtrip it through `to_compact()` and `from_compact()`.
- [x] Add one revoked and one stale-epoch branch and show the exact record-layer rejection point.
- [x] State explicitly that the publication record freezes canonical card bytes and epoch/revocation semantics, not duplicated shadow metadata.
- [x] Keep the example downstream artifact source limited to the record's own compact export path.

### Example 5. `EX-S5-6` Transitional Closure Honesty Demo

📌 Show one explanatory example that contrasts a live transitional verifier path with what `post-spec-5.md` still considers open protocol-complete work.

📌 This example should teach:

- how to talk honestly about what is implemented now;
- how to avoid overstating claim, authority, spend, or fee closure;
- why closure documents and live tests must move together.

📌 Implementation checklist:

- [x] Pick one live transitional helper and one still-missing final public verifier surface from the current codebase.
- [x] Show the helper executing successfully while stating explicitly why that does not equal protocol-complete closure.
- [x] Tie the wording back to `post-spec-5.md` and the concrete live module names used in code.
- [x] Fail the example review if the prose upgrades a transitional helper into a final verifier by implication, naming, or omission of current blockers.

## Phase 10. Cross-Spec Example

### Example 6. `EX-S5-3` Full Leaf Creation And Receive Bridge

📌 Show a single example that builds a canonical `AssetLeaf` and then immediately demonstrates its successful consumption by the implemented Spec-6 receive path.

📌 This example should teach:

- how the sender-side builder and receiver-side scanner meet at the leaf boundary;
- why this bridge is the main proof of inter-spec compatibility;
- why detection and claim are still separate even after a successful receive.

📌 Implementation checklist:

- [x] Build one full `AssetLeaf` through the canonical full-leaf path and preserve the sender-side fixture values needed to verify the receive result.
- [x] Feed the resulting leaf into `receiver_scan_leaf()` and, if shown, the runtime scan/report path without changing cryptographic fields between the two calls.
- [x] Assert the decrypted payload matches sender intent and keep claim construction out of the main example body.
- [x] Add one short explanatory note and one assertion that successful receive means detect-and-decrypt success, not automatic claim completion.
- [x] Keep the bridge example focused on one leaf boundary and one receiver flow; do not dilute it with publication or transitional-closure concerns.

📌 This is the only example that should teach the initial sender-to-receiver bridge in one place.

## Phase 11. Receiver-Facing Examples

### Example 7. `EX1` Single Owned Leaf Walkthrough

📌 Show a minimal example that starts from one valid `AssetLeaf`, runs `receiver_scan_leaf()` and `receiver_scan_report()`, and prints the resulting `Detected` status plus decrypted business fields.

📌 This example should teach:

- what the canonical full-leaf authority is;
- how `AssetLeaf` differs from runtime `Asset`;
- that successful detection still does not mean wallet claim persistence.

📌 Implementation checklist:

- [x] Build one minimal valid `AssetLeaf` through the live sender construction path and do not inline cryptographic formulas or hard-coded ciphertext blobs into the example.
- [x] Call `receiver_scan_leaf()` first and print only the safe business fields from the returned pack, such as amount and public identifiers, never any secret-derived material.
- [x] Call `receiver_scan_report()` on the same leaf and print the stable outward status code `RECEIVE_DETECTED` plus the explicit next-step semantic `ReportOnly`.
- [x] Add one short explanatory assertion or comment that the example ends before any claim persistence occurs and that `AssetLeaf` is the canonical full-leaf authority, not the runtime wallet object.
- [x] Keep the example output limited to public or already-decrypted business data and avoid logging raw view secrets, `k_dh`, or pack internals not required for understanding the flow.

### Example 8. `EX2` Runtime Asset Scan Walkthrough

📌 Show the same logical output hydrated as runtime `Asset`, then scanned via `StealthOutputScanner::scan_leaf()`.

📌 This example should teach:

- why runtime assets require `validate_stealth_consistency()`;
- how runtime scanning produces the same receive/report semantics as canonical leaf scanning;
- where wallet-facing adaptation lives in the architecture.

📌 Implementation checklist:

- [x] Start from the same logical output used in the leaf example, then hydrate it into the real runtime `Asset` representation through the repository's existing conversion path.
- [x] Call `validate_stealth_consistency()` before scanning and make that precheck visible in the example so readers understand why runtime assets have an extra boundary beyond canonical leaf scanning.
- [x] Run `StealthOutputScanner::scan_leaf()` and convert the result through `ScanResult::recv_report()` instead of inventing a second reporting helper.
- [x] Show that the runtime path ends in the same public status as the canonical leaf path while still remaining a runtime/wallet adaptation layer rather than a replacement for `receiver_scan_leaf()`.
- [x] Keep the example text explicit that runtime scanning is fed by hydrated wallet assets and that canonical leaf ownership semantics remain the source of truth.

### Example 9. `EX3` Receive Versus Claim Example

📌 Show one example that first performs report-only receive and then performs explicit claim persistence.

📌 This example should teach:

- that `receive_asset()` is report-only;
- that `recv_route()` is the claim gate;
- how to explain the difference between `Detected` and persisted wallet ownership.

📌 Implementation checklist:

- [x] Structure the example into two explicit phases named report-only receive and explicit claim, and fail the example if those phases are ever merged by helper code.
- [x] In phase one, drive the actual receive/report surface and show the outward `RECEIVE_DETECTED` result while confirming claimed wallet state is still empty.
- [x] In phase two, pass the same owned asset through `recv_route(..., PersistClaim)` and then re-read claimed wallet state to show the transition into persisted ownership.
- [x] Print or document the before/after claimed-state difference so the reader cannot miss that `Detected` and claimed ownership are different milestones.
- [x] Do not include any auto-persist convenience wrapper in this example, because the point of the example is the explicit boundary itself.

### Example 10. `EX4` Resume After Restart Example

📌 Show a range receive operation that stops after one checkpoint, persists cursor state, restarts the service, and continues.

📌 This example should teach:

- what `ScanStatePayload` is for;
- how partial receive work resumes safely;
- why restart tests are part of Spec-6 done criteria.

📌 Implementation checklist:

- [x] Use a checkpoint list where the first pass intentionally stops early with `max_ckpt = Some(1)` so the example demonstrates a real partial scan.
- [x] Persist cursor state through the normal `.wlt` wallet flow and surface the first-pass cursor in the example via the returned `ScanRangeOut.stat.cursor`.
- [x] Tear down and recreate the service over the same wallet storage before running the second pass, rather than simulating restart with the same in-memory service instance.
- [x] Run the resumed pass without manually rewriting the cursor and show that the scanner continues from the persisted checkpoint instead of rescanning from origin.
- [x] End the example by comparing the final claimed set and final cursor against the expected full-range result so restart safety is demonstrated, not merely implied.

### Example 11. `EX5` Request-Aware Merchant Example

📌 Show a merchant-style flow where an active `PaymentRequest` is registered before scanning incoming outputs.

📌 This example should teach:

- how active request registration feeds the canonical request-aware scan path;
- why explicit `Tag16Context` entries are still required for a strict tag-only prefilter demonstration;
- why active request context is not sufficient by itself to prove ownership;
- how request-aware receive still terminates in the same stable public statuses.

📌 Implementation checklist:

- [x] Generate one live merchant-facing `PaymentRequest` and one matching request-bound output for the receiver using the real request id from the signed request.
- [x] Register the request in the scanner through `add_request()` and separately show the strict tag-prefilter path by inserting `Tag16Context` with the matching `req_id` through `add_tag_context()`.
- [x] Demonstrate both `scan_leaf()` and `scan_leaf_tag_only()` so the example teaches the difference between request metadata registration and concrete tag-context population.
- [x] Include one contrasting non-matching request case and assert it stays non-owned even when the receiver identity is otherwise the same.
- [x] End the example on the same stable receive vocabulary used elsewhere in Spec-6 and avoid any language suggesting that request context alone proves ownership.

### Example 12. `EX6` Tamper-Reject Demo

📌 Show one valid output and one intentionally tampered output side by side.

📌 This example should teach:

- how invalid proof paths are surfaced;
- that malformed outputs do not silently downgrade into false ownership;
- how Spec-6 protects integrity at the receiver boundary.

📌 Implementation checklist:

- [x] Build one pristine valid output and one single-field tampered clone from the same baseline so the example can compare success and reject paths side by side without hidden fixture differences.
- [x] Run the canonical receive path on both artifacts first and show that the valid output is detected while the tampered one is either rejected as invalid proof or fails at the typed leaf-validation boundary.
- [x] If the example also includes runtime scanning, make the outward mapping explicit and keep it consistent with the canonical result instead of inventing a second reject interpretation.
- [x] Show that the malformed output never reaches claimed persistence and never becomes `Mine`, even if a prefilter such as tag16 happens to match.
- [x] Keep the example focused on integrity semantics and do not dilute it with unrelated wallet persistence or performance concerns.

## Unified Done Criteria

📌 This unified area should be considered fully demonstrated only when the final E2E suite proves all of the following together:

- sender input validation is strict and canonical;
- raw and validated lightweight builder contracts are not confused;
- sender output derivation matches the frozen cryptographic contracts;
- lightweight and full output models are related correctly but not confused;
- trust pinning and publication records behave through canonical modules only;
- a valid sender-side output is accepted by the implemented Spec-6 receiver path;
- a tampered sender-side output is rejected by the implemented Spec-6 receiver path;
- canonical and runtime receiver paths agree on owned and rejected cases;
- report-only receive does not implicitly claim assets;
- explicit claim routing persists exactly through wallet-native boundaries;
- restart and resume use persisted `ScanStatePayload` correctly;
- RPC and wallet service share one receive status vocabulary;
- request-aware and tag16-aware flows never bypass canonical cryptographic validation;
- post-Spec-5 transitional tracks are described honestly and not over-claimed as protocol-complete;
- one business-level full journey example explains the whole implemented flow clearly.

## Design Foundation Alignment Checklist

📌 This unified plan is compliant only if every later implementation that follows it preserves all of the following:

- one source of truth: request, card, TOFU, stealth-output, full-leaf, publication, receiver detection, and claim-routing contracts stay in their existing canonical modules instead of being recopied into test-only helper stacks;
- validation layering: request/card structure, point checks, signature checks, trust outcomes, builder correctness, canonical leaf parse failures, runtime input failures, ownership checks, and persistence checks are asserted at the layer where they actually happen;
- trait-based determinism: E2E fixtures use real wallet and crypto components with deterministic inputs or provider-backed state rather than fake policy shims or ad hoc randomness;
- domain separation honesty: tests do not replace canonical `k_dh`, `owner_tag`, `leaf_ad`, `s_out`, `asset_id`, or record-id derivation with alternate formulas;
- publication honesty: `ReceiverCardRecordV1` scenarios verify canonical serialized bytes and epoch/revocation rules instead of shadow metadata copies;
- stable public taxonomy: outward receive semantics remain limited to `RECEIVE_DETECTED`, `RECEIVE_INVALID_PROOF`, and `RECEIVE_NOT_MINE`;
- persistence honesty: report-only receive is never described as equivalent to wallet claim persistence;
- restart honesty: resume assertions use the persisted `ScanStatePayload` boundary instead of in-memory shortcuts;
- closure honesty: transitional post-Spec-5 helpers remain labeled transitional until final public verifier paths truly replace them;
- security hygiene: examples and assertions never leak receiver secrets, identity secrets, or raw key material beyond the minimum public bytes required for the scenario.

## Replacement Rule

📌 This file is complete only if it is sufficient to plan and review the whole Spec-5 plus Spec-6 E2E rollout without opening the older `E2E-spec5-EXAMPLES.md`, `E2E-spec6-EXAMPLES.md`, or `E2E-UNIFIED-EXECUTION-ORDER.md` files.

📌 If later edits are needed, update this file directly instead of reintroducing parallel execution-order or parallel example-plan documents.

## Final Note

📌 The most valuable property of this unified plan is architectural proof. It must show that Spec-5, post-Spec-5 closure rules, and the implemented Spec-6 receiver pipeline form one coherent system instead of separate documentation islands.
