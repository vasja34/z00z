# Spec 6: Receiver Output Reception Integration Plan

📌 This document is the implementation-oriented source of truth for Section 6 receiver output reception work in the current repository state.

📌 The logical base for this document is `specs/012-z00z-ecc-spec-6/Output_Reception_6.md`, but all concrete module paths, function names, field names, and integration steps in this file are derived from the live codebase first.

📌 The original source referenced by `Output_Reception_6.md` is not present in the workspace. Therefore this document uses the preserved logic through these repository-visible sources, in descending precedence:

1. Live Rust code in `crates/z00z_wallets`, `crates/z00z_core`, and related adapters.
2. `specs/011-z00z-ecc-spec-5/spec-5.md` and boundary notes.
3. `crates/Z00Z-ECC-SPEC_part1.md` for terminology and receiver-stage intent.
4. `specs/012-z00z-ecc-spec-6/Output_Reception_6.md` for high-level workflow intent.

📌 This document MUST be used as the planning and review baseline for Spec-6 implementation. No parallel receiver module tree may be introduced unless this file is updated first.

## Phase 1. Purpose And Scope

### 1.1 Specification Goal

📌 Spec 6 defines how the receiver discovers, filters, decrypts, validates, classifies, reports, and optionally persists incoming stealth outputs without introducing duplicate scanner stacks, duplicate persistence schemas, or alternate cryptographic contracts.

📌 The repository already contains the major building blocks for receiver-side logic. The missing work is not invention of a new design. The missing work is consolidation, boundary freezing, and end-to-end execution discipline.

📌 Review note: the live Spec-6 landing set stayed consolidation-only. The implementation series extended `core/address/*`, `wallet_service.rs`, and RPC adapters in place; no new public receiver namespace or alternate detect stack was introduced.

📌 The primary implementation goal is one canonical receiver program that starts from wallet-visible output material and terminates in one of three stable end states:

- rejected as not mine or malformed;
- accepted as detected but not yet claimed or imported;
- accepted and persisted through existing wallet-native storage boundaries.

Checklist:

- [x] State in code comments and API docs that Spec-6 is a consolidation program, not a greenfield receiver design.
- [x] Ensure every implementation PR names which existing module it is extending before proposing any new internal helper.
- [x] Reject any plan that starts with a new public receiver namespace instead of refactoring `core/address/*`.
- [x] Keep the receiver end states limited to `Rejected`, `Detected`, and `Persisted/Claimed` in docs, tests, and public API mapping.

### 1.2 In-Scope Responsibilities

📌 In scope:

- scanning already materialized wallet-visible outputs;
- trial decryption and M1 ownership validation;
- tag16 filtering and request-aware candidate derivation;
- rejection taxonomy and observability;
- wallet-facing storage and import integration;
- public wallet and RPC entry points for reception;
- checkpoint progress and resume binding over existing scan-state substrate;
- sequential implementation phases and test gates.

📌 Review note: the live change set stayed inside receiver scan, receive/report, and persist boundaries; request-aware scan behavior is covered in scanner and checkpoint tests, and resume stays bound to `ScanStatePayload`.

Checklist:

- [x] Limit Spec-6 code changes to receiver scan, receive, report, and persist boundaries.
- [x] Treat scan progress persistence as in scope only through existing `ScanStatePayload` substrate.
- [x] Include request-aware scanning behavior in unit and integration tests.
- [x] Keep every new helper tied to one of the in-scope responsibilities listed above.

### 1.3 Out-Of-Scope Responsibilities

📌 This document does not redefine sender-side output construction, claim proof format, public spend proof format, checkpoint authority rules, or consensus-side proof contracts.

📌 This document also does not authorize redesign of leaf encodings, `tag16` formulas, `leaf_ad` formulas, or asset plaintext layout. Those are already constrained by live code and Spec-5 boundary documents.

📌 Review note: the final Spec-6 implementation series did not change sender-side stealth formulas, canonical leaf contracts, or receiver-visible consensus/public-proof structures. Canonical receiver contracts still terminate in receive rejection/report and wallet-native claim persistence only.

Checklist:

- [x] Do not modify sender-side cryptographic formulas while implementing Spec 6 unless a separate approved spec update exists.
- [x] Do not add new public proof or consensus structures inside receiver implementation work.
- [x] Reject any Spec-6 patch that changes `AssetLeaf`, `AssetPackPlain`, `compute_leaf_ad`, or `compute_tag16` semantics without explicit spec revision.
- [x] Keep sender-only artifacts such as `TxStealthOutput` out of receiver canonical contracts.

## Phase 2. Codebase Compliance Review Against `Output_Reception_6.md`

### 2.1 Hard Mismatches That MUST NOT Be Copied

📌 `Output_Reception_6.md` contains useful receiver-flow logic, but several concrete signatures and module targets in that document do not match the current repository state and MUST NOT be copied literally.

| `Output_Reception_6.md` proposal | Live codebase reality | Spec-6 rule |
| --- | --- | --- |
| `z00z_wallets::receiver::scanner::*` new module tree | Receiver scan logic already lives in `crates/z00z_wallets/src/core/address/stealth_scanner.rs`, `leaf_scan.rs`, `optimized_scanner.rs`, and wallet/RPC adapters | Extend existing modules first; do not add a second scanner stack |
| `z00z_wallets::receiver::detector` | Detection logic already exists in `receiver_scan_leaf()` and `StealthOutputScanner` internals | Unify around current code paths instead of inventing a new detector namespace |
| `z00z_core::tx::output_leaf` | Canonical public leaf is `crates/z00z_core/src/assets/leaf.rs::AssetLeaf` | Keep `AssetLeaf` as the canonical imported leaf contract |
| `z00z_storage::asset_db` | Wallet persistence already exists in `wallet_service.rs`, `asset_storage_impl.rs`, and wallet snapshot state | Reuse existing wallet persistence surfaces |
| `OutputLeaf` / `OutputLeafWithTag16` custom structures | Current code uses `AssetLeaf` for canonical full leaves and `Asset` with optional stealth fields for runtime wallet scans | Normalize existing types; do not add a third public output type |
| `tag16 = owner_tag[0..2]` simplification | Current canonical contract is `compute_tag16(k_dh, leaf_ad)` or `compute_tag16_with_req(k_dh, req_id)` | Preserve current `tag16` formula and semantics |
| `R_pub` / `C_amount` field names | Current code uses `r_pub` and `c_amount` | Follow live field names only |

Checklist:

- [x] Before editing code, map each planned change to an existing live module in the table above.
- [x] Remove any implementation note that references a new top-level `receiver/` module tree as the default path.
- [x] Keep field naming aligned with live code: `r_pub`, `c_amount`, `enc_pack`, `tag16`.
- [x] Reject any proposal that replaces current `tag16` logic with owner-tag truncation.

### 2.2 Critical Review Findings That MUST Survive Rewriting

📌 The following live-code findings are critical and MUST remain explicit in every implementation pass.

| Risk | Live code evidence | Spec-6 requirement |
| --- | --- | --- |
| `compute_leaf_ad` has two public call shapes | `core/stealth/tag.rs` uses canonical order `asset_id, serial_id, r_pub, owner_tag, c_amount`, while `facade_kdf.rs` intentionally exposes `r_pub` first | Every implementation note MUST name which layer it is using |
| `Tag16Cache` is not yet a fully automatic request-derived prefilter | `StealthOutputScanner::add_request()` registers active `req_id` values, but complete tag-context population is not fully frozen | Treat current tag16 acceleration as partial or opportunistic |
| runtime scanner consumes `Asset`, not canonical `AssetLeaf` | `StealthOutputScanner::scan_leaf()` works over runtime assets with optional stealth fields | Preserve the distinction between canonical imported leafs and wallet-runtime hydrated assets |
| runtime `Asset` enforces full stealth tuple consistency | `Asset::validate_stealth_consistency()` rejects partial stealth tuples and requires `tag16` when stealth fields are present | Keep runtime receive or import logic aligned with this invariant |
| receive path and claimed-asset persistence are not the same boundary | `wallet_service.rs::put_claimed_asset()` persists claimed assets, while RPC `receive_asset()` mainly scans and reports | Detection MUST NOT be described as equivalent to claim or import completion |
| scan-state substrate exists, but receiver pipeline wiring is incomplete | `redb_wallet_store.rs` already defines `ScanStatePayload`, but current receiver orchestration is not yet frozen end-to-end against it | Describe scan progress and resume as integration work, not as already solved |

Checklist:

- [x] Name the `compute_leaf_ad` layer explicitly in every helper extraction note and code review summary.
- [x] Treat `Tag16Cache` as a best-effort prefilter in docs, tests, and public API comments.
- [x] Preserve the distinction between `AssetLeaf` inputs and runtime `Asset` inputs in helper signatures and adapter layers.
- [x] Keep `Asset::validate_stealth_consistency()` as a required invariant whenever runtime assets are created or imported.
- [x] Document scan success and claimed-asset persistence as separate milestones in code and tests.
- [x] Bind scan cursor persistence work to `ScanStatePayload` instead of inventing a second cursor model by default.

### 2.3 Duplication Ban For Spec-6 Delivery

📌 Duplicate solutions are forbidden in three areas:

- duplicate crypto validation cores;
- duplicate public receiver result types;
- duplicate persistence schemas for detected outputs.

Checklist:

- [x] Extract common receiver logic before adding any second validation sequence.
- [x] Reuse `WalletStealthOutput`, `Asset`, or private adapters before defining another public receive result type.
- [x] Reuse wallet snapshot state, `AssetStorageImpl`, or `ScanStatePayload` before creating a new receiver persistence table.
- [x] Block any PR that introduces both a new helper stack and leaves the old implementation intact.

## Phase 3. Canonical Live Modules For Spec 6

### 3.1 Canonical Module Map

📌 The following modules are the current source-of-truth entry points for receiver output reception and MUST be treated as canonical until explicitly migrated.

| Area | Canonical module | Current role |
| --- | --- | --- |
| Canonical imported leaf | `crates/z00z_core/src/assets/leaf.rs` | Defines `AssetLeaf` and `AssetPackPlain` |
| Canonical tag and AD formulas | `crates/z00z_wallets/src/core/stealth/tag.rs` | Owns canonical `leaf_ad` and `tag16` formulas |
| Wallet KDF facade order adapter | `crates/z00z_wallets/src/core/stealth/facade_kdf.rs` | Re-exports wallet-facing helpers with alternate parameter order |
| Canonical full-leaf detect path | `crates/z00z_wallets/src/core/address/leaf_scan.rs` | `receiver_scan_leaf()` over `AssetLeaf` |
| Wallet runtime scan path | `crates/z00z_wallets/src/core/address/stealth_scanner.rs` | Runtime scan front end, request registration, tag cache, and DTO shaping |
| Private runtime scan helper extraction | `crates/z00z_wallets/src/core/address/stealth_scan_support.rs` | Private decrypt/parse/commit helper unit used by `stealth_scanner.rs` |
| Parallel scan wrapper | `crates/z00z_wallets/src/core/address/optimized_scanner.rs` | Rayon-backed batch scan wrapper |
| Wallet-facing scan orchestration | `crates/z00z_wallets/src/core/address/address_manager.rs` | Checkpoint scan orchestration |
| Wallet-native persistence | `crates/z00z_wallets/src/services/wallet_service.rs` | Stores claimed assets in wallet snapshot state |
| Asset storage adapter | `crates/z00z_wallets/src/core/storage/asset_storage_impl.rs` | Internal asset persistence and spend metadata |
| Wallet scan progress substrate | `crates/z00z_wallets/src/db/redb_wallet_store.rs` | Defines `ScanStatePayload` and wallet scan metadata |
| RPC receive surface | `crates/z00z_wallets/src/adapters/rpc/methods/asset_impl.rs` | `receive_asset()` |
| RPC tx scan surface | `crates/z00z_wallets/src/adapters/rpc/methods/tx_impl.rs` | Package scan and report logic |

📌 The current map is synchronized with the live extraction state: receiver execution remains in canonical owner modules, while `stealth_scan_support.rs` stays private and non-authoritative.

Checklist:

- [x] Keep the module map synchronized with live code before each implementation phase starts.
- [x] Extend one of the canonical modules above before proposing any new internal file.
- [x] Record module ownership decisions in this spec when responsibility moves from one file to another.
- [x] Keep `z00z_core` as canonical for leaf shapes and `z00z_wallets` as canonical for receiver execution.

### 3.2 Responsibility Ownership Map

📌 Ownership rules:

- `z00z_core` owns canonical data contracts such as `AssetLeaf` and `AssetPackPlain`.
- `core/stealth/tag.rs` owns canonical `leaf_ad` and `tag16` rules.
- `leaf_scan.rs` owns the canonical full-leaf validation sequence.
- `stealth_scanner.rs` owns wallet-runtime adaptation, request iteration, tag-cache use, and scan result DTO production.
- `stealth_scan_support.rs` owns only the private runtime helper extraction used by `stealth_scanner.rs`; it does not become a second public scan authority.
- `wallet_service.rs`, `asset_storage_impl.rs`, and `redb_wallet_store.rs` own persistence and scan progress boundaries.
- RPC adapters own external result shaping only and MUST NOT become the place where crypto rules are reimplemented.

📌 The current caller graph for the private helper extraction is intentionally singular: `stealth_scanner.rs` delegates to `stealth_scan_support.rs`, while RPC adapters continue to call the scanner and only shape outward results.

Checklist:

- [x] Keep cryptographic validation logic out of RPC adapter files except for delegation and error mapping.
- [x] Keep persistence branching out of `leaf_scan.rs` unless the change is an internal callback hook with explicit review.
- [x] Keep formula ownership in `core/stealth/tag.rs` and avoid shadow helpers elsewhere.
- [x] Ensure every new helper has one owner file and one caller graph.

### 3.3 File Selection Rule Before Any New File Is Added

📌 Spec-6 permits a new internal file only after the existing owner files become unreadable or accumulate multiple private helpers that are logically one extracted unit.

📌 The current private extraction follows that rule: `stealth_scan_support.rs` exists because the runtime decrypt, parse, and commitment helpers became one dense private unit inside `stealth_scanner.rs`; the file remains private to `core/address/` and the canonical map above now records it explicitly.

Checklist:

- [x] Attempt the smallest change inside existing owner files first.
- [x] Add a new internal file only after documenting why the existing file can no longer hold the shared helper cleanly.
- [x] Keep any extracted file private to `core/address/` unless a second live module truly needs the API.
- [x] Update the canonical module map and phase tasks the same day a new internal file is introduced.

## Phase 4. Current Receiver Workflow In Live Code

### 4.1 Canonical Full-Leaf Detection Path

📌 `receiver_scan_leaf()` already performs the canonical full-leaf path for `AssetLeaf`.

📌 The current ordered stages are:

- validate `serial_id` version;
- decode and reject invalid or identity `r_pub`;
- compute receiver-side ECDH;
- derive `k_dh`;
- perform the M1 `owner_tag` check before decryption;
- recompute `leaf_ad`;
- verify `tag16` using the current canonical formula;
- decrypt `enc_pack` through `ZkPack::decrypt`;
- parse `AssetPackPlain` with bounded checks;
- verify commitment opening.

📌 The live Phase-4 boundary now uses one shared private detect core for both `AssetLeaf` and runtime `Asset` inputs after the public adapter layer selects the input shape.

Checklist:

- [x] Preserve the current validation order when refactoring shared helpers.
- [x] Keep M1 before decryption and before commitment verification.
- [x] Keep bounded parsing after successful AEAD verification.
- [x] Keep `receiver_scan_leaf()` as the canonical authority for `AssetLeaf` inputs.

### 4.2 Wallet Runtime Scan Path

📌 `StealthOutputScanner` already provides a wallet-runtime scan path over `Asset` with optional stealth metadata.

📌 Wallet-facing code already consumes this scanner through address-manager hooks, RPC transaction package verification, RPC receive flow, and scanner tests.

📌 Runtime `Asset` inputs continue to enter through `StealthOutputScanner`, while runtime receive/import boundaries keep hydrated assets aligned with `Asset::validate_stealth_consistency()`, tag-cache misses remain fallback candidates, and persistence plus public result shaping stay outside batch scan execution.

Checklist:

- [x] Preserve `StealthOutputScanner` as the wallet-runtime front end instead of bypassing it.
- [x] Keep runtime `Asset` validation aligned with `Asset::validate_stealth_consistency()`.
- [x] Treat `Tag16Cache` misses as a path to fallback scanning, not as proof of `NotMine` by themselves.
- [x] Keep batch parallelism separate from cursor persistence and API result shaping.

### 4.3 Fragmentation And Unresolved Boundaries

📌 The current receiver logic is split across two partially overlapping implementations:

- `receiver_scan_leaf()` over canonical `AssetLeaf`;
- `StealthOutputScanner::scan_leaf()` over wallet `Asset` objects with embedded stealth fields.

📌 These paths repeat the same logical stages with slightly different adapters and therefore create the duplication risk that Spec 6 MUST resolve.

📌 The Phase-4 live freeze is now: one shared private detect core inside `core/address/*`, one explicit receive-versus-claim boundary (`receive_asset()` scans/reports, `put_claimed_asset()` persists claims), one cursor substrate (`ScanStatePayload`), and one receive-status mapper from internal scan outcomes to public RPC status codes.

Checklist:

- [x] Freeze a single shared detection core for both leaf and runtime scan paths.
- [x] Define one explicit receive-versus-claim boundary in docs, code comments, and integration tests.
- [x] Bind scan resume to `ScanStatePayload` or document why a different internal substrate is strictly necessary.
- [x] Add one mapping layer from detailed internal rejection classes to public API statuses.

## Phase 5. Non-Negotiable Spec-6 Rules

### 5.1 Cryptographic Invariants

📌 The following cryptographic rules are mandatory and not open to reinterpretation.

Checklist:

- [x] Reuse canonical formula helpers from live code instead of rewriting them inline.
- [x] Name every helper by the layer it belongs to when argument order differs.
- [x] Keep M1 ahead of decryption, parsing, and commitment verification in all entry points.
- [x] Add regression tests that fail if `tag16` or `leaf_ad` semantics drift.

### 5.2 Architectural Invariants

📌 The following architectural rules are mandatory.

Checklist:

- [x] Start every phase by modifying `core/address/*` before considering new extraction.
- [x] Preserve public signatures where possible and move duplication behind private helpers.
- [x] Keep request-aware logic in scanner or shared detect helpers, not in RPC adapters.
- [x] Reject any design that duplicates both scan orchestration and detect logic.

### 5.3 Persistence And API Invariants

📌 The following receive and persistence rules are mandatory.

Checklist:

- [x] Reuse wallet-native storage boundaries before proposing new receiver persistence records.
- [x] Keep detected output DTOs separate from claimed wallet assets until import rules are frozen.
- [x] Store or report scan progress through one explicit cursor model.
- [x] Map internal rejection reasons to stable, non-sensitive public result categories.

## Phase 6. Required Implementation Outcome

### 6.1 Canonical Pipeline Properties

📌 Spec-6 is complete only when the repository has one unambiguous receiver pipeline.

Checklist:

- [x] Share receiver crypto validation through one helper core used by both leaf and runtime paths.
- [x] Publish one stable internal rejection enum or equivalent mapped taxonomy used across scan and RPC surfaces.
- [x] Freeze one receive-to-persist decision point and use it everywhere.
- [x] Expose one progress model for range scanning and resume.

### 6.2 Public Result Semantics

📌 Public wallet and RPC surfaces do not need to expose every internal failure detail, but they must stop being ambiguous.

Checklist:

- [x] Define one public status vocabulary shared by wallet service and RPC adapters.
- [x] Keep `NotMine` separate from malformed or invalid output results.
- [x] Keep internal crypto or runtime failure distinct from validation failure in logs and metrics.
- [x] Add tests that assert identical public status mapping across wallet and RPC surfaces.

### 6.3 Done Criteria For Spec Closure

📌 Spec-6 is done when receiver behavior is frozen enough that later code changes cannot silently re-fragment the pipeline.

📌 Review note: canonical full-leaf and runtime receive entry points now converge on one private detect core in `core/address/stealth_scan_support.rs`, while RPC adapters keep outward mapping only and do not reimplement receiver cryptography.

📌 Restart note: wallet-native scan progress remains bound to `ScanStatePayload`, and persisted reopen behavior is covered by the `.wlt` restart test path.

Checklist:

- [x] Refuse to close Spec 6 until all five boundary areas from Phase 4.3 are frozen in code and tests.
- [x] Keep docs, tests, and code comments synchronized on the same boundary language.
- [x] Add review notes proving there is no remaining duplicate receiver crypto flow.
- [x] Mark Spec 6 complete only after restart or recovery behavior is tested with persisted state.

## Phase 7. Sequential Implementation Plan

### 7.1 Freeze The Canonical Receiver Boundary

📌 Purpose: eliminate ambiguity about which existing functions and types own Spec-6.

📌 Required code work:

- keep `AssetLeaf` and `AssetPackPlain` as canonical full-leaf types;
- keep `StealthOutputScanner` as the wallet-runtime scanner front end;
- explicitly document that `receiver_scan_leaf()` is the full-leaf authority and `StealthOutputScanner` is the wallet-facing adapter;
- add missing inline documentation only where the live code boundary is still unclear.

📌 Files to touch first:

- `crates/z00z_wallets/src/core/address/mod.rs`;
- `crates/z00z_wallets/src/core/address/leaf_scan.rs`;
- `crates/z00z_wallets/src/core/address/stealth_scanner.rs`;
- `specs/012-z00z-ecc-spec-6/spec-6.md`.

📌 Exit criteria:

- no document proposes a parallel `z00z_wallets::receiver::*` tree as the primary implementation path;
- one table maps every Spec-6 responsibility to a live module.

Checklist:

- [x] Add or update module-level docs in `core/address/mod.rs` naming `leaf_scan.rs` and `stealth_scanner.rs` as canonical Spec-6 owners.
- [x] Add a short comment in `leaf_scan.rs` stating it is the canonical full-leaf detection authority.
- [x] Add a short comment in `stealth_scanner.rs` stating it is the runtime asset adapter, not the canonical formula source.
- [x] Verify `spec-6.md` and `WALLET-ECC-SPEC.md` use the same ownership language.

### 7.2 Unify Detection Logic Without Public Type Drift

📌 Purpose: remove duplicated receiver cryptography and validation flow.

📌 Review note: canonical full-leaf detection still owns the formula path, while the runtime wallet adapter now routes into the same detect order and no longer reassembles its own crypto sequence in RPC code.

Checklist:

- [x] Inventory duplicated steps between `receiver_scan_leaf()` and `StealthOutputScanner::scan_leaf()` before writing code.
- [x] Extract one private helper sequence for ECDH, M1, decrypt, parse, and commitment verification.
- [x] Keep one adapter path from `AssetLeaf` and one adapter path from runtime `Asset` into the shared helper.
- [x] Add regression tests proving both entry points still reject and accept in the same order.

### 7.3 Normalize Rejection Taxonomy And Observability

📌 Purpose: make receiver failures diagnosable without changing the security contract.

Checklist:

- [x] Define one internal rejection taxonomy used by both leaf and runtime scan paths.
- [x] Distinguish malformed runtime `Asset` stealth tuples from cryptographic `NotMine` results.
- [x] Map the internal taxonomy consistently in `asset_impl.rs` and `tx_impl.rs`.
- [x] Add unit tests that assert stable classification for tampered `r_pub`, `enc_pack`, `tag16`, and commitments.

### 7.4 Formalize Scanner Orchestration Over Existing Scanners

📌 Purpose: grow from single-leaf scan to checkpoint or range scan without replacing the current scanner family.

📌 Restart note: range resume remains bound to `ScanStatePayload`, and wallet-service restart coverage now proves that persisted cursor state resumes from the next checkpoint instead of rescanning the entire range.

Checklist:

- [x] Implement range-scan orchestration as a wrapper over existing scanner primitives, not as a new scanner family.
- [x] Define one scan progress DTO containing checkpoint position, work totals, and result counters.
- [x] Persist scan cursor updates through `ScanStatePayload` integration points.
- [x] Add tests for resume-after-restart and partial-scan continuation.

### 7.5 Integrate Reception With Wallet Persistence

📌 Purpose: ensure detected outputs land in wallet-native state through existing storage layers.

📌 Review note: Phase 7 keeps `WalletStealthOutput` as an ephemeral scan/report DTO only; persistence still happens only after the explicit `recv_route()` decision upgrades runtime `Asset` data into the wallet-native claimed path.

Checklist:

- [x] Define one staging record or direct import path and document it explicitly.
- [x] Keep `WalletStealthOutput` out of long-term persistence unless a deliberate adapter proves otherwise.
- [x] Reuse `wallet_service.rs` and `asset_storage_impl.rs` before creating new persistence code.
- [x] Add restart tests proving detected or imported outputs remain available after reload.

### 7.6 Freeze Wallet And RPC Reception APIs

📌 Purpose: make the receiver workflow accessible without bypassing validation order.

Checklist:

- [x] Add one wallet-facing reception method that performs checkpoint or range scan through existing scanner primitives.
- [x] Keep public API methods delegating to shared receive logic instead of re-implementing detection.
- [x] Expose progress without leaking secrets, derived keys, or internal crypto material.
- [x] Add API tests that assert stable status mapping for `Mine`, `NotMine`, malformed, and internal-error outcomes.

### 7.7 Complete The Test And Benchmark Matrix

📌 Purpose: freeze Spec-6 behavior against regressions.

Checklist:

- [x] Extend `test_stealth_scanner.rs` first for scanner-level regressions.
- [x] Extend sender-to-receiver roundtrip tests before adding new benchmark-only coverage.
- [x] Add persistence and restart scenarios to the closest existing integration suite.
- [x] Add adversarial cases for M1, tag16 collisions, and malformed runtime assets in the same phase as production code changes.

## Phase 8. Recommended File-Level Integration Map

📌 Review note: the live Spec-6 landing order stayed core-first: detect ownership remains in `core/address/*`, range orchestration delegates downward, scan-state persistence stays in `redb_wallet_store.rs`, wallet claim routing stays in `wallet_service.rs`, and RPC adapters only shape outward results after shared receive decisions are already frozen. `asset_storage_impl.rs` remains a parallel storage adapter, not the active claimed-receive path.

### 8.1 Implementation Order

📌 The following file order is the recommended implementation sequence for actual code work.

| Order | File | Role in Spec-6 program |
| --- | --- | --- |
| 1 | `crates/z00z_wallets/src/core/address/leaf_scan.rs` | Canonical full-leaf receiver detection |
| 2 | `crates/z00z_wallets/src/core/stealth/tag.rs` | Canonical `leaf_ad` and `tag16` rules |
| 3 | `crates/z00z_wallets/src/core/stealth/facade_kdf.rs` | Wallet-facing KDF adapter |
| 4 | `crates/z00z_wallets/src/core/address/stealth_scanner.rs` | Runtime adapter, tag cache, DoS surface |
| 5 | `crates/z00z_wallets/src/core/address/optimized_scanner.rs` | Parallel batch execution |
| 6 | `crates/z00z_wallets/src/core/address/address_manager.rs` | Wallet-level checkpoint orchestration |
| 7 | `crates/z00z_wallets/src/db/redb_wallet_store.rs` | Scan-state substrate |
| 8 | `crates/z00z_wallets/src/services/wallet_service.rs` | Persistence boundary |
| 9 | `crates/z00z_wallets/src/core/storage/asset_storage_impl.rs` | Asset persistence metadata |
| 10 | `crates/z00z_wallets/src/adapters/rpc/methods/asset_impl.rs` | Public receive API |
| 11 | `crates/z00z_wallets/src/adapters/rpc/methods/tx_impl.rs` | Package scan API |

📌 Mermaid note: the diagram below shows recommended edit sequence only. It is not a Rust module dependency graph.

```mermaid
flowchart TD
    A[1. leaf_scan.rs] --> B[2. tag.rs]
    B --> C[3. facade_kdf.rs]
    C --> D[4. stealth_scanner.rs]
    D --> E[5. optimized_scanner.rs]
    E --> F[6. address_manager.rs]
    F --> G[7. redb_wallet_store.rs]
    G --> H[8. wallet_service.rs]
    H --> I[9. asset_storage_impl.rs]
    I --> J[10. asset_impl.rs]
    J --> K[11. tx_impl.rs]
```

Checklist:

- [x] Follow the file order above unless a blocking dependency forces a documented reordering.
- [x] Update formula owner files before adapter or API files when both need changes.
- [x] Touch test files in the same phase as production files.
- [x] Keep storage and API file changes after detect-core stabilization unless a failing test proves otherwise.

### 8.2 Edit Boundary Rules

📌 Spec-6 changes should move from core to adapters, not from adapters back into core.

📌 Review note: the current live boundary is now explicit in code comments too: `address_manager.rs` delegates range work into the scanner, `wallet_service.rs` owns receive-versus-claim routing, `asset_storage_impl.rs` remains a separate storage adapter rather than the claimed receive path, and `asset_impl.rs` remains an outward adapter instead of compensating for missing core logic.

Checklist:

- [x] Do not patch RPC adapters to compensate for unresolved core logic.
- [x] Do not patch persistence code before receive-versus-claim semantics are written down.
- [x] Keep range-scan wrappers delegating into stable detect code, not vice versa.
- [x] Review dependency direction before each phase lands.

## Phase 9. Pseudocode For The Target Receiver Pipeline

### 9.1 Canonical Receive Flow Pseudocode

📌 Review note: the live canonical checkpoint receive flow remains scanner-driven through `address_manager.rs`, while the full-leaf authority remains `receiver_scan_leaf()`. Convergence is now locked at the shared receive/report contract too: Phase 9 parity tests compare full-leaf `receiver_scan_report()` against runtime `ScanResult::recv_report()` over the same sender-to-receiver fixture for both owned and invalid-proof paths.

```rust
pub fn receive_checkpoint(
    keys: &ReceiverKeys,
    leaves: &[Asset],
    reqs: &[PaymentRequest],
) -> Result<Vec<WalletStealthOutput>, ReceiveError> {
    let mut scanner = StealthOutputScanner::from_keys(keys);

    for req in reqs {
        scanner.add_request(req);
    }

    let outputs = scanner.scan_checkpoint(leaves);
    Ok(outputs)
}

pub fn detect_full_leaf(
    keys: &ReceiverKeys,
    leaf: &AssetLeaf,
) -> Result<Option<AssetPackPlain>, WalletError> {
    receiver_scan_leaf(keys, leaf)
}
```

Checklist:

- [x] Keep one canonical detect order shared by full-leaf and runtime paths.
- [x] Adapt runtime `Asset` into the detect core without redefining formulas.
- [x] Keep request registration outside the cryptographic core and inside orchestration layers.
- [x] Add tests proving both entry points converge on the same internal result semantics.

### 9.2 Persistence Boundary Pseudocode

📌 Review note: the live persisted upgrade boundary is now explicit: `ReceiveNext::ReportOnly` cannot mutate claimed state, while `ReceiveNext::PersistClaim` routes only canonical validated asset data through `wallet_service.rs` before restart-backed persistence assertions are accepted.

```rust
pub async fn persist_detected_asset(
    service: &WalletService,
    wallet_id: &PersistWalletId,
    asset: Asset,
) -> WalletResult<bool> {
    service.put_claimed_asset(wallet_id, asset).await
}
```

Checklist:

- [x] Freeze the exact condition that upgrades `Detected` into `Persisted/Claimed`.
- [x] Convert detection output into canonical asset data before persistence if import is truly happening.
- [x] Keep persistence code behind wallet service boundaries instead of writing directly from RPC adapters.
- [x] Add restart tests for the persisted path before declaring the boundary stable.

## Phase 10. Mermaid Overview

### 10.1 Receiver Flow Diagram

📌 Review note: the live entry points remain `receiver_scan_leaf()` for canonical `AssetLeaf`, `StealthOutputScanner::scan_leaf()` for runtime `Asset`, `recv_route()` for the explicit claim boundary, and `recv_range()` for range execution plus `ScanStatePayload` cursor updates after processed checkpoints. Shared receive reports stay report-only; `PersistClaim` is selected only by caller-specific boundaries such as range receive or validated import.

```mermaid
flowchart TD
    A[Materialized input] --> B{Input shape}
    B -->|AssetLeaf| C[receiver_scan_leaf / receiver_scan_report]
    B -->|Runtime Asset| D[validate_stealth_consistency]
    D --> E[StealthOutputScanner::scan_leaf]
    E --> F[Optional Tag16Cache prefilter]
    F --> G[M1 owner_tag validation]
    C --> G
    G --> H[ZkPack decrypt]
    H --> I[AssetPackPlain parse]
    I --> J[Commitment opening check]
    J --> K[ReceiveReport status]
    K --> L[Report only]
    M[Validated import or recv_range] --> N[caller selects PersistClaim]
    N --> O[recv_route -> wallet claimed persistence]
    O --> R[Claimed wallet state]
    P[recv_range processed checkpoints] --> Q[upsert ScanStatePayload cursor]
```

Checklist:

- [x] Keep the flow ordered as `prefilter -> M1 -> decrypt -> parse -> open -> detect -> persist-or-stage`.
- [x] Keep the persistence boundary explicit in code comments and API docs.
- [x] Update the diagram if any phase changes where scan-state updates occur.
- [x] Ensure the diagram remains aligned with actual code entry points after refactoring.

### 10.2 State Transition Diagram Requirements

📌 Review note: public receive status remains `Detected`, `InvalidProof`, or `NotMine`, while wallet-native claimed persistence stays a later state behind caller-selected `ReceiveNext::PersistClaim` and must not be collapsed into `Detected`.

```mermaid
stateDiagram-v2
    [*] --> InputSeen
    InputSeen --> NotMine: ReceiveStatus::NotMine
    InputSeen --> InvalidProof: ReceiveStatus::InvalidProof
    InputSeen --> Detected: ReceiveStatus::Detected
    Detected --> ReportOnly: recv_report()
    Detected --> ClaimGate: recv_range or validated import
    ClaimGate --> Claimed: caller-selected PersistClaim via recv_route()
```

Checklist:

- [x] Keep state names stable across diagrams, tests, and API status mapping.
- [x] Do not add a direct `Detected == Claimed` assumption in any diagram or doc string.
- [x] Use the same state names in benchmark and observability reports where possible.
- [x] Revisit the diagram if a staging record is introduced.

## Phase 11. Acceptance Checklist

### 11.1 Code Readiness Gate

📌 Review note: acceptance evidence is now explicit in live code: canonical ownership remains in `core/address/mod.rs`, no new public `receiver::*` module tree exists in live `z00z_wallets` code, shared detect execution is frozen in `core/address/stealth_scan_support.rs`, `scan_owned()` keeps the M1 owner-tag gate ahead of decrypt/parse/open, and `tag16` still routes through canonical helpers rather than owner-tag truncation. Historical archival ECC drafts still contain legacy `receiver::*` references and are not the acceptance authority for Spec-6 closure.

Checklist:

- [x] Spec-6 uses existing modules as canonical sources.
- [x] No parallel receiver module tree is introduced.
- [x] One shared detection core replaces duplicated receiver crypto logic.
- [x] M1 remains the first meaningful ownership gate.
- [x] `tag16` semantics stay aligned with existing code and Spec-5 assumptions.

### 11.2 Persistence And API Gate

📌 Review note: persistence still reuses wallet-native boundaries only: `recv_route()` is the single claim gate, canonical wallet-service receive surfaces (`recv_one()`, `recv_range()`, `recv_code()`) and RPC `receive_asset()` remain aligned on the shared receive taxonomy, `recv_range()` plus `ScanStatePayload` remains the explicit resume contract, and public status mapping stays frozen around `Detected`, `InvalidProof`, and `NotMine` without collapsing detection into claimed state. The older reachability placeholder path is not part of the acceptance authority for Spec-6 closure.

Checklist:

- [x] Persistence reuses wallet-native storage boundaries.
- [x] Wallet and RPC reception APIs align on one result taxonomy.
- [x] Scan progress and resume use one explicit cursor contract.
- [x] Receive success is not presented as claimed wallet state until persistence rules are satisfied.

### 11.3 Test And Review Gate

📌 Review note: the active acceptance baseline remains synchronized across code comments, `spec-6.md`, `WALLET-ECC-SPEC.md`, unit tests, integration tests, adversarial tests, and existing benchmark surfaces. Historical archival ECC drafts are not treated as synchronization targets for this gate. No blocking unresolved acceptance boundary remains; the known best-effort `Tag16Cache` limitation is already frozen and documented rather than hidden.

Checklist:

- [x] Unit, integration, adversarial, and performance tests are updated together.
- [x] Documentation and code references stay synchronized.
- [x] Review notes explicitly call out remaining unresolved boundaries, if any.
- [x] Spec 6 is not marked complete while any acceptance item above remains unchecked.

## Phase 12. Relationship To `WALLET-ECC-SPEC.md`

### 12.1 Document Relationship

📌 `WALLET-ECC-SPEC.md` in this folder is the broader skeleton document that will gradually absorb phase-by-phase ECC wallet implementation guidance.

📌 `spec-6.md` is the receiver-output-reception execution plan for the current repository state. `WALLET-ECC-SPEC.md` should reference this file for receiver specifics, not re-describe them in parallel.

📌 Review note: the active document pair is now explicit. `spec-6.md` remains the authoritative receiver review baseline, while `WALLET-ECC-SPEC.md` keeps only ownership language, top-level routing, and the rule that future receiver behavior changes must update `spec-6.md` first or together with tests.

Checklist:

- [x] Keep receiver-specific sequencing in `spec-6.md` and only summarize it from `WALLET-ECC-SPEC.md`.
- [x] Update `WALLET-ECC-SPEC.md` if Spec-6 phase names or boundaries change.
- [x] Avoid duplicating detailed receiver checklists in both documents.
- [x] Keep terminology identical across both files.

### 12.2 Update Rule For Future Phases

📌 Review note: future receiver work now has one update rule: change `spec-6.md` first or in the same change set as code/tests, then adjust `WALLET-ECC-SPEC.md` only when the ownership or top-level routing summary must move with it.

Checklist:

- [x] Update `spec-6.md` before or together with any receiver behavior change.
- [x] Update tests in the same change set as the spec if receiver semantics move.
- [x] Re-run document review against live code whenever a new receive phase starts.
- [x] Keep `spec-6.md` as the authoritative review baseline until receiver work is absorbed into a broader finalized wallet ECC spec.
