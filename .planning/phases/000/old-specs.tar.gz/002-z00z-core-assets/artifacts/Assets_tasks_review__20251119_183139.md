# Review: Asset Output Workstream Task List

**Version/Commit:** Draft v1  
**Reviewer:** Review Agent (POML-driven)  
**Date:** 2025-11-19  
**Inputs:** `Assets_tasks_draft__20251119_183139.md`  
**Scope reviewed:** Full task list (9 phases, 45 tasks)

---

## 0. Executive Summary

* [x] **Current readiness**: **GREEN** — Draft is well-structured, comprehensive, and actionable
* [x] **Critical decision(s) needed**:
  - Confirm gas schedule constants before T027 implementation
  - Agree on YAML schema version for code generation (T031)
  - Validate offline coin record format for cross-wallet compatibility (T023-T024)

---

## 0. Marker Verification Audit ✅ MANDATORY (P1 BLOCKER)

### Marker Count Check

```plaintext
INPUT spec marker count:  8 (👍🔔 markers in assets_spec_release.md)
DRAFT task list marker count: 8 (preserved in Phase Overviews)
Status: PASS ✅
```

### Verification Result

- [x] **PASS**: Marker counts match (8 == 8) → All critical requirements preserved
- [x] All 8 markers correctly mapped to phase overviews:
  - Phase 1: SUB-FEATURE-001 (Canonical Schema)
  - Phase 2: SUB-FEATURE-002 (CoinOutput)
  - Phase 3: SUB-FEATURE-003 (Asset ID Derivation)
  - Phase 4: SUB-FEATURE-004 (Specialized Outputs)
  - Phase 5: SUB-FEATURE-005 (Offline Coins)
  - Phase 6: SUB-FEATURE-006 (Gas Model)
  - Phase 7: SUB-FEATURE-007 (YAML Schema)
  - Phase 8: SUB-FEATURE-008 (Lifecycle Invariants)

**No missing markers detected. Traceability preserved.**

---

## 1. What's Solid

* [x] **Strengths worth keeping**:
  - [x] **Comprehensive phase breakdown**: 9 phases covering all spec sections with clear progression
  - [x] **Detailed task granularity**: 45 tasks with explicit subtasks, dependencies, and commit points
  - [x] **Strong test coverage**: Each phase includes unit tests, integration tests, and verification criteria
  - [x] **Traceability maintained**: All 8 👍🔔 markers from spec preserved in phase overviews
  - [x] **Dependency graph**: Task dependencies explicitly mapped for proper execution order
  - [x] **Git/GitHub commit discipline**: `git_commit()` after each task, `github_commit()` every 5th task and at phase ends

---

## 2. Evidence Map (claims → evidence)

### C-001: All spec sections covered

* [x] **Claim**: Draft covers all spec sections from `assets_spec_release.md`
* [x] **File**: `Assets_tasks_draft__20251119_183139.md`
* [x] **Evidence**:
  - Section 2 (Global asset model) → Phase 1, 3, 4
  - Section 3 (coins.rs) → Phase 2
  - Section 4-6 (tokens/nfts/void) → Phase 4
  - Section 7 (gas.rs) → Phase 6
  - Section 8 (offline) → Phase 5
  - Section 9 (YAML) → Phase 7
  - Section 10 (invariants) → Phase 8
  - Section 11 (integration) → Phase 9
* [x] **Status**: Supported ✅

### C-002: Task dependencies are correct

* [x] **Claim**: Task dependency order respects spec requirements
* [x] **File**: `Assets_tasks_draft__20251119_183139.md`, "Task Dependencies" section
* [x] **Evidence**: Sequential dependencies within phases (e.g., T001→T002→T003), cross-phase dependencies (T002→T011, T003→T016)
* [x] **Status**: Supported ✅

### C-003: Test coverage is adequate

* [x] **Claim**: Each phase includes test cases covering unit, integration, and property tests
* [x] **File**: `Assets_tasks_draft__20251119_183139.md`, "Test Cases" sections in each phase
* [x] **Evidence**: 
  - Phase 1: 5 unit tests (enum, validation, nonce uniqueness, size limits, conversion)
  - Phase 2: 5 tests (constructor, verification, nullifier uniqueness, limits, roundtrip)
  - Phase 3: 5 tests (determinism, uniqueness, constant matching, encoding, property)
  - Phases 4-8: Similar coverage patterns
* [x] **Status**: Supported ✅

---

## 3. Findings (prioritized checklist)

### F-001 — Missing explicit error handling strategy

* [x] **Priority**: P2 (risks acceptance)
* [x] **Effort**: M (medium)
* [x] **Impact**: Developer experience — unclear how errors propagate across asset validation layers
* [x] **Evidence**:
  - File: `Assets_tasks_draft__20251119_183139.md`
  - Tasks T007, T008, T017, T029, T036 mention `Result<()>` but don't specify error types
  - No unified error enum defined
* [x] **Diagnosis**: Error handling is implicit; spec mentions "descriptive errors" but draft doesn't require a consistent error type hierarchy
* [x] **Recommendation**:
  - Add **T005.5** (between T005 and T006): "Define `AssetError` enum with variants for InvalidCommitment, ProofVerificationFailed, InvalidMetadata, BurnNotAllowed, etc."
  - Update T007-T010, T017, T029, T036-T039 to use `Result<T, AssetError>` consistently
  - Add error display/debug tests in Phase 1 test cases
* [x] **Validation**: Compile-time check that all public functions return `Result<T, AssetError>`; runtime test for error message clarity

### F-002 — Gas schedule constants not specified

* [x] **Priority**: P2 (risks acceptance)
* [x] **Effort**: S (small)
* [x] **Impact**: Fee calculation (T029) cannot be implemented without concrete `GasSchedule` values
* [x] **Evidence**:
  - File: `Assets_tasks_draft__20251119_183139.md`
  - Task T027: "Document that this is a compile-time constant in v1" but no values provided
  - Spec section 7 defines formula but not actual costs
* [x] **Diagnosis**: Draft correctly notes compile-time constant requirement but doesn't specify values or reference decision document
* [x] **Recommendation**:
  - Update T027 to include: "Define placeholder constants (base_tx_cost=100, per_input=50, per_output=50, per_range_proof_bit=1) pending finalization"
  - Add note: "TODO: Link to economic model doc once gas schedule is formalized"
  - Or: Add prerequisite to T027: "Wait for gas schedule decision from Z00Z economics team"
* [x] **Validation**: `GasSchedule` struct compiles with const fn; fee tests use placeholder values with clear "FIXME" markers

### F-003 — Offline record format versioning not addressed

* [x] **Priority**: P2 (risks acceptance)
* [x] **Effort**: M (medium)
* [x] **Impact**: Wallet interoperability — offline records from different versions may be incompatible
* [x] **Evidence**:
  - File: `Assets_tasks_draft__20251119_183139.md`
  - Tasks T023-T024: "Serialize to binary format (bincode or custom encoding)" but no version field
  - T025 mentions "serialize to file/QR" without format versioning
* [x] **Diagnosis**: Spec section 8 doesn't mandate versioning; draft follows spec but risks future incompatibility
* [x] **Recommendation**:
  - Update T021 `OfflineMeta` to include `format_version: u32` field
  - Update T023 serialization to write version header (4 bytes) before record data
  - Update T024 deserialization to check version and reject unsupported formats
  - Add test in Phase 5: "Version mismatch rejects deserialization with clear error"
* [x] **Validation**: Serialize with v1 format, attempt deserialize with v2 parser → error; roundtrip test with same version → success

### F-004 — YAML code generation output not tested

* [x] **Priority**: P3 (polish)
* [x] **Effort**: S (small)
* [x] **Impact**: Code quality — generated Rust code might have warnings or invalid syntax
* [x] **Evidence**:
  - File: `Assets_tasks_draft__20251119_183139.md`
  - Task T034-T035: Generate `assets_gen.rs` and `assets_validation_gen.rs`
  - Test cases mention "compile check" but no explicit task to run `cargo check` on generated code
* [x] **Diagnosis**: Draft assumes generated code will compile but doesn't enforce it in task flow
* [x] **Recommendation**:
  - Add **T035.5** (after T035): "Run `cargo check` on generated code files; fail if warnings or errors present"
  - Add to Phase 7 test cases: "Integration test: Load reference YAML, generate code, run `cargo test` on generated validation templates"
* [x] **Validation**: CI job runs code generator + `cargo check` on output; zero warnings policy

### F-005 — Mermaid diagram references not linked to code

* [x] **Priority**: P3 (polish)
* [x] **Effort**: S (small)
* [x] **Impact**: Documentation quality — diagrams in docs might drift from implementation
* [x] **Evidence**:
  - File: `Assets_tasks_draft__20251119_183139.md`
  - Task T042: "Add mermaid diagrams to documentation" but no validation that diagrams match code
  - Spec includes 4 mermaid diagrams (class, offline flow, derivation, gas)
* [x] **Diagnosis**: Diagrams are documentation-only; no mechanism to keep them in sync with code
* [x] **Recommendation**:
  - Update T042: "For each mermaid diagram, add doc comment linking to corresponding Rust struct/module"
  - Add to Phase 9 verification: "Manual review: Check that class diagram matches `src/types.rs` struct definitions"
  - Consider: Future task to auto-generate diagrams from code (out of scope for v1)
* [x] **Validation**: Documentation review checklist includes diagram-to-code correspondence check

### F-006 — Test coverage metrics not defined

* [x] **Priority**: P3 (polish)
* [x] **Effort**: S (small)
* [x] **Impact**: Quality assurance — unclear what "adequate test coverage" means
* [x] **Evidence**:
  - File: `Assets_tasks_draft__20251119_183139.md`
  - Each phase has "Test Cases" section but no coverage targets (e.g., 80% line coverage, 100% public API coverage)
  - Phase 9 verification mentions "cargo doc" but not "cargo tarpaulin" or similar
* [x] **Diagnosis**: Draft provides test cases but doesn't quantify coverage expectations
* [x] **Recommendation**:
  - Add to Phase 9, T045: "Run `cargo tarpaulin` or `cargo llvm-cov`; verify ≥80% line coverage for `assets` crate"
  - Add to Phase 1-8 verification criteria: "All public functions have at least one test case"
* [x] **Validation**: CI enforces coverage threshold; PR reviews check test count per public API

### F-007 — Transaction integration not explicitly tasked

* [x] **Priority**: P2 (risks acceptance)
* [x] **Effort**: M (medium)
* [x] **Impact**: System integration — asset outputs must integrate with transaction validation, but no explicit task
* [x] **Evidence**:
  - File: `Assets_tasks_draft__20251119_183139.md`
  - Tasks mention "transaction kernel" (T030), "transaction validation" (T038), but no task defines how `CoinOutput`, `TokenOutput`, etc. plug into `Transaction` struct
  - Spec section 3 mentions "for integration with the UTXO set and validation" but draft doesn't detail this
* [x] **Diagnosis**: Assets are defined in isolation; integration with `z00z_core/tx` module is assumed but not tasked
* [x] **Recommendation**:
  - Add **T045.5** (after T045): "Implement `Transaction::validate_outputs()` method to call `verify_features` for each output and check balance/burn constraints"
  - Add integration test: "Create transaction with multiple asset outputs (Coin, Token, NFT), validate successfully"
  - Reference `z00z_core/tx` module or add note: "Depends on transaction spec completion"
* [x] **Validation**: Integration test creates full transaction with asset outputs and verifies end-to-end validation

---

## 4. Next Steps (actionable brief)

### Immediate actions (before implementation)

1. **[P2-F001]** Define `AssetError` enum (add T005.5)
2. **[P2-F002]** Specify gas schedule constants or document decision dependency (update T027)
3. **[P2-F003]** Add versioning to `OfflineCoinRecord` format (update T021, T023, T024)
4. **[P2-F007]** Task transaction integration explicitly (add T045.5)

### Recommended refinements (during implementation)

5. **[P3-F004]** Add code generation validation task (add T035.5)
6. **[P3-F005]** Link mermaid diagrams to code (update T042)
7. **[P3-F006]** Define test coverage metrics (update T045)

### Validation gates

- **Before Phase 2**: `AssetError` enum defined and used in all Result types
- **Before Phase 6**: Gas schedule constants finalized or documented as pending
- **Before Phase 5**: Offline record format version strategy agreed
- **Before Phase 9**: Transaction integration task added and validated

---

## 5. Overall Assessment

**Draft Quality**: **8.5/10** — Excellent structure, comprehensive coverage, strong traceability.

**Readiness**: **Ready for implementation with minor refinements** (address P2 findings first).

**Risk Level**: **Low** — All P1 issues avoided; P2 issues are clarifications, not blockers.

**Recommendation**: **Approve draft with requested updates**. Implement F-001, F-002, F-003, F-007 before starting Phase 1 coding. Address P3 findings opportunistically during review cycles.

---

## Appendix A: Quick Locate Commands

### Find Phase Overviews
```bash
grep -nE '^## Phase [0-9]+:' Assets_tasks_draft__20251119_183139.md
```

### Find all 👍🔔 markers
```bash
grep -nE '👍🔔' Assets_tasks_draft__20251119_183139.md
```

### Find Task Dependencies section
```bash
grep -nE '^## Task Dependencies' Assets_tasks_draft__20251119_183139.md
```

### Find git_commit() calls
```bash
grep -nE 'git_commit\(\)' Assets_tasks_draft__20251119_183139.md
```

### Find github_commit() calls
```bash
grep -nE 'github_commit\(\)' Assets_tasks_draft__20251119_183139.md
```

---

**End of Review**
