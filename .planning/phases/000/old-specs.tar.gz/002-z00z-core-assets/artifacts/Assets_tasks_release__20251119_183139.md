# Task List: Asset Output Workstream

Generated from: `specs/002-z00z-core-assets/assets_spec_release.md`  
Target: Devs

## Phase 1: Canonical Asset Schema

### Phase Overview

> 👍🔔 **SUB-FEATURE-001** — Establish the canonical `AssetClass`, `AssetTag`, `OutputFeatures`, and `OutputMetadata` structures that serve as the foundation for all asset outputs in `z00z_core/assets`.

This phase defines the shared types and canonical layout that all asset outputs (Coin, Token, NFT, Void) must use. These structures are consensus-critical and must have exactly one definition across all specs.

### Tasks

- [ ] **T001**: Define `AssetClass` enum with variants `Coin`, `Token`, `Nft`, `Void`
  - [ ] Document the semantic meaning of each class (native coin, fungible token, NFT, protocol sink)
  - [ ] Ensure enum derives standard traits (`Debug`, `Clone`, `PartialEq`, `Eq`, `Serialize`, `Deserialize`)
  - git_commit()

- [ ] **T002**: Define `AssetTag` struct with fields `id: [u8; 32]`, `class: AssetClass`, `decimals: u8`
  - [ ] Document that `id` uniquely identifies the asset at protocol level
  - [ ] Add validation: `decimals` must be 0 for NFT and Void classes
  - git_commit()

- [ ] **T003**: Define canonical `OutputFeatures` struct with minimal protocol layout
  - [ ] Include fields: `lock_height: Option<u64>`, `is_burned: bool`, `nonce: [u8; 32]`, `asset_tag: Option<AssetTag>`
  - [ ] Document invariants: nonce must be unique, derived from `hash(PROTOCOL_SEED || random)`
  - [ ] Add note: NO script field in v1, NO metadata field (metadata goes to `OutputMetadata`)
  - git_commit()

- [ ] **T004**: Define `OutputMetadata` struct (non-consensus UX data)
  - [ ] Include fields: `memo: Option<String>`, `wallet_hint: Option<[u8; 32]>`, `app_tag: Option<[u8; 32]>`
  - [ ] Document size limits: memo max 256 bytes UTF-8, total metadata max 4 KiB
  - [ ] Mark as non-consensus: may be truncated by minimal nodes
  - git_commit()

- [ ] **T005**: Implement `From<CoinFeatures> for OutputFeatures` conversion helper
  - [ ] Define `CoinFeatures` struct with `lock_height`, `is_burned`, `nonce` fields
  - [ ] Conversion sets `asset_tag: None` by default (native coin implicit)
  - [ ] Document that `OutputFeatures` is the canonical stored form
  - git_commit()

- [ ] **T006**: Define `AssetError` enum (Review F-001)
  - [ ] Variants: `InvalidCommitment`, `ProofVerificationFailed`, `InvalidMetadata`, `BurnNotAllowed`, `InvalidClass`, `InvalidDecimals`, `InvalidAssetTag`
  - [ ] Implement `std::error::Error` and `Display` traits
  - [ ] Add conversion from crypto errors (`From<tari_crypto::errors::RangeProofError>`, etc.)
  - git_commit()
  - github_commit()

### Test Cases

- Unit test: `AssetClass` enum roundtrip serialization
- Unit test: `AssetTag` validation rejects invalid decimals for NFT/Void
- Unit test: `OutputFeatures` nonce uniqueness (statistical test with 10k samples)
- Unit test: `OutputMetadata` size limit enforcement (memo 256B, total 4KB)
- Unit test: `CoinFeatures` to `OutputFeatures` conversion preserves fields
- Unit test: `AssetError` display messages are clear and actionable (Review F-001)

### Verification Criteria

- All structures compile without warnings
- Canonical layout of `OutputFeatures` matches mermaid diagram in spec
- No `script` or `metadata` field present in `OutputFeatures`
- Documentation includes all invariants from spec sections 2.1-2.2
- All public functions return `Result<T, AssetError>` consistently (Review F-001)

## Phase 2: CoinOutput Implementation

### Phase Overview

> 👍🔔 **SUB-FEATURE-002** — Implement `CoinOutput` structure and methods for the native Z00Z coin, including Pedersen commitment, Bulletproof range proofs, and nullifier derivation.

This phase translates the base coin specification into working Rust code with proper cryptographic primitives from `tari_crypto`.

### Tasks

- [ ] **T007**: Define `CoinOutput` struct
  - [ ] Fields: `commitment: Commitment`, `range_proof: RangeProof`, `features: OutputFeatures`, `metadata: Option<OutputMetadata>`
  - [ ] Document that this is a Mimblewimble-style output for native coin
  - git_commit()

- [ ] **T008**: Implement `CoinOutput::new(amount, blinding, height, metadata) -> Result<Self, AssetError>`
  - [ ] Compute Pedersen commitment via `PedersenGens::default().commit_value(amount, blinding)`
  - [ ] Generate Bulletproof via `RangeProof::prove_single(...)`  with 64-bit range
  - [ ] Set `features.lock_height = Some(height)` or `None` as appropriate
  - [ ] Initialize `features.nonce = hash(PROTOCOL_SEED || random)` using `tari_crypto::hashing`
  - [ ] Apply metadata size checks before filling `metadata` field, return `AssetError::InvalidMetadata` on violation
  - git_commit()

- [ ] **T009**: Implement `CoinOutput::verify_proof(&self, bp_gens) -> Result<(), AssetError>`
  - [ ] Delegate to `RangeProof::verify_single` with provided `BulletproofGens`
  - [ ] Return `AssetError::ProofVerificationFailed` with context on failure
  - git_commit()

- [ ] **T010**: Implement `CoinOutput::commitment(&self) -> Commitment` accessor
  - [ ] Return the commitment for integration with UTXO set and validation
  - git_commit()

- [ ] **T011**: Implement nullifier derivation for `CoinOutput`
  - [ ] Function: `pub fn nullifier(&self) -> [u8; 32]`
  - [ ] Formula: `Hash(domain_nullifier || features.nonce || commitment || extra)`
  - [ ] Use consistent domain separation string `"z00z/nullifier/coin"`
  - [ ] Document that nonce uniqueness ensures nullifier uniqueness
  - git_commit()
  - github_commit()

### Test Cases

- Unit test: `CoinOutput::new` produces valid commitment and range proof
- Unit test: `CoinOutput::verify_proof` succeeds for honest proofs, fails for invalid with `AssetError::ProofVerificationFailed`
- Unit test: Nullifier uniqueness (generate 100 outputs, check all nullifiers distinct)
- Unit test: Metadata size limit enforcement in `new` constructor returns `AssetError::InvalidMetadata`
- Integration test: Create coin, serialize, deserialize, verify proof still passes

### Verification Criteria

- All `CoinOutput` methods compile and pass clippy
- Range proof verification uses correct `BulletproofGens` (64-bit range)
- Nullifier derivation is deterministic and uses proper domain separation
- Constructor enforces metadata size limits (4 KiB max)
- All methods use `AssetError` consistently (Review F-001)

## Phase 3: Deterministic Asset ID Derivation

### Phase Overview

> 👍🔔 **SUB-FEATURE-003** — Implement fully deterministic derivation of `AssetTag.id` and `TokenId` using blake2b256 with chain_id, version, class byte, and asset identifier.

This phase ensures that asset IDs are computed identically across all implementations and tied to the YAML asset definitions.

### Tasks

- [ ] **T012**: Define `TokenId` type alias
  - [ ] `pub type TokenId = [u8; 32];`
  - [ ] Document that `TokenId == AssetTag.id` for Token and NFT classes
  - git_commit()

- [ ] **T013**: Implement deterministic `AssetTag::derive_id` function
  - [ ] Parameters: `chain_id: [u8; 32]`, `version: u32`, `class: AssetClass`, `asset_id: &str`
  - [ ] Domain string: `"z00z/asset"`
  - [ ] Class byte mapping: Coin=0x01, Token=0x02, Nft=0x03, Void=0x04
  - [ ] Formula: `blake2b256(domain || chain_id || u32_be(version) || class_byte || asset_id.as_bytes())`
  - [ ] Return `[u8; 32]` as `AssetTag.id`
  - git_commit()

- [ ] **T014**: Define `Z00Z_NATIVE_COIN_ID` constant
  - [ ] Compute using `AssetTag::derive_id` with native coin parameters from YAML
  - [ ] Asset must have `kind: coin`, `usage.is_gas: true` in YAML
  - [ ] Make constant public: `pub const Z00Z_NATIVE_COIN_ID: [u8; 32] = ...`
  - git_commit()

- [ ] **T015**: Implement `AssetTag::from_yaml` helper for code generation
  - [ ] Parse YAML asset entry, extract `id`, `kind`, `class`, `decimals`, `version`
  - [ ] Call `derive_id` with extracted parameters
  - [ ] Return `AssetTag` struct with computed `id`, `class`, `decimals`
  - git_commit()

- [ ] **T016**: Add derivation tests for reference assets
  - [ ] Test native coin (`z00z`, Coin, decimals=8) derives consistent ID
  - [ ] Test token (`zusd`, Token, decimals=6) derives consistent ID
  - [ ] Test NFT (`ticket_nft`, Nft, decimals=0) derives consistent ID
  - [ ] Test void sink (`burn_sink`, Void, decimals=0) derives consistent ID
  - [ ] Ensure changing any input parameter changes the derived ID
  - git_commit()
  - github_commit()

### Test Cases

- Unit test: Derivation determinism (same inputs → same ID, 100 iterations)
- Unit test: Derivation uniqueness (different inputs → different IDs)
- Unit test: `Z00Z_NATIVE_COIN_ID` matches expected hardcoded value from spec
- Unit test: Class byte encoding (Coin=0x01, Token=0x02, Nft=0x03, Void=0x04)
- Property test: blake2b256 output is always 32 bytes

### Verification Criteria

- `AssetTag::derive_id` is pure function with no side effects
- Derivation uses correct domain string `"z00z/asset"`
- Native coin constant `Z00Z_NATIVE_COIN_ID` is publicly exposed
- All reference assets from YAML produce deterministic IDs

## Phase 4: Specialized Asset Outputs (Token, NFT, Void)

### Phase Overview

> 👍🔔 **SUB-FEATURE-004** — Implement `TokenOutput`, `NftOutput`, and `VoidOutput` structures following the same `OutputFeatures` canonical layout while introducing specialized fields.

This phase extends the asset model to fungible tokens, NFTs, and protocol sinks (void assets).

### Tasks

- [ ] **T017**: Define `TokenOutput` struct
  - [ ] Fields: `commitment: Commitment`, `range_proof: RangeProof`, `features: OutputFeatures`, `token_id: TokenId`, `metadata: Option<OutputMetadata>`
  - [ ] Invariant: `features.asset_tag.id == token_id` and `features.asset_tag.class == AssetClass::Token`
  - [ ] Document multi-asset support via multiple `TokenOutput`s with different `token_id`
  - git_commit()

- [ ] **T018**: Implement `TokenOutput::new(...) -> Result<Self, AssetError>`
  - [ ] Parameters: `amount: TokenAmount`, `token_id: TokenId`, `blinding: &BlindingFactor`, `features: OutputFeatures`, `metadata: Option<OutputMetadata>`
  - [ ] Compute commitment for token quantity (respect `AssetTag.decimals`)
  - [ ] Generate range proof for token supply range
  - [ ] Validate `features.asset_tag.id == token_id`, return `AssetError::InvalidAssetTag` on mismatch
  - git_commit()

- [ ] **T019**: Define `NftMetadata` struct
  - [ ] Fields: `name: Option<String>`, `description: Option<String>`, `media_uri: Option<String>`, `media_hash: Option<[u8; 32]>`, `attributes: Vec<(String, String)>`
  - [ ] Enforce size limits: max 32 attributes, max 256 bytes per string field
  - git_commit()

- [ ] **T020**: Define `NftOutput` struct
  - [ ] Fields: `commitment: Commitment`, `range_proof: Option<RangeProof>`, `features: OutputFeatures`, `token_id: TokenId`, `metadata: Option<NftMetadata>`
  - [ ] Invariant: For pure NFTs, committed amount = 1, `AssetTag.decimals = 0`, `class = AssetClass::Nft`
  - [ ] Document semi-fungible support (amount > 1 for series/tickets)
  - git_commit()

- [ ] **T021**: Define `VoidOutput` struct
  - [ ] Fields: `commitment: Commitment`, `is_void: bool`, `range_proof: Option<RangeProof>`, `features: OutputFeatures`
  - [ ] Invariant: `is_void == true`, never inserted into spendable UTXO set
  - [ ] Document use cases: burn, fee sink, slash sink
  - git_commit()
  - github_commit()

### Test Cases

- Unit test: `TokenOutput` validates `token_id == features.asset_tag.id`, returns `AssetError::InvalidAssetTag` on mismatch
- Unit test: `NftMetadata` rejects > 32 attributes or oversized strings
- Unit test: `NftOutput` with amount=1, decimals=0 passes validation
- Unit test: `VoidOutput` with `is_void=true` and `require_zero_proof=true` enforces zero range proof
- Integration test: Create token, NFT, void outputs and verify all commitments and proofs

### Verification Criteria

- All specialized output types reuse canonical `OutputFeatures`
- `TokenId == AssetTag.id` equality enforced in constructors
- NFT metadata respects YAML type system limits (section 9.2)
- Void outputs are marked non-spendable and excluded from UTXO set

## Phase 5: Offline Coin Records

### Phase Overview

> 👍🔔 **SUB-FEATURE-005** — Implement `OfflineCoinRecord` for offline coin handoff between wallets, with serialization, proof-of-possession, and slashing detection.

This phase enables offline payments by wrapping `CoinOutput` in a transferable record with ownership proofs.

### Tasks

- [ ] **T022**: Define `OfflineMeta` struct (Review F-003: add versioning)
  - [ ] Fields: `format_version: u32`, `origin_slot: u64`, `counter: u64`, `da_proof_placeholder: Option<Vec<u8>>`
  - [ ] Document usage: format_version for compatibility, origin slot for DA inclusion, counter for replay detection
  - git_commit()

- [ ] **T023**: Define `OfflineCoinRecord` struct
  - [ ] Fields: `output: CoinOutput`, `owner_pub: PublicKey`, `proof_of_possession: KernelSignature`, `slashed: bool`, `offline_metadata: Option<OfflineMeta>`
  - [ ] Document that `output` must be native coin (`AssetClass::Coin`)
  - git_commit()

- [ ] **T024**: Implement `OfflineCoinRecord::serialize_to_file` method (Review F-003: version header)
  - [ ] Write 4-byte version header (`format_version` from `OfflineMeta`)
  - [ ] Serialize record to binary format (bincode or custom encoding)
  - [ ] Write to file path or return bytes for QR encoding
  - [ ] Include integrity check (checksum or signature)
  - git_commit()

- [ ] **T025**: Implement `OfflineCoinRecord::deserialize_from_file` method (Review F-003: version check)
  - [ ] Read 4-byte version header, check against supported versions
  - [ ] Return `AssetError::UnsupportedVersion` if version mismatch
  - [ ] Read from file path or bytes
  - [ ] Validate integrity check
  - [ ] Return deserialized `OfflineCoinRecord`
  - git_commit()

- [ ] **T026**: Implement wallet handoff workflow documentation
  - [ ] Wallet A: create `OfflineCoinRecord` from on-chain `CoinOutput`, serialize to file/QR
  - [ ] Wallet B: deserialize, verify `!slashed && !in_spent_root`, store locally
  - [ ] Wallet B: when online, build `Transaction` to redeem coin, check DA inclusion
  - [ ] Document slashing: mark `slashed = true` on double-spend or invalid proof detection
  - git_commit()
  - github_commit()

### Test Cases

- Unit test: `OfflineCoinRecord` serialization roundtrip (serialize → deserialize → equal)
- Unit test: Slashed flag prevents redemption in wallet logic
- Unit test: Integrity check detects corrupted file/QR data
- Unit test: Version mismatch rejects deserialization with `AssetError::UnsupportedVersion` (Review F-003)
- Integration test: Full handoff flow (Wallet A export → Wallet B import → Wallet B redeem online)

### Verification Criteria

- `OfflineCoinRecord` works only with native coin (`AssetClass::Coin`)
- Serialization format is deterministic and versioned (Review F-003)
- Wallet behavior documented: local storage, slashing detection, online redemption
- Mermaid diagram from spec matches implementation flow

## Phase 6: Gas and Fee Calculation

### Phase Overview

> 👍🔔 **SUB-FEATURE-006** — Implement gas model with `GasAsset`, `GasSchedule`, `GasPrice`, and fee calculation formula tied to transaction shape.

This phase defines how transaction fees are computed and paid in native coin.

### Tasks

- [ ] **T027**: Define gas types
  - [ ] `pub type GasUnit = u64;`
  - [ ] `pub struct GasPrice { pub per_unit: Amount }`
  - [ ] Document that `Amount` is in native coin units
  - git_commit()

- [ ] **T028**: Define `GasSchedule` struct (Review F-002: placeholder constants)
  - [ ] Fields: `base_tx_cost: GasUnit`, `per_input_cost: GasUnit`, `per_output_cost: GasUnit`, `per_range_proof_bit_cost: GasUnit`
  - [ ] Document that this is a compile-time constant in v1 (no on-chain governance)
  - [ ] Define placeholder constants: `base_tx_cost=100`, `per_input=50`, `per_output=50`, `per_range_proof_bit=1`
  - [ ] Add FIXME comment: "TODO: Finalize gas schedule values pending economic model review"
  - git_commit()

- [ ] **T029**: Define `GasAsset` struct
  - [ ] Field: `base_asset_tag: AssetTag`
  - [ ] Invariant: `base_asset_tag.class == AssetClass::Coin` and `base_asset_tag.id == Z00Z_NATIVE_COIN_ID`
  - [ ] Document that there is exactly ONE `GasAsset` in v1, pointing to native coin
  - git_commit()

- [ ] **T030**: Implement fee calculation function
  - [ ] `pub fn calculate_fee(tx: &Transaction, schedule: &GasSchedule, price: &GasPrice) -> Amount`
  - [ ] Formula: `gas_used = base_tx_cost + per_input_cost * n_inputs + per_output_cost * n_outputs + per_range_proof_bit_cost * sum_proof_bits`
  - [ ] Return: `fee_in_coin = gas_used * price.per_unit`
  - [ ] Document that only native coin outputs may pay fees in v1
  - git_commit()

- [ ] **T031**: Add fee validation to transaction verification
  - [ ] Check that computed fee matches declared fee in transaction kernel
  - [ ] Ensure fee is covered by native coin outputs (`AssetClass::Coin`, `id == Z00Z_NATIVE_COIN_ID`)
  - [ ] Reject transactions paying fees with Token/NFT/Void outputs, return `AssetError::InvalidFeeAsset`
  - git_commit()
  - github_commit()

### Test Cases

- Unit test: Fee calculation for simple transaction (1 input, 1 output, 1 range proof) with placeholder constants
- Unit test: Fee calculation for complex transaction (5 inputs, 10 outputs, 15 range proofs)
- Unit test: Fee validation rejects mismatched fee (computed vs declared)
- Unit test: Fee validation rejects fee paid in non-native asset with `AssetError::InvalidFeeAsset`
- Property test: Fee is monotonic in transaction size (more inputs/outputs → higher fee)

### Verification Criteria

- `GasSchedule` is compile-time constant (hardcoded or const fn)
- `GasAsset` points only to native coin in v1
- Fee calculation deterministic and matches formula from spec section 7
- Mermaid gas flow diagram matches implementation
- Placeholder constants clearly marked for future finalization (Review F-002)

## Phase 7: YAML Asset Schema and Code Generation

### Phase Overview

> 👍🔔 **SUB-FEATURE-007** — Define YAML schema for asset definitions and implement code generator to produce Rust constants and validation templates.

This phase enables declarative asset configuration via YAML and automatic code generation.

### Tasks

- [ ] **T032**: Document YAML asset schema structure (section 9.1)
  - [ ] Top-level: `version: u32`, `assets: []`
  - [ ] Per-asset fields: `id`, `kind` (coin/token/nft/void), `symbol`, `name`, `description`, `decimals`, `class`
  - [ ] Commitment config: `range_bits`, `gens`
  - [ ] Usage flags: `is_gas`, `allow_burn`, `accepts_assets`, `require_zero_proof`
  - [ ] Policy fields: `mint_script_hash`, `max_supply`, `can_burn`, `max_per_series`, `unique_per_token_id`
  - [ ] Metadata schema: type system (string, bytes32, u64, uri, map<string,string>, nullable `?`)
  - git_commit()

- [ ] **T033**: Define YAML type system and size limits (section 9.2)
  - [ ] Primitive types: `string` (max 256 bytes UTF-8), `bytes32` (exactly 32 bytes), `u64`, `uri`
  - [ ] Composite types: `map<string,string>` (max 32 entries)
  - [ ] Nullable marker: trailing `?` (e.g., `string?`)
  - [ ] Total metadata size limit: 4 KiB per output
  - [ ] Document enforcement at YAML load time and runtime validation
  - git_commit()

- [ ] **T034**: Implement YAML parser and validator
  - [ ] Parse YAML file with `serde_yaml`
  - [ ] Validate schema: check all required fields present, types correct
  - [ ] Validate types: ensure metadata_schema uses only allowed types
  - [ ] Validate limits: check default values fit size constraints
  - [ ] Return validated `AssetDefinitions` struct or `AssetError::InvalidYaml`
  - git_commit()

- [ ] **T035**: Implement code generator for asset constants
  - [ ] For each asset: generate `pub const ASSET_<ID>_TAG: AssetTag`
  - [ ] Call `AssetTag::derive_id` with YAML parameters
  - [ ] For native coin (`is_gas: true`): generate `pub const Z00Z_NATIVE_COIN_ID: [u8; 32]`
  - [ ] For tokens: generate `TokenId` constant equal to `AssetTag.id`
  - [ ] Output as `assets_gen.rs` file
  - git_commit()

- [ ] **T036**: Implement code generator for validation templates
  - [ ] For NFTs: generate `NftMetadata` validation based on `metadata_schema`
  - [ ] For void assets: generate `VoidOutput` templates with `accepts_assets` and `require_zero_proof` config
  - [ ] For tokens: generate policy constraint checks (`max_supply`, `can_burn`)
  - [ ] Output as `assets_validation_gen.rs` file
  - git_commit()

- [ ] **T037**: Validate generated code compiles (Review F-004)
  - [ ] Run `cargo check` on `assets_gen.rs` and `assets_validation_gen.rs`
  - [ ] Fail build if warnings or errors present
  - [ ] Add CI job to enforce zero warnings policy on generated code
  - git_commit()
  - github_commit()

### Test Cases

- Unit test: YAML parser accepts valid asset definitions
- Unit test: YAML validator rejects invalid types or missing fields
- Unit test: YAML validator enforces size limits (string > 256 bytes, > 32 attributes)
- Unit test: Code generator produces valid Rust code (compile check via `cargo check`)
- Integration test: Load reference YAML, generate code, run `cargo test` on generated validation templates (Review F-004)

### Verification Criteria

- YAML schema matches spec section 9.1 exactly
- Type system and limits from section 9.2 enforced
- Code generator produces deterministic output (same YAML → same generated code)
- Generated constants include `Z00Z_NATIVE_COIN_ID` and all asset tags
- Generated code compiles without warnings (Review F-004)

## Phase 8: Asset Lifecycle Invariants and Burn Logic

### Phase Overview

> 👍🔔 **SUB-FEATURE-008** — Implement asset lifecycle invariants for burn semantics, void sink behavior, and supply accounting across all asset classes.

This phase enforces the truth table from spec section 10 and implements burn validation.

### Tasks

- [ ] **T038**: Implement `verify_features` validation function
  - [ ] Signature: `pub fn verify_features(output: &impl HasOutputFeatures, asset_def: &YamlAssetDef) -> Result<(), AssetError>`
  - [ ] Check: `output.features.asset_tag.class == asset_def.class`, return `AssetError::InvalidClass` on mismatch
  - [ ] Check: If `asset_def.usage.allow_burn == false`, then `output.features.is_burned == false`, return `AssetError::BurnNotAllowed` if violated
  - [ ] Check: For `VoidOutput`, `is_void == true` and `class == AssetClass::Void`
  - git_commit()

- [ ] **T039**: Implement truth table validation (section 10.1)
  - [ ] For each asset class (Coin, Token, NFT, Void) and flag combination (`allow_burn`, `is_burned`, `is_void`)
  - [ ] Enforce allowed/forbidden combinations from truth table
  - [ ] For "Yes\*" cases: defer to contextual burn validation (next task)
  - git_commit()

- [ ] **T040**: Implement contextual burn validation
  - [ ] When `output.features.is_burned == true` and `asset_def.usage.allow_burn == true`
  - [ ] Check: transaction reduces total supply in sanctioned way
  - [ ] Check: value routed into Void asset whose `usage.accepts_assets` includes this asset
  - [ ] Check: supply invariants upheld (minted - burned ≥ 0)
  - git_commit()

- [ ] **T041**: Implement void sink validation
  - [ ] For `VoidOutput` with `usage.accepts_assets` list
  - [ ] Check: burned asset ID is in `accepts_assets` or `accepts_assets == ["*"]`
  - [ ] Check: If `usage.require_zero_proof == true`, verify range proof proves amount = 0
  - [ ] Document: void outputs never inserted into spendable UTXO set
  - git_commit()

- [ ] **T042**: Add supply accounting tests
  - [ ] Test: Native coin burn reduces supply, tracked by indexers
  - [ ] Test: Token burn with `can_burn: true` decreases circulating supply
  - [ ] Test: NFT burn removes from circulation (if `allow_burn: true`)
  - [ ] Test: Void sink accepts multiple asset types (if `accepts_assets: ["*"]`)
  - git_commit()
  - github_commit()

### Test Cases

- Unit test: `verify_features` rejects mismatched class with `AssetError::InvalidClass`
- Unit test: `verify_features` rejects burn when `allow_burn == false` with `AssetError::BurnNotAllowed`
- Unit test: Truth table validation rejects forbidden flag combinations
- Unit test: Contextual burn validation accepts valid burn transaction
- Unit test: Void sink validation accepts asset in `accepts_assets` list
- Unit test: Void sink validation rejects asset not in `accepts_assets`
- Integration test: Full burn flow (coin → void sink → supply accounting)

### Verification Criteria

- Truth table from section 10.1 fully implemented
- All "No" cases rejected with descriptive `AssetError` variants
- All "Yes\*" cases trigger contextual burn validation
- Void sinks never in spendable UTXO set

## Phase 9: Documentation and Integration

### Phase Overview

Document all assets implementation details, update relevant files, and ensure integration with the rest of `z00z_core`.

### Tasks

- [ ] **T043**: Update `crates/z00z_core/assets/README.md`
  - [ ] Overview of asset model (Coin, Token, NFT, Void)
  - [ ] Canonical `OutputFeatures` layout and invariants
  - [ ] Deterministic asset ID derivation
  - [ ] YAML schema and code generation workflow
  - [ ] Offline coin records and wallet handoff
  - [ ] Gas model and fee calculation
  - git_commit()

- [ ] **T044**: Add mermaid diagrams to documentation (Review F-005: link to code)
  - [ ] Class diagram for asset structures (from spec) with doc comment links to `src/types.rs`
  - [ ] Offline coin handoff flow (from spec section 3) with links to `src/offline.rs`
  - [ ] Asset ID derivation flow (from spec section 2.2) with links to `src/derivation.rs`
  - [ ] Gas fee calculation flow (from spec section 7) with links to `src/gas.rs`
  - [ ] Add note in each diagram: "Verify correspondence with linked code modules during reviews"
  - git_commit()

- [ ] **T045**: Update `config/z00z-genesis.json` with native coin configuration
  - [ ] Include `Z00Z_NATIVE_COIN_ID` constant
  - [ ] Reference YAML asset definitions for genesis assets
  - git_commit()

- [ ] **T046**: Add examples to `crates/z00z_core/assets/examples/`
  - [ ] Example: Create and verify a `CoinOutput`
  - [ ] Example: Create a `TokenOutput` for a custom token
  - [ ] Example: Create an `NftOutput` with metadata
  - [ ] Example: Offline coin handoff (serialize, transfer, deserialize)
  - [ ] Example: Calculate transaction fee with `GasSchedule`
  - git_commit()

- [ ] **T047**: Implement transaction integration (Review F-007)
  - [ ] Add `Transaction::validate_outputs()` method to call `verify_features` for each output
  - [ ] Check balance constraints (inputs == outputs + fee)
  - [ ] Check burn constraints via `verify_features` and void sink rules
  - [ ] Integration test: Create transaction with multiple asset outputs (Coin, Token, NFT), validate end-to-end
  - [ ] Note: Depends on `z00z_core/tx` module completion
  - git_commit()

- [ ] **T048**: Run final verification and quality checks (Review F-006: coverage metrics)
  - [ ] Ensure all 👍🔔 markers from spec are addressed
  - [ ] Check that all methods have doc comments with examples
  - [ ] Verify `cargo doc --no-deps` builds without warnings
  - [ ] Run `cargo tarpaulin` or `cargo llvm-cov`, verify ≥80% line coverage for `assets` crate
  - [ ] Review code against Rust instructions (@rust.instructions)
  - [ ] Manual review: Check mermaid diagrams match code (Review F-005)
  - git_commit()
  - github_commit()

### Test Cases

- Documentation test: All code examples in README compile and run
- Documentation test: All doc comments include runnable examples (doctests)
- Integration test: Genesis configuration loads correctly with native coin
- Integration test: Transaction with multiple outputs validates successfully (Review F-007)
- Coverage test: ≥80% line coverage achieved (Review F-006)

### Verification Criteria

- README.md provides clear overview and links to detailed docs
- All mermaid diagrams from spec included in documentation with code links (Review F-005)
- Genesis config references correct `Z00Z_NATIVE_COIN_ID`
- Examples demonstrate all major asset operations
- Transaction integration complete with end-to-end validation (Review F-007)
- Test coverage meets ≥80% threshold (Review F-006)

## Task Dependencies

- **Phase 1**: T001 → T002 → T003 → T004 → T005 → T006 (Canonical Schema + Error Handling)
- **Phase 2**: T006 → T007 → T008 → T009 → T010 → T011 (CoinOutput Implementation)
- **Phase 3**: T002 → T012 → T013 → T014 → T015 → T016 (Asset ID Derivation)
- **Phase 4**: T003, T012 → T017 → T018; T003, T012 → T019 → T020; T003 → T021 (Specialized Outputs)
- **Phase 5**: T007 → T022 → T023 → T024 → T025 → T026 (Offline Coins)
- **Phase 6**: T004 → T027 → T028 → T029 → T030 → T031 (Gas Model)
- **Phase 7**: T013 → T032 → T033 → T034 → T035 → T036 → T037 (YAML + Code Gen)
- **Phase 8**: T003, T034 → T038 → T039 → T040 → T041 → T042 (Lifecycle Invariants)
- **Phase 9**: T042 → T043 → T044 → T045 → T046 → T047 → T048 (Documentation + Integration)

**Cross-Phase Dependencies**:
- T008, T009, T018 depend on T006 (AssetError)
- T038, T039, T040 depend on T006 (AssetError)
- T030, T031 depend on T014 (Z00Z_NATIVE_COIN_ID)
- T047 depends on all phases (Transaction integration)

## Assets Strategy

The assets implementation follows a layered strategy:

1. **Consensus Layer**: Canonical `OutputFeatures` and `AssetTag` structures shared across all asset types, deterministic ID derivation, and strict validation rules enforced via `AssetError`
2. **Asset Types**: Specialized outputs (Coin, Token, NFT, Void) reusing the canonical layout with minimal additional fields
3. **Cryptographic Primitives**: Pedersen commitments, Bulletproof range proofs, and nullifier derivation using `tari_crypto`
4. **Configuration**: YAML-driven asset definitions with code generation for constants and validation templates, including compile-time validation
5. **Offline Support**: `OfflineCoinRecord` wrapper for native coin with proof-of-possession, slashing detection, and versioned serialization format
6. **Economic Model**: Gas schedule, price, and fee calculation tied to transaction shape, paid only in native coin (v1), with placeholder constants pending finalization
7. **Lifecycle Management**: Burn semantics, void sinks, and supply accounting enforced via truth table and contextual validation
8. **Error Handling**: Unified `AssetError` enum with clear, actionable error messages and consistent usage across all public APIs
9. **Quality Assurance**: Test coverage ≥80%, generated code validation, documentation-to-code traceability via mermaid diagram links

## Relevant Files

- `crates/z00z_core/assets/src/lib.rs`: Public API facade
- `crates/z00z_core/assets/src/error.rs`: `AssetError` enum (Review F-001)
- `crates/z00z_core/assets/src/types.rs`: `AssetClass`, `AssetTag`, `OutputFeatures`, `OutputMetadata`
- `crates/z00z_core/assets/src/coins.rs`: `CoinOutput`, `CoinFeatures`, nullifier derivation
- `crates/z00z_core/assets/src/tokens.rs`: `TokenOutput`, `TokenId`
- `crates/z00z_core/assets/src/nfts.rs`: `NftOutput`, `NftMetadata`
- `crates/z00z_core/assets/src/void.rs`: `VoidOutput`, sink validation
- `crates/z00z_core/assets/src/gas.rs`: `GasAsset`, `GasSchedule`, `GasPrice`, fee calculation
- `crates/z00z_core/assets/src/offline.rs`: `OfflineCoinRecord`, `OfflineMeta`, versioned serialization
- `crates/z00z_core/assets/src/derivation.rs`: Asset ID derivation, `Z00Z_NATIVE_COIN_ID`
- `crates/z00z_core/assets/src/yaml.rs`: YAML parser, validator, code generator
- `crates/z00z_core/assets/src/validation.rs`: `verify_features`, truth table, burn logic
- `crates/z00z_core/assets/examples/`: Usage examples for all asset types
- `crates/z00z_core/assets/build.rs`: Code generation build script (Review F-004)
- `crates/z00z_core/tx/src/validation.rs`: Transaction integration (`validate_outputs`) (Review F-007)
- `config/z00z-genesis.json`: Genesis configuration with native coin
- `docs/001-TLD/**`: YAML templates and asset lifecycle documentation
