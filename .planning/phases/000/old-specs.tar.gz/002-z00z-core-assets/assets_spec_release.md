

------

## `crates/z00z_core/assets`

```mermaid
classDiagram
    class AssetClass {
        <<enum>>
        Coin
        Token
        Nft
        Void
    }

    class AssetTag {
        +[u8;32] id
        +AssetClass class
        +u8 decimals
    }

    class OutputFeatures {
        +Option<u64> lock_height
        +bool is_burned
        +[u8;32] nonce
        +Option<AssetTag> asset_tag
    }

    class OutputMetadata {
        +Option<String> memo
        +Option<[u8;32]> wallet_hint
        +Option<[u8;32]> app_tag
    }

    class CoinOutput {
        +Commitment commitment
        +RangeProof range_proof
        +OutputFeatures features
        +Option<OutputMetadata> metadata
    }

    class TokenOutput {
        +Commitment commitment
        +RangeProof range_proof
        +OutputFeatures features
        +TokenId token_id
        +Option<OutputMetadata> metadata
    }

    class NftOutput {
        +Commitment commitment
        +Option<RangeProof> range_proof
        +OutputFeatures features
        +TokenId token_id
        +Option<NftMetadata> metadata
    }

    class VoidOutput {
        +Commitment commitment
        +bool is_void
        +Option<RangeProof> range_proof
        +OutputFeatures features
    }

    class NftMetadata {
        +Option<String> name
        +Option<String> description
        +Option<String> media_uri
        +Option<[u8;32]> media_hash
        +Vec<(String,String)> attributes
    }

    CoinOutput --> OutputFeatures
    TokenOutput --> OutputFeatures
    NftOutput --> OutputFeatures
    VoidOutput --> OutputFeatures

    CoinOutput --> OutputMetadata
    TokenOutput --> OutputMetadata
    NftOutput --> NftMetadata
    VoidOutput ..> OutputMetadata : may use

    OutputFeatures --> AssetTag
    AssetTag --> AssetClass

```





This diagram shows the **canonical shape** of the asset-related outputs in `z00z_core`:

- All spendable outputs (`CoinOutput`, `TokenOutput`, `VoidOutput`) embed a common `OutputFeatures` struct and optional `OutputMetadata`.
- `OutputFeatures` is **consensus-critical** and has a single canonical layout: `{ lock_height, is_burned, nonce, asset_tag }`. 
- `OutputMetadata` is **non-consensus UX data** (wallet/app hints, memo).

> Script support per-output is explicitly out of scope for v1; there is no per-output script field in `OutputFeatures`. Scripts, if any, live at a different layer and must not affect the binary layout of `OutputFeatures`. 

------

1. **`coins.rs`**

   Define the structures and methods for the native Z00Z coin.

   - Structures:
     - `CoinOutput` (Mimblewimble-style output) containing:
       - `commitment: Commitment`
       - `range_proof: RangeProof`
       - `features: OutputFeatures`
       - `metadata: Option<OutputMetadata>` 
     - (Optional helper) `CoinFeatures` as a convenience wrapper with `lock_height`, `is_burned`, `nonce`; in the canonical encoding, these are stored inside `OutputFeatures` and `CoinFeatures` should be convertible to `OutputFeatures`.
   - Methods:
     - `pub fn new(amount: Amount, blinding: &BlindingFactor, height: u64, metadata: Option<Vec<u8>>) -> Result<Self>`:
       - computes the Pedersen commitment via `PedersenGens::default().commit_value(amount, blinding)`,
       - generates a single-output Bulletproof via `RangeProof::prove_single(...)`,
       - sets `features.lock_height = Some(height)` or `None`,
       - initializes `features.nonce = hash(PROTOCOL_SEED || random)` (using `tari_crypto::hashing`), 
       - fills `metadata` from the provided blob, if any (after size checks).
     - `pub fn verify_proof(&self, bp_gens: &BulletproofGens) -> Result<()>` delegating to `RangeProof::verify_single`.
     - `pub fn commitment(&self) -> Commitment` for integration with the UTXO set and validation.

2. **`tokens.rs`, `nfts.rs`, `void.rs`**

   - Document templates for fungible tokens, NFTs, and void/burn outputs (see `docs/001-TLD`, section 6.2.4). In particular:
     - `TokenOutput` includes `token_id`, `commitment` of the token amount, `range_proof`, and `owner` commitment implied by the transaction. 
     - NFT outputs rely on the same commitments but typically use `amount = 1` and a separate `NftMetadata` struct.
     - `VoidOutput` represents a burn sink flagged as `is_void = true` and may omit the range proof or use it to prove zero value, depending on the YAML configuration for the corresponding void asset.
   - See detailed type definitions in sections 4–6 below.

3. **Offline coin**

   - `pub struct OfflineCoinRecord { output: CoinOutput, owner_pub: PublicKey, proof_of_possession: KernelSignature, slashed: bool, offline_metadata: Option<OfflineMeta> }` where:
     - `output` is a canonical `CoinOutput`,
     - `owner_pub` binds the record to a public key,
     - `proof_of_possession` proves ownership (re-signing capability),
     - `slashed` indicates that a double-spend or violation has been observed
     - `offline_metadata` stores origin slot, counters, and DA inclusion proof placeholders required by FR-OFF-01..05 (re-signing, slashing, double-spend detection). 
   - Add a `serialize_to_file` helper to support offline handoffs between wallets:
     - Wallet A creates an `OfflineCoinRecord` from a fresh on-chain `CoinOutput`,
     - serializes it to a file or QR payload,
     - passes it to Wallet B while both parties may be offline.
   - Wallet behavior:
     - wallet stores `OfflineCoinRecord`s locally,
     - marks them `slashed = true` once a double spend or invalid proof is observed,
     - only assembles a `Transaction` to redeem the coin when connectivity returns or receipt proofs are refreshed.
   - Note that the wallet keeps `OfflineCoinRecord`s locally, marks them `slashed` once double spends are observed, and only assembles a `Transaction` when connectivity returns or receipt proofs are refreshed.



```mermaid
flowchart TD
    MINT["On-chain tx<br/>creates CoinOutput"]
    OCR["OfflineCoinRecord<br/>{ output, owner_pub,<br/>proof_of_possession,<br/>offline_metadata, slashed=false }"]
    W1["Wallet A (sender)"]
    W2["Wallet B (receiver)"]
    REDEEM["Redeem online tx<br/>(build Transaction)"]
    SLASH["On-chain check<br/>spent_root / slashed flag"]

    MINT -->|"export OfflineCoinRecord<br/>serialize_to_file()"| OCR
    OCR -->|"stored in"| W1
    W1 -->|"hand-off file / QR"| W2
    W2 -->|"local checks<br/>!slashed & !in spent_root"| OCR
    W2 -->|"when online"| REDEEM --> SLASH

```



------

## *👍🔔*2. Global asset model in `z00z_core/assets`

### 2.1. Shared types

**AssetClass**

```rust
pub enum AssetClass {
    Coin,  // native Z00Z coin (gas + value)
    Token, // arbitrary fungible token
    Nft,   // NFT / semi-fungible
    Void,  // protocol sinks (burn, fee-sink, slash, etc.)
}
```

**AssetTag**

`AssetTag` appears inside `OutputFeatures` and identifies the asset at the protocol level (similar to a Liquid Asset ID). 

```rust
pub struct AssetTag {
    pub id: [u8; 32],      // unique asset identifier (see derivation below)
    pub class: AssetClass, // Coin / Token / Nft / Void
    pub decimals: u8,      // number of decimal places (0 for NFT/Void)
}
```

**OutputFeatures (canonical layout)**

`OutputFeatures` is consensus-critical. There MUST be exactly one definition of this struct across `z00z_core` and all specs. We adopt the **minimal protocol layout** (Decision D1-A in the review): 

```rust
pub struct OutputFeatures {
    pub lock_height: Option<u64>, // do not spend before height H
    pub is_burned: bool,            // logical burn flag (subject to invariants)
    pub nonce: [u8; 32],          // base for nullifier derivation
    pub asset_tag: Option<AssetTag>, // protocol-level asset identifier
}
```

Notes:

- `nonce` is used in the nullifier derivation:
   `nullifier = Hash(nonce || commitment || extra_domain_name)`. 
- There is **no `script` field** and no `metadata` field in `OutputFeatures` in v1; UX data goes to `OutputMetadata`. Scripts (if any) will use a separate mechanism and must not modify this layout.
- Any previously mentioned `token_id_hint` is dropped at the protocol level to avoid conflicting definitions; wallets can derive hints from `AssetTag` and YAML.

**OutputMetadata (non-consensus UX data)**

```rust
pub struct OutputMetadata {
    pub memo: Option<String>,          // user-facing text
    pub wallet_hint: Option<[u8; 32]>, // hint for local wallet indexing
    pub app_tag: Option<[u8; 32]>,     // app-specific tag (dApp, contract, etc.)
}
```

This struct is **not part of consensus encoding** and may be truncated or ignored by minimal nodes, but its maximal size and shape are constrained by the YAML type system and limits (see section 9.2).

### 2.2. AssetTag & TokenId derivation (deterministic IDs)

The review identified that the way `AssetTag.id` and `TokenId` are derived must be **fully deterministic** and identical across implementations. 

We define:

```rust
pub type TokenId = [u8; 32];
```

**Canonical derivation algorithm**:

Let:

- `chain_id: [u8; 32]` — a fixed identifier of the chain/network (mainnet/testnet/**must** be specified elsewhere).
- For each YAML-defined asset `a`:
  - `a.kind ∈ {coin, token, nft, void}`,
  - `a.id` — short ASCII identifier from YAML (`z00z`, `zusd`, `ticket_nft`, `burn_sink`, ...),
  - top-level `version: u32` — the asset schema version (currently `1` in examples). 

We define:

```rust
asset_tag_domain = "z00z/asset"      // ASCII
class_byte(Coin)  = 0x01
class_byte(Token) = 0x02
class_byte(Nft)   = 0x03
class_byte(Void)  = 0x04

AssetTag.id = blake2b256(
    asset_tag_domain
    || chain_id
    || u32_be(version)
    || class_byte(a.class)
    || a.id.as_bytes()
)
```

- For assets of class `Token` and `Nft` we **also define**:

  ```rust
  TokenId = AssetTag.id
  ```

  i.e. the on-chain `TokenId` and protocol `AssetTag.id` are exactly the same bytes. 

- For the **native Coin**:

  - there MUST be exactly one YAML asset with `kind: coin` and `usage.is_gas: true`,

  - its `AssetTag.id` is derived via the same formula and the spec additionally defines:

    ```rust
    pub const Z00Z_NATIVE_COIN_ID: [u8; 32] = /* this computed value */;
    ```

- For **Void** assets:

  - each configured void sink (`burn_sink`, `fee_sink`, etc.) gets a unique `AssetTag.id` according to the same formula,
  - they are distinguished by `class = AssetClass::Void` and by their YAML `id`.

This ensures:

- a **single source of truth** for asset IDs,
- deterministic equality of `AssetTag.id` and `TokenId` for non-coin assets,
- a stable constant for the native coin used by GasAsset and other modules.

```mermaid
flowchart TD
    YAML["YAML asset entry
    {id, kind, class, decimals, version}"]
    CHAIN["chain_id
    (network identifier)"]
    DOMAIN["domain = \"z00z/asset\""]
    CLASSB["class_byte(class)
    01=Coin, 02=Token,
    03=Nft, 04=Void"]
    HASH["blake2b256(
    domain || chain_id ||
    version || class_byte || id )"]
    TAG["AssetTag {
    id, class, decimals }"]
    TID_CHECK{"class == Token or Nft?"}
    TID["TokenId = AssetTag.id"]

    YAML --> HASH
    CHAIN --> HASH
    DOMAIN --> HASH
    CLASSB --> HASH

    HASH --> TAG
    TAG --> TID_CHECK
    TID_CHECK -->|yes| TID
    TID_CHECK -->|no| TAG

```



------

## *👍🔔*3. `coins.rs` — base coin (CoinOutput)

### 3.1. Structures

```rust
pub struct CoinOutput {
    pub commitment: Commitment,
    pub range_proof: RangeProof,
    pub features: OutputFeatures,
    pub metadata: Option<OutputMetadata>,
}
```

An optional helper wrapper:

```rust
pub struct CoinFeatures {
    pub lock_height: Option<u64>,
    pub is_burned: bool,
    pub nonce: [u8; 32],
}

impl From<CoinFeatures> for OutputFeatures {
    fn from(cf: CoinFeatures) -> Self {
        OutputFeatures {
            lock_height: cf.lock_height,
            is_burned: cf.is_burned,
            nonce: cf.nonce,
            asset_tag: None, // native coin by default; may be set later
        }
    }
}
```

`CoinFeatures` is a convenience API; the **canonical stored form is `OutputFeatures`**.

### 3.2. Invariants

1. **Commitment**

   - `commitment = v·G + r·H`, where `v` is an `Amount` in the native coin and `r` is a `BlindingFactor`. 
   - All `CoinOutput` instances use the same generator set (`PedersenGens::default()`), otherwise cut-through and balance proofs break.

2. **Range proof**

   - `range_proof` proves that `0 ≤ v ≤ MAX_COINS` (e.g. 64-bit range), via bulletproofs.

3. **Nullifier**

   - The nullifier is derived from:

     ```text
     nullifier = Hash(domain_nullifier || features.nonce || commitment || extra)
     ```

   - `features.nonce` MUST be filled for every spendable output and MUST be unique enough (pseudo-random under protocol seed).

4. **AssetTag**

   - For the native coin:
     - `features.asset_tag` is either `None` (implicitly “base asset”) or explicitly set to `Some(AssetTag { id = Z00Z_NATIVE_COIN_ID, class = AssetClass::Coin, ... })` at genesis.
   - For non-native coins, `CoinOutput` SHOULD NOT be used; use `TokenOutput` instead.

### 3.3. Methods

As in the introductory section:

- `pub fn new(amount: Amount, blinding: &BlindingFactor, height: u64, metadata: Option<Vec<u8>>) -> Result<Self>`
- `pub fn verify_proof(&self, bp_gens: &BulletproofGens) -> Result<()>`
- `pub fn commitment(&self) -> Commitment`

All constructors must:

- initialize `features.nonce`,
- enforce any metadata size limits (see YAML type system),
- attach the appropriate `asset_tag` for the native coin where required (e.g. genesis).

------

## *👍🔔*4. `tokens.rs` — fungible tokens

We follow the UTXO-multi-asset pattern similar to Cardano / Ergo / Liquid: every token has an asset ID (`AssetTag.id` / `TokenId`) decoupled from the amount, while human-readable metadata is off-chain / wallet-side.  

### 4.1. Types

```rust
pub type TokenId = [u8; 32]; // exactly equal to AssetTag.id for Token/Nft

pub struct TokenOutput {
    pub commitment: Commitment,       // committed amount for this token
    pub range_proof: RangeProof,      // 0 <= v <= MAX_TOKEN_SUPPLY
    pub features: OutputFeatures,
    pub token_id: TokenId,            // identical to AssetTag.id for this asset
    pub metadata: Option<OutputMetadata>,
}
```

### 4.2. Semantics

- `commitment` binds the **token quantity** in units defined by `AssetTag.decimals`.
- `features.asset_tag` MUST be `Some(tag)` where `tag.id == token_id` and `tag.class == AssetClass::Token`.
- Multi-asset support is achieved by allowing a transaction to contain multiple `TokenOutput`s with different `token_id` / `asset_tag` values for different assets.

### 4.3. Methods (spec)

- `pub fn new(amount: TokenAmount, token_id: TokenId, blinding: &BlindingFactor, features: OutputFeatures, metadata: Option<OutputMetadata>) -> Result<Self>`
- `pub fn verify_proof(&self, bp_gens: &BulletproofGens) -> Result<()>`
- `pub fn asset_tag(&self) -> AssetTag`:
  - returns an `AssetTag` reconstructed from `token_id` and known decimals/class,
  - MUST be consistent with `features.asset_tag` if present.

------

## *👍🔔*5. `nfts.rs` — NFTs and semi-fungible tokens

We adopt the idea of NFT metadata structures inspired by Ergo (boxes with extra registers) and Tari’s NFT survey. 

### 5.1. Types

```rust
pub struct NftMetadata {
    pub name: Option<String>,
    pub description: Option<String>,
    pub media_uri: Option<String>,         // IPFS/HTTPS URI
    pub media_hash: Option<[u8; 32]>,      // blake2b256(content)
    pub attributes: Vec<(String, String)>, // arbitrary key-value pairs
}

pub struct NftOutput {
    pub commitment: Commitment,            // usually commit(1) or commit(0) + flag
    pub range_proof: Option<RangeProof>,   // can optionally prove amount = 1
    pub features: OutputFeatures,
    pub token_id: TokenId,                 // unique ID for this NFT asset
    pub metadata: Option<NftMetadata>,
}
```

### 5.2. Invariants

- For “pure” NFTs:
  - the committed amount MUST be 1,
  - `AssetTag.decimals = 0`,
  - `AssetTag.class = AssetClass::Nft`.
- For semi-fungible collections (e.g. tickets of the same type):
  - the committed amount MAY be greater than 1,
  - `class = AssetClass::Nft` and the YAML `policy` describes the per-series constraints (`max_per_series`, `unique_per_token_id`, etc.).

------

## *👍🔔*6. `void.rs` — burn / sink outputs

```rust
pub struct VoidOutput {
    pub commitment: Commitment,          // may be commit(0) or commit(v)
    pub is_void: bool,                   // MUST be true
    pub range_proof: Option<RangeProof>, // either prove v = 0 or omit proof
    pub features: OutputFeatures,        // may contain asset_tag for "which asset is burned"
}
```

Invariants:

- `is_void == true` → this output is **never inserted** into the spendable UTXO set.
- If the corresponding YAML void asset has `usage.require_zero_proof = true`, then:
  - `range_proof` MUST be present and MUST prove amount = 0.
- For supply auditing:
  - off-chain indexers may track how many units of each `AssetTag.id` are “sent into” void sinks and subtract them from circulation.

Void behavior, including which assets a void sink may accept and how it interacts with `is_burned`, is pinned down in the **asset lifecycle invariants** section (see §10). 

------

## *👍🔔*7. `gas.rs` — gas as an asset view

In the core spec, gas is represented via a `fee` in the transaction kernel. Here we define the abstractions that tie gas to a specific asset and schedule. 

```rust
pub type GasUnit = u64;

pub struct GasPrice {
    pub per_unit: Amount, // how many units of the native coin per GasUnit
}

pub struct GasSchedule {
    pub base_tx_cost: GasUnit,
    pub per_input_cost: GasUnit,
    pub per_output_cost: GasUnit,
    pub per_range_proof_bit_cost: GasUnit,
    // ... additional cost components as needed
}

pub struct GasAsset {
    pub base_asset_tag: AssetTag, // MUST be the native Coin asset
}
```

**v1 policy (per review):** 

- There is exactly **one** `GasAsset` in the system, pointing to the **native coin** (`AssetClass::Coin`, `id = Z00Z_NATIVE_COIN_ID`).

- `GasSchedule` is a **compile-time constant** in v1 (no on-chain governance yet). Future versions may move it on-chain, but that is explicitly out of scope for this iteration.

- The fee for a transaction is computed as:

  ```rust
  gas_used = base_tx_cost
           + per_input_cost * n_inputs
           + per_output_cost * n_outputs
           + per_range_proof_bit_cost * sum_proof_bits
           + ...
  fee_in_coin = gas_used * GasPrice.per_unit
  ```

- **Only outputs backed by the native Coin (AssetClass::Coin with `id = Z00Z_NATIVE_COIN_ID`) may be used to pay fees in v1.**
   Tokens, NFTs, and Void outputs MUST NOT be accepted as fee payment until a future multi-asset gas model is specified.

Validation:

- All validators must use the same `GasSchedule` and `GasPrice` to reach deterministic `fee_in_coin` for a given transaction shape.
- Balance validation MUST ensure that the fee paid in native coin exactly matches the fee computed from the gas schedule (within consensus rules).

```mermaid
flowchart TD
    TX["Transaction
    (inputs, outputs,
    range proofs, etc.)"]
    GS["GasSchedule
    { base_tx_cost,
    per_input_cost,
    per_output_cost,
    per_range_proof_bit_cost }"]
    GP["GasPrice
    { per_unit }"]
    COUNT["count n_inputs,
    n_outputs,
    sum_proof_bits"]
    GAS_USED["gas_used = base_tx_cost
    + per_input_cost * n_inputs
    + per_output_cost * n_outputs
    + per_range_proof_bit_cost * sum_proof_bits"]
    FEE["fee_in_coin = gas_used * per_unit"]
    GASASSET["GasAsset.base_asset_tag
    = native coin (Z00Z_NATIVE_COIN_ID)"]
    BAL["fee covered by
    Coin outputs
    (class=Coin, id=Z00Z_NATIVE_COIN_ID)"]
    VALID{"fee matches
    schedule & price?"}

    TX --> COUNT --> GAS_USED
    GS --> GAS_USED
    GP --> FEE
    GAS_USED --> FEE
    FEE --> BAL
    GASASSET --> BAL
    BAL --> VALID

```

  Implementation status (`crates/z00z_core/assets/src/gas.rs`):

  - `GasUnit`, `GasPrice`, and `GasSchedule` are defined with the compile-time placeholder constant `GAS_SCHEDULE_PLACEHOLDER = { base_tx_cost: 100, per_input_cost: 50, per_output_cost: 50, per_range_proof_bit_cost: 1 }` (guarded with a FIXME pending the economic review).
  - `GasAsset::new` enforces that gas is exclusively bound to the native coin by checking `AssetClass::Coin` and `Z00Z_NATIVE_COIN_ID`.
  - `GasUsage` plus the `GasMetered` trait project any transaction shape into `{n_inputs, n_outputs, sum_proof_bits}` so `calculate_fee` can deterministically evaluate `gas_used * GasPrice.per_unit`.
  - `validate_fee` compares the declared kernel fee with the computed value and ensures fee coverage uses only native-coin outputs, returning `AssetError::InvalidFee` / `AssetError::InvalidFeeAsset` on violations.



------

## *👍🔔*8. OfflineCoinRecord — tying assets to offline flows

```rust
pub struct OfflineCoinRecord {
    pub output: CoinOutput,
    pub owner_pub: PublicKey,
    pub proof_of_possession: KernelSignature,
    pub slashed: bool,
    pub offline_metadata: Option<OfflineMeta>,
}
```

`OfflineMeta` contains:

- `origin_slot` (e.g. `DaSlot` / `EpochIndex`),
- `counter` (for replay/double-spend detection),
- DA-proof placeholders to be extended when connectivity is restored.

Key points:

- `output` is a **native coin** `CoinOutput`:
  - `output.features.asset_tag.class == AssetClass::Coin`,
  - the YAML definition for this asset MUST have `usage.allow_offline = true`. 
- The wallet stores `OfflineCoinRecord`s locally and:
  - refuses to create them for assets with `allow_offline = false`,
  - marks them `slashed = true` when conflicts or malicious behavior are detected,
  - later converts them into normal online `Transaction`s when possible.

------

Here’s an updated **Section 9** and **Section 10** with `allow_offline` removed completely and the logic adjusted so offline usage is a protocol-wide default (not controlled by YAML flags).

You can paste these in place of the old §§9–10.

------

## *👍🔔*9. YAML schema for asset generation

Assets are specified in a YAML file. The YAML definitions are used by a code generator to:

- produce `AssetTag` / `TokenId` constants,
- default `OutputFeatures` templates,
- supply/policy constraints,
- configuration for void sinks and gas.

### 9.1. Overall structure

```yaml
version: 1

assets:
  - id: z00z               # internal ID
    kind: coin            # coin | token | nft | void
    symbol: Z00Z
    name: "Z00Z Native Coin"
    description: "Native confidential UTXO coin used as gas and value"
    decimals: 8
    class: Coin           # mirrors kind for convenience
    commitment:
      range_bits: 64      # Bulletproof range
      gens: "default"
    usage:
      is_gas: true        # this asset is used to pay gas/fees
      allow_burn: true    # supply may decrease via burn
    features_defaults:
      lock_height: null
      is_burned: false
    metadata_schema:
      memo: string?
      wallet_hint: bytes32?
      app_tag: bytes32?

  - id: zUSD
    kind: token
    symbol: zUSD
    name: "Z00Z USD stablecoin"
    decimals: 6
    class: Token
    policy:
      mint_script_hash: "0x..."   # off-chain / L2 policy identifier
      max_supply: null            # unlimited / capped
      can_burn: true
    commitment:
      range_bits: 64
    usage:
      allow_burn: true            # this token may be burned
    features_defaults:
      lock_height: null
      is_burned: false

  - id: ticket_nft
    kind: nft
    symbol: TICKET
    name: "Event Ticket"
    decimals: 0
    class: Nft
    policy:
      max_per_series: 10000
      unique_per_token_id: true
    commitment:
      range_bits: 0               # amount fixed to 1
    metadata_schema:
      name: string
      description: string?
      media_uri: uri?
      media_hash: bytes32?
      attributes: map<string,string>?

  - id: burn_sink
    kind: void
    name: "Protocol Burn Sink"
    class: Void
    usage:
      accepts_assets: ["*"]       # all assets
      require_zero_proof: true    # prove zero amount for inputs to this sink
```

### 9.2. Type system and size limits

- **Top-level contract** – `version: u32` plus `assets: []` where each entry follows the shape above. Every entry must declare `{ id, kind, class, symbol, name, description, decimals }`, `commitment.range_bits`, `usage` flags, and optional `policy`, `features_defaults`, and `metadata_schema` blocks.
- **Metadata types** – values under `metadata_schema` must come from the following primitive/composite set (nullable by appending `?`):

  | Type | Meaning | Limits |
  | ---- | ------- | ------ |
  | `string` | UTF-8 text | ≤256 bytes |
  | `bytes32` | Hex/base32 encoded 32-byte blob | exactly 32 bytes |
  | `u64` | Unsigned integer | native 64-bit |
  | `uri` | UTF-8 string interpreted as URI | ≤256 bytes |
  | `map<string,string>` | Attribute bag | ≤32 entries, each key max 64 bytes |

- **Nullable types** – suffix `?` marks a field optional; required fields must exist in every concrete metadata payload.
- **Budgeting** – at schema load time the parser sums conservative per-field allocations and ensures the total does not exceed the protocol-wide `4 KiB` metadata ceiling. Runtime validators enforce the exact limits against actual payloads (see §9.3).

### 9.3. Parser and code generation outputs

- `load_asset_schema_from_str` / `load_default_asset_schema` (in `assets/src/common.rs`) parse the YAML into an `AssetSchemaValidated` structure, applying identifier normalization, enforcing `is_gas`/`accepts_assets` invariants, and deriving the canonical `AssetTag` via `blake2b256`.
- `generate_asset_constants(validated)` emits deterministic Rust source containing:
  - `pub const ASSET_<ID>_TAG: AssetTag` for every asset,
  - `pub const TOKEN_<ID>_ID: TokenId` for Token/NFT classes,
  - `pub const Z00Z_NATIVE_COIN_ID: [u8; 32] = ASSET_<GAS>_TAG.id;` for the single gas asset.
- `generate_validation_templates(validated)` produces helper functions such as `validate_ticket_nft_metadata`, along with policy/void sink templates:
  - `TokenPolicy`/`NftPolicy` constants carrying `max_supply`, `can_burn`, `max_per_series`, `unique_per_token_id` flags.
  - `VoidSinkConfig` constants mirroring `accepts_assets`/`require_zero_proof` for every sink asset.
  - Field-level validators that enforce the YAML-declared metadata schema (string length, map entry caps, optional vs required fields).
  The generated file is intended to be written to `assets_validation_gen.rs` during the build.
- Tests under `crates/z00z_core/assets/src/common.rs` parse the YAML, run the generators, and use `syn::parse_file` to guarantee the emitted Rust compiles cleanly.



```mermaid
flowchart LR
    subgraph YAML["YAML file"]
        YVER["version: u32"]
        YASSET["assets[i]"]
        YUSAGE["usage{ is_gas, allow_burn, accepts_assets, require_zero_proof }"]
        YPOLICY["policy{ max_supply, can_burn,
        max_per_series, unique_per_token_id }"]
        YMETA["metadata_schema{ fields... }"]
        YCOMM["commitment{ range_bits, gens }"]
    end

    subgraph CODEGEN["Code generator"]
        PARSE["parse + validate types
        & limits"]
        DERIVE_ID["derive AssetTag.id
        (blake2b256)"]
        GEN_CONSTS["gen const ASSET_*_TAG"]
        GEN_TYPES["gen Rust templates
        (NftMetadata, Void templates, etc.)"]
    end

    subgraph RUST["Rust / z00z_core"]
        ATAG["AssetTag
        {id, class, decimals}"]
        GASID["Z00Z_NATIVE_COIN_ID"]
        TID["TokenId= AssetTag.id
        (for Token/Nft)"]
        NFTMETA["NftMetadata
        validation template"]
        VOIDCFG["Void sink config
        (accepts_assets, require_zero_proof)"]
    end

    YASSET --> PARSE
    YUSAGE --> PARSE
    YPOLICY --> PARSE
    YMETA --> PARSE
    YCOMM --> PARSE
    YVER --> PARSE

    PARSE --> DERIVE_ID --> GEN_CONSTS --> ATAG
    GEN_CONSTS --> GASID
    GEN_CONSTS --> TID
    GEN_TYPES --> NFTMETA
    GEN_TYPES --> VOIDCFG

```



Notes:

- There is **no `allow_offline` flag** in the schema. Offline representation is a first-class property of the protocol: any Coin/Token/NFT output may have an offline representation (e.g. via `OfflineCoinRecord` or a generalized offline record type). Whether an ecosystem *chooses* to use offline flows for a specific asset is treated as a higher-level policy, not a consensus flag.
- `usage.is_gas` is only meaningful for `kind: coin` and marks the single native gas asset.
- `usage.allow_burn` and `usage.accepts_assets` / `usage.require_zero_proof` control **supply/burn semantics** and void sinks, not offline behavior.

### 9.2. YAML type system and limits

We define a minimal type system for fields under `metadata_schema` and selected `policy` fields.

**Primitive types**

- `string` — UTF-8 string.
- `bytes32` — fixed 32-byte value (encoded as 64 hex characters in YAML).
- `u64` — 64-bit unsigned integer.
- `uri` — string with URI semantics (syntax checked only; semantics are out of consensus).

**Composite types**

- `map<string,string>` — map with string keys and string values.

A trailing `?` denotes **nullable**:

- `string?` → `string` or `null`,
- `bytes32?` → 32-byte value or `null`, etc.

**Size limits (consensus-relevant):**

- Maximum length of any `string` field: **256 bytes** (UTF-8 length).
- Maximum number of entries in `attributes: map<string,string>`: **32**.
- Maximum total encoded size of metadata per output (including keys and values): **4 KiB**.
- `bytes32` is always exactly 32 bytes.

**Enforcement:**

- At **YAML load / codegen time**:
  - the generator validates that schemas use only the allowed type names and that default values fit into limits,
  - invalid schemas cause code generation to fail and cannot be deployed.
- At **runtime (transaction validation)**:
  - nodes must reject outputs whose encoded metadata violates these size limits, even if the YAML would technically allow them,
  - numeric policy fields (e.g. `max_supply`, `max_per_series`) are checked for sane ranges and consistency.

### 9.3. Generation of Rust structures from YAML

The code generator (separate crate) performs:

- For each `assets[i]`:
  - generates `const ASSET_<ID>_TAG: AssetTag` with:
    - `id` derived by the canonical algorithm (`AssetTag.id = blake2b256("z00z/asset" || chain_id || version || class || id)`),
    - `class` taken from `class`,
    - `decimals`.
  - for `kind: coin`:
    - marks the single `is_gas: true` asset as the native gas asset,
    - exposes `Z00Z_NATIVE_COIN_ID` constant.
  - for `kind: token`:
    - sets `TokenId = AssetTag.id`,
    - attaches policy constraints (`max_supply`, `can_burn`) for validation.
  - for `kind: nft`:
    - prepares an `NftMetadata` validation template based on `metadata_schema`,
    - enforces `decimals = 0`.
  - for `kind: void`:
    - prepares default `VoidOutput` templates (e.g. `commitment = commit(0)` when `usage.require_zero_proof = true`),
    - exposes `accepts_assets` to the validation layer to decide which assets may be burned/slashed into this sink.

Offline representations (offline records, files, QR payloads) are **not driven by YAML flags**. Any Coin/Token/NFT output can be wrapped and circulated offline; YAML only defines how the on-chain asset behaves in terms of supply, gas and void interaction.

------

## 10. Asset lifecycle invariants (AssetClass / burn / Void / offline)

This section makes invariants around `AssetClass`, YAML `usage` flags, `Void` behavior, and burn semantics explicit and machine-checkable.

Offline usage is **orthogonal**: by design, any Coin/Token/NFT output may have an offline representation. These invariants talk about on-chain outputs and supply/burn rules, not about whether the asset is currently held offline or online.

### 10.1. Truth table for burn & void semantics

We consider per-asset YAML settings and per-output flags:

- `AssetClass ∈ { Coin, Token, Nft, Void }`
- `YAML.allow_burn` — from `usage.allow_burn` / `policy.can_burn` for that asset.
- `OutputFeatures.is_burned` — burn flag on the output.
- `VoidOutput.is_void` — special flag on void outputs (only meaningful when `AssetClass = Void`).

High-level truth table:

| AssetClass | YAML.allow_burn | OutputFeatures.is_burned | VoidOutput.is_void | Allowed? | Notes                                                        |
| ---------- | --------------- | ---------------------- | ------------------ | -------- | ------------------------------------------------------------ |
| Coin       | false           | false                  | false              | Yes      | Default spendable coin; no burn semantics.                   |
| Coin       | true            | false                  | false              | Yes      | Spendable coin; burn is possible via separate operations.    |
| Coin       | true            | true                   | false              | Yes*     | Coin burn only if the transaction routes value into a configured Void asset and respects policy. |
| Coin       | false           | true                   | any                | No       | Cannot mark burn if YAML/policy says this coin is non-burnable. |
| Token      | true            | true                   | false              | Yes*     | Token burn only if YAML policy allows it and supply invariants are enforced. |
| Token      | false           | true                   | any                | No       | Cannot mark burn if allow_burn = false.                      |
| Nft        | true            | true                   | false              | Yes*     | NFT burn by sending the NFT into a burn sink according to policy. |
| Nft        | false           | true                   | any                | No       | No burning if policy forbids; NFT must only move, not disappear. |
| Void       | n/a             | any                    | true               | Yes      | Void outputs are always sinks, never spendable UTXOs.        |

\* **“Yes\*”** means “allowed only under additional checks”:

- For any output with `OutputFeatures.is_burned = true`:
  - YAML for that asset must allow burning (`allow_burn = true` or `policy.can_burn = true`),
  - the transaction must route value into a compatible Void asset (a sink whose `usage.accepts_assets` includes this asset, or whose policy explicitly permits this burn),
  - supply invariants must be checked (total minted – total burned is consistent, and the burn does not exceed what exists).

Nice, let’s walk through the **new table** slowly and in plain English.

------

### What the table is actually checking

The table is about **one asset** and **one output** at a time.

It answers:

> “Given this asset’s YAML settings and these flags on the output,
>  is this combination allowed by the protocol?”

Columns:

- **AssetClass** – what type of asset this is:
  - `Coin` – native coin,
  - `Token` – fungible token,
  - `Nft` – non-fungible / semi-fungible,
  - `Void` – sink asset (burn / slash / fee).
- **YAML.allow_burn** – from YAML:
  - `true` → supply is allowed to decrease (burn),
  - `false` → protocol says “you must never reduce supply of this asset”.
- **OutputFeatures.is_burned** – flag on the *output*:
  - `true` → “this output participates in a burn operation”,
  - `false` → normal output.
- **VoidOutput.is_void** – only meaningful for `VoidOutput`:
  - `true` → this output is a sink, never a spendable UTXO.
- **Allowed?** – whether this combination is valid at all:
  - `Yes` → allowed,
  - `No` → forbidden; validator must reject,
  - `Yes*` → allowed **only with extra contextual checks**.

------

### Row-by-row explanation

### 🪙 Coin rows

#### 1) `Coin / allow_burn = false / is_burned = false / is_void = false → Yes`

- This is the **simplest coin**:
  - YAML says “you cannot burn this coin”,
  - the output does **not** claim to be a burn,
  - it’s a normal, spendable Coin output.

✅ Allowed: this is the default “just a coin” behavior.

------

#### 2) `Coin / allow_burn = true / is_burned = false / is_void = false → Yes`

- Coin **could** be burned in general (policy allows it),
- but this **particular** output is not a burn (flag is false),
- it’s just a standard spendable Coin.

✅ Also fully allowed: asset *supports* burn, but we are not burning here.

------

#### 3) `Coin / allow_burn = true / is_burned = true / is_void = false → Yes*`

- Coin can be burned (policy says OK),
- this output is flagged as burn (`is_burned = true`),
- it is not a Void output itself.

So we are trying to do a **burn operation** for a Coin.

`Yes*` means:

- this is **potentially valid**, but the validator must:
  1. Confirm that the asset is burnable (`allow_burn = true`),
  2. Check transaction context:
     - that value is being removed in a controlled way,
     - usually by sending it into a Void sink that accepts this asset,
  3. Ensure that supply accounting stays correct
      (minted - burned is sane, no negative or “magic extra” coins).

✅ Allowed, but only if the full burn logic and policy checks pass.

------

#### 4) `Coin / allow_burn = false / is_burned = true / any is_void → No`

- YAML says “this coin must not be burned”,
- output claims a burn (`is_burned = true`).

❌ Forbidden: validator must reject this combination.
 You cannot signal a burn when the asset’s policy explicitly says “no burns”.

------

### 🪪 Token rows

#### 5) `Token / allow_burn = true / is_burned = true / is_void = false → Yes*`

- Token is burnable (policy),
- this output is flagged as burn.

Again, `Yes*` means:

- allowed only if:
  - policy allows this type of burn (e.g. not exceeding `max_supply` logic),
  - and (depending on design) the burned value is routed into an appropriate Void sink or controlled mechanism.

✅ Token burn is allowed, but with the same kind of extra checks as for Coin.

------

#### 6) `Token / allow_burn = false / is_burned = true / any is_void → No`

- Token must *not* be burned,
- output tries to mark it as burn.

❌ Not allowed. Flag and policy contradict: validator rejects.

------

### 🎴 NFT rows

#### 7) `Nft / allow_burn = true / is_burned = true / is_void = false → Yes*`

- NFT can be burned (for example, you can “destroy” a ticket or artwork),
- this output is set as burn.

`Yes*` again:

- only valid if:
  - burning follows NFT’s policy (e.g. maybe only owner or issuer can burn; maybe only after some time),
  - and supply accounting per NFT/series is upheld.

✅ “Destroying” an NFT is OK, but only if policy and burn rules are obeyed.

------

#### 8) `Nft / allow_burn = false / is_burned = true / any is_void → No`

- Policy disables burning this NFT,
- output tries to flag burn.

❌ Forbidden. NFTs may only move between owners, not disappear, if `allow_burn = false`.

------

### 🕳️ Void row

#### 9) `Void / n/a / is_burned = any / is_void = true → Yes`

- This is a Void asset:
  - `is_void = true` means “this is a sink, not a normal UTXO”.
- For Void assets we **don’t care** about `allow_burn`:
  - they are *always* sinks,
  - never spendable UTXOs,
  - used for burns, slashing, protocol fees, etc.

✅ Always allowed (with the usual proof/range rules): any time you create a `VoidOutput` with `is_void = true` and correct class, it’s a sink.

------

###  “Yes*” really implies

Whenever you see **Yes\***:

> “This combination is structurally allowed,
>  but **you must still check transaction context and policy**.”

Concretely:

- For any output with `is_burned = true`:
  - asset policy must allow burn,
  - the transaction must actually **remove supply** in a sanctioned way
     (e.g. via a Void asset that accepts this asset),
  - supply and balance rules must remain consistent.

So the table is doing two things:

1. **First filter (structural)**:
    Is this combination of flags even meaningful for this asset class and YAML settings?
2. **Second filter (contextual, for Yes\*)**:
    In a real transaction, do we actually route value into sinks / obey policy / not break supply?

Offline vs online is not in the table anymore — any Coin/Token/Nft can live offline.
 The table only cares about **what is allowed to happen to supply on-chain**.



### 10.2. `verify_features()` rules (assets-level validation)

A helper function `verify_features(output: &impl HasOutputFeatures, asset_def: &YamlAssetDef) -> Result<()>` must enforce at least:

- `output.features.asset_tag.class == asset_def.class`.
- If `asset_def.usage.allow_burn == false`:
  - `output.features.is_burned` MUST be `false`.
- For `VoidOutput`:
  - `is_void == true`,
  - `output.features.asset_tag.class == AssetClass::Void`.

Additional checks for burn:

- If `output.features.is_burned == true` and `asset_def.usage.allow_burn == true`:
  - validation must ensure that:
    - the output participates in a transaction that reduces total supply in a way consistent with the asset’s burn policy,
    - and (for assets that require void sinks) that the value is delivered into a Void asset that lists this asset in `usage.accepts_assets`.

### 10.3. Void asset behavior

Given a Void asset `V` with YAML:

```yaml
kind: void
usage:
  accepts_assets: ["*", "z00z", "zusd"]
  require_zero_proof: true
```

We require:

- `VoidOutput.features.asset_tag` MUST point to `V` (class = `Void`).
- Any asset whose ID is in `accepts_assets`:
  - MAY be burned/slashed into this sink when its outputs are consumed by a transaction that creates a `VoidOutput` for `V` and sets `is_burned = true` on the affected inputs/outputs as specified by the protocol.
- If `usage.require_zero_proof == true`:
  - the `VoidOutput` MUST include a `range_proof` that proves amount = 0 for the void commitment (or satisfies whatever “zero-value” semantics are defined for that sink).

Void sinks are never inserted into the spendable UTXO set. They represent terminal endpoints for value (burn, protocol fees, slashing) and are only used in balance and supply accounting.

### 10.4. Offline representation and invariants

Offline representation (e.g. `OfflineCoinRecord` or a generalized offline record type) is deliberately **not** controlled by YAML flags:

- Any Coin/Token/NFT output **may** be wrapped into an offline record, handed over, and later redeemed on-chain.
- The invariants in this section apply to the on-chain outputs that appear when an offline record is eventually redeemed:
  - if the redeemed transaction burns value, it must still obey `allow_burn` and void sink rules;
  - if it does not burn value, it must respect the usual balance and range-proof checks.

From the protocol’s point of view, “offline vs online” is a question of *where the ownership data lived before the transaction*, not a different on-chain asset type.

------

## 11. What is added beyond the original core spec

This `assets` spec extends the original `z00z_core` document with the following elements (translated and refined from the draft summary): 

1. A concrete decomposition of the `assets` crate into:
   - shared types (`AssetClass`, `AssetTag`, `OutputFeatures`, `OutputMetadata`),
   - per-file modules (`coins.rs`, `tokens.rs`, `nfts.rs`, `void.rs`, `gas.rs`),
   - offline bridge structures (`OfflineCoinRecord`).
2. A canonical, minimal protocol layout for `OutputFeatures` shared across all specs and diagrams.
3. A deterministic derivation for `AssetTag.id` and `TokenId`, binding them to YAML asset definitions and `chain_id`.
4. A formal YAML type system (allowed types and nullable markers) and explicit size limits for metadata and attributes.
5. Explicit invariants for:
   - asset lifecycle across Coin/Token/Nft/Void,
   - burn semantics and void sinks,
   - offline support for native coin only in v1.
6. A clarified v1 gas policy:
   - single native GasAsset,
   - compile-time GasSchedule,
   - fee calculation formula tied to transaction shape.

These additions are intentionally scoped to the areas highlighted in the `review.md` and do not alter unrelated parts of the original document.
