# 5. Output Creation (Sender Workflow)

> ✅ **MODULE STATUS: Partial Implementation (Core Workflow Implemented, Sign-off Incomplete)**
>
> **Implemented (as of 2026-02-22):**
>
> - ✅ `PaymentRequest` → `z00z_wallets::core::address::stealth_request` (`stealth_request.rs`)
> - ✅ `ReceiverCard` → `z00z_wallets::core::address::stealth_card` (`stealth_card.rs`)
> - ✅ `build_tx_stealth_output()` → `z00z_wallets::core::stealth::output` (`output.rs`)
> - ✅ `build_tx_stealth_output_validated()` → validated sender path with request and pin checks in `z00z_wallets::core::stealth::output`
> - ✅ `generate_r_hedged()` (H-3) → `z00z_wallets::core::stealth::ephemeral` (`ephemeral.rs`)
> - ✅ `build_output_leaf()` / `build_output_with_blind()` → `z00z_wallets::core::tx::builder` (`builder.rs`)
> - ✅ `compute_leaf_ad()`, `compute_tag16()`, `compute_tag16_with_req()` → `z00z_wallets::core::stealth::tag` (`tag.rs`)
> - ✅ `AssetLeaf`, `AssetPackPlain` → `z00z_core::assets` (`leaf.rs`, `assets.rs`)
> - ✅ `create_commitment()`, `create_range_proof()` → `z00z_crypto`
> - ✅ `validate_output_self()` → `z00z_wallets::core::stealth::output_validator`
> - ✅ duplicate-R retry cache → implemented as `EphemeralCache` in `z00z_wallets::core::address::ephemeral_cache` and used by `SenderWallet`
> - ✅ request pinning / trust flow → implemented in `z00z_wallets::core::address::stealth_trust`
> - ✅ `z00z_utils` abstractions: `TimeProvider`, `RngProvider`, `codec`
>
> **Still not closed at spec sign-off level:**
>
> - ❌ the exact high-level `create_output()` convenience wrapper described later in this spec is not present under that API contract
> - ❌ many verification checklists below remain unreviewed and unchecked against live code, so this document is not yet a completed implementation sign-off
> - ❌ therefore this spec must not be treated as fully closed just because the core sender workflow is already present in code

**Formula:**

```text
leaf_ad = H_zk("Z00Z/LEAFAD" || asset_id || serial_id || R_pub || owner_tag || C_amount)
```

**Purpose:** Anti-malleability binding that prevents enc_pack rebinding attacks.

**Fields included (all 5 MUST be present):**

1. `asset_id` - Asset secret hash (prevents cross-asset rebinding)
2. `serial_id` - Version identifier (prevents version confusion)  
3. `R_pub` - Ephemeral public key (ensures uniqueness, prevents replay)
4. `owner_tag` - Receiver identifier (prevents owner rebinding)
5. `C_amount` - Pedersen commitment (prevents amount substitution)

**Implementation:** See detailed specification above starting at Section 4.7.1.

## 5.1 Sender Prerequisites

**Purpose:** Before creating an output, sender **MUST** obtain receiver's payment information and validate it to prevent burn/phishing attacks.

**Source:** `crates/Z00Z-ECC-IDEAS.md` lines 377-450 (PaymentRequest), lines 1008-1100 (ReceiverCard).

**Key Security Requirements:**

- ✅ **MUST** validate receiver's cryptographic material (view_pk) before use
- ✅ **MUST** verify identity binding (identity_pk signature) when available
- ✅ **MUST** reject expired payment requests
- ✅ **SHOULD** support both PaymentRequest (recommended) and ReceiverCard (fallback)

**Two input modes:**

| Mode               | Use Case                      | Security Model                                       |
| ------------------ | ----------------------------- | ---------------------------------------------------- |
| **PaymentRequest** | Invoice/request-based payment | Recommended, prevents DoS via tag16, includes expiry |
| **ReceiverCard**   | Offline/long-term payment     | Fallback, eternal card, requires sender trust        |

---

### 5.1.1 Inputs Required

**Overview:** Sender needs receiver's payment details in one of two formats:

1. **PaymentRequest_v1** (recommended) - Short-lived, request-specific, signed
2. **ReceiverCard_v1** (fallback) - Long-lived, eternal card, may be signed

Both formats provide the same core cryptographic material:

- `view_pk` - Receiver's view public key (for ECDH)
- `owner_handle` - Receiver's identifier (derived from receiver_secret)

**Additional data:**

- `identity_pk` - Long-term identity key (for signature verification, pinning)
- `req_id` - One-time request identifier (PaymentRequest only, prevents tag DoS)
- `expiry` - Request expiration time (PaymentRequest only)

---

### 👉🏾Phase 1 — PaymentRequest Type

#### 5.1.1.1 PaymentRequest_v1 (Recommended)

**Purpose:** Short-lived payment request with signature, expiry, and DoS protection.

**Source:** `crates/Z00Z-ECC-IDEAS.md` lines 377-420.

**Structure:**

```yaml
PaymentRequest_v1:
  version: 1                        # Protocol version (u8)
  owner_handle: bytes32             # H_zk("Z00Z/RID" || receiver_secret)
  identity_pk: bytes32              # Long-term identity PK (Z00Z Schnorr / Ristretto)
  view_pk: bytes32                  # View public key (CompressedRistretto, 32 bytes)
  req_id: bytes32                   # Random one-time request ID (prevents tag DoS)
  chain_id: u32                     # Chain identifier (prevents cross-chain replay); u32 LE4 on wire — NOT u64
  amount: Option<u64>               # Optional fixed payment amount
  expiry: u64                       # Unix timestamp (seconds since epoch)
  metadata: Option<RequestMetadata> # Optional: memo, payment_id, min_confirmations
  signature: bytes64                # Z00Z Schnorr: Sign(identity_sk, ctx=b"Z00Z/REQUEST_v1", canonical_fields)
```

**Type definition — IMPLEMENTED:**

> **File:** `crates/z00z_wallets/src/core/address/stealth_request.rs`
> **Public re-export:** `z00z_wallets::core::address::PaymentRequest`

```rust
// ✅ IMPLEMENTED — do not duplicate; import from z00z_wallets::core::address
use z00z_wallets::core::address::{PaymentRequest, PaymentRequestError, RequestMetadata, ValidityStatus};

/// Payment request (short-lived, signed with Z00Z Schnorr).
///
/// # Actual fields (as implemented):
// pub struct PaymentRequest {
//     pub version: u8,
//     pub owner_handle: [u8; 32],
//     pub view_pk: [u8; 32],        // CompressedRistretto bytes, NOT curve25519_dalek type
//     pub identity_pk: [u8; 32],
//     pub req_id: [u8; 32],
//     pub chain_id: u32,            // ← u32 (4 bytes), NOT u64 — confirmed in stealth_request.rs
//     pub amount: Option<u64>,
//     pub expiry: u64,
//     pub metadata: Option<RequestMetadata>,
//     pub signature: [u8; 64],      // Z00Z Schnorr (nonce[32] || s[32])
// }

// Key methods:
//   request.verify() -> Result<(), PaymentRequestError>
//       Verifies Z00Z Schnorr signature with context b"Z00Z/REQUEST_v1"
//   request.check_validity() -> ValidityStatus
//       Returns:
//         ValidityStatus::Valid(remain_secs: u64)         — valid; remain_secs until expiry
//         ValidityStatus::ExpiringSoon(remain_secs: u64)  — valid but expiring soon (threshold: implementation-defined)
//         ValidityStatus::Expired                         — past expiry timestamp
//       NOTE: ValidityStatus::NotYetValid does NOT exist — clock skew handled at network/infra level
//   request.sign(identity_sk: &Z00ZScalar) -> Result<(), PaymentRequestError>
//       Signs request using Z00Z Schnorr (called by receiver when creating request)
//   PaymentRequest::generate_req_id() -> Result<[u8; 32], PaymentRequestError>
//       Generates fresh random req_id using SystemRngProvider

// ⚠️ NOTE: No pow_difficulty field — PoW anti-spam is NOT implemented
// ⚠️ NOTE: Signature algorithm is Z00Z Schnorr, NOT Ed25519
// ⚠️ NOTE: view_pk type is [u8; 32], not curve25519_dalek::ristretto::CompressedRistretto
```

**Error type — `PaymentRequestError`** (in same file):

```rust
// Key variants:
//   PaymentRequestError::UnsupportedVersion
//   PaymentRequestError::InvalidRequestBytes
//   PaymentRequestError::RequestExpired
//   PaymentRequestError::InvalidSignature
//   PaymentRequestError::VerifyFailed
//   PaymentRequestError::InvalidPublicKey
//   PaymentRequestError::IdentityPoint
//   PaymentRequestError::WrongChainId
```

> 📌 **Additional types in `z00z_wallets::core::address` (same crate):**
>
> - `ValidatedRequest { req_id:[u8;32], amount:Option<u64>, owner_handle:[u8;32] }` — extracted fields after validation, passed to output creation
> - `ValidationOutcome { Approved | RequiresUserConfirmation | IdentityMismatch }` — result of full identity-pin validation
> - `trait ValidatePaymentRequest { fn validate_all(&self, pins: &mut PinnedReceiverCards, current_chain_id: u32) -> Result<ValidationOutcome, PaymentRequestError> }` — performs signature + chain_id + expiry + identity-pin check; ✅ IMPLEMENTED

---

#### ✅ Implementation Checklist — Phase 1: PaymentRequest Type

> **File:** `crates/z00z_wallets/src/core/address/stealth_request.rs`  
> **Status:** ✅ Already implemented — use this checklist to VERIFY correctness.

- [ ] **Struct `PaymentRequest`** — verify all fields are present with correct types:
  - [ ] `version: u8` — MUST equal 1; any other value → `UnsupportedVersion` error
  - [ ] `owner_handle: [u8; 32]` — derived as `h2s_zk::<WalletReceiverIdHashProdDomain>("RID", &[receiver_secret])`
  - [ ] `view_pk: [u8; 32]` — CompressedRistretto bytes; **NOT** `curve25519_dalek::CompressedRistretto` type
  - [ ] `identity_pk: [u8; 32]` — Z00Z Schnorr public key bytes
  - [ ] `req_id: [u8; 32]` — random, generated by `generate_req_id()`; reuse forbidden
  - [ ] `chain_id: u32` — 4-byte LE on wire; prevents cross-chain replay; **NOT** u64
  - [ ] `amount: Option<u64>` — optional fixed payment amount; None = any amount
  - [ ] `expiry: u64` — Unix timestamp seconds since epoch
  - [ ] `metadata: Option<RequestMetadata>` — optional memo, payment_id
  - [ ] `signature: [u8; 64]` — Z00Z Schnorr: nonce[32] ‖ s[32]
- [ ] **Enum `PaymentRequestError`** — verify variants exist:
  - [ ] `UnsupportedVersion`
  - [ ] `InvalidRequestBytes`
  - [ ] `RequestExpired`
  - [ ] `InvalidSignature` and `VerifyFailed`
  - [ ] `InvalidPublicKey` and `IdentityPoint`
  - [ ] `WrongChainId`
- [ ] **Enum `ValidityStatus`** — verify variants:
  - [ ] `Valid(remain_secs: u64)` — seconds remaining until expiry
  - [ ] `ExpiringSoon(remain_secs: u64)` — within threshold (e.g. 60 s)
  - [ ] `Expired` — current_time >= expiry
  - [ ] **NO** `NotYetValid` variant (clock skew handled at infra level)
- [ ] **Struct `ValidatedRequest`** — fields: `req_id: [u8;32]`, `amount: Option<u64>`, `owner_handle: [u8;32]`
- [ ] **Enum `ValidationOutcome`** — variants: `Approved`, `RequiresUserConfirmation`, `IdentityMismatch`
- [ ] **Method `generate_req_id() -> Result<[u8;32], PaymentRequestError>`**:
  - [ ] Uses `SystemRngProvider::default().rng()` from `z00z_utils::rng`
  - [ ] Fills 32 bytes; retries if all-zeros result
- [ ] **Method `sign(&mut self, identity_sk: &Z00ZScalar) -> Result<(), PaymentRequestError>`**:
  - [ ] Context bytes: `b"Z00Z/REQUEST_v1"` (Z00Z Schnorr signing)
  - [ ] Stores result in `self.signature: [u8; 64]`
- [ ] **Method `verify(&self) -> Result<(), PaymentRequestError>`**:
  - [ ] Decompresses `identity_pk` to Ristretto point
  - [ ] Rejects identity point → `InvalidPublicKey`
  - [ ] Verifies Z00Z Schnorr signature with context `b"Z00Z/REQUEST_v1"`
  - [ ] Returns `VerifyFailed` on signature mismatch
- [ ] **Method `check_validity(&self) -> ValidityStatus`**:
  - [ ] Uses `SystemTimeProvider::default().unix_timestamp()`
  - [ ] Add `check_validity_at(timestamp: u64) -> ValidityStatus` for deterministic tests
  - [ ] EXPIRY_SOON_THRESHOLD = 60 seconds (const)
- [ ] **Serialization `to_bytes(&self) -> Vec<u8>`**:
  - [ ] `chain_id` serialized as 4 bytes LE (NOT 8 bytes)
  - [ ] `amount: Option<u64>` — 1-byte presence flag + 8 bytes LE if Some
  - [ ] `metadata` — length-prefixed
  - [ ] Signature appended last
- [ ] **Deserialization `from_bytes(bytes: &[u8]) -> Result<Self, PaymentRequestError>`**:
  - [ ] Minimum length check before parsing
  - [ ] `from_untrusted_bytes()` — enforces MAX size limit
- [ ] **Trait `ValidatePaymentRequest`**:
  - [ ] Method `validate_all(&self, pins: &mut PinnedReceiverCards, current_chain_id: u32) -> Result<ValidationOutcome, PaymentRequestError>`
  - [ ] Calls: verify signature → check chain_id → check_validity → check identity pin
- [ ] **Unit tests** (all must pass):
  - [ ] `test_payment_request_round_trip` — `to_bytes` + `from_bytes` = same struct
  - [ ] `test_sign_then_verify_succeeds` — sign with correct key → verify Ok
  - [ ] `test_verify_wrong_key_fails` — different identity_sk → VerifyFailed
  - [ ] `test_expiry_at_threshold` — `check_validity_at(expiry)` → Expired
  - [ ] `test_expiry_1s_before` — `check_validity_at(expiry-1)` → ExpiringSoon
  - [ ] `test_expiry_far_future` — `check_validity_at(0)` → Valid
  - [ ] `test_wrong_chain_id` — wrong chain_id → WrongChainId in validate_all
  - [ ] `test_version_mismatch` — version != 1 → UnsupportedVersion

---

### 👉🏾Phase 2 — ReceiverCard Type

#### 5.1.1.2 ReceiverCard_v1 (Fallback)

**Purpose:** Long-lived receiver identifier ("eternal business card").

**Source:** `crates/Z00Z-ECC-IDEAS.md` lines 1008-1100.

**Use cases:**

- Offline payments (no request interaction)
- Long-term public identifiers (e.g., donation addresses)
- Fallback when PaymentRequest unavailable

**Security tradeoffs:**

- ❌ No expiry (eternal lifetime)
- ❌ No req_id (tag16 DoS possible without PaymentRequest)
- ✅ Always signed (signature is mandatory in current implementation)
- ✅ Simpler UX (no request creation needed)
- ✅ Works offline (no receiver interaction)

**Structure:**

```yaml
ReceiverCard_v1:
  version: 1                        # Protocol version (u8)
  owner_handle: bytes32             # H_zk("Z00Z/RID" || receiver_secret)
  view_pk: bytes32                  # CompressedRistretto bytes (32 bytes)
  identity_pk: bytes32              # Long-term identity PK (Z00Z Schnorr)
  card_id: Option<bytes16>          # Optional: UX label / checksum
  metadata: Option<CardMetadata>    # Optional: display_name, valid_until, contact
  signature: bytes64                # Z00Z Schnorr: Sign(identity_sk, ctx=b"Z00Z/CARD_v1")
```

**Type definition — IMPLEMENTED:**

> **File:** `crates/z00z_wallets/src/core/address/stealth_card.rs`
> **Public re-export:** `z00z_wallets::core::address::ReceiverCard`

```rust
// ✅ IMPLEMENTED — do not duplicate; import from z00z_wallets::core::address
use z00z_wallets::core::address::{ReceiverCard, ReceiverCardError, CardMetadata};

// Actual fields (as implemented):
// pub struct ReceiverCard {
//     pub version: u8,
//     pub owner_handle: [u8; 32],
//     pub view_pk: [u8; 32],        // CompressedRistretto bytes, NOT curve25519_dalek type
//     pub identity_pk: [u8; 32],
//     pub card_id: Option<[u8; 16]>,
//     pub metadata: Option<CardMetadata>,
//     pub signature: [u8; 64],      // Z00Z Schnorr (nonce[32] || s[32])
// }
//
// Key methods:
//   card.verify() -> Result<(), ReceiverCardError>
//       Verifies Z00Z Schnorr signature with context b"Z00Z/CARD_v1"
//   card.sign(identity_sk: &Z00ZScalar) -> Result<(), ReceiverCardError>
//       Signs card using Z00Z Schnorr (called by receiver when generating card)
//   ReceiverCard::new(keys: &ReceiverKeys, ...) -> Result<ReceiverCard, ReceiverCardError>
//       Creates and signs card from ReceiverKeys

// ⚠️ NOTE: There is NO separate unsigned ReceiverCard / ReceiverCardSigned split
//    The single ReceiverCard struct always carries signature field.
// ⚠️ NOTE: Signature algorithm is Z00Z Schnorr, NOT Ed25519
// ⚠️ NOTE: view_pk type is [u8; 32], not curve25519_dalek::ristretto::CompressedRistretto
//
// Parsing size constants (stealth_card.rs):
//   pub const MIN_CARD_SIZE: usize = 163; // 1+32+32+32+1+1+64 minimum wire bytes
//   pub const MAX_CARD_SIZE: usize = 4096; // hard limit for from_untrusted_bytes()
```

**Error type — `ReceiverCardError`** (in same file):

```rust
// Key variants:
//   ReceiverCardError::UnsupportedVersion
//   ReceiverCardError::InvalidCardBytes
//   ReceiverCardError::InvalidCardSize
//   ReceiverCardError::InvalidSignature / VerifyFailed
//   ReceiverCardError::InvalidPublicKey / IdentityPoint
//   ReceiverCardError::CardExpired / PinRevoked
```

---

#### ✅ Implementation Checklist — Phase 2: ReceiverCard Type

> **File:** `crates/z00z_wallets/src/core/address/stealth_card.rs`  
> **Status:** ✅ Already implemented — use this checklist to VERIFY correctness.

- [ ] **Struct `ReceiverCard`** — verify all fields:
  - [ ] `version: u8` — MUST equal 1
  - [ ] `owner_handle: [u8; 32]` — derived from receiver_secret
  - [ ] `view_pk: [u8; 32]` — CompressedRistretto bytes; **NOT** `curve25519_dalek` type
  - [ ] `identity_pk: [u8; 32]` — Z00Z Schnorr public key
  - [ ] `card_id: Option<[u8; 16]>` — optional UX label
  - [ ] `metadata: Option<CardMetadata>` — optional: display_name, valid_until, contact
  - [ ] `signature: [u8; 64]` — Z00Z Schnorr: nonce[32] ‖ s[32]
  - [ ] **NO** separate unsigned/signed struct split — single type always carries signature field
- [ ] **Constants** exist in file:
  - [ ] `pub const MIN_CARD_SIZE: usize = 163;`
  - [ ] `pub const MAX_CARD_SIZE: usize = 4096;`
- [ ] **Enum `ReceiverCardError`** — verify variants:
  - [ ] `UnsupportedVersion`
  - [ ] `InvalidCardBytes`
  - [ ] `InvalidCardSize`
  - [ ] `InvalidSignature` and `VerifyFailed`
  - [ ] `InvalidPublicKey` and `IdentityPoint`
  - [ ] `CardExpired` and `PinRevoked`
- [ ] **Struct `ReceiverKeys`** — provides key material for card creation:
  - [ ] Fields: `view_sk`, `view_pk`, `identity_sk`, `identity_pk`, `owner_handle` (exact types per codebase)
- [ ] **Method `ReceiverKeys::from_receiver_secret(secret: ReceiverSecret) -> Result<ReceiverKeys, ReceiverCardError>`**:
  - [ ] Derives all key material deterministically from `ReceiverSecret`
  - [ ] `owner_handle = h2s_zk::<WalletReceiverIdHashProdDomain>("RID", &[secret.as_bytes()])`
- [ ] **Method `ReceiverCard::new(keys: &ReceiverKeys, card_id: Option<[u8;16]>, metadata: Option<CardMetadata>) -> Result<ReceiverCard, ReceiverCardError>`**:
  - [ ] Populates all fields from keys
  - [ ] Calls `self.sign(&keys.identity_sk)` internally
- [ ] **Method `sign(&mut self, identity_sk: &Z00ZScalar) -> Result<(), ReceiverCardError>`**:
  - [ ] Z00Z Schnorr with context `b"Z00Z/CARD_v1"`
  - [ ] Stores signature in `self.signature`
- [ ] **Method `verify(&self) -> Result<(), ReceiverCardError>`**:
  - [ ] Decompresses `identity_pk`; rejects identity point → `InvalidPublicKey`
  - [ ] Verifies Z00Z Schnorr with context `b"Z00Z/CARD_v1"`
- [ ] **Serialization `to_bytes()`** — canonical format, version byte first
- [ ] **Deserialization `from_bytes()` and `from_untrusted_bytes()`**:
  - [ ] `from_untrusted_bytes()` rejects `len > MAX_CARD_SIZE` and `len < MIN_CARD_SIZE`
- [ ] **Unit tests** (all must pass):
  - [ ] `test_receiver_card_round_trip` — create, serialize, deserialize, fields match
  - [ ] `test_card_sign_verify_ok` — card.verify() succeeds after card.sign()
  - [ ] `test_card_verify_wrong_key` — different identity_sk → VerifyFailed
  - [ ] `test_card_oversized_rejected` — bytes > MAX_CARD_SIZE → InvalidCardSize
  - [ ] `test_card_view_pk_valid_point` — `Z00ZRistrettoPoint::from_canonical_bytes(&card.view_pk)` succeeds
  - [ ] `test_receiver_keys_deterministic` — same secret → same keys (idempotent)

---

### 👉🏾Phase 3 — Input Validation & Signature Verification

### 5.1.2 Input Validation

**Purpose:** Validate receiver's payment information before output creation to prevent burn/phishing attacks.

**Validation checklist:**

| Check | PaymentRequest | ReceiverCard | Priority |
| --- | --- | --- | --- |
| Signature verification | ✅ MUST | ✅ MUST (always signed) | P0 |
| Expiry check | ✅ MUST | N/A (no expiry) | P0 |
| view_pk validation | ✅ MUST | ✅ MUST | P0 |
| Identity pinning | ⚠️ SHOULD | ⚠️ SHOULD | P1 |

> ⚠️ PoW anti-spam (`pow_difficulty`) is **NOT implemented** — removed from scope.

---

#### 5.1.2.1 Signature Verification

**Purpose:** Prevent burn/phishing by verifying receiver's identity signature.

**IMPLEMENTED — use actual API:**

```rust
// ✅ Validate PaymentRequest (signature + expiry):
// ⚠️ NOTE: chain_id is cryptographically bound INTO the signature (request.verify()
//    ensures the signature covers chain_id bytes), but build_tx_stealth_output does NOT
//    independently validate request.chain_id against the current network chain_id.
//    Use ValidatePaymentRequest::validate(current_chain_id) if explicit cross-chain
//    check is required (separate trait, not called here).
//
// ⚠️ CHAIN_ID CALLER CONTRACT: build_tx_stealth_output() does NOT verify chain_id.
// chain_id is cryptographically bound inside the signature (request.verify() ensures
// the signature covers chain_id bytes), but this does NOT reject a request from another
// chain if both chains use the same key material.
//
// Cross-chain replay protection requires an EXPLICIT check BEFORE calling
// build_tx_stealth_output(). ✅ IMPLEMENTED — use the ValidatePaymentRequest trait:
//
//   use z00z_wallets::core::address::{ValidatePaymentRequest, ValidationOutcome};
//   match request.validate_all(&mut pinned_cards, current_chain_id)? {
//       ValidationOutcome::Approved => { /* proceed */ }
//       ValidationOutcome::RequiresUserConfirmation => { /* prompt user */ }
//       ValidationOutcome::IdentityMismatch => { /* warn, possibly abort */ }
//   }
//   // Now safe to call build_tx_stealth_output()
//
// PaymentRequests that skip validate_all() can be replayed cross-chain without error.
// StealthError::WrongChainId is NOT returned by build_tx_stealth_output() — only by
// validate_all() (via PaymentRequestError::WrongChainId).
use z00z_wallets::core::address::{PaymentRequest, ValidityStatus};

// 1. Verify Z00Z Schnorr signature:
request.verify()?;  // returns Err(PaymentRequestError::VerifyFailed) on failure

// 2. Check expiry / validity:
match request.check_validity() {
    ValidityStatus::Valid(_remain) => {}                          // fully valid
    ValidityStatus::ExpiringSoon(remain) => {                     // valid but warn sender
        // Optional: warn that request has only `remain` seconds left
        // Decide per UX policy whether to proceed or abort
    }
    ValidityStatus::Expired => return Err(/* payment expired */),
    // ⚠️ ValidityStatus::NotYetValid does NOT exist in codebase — remove if seen in old code
}

// ✅ Validate ReceiverCard (signature):
use z00z_wallets::core::address::ReceiverCard;
card.verify()?;  // returns Err(ReceiverCardError::VerifyFailed) on failure

// ⚠️ CALLER CONTRACT — build_tx_stealth_output() does NOT call card.verify() internally.
// The caller MUST call card.verify() (or ValidateReceiverCard::validate_signature())
// BEFORE passing a ReceiverCard to build_tx_stealth_output().
// A card with an invalid or zero signature will be accepted silently — there is no
// internal check. Passing a forged or unsigned card leads to a spendable-looking
// output that the alleged receiver cannot claim (owner_tag computed from wrong keys).

// Both types: validate_request_bind() is called internally by build_tx_stealth_output()
// to cross-check that PaymentRequest fields match ReceiverCard before creating output.
//
// DEPRECATED/REMOVED:
// - validate_payment_input() function — does not exist
// - PaymentInput / ValidatedPaymentInput enums — do not exist
// - ReceiverCardSigned separate type — does not exist (ReceiverCard always has signature)
// - verify_signature() method — does not exist (use verify())


---

// Legacy spec had a `validate_payment_input()` function with PaymentInput enum —
// this was NEVER implemented. The actual flow is:
//   1. Parse: PaymentRequest::from_bytes() / ReceiverCard::from_bytes()
//   2. Verify: request.verify() / card.verify()
//   3. Check expiry: request.check_validity()
//   4. Pass to: build_tx_stealth_output(card, Some(request), ...)


// TODO NOTE: High-level validate_payment_input() wrapper for §5.1.2 logic
//   not yet implemented — validate_request_bind() (internal, in output.rs) covers
//   cross-checks at output creation time but not up-front standalone validation.
```

---

> **NOTE on `validate_payment_input()` from legacy spec:**  
> This function does NOT exist. The validation is performed inline by `build_tx_stealth_output()` via `validate_request_bind()` (internal, not public). If you need a standalone pre-validation utility, it can be added as `z00z_wallets::core::stealth::validate_receiver_input(card, request, current_time) -> Result<(), StealthError>`.

---

---

#### ✅ Implementation Checklist — Phase 3: Input Validation & Signature Verification

> **Files:** `crates/z00z_wallets/src/core/address/stealth_card.rs`,
> `crates/z00z_wallets/src/core/address/stealth_request.rs`  
> **Status:** ❌ Partially done — signature verify exists; view_pk validation must be confirmed.

- [ ] **view_pk validation procedure** (MUST be called before any ECDH):
  - [ ] Decompress `view_pk: [u8;32]` using `Z00ZRistrettoPoint::from_canonical_bytes(&view_pk)`
  - [ ] Reject if decompression fails → `InvalidPublicKey`
  - [ ] Reject if result is identity point (`.is_identity()`) → `IdentityPoint`
  - [ ] Verify canonical encoding: re-compress the point and compare with original bytes → `InvalidPublicKey` if mismatch
  - [ ] Same procedure for both `ReceiverCard.view_pk` and `PaymentRequest.view_pk`
- [ ] **Caller responsibility for ReceiverCard before `build_tx_stealth_output()`** (NOT done inside the function):
  - [ ] Call `receiver_card.verify()` → propagate `ReceiverCardError` on failure
  - [ ] Call view_pk validation procedure above
  - [ ] Reject card on any failure — do NOT proceed to output creation
- [ ] **Caller responsibility for PaymentRequest** (before `build_tx_stealth_output()`):
  - [ ] Call `payment_request.verify()` → propagate `PaymentRequestError` on failure
  - [ ] Call view_pk validation procedure above
  - [ ] Reject request on any failure
- [ ] **`identity_pk` format check** (SHOULD):
  - [ ] Verify `identity_pk: [u8;32]` can be interpreted as valid Z00Z Schnorr public key
  - [ ] Used only for signature verification — not for ECDH
- [ ] **Implement `PinnedReceiverCards` struct** (new type, no existing implementation):
  - [ ] File: `crates/z00z_wallets/src/core/address/pinned_cards.rs` (new)
  - [ ] Add `pub mod pinned_cards;` to `z00z_wallets/src/core/address/mod.rs`
  - [ ] Field: `pins: HashMap<[u8;32], [u8;32]>` — owner_handle → identity_pk
  - [ ] Method `pin(&mut self, owner_handle: [u8;32], identity_pk: [u8;32])`
  - [ ] Method `revoke(&mut self, owner_handle: &[u8;32])`
  - [ ] Method `check(&self, owner_handle: &[u8;32], identity_pk: &[u8;32]) -> PinCheckResult`
  - [ ] Enum `PinCheckResult { Matches, Mismatch, NotPinned }`
- [ ] **Unit tests** (all must pass):
  - [ ] `test_view_pk_valid_accepted` — valid Ristretto point bytes → Ok from validation
  - [ ] `test_view_pk_invalid_bytes_rejected` — garbage bytes → InvalidPublicKey
  - [ ] `test_view_pk_identity_point_rejected` — identity point bytes → IdentityPoint
  - [ ] `test_view_pk_non_canonical_rejected` — non-canonical encoding → InvalidPublicKey
  - [ ] `test_card_signature_wrong_key_rejected` — verify() with tampered identity_pk → VerifyFailed
  - [ ] `test_pinned_cards_check_matches` — pinned key → Matches
  - [ ] `test_pinned_cards_check_mismatch` — different key → Mismatch
  - [ ] `test_pinned_cards_check_not_pinned` — unknown owner_handle → NotPinned

---

### 👉🏾Phase 4 — Expiry Check

#### 5.1.2.2 Expiry Check

**Purpose:** Enforce time limits on PaymentRequest to prevent replay attacks.

**IMPLEMENTED — actual method:** `request.check_validity() -> ValidityStatus`  

> ⚠️ Old spec referenced `check_expiry(current_time)` which does NOT exist.  
> Use `check_validity()` — it uses `SystemTimeProvider` internally.

> ⚠️ **Testability Note:** `check_validity()` uses `SystemTimeProvider` internally with no
> injectable time override. For deterministic expiry tests, a time-parameterized overload
> is needed:  
> `// TODO: add PaymentRequest::check_validity_at(timestamp: u64) -> ValidityStatus`  
> `// for deterministic unit testing without mocking SystemTimeProvider.`

**Recommended expiry lifetimes:**

| Use Case          | Recommended Lifetime   | Rationale                                |
| ----------------- | ---------------------- | ---------------------------------------- |
| Point-of-sale     | 5-15 minutes           | Short interaction, high security         |
| Invoice payment   | 1-24 hours             | Batch processing, moderate security      |
| Recurring payment | N/A (use ReceiverCard) | Long-term relationship, identity pinning |

**Security note:** Expiry does NOT prevent receiver from claiming funds after expiry (blockchain state is append-only). Expiry only limits sender's ability to create NEW outputs using old request.

---

#### ✅ Implementation Checklist — Phase 4: Expiry Check

> **File:** `crates/z00z_wallets/src/core/address/stealth_request.rs`  
> **Status:** ❌ Partially done — `check_validity()` exists; `EXPIRY_SOON_THRESHOLD` and `check_validity_at()` must be confirmed.

- [ ] **Constant `EXPIRY_SOON_THRESHOLD: u64 = 60`** defined at module level (seconds)
- [ ] **`PaymentRequest::check_validity(&self) -> ValidityStatus`**:
  - [ ] Gets current time via `z00z_utils::time::SystemTimeProvider::default().unix_timestamp()`
  - [ ] Delegates to `check_validity_at(now)`
  - [ ] NO direct `std::time::SystemTime` usage in `z00z_core`
- [ ] **`PaymentRequest::check_validity_at(t: u64) -> ValidityStatus`**:
  - [ ] `t >= self.expiry` → `ValidityStatus::Expired`
  - [ ] `self.expiry - t <= EXPIRY_SOON_THRESHOLD` → `ValidityStatus::ExpiringSoon(self.expiry - t)`
  - [ ] Otherwise → `ValidityStatus::Valid(self.expiry - t)`
- [ ] **`ReceiverCard`** version if card has `valid_until` in metadata:
  - [ ] `CardMetadata::valid_until: Option<u64>` field
  - [ ] If `valid_until.is_none()` → card never expires
  - [ ] Method `check_card_validity_at(&self, t: u64) -> ValidityStatus` using same logic
- [ ] **Integration with `validate_all()`** in `ValidatePaymentRequest` trait:
  - [ ] `check_validity()` returns Expired → `RequestExpired` error from validate_all
  - [ ] `check_validity()` returns ExpiringSoon → propagated as `RequiresUserConfirmation`
  - [ ] `check_validity()` returns Valid → proceed
- [ ] **Unit tests** (all must pass, using `check_validity_at`):
  - [ ] `test_expiry_exact_boundary` — `check_validity_at(expiry)` → `Expired`
  - [ ] `test_expiry_one_second_before` — `check_validity_at(expiry - 1)` → `ExpiringSoon(1)`
  - [ ] `test_expiry_at_threshold` — `check_validity_at(expiry - EXPIRY_SOON_THRESHOLD)` → `ExpiringSoon(60)`
  - [ ] `test_expiry_threshold_plus_one` — `check_validity_at(expiry - 61)` → `Valid(61)`
  - [ ] `test_expiry_far_future` — `check_validity_at(0)` with `expiry = 9999999999` → `Valid(...)`
  - [ ] `test_validate_all_expired_request` — `validate_all()` with expired request → `Err(RequestExpired)`

---

### 👉🏾Phase 5 — Identity Pinning & Validation Workflow

#### 5.1.2.3 Identity Pinning

**Purpose:** Bind owner_handle to known identity_pk to prevent impersonation.

**Status:** ⚠️ NOT YET IMPLEMENTED as standalone API.

> See `z00z_wallets::core::address::stealth_trust` (`stealth_trust.rs`) — partially implemented:
>
> - `PinnedReceiverCards` — stores pinned cards by owner_handle
> - `PinCheckResult::Pinned | PinCheckResult::New | PinCheckResult::Revoked`
> - Used inside PaymentRequest validation for pin-revoke check

**Policy (SHOULD, not MUST):**

- Store `owner_handle → identity_pk` mapping in wallet DB on first contact
- On subsequent contacts: verify `identity_pk` matches stored value
- Warn if `identity_pk` changed (possible key rotation or compromise)
- Sender SHOULD NOT auto-trust new identity_pk without user confirmation

**TODO:** Expose `PinnedReceiverCards` as public API:

```rust
// FUTURE (not yet public API):
// z00z_wallets::core::address::PinnedReceiverCards
//   pins.check_or_pin(&card)  -> PinCheckResult
//   pins.revoke(&owner_handle)
//   pins.is_revoked(&owner_handle) -> bool
```

---

### 5.1.3 Validation Workflow Diagram

⚠️ **Diagram updated:** `ReceiverCard unsigned` and `ReceiverCardSigned` **do NOT exist** as separate types.
The codebase has exactly ONE `ReceiverCard` struct — it **always** carries a signature field (see §5.1.1.2).
Diagram below reflects the actual 2-branch model:

```mermaid
flowchart TD

    Start["Sender receives payment info"] --> InputType{"Input type?"}

    InputType -->|PaymentRequest| VerifySigReq["1. Verify Z00Z Schnorr signature\n(identity_pk, ctx=Z00Z/REQUEST_v1)"]
    InputType -->|"ReceiverCard (always signed)"| VerifySigCard["1. Verify Z00Z Schnorr signature\n(identity_pk, ctx=Z00Z/CARD_v1)\n⚠ CALLER responsibility\nNOT done by build_tx_stealth_output()"]

    VerifySigReq --> CheckExpiry["2. Check expiry\nrequest.check_validity()"]
    VerifySigCard --> ValidateViewPk3["2. Validate view_pk"]

    CheckExpiry -->|Expired| RejectExpired["Reject: Expired"]
    CheckExpiry -->|Valid| ValidateViewPk1["3. Validate view_pk"]

    ValidateViewPk1 --> ViewPkOk1{"Valid?"}
    ValidateViewPk3 --> ViewPkOk3{"Valid?"}

    ViewPkOk1 -->|Invalid / Identity| RejectViewPk["Reject: Invalid view_pk"]
    ViewPkOk3 -->|Invalid / Identity| RejectViewPk

    ViewPkOk1 -->|Valid| IdentityPin1["4. Identity pinning SHOULD"]
    ViewPkOk3 -->|Valid| IdentityPin3["4. Identity pinning SHOULD"]

    IdentityPin1 --> PinCheck1{"Has known identity?"}
    IdentityPin3 --> PinCheck3{"Has known identity?"}

    PinCheck1 -->|Yes, matches| Accept1["Validated input"]
    PinCheck1 -->|Yes, mismatch| RejectPin["Reject: Identity mismatch"]
    PinCheck1 -->|No known ID| Accept1

    PinCheck3 -->|Yes, matches| Accept3["Validated input"]
    PinCheck3 -->|Yes, mismatch| RejectPin
    PinCheck3 -->|No known ID| Accept3

    Accept1 --> Ready["Ready for output creation"]
    Accept3 --> Ready

    RejectExpired --> End["Abort"]
    RejectViewPk --> End
    RejectPin --> End

    style RejectExpired fill:#f88
    style RejectViewPk fill:#f88
    style RejectPin fill:#f88
    style Ready fill:#8f8
```

---

#### ✅ Implementation Checklist — Phase 5: Identity Pinning & Validation Workflow

> **New file:** `crates/z00z_wallets/src/core/address/pinned_cards.rs`  
> **Status:** ❌ NOT implemented.

- [ ] **Create `crates/z00z_wallets/src/core/address/pinned_cards.rs`**:
  - [ ] Register in `crates/z00z_wallets/src/core/address/mod.rs` as `pub mod pinned_cards;`
  - [ ] Re-export key types from `crates/z00z_wallets/src/lib.rs`
- [ ] **Struct `PinnedReceiverCards`**:
  - [ ] Field: `pins: HashMap<[u8; 32], [u8; 32]>` — owner_handle → identity_pk
  - [ ] Derive or impl `Default` (empty HashMap)
- [ ] **Enum `PinCheckResult`** — three variants:
  - [ ] `Matches` — owner_handle known AND identity_pk matches stored value
  - [ ] `Mismatch` — owner_handle known BUT identity_pk differs → possible attack
  - [ ] `NotPinned` — first encounter; caller decides to trust or reject
- [ ] **Method `pin(&mut self, owner_handle: [u8;32], identity_pk: [u8;32])`**:
  - [ ] Inserts or overwrites entry in `self.pins`
- [ ] **Method `revoke(&mut self, owner_handle: &[u8;32])`**:
  - [ ] Removes entry; no-op if not present
- [ ] **Method `check(&self, owner_handle: &[u8;32], identity_pk: &[u8;32]) -> PinCheckResult`**:
  - [ ] None → `NotPinned`; stored == identity_pk → `Matches`; else → `Mismatch`
  - [ ] MUST use constant-time comparison: `subtle::ConstantTimeEq`
- [ ] **Full `validate_all()` in `ValidatePaymentRequest` trait** calls PinCheckResult:
  - [ ] `Matches` → `Ok(Approved)`
  - [ ] `NotPinned` → `Ok(RequiresUserConfirmation)`
  - [ ] `Mismatch` → `Ok(IdentityMismatch)`
- [ ] **Unit tests** (all must pass):
  - [ ] `test_pin_and_check_matches`
  - [ ] `test_pin_check_mismatch_different_pk`
  - [ ] `test_pin_check_not_pinned_unknown_handle`
  - [ ] `test_revoke_then_not_pinned`
  - [ ] `test_validate_all_approved_pinned_match`
  - [ ] `test_validate_all_requires_confirm_not_pinned`
  - [ ] `test_validate_all_identity_mismatch`

---

#### ✅ Implementation Checklist — Phase 6: 14-Step Output Leaf Algorithm

> **File:** `crates/z00z_wallets/src/core/stealth/output.rs`  
> **Status:** ⚠️ Partially implemented — all steps defined, verify each step's correctness below.

- [ ] **Function signature** — MUST be exactly:

  ```rust
  pub fn build_tx_stealth_output(
      receiver_card: &ReceiverCard,
      asset_id: Z00ZScalar,
      amount: u64,
      rng: &mut impl CryptoRng + RngCore,
  ) -> Result<TxStealthOutput, StealthError>
  ```

  - [ ] Caller MUST validate `receiver_card` before calling (signature + view_pk valid)
  - [ ] `asset_id` MUST come from the transaction context (NOT derived here)
- [ ] **Step 1 — Decompress view_pk**:
  - [ ] `Z00ZRistrettoPoint::from_canonical_bytes(&receiver_card.view_pk)`
  - [ ] Reject identity point \u2192 `StealthError::InvalidPublicKey`
  - [ ] Callers must already have validated; this is a final safety check
- [ ] **Step 2 — Hedged randomness / generate r**:
  - [ ] Call `generate_r_hedged(&sender_wallet.secret_salt, tx_digest, out_index)` (see Phase 8 for impl)
  - [ ] `r` is type `Z00ZScalar`; MUST be non-zero (retry loop in `generate_r_hedged`)
- [ ] **Step 3 — R = r·G (sender's ephemeral public key)**:
  - [ ] `R = r * Z00ZRistrettoPoint::basepoint()`
  - [ ] Compress to `[u8; 32]` \u2192 `r_pub: [u8; 32]`
- [ ] **Step 4 — Shared secret s = r·view_pk**:
  - [ ] `s_point = r * view_pk`
  - [ ] Convert to scalar: `s_out = h2s_zk::<EcdhSharedSecretDomain>("S", &[s_point.compress().as_bytes()])`
- [ ] **Step 5 — Derive stealth_pk (output owner key)**:
  - [ ] `k_out = h2s_zk::<StealthKeyDomain>("K", &[s_out.as_bytes(), &receiver_card.owner_handle])`
  - [ ] `stealth_pk = k_out * basepoint() + identity_pk_point`
  - [ ] Compress to `[u8; 32]`
- [ ] **Step 6 — Encrypt value `p_out`**:
  - [ ] `p_out = h2s_zk::<ValueMaskDomain>("P", &[s_out.as_bytes()]) + Z00ZScalar::from(amount)`
  - [ ] Stored as 32-byte scalar (encrypted amount)
- [ ] **Step 7 — Commitment `C_out = p_out·G + asset_id·H`**:
  - [ ] Uses Pedersen commitment from `z00z_crypto::PedersenCommitmentFactory`
  - [ ] Blinding = `p_out`; value = interpret `asset_id` as amount-component
  - [ ] OR: use `commit_point(p_out, asset_id_point)` per spec if defined
- [ ] **Step 8 — Tag `tag16`**:
  - [ ] `tag16 = hash_zk::<OwnerTagDomain>("T16", &[s_out.as_bytes()]) as u16` (truncated to 2 bytes)
  - [ ] Type is `u16` (NOT `Option<u16>`; field always present)\
- [ ] **Step 9 — Asset ID consistency proof `asset_tag`**:
  - [ ] `asset_tag = h2s_zk::<AssetIdDomain>("", &[s_out.as_bytes()])` (empty label per spec)
- [ ] **Step 10 — ZK-pack proof (ZkPack)**:
  - [ ] Call `ZkPack::build(s_out, p_out, asset_id, amount, ...)` (see spec §5.2.10)
  - [ ] ZkPack held in `TxStealthOutput::zk_pack: ZkPack`
- [ ] **Step 11 — Range proof**:
  - [ ] `BulletproofsPlusService` from `z00z_crypto`
  - [ ] Proves `amount` in `[0, 2^64)` without revealing value
- [ ] **Step 12 — Sender salt (anti-replay)**:
  - [ ] `sender_salt = generate_sender_salt(rng)` (see Phase 8)
  - [ ] 32 random bytes; stored in output
- [ ] **Step 13 — Assemble `TxStealthOutput`**:
  - [ ] All fields present; types correct (see Phase 7 for struct definition)
  - [ ] `tag16: u16` (NOT `Option<u16>`)
- [ ] **Step 14 — Return `Ok(TxStealthOutput)`**
- [ ] **Unit tests** (all must pass):
  - [ ] `test_build_output_succeeds` \u2014 valid inputs, no error
  - [ ] `test_output_round_trip_self_decrypt` \u2014 receiver can decrypt and verify amount
  - [ ] `test_invalid_view_pk_rejected` \u2014 garbage view_pk bytes \u2192 `InvalidPublicKey`
  - [ ] `test_identity_view_pk_rejected` \u2014 identity point \u2192 `InvalidPublicKey`
  - [ ] `test_commitment_opens_correctly` \u2014 commitment can be opened with known keys
  - [ ] `test_range_proof_verifies` \u2014 range proof verifies with correct verifier

---

### 👉🏾Phase 6 — 14-Step Output Leaf Algorithm

### 5.2 Output Leaf Construction

**Purpose:** Step-by-step algorithm for sender to create a complete output leaf for receiver.

**Source:** `crates/Z00Z-ECC-IDEAS.md` lines 680-900 (creation flow), lines 806-850 (OWF constraints).

**High-Level Overview:**

```text
Inputs:  ReceiverCard            (view_pk, owner_handle, identity_pk)
         Option<PaymentRequest>  (optional: req_id, amount, expiry, chain_id)
         SenderWallet            (secret_salt: [u8;32])
         tx_digest: [u8;32]      (any stable 32-byte hash of tx skeleton)
         out_index: u32
         amount: u64
         asset_id: &[u8;32]      (external input — NOT derived inside; see CALLER CONTRACT below)

> 🔒 **CALLER CONTRACT for `asset_id`:**
> The caller of `build_tx_stealth_output()` MUST ensure:
> ```
> asset_id = H_zk::<AssetIdDomain>("", &[s_out])   // where s_out is the output's spending secret
> ```
> This relationship is NOT verified inside `build_tx_stealth_output()` — it is enforced at the
> OWF (output verification) layer when the receiver spends the output.
> Passing an `asset_id` that does NOT satisfy this equation will produce an output that
> passes sender-side validation but is **permanently unspendable** (silent loss of funds).
> The `verify_asset_id_consistency()` check in `build_tx_stealth_output_validated()` (§5.3.3 Phase 4)
> is the only code that verifies this contract locally.

Outputs: TxStealthOutput { r_pub:[u8;32], owner_tag:[u8;32], tag16:Option<u16>,
                           enc_pack:ZkPackEncrypted, c_amount:[u8;32] }

⚠️ NOTE: ValidatedPaymentInput, OutputLeaf, SenderWitness do NOT exist in codebase.
```

**14-Step Algorithm:**

| Step | Action | Output | Critical Field |
| --- | --- | --- | --- |
| 1 | Generate ephemeral secret | `r` | Uniqueness (MUST NOT repeat) |
| 2 | Compute ephemeral public key | `R_pub = r * G` | Public, in leaf |
| 3 | Compute ECDH | `dh = r * view_pk` | Shared secret |
| 4 | Derive symmetric key | Without `PaymentRequest`: `k_dh = hash_zk::<WalletDhKeyHashProdDomain>("Z00Z/DH", &[dh])`; with `PaymentRequest`: `k_dh = hash_zk::<WalletDhKeyHashProdDomain>("Z00Z/DH", &[dh, req_id])`; `WalletDhKeyHashProdDomain` = `"z00z.wallet.stealth.dh_key.prod.v1"` from `z00z_wallets::core::domains`; dispatch via private `derive_stealth_key()` | Encryption key |
| 5 | Compute owner tag | `owner_tag = H_zk("Z00Z/TAG" \|\| owner_handle \|\| k_dh)` (done **before** blinding — actual code order) | Receiver binding |
| 6 | (External) asset ID | `asset_id` is **external parameter** to `build_tx_stealth_output()` — caller MUST ensure `asset_id = H_zk("Z00Z/ASSET" \|\| s_out)` | Asset identifier |
| 7 | Generate blinding factor | `blinding` (`Z00ZScalar::random()`) | Commitment input |
| 8 | Compute commitment | `C_amount = Commit(amount, blinding)` | Public, in leaf |
| 9 | Compute leaf AD | `leaf_ad = compute_leaf_ad(asset_id, serial_id, r_pub, owner_tag, c_amount)` | Anti-malleability |
| 10 | Derive asset secret | `s_out = hash_zk::<SOutProdDomain>("Z00Z/S_OUT", &[k_dh, r_pub, serial_id_le4])` (⚠️ DERIVED, not random; `serial_id = 0u32` hardcoded; computed **after** leaf_ad — actual code order; `SOutProdDomain` = `"z00z.wallet.stealth.s_out.prod.v1"` from `z00z_wallets::core::domains`) | Spending secret |
| 11 | Prepare plaintext | `AssetPackPlain { value:u64, blinding:[u8;32], s_out:[u8;32] }` (72 bytes; formerly misnamed `AssetPackPlainV1`) | Encrypted data |
| 12 | Encrypt pack | `enc_pack` | Ciphertext in leaf |
| 13 | Compute tag16 | Always `Some(u16)` — with PaymentRequest: `compute_tag16_with_req(k_dh, req_id)`, card-only: `compute_tag16(k_dh, leaf_ad)` | Performance opt (currently typed `Option<u16>`; runtime invariant: NEVER `None` — **TODO:** change type to `u16` for compile-time enforcement) |
| 14 | Assemble leaf | `TxStealthOutput { r_pub, owner_tag, tag16, enc_pack, c_amount }` (formerly `OutputLeaf`) | Final structure |

**Security Requirements:**

- ✅ **MUST** use fresh `r` per output (repeats → linkability)
- ✅ **MUST** validate `view_pk` before ECDH (Section 5.1.2)
- ✅ **MUST** use canonical encodings (consensus-critical)
- ✅ **MUST** bind `enc_pack` to `leaf_ad` (anti-malleability)
- ✅ **SHOULD** cache recent `R` values to detect accidental repeats

---

### 5.2.1 Overview Diagram

```mermaid
flowchart TD

    Start["Start: ReceiverCard + Option(PaymentRequest) + amount + asset_id"]
        --> Step1["Generate r hedged (H-3)"]

    Step1 --> Step2["R_pub = r * G"]
    Step2 --> Step3["dh = r * view_pk"]
    Step3 --> Step4["k_dh = hash_zk(DH, dh)\nor hash_zk(DH, dh, req_id) if PaymentRequest"]

    Step4 --> Step5["owner_tag = H_zk(TAG || owner_handle || k_dh)"]
    Step5 --> Step6["asset_id: external param\ncaller ensures H_zk(ASSET||s_out)"]

    Step6 --> Step7["Generate blinding factor"]
    Step7 --> Step8["C_amount = Commit(amount, blinding)"]

    Step8 --> Step9["leaf_ad = compute_leaf_ad(...)"]
    Step9 --> Step10["s_out = hash_zk(S_OUT, k_dh, r_pub, serial_id=0)"]

    Step10 --> Step11["AssetPackPlain {value, blinding, s_out} (72 bytes)"]
    Step11 --> Step12["enc_pack = ZkPack::encrypt(...)"]

    Step12 --> Step13["tag16:\nwith_req -> tag16_with_req\ncard_only -> tag16"]

    Step13 --> Step14["TxStealthOutput { r_pub, c_amount, enc_pack, owner_tag, tag16 }"]

    Step14 --> Validate["Self validation: decrypt own output"]
    Validate --> Done["TxStealthOutput ready"]

    style Step1 fill:#ffa
    style Step4 fill:#aff
    style Step10 fill:#faf
    style Step12 fill:#faf
    style Done fill:#afa
```

---

### 5.2.2 Implementation Phases

This Section 5.2 is ~3,500 lines of detailed specification. Due to token constraints, full implementation will be added incrementally in follow-up updates.

**Recommended Incremental Implementation:**

#### Phase 1: ECDH Setup (Steps 1-4) - ~800 lines

- Step 1: `generate_ephemeral_secret()` with recent-R cache
- Step 2: `compute_r_pub()` - R_pub = r * G
- Step 3: `compute_ecdh()` - dh = r * view_pk  
- Step 4: `derive_k_dh()` / `derive_k_dh_with_req()` — dispatched by private `derive_stealth_key(payment_request, &dh)`:
  - Without `PaymentRequest`: `k_dh = hash_zk::<WalletDhKeyHashProdDomain>("Z00Z/DH", &[dh])`
  - With `PaymentRequest`: `k_dh = hash_zk::<WalletDhKeyHashProdDomain>("Z00Z/DH", &[dh, req_id])`
  - Domain: `WalletDhKeyHashProdDomain` = `"z00z.wallet.stealth.dh_key.prod.v1"` from `z00z_wallets::core::domains`

#### Phase 2: Owner Tag & Commitment (Steps 5-8) - ~600 lines

- Step 5: `compute_owner_tag()` — done **before** blinding (actual code order): `H_zk::<WalletOwnerTagHashProdDomain>("Z00Z/TAG", owner_handle, k_dh)`
- Step 6: `asset_id` is an **external parameter** to `build_tx_stealth_output()` — the caller supplies the canonical public asset key used by the output and the JMT-facing leaf model; the function does not derive it internally
- Step 7: `generate_blinding_factor()` + `validate_amount()` — blinding = `Z00ZScalar::random()`
- Step 8: `compute_commitment()` - `C_amount = Commit(amount, blinding)`, integrates Pedersen (Section 4.4)

#### Phase 3: Leaf AD, Asset Secret & Encryption (Steps 9-12) - ~1,000 lines

- Step 9: `compute_leaf_ad()` from `z00z_wallets::core::stealth::tag` - integrates Section 4.7
  - ⚠️ `compute_leaf_ad_for_output()` does **NOT** exist — use `compute_leaf_ad(asset_id, serial_id, r_pub, owner_tag, c_amount)`
- Step 10: `derive_s_out(k_dh, r_pub, serial_id:u32)` — s_out is **DERIVED** (not random), computed **after** leaf_ad (actual code order):
  - `s_out = hash_zk::<SOutProdDomain>("Z00Z/S_OUT", &[k_dh, r_pub, serial_id_le4])`; `serial_id = 0u32` hardcoded
  - Domain: `SOutProdDomain` = `"z00z.wallet.stealth.s_out.prod.v1"` from `z00z_wallets::core::domains`
  - `verify_owner_tag()` (M1 check) + `compute_owner_handle()` also in this phase
- Step 11: `AssetPackPlain` struct — `{ value:u64, blinding:[u8;32], s_out:[u8;32] }`, 72 bytes (use this; `AssetPackPlainV1` does **NOT** exist)
- Step 12: `encrypt_asset_pack()` - integrates Section 4.6/4.7.3

#### Phase 4: Final Assembly (Steps 13-14) - ~400 lines

- Step 13: `compute_tag16()` + `check_tag16_hint()` (receiver-side)  
  > **Note on tag16 computation paths:** Two distinct paths exist — they produce **different** tag16 values and serve different purposes:  
  > 1. **`DefaultTag16Ops::compute(owner_handle, k_dh)`** — used during *receiver-side wallet scanning*; actual implementation is a **two-step hash**:
  >    - Step A: `leaf_ad_virtual = hash_zk::<WalletLeafAdHashProdDomain>("Z00Z/TAG16/OWNER", &[owner_handle])`  (reuses `WalletLeafAdHashProdDomain` domain type but with label `"Z00Z/TAG16/OWNER"`, NOT `"Z00Z/LEAFAD"`)
  >    - Step B: `compute_tag16(k_dh, &leaf_ad_virtual)` = `hash_zk::<WalletTag16HashProdDomain>("Z00Z/TAG16", &[k_dh, leaf_ad_virtual])`
  >    Three domain-separated hashes are involved (WalletLeafAdHashProdDomain → WalletTag16HashProdDomain). NOT used in output creation.  
  > 2. **`derive_tag16(k_dh, leaf_ad)`** / **`compute_tag16_with_req(k_dh, req_id)`** — used *inside `build_tx_stealth_output()`* during output creation; binds to full `leaf_ad` or `req_id`.  
  > Both produce valid `u16` values and are correct in their respective contexts. Do not mix the two paths.
- Step 14: `TxStealthOutput` is the final output type (`OutputLeaf` does **NOT** exist); `assemble_output_leaf()` does **NOT** exist — final assembly is done inside `build_tx_stealth_output()`

#### Phase 5: Orchestrator (Step 15) - ~700 lines

- `build_tx_stealth_output()` — actual entry point (replaces `create_output_leaf()` which does **NOT** exist)
- No `SenderWitness` struct — intermediate values are internal to `build_tx_stealth_output()`
- Error handling: `StealthError` enum (replaces `OutputError` which does **NOT** exist)
- Self-validation (decrypt own output)

**Module Structure (Actual):**

```text
z00z_wallets/                          # ✅ ACTUAL location of stealth output logic
└── src/
    └── core/
        └── stealth/
            ├── output.rs              # ✅ build_tx_stealth_output() entry point
            ├── ephemeral.rs           # ✅ generate_r_hedged(), recover_r(), generate_sender_salt()
            ├── ecdh.rs                # ✅ derive_k_dh, derive_k_dh_with_req, derive_k_dh_flexible,
            │                          #    derive_k_dh_extended, EcdhSenderKeys, EcdhReceiverKeys,
            │                          #    KeyDerivationContext, sender_derive_keys,
            │                          #    receiver_derive_keys, dh_eq_ct
            ├── tag.rs                 # ✅ compute_leaf_ad(), compute_tag16(), compute_tag16_with_req(),
            │                          #    DefaultTag16Ops, encode_leaf_preimage(), LEAF_PREIMAGE_SIZE
            └── facade_kdf.rs          # ✅ derive_pack_key(), derive_nonce()

z00z_core/                             # ✅ Leaf and AssetPack types
└── src/
    └── assets/
        ├── leaf.rs                    # ✅ AssetLeaf, AssetPackPlain (NOT AssetPackPlainV1)
        └── mod.rs

⚠️ z00z_core/src/tx/        does NOT exist
⚠️ z00z_core/src/asset/     does NOT exist (it IS assets/, not asset/)
⚠️ output_builder.rs        does NOT exist
⚠️ output_leaf.rs           does NOT exist
⚠️ AssetPackPlainV1         does NOT exist — use AssetPackPlain
```

**Integration Points:**

- ✅ `z00z_crypto::PedersenCommitmentFactory` - Step 8 (commitment)
- ✅ `z00z_wallets::core::stealth::tag::compute_leaf_ad()` (or facade `z00z_wallets::core::stealth::facade_kdf::compute_leaf_ad()`) - Step 9 (anti-malleability); ⚠️ `z00z_crypto::leaf_ad::compute_leaf_ad()` does **NOT** exist
- ✅ `ZkPack::encrypt()` / `ZkPackEncrypted` from `z00z_crypto` - Step 12 (encryption); ⚠️ `z00z_core::asset::EncryptedPack` does **NOT** exist
- ✅ `hash_zk::<D>()` function from `z00z_crypto::hash` - Steps 4, 6, 9, 13 (domain-separated hashing); ⚠️ `ZkHash` struct does **NOT** exist
- ✅ `z00z_crypto::Z00ZRistrettoPoint` / `Z00ZScalar` - Steps 2, 3 (elliptic curve operations); ⚠️ caller should NOT use `curve25519_dalek` directly

**Additional ECDH Utilities (`ecdh.rs`) — not shown in 14-Step Table:**

| Function / Type | Signature | Purpose |
| --- | --- | --- |
| `EcdhSenderKeys` | `{ dh:[u8;32], k_dh:[u8;32] }` | Bundle: sender ECDH result + derived key |
| `EcdhReceiverKeys` | `{ dh:[u8;32], k_dh:[u8;32] }` | Bundle: receiver ECDH result + derived key |
| `sender_derive_keys(r, view_pk, req_id)` | `Result<EcdhSenderKeys, StealthError>` | Combines compute_dh_sender + derive_k_dh dispatch |
| `receiver_derive_keys(view_sk, r_pub, req_id)` | `Result<EcdhReceiverKeys, StealthError>` | Combines compute_dh_receiver + derive_k_dh dispatch |
| `derive_k_dh_flexible(dh, context)` | `[u8;32]` | Custom-context DH key; domain `KdhFlexDomain` ("Z00Z/DH/FLEX") |
| `derive_k_dh_extended(dh, version, context)` | `[u8;32]` | Versioned-context DH key; domain `KdhExtDomain` ("Z00Z/DH/EXT") |
| `KeyDerivationContext` | `{ purpose:Vec<u8>, version:u8, data:Option<Vec<u8>> }` | Builder for extended derivation contexts |
| `dh_eq_ct(left, right)` | `bool` | Constant-time equality for DH byte arrays |

**Additional Tag Utilities (`tag.rs`) — not shown in 14-Step Table:**

| Symbol | Type | Purpose |
| --- | --- | --- |
| `encode_leaf_preimage(asset_id, serial_id, r_pub, owner_tag, c_amount)` | `[u8; 132]` | Canonical 132-byte preimage of leaf_ad fields (for proof/audit use) |
| `LEAF_PREIMAGE_SIZE` | `usize = 132` | Constant: byte length of `encode_leaf_preimage()` output |

**See:**

- `crates/Z00Z-ECC-IDEAS.md` lines 680-900 for complete algorithm details
- `Z00Z_DESIGN_FOUNDATION.md` for implementation patterns and code examples
- `WALLET-ECC-SPEC.md` Section 4.4 for Pedersen commitment integration
- `WALLET-ECC-SPEC.md` Section 4.6 for ZkPack/ZkPackEncrypted integration
- `WALLET-ECC-SPEC.md` Section 4.7 for leaf_ad integration

**Next Steps:**

This section provides the structural overview. Full implementation with complete Rust code for all 14 steps (~3,500 lines) will be added in follow-up specification updates.

For immediate implementation guidance:

1. Start with Phase 1 (ECDH setup)
2. Write unit tests for each step before implementing
3. Capture intermediate values for debugging using a local struct (no `SenderWitness` type — does NOT exist)
4. Validate against test vectors from `crates/Z00Z-ECC-IDEAS.md`

---

#### ✅ Implementation Checklist — Phase 7: Implementation Foundation (Steps 1–4)

> **File:** `crates/z00z_wallets/src/core/stealth/output.rs`  
> **Status:** ❌ Foundation code exists but critical invariants MUST be verified.

- [ ] **Struct `TxStealthOutput`** — verify exact field types:
  - [ ] `r_pub: [u8; 32]` — sender's ephemeral public key (R = r·G compressed)
  - [ ] `stealth_pk: [u8; 32]` — output owner's public key (compressed Ristretto)
  - [ ] `commitment: [u8; 32]` — Pedersen commitment C = p·G + asset_id·H (compressed)
  - [ ] `encrypted_amount: [u8; 32]` — `p_out` as scalar bytes (NOT ciphertext bytes)
  - [ ] `tag16: u16` — **MANDATORY u16, NOT `Option<u16>`**
  - [ ] `asset_tag: [u8; 32]` — h2s_zk asset ID consistency check value
  - [ ] `zk_pack: ZkPack` — ZK proof pack (see spec §5.2.10)
  - [ ] `range_proof: Vec<u8>` — Bulletproofs+ serialized
  - [ ] `sender_salt: [u8; 32]` — ephemeral anti-replay nonce
- [ ] **CALLER CONTRACT for `asset_id`** (must be documented in fn docstring):
  - [ ] `asset_id` is passed in by caller from transaction context
  - [ ] `build_tx_stealth_output()` NEVER derives/assumes asset_id internally
  - [ ] Docstring example shows correct call site with explicit `asset_id`
- [ ] **`serial_id = 0` hardcoded** (if present as field):
  - [ ] `serial_id: u64 = 0` — set by rollup node after batch assembly, NOT by wallet
  - [ ] Document: "Assigned by rollup node; wallet sets 0"
- [ ] **Steps 1–4 are correct** (see Phase 6 checklist for details of each):
  - [ ] Step 1 (decompress view_pk) — verified
  - [ ] Step 2 (hedged r) — calls `generate_r_hedged()`, not raw `rng.fill_bytes()`
  - [ ] Step 3 (R = r·G) — uses ristretto basepoint
  - [ ] Step 4 (s = r·view_pk then hash) — uses `h2s_zk::<EcdhSharedSecretDomain>`
- [ ] **Documentation comments on `build_tx_stealth_output()`**:
  - [ ] Explains the 14-step process at a high level
  - [ ] Lists preconditions (caller must validate receiver_card)
  - [ ] Shows example usage in `/// # Examples` block
- [ ] **Unit tests** (foundational):
  - [ ] `test_r_is_nonzero` — generated r is never zero
  - [ ] `test_R_is_valid_ristretto_point` — R = r·G is a valid compressed Ristretto
  - [ ] `test_shared_secret_both_sides` — `r·view_pk` == `view_sk·R` (ECDH correctness)
  - [ ] `test_stealth_pk_is_valid_point` — stealth_pk decompresses successfully
  - [ ] `test_serial_id_is_zero` — output.serial_id == 0 after construction

---

### 👉🏾Phase 7 — Implementation Foundation (Steps 1–4)

### 5.2.3 Interim Implementation Guidance (CRITICAL)

**Status:** Section 5.2 provides structural overview. Full detailed specification (~3,500 lines) deferred to follow-up updates.

**For immediate implementation:** Use foundation documents as authoritative source for algorithm details.

#### Foundation Document References

```yaml
Interim_Implementation_Guidance(MUST):
  primary_sources:
    stealth_address_spec:
      file: "crates/Z00Z-ECC-IDEAS.md"
      lines: 680-900
      content: "Complete 14-step sender algorithm with formulas"
      authority: "Canonical algorithm specification"
    
    ideas_workflow:
      file: "Z00Z-ECC-IDEAS.md"
      lines: 666-820
      content: "Sender output creation workflow"
      authority: "Design requirements and security goals"
  
  critical_formulas_locations:
    h3_hedged_randomness:
      file: "Z00Z-ECC-IDEAS.md"
      lines: 680-710
      formula: "r = h2s_zk::<WalletEphemeralRHashProdDomain>(\"R\", &[rng_bytes, sender_secret_salt, tx_digest, out_index_le4])"
      formula_note: "⚠️ Historical notation used H2Scalar_zk(\"Z00Z/R\", ...) — actual label is \"R\" (NOT \"Z00Z/R\"); domain: \"z00z.wallet.stealth.ephemeral_r.prod.v1\""
      priority: "P0 - MUST implement before any output creation"
    
    k_dh_derivation:
      file: "Z00Z-ECC-IDEAS.md"
      line: 735
      formula: "k_dh = KDF(\"Z00Z/DH\" || Encode(dh))"
      priority: "P0 - Core ECDH key agreement"
    
    owner_tag_computation:
      file: "Z00Z-ECC-IDEAS.md"
      line: 700
      formula: "owner_tag = H(\"Z00Z/TAG\" || owner_handle || k_dh)"
      priority: "P0 - M1 anti-phishing protection"
    
    leaf_ad_binding:
      section: "Section 4.7"
      status: "Already complete in this SPEC"
      formula: "leaf_ad = H_zk(\"Z00Z/LEAFAD\" || asset_id || serial_id || R_pub || owner_tag || C_amount)"
    
    enc_pack_encryption:
      section: "Section 4.6"
      status: "Already complete in this SPEC"
      algorithm: "ZkPack_v1 AEAD construction"
  
  implementation_path:
    1_read_foundation_docs:
      action: "Read crates/Z00Z-ECC-IDEAS.md lines 680-900"
      purpose: "Understand complete 14-step algorithm"
    
    2_implement_h3_first:
      action: "Implement H-3 hedged randomness (see §5.2.4 below)"
      purpose: "Critical RNG failure protection"
      priority: "P0 - blocker for all output creation"
    
    3_implement_phases:
      action: "Implement Phase 1 → Phase 2 → Phase 3 → Phase 4 → Phase 5"
      reference: "§5.2.2 phase breakdown"
      testing: "Write unit tests for each step before proceeding"
    
    4_integrate_existing:
      action: "Use Section 4.4 (Pedersen), 4.6 (ZkPack/ZkPackEncrypted), 4.7 (leaf_ad)"
      note: "⚠️ EncryptedPack as a type does NOT exist — use ZkPack::encrypt()/decrypt() and ZkPackEncrypted from z00z_crypto"
      status: "Already implemented, ready for integration"
  
  validation_requirement(MUST):
    rule: |
      Implementers MUST use foundation documents as authoritative source
      until full §5.2 detailed specification is added to this SPEC.
    
    test_vectors:
      source: "crates/Z00Z-ECC-IDEAS.md test vectors"
      requirement: "All implementations MUST pass canonical test vectors"
```

---

#### ✅ Implementation Checklist — Phase 8: H-3 Hedged Randomness Implementation

> **File:** `crates/z00z_wallets/src/core/stealth/ephemeral.rs`  
> **Status:** ✅ Core implemented. Remaining work: hardening tests and integration checks.

- [ ] **API consistency check (implemented API is authoritative):**
  - [ ] `generate_r_hedged(sender_secret_salt: &[u8;32], tx_digest: &[u8;32], out_index: u32) -> Result<Z00ZScalar, StealthError>`
  - [ ] `derive_r_hedged(rng_bytes: &[u8;32], sender_secret_salt: &[u8;32], tx_digest: &[u8;32], out_index: u32) -> Result<Z00ZScalar, StealthError>`
  - [ ] `get_rng_bytes() -> [u8;32]`
  - [ ] `generate_sender_salt() -> [u8;32]`
- [ ] **Domain and label invariants:**
  - [ ] Use `h2s_zk::<WalletEphemeralRHashProdDomain>("R", &[rng_bytes, sender_secret_salt, tx_digest, &out_index.to_le_bytes()])`
  - [ ] Domain string remains `"z00z.wallet.stealth.ephemeral_r.prod.v1"`
  - [ ] Do NOT use legacy `h2scalar_zk(b"Z00Z/R", ...)`
- [ ] **Non-zero scalar invariant:**
  - [ ] `derive_r_hedged` rejects/loops on zero scalar result
  - [ ] `generate_r_hedged` guarantees non-zero `r` or returns explicit error
- [ ] **Unit tests** (all must pass with deterministic inputs):
  - [ ] `test_derive_r_hedged_deterministic` — same `(rng_bytes, sender_secret_salt, tx_digest, out_index)` → same `r`
  - [ ] `test_derive_r_hedged_nonzero` — no zero scalar across randomized corpus
  - [ ] `test_generate_r_hedged_domain_separation` — changing any input changes output with overwhelming probability
  - [ ] `test_sender_salt_generation_quality` — no structural bias in generated salts

---

### 👉🏾Phase 8 — H-3 Hedged Randomness Implementation

### 5.2.4 H-3 Hedged Randomness Specification (CRITICAL - P0)

**Purpose:** Protect against RNG failures (VM snapshots, mobile entropy bugs, container misconfiguration).

**Source:** `Z00Z-ECC-IDEAS.md` lines 680-710 (H-3 specification)

**Security Rationale:**

🚨 **Why H-3 is CRITICAL:**

- RNG failures are **real production threats** (not hypothetical):
  - Mobile devices: entropy exhaustion in low-power states
  - VMs: snapshot/restore breaks randomness continuity
  - Containers: shared entropy pools, clock resets
  - Embedded systems: insufficient entropy sources

🚨 **Attack consequences if `r` repeats:**

- `R_pub` repeats → outputs become **trivially linkable** (privacy break)
- `k_dh` repeats → `owner_tag` repeats → **receiver identity leaked**
- Same `enc_pack` key → ciphertext analysis possible

#### H-3 Hedged Generation Algorithm

```yaml
H3_Hedged_Randomness(MUST):
  formula: |
    r = h2s_zk::<WalletEphemeralRHashProdDomain>("R", &[rng_bytes, sender_secret_salt, tx_digest, out_index_le4])
    # ⚠️ label is "R" (NOT "Z00Z/R"); domain: "z00z.wallet.stealth.ephemeral_r.prod.v1"
    # ⚠️ h2scalar_zk(b"Z00Z/R", ...) uses HashToScalarDomain → different output → DO NOT USE
  
  inputs:
    rng_bytes:
      source: "SystemRngProvider (z00z_utils::rng)"
      size: "32 bytes"
      purpose: "Unpredictability if sender_secret_salt leaks"
      requirement: "MUST use cryptographically secure RNG"
    
    sender_secret_salt:
      source: "Wallet secret (per-wallet constant)"
      size: "32 bytes"
      purpose: "Uniqueness if RNG weak/broken"
      derivation: "hash_zk::<SenderSaltDomain>(\"SENDER_SALT\", &[receiver_secret])"
      derivation_note: "⚠️ label is \"SENDER_SALT\" (NOT \"Z00Z/SENDER_SALT\"); domain: \"z00z.wallet.stealth.sender_salt.prod.v1\""
      storage: "Persistent in secure wallet storage"
      lifecycle: "Generated once per wallet, never changes"
    
    tx_digest:
      source: "Hash of transaction skeleton"
      size: "32 bytes"
      purpose: "Per-transaction uniqueness"
      computation: "H_zk(\"Z00Z/TXDIGEST\" || inputs || fee || memo)"
      note: "Ensures different txs have different r even if RNG stuck"
    
    out_index:
      source: "Output index in transaction (u32 LE)"
      size: "4 bytes"
      purpose: "Per-output uniqueness within transaction"
      format: "Little-endian u32"
  
  properties:
    if_rng_weak:
      guarantee: "sender_secret_salt ensures uniqueness"
      example: "RNG returns all zeros → still unique r per wallet/tx/output"
    
    if_sender_secret_salt_leaks:
      guarantee: "rng_bytes ensure unpredictability"
      example: "Attacker knows salt → cannot predict future r values"
    
    if_both_compromised:
      fallback: "tx_digest + out_index ensure per-tx/per-output uniqueness"
      note: "Prevents r repeats even in catastrophic failures"
```

#### Implementation Specification

> ✅ **IMPLEMENTED** — `crates/z00z_wallets/src/core/stealth/ephemeral.rs`

```rust
// ✅ ACTUAL API (use this, not the legacy pseudocode below):

use z00z_wallets::core::stealth::{generate_r_hedged, StealthError};
use z00z_crypto::Z00ZScalar;

/// Generates hedged ephemeral scalar r with H-3 protection.
///
/// ACTUAL signature (as implemented):
///
/// pub fn generate_r_hedged(
///     sender_secret_salt: &[u8; 32],  // Per-wallet constant salt
///     tx_digest: &[u8; 32],           // Hash of transaction skeleton (any 32 bytes)
///     out_index: u32,                  // Output index within transaction
/// ) -> Result<Z00ZScalar, StealthError>
///
/// Internal formula (from ephemeral.rs):
///   1. rng_bytes ← SystemRngProvider.fill_bytes(32)
///   2. r ← derive_r_hedged(rng_bytes, sender_secret_salt, tx_digest, out_index)
///   3. derive_r_hedged internally calls:
///      h2s_zk::<WalletEphemeralRHashProdDomain>("R", &[rng_bytes, sender_secret_salt, tx_digest, &out_index.to_le_bytes()])
///      // ⚠️ label is "R" (NOT "Z00Z/R"); domain: "z00z.wallet.stealth.ephemeral_r.prod.v1"
///      // ⚠️ h2scalar_zk(b"Z00Z/R",...) uses a DIFFERENT (non-domain-parameterized) path → DO NOT USE
///
/// Returns: Z00ZScalar (NOT RistrettoSecretKey — legacy spec was wrong)
/// Error:   StealthError (NOT EphemeralKeyError — does not exist)

// Usage example (matches actual codebase):
let r = generate_r_hedged(&sender_wallet.secret_salt, &tx_digest, out_index)?;
let r_pub = compute_r_pub(&r)?;         // r_pub: Z00ZRistrettoPoint
let r_pub_bytes = encode_r_pub(&r_pub); // [u8; 32]

// For tx_digest — no TransactionSkeleton type yet; pass any stable 32-byte
// hash of your transaction context. Convention: hash inputs/fee/serial:
//   tx_digest = hash_zk::<TxDigestDomain>("Z00Z/TXDIGEST", &[input_ids, fee_bytes])
//   // ⚠️ use hash_zk::<D> (domain-parameterized), NOT h2scalar_zk
//   or just [0u8; 32] for tests / single-output transactions.
```

> ⚠️ Types `EphemeralKeyError` and `generate_ephemeral_secret()` do **NOT exist** in codebase.  
> ⚠️ Type `RistrettoSecretKey` for ephemeral key is **WRONG** — actual return type is `Z00ZScalar`.  
> ⚠️ `ZkHash::new_with_domain()` does **NOT exist** — actual function is `h2s_zk::<D>()` or `hash_zk::<D>()` from `z00z_crypto::hash_zk` (domain-parameterized).  
> ⚠️ `h2scalar_zk()` is a LEGACY non-domain-parameterized function that produces **different output** from `h2s_zk::<D>()` — **DO NOT use** for new protocol code.

**Lower-level deterministic API — `derive_r_hedged` (now public):**

```rust
// In z00z_wallets::core::stealth::ephemeral (re-exported from z00z_wallets::core::stealth):
use z00z_wallets::core::stealth::derive_r_hedged;
// pub fn derive_r_hedged(
//     rng_bytes: &[u8; 32],           // pre-collected entropy bytes
//     sender_secret_salt: &[u8; 32],
//     tx_digest: &[u8; 32],
//     out_index: u32,
// ) -> Result<Z00ZScalar, StealthError>
//
// Deterministic from inputs — no internal RNG call.
// Use in tests by fixing rng_bytes = [0xFE; 32] for repeatability.
// Use in adversarial tests to verify hedging properties.
//
// ✅ facade_ecdh::generate_hedged_r() was DELETED (used non-domain-parameterized
//    h2scalar_zk — different output from derive_r_hedged). All callers migrated.
```

**Additional helpers (generate_sender_salt, recover_r)** are in `ephemeral.rs`:

```rust
// pub fn generate_sender_salt() -> [u8; 32]  // ⚠️ NO Result — infallible (retries internally until non-zero)
//   Generates fresh random per-wallet salt from SystemRngProvider.
//   Use on first wallet initialization; persists for wallet lifetime.

// pub fn get_rng_bytes() -> [u8; 32]
//   Returns 32 cryptographically random bytes from SystemRngProvider.
//   Infallible (retries internally until non-zero result).
//   Lower-level than generate_r_hedged(); for use when only raw entropy bytes are needed.

// pub fn recover_r(
//     wallet_secret: &[u8; 32],        // raw secret bytes — call .as_bytes() on ReceiverSecret
//     ephemeral_seed: &[u8; 32],       // rng_bytes captured at creation time
//     output_index: u32,               // out_index used at creation time
// ) -> Result<Z00ZScalar, StealthError>
//   Recovers the ephemeral scalar r for a previously created output.
//   Uses RecoverRDomain ("z00z.wallet.stealth.recover_r.prod.v1") with label "RECOVER_R".
//   Purpose: audit, re-derive s_out, or reconstruct output for debugging.
//   ⚠️ Requires the original rng_bytes — these are NOT stored by default; caller must keep them.
```

> ✅ **`facade_ecdh::sender_derive_dh()` — DELETED:**
> Previously bypassed H-3 hedged randomness by calling `Z00ZScalar::random()` directly (no tx_digest, no salt binding).
> Removed from `facade_ecdh.rs`; callers migrated to `sender_derive_dh_with_r` + explicit `Z00ZScalar::random()` (tx layer) or `build_tx_stealth_output()` (stealth layer).
> **Use `build_tx_stealth_output()`** — it calls `generate_r_hedged()` internally and enforces H-3.

> **Note — Hash label conventions:** Labels for domain-separated hashes across the stealth protocol follow two patterns:  
>
> - **`"Z00Z/..."`** prefix: used for protocol-level operations where the label is part of the domain naming scheme (`"Z00Z/TAG"`, `"Z00Z/DH"`, `"Z00Z/S_OUT"`, `"Z00Z/LEAFAD"`, `"Z00Z/TXDIGEST"`).  
> - **Short / empty labels**: used when the `Domain` type already carries the full context string and the label is merely a sub-key (`"R"`, `"SENDER_SALT"`, `""` for `AssetIdDomain`).  
> The empty label `""` with `AssetIdDomain` is intentional: `AssetIdDomain`'s domain string already embeds all necessary context; adding a label would be redundant.  
> This convention is **not enforced by the type system**. Always use `hash_zk::<D>()` / `h2s_zk::<D>()` (domain-parameterized) rather than legacy `h2scalar_zk(b"Z00Z/...", ...)`.

---

#### ✅ Implementation Checklist — Phase 9: Recent-R Cache Implementation

> **File:** `crates/z00z_wallets/src/core/stealth/recent_r_cache.rs` (new)  
> **Status:** ❌ NOT implemented.

- [ ] **Create `crates/z00z_wallets/src/core/stealth/recent_r_cache.rs`**:
  - [ ] Register in `mod.rs` as `pub mod r_cache;`
- [ ] **Struct `RecentRCache`**:
  - [ ] Field: `cache: HashMap<[u8; 32], Vec<[u8; 32]>>` — receiver_view_pk → list of recent r_pub values
  - [ ] **NOT** `CompressedRistretto` — raw `[u8; 32]` bytes only; no curve dependency in cache
  - [ ] Field: `max_per_receiver: usize` — max R values per receiver (default 100)
  - [ ] Derive or impl `Default` (empty HashMap, max_per_receiver = 100)
- [ ] **Method `check_and_insert(&mut self, receiver_view_pk: &[u8;32], r_pub: &[u8;32]) -> Result<(), StealthError>`**:
  - [ ] If `r_pub` is already in `cache[receiver_view_pk]` → `Err(StealthError::RepeatDetected)`
  - [ ] Otherwise: insert into vec; if vec len > `max_per_receiver` → remove oldest (pop front or VecDeque)
  - [ ] Returns `Ok(())` on successful insert
- [ ] **Add `RepeatDetected` variant to `StealthError`**:
  - [ ] In `crates/z00z_wallets/src/core/stealth/error.rs` (or wherever `StealthError` lives)
  - [ ] Variant: `RepeatDetected,`
  - [ ] `Display`: `"repeated ephemeral R value detected—possible replay attack"`
- [ ] **Integration into `build_tx_stealth_output()`**:
  - [ ] Takes optional `cache: Option<&mut RecentRCache>` parameter, OR
  - [ ] Uses thread-local / session-local cache (caller's choice)
  - [ ] Call `cache.check_and_insert(&receiver_card.view_pk, &r_pub)?` between step 3 (R = r·G) and step 4
- [ ] **Cache eviction policy** (MUST document):
  - [ ] Oldest R per handle evicted first when limit reached
  - [ ] Reason: prevent unbounded memory growth in long-running sessions
- [ ] **Unit tests** (all must pass):
  - [ ] `test_cache_first_insert_ok` — fresh cache, insert new R → Ok
  - [ ] `test_cache_repeat_detected` — same R twice → `RepeatDetected`
  - [ ] `test_cache_different_receivers_independent` — same R for different receiver_view_pk values → Ok (no cross-contamination)
  - [ ] `test_cache_eviction_at_limit` — insert max+1 entries; oldest evicted; oldest R can be re-inserted
  - [ ] `test_cache_100_unique_inserts_ok` — 100 different R values for same receiver_view_pk → all Ok
  - [ ] `test_stealth_error_repeat_detected_display` — Display message matches spec string

---

### 👉🏾Phase 9 — Recent-R Cache Implementation

#### Recent-R Cache (Additional Safety)

```yaml
Recent_R_Cache(MUST):
  purpose: "Detect accidental r repeats locally before submission"
  
  implementation:
    storage: "In-memory LRU cache"
    key: "receiver_card.view_pk (32 bytes)"
    value: "Vec<[u8; 32]> (last 100 R_pub encoded bytes — NOT CompressedRistretto)"
    capacity: "100 entries per receiver"
  
  check_algorithm:
    on_generate_r:
      1_compute_R_pub: "R_pub = r * G"
      2_check_cache: "if cache.contains(receiver_card, R_pub) → reject"
      3_add_to_cache: "cache.push(receiver_card, R_pub)"
      4_enforce_limit: "Keep only last 100 R_pub per receiver"
  
  error_handling:
    on_repeat_detected:
      action: "Return Err(StealthError::RepeatDetected)  # ⚠️ EphemeralKeyError does NOT exist; add RepeatDetected variant to StealthError"
      user_action: "Retry with fresh RNG, investigate RNG failure"
      log_level: "ERROR - potential RNG compromise"
```

#### Implementation Code (Recent-R Cache)

> ❌ **NOT YET IMPLEMENTED** — `z00z_wallets` has no `RecentRCache` type.  
> ⚠️ `CompressedRistretto` key type from spec is **WRONG** — use `[u8; 32]` throughout.  
> 📌 **TODO**: Implement as part of `z00z_wallets::core::stealth` or `z00z_wallets::core::tx`.

**When implementing, use these types:**

```rust
// File (planned): crates/z00z_wallets/src/core/stealth/recent_r_cache.rs
// ❌ NOT YET IMPLEMENTED — spec below is a TODO design, NOT actual code

use std::collections::HashMap;

/// Per-wallet cache of recently-used R_pub values.
/// Detects accidental ephemeral key repeats (catastrophic RNG failure guard).
///
/// Key type: [u8; 32] (encoded R_pub or view_pk)  ← CORRECT
/// NOT: CompressedRistretto (curve25519_dalek) — direct dalek types are not
/// part of z00z_wallets public contracts.
pub struct RecentRCache {
    /// Map: receiver_view_pk:[u8;32] → recent r_pub values Vec<[u8;32]>
    cache: HashMap<[u8; 32], Vec<[u8; 32]>>,
    /// Maximum entries per receiver (default: 100)
    max_entries: usize,
}

/// TODO: impl RecentRCache
/// - check_and_insert(view_pk: &[u8;32], r_pub: &[u8;32]) -> Result<(), StealthError>
/// - clear_receiver(view_pk: &[u8;32])
///
/// Error variant to add to StealthError: RepeatDetected
```

**Integration with Phase 1 (actual API, NOT legacy pseudocode):**

```rust
// ✅ ACTUAL entry point into stealth output creation:
// File: crates/z00z_wallets/src/core/stealth/output.rs

use z00z_wallets::core::stealth::output::build_tx_stealth_output;
use z00z_wallets::core::stealth::output::{TxStealthOutput, SenderWallet};

// Actual signature as of codebase:
pub fn build_tx_stealth_output(
    receiver_card: &ReceiverCard,
    payment_request: Option<&PaymentRequest>,
    sender_wallet: &SenderWallet,    // SenderWallet { secret_salt: [u8;32] }
    tx_digest: &[u8; 32],
    out_index: u32,
    amount: u64,
    asset_id: &[u8; 32],
) -> Result<TxStealthOutput, StealthError>

// TxStealthOutput { r_pub:[u8;32], owner_tag:[u8;32], tag16:Option<u16>,
//                   enc_pack:ZkPackEncrypted, c_amount:[u8;32] }

// RecentRCache check would be added INSIDE build_tx_stealth_output
// once implemented (it is a TODO).
```

> ⚠️ Types `ValidatedPaymentInput`, `OutputLeaf`, `SenderWitness`, `OutputError`, `create_output_leaf()` do **NOT exist** in codebase.

**Examples:**

- "VM snapshot → all subsequent outputs linkable"
- "Mobile low entropy → predictable r values"
- "Container RNG misconfiguration → r repeats"

```yaml
recommendation:
  action: "Implement H-3 BEFORE any other output creation code"
  test_vectors: "Use Z00Z-ECC-IDEAS.md test vectors for validation"
  review: "Mandatory security review of RNG handling"
```




---

#### ✅ Implementation Checklist — Phase 10: Sender-Side Validation Overview

> **Scope:** Architecture decision and scaffolding  
> **Status:** ❌ NOT started. Design decision must be made before coding.

- [ ] **Architecture decision: where does sender-side validation live?**:
  - [ ] Option A: `output_validator.rs` module in `z00z_wallets/src/core/stealth/`
  - [ ] Option B: inline in `build_tx_stealth_output()` behind `#[cfg(feature)]`
  - [ ] **Decision: Option A** — separate `output_validator.rs` (confirmed per spec §5.3)
- [ ] **Create skeleton files**:
  - [ ] `crates/z00z_wallets/src/core/stealth/output_validator.rs` — new file
  - [ ] `crates/z00z_wallets/src/core/stealth/error.rs` — add `ValidationError` enum
  - [ ] Register `output_validator` in `mod.rs`
- [ ] **Feature flag** setup in `Cargo.toml`:
  - [ ] Add `paranoid-validation = []` to `[features]`
  - [ ] `build_tx_stealth_output_validated()` gated by `#[cfg(feature = "paranoid-validation")]`
- [ ] **Document `SenderValidationContext` struct** (partial spec):
  - [ ] Fields: `receiver_card: &ReceiverCard`, `asset_id: Z00ZScalar`, `amount: u64`, `r: Z00ZScalar`
  - [ ] All fields needed to re-derive and verify output contents
  - [ ] `r` held in memory only during validation; zeroed afterward
- [ ] **High-level validation capabilities that MUST be implemented** (list for spec readers):
  - [ ] Self-decryption check (re-derive s, p, k and verify stealth_pk) → Phase 12
  - [ ] Commitment consistency check (verify C = p·G + asset_id·H) → Phase 13
  - [ ] Asset ID consistency check (verify asset_tag) → Phase 14
  - [ ] Owner tag verification (verify tag16) → Phase 15
  - [ ] Orchestrator combining all checks → Phase 16
- [ ] **Unit tests** (skeleton tests, can be `#[ignore]` initially):
  - [ ] `test_output_validator_module_exists` — import succeeds
  - [ ] `test_validation_context_creation` — struct can be constructed
  - [ ] `test_feature_flag_paranoid_gating` — `build_tx_stealth_output_validated` absent without feature

---

---

### 👉🏾Phase 10 — Sender-Side Validation Overview

### 5.3 Output Validation (Sender-Side)

> ❌ **NOT YET IMPLEMENTED** — `validate_output_self()` and associated types do NOT exist in codebase.  
> 📌 The architectural intent (§5.3) is valid and correct.  

> ⚠️ **Architectural Constraint — k_dh Availability:**  
> `k_dh` is an ephemeral intermediate value computed inside `build_tx_stealth_output()`.
> It is **NOT stored** anywhere after the function returns, and there is no way to recover
> it without also re-running the ECDH (which requires the ephemeral scalar `r` — also discarded).
>
> **Consequence:** `validate_output_self()` CANNOT be implemented as a standalone
> post-creation function called from outside with just a `TxStealthOutput`.
>
> **Required implementation pattern (mandatory):** Validation MUST be invoked INSIDE
> `build_tx_stealth_output()` before `k_dh` and `r` go out of scope. The
> `build_tx_stealth_output_validated()` sketch in §5.3.3 Phase 6 (with
> `#[cfg(feature = "paranoid-validation")]`) represents the only architecturally sound
> implementation path.
>
> ⚠️ All Rust code blocks in §5.3 use legacy/wrong type names. Corrections:
>
> - `OutputLeaf` → `AssetLeaf` (`z00z_core::assets::leaf`)
> - `SenderWitness` → internal to `build_tx_stealth_output()`; no public witness struct yet
> - `AssetPackPlainV1` → `AssetPackPlain` (`z00z_core::assets`)
> - `CompressedRistretto` → `[u8; 32]`
> - `ValidationError` → TODO; add to `StealthError` or a new enum
> - `validate_output_self()` → TODO; implement in `z00z_wallets::core::stealth`
> - `z00z_core::tx::*` → `z00z_wallets::core::stealth::output::*`
>
> **What IS implemented** (use these instead):
>
> - `verify_owner_tag(receiver_keys, r_pub, owner_tag)` in `output.rs`
> - `verify_owner_two_factor(receiver_secret, r_pub, owner_tag, s_out, serial_id)` in `output.rs`
> - `build_tx_stealth_output()` — performs creation + internal consistency; no separate post-creation validation yet.

**Purpose:** Local validation checks performed by sender AFTER creating output, BEFORE submitting to aggregator. This is paranoid self-check + early bug detection layer.

**Source:** `crates/Z00Z-ECC-IDEAS.md` lines 750-950 (OWF constraints, M1 check rationale, receiver opening requirements).

**Security Rationale:**

🎯 **Why validate after creation?**

- **Paranoid check**: Catch implementation bugs in output creation (Section 5.2) before submitting
- **Early detection**: Find errors locally (cheap) vs after checkpoint acceptance (expensive)
- **Self-consistency**: Verify all cryptographic components are mathematically aligned
- **UX protection**: Prevent sending "broken" outputs that receiver cannot process

⚠️ **What could go wrong without validation?**

- Encryption bug → receiver cannot decrypt → funds lost
- Commitment mismatch → receiver decrypts but commitment doesn't open → OWF fails
- Asset ID error → wrong asset identity → wallet confusion
- Owner tag error → receiver passes decryption but fails M1 check → "decryptable-but-not-spendable"

---

### 5.3.1 Overview: Four Validation Checks

**High-Level Flow:**

```text
TxStealthOutput + sender_wallet (from Section 5.2)
    ↓
[1] Self-Decryption Check
    Can sender decrypt own enc_pack?
    ↓
[2] Commitment Consistency
    Does C_amount == Commit(amount, blinding)?
    ↓
[3] Asset ID Consistency
    Does asset_id == H_zk("Z00Z/ASSET" || derive_s_out(k_dh, r_pub, 0))?
    (s_out is DERIVED deterministically — verify caller's contract)
    ↓
[4] Owner Tag Verification
    Does owner_tag == H_zk("Z00Z/TAG" || owner_handle || k_dh)?
    ↓
✅ All checks passed → safe to submit
❌ Any check failed → reject output, log error
```

**Validation Components:**

| Check | What | Why | Integration |
| --- | --- | --- | --- |
| **Self-Decryption** | Decrypt enc_pack using k_dh | Proves receiver can decrypt | Section 4.6 (`ZkPack::decrypt()`, ⚠️ `EncryptedPack` does NOT exist) |
| **Commitment** | Verify C_amount opens to (amount, blinding) | Proves OWF constraint satisfied | Section 4.4 (Pedersen) |
| **Asset ID** | Verify asset_id derived from s_out | Proves asset identity correct | `z00z_crypto::hash` |
| **Owner Tag** | Verify owner_tag binds to owner_handle | Proves receiver can pass M1 check | Section 5.2.9 |

**Module Structure:**

```text
z00z_wallets/                         # ✅ ACTUAL planned location
└── src/
    └── core/
        └── stealth/
            ├── output_validator.rs    # TODO: Validation logic (this section)
            ├── output.rs              # ✅ Creation logic (build_tx_stealth_output)
            └── mod.rs                 # Re-exports

⚠️ z00z_core/src/tx/ does NOT exist
⚠️ output_builder.rs, output_leaf.rs do NOT exist
```

---

### 5.3.2 Validation Diagram

```mermaid
flowchart TD
    Start["TxStealthOutput + sender_wallet (from Section 5.2)"] --> Check1{"Check 1: Self-Decryption"}
    
    Check1 -->|"Compute k_dh"| Decrypt["Decrypt enc_pack with leaf_ad"]
    Decrypt -->|"Success"| Parse["Parse AssetPackPlain (72 bytes)"]
    Parse --> ExtractValues["Extract s_out, amount, blinding, serial_id"]
    
    Decrypt -->|"Failure"| Error1["❌ ValidationError::SelfDecryptionFailed"]
    Error1 --> End
    
    ExtractValues --> Check2{"Check 2: Commitment Consistency"}
    Check2 --> ComputeC["C_test = Commit(amount, blinding)"]
    ComputeC -->|"Match"| Check3{"Check 3: Asset ID Consistency"}
    ComputeC -->|"Mismatch"| Error2["❌ ValidationError::CommitmentMismatch"]
    Error2 --> End
    
    Check3 --> ComputeAsset["asset_id_test = H_zk(ASSET concat s_out)"]
    ComputeAsset -->|"Match"| Check4{"Check 4: Owner Tag"}
    ComputeAsset -->|"Mismatch"| Error3["❌ ValidationError::AssetIdMismatch"]
    Error3 --> End
    
    Check4 --> ComputeTag["owner_tag_test = H_zk(TAG concat owner_handle concat k_dh)"]
    ComputeTag -->|"Match"| Success["✅ All checks passed"]
    ComputeTag -->|"Mismatch"| Error4["❌ ValidationError::OwnerTagMismatch"]
    Error4 --> End
    
    Success --> Submit["Safe to submit to aggregator"]
    
    style Check1 fill:#ffa
    style Check2 fill:#aff
    style Check3 fill:#faf
    style Check4 fill:#afa
    style Success fill:#8f8
    style Error1 fill:#f88
    style Error2 fill:#f88
    style Error3 fill:#f88
    style Error4 fill:#f88

```

---

#### ✅ Implementation Checklist — Phase 11: Validation Core Infrastructure

> **File:** `crates/z00z_wallets/src/core/stealth/output_validator.rs`  
> **Status:** ❌ NOT implemented.

- [ ] **Enum `ValidationError`** in `error.rs`:
  - [ ] `SelfDecryptionFailed` — re-derived stealth_pk doesn't match stored
  - [ ] `CommitmentMismatch` — re-computed commitment doesn't match stored
  - [ ] `AssetIdMismatch` — asset_tag doesn't match expected value
  - [ ] `OwnerTagMismatch` — tag16 doesn't match expected value
  - [ ] `InvalidPublicKey` — bad point in output
  - [ ] Derives `thiserror::Error`, `Debug`
  - [ ] All variants have `#[error("...")]` messages
- [ ] **Struct `SenderValidationContext`**:
  - [ ] `receiver_card: &ReceiverCard` — reference, not owned
  - [ ] `asset_id: Z00ZScalar`
  - [ ] `amount: u64`
  - [ ] `r: Z00ZScalar` — ephemeral scalar; held only during validation
  - [ ] `zeroize` impl or `Hidden<Z00ZScalar>` for `r` field
- [ ] **Re-derive shared secret helper** (private):
  - [ ] `fn recompute_s(r: &Z00ZScalar, view_pk: &[u8;32]) -> Result<Z00ZScalar, ValidationError>`
  - [ ] Same computation as step 4 of `build_tx_stealth_output()`
  - [ ] Returns `ValidationError::InvalidPublicKey` if view_pk decompression fails
- [ ] **Unit tests** (infrastructure level):
  - [ ] `test_validation_error_display_messages` — all variants have non-empty messages
  - [ ] `test_recompute_s_matches_build` — shared secret from builder == recomputed
  - [ ] `test_context_r_field_zeroize` — memory is zeroed after drop (use `zeroize` test pattern)

### 5.3.3 Implementation Phases

**Recommended incremental implementation approach:**

### 👉🏾Phase 11 — Validation Core Infrastructure

#### Phase 11a: Core Validation Infrastructure (~200 lines)

**Deliverables:**

- `ValidationError` enum with all error types
- `ValidationResult` type alias
- `validate_output_self()` orchestrator function skeleton
- Basic error propagation infrastructure

**Module (planned):** `z00z_wallets/src/core/stealth/output_validator.rs`

> ❌ NOT YET IMPLEMENTED. Correct type sketch when implementing:

```rust
// File (planned): crates/z00z_wallets/src/core/stealth/output_validator.rs
// TODO: implement validate_output_self()

use thiserror::Error;
use z00z_wallets::core::stealth::output::TxStealthOutput; // replaces "OutputLeaf"
use z00z_core::assets::AssetPackPlain;                    // replaces "AssetPackPlainV1"
// NOTE: "SenderWitness" does not exist. k_dh must be recomputed from sender_wallet.

#[derive(Debug, Error)]
pub enum ValidationError {
    #[error("Self-decryption failed: {0}")]
    SelfDecryptionFailed(String),

    #[error("Commitment mismatch")]
    CommitmentMismatch { expected: [u8; 32], actual: [u8; 32] },  // [u8;32], NOT CompressedRistretto

    #[error("Asset ID mismatch")]
    AssetIdMismatch { expected: [u8; 32], actual: [u8; 32] },

    #[error("Owner tag mismatch")]
    OwnerTagMismatch { expected: [u8; 32], actual: [u8; 32] },

    #[error("Stealth error: {0}")]
    Stealth(#[from] z00z_wallets::core::stealth::StealthError),
}

pub type ValidationResult<T> = Result<T, ValidationError>;

/// TODO: Validate sender's own output after creation.
/// 
/// Takes the output produced by build_tx_stealth_output() plus the precomputed k_dh,
/// owner_handle (from ReceiverCard), and asset_id (from the creation call), and verifies
/// all 4 invariants:
///   1. Self-decryption: can sender decrypt own enc_pack?
///   2. Commitment consistency: C_amount == Commit(amount, blinding)?
///   3. Asset ID consistency: asset_id == H_zk("Z00Z/ASSET" || s_out)?
///   4. Owner tag: owner_tag == H_zk("Z00Z/TAG" || owner_handle || k_dh)?
///
/// Note: verify_owner_tag() from output.rs covers check 4 partially;
/// the full validate_output_self() is not yet wired.
///
/// ⚠️ k_dh must be recomputed from sender_wallet after creation (via ECDH with r and view_pk).
/// There is no SenderWitness struct — pass k_dh directly as &[u8;32].
pub fn validate_output_self(
    output: &TxStealthOutput,
    k_dh: &[u8; 32],                   // recomputed ECDH key — NOT SenderWitness (does not exist)
    owner_handle: &[u8; 32],           // from ReceiverCard.owner_handle
    asset_id: &[u8; 32],               // external param from build_tx_stealth_output call
) -> ValidationResult<()> {
    todo!("Implement validation checks — see §5.3.3 Phase 6 for complete orchestrator")
}
```



---

#### ✅ Implementation Checklist — Phase 12: Self-Decryption Check

> **File:** `crates/z00z_wallets/src/core/stealth/output_validator.rs`  
> **Status:** ❌ NOT implemented.

- [ ] **Function `check_self_decryption(ctx: &SenderValidationContext, output: &TxStealthOutput) -> Result<(), ValidationError>`**:
  - [ ] Step 1: re-derive `s_out` using `recompute_s(&ctx.r, &ctx.receiver_card.view_pk)`
  - [ ] Step 2: re-derive `k_out = h2s_zk::<StealthKeyDomain>("K", &[s_out.as_bytes(), &ctx.receiver_card.owner_handle])`
  - [ ] Step 3: compute expected `stealth_pk = k_out · G + identity_pk_point`
  - [ ] Step 4: compress expected stealth_pk to `[u8; 32]`
  - [ ] Step 5: constant-time compare `expected_stealth_pk == output.stealth_pk`
  - [ ] Return `Err(SelfDecryptionFailed)` if mismatch; `Ok(())` if match
  - [ ] Identity point check: if re-derived stealth_pk is identity → `Err(InvalidPublicKey)`
- [ ] **ZkPack decrypt helper** (private function or method):
  - [ ] `ZkPack::decrypt(s_out: Z00ZScalar) -> Result<AssetPackPlain, ValidationError>`
  - [ ] Re-decrypts the ZkPack using the shared secret
  - [ ] Returns `AssetPackPlain { p_out: Z00ZScalar, asset_id: Z00ZScalar }`
- [ ] **Struct `AssetPackPlain`**:
  - [ ] `p_out: Z00ZScalar` — decrypted blinding factor
  - [ ] `asset_id: Z00ZScalar` — decrypted asset identifier
  - [ ] Derive `Zeroize` and `Drop` (zeroize on drop)
- [ ] **Unit tests** (all must pass):
  - [ ] `test_self_decrypt_success` — correct ctx with freshly-built output → Ok
  - [ ] `test_self_decrypt_wrong_r` — different r value → SelfDecryptionFailed
  - [ ] `test_self_decrypt_wrong_view_pk` — different receiver_card → SelfDecryptionFailed
  - [ ] `test_self_decrypt_tampered_stealth_pk` — modified output.stealth_pk → SelfDecryptionFailed
  - [ ] `test_zk_pack_decrypt_matches_original` — decrypted p_out == original p_out
  - [ ] `test_asset_pack_plain_zeroize` — fields zeroed after drop

---

### 👉🏾Phase 12 — Self-Decryption Check

#### Phase 12a: Self-Decryption Check (~150 lines)

**What it validates:**

- Sender can decrypt own enc_pack using recomputed k_dh
- Decrypted plaintext parses correctly to `AssetPackPlain` (72 bytes, NOT `AssetPackPlainV1`)
- All fields (value, blinding, s_out) match expected derived values

**Implementation:**

```rust
/// Check 1: Verify sender can decrypt own enc_pack
///
/// # Security Notes
/// - Uses same decryption path as receiver (Section 6)
/// - If this fails, receiver will also fail to decrypt
/// - Early detection of encryption bugs
///
/// # Arguments
/// - `output`: `TxStealthOutput` with enc_pack to decrypt (NOT `OutputLeaf` — does not exist)
/// - `k_dh`: recomputed DH key (NOT `SenderWitness` — does not exist)
///
/// # Returns
/// - `Ok(AssetPackPlain)`: Successfully decrypted and parsed (NOT `AssetPackPlainV1`)
/// - `Err(ValidationError::SelfDecryptionFailed)`: Decryption or parsing failed
fn verify_self_decryption(
    output: &TxStealthOutput,  // use TxStealthOutput, NOT OutputLeaf
    k_dh: &[u8; 32],           // pass recomputed k_dh directly; no SenderWitness type
    asset_id: &[u8; 32],       // ⚠️ NOT a field of TxStealthOutput — must pass separately
    serial_id: u32,             // ⚠️ NOT a field of TxStealthOutput (hardcoded 0u32 at creation time)
) -> ValidationResult<AssetPackPlain> {  // return AssetPackPlain, NOT AssetPackPlainV1
    // ⚠️ TxStealthOutput fields: r_pub, owner_tag, tag16, enc_pack, c_amount
    //    NO asset_id field, NO serial_id field — these must be passed as parameters
    // Step 1: Compute leaf_ad (anti-malleability binding)
    // ⚠️ compute_leaf_ad_for_output() does NOT exist — use compute_leaf_ad()
    let leaf_ad = compute_leaf_ad(
        asset_id,               // external param; NOT output.asset_id (field doesn't exist)
        serial_id,              // external param; NOT output.serial_id (field doesn't exist)
        &output.r_pub,          // lowercase snake_case; NOT output.R_pub (wrong casing)
        &output.owner_tag,
        &output.c_amount,       // lowercase snake_case; NOT output.C_amount (wrong casing)
    );
    
    // Step 2: Decrypt using ZkPack::decrypt — NOT output.enc_pack.decrypt() (wrong method/API)
    // ⚠️ ZkPack::decrypt(k_dh, leaf_ad, r_pub, asset_id, serial_id, enc) -> Option<Vec<u8>>
    //    Returns None on AEAD failure (no Result — use .ok_or_else())
    let plaintext_bytes = ZkPack::decrypt(
        k_dh,
        &leaf_ad,
        &output.r_pub,
        asset_id,
        serial_id,
        &output.enc_pack,
    ).ok_or_else(|| ValidationError::SelfDecryptionFailed(
        "AEAD authentication failed (wrong k_dh or tampered ciphertext)".into()
    ))?;
    
    // Step 3: Parse AssetPackPlain from plaintext (NOT AssetPackPlainV1)
    // ⚠️ AssetPackPlain::from_bytes() returns Option<Self>, NOT Result<Self, E>
    //    Use .ok_or_else(), NOT .map_err() — there is no error value to map
    let asset_pack = AssetPackPlain::from_bytes(&plaintext_bytes)
        .ok_or_else(|| ValidationError::SelfDecryptionFailed(
            "AssetPackPlain parse failed: invalid length or format (expected exactly 72 bytes)".into()
        ))?;
    
    // Step 4: Verify decrypted values
    // NOTE: s_out is DERIVED deterministically from (k_dh, r_pub, serial_id=0)
    // ⚠️ derive_s_out() is a PRIVATE fn in output.rs — NOT importable from output_validator.rs.
    //    Inline the same formula here:
    //    TODO: Consider making derive_s_out pub(crate) to eliminate this duplication:
    //      pub(crate) fn derive_s_out(k_dh: &[u8;32], r_pub: &[u8;32], serial_id: u32) -> [u8;32]
    //    Drift risk: any change to derive_s_out MUST be manually reflected in this copy.
    use z00z_wallets::core::domains::SOutProdDomain;
    let expected_s_out = hash_zk::<SOutProdDomain>("Z00Z/S_OUT", &[k_dh, &output.r_pub, &0u32.to_le_bytes()]);
    if asset_pack.s_out != expected_s_out {
        return Err(ValidationError::SelfDecryptionFailed(
            "Decrypted s_out does not match H_zk(S_OUT, k_dh, r_pub, 0)".into()
        ));
    }
    // NOTE: no witness struct — 'v' comes from the amount used at creation time;
    // pass expected amount inline or via a simple struct (not SenderWitness)

    Ok(asset_pack)
}

/// Helper: Derive pack_key (matches Section 5.2.12 encryption)
/// ✅ Already implemented in z00z_wallets::core::stealth::facade_kdf::derive_pack_key()
/// ⚠️ NOTE: verify_self_decryption() no longer calls this directly — ZkPack::decrypt()
///          handles pack_key derivation internally. Keep for other callers.
fn derive_pack_key(
    k_dh: &[u8; 32],
    asset_id: &[u8; 32],    // pass by reference; NOT by value
    serial_id: u32,
) -> [u8; 32] {             // ⚠️ infallible — NO ValidationResult wrapper; returns [u8;32] directly
    // ✅ actual: hash_zk::<PackKeyProdDomain>("Z00Z/PACKKEY", &[k_dh, asset_id, &serial_id.to_le_bytes()])
    // ⚠️ ZkHash::new_with_domain() does NOT exist — use hash_zk::<D>() from z00z_crypto::hash
    use z00z_wallets::core::stealth::facade_kdf::derive_pack_key as impl_derive_pack_key;
    impl_derive_pack_key(k_dh, asset_id, serial_id)
}
```

**Integration:**

- ✅ Uses `z00z_wallets::core::stealth::facade_kdf::derive_pack_key()` (Section 5.2.12, ✅ implemented)
- ✅ Uses `compute_leaf_ad()` from `z00z_wallets::core::stealth::tag` (NOT `compute_leaf_ad_for_output` — does not exist)
- ✅ Uses `AssetPackPlain::from_bytes()` (72 bytes; NOT `AssetPackPlainV1::from_bytes`)
- ⚠️ `derive_s_out()` is a **private** `fn` in `output.rs` — use the inline formula `hash_zk::<SOutProdDomain>("Z00Z/S_OUT", &[k_dh, r_pub, &serial_id.to_le_bytes()])` instead; do NOT import as if it were public

---

#### ✅ Implementation Checklist — Phase 13: Commitment Consistency Check

> **File:** `crates/z00z_wallets/src/core/stealth/output_validator.rs`  
> **Status:** ❌ NOT implemented.

- [ ] **Function `check_commitment(ctx: &SenderValidationContext, output: &TxStealthOutput) -> Result<(), ValidationError>`**:
  - [ ] Step 1: decrypt ZkPack → `plain = ZkPack::decrypt(s_out)?` → gives `p_out`, `asset_id`
  - [ ] Step 2: re-compute commitment: `C_expected = p_out · G + asset_id · H`
    - [ ] Uses `PedersenCommitmentFactory` from `z00z_crypto`
    - [ ] H = `RISTRETTO_BASEPOINT_TABLE` with domain-separated scalar, per project convention
  - [ ] Step 3: compress `C_expected` to `[u8; 32]`
  - [ ] Step 4: constant-time compare `C_expected == output.commitment`
  - [ ] Return `Err(CommitmentMismatch)` if differ; `Ok(())` if match
- [ ] **Verify `p_out` encodes `amount`**:
  - [ ] `p_out = mask + Z00ZScalar::from(amount)` where `mask = h2s_zk::<ValueMaskDomain>("P", &[s_out])`
  - [ ] Verify that `p_out - mask == Z00ZScalar::from(ctx.amount)`
  - [ ] Return `CommitmentMismatch` if this check fails
- [ ] **Unit tests** (all must pass):
  - [ ] `test_commitment_check_success` — valid output → Ok
  - [ ] `test_commitment_check_wrong_amount` — output built with amount=1000, ctx.amount=999 → CommitmentMismatch
  - [ ] `test_commitment_check_wrong_asset_id` — different asset_id in context → CommitmentMismatch
  - [ ] `test_commitment_check_tampered_bytes` — flip bit in output.commitment → CommitmentMismatch
  - [ ] `test_commitment_check_p_out_encodes_amount` — verify p_out - mask == amount

---

### 👉🏾Phase 13 — Commitment Consistency Check

#### Phase 13a: Commitment Consistency Check (~120 lines)

**What it validates:**

- C_amount commitment opens to decrypted (amount, blinding)
- Uses same Pedersen factory as OWF will use
- Verifies anti-burn property locally

**Implementation:**

```rust
/// Check 2: Verify commitment consistency
///
/// # Security Notes
/// - Critical for OWF correctness (constraint 4)
/// - If this fails, OWF will reject output
/// - Proves receiver can open Pedersen commitment
///
/// # Arguments
/// - `output`: `TxStealthOutput` with c_amount (NOT `OutputLeaf`)
/// - `asset_pack`: Decrypted `AssetPackPlain` with value and blinding (NOT `AssetPackPlainV1`)
///
/// # Returns
/// - `Ok(())`: Commitment opens correctly
/// - `Err(ValidationError::CommitmentMismatch)`: Commitment does not open
fn verify_commitment_consistency(
    output: &TxStealthOutput,
    asset_pack: &AssetPackPlain,
) -> ValidationResult<()> {
    use z00z_crypto::{
        create_commitment,  // ⚠️ NOT factory.commit_value — use create_commitment(amount, &Z00ZScalar)
        Z00ZScalar,         // ⚠️ NOT RistrettoSecretKey — blinding is Z00ZScalar
    };
    
    // Step 1: Parse blinding factor from asset_pack
    // ⚠️ Z00ZScalar, NOT RistrettoSecretKey::from_bytes (wrong type)
    let blinding = Z00ZScalar::from_canonical_bytes(&asset_pack.blinding)  // field: blinding, NOT r_out
        .map_err(|_| ValidationError::SelfDecryptionFailed(   // ⚠️ from_canonical_bytes returns Result, NOT Option — use .map_err, NOT .ok_or_else
            "Invalid blinding factor: non-canonical scalar bytes".into()
        ))?;
    
    // Step 2: Compute expected commitment using create_commitment (NOT factory.commit_value)
    // ⚠️ create_commitment(amount: u64, blinding: &Z00ZScalar) -> Result<Z00ZCommitment, _>
    let c_expected = create_commitment(asset_pack.value, &blinding)         // field: value, NOT v
        .map_err(|e| ValidationError::SelfDecryptionFailed(
            format!("Commitment creation failed: {}", e)
        ))?;
    
    // Step 3: Convert to [u8; 32] and compare with output.c_amount (lowercase; NOT C_amount)
    // ⚠️ c_expected.to_compressed() does NOT exist — use as_bytes() and try_into()
    let c_bytes: [u8; 32] = c_expected.as_bytes()
        .try_into()
        .map_err(|_| ValidationError::SelfDecryptionFailed(
            "Commitment bytes length mismatch".into()
        ))?;
    
    if c_bytes != output.c_amount {
        return Err(ValidationError::CommitmentMismatch {
            expected: c_bytes,
            actual: output.c_amount,
        });
    }
    
    Ok(())
}
```

**Integration:**

- ⚠️ Uses `Z00ZScalar` for blinding factor (NOT `RistrettoSecretKey` — wrong type)
- ⚠️ Uses `create_commitment(amount, &Z00ZScalar)` (NOT `factory.commit_value()` — wrong API)
- ✅ Uses `HomomorphicCommitmentFactory` concept (via `create_commitment` wrapper)
- ✅ Verifies same computation as OWF constraint 4

**Mathematical Property:**

Given:

- `v` ∈ [0, 2^64) (amount)
- `blinding` ∈ ℤ_q (blinding factor, scalar; field `AssetPackPlain::blinding`)
- `C_amount = amount*H + blinding*G` (Pedersen commitment)

Verify:

```text
Commit(amount, blinding) == C_amount
```

If this holds, receiver can:

1. Decrypt enc_pack → get (amount, blinding)
2. Prove C_amount opens to v (without revealing v publicly)
3. Include this asset in balance proof

---

#### ✅ Implementation Checklist — Phase 14: Asset ID Consistency Check

> **File:** `crates/z00z_wallets/src/core/stealth/output_validator.rs`  
> **Status:** ❌ NOT implemented.

- [ ] **Function `check_asset_id(ctx: &SenderValidationContext, output: &TxStealthOutput) -> Result<(), ValidationError>`**:
  - [ ] Step 1: re-derive s_out from ctx.r and receiver_card.view_pk
  - [ ] Step 2: `expected_asset_tag = h2s_zk::<AssetIdDomain>("", &[s_out.as_bytes()])`
    - [ ] **CRITICAL:** Label is `""` (empty string), NOT `"A"` or `"Z00Z/ASSET"`
    - [ ] Domain: `AssetIdDomain` defined in `crates/z00z_wallets/src/core/domains.rs`
  - [ ] Step 3: constant-time compare `expected_asset_tag.as_bytes() == &output.asset_tag`
  - [ ] Return `Err(AssetIdMismatch)` if differ; `Ok(())` if match
- [ ] **`AssetIdDomain` hash domain**:
  - [ ] Defined via `hash_domain!` macro: `"z00z.wallet.stealth.asset_id.prod.v1"`
  - [ ] Located in `crates/z00z_wallets/src/core/domains.rs` alongside other domains
  - [ ] NOT the same domain as any validation-side domain
- [ ] **Unit tests** (all must pass):
  - [ ] `test_asset_id_check_success` — correct ctx → Ok
  - [ ] `test_asset_id_check_wrong_asset` — different asset_id in ctx → AssetIdMismatch
  - [ ] `test_asset_id_check_tampered_tag` — flip bit in output.asset_tag → AssetIdMismatch
  - [ ] `test_asset_id_tag_deterministic` — same inputs always produce same asset_tag value
  - [ ] `test_asset_id_empty_label_used` — using `"a"` label produces different result (domain test)

---

### 👉🏾Phase 14 — Asset ID Consistency Check

#### Phase 14a: Asset ID Consistency Check (~80 lines)

**What it validates:**

- asset_id derived correctly from s_out (caller contract for `build_tx_stealth_output`)
- Uses actual hash domain used in production (NOT `ZkHash::new_with_domain` — does NOT exist)
- ⚠️ `TxStealthOutput` has NO `asset_id` field — must pass `asset_id` as separate parameter

**Implementation:**

```rust
/// Check 3: Verify asset ID consistency
///
/// # Security Notes
/// - Ensures asset identity is deterministic from s_out
/// - Prevents "wrong asset_id" bugs in output creation
/// - Must match OWF constraint and receiver derivation
///
/// # Arguments
/// - `asset_id`: External `asset_id` param from `build_tx_stealth_output()` (NOT a field of `TxStealthOutput`)
/// - `asset_pack`: Decrypted `AssetPackPlain` with s_out (NOT `AssetPackPlainV1`)
///
/// # Returns
/// - `Ok(())`: Asset ID matches H_zk("Z00Z/ASSET" || s_out)
/// - `Err(ValidationError::AssetIdMismatch)`: Asset ID does not match
fn verify_asset_id_consistency(
    asset_id: &[u8; 32],        // external parameter; NOT a TxStealthOutput field
    asset_pack: &AssetPackPlain,  // NOT AssetPackPlainV1
) -> ValidationResult<()> {
    use z00z_crypto::{
        hash_zk::hash_zk,
        domains::AssetIdDomain,  // ⚠️ AssetIdProdDomain does NOT exist — use AssetIdDomain
    };
    
    // Step 1: Compute expected asset_id from s_out
    // ⚠️ ZkHash::new_with_domain does NOT exist — use hash_zk::<D> from z00z_crypto::hash_zk
    // ⚠️ AssetIdProdDomain does NOT exist — use AssetIdDomain (domain string: "Z00Z/ASSET")
    // ⚠️ label is "" (EMPTY STRING), NOT "Z00Z/ASSET"
    //    the domain string "Z00Z/ASSET" lives inside AssetIdDomain, not in the label argument
    let asset_id_expected = hash_zk::<AssetIdDomain>("", &[&asset_pack.s_out]);
    // actual call in codebase: hash_zk::<AssetIdDomain>("", &[s_out])
    
    // Step 2: Compare with external asset_id parameter
    if asset_id_expected != *asset_id {
        return Err(ValidationError::AssetIdMismatch {
            expected: asset_id_expected,
            actual: *asset_id,
        });
    }
    
    Ok(())
}
```

**Integration:**

- ⚠️ Use `AssetIdDomain` from `z00z_crypto::domains` (NOT `AssetIdProdDomain` — does not exist)
- ⚠️ Label argument is `""` (empty string), NOT `"Z00Z/ASSET"` — domain string is inside `AssetIdDomain`
- ⚠️ `ZkHash::new_with_domain("Z00Z/ASSET")` does **NOT exist** — use `hash_zk::<AssetIdDomain>("",...)`
- ✅ Matches receiver-side s_out derivation (Section 6)
- ✅ Matches OWF constraint for asset_id

**Mathematical Property:**

```text
asset_id = canonical public asset key carried by the output
```

Where:

- `asset_id` is the public leaf key used by downstream leaf/JMT logic
- `s_out` is the 32-byte asset secret — **DERIVED** deterministically: `H_zk("Z00Z/S_OUT" || k_dh || r_pub || serial_id_le4)` (⚠️ NOT random)
- `H_zk(domain || data)` remains domain-separated for ownership-side derivations such as `s_out` and `secret_tag`

---

#### ✅ Implementation Checklist — Phase 15: Owner Tag Verification

> **File:** `crates/z00z_wallets/src/core/stealth/output_validator.rs`  
> **Status:** ❌ NOT implemented.

- [ ] **Function `check_owner_tag(ctx: &SenderValidationContext, output: &TxStealthOutput) -> Result<(), ValidationError>`**:
  - [ ] Step 1: re-derive s_out from ctx.r and receiver_card.view_pk
  - [ ] Step 2: `hash_val = hash_zk::<OwnerTagDomain>("T16", &[s_out.as_bytes()])`
    - [ ] `hash_zk` returns `u64` or `[u8; 32]` — take lowest 2 bytes as `u16`
    - [ ] `expected_tag16 = (hash_val & 0xFFFF) as u16`
  - [ ] Step 3: compare `expected_tag16 == output.tag16`
  - [ ] Return `Err(OwnerTagMismatch)` if differ; `Ok(())` if match
  - [ ] NOT constant-time (tag16 is not secret; timing-safe not required here)
- [ ] **`OwnerTagDomain` hash domain**:
  - [ ] Defined: `"z00z.wallet.stealth.owner_tag.prod.v1"`
  - [ ] In `crates/z00z_wallets/src/core/domains.rs`
- [ ] **Type of `output.tag16`** — MUST be `u16`, NOT `Option<u16>`:
  - [ ] Confirm `TxStealthOutput.tag16: u16` in struct definition
  - [ ] If currently `Option<u16>` — schedule fix for Phase 23
- [ ] **Unit tests** (all must pass):
  - [ ] `test_owner_tag_check_success` — correct ctx → Ok
  - [ ] `test_owner_tag_check_wrong_r` — different r → OwnerTagMismatch
  - [ ] `test_owner_tag_check_wrong_view_pk` — different receiver_card → OwnerTagMismatch
  - [ ] `test_owner_tag_check_tampered_tag16` — `output.tag16 ^ 1` → OwnerTagMismatch
  - [ ] `test_tag16_is_u16_not_option` — type is `u16`; compiler test (can be a compile-check test)
  - [ ] `test_owner_tag_domain_separation` — OwnerTagDomain != AssetIdDomain for same input

---

### 👉🏾Phase 15 — Owner Tag Verification

#### Phase 15a: Owner Tag Verification (~100 lines)

**What it validates:**

- owner_tag binds to correct owner_handle and k_dh
- Receiver will pass M1 check (anti-phishing)
- Prevents "decryptable-but-not-spendable" attack

**Implementation:**

```rust
/// Check 4: Verify owner tag correctness
///
/// # Security Notes
/// - **CRITICAL (M1)**: Prevents "decryptable-but-not-spendable" attack
/// - Sender verifies receiver can pass M1 check at reception
/// - If this fails, output is toxic: decrypts but not spendable
///
/// # Arguments
/// - `output`: `TxStealthOutput` with owner_tag field (⚠️ `OutputLeaf` does NOT exist)
/// - `k_dh`: recomputed DH key directly (⚠️ `SenderWitness` does NOT exist)
///
/// # Returns
/// - `Ok(())`: Owner tag matches H_zk("Z00Z/TAG" || owner_handle || k_dh)
/// - `Err(ValidationError::OwnerTagMismatch)`: Owner tag does not match
///
/// # M1 Attack Scenario (what this check prevents)
/// Without this check, malicious sender could:
/// 1. Use correct view_pk for ECDH (victim can decrypt)
/// 2. Use WRONG owner_handle in owner_tag (not victim's handle)
/// 3. Result: Victim sees incoming asset, but cannot spend it
/// 4. UX catastrophe: "phantom balance" that's not spendable
// ⚠️ NAME COLLISION: A receiver-side public fn `verify_owner_tag(ReceiverKeys, r_pub, owner_tag)`
//    already exists in z00z_wallets::core::stealth::output. The sender-side validation
//    function below (for output_validator.rs) MUST use a different name to avoid ambiguity.
fn verify_sender_owner_tag(  // renamed from verify_owner_tag to avoid collision with receiver-side API
    output: &TxStealthOutput,  // NOT OutputLeaf
    k_dh: &[u8; 32], owner_handle: &[u8; 32],  // NOT SenderWitness
) -> ValidationResult<()> {
    use z00z_crypto::hash_zk::hash_zk;
    // ⚠️ WalletOwnerTagHashProdDomain lives in z00z_wallets::core::domains, NOT z00z_crypto::domains!
    // ⚠️ OwnerTagProdDomain does NOT exist — use WalletOwnerTagHashProdDomain
    use z00z_wallets::core::domains::WalletOwnerTagHashProdDomain;
    
    // Step 1: Compute expected owner_tag
    // ⚠️ ZkHash::new_with_domain does NOT exist — use hash_zk::<D>() from z00z_crypto::hash_zk
    // actual formula comes from compute_owner_tag() in output.rs (z00z_wallets)
    let owner_tag_expected = hash_zk::<WalletOwnerTagHashProdDomain>("Z00Z/TAG", &[owner_handle, k_dh]);
    
    // Step 2: Compare with output.owner_tag
    if owner_tag_expected != output.owner_tag {
        return Err(ValidationError::OwnerTagMismatch {
            expected: owner_tag_expected,
            actual: output.owner_tag,
        });
    }
    
    Ok(())
}
```

**Integration:**

- ⚠️ Use `WalletOwnerTagHashProdDomain` from `z00z_wallets::core::domains` (NOT `z00z_crypto::domains` — wrong crate; NOT `OwnerTagProdDomain` — does not exist)
- ✅ Uses `hash_zk::<WalletOwnerTagHashProdDomain>("Z00Z/TAG", ...)` (Section 5.2.9)
- ✅ Matches receiver-side M1 check (Section 6.2.5)
- ⚠️ Does NOT use `SenderWitness` (does not exist) — pass k_dh and owner_handle from ReceiverCard directly

**M1 Check Security Property (from crates/Z00Z-ECC-IDEAS.md lines 750-786):**

Receiver computes at reception:

```rust
owner_handle_self = H_zk("Z00Z/RID" || receiver_secret)
owner_tag_expected = H_zk("Z00Z/TAG" || owner_handle_self || k)

if owner_tag_expected != leaf.owner_tag {
    reject_as_not_spendable()
}
```

Sender verification here ensures:

- owner_tag in output was computed with CORRECT owner_handle from ReceiverCard
- Receiver will successfully pass M1 check
- Prevents "soft burn" where money looks incoming but is actually unspendable

---

#### ✅ Implementation Checklist — Phase 16: Complete Validation Orchestrator

> **File:** `crates/z00z_wallets/src/core/stealth/output_validator.rs`  
> **Status:** ❌ NOT implemented.

- [ ] **Function `validate_output_self(ctx: &SenderValidationContext, output: &TxStealthOutput) -> Result<(), ValidationError>`**:
  - [ ] Calls check functions in this exact order (fail-fast on first error):
    1. `check_self_decryption(ctx, output)?` → Phase 12
    2. `check_commitment(ctx, output)?` → Phase 13
    3. `check_asset_id(ctx, output)?` → Phase 14
    4. `check_owner_tag(ctx, output)?` → Phase 15
  - [ ] Returns `Ok(())` only if ALL four checks pass
  - [ ] Each error variant is distinct and unambiguous
- [ ] **Function `build_tx_stealth_output_validated()`** — gated by feature flag:

  ```rust
  #[cfg(feature = "paranoid-validation")]
  pub fn build_tx_stealth_output_validated(
      receiver_card: &ReceiverCard,
      asset_id: Z00ZScalar,
      amount: u64,
      rng: &mut impl CryptoRng + RngCore,
  ) -> Result<TxStealthOutput, BuildValidatedError>
  ```

  - [ ] Calls `build_tx_stealth_output()` to create output AND keeps `r` in scope
  - [ ] Calls `validate_output_self(ctx, &output)?` before returning
  - [ ] If validation fails → `Err(BuildValidatedError::ValidationFailed(e))`
  - [ ] Zeroes `r` scalar after validation completes
- [ ] **Enum `BuildValidatedError`** (only with `paranoid-validation`):
  - [ ] `BuildFailed(StealthError)` — from `build_tx_stealth_output()`
  - [ ] `ValidationFailed(ValidationError)` — from `validate_output_self()`
  - [ ] Implements `Display` and `From<StealthError>`, `From<ValidationError>`
- [ ] **Batch validation function** (optional, SHOULD):
  - [ ] `validate_outputs_batch(pairs: &[(SenderValidationContext, TxStealthOutput)]) -> Vec<Result<(), ValidationError>>`
  - [ ] Validates each pair independently (NOT short-circuit)
  - [ ] Returns one Result per pair
- [ ] **Unit tests** (all must pass):
  - [ ] `test_orchestrator_all_checks_pass` — valid output + correct ctx → Ok
  - [ ] `test_orchestrator_fails_on_first_error` — tampered stealth_pk → SelfDecryptionFailed (not CommitmentMismatch)
  - [ ] `test_build_validated_succeeds` — feature=paranoid, correct inputs → Ok
  - [ ] `test_build_validated_propagates_validation_error` — forced tamper mid-build → ValidationFailed
  - [ ] `test_build_validated_absent_without_feature` — compile-time check (use cfg_attr test)
  - [ ] `test_batch_validates_independently` — second invalid doesn't affect first valid

---

### 👉🏾Phase 16 — Complete Validation Orchestrator

#### Phase 16a: Complete Orchestrator (~150 lines)

**What it provides:**

- Single entry point for all validation
- Sequential execution of all 4 checks
- Clear error reporting with context
- Integration with Section 5.2 output creation

**Implementation:**

```rust
/// Complete sender-side validation of newly created output
///
/// # Purpose
/// Paranoid self-check after output creation (Section 5.2) before submission.
/// Catches bugs early and ensures output is well-formed.
///
/// # Validation Sequence
/// 1. Self-decryption: Can sender decrypt own enc_pack?
/// 2. Commitment: Does C_amount open to decrypted (amount, blinding)?
/// 3. Asset ID: Does asset_id match H_zk(s_out)?
/// 4. Owner Tag: Does owner_tag match expected for receiver?
///
/// # Arguments
/// - `output`: `TxStealthOutput` (NOT `OutputLeaf` — does not exist)
/// - `k_dh`: recomputed DH key (NOT `SenderWitness` — does not exist)
/// - `owner_handle`: from ReceiverCard.owner_handle
/// - `asset_id`: external param from build_tx_stealth_output call
///
/// # Returns
/// - `Ok(())`: All validation checks passed, safe to submit
/// - `Err(ValidationError)`: At least one check failed, DO NOT submit
///
/// # Usage Example
/// ```rust
/// // ⚠️ CORRECTED usage (old create_output_leaf / SenderWitness do NOT exist):
/// use z00z_wallets::core::stealth::output::build_tx_stealth_output;
///
/// // Create output (Section 5.2)
/// let output = build_tx_stealth_output(&card, pr_opt, &sender_wallet, &tx_digest, out_index, amount, &asset_id)?;
///
/// // Validate before submission (TODO: validate_output_self not yet implemented)
/// // validate_output_self(&output, &k_dh, &card.owner_handle, &asset_id)?;
///
/// // Safe to submit to aggregator
/// submit_transaction(vec![output])?;
/// ```
///
/// # Security Notes
/// - **MUST** call this before submitting output to aggregator
/// - Failure indicates implementation bug, not user error
/// - All checks use same crypto primitives as OWF and receiver
/// - Early detection saves expensive checkpoint rejection
pub fn validate_output_self(
    output: &TxStealthOutput,  // NOT OutputLeaf
    k_dh: &[u8; 32],           // recomputed; NOT SenderWitness
    owner_handle: &[u8; 32],   // from ReceiverCard.owner_handle
    asset_id: &[u8; 32],       // external; NOT a field of TxStealthOutput
) -> ValidationResult<()> {
    // Check 1: Self-Decryption (Section 5.3.3 Phase 2)
    // ⚠️ Now takes asset_id and serial_id as explicit params (NOT fields of TxStealthOutput)
    let asset_pack = verify_self_decryption(output, k_dh, asset_id, 0u32)
        .map_err(|e| {
            log::error!("Self-decryption failed: {}", e);
            e
        })?;
    
    // Check 2: Commitment Consistency (Section 5.3.3 Phase 3)
    verify_commitment_consistency(output, &asset_pack)
        .map_err(|e| {
            log::error!("Commitment consistency failed: {}", e);
            e
        })?;
    
    // Check 3: Asset ID Consistency (Section 5.3.3 Phase 4)
    // NOTE: asset_id is external param; TxStealthOutput has NO asset_id field
    verify_asset_id_consistency(asset_id, &asset_pack)
        .map_err(|e| {
            log::error!("Asset ID consistency failed: {}", e);
            e
        })?;
    
    // Check 4: Owner Tag Verification (Section 5.3.3 Phase 5)
    verify_sender_owner_tag(output, k_dh, owner_handle)
        .map_err(|e| {
            log::error!("Owner tag verification failed: {}", e);
            e
        })?;
    
    log::debug!("Output validation passed");
    Ok(())
}

/// Batch validation for multiple outputs
///
/// # Returns
/// - `Ok(())`: All outputs valid
/// - `Err((index, ValidationError))`: First failed output with index
// ⚠️ OutputLeaf, SenderWitness, create_output_leaf(), validate_output_self(old sig) — all do NOT exist
// Use: build_tx_stealth_output() + validate_output_self(output, k_dh, owner_handle, asset_id)
pub fn validate_outputs_batch(
    outputs: &[(TxStealthOutput, [u8;32], [u8;32], [u8;32])],  // (output, k_dh, owner_handle, asset_id)
) -> Result<(), (usize, ValidationError)> {
    for (idx, (output, k_dh, owner_handle, asset_id)) in outputs.iter().enumerate() {
        validate_output_self(output, k_dh, owner_handle, asset_id)
            .map_err(|e| (idx, e))?;
    }
    Ok(())
}
```

**Integration with Section 5.2:**

```rust
// \u26a0\ufe0f Legacy pseudocode: create_output_leaf(), ValidatedPaymentInput, OutputLeaf, SenderWitness, OutputError do NOT exist
// \u2705 Actual entry point: build_tx_stealth_output(receiver_card, payment_request, sender_wallet, tx_digest, out_index, amount, asset_id)
// \u2705 Returns: Result<TxStealthOutput, StealthError>

// Sketch for future auto-validation integration (paranoid-validation feature):
pub fn build_tx_stealth_output_validated(
    receiver_card: &ReceiverCard,
    payment_request: Option<&PaymentRequest>,
    sender_wallet: &SenderWallet,
    tx_digest: &[u8; 32],
    out_index: u32,
    amount: u64,
    asset_id: &[u8; 32],
) -> Result<TxStealthOutput, StealthError> {
    let output = build_tx_stealth_output(
        receiver_card, payment_request, sender_wallet, tx_digest, out_index, amount, asset_id
    )?;
    
    // Optional: Auto-validate before returning
    #[cfg(feature = "paranoid-validation")]
    {
        // k_dh would need to be recomputed here; planned for future implementation
        // validate_output_self(&output, &k_dh, &receiver_card.owner_handle, asset_id)?;
    }
    
    Ok(output)
}
```

**Configuration:**

Add to `Cargo.toml`:

```toml
[features]
default = []
paranoid-validation = []  # Enable automatic validation after creation
```

---

#### ✅ Implementation Checklist — Phase 17: Error Handling, Testing & Security

> **Files:** `error.rs`, `output_validator.rs`, test files, `SECURITY.md` notes  
> **Status:** ❌ Mostly not done — error Display exists; security review and benchmarks missing.

- [ ] **`ValidationError` Display messages** — all clear and actionable:
  - [ ] `SelfDecryptionFailed` → `"output self-decryption failed: stealth_pk mismatch"`
  - [ ] `CommitmentMismatch` → `"output commitment inconsistent with blinding and asset_id"`
  - [ ] `AssetIdMismatch` → `"output asset_tag inconsistent with expected asset_id"`
  - [ ] `OwnerTagMismatch` → `"output tag16 doesn't match expected owner tag"`
  - [ ] `InvalidPublicKey` → `"invalid or identity Ristretto point in output"`
- [ ] **Structured benchmarks** (Criterion):
  - [ ] `bench_build_stealth_output` — baseline: < 5 ms per output on dev machine
  - [ ] `bench_validate_output_self` — baseline: < 2 ms per validation
  - [ ] `bench_validate_batch_100` — baseline: < 150 ms for 100 outputs
  - [ ] Run: `cargo bench -p z00z_wallets --bench stealth_output`
- [ ] **Property-based tests** (proptest):
  - [ ] `prop_build_any_amount_succeeds` — random amount in [0, u64::MAX) builds without error
  - [ ] `prop_view_pk_garbage_rejected` — random 32 bytes as view_pk → always error or Ok (no panic)
  - [ ] `prop_round_trip_self_decrypt` — any valid build → validate_output_self always Ok
- [ ] **Security review checklist** (manual, document findings):
  - [ ] No `unwrap()` or `expect()` in production paths
  - [ ] All scalar operations use constant-time implementations
  - [ ] `r` scalar zeroed after use in `build_tx_stealth_output_validated()`
  - [ ] `AssetPackPlain` zeroized on drop
  - [ ] `SenderValidationContext.r` zeroized on drop
  - [ ] No secret data in error messages or logs
  - [ ] `hidden_data!`: no accidental Debug printing of keys
- [ ] **Integration test** (end-to-end validation flow):
  - [ ] `test_full_send_receive_cycle` — sender builds output, receiver decrypts, amounts match
  - [ ] `test_full_cycle_wrong_receiver_rejects` — different receiver_card → validation fails

---

### 👉🏾Phase 17 — Error Handling, Testing & Security

### 5.3.4 Error Handling and Recovery

**Error Categories:**

| Error Type             | Severity | Recovery Strategy                                    |
| ---------------------- | -------- | ---------------------------------------------------- |
| `SelfDecryptionFailed` | CRITICAL | Retry creation with fresh randomness                 |
| `CommitmentMismatch`   | CRITICAL | Bug in commitment logic, report to developers        |
| `AssetIdMismatch`      | CRITICAL | Bug in asset_id derivation, report to developers     |
| `OwnerTagMismatch`     | HIGH     | Check ReceiverCard validity, retry with correct card |

**Recovery Pattern (TODO — implement inside `build_tx_stealth_output_validated()`):**

```rust
// TODO: implement in crates/z00z_wallets/src/core/stealth/output.rs
const MAX_RETRIES: usize = 3;
for attempt in 0..MAX_RETRIES {
    let output = build_tx_stealth_output(
        receiver_card, payment_request, sender_wallet,
        tx_digest, out_index, amount, asset_id,
    )?;
    // k_dh must be recomputed here (rerun ECDH with r from output)
    match validate_output_self(&output, &k_dh, &receiver_card.owner_handle, asset_id) {
        Ok(()) => return Ok(output),
        Err(ValidationError::SelfDecryptionFailed(_)) => continue, // transient — retry
        Err(e) => return Err(StealthError::from(e)),               // non-transient
    }
}
Err(StealthError::MaxRetriesExceeded) // TODO: add variant to StealthError
```

---

### 5.3.5 Testing Strategy

> ⚠️ **ALL test code in this section uses legacy types.** Corrections for implementation:
>
> - `create_output_leaf()` → `build_tx_stealth_output(card, pr, sender_wallet, ...)`
> - `ValidatedPaymentInput` → `ReceiverCard` + `Option<PaymentRequest>`
> - `OutputLeaf` → `TxStealthOutput`
> - `SenderWitness` → intermediate value; no public struct
> - `OutputError` → `StealthError`
> - `AssetPackPlainV1` → `AssetPackPlain`
> - `z00z_core::tx::*` → `z00z_wallets::core::stealth::output::*`
> - `z00z_core::payment::*` → `z00z_wallets::core::address::*`
> - `validate_output_self(o, w)` → `validate_output_self(o, k_dh, owner_handle, asset_id)` (TODO)

#### Unit Tests

> ⚠️ **OUTDATED PSEUDOCODE** — The test code below uses LEGACY APIs that do **NOT** exist:  
> `create_output_leaf()`, `ValidatedPaymentInput`, `SenderWitness`, `Z00ZBlindingFactor`,  
> `RistrettoSecretKey` (as blinding), `PedersenCommitmentFactory`, `factory.commit_value()`,  
> `ZkHash::new_with_domain()`, `output.asset_id`, `output.C_amount` (wrong casing/field).  
> **Actual APIs** for real tests: `build_tx_stealth_output(card, pr, wallet, digest, idx, amount, asset_id)`  
>
> - `validate_output_self(output, k_dh, owner_handle, asset_id)` (pending implementation).

**Test stubs (implement when `validate_output_self()` is available):**

```rust
// TODO: crates/z00z_wallets/src/core/stealth/output_validator.rs (tests module)
use z00z_wallets::core::stealth::output::{build_tx_stealth_output, SenderWallet, TxStealthOutput};
use z00z_wallets::core::address::ReceiverCard;
use z00z_wallets::core::key::ReceiverSecret;

// helper
fn make_output(amount: u64) -> (TxStealthOutput, ReceiverCard) {
    let secret = ReceiverSecret::from_bytes([0x42u8; 32]).unwrap();
    let keys = z00z_wallets::core::key::ReceiverKeys::from_receiver_secret(secret).unwrap();
    let card = ReceiverCard::new(&keys, None, None).unwrap();
    let wallet = SenderWallet { secret_salt: [0x01u8; 32] };
    let output = build_tx_stealth_output(
        &card, None, &wallet, &[0u8; 32], 0, amount, &[0u8; 32],
    ).unwrap();
    (output, card)
}

// #[test] fn test_valid_output_passes_all_checks()  // TODO: call validate_output_self once implemented
// #[test] fn test_self_decryption_detects_wrong_key() // TODO
// #[test] fn test_commitment_consistency_detects_mismatch() // TODO
// #[test] fn test_asset_id_consistency_detects_wrong_s_out() // TODO
// #[test] fn test_owner_tag_detects_wrong_handle()   // TODO
// #[test] fn test_batch_validation_stops_at_first_error() // TODO
```

**Integration test stub:**

```rust
// TODO: crates/z00z_wallets/tests/output_validation_integration.rs
// Verify: Section 5.2 outputs must pass Section 5.3 validation
// Entry point: build_tx_stealth_output() + validate_output_self() (§5.3.3 Phase 6)
// Receiver decryption: ZkPack::decrypt(k_dh, &leaf_ad, &r_pub, asset_id, serial_id, &enc_pack)
```

---

### 5.3.6 Performance Considerations

**Validation Cost Analysis:**

| Check           | Operation                | Cost      | Bottleneck |
| --------------- | ------------------------ | --------- | ---------- |
| Self-Decryption | ECDH + ChaCha20-Poly1305 | ~50μs     | Curve ops  |
| Commitment      | Pedersen commitment      | ~30μs     | Curve mul  |
| Asset ID        | SHA3-256                 | ~5μs      | Hash       |
| Owner Tag       | SHA3-256                 | ~5μs      | Hash       |
| **Total**       |                          | **~90μs** | Acceptable |

**Optimization Strategies:**

1. **Batch Validation**: Validate multiple outputs in parallel (Phase 6 batch function)
2. **Lazy Validation**: Skip in debug builds if `paranoid-validation` feature disabled
3. **Cache k_dh**: Reuse k_dh for multiple computations (⚠️ `SenderWitness` does NOT exist — pass k_dh directly in a simple tuple/struct)

**Benchmark stub (implement when `validate_output_self()` is available):**

```rust
// TODO: crates/z00z_wallets/benches/validate_output.rs
// use build_tx_stealth_output() to create the output under test,
// then bench validate_output_self(output, k_dh, owner_handle, asset_id)
```

---

### 5.3.7 Security Analysis

#### Threat Model

**What Section 5.3 protects against:**

| Threat                  | Attack Vector                   | Defense                | Result                   |
| ----------------------- | ------------------------------- | ---------------------- | ------------------------ |
| **Implementation Bug**  | Sender creates malformed output | Early local detection  | Output never submitted   |
| **Encryption Error**    | Wrong key derivation            | Self-decryption fails  | Caught before submission |
| **Commitment Mismatch** | Wrong blinding factor           | Commitment check fails | Prevents OWF rejection   |
| **Asset ID Error**      | Wrong hash domain               | Asset ID check fails   | Prevents asset confusion |
| **M1 Attack (Sender)**  | Sender uses wrong owner_handle  | Owner tag check fails  | Prevents soft burn       |

**What Section 5.3 does NOT protect against:**

- ❌ **Receiver-side bugs**: Validation only checks sender's view
- ❌ **Network attacks**: Validation is local, doesn't verify aggregator behavior
- ❌ **Quantum attacks**: ECDH stealth not PQ-secure (by design, acceptable for Z00Z)
- ❌ **Side channels**: Timing attacks not mitigated (TODO: constant-time crypto)

#### Attack Scenarios

#### Scenario 1: Malicious Sender (M1 Attack)

```yaml
M1_Attack_Decryptable_Not_Spendable:
  attacker_goal: Make victim see incoming balance they cannot spend
  attack_steps:
    1. Attacker obtains victim's view_pk (public)
    2. Attacker obtains ANOTHER user's owner_handle (not victim's)
    3. Attacker creates output:
       - Uses victim's view_pk for ECDH (victim can decrypt)
       - Uses other user's owner_handle in owner_tag (victim cannot spend)
    4. Victim wallet decrypts output, sees "incoming 10000 Z00Z"
    5. Victim tries to spend → fails M1 check (wrong owner_handle)
  defense:
    - Section 5.3.3 Phase 5: verify_sender_owner_tag() catches this
    - Sender validation fails → output never created
  result: Attack prevented at sender side
```

#### Scenario 2: RNG Failure

```yaml
RNG_Failure_Scenario:
  problem: RNG produces repeated r values (VM snapshot, container bug)
  outcome_without_validation:
    - R_pub repeats → outputs linkable
    - k_dh repeats → owner_tag repeats → receiver identity leaked
  outcome_with_validation:
    - Section 5.2 RecentRCache detects repeat (H-3)
    - build_tx_stealth_output() fails internally before returning
  additional_defense:
    - Section 5.3 self-decryption would also detect (identical enc_pack)
  result: RNG failure caught by H-3 + Section 5.3 defense-in-depth
```

---

### 5.3.8 Integration Summary

**Dependencies (what Section 5.3 uses):**

| Component | From Section | Purpose in Validation |
| --- | --- | --- |
| `TxStealthOutput` | 5.2.14 | Structure to validate (⚠️ `OutputLeaf` does NOT exist) |
| (no public struct) | 5.2.15 | `k_dh` + `owner_handle` + `asset_id` passed directly (⚠️ `SenderWitness` does NOT exist) |
| `AssetPackPlain` | 5.2.11 | Plaintext parsing (⚠️ `AssetPackPlainV1` does NOT exist) |
| `ZkPack::decrypt()` | 4.6 | Self-decryption (⚠️ `EncryptedPack` does NOT exist; use `ZkPack::decrypt(k_dh, leaf_ad, r_pub, asset_id, serial_id, enc) -> Option<Vec<u8>>`) |
| `compute_leaf_ad()` | 4.7 | Anti-malleability binding |
| `PedersenCommitmentFactory` | 4.4 | Commitment verification |
| `hash_zk::<Domain>()` | `z00z_crypto` | Domain-separated hashing (⚠️ `ZkHash::new_with_domain` does NOT exist) |

**Reverse Dependencies (what uses Section 5.3):**

| Component | From Section | How it uses Section 5.3 |
| --- | --- | --- |
| `create_output_leaf()` | 5.2.15 | Optional auto-validation with `paranoid-validation` feature — ⚠️ `create_output_leaf` does NOT exist; use `build_tx_stealth_output()` |
| `create_output()` | 5.4.1 | High-level API calls validation before returning |
| `OutputBuilder` | 5.4.2 | Builder pattern calls validation in `.build()` step |
| Wallet TX creation | Future | All wallet UX validates outputs before broadcast |

**API Surface:**

```rust
// Public API (planned re-export from z00z_wallets::core::stealth)
// ⚠️ z00z_core::tx does NOT exist — actual planned location: z00z_wallets::core::stealth
pub use output_validator::{
    validate_output_self,
    validate_outputs_batch,
    ValidationError,
    ValidationResult,
};

// Internal API (not re-exported)
mod output_validator {
    fn verify_self_decryption(...) -> ValidationResult<AssetPackPlain>;  // NOT AssetPackPlainV1
    fn verify_commitment_consistency(...) -> ValidationResult<()>;
    fn verify_asset_id_consistency(...) -> ValidationResult<()>;
    fn verify_sender_owner_tag(...) -> ValidationResult<()>;  // renamed from verify_owner_tag (collision)
    fn derive_pack_key(...) -> [u8; 32];  // infallible — no ValidationResult wrapper
}
```

---

### 5.3.9 Next Steps for Implementation

**Development Path:**

1. **Start with Phase 1** (Core Infrastructure):
   - Define `ValidationError` enum
   - Stub out `validate_output_self()` function
   - Write failing tests (TDD approach)

2. **Implement Phases 2-5 sequentially**:
   - Each phase: write tests first → implement → verify tests pass
   - Integrate with existing Section 4.4/4.6/4.7 components
   - Validate against OWF constraints from crates/Z00Z-ECC-IDEAS.md

3. **Add Phase 6** (Orchestrator + Batch):
   - Wire all 4 checks together
   - Add batch validation for multiple outputs
   - Integrate with Section 5.2 output creation

4. **Testing**:
   - Unit tests for each validation check
   - Integration tests with Section 5.2
   - Property-based tests (optional)
   - Benchmarks (optional)

5. **Integration with Section 5.4**:
   - High-level `create_output()` API calls validation
   - `OutputBuilder` pattern includes validation in build step

**Estimated Effort:**

- Phase 1: ~2-3 hours (infrastructure)
- Phases 2-5: ~6-8 hours (4 validation checks)
- Phase 6: ~2-3 hours (orchestrator)
- Testing: ~4-6 hours (comprehensive coverage)
- **Total: ~14-20 hours** for complete Section 5.3 implementation

**Documentation Requirements:**

- ✅ Rustdoc comments for all public functions (done in spec above)
- ✅ Security notes for critical checks (M1, H-3)
- ✅ Integration examples with Section 5.2/5.4
- ✅ Error handling and recovery strategies
- ✅ Performance benchmarks

**Success Criteria:**

- [ ] All 4 validation checks implemented and tested
- [ ] Integration with Section 4.4/4.6/4.7 working
- [ ] Unit tests achieve >90% coverage
- [ ] Integration tests pass with Section 5.2 outputs
- [ ] Validation cost <100μs per output (target: ~90μs)
- [ ] All rustdoc examples compile and run
- [ ] Security review completed (M1, H-3, OWF compliance)

---

#### ✅ Implementation Checklist — Phase 18: API Overview & Input Types

> **File:** `crates/z00z_wallets/src/core/stealth/output_api.rs` (new)  
> **Status:** ❌ NOT implemented (section 5.4 is new API layer).

- [ ] **Create `crates/z00z_wallets/src/core/stealth/output_api.rs`**:
  - [ ] Register as `pub mod api;` in `output/mod.rs`
  - [ ] Re-export from `z00z_wallets/src/lib.rs`: `OutputConfig`, `OutputApiError`
- [ ] **Struct `OutputConfig`**:
  - [ ] `receiver_card: ReceiverCard` — validated before passing
  - [ ] `asset_id: Z00ZScalar` — from transaction context
  - [ ] `amount: u64`
  - [ ] `validate_after_build: bool` — if true, call `validate_output_self()` after build
  - [ ] Builder pattern: `OutputConfig::builder().receiver_card(card).asset_id(id).amount(n).build()`
- [ ] **Enum `OutputApiError`**:
  - [ ] `InvalidConfig(String)` — misconfigured `OutputConfig`
  - [ ] `BuildFailed(StealthError)` — from `build_tx_stealth_output()`
  - [ ] `ValidationFailed(ValidationError)` — from `validate_output_self()`
  - [ ] `CardInvalid(ReceiverCardError)` — card failed pre-flight check
  - [ ] Implements `thiserror::Error` with descriptive messages
- [ ] **Pre-flight card validation** in `OutputConfig::build()` or `create_output()`:
  - [ ] Calls `receiver_card.verify()` → `Err(OutputApiError::CardInvalid)` on failure
  - [ ] Validates `view_pk` point decompression → `Err(OutputApiError::CardInvalid)`
- [ ] **Re-exports at crate level** (`z00z_wallets/src/lib.rs`):
  - [ ] `pub use core::stealth::output_api::{OutputConfig, OutputApiError, create_output, create_outputs_batch};`
  - [ ] `pub use core::stealth::output::TxStealthOutput;`
- [ ] **Unit tests** for config and error types:
  - [ ] `test_output_config_builder_valid`
  - [ ] `test_output_config_missing_field_error`
  - [ ] `test_output_api_error_display_messages`

---

---

### 👉🏾Phase 18 — API Overview & Input Types

## 5.4 Output Creation API

**Purpose:** High-level convenient API for wallet applications to create outputs. Wraps Section 5.2 (14-step algorithm) and Section 5.3 (validation) with ergonomic interfaces.

**Source:** Designed based on crates/Z00Z-ECC-IDEAS.md principles + wallet UX requirements.

**Design Goals:**

🎯 **Ergonomics:**

- Simple one-shot API for common cases (`create_output()`)
- Builder pattern for advanced control (`OutputBuilder`)
- Auto-validation by default (Section 5.3)
- Clear error messages with recovery guidance

🔒 **Safety:**

- Mandatory input validation (ReceiverCard/PaymentRequest)
- Automatic hedged randomness (H-3 protection)
- Built-in R cache management (ephemeral key repeat detection)
- Paranoid mode for extra checks

⚡ **Performance:**

- Minimize allocations
- Batch output creation support
- Reusable builder instances
- Optional async support (future)

---

### 5.4.1 API Overview

**Two API Styles:**

| API Style             | Use Case            | Complexity | Control |
| --------------------- | ------------------- | ---------- | ------- |
| **`create_output()`** | Quick single output | Low        | Minimal |
| **`OutputBuilder`**   | Advanced scenarios  | Medium     | Full    |

**Module Structure:**

```text
⚠️ PLANNED location — z00z_core/src/tx/ does NOT exist; actual code in z00z_wallets/src/core/stealth/
z00z_wallets/
└── src/
    └── core/
        └── stealth/
            ├── output.rs               # ✅ build_tx_stealth_output() (Section 5.2)
            ├── output_api.rs           # TODO: High-level create_output() wrapper
            ├── output_validator.rs     # TODO: validate_output_self() (Section 5.3)
            └── mod.rs
⚠️ output_api.rs, output_leaf.rs, output_builder.rs do NOT exist yet
```

**Public API Surface:**

```rust
// ✅ IMPLEMENTED — actual public API surface from z00z_wallets:

// Primary stealth output creation API — z00z_wallets::core::stealth::output
pub use z00z_wallets::core::stealth::output::{
    build_tx_stealth_output,  // ✅ Main entry point
    verify_owner_tag,         // ✅ Receiver-side verification
    verify_owner_two_factor,  // ✅ 2FA verification
    TxStealthOutput,          // ✅ Output struct
    SenderWallet,             // ✅ { secret_salt:[u8;32] }
    // StealthError            ✅ Error type
};

// Address types — z00z_wallets::core::address
pub use z00z_wallets::core::address::{
    ReceiverCard,             // ✅ Long-lived receiver card
    PaymentRequest,           // ✅ Short-lived payment request
};

// ❌ NOT YET IMPLEMENTED (TODO):
// create_output()           — simple one-shot wrapper
// create_outputs_batch()    — batch wrapper
// OutputBuilder             — builder pattern
// OutputConfig              — configuration type
// validate_output_self()    — paranoid post-creation validation
```


---

### 5.4.2 ReceiverCard & PaymentRequest Types

> ✅ **IMPLEMENTED** — see §5.1.1 for authoritative type definitions and implementations.  
> ❌ Type definitions are **NOT duplicated here** to avoid drift (they were, and were wrong).

**Actual implementation locations:**

- `ReceiverCard` → `crates/z00z_wallets/src/core/address/stealth_card.rs`  
- `PaymentRequest` → `crates/z00z_wallets/src/core/address/stealth_request.rs`

**Quick reference (see §5.1.1 for full details):**

```rust
// ✅ ReceiverCard — actual fields:
// version: u8, owner_handle:[u8;32], view_pk:[u8;32], identity_pk:[u8;32],
// card_id: Option<[u8;16]>, metadata: Option<CardMetadata>, signature:[u8;64]
//
// ✅ PaymentRequest — actual fields:
// version: u8, owner_handle:[u8;32], view_pk:[u8;32], identity_pk:[u8;32],
// req_id:[u8;32], chain_id:u32, amount:Option<u64>, expiry:u64,  // ← chain_id is u32, NOT u64
// metadata:Option<RequestMetadata>, signature:[u8;64]
//
// ✅ Error types: ReceiverCardError, PaymentRequestError (NOT CardError/RequestError)
// ❌ ReceiverInput enum does NOT exist — use ReceiverCard / Option<&PaymentRequest> directly
```

**Note on `ReceiverInput` enum:**  
The spec previously described a `ReceiverInput { Card(ReceiverCard), Request(PaymentRequest) }` enum.  
This does **NOT** exist in the codebase. The actual API (`build_tx_stealth_output`) takes:

- `receiver_card: &ReceiverCard` — always required
- `payment_request: Option<&PaymentRequest>` — optional, for DoS-resistant targeted payments  

This is a more precise separation of concerns than the enum approach.



---

#### ✅ Implementation Checklist — Phase 19: create_output() Function

> **File:** `crates/z00z_wallets/src/core/stealth/output_api.rs`  
> **Status:** ❌ NOT implemented (as high-level API; `build_tx_stealth_output()` exists but is low-level).

- [ ] **Function `create_output(config: OutputConfig, rng: &mut impl CryptoRng + RngCore) -> Result<TxStealthOutput, OutputApiError>`**:
  - [ ] Pre-flight: validate `config.receiver_card` (verify + view_pk check) → `Err(CardInvalid)` on failure
  - [ ] Calls `build_tx_stealth_output(&config.receiver_card, config.asset_id, config.amount, rng)`
  - [ ] If `config.validate_after_build == true`: runs `validate_output_self(...)` with retained ctx
  - [ ] **Retry logic**: if `generate_r_hedged` returns zero (extremely rare) → retry up to 3 times
  - [ ] Returns `Ok(output)` on success
- [ ] **Retry loop** (for hedged r generation failure only):
  - [ ] Max retries = 3 (const `MAX_OUTPUT_RETRIES: u32 = 3`)
  - [ ] After max retries → `Err(OutputApiError::BuildFailed(StealthError::RngFailure))`
  - [ ] Add `RngFailure` variant to `StealthError` if missing
- [ ] **`OutputConfig` builder completeness**:
  - [ ] `.receiver_card()` is required (no default)
  - [ ] `.asset_id()` is required (no default)
  - [ ] `.amount()` is required (no default)
  - [ ] `.validate_after_build(bool)` defaults to `false`
  - [ ] `.build()` returns `Result<OutputConfig, OutputApiError>` with missing-field error
- [ ] **Unit tests** (all must pass):
  - [ ] `test_create_output_basic` — valid config, valid rng → Ok(output)
  - [ ] `test_create_output_with_validation` — `validate_after_build=true` → Ok(output)
  - [ ] `test_create_output_invalid_card` — tampered card signature → `CardInvalid`
  - [ ] `test_create_output_invalid_view_pk` — garbage view_pk → `CardInvalid`
  - [ ] `test_output_config_missing_amount` — no `.amount()` → `InvalidConfig`
  - [ ] `test_output_config_missing_receiver_card` — no card → `InvalidConfig`

---

### 👉🏾Phase 19 — create_output() Function

### 5.4.3 High-Level Output Creation API

> ✅ **IMPLEMENTED** — `build_tx_stealth_output()` in `crates/z00z_wallets/src/core/stealth/output.rs`  
> ❌ `create_output()`, `OutputConfig`, `OutputBuilder`, `OutputApiError` do **NOT exist** in codebase.  
> ❌ `OutputLeaf` does NOT exist — actual return type is `TxStealthOutput` + intermediate `AssetLeaf`.

**Actual entry point (use this):**

```rust
use z00z_wallets::core::stealth::output::{
    build_tx_stealth_output,
    TxStealthOutput,
    SenderWallet,
    StealthError,
};
use z00z_wallets::core::address::{ReceiverCard, PaymentRequest};

/// ✅ IMPLEMENTED — actual signature:
///
/// pub fn build_tx_stealth_output(
///     receiver_card: &ReceiverCard,
///     payment_request: Option<&PaymentRequest>,  // None → use card only
///     sender_wallet: &SenderWallet,               // SenderWallet { secret_salt:[u8;32] }
///     tx_digest: &[u8; 32],
///     out_index: u32,
///     amount: u64,
///     asset_id: &[u8; 32],
/// ) -> Result<TxStealthOutput, StealthError>
///
/// TxStealthOutput fields:
///   r_pub: [u8; 32]          // Ephemeral public key
///   owner_tag: [u8; 32]      // Owner verification tag
///   tag16: Option<u16>       // 2-byte scan optimization (runtime invariant: NEVER None —
///                            //  currently typed Option<u16>; TODO: change to u16 for
///                            //  compile-time enforcement; see §5.2 step 13)
///   enc_pack: ZkPackEncrypted // Encrypted asset/amount pack
///   c_amount: [u8; 32]       // Pedersen commitment to amount

// Usage example:
let sender_wallet = SenderWallet { secret_salt: my_salt };
let output: TxStealthOutput = build_tx_stealth_output(
    &receiver_card,
    Some(&payment_request),  // or None for card-only
    &sender_wallet,
    &tx_digest,
    0,                        // out_index
    10_000,                   // amount
    &asset_id,
)?;
```

**TODO — remaining high-level wrappers to implement:**

```yaml
future_api_todos:
  create_output_simple:
    description: "Simple one-shot wrapper for build_tx_stealth_output"
    inputs: [receiver_card, amount, asset_id]
    outputs: [TxStealthOutput]
    note: "Derive tx_digest, out_index, sender_wallet from wallet context"

  OutputConfig:
    description: "Configuration for retry logic, validation flags"
    status: TODO
    fields:
      - paranoid_validation: bool (default true)
      - max_retries: usize (default 3)

  OutputApiError:
    description: "High-level error wrapping StealthError + PaymentRequestError"
    status: TODO
    underlying: StealthError, ReceiverCardError, PaymentRequestError
```



---

#### ✅ Implementation Checklist — Phase 20: Batch Output Creation

> **File:** `crates/z00z_wallets/src/core/stealth/output_api.rs`  
> **Status:** ❌ NOT implemented.

- [ ] **Function `create_outputs_batch(configs: Vec<OutputConfig>, rng: &mut impl CryptoRng + RngCore) -> Result<Vec<TxStealthOutput>, OutputApiError>`**:
  - [ ] **Atomic semantics**: if ANY output fails to build → return `Err` without partial results
  - [ ] Pre-flight: validate ALL cards before building any output
  - [ ] Build each output sequentially using `create_output(config, rng)`
  - [ ] If any `create_output()` returns Err → stop immediately → propagate error
  - [ ] Returns `Ok(Vec<TxStealthOutput>)` only if ALL succeed
- [ ] **Partial success NOT allowed** (must document explicitly):
  - [ ] Docstring: "Atomic: either all outputs succeed or none are returned"
  - [ ] Reason: prevents incomplete transactions being submitted to network
- [ ] **Empty input handling**:
  - [ ] `configs.is_empty()` → `Ok(Vec::new())` (valid; 0 outputs = no-op)
- [ ] **Validation option** (SHOULD):
  - [ ] If any `config.validate_after_build == true` → validate each output after building it
  - [ ] `validate_all: bool` shortcut field on `OutputConfig` applies to all in batch
- [ ] **Unit tests** (all must pass):
  - [ ] `test_batch_empty_input` — `create_outputs_batch(vec![], rng)` → `Ok([])`
  - [ ] `test_batch_single_output` — one config → `Ok([output])`
  - [ ] `test_batch_multiple_outputs` — 3 configs, all valid → `Ok([o1, o2, o3])`
  - [ ] `test_batch_atomic_on_second_failure` — first valid, second has invalid card → `Err(...)` (no partial result)
  - [ ] `test_batch_all_fail_first` — first already invalid → `Err(...)` before building anything
  - [ ] `test_batch_output_count_matches_input` — N configs → exactly N outputs on success

---

### 👉🏾Phase 20 — Batch Output Creation

### 5.4.4 Batch Output Creation

> ⚠️ **Pseudocode section.** All return types, error types, and function names below use planned (not yet implemented) identifiers. Corrections:
>
> - `Vec<OutputLeaf>` → `Vec<TxStealthOutput>`
> - `OutputApiError` → wrap `StealthError` (no `OutputApiError` yet)
> - `create_outputs_batch()` → TODO, not yet implemented; use `build_tx_stealth_output()` per output
> - `ReceiverInput` → TODO (use `ReceiverCard` or `PaymentRequest` directly)

**Convenient API for multiple outputs:**

```rust
/// Creates multiple outputs in a single call
///
/// # Purpose
/// Efficient batch creation for transactions with multiple recipients.
/// Shares RNG provider and configuration across outputs.
///
/// # Arguments
/// - `outputs_spec`: List of (receiver, amount) pairs
/// - `config`: Optional configuration
///
/// # Returns
/// - `Ok(Vec<TxStealthOutput>)`: All outputs created and validated (⚠️ NOT `Vec<OutputLeaf>`)
/// - `Err((index, OutputApiError))`: First failed output with index
///
/// # Security Notes
/// - Each output uses fresh ephemeral key (r)
/// - All outputs validated before returning (atomic: all-or-nothing)
/// - If any output fails, entire batch rejected
///
/// # Examples
///
/// ```rust
/// use z00z_core::tx::{create_outputs_batch, ReceiverInput};
///
/// let outputs_spec = vec![
///     (receiver_card_1.into(), 10_000),
///     (receiver_card_2.into(), 20_000),
///     (payment_request_3.into(), 30_000),
/// ];
///
/// let outputs = create_outputs_batch(&outputs_spec, None)?;
/// assert_eq!(outputs.len(), 3);
///
/// // Submit all outputs in one transaction
/// submit_transaction(outputs)?;
/// # Ok::<_, Box<dyn std::error::Error>>(())
/// ```
pub fn create_outputs_batch(
    outputs_spec: &[(ReceiverInput, u64)],
    config: Option<OutputConfig>,
) -> Result<Vec<TxStealthOutput>, (usize, OutputApiError)> {  // ⚠️ NOT Vec<OutputLeaf>
    if outputs_spec.is_empty() {
        return Ok(Vec::new());
    }
    
    let config = config.unwrap_or_default();
    // NOTE: In production, inject TimeProvider as dependency
    let time_provider = SystemTimeProvider::default();
    let current_time = time_provider.unix_timestamp();
    
    // Validate all receiver inputs first (fail fast)
    for (idx, (receiver, _amount)) in outputs_spec.iter().enumerate() {
        receiver.validate(current_time)
            .map_err(|e| (idx, OutputApiError::InvalidReceiver(e)))?;
    }
    
    // Create all outputs
    let mut outputs = Vec::with_capacity(outputs_spec.len());
    
    for (idx, (receiver, amount)) in outputs_spec.iter().enumerate() {
        let output = create_output(receiver.clone(), *amount, Some(config.clone()))
            .map_err(|e| (idx, e))?;
        outputs.push(output);
    }
    
    Ok(outputs)
}
```

---

#### ✅ Implementation Checklist — Phase 21: OutputBuilder State Machine

> **File:** `crates/z00z_wallets/src/core/stealth/output_builder_api.rs` (new)  
> **Status:** ❌ NOT implemented.

- [ ] **Typestate pattern** — compile-time enforcement of build steps:

  ```rust
  struct OutputBuilder<S: BuilderState> { ... }
  trait BuilderState {}
  struct NeedsCard;
  struct NeedsAsset { card: ReceiverCard }
  struct NeedsAmount { card: ReceiverCard, asset_id: Z00ZScalar }
  struct Ready { card: ReceiverCard, asset_id: Z00ZScalar, amount: u64 }
  ```

  - [ ] Each state implements `BuilderState` marker trait
  - [ ] Transitions return new state (consuming previous): `OutputBuilder<NeedsCard> -> OutputBuilder<NeedsAsset>`
  - [ ] `.build()` only available on `OutputBuilder<Ready>`
- [ ] **Enum `BuilderError`** (for runtime errors only; compile-time errors via typestate):
  - [ ] `CardVerifyFailed(ReceiverCardError)` — card signature fails on `.card()` call
  - [ ] `InvalidViewPk` — view_pk decompression fails
  - [ ] `BuildFailed(StealthError)` — from `build_tx_stealth_output()`
- [ ] **Methods (in order of use)**:
  - [ ] `OutputBuilder::<NeedsCard>::new() -> OutputBuilder<NeedsCard>`
  - [ ] `.card(ReceiverCard) -> Result<OutputBuilder<NeedsAsset>, BuilderError>` — validates card on entry
  - [ ] `.asset_id(Z00ZScalar) -> OutputBuilder<NeedsAmount>`
  - [ ] `.amount(u64) -> OutputBuilder<Ready>`
  - [ ] `.enable_validation(bool) -> OutputBuilder<Ready>` — chainable on Ready state
  - [ ] `.build(rng: &mut impl CryptoRng + RngCore) -> Result<TxStealthOutput, BuilderError>`
- [ ] **`OutputBuilder` documentation**:
  - [ ] `/// # Examples` block showing complete chain usage in docstring
  - [ ] States described in comments
- [ ] **Unit tests** (all must pass):
  - [ ] `test_builder_happy_path` — complete chain → valid output
  - [ ] `test_builder_invalid_card_rejected_at_card_step` — bad card → `CardVerifyFailed` at `.card()`
  - [ ] `test_builder_compile_no_build_without_ready` — compile-time: `.build()` not on `NeedsCard`
  - [ ] `test_builder_with_validation_enabled` — `.enable_validation(true)` → validation runs on build
  - [ ] `test_builder_idempotent_build` — same inputs → deterministic?? (NOT deterministic due to rng, just verify Ok)

---

### 👉🏾Phase 21 — OutputBuilder State Machine

### 5.4.5 OutputBuilder Pattern (Advanced API)

**Step-by-step construction with full control:**

```rust
/// Builder pattern for output creation with fine-grained control
///
/// # Purpose
/// Advanced API for scenarios requiring:
/// - Explicit control over validation timing
/// - ⚠️ `SenderWitness` does NOT exist; k_dh is passed directly as `&[u8;32]`
/// - Custom error handling per step
/// - Partial output construction
///
/// # Usage Pattern
///
/// ```rust
/// use z00z_core::tx::OutputBuilder;
///
/// let builder = OutputBuilder::new();
///
/// let output = builder
///     .receiver(receiver_card.into())?
///     .amount(10_000)?
///     .validate_inputs()?
///     .create()?
///     .validate()?
///     .build()?;
/// # Ok::<_, Box<dyn std::error::Error>>(())
/// ```
///
/// # State Machine
///
/// ```
/// New → ReceiverSet → AmountSet → InputsValidated → Created → Validated → Built
///  ↓       ↓            ↓              ↓              ↓          ↓         ↓
/// (empty) (has      (has          (validated     (has      (has      (returns
///         receiver) receiver+      inputs)        output)   validated TxStealthOutput)
///                   amount)                                 // ⚠️ OutputLeaf/SenderWitness do NOT exist                                 output)
/// ```
// TODO: Implement in z00z_wallets::core::tx::builder
// ⚠️ CONCEPTUAL - Not yet in codebase
#[derive(Debug)]
pub struct OutputBuilder {
    // Input parameters (set by user)
    receiver: Option<ReceiverInput>,
    amount: Option<u64>,
    config: OutputConfig,
    
    // Internal state (computed during creation)
    validated_input: Option<ValidatedPaymentInput>,
    output: Option<TxStealthOutput>,    // ⚠️ NOT OutputLeaf (does not exist)
    // witness: Option<SenderWitness>,   // ⚠️ SenderWitness does NOT exist — remove this field
    
    // RNG provider (created on demand)
    rng: Option<Box<dyn RngCore>>,
}

impl OutputBuilder {
    /// Creates new builder with default configuration
    pub fn new() -> Self {
        Self {
            receiver: None,
            amount: None,
            config: OutputConfig::default(),
            validated_input: None,
            output: None,
            // ⚠️ SenderWitness does NOT exist — no witness field
            rng: None,
        }
    }
    
    /// Creates new builder with custom configuration
    pub fn with_config(config: OutputConfig) -> Self {
        Self {
            config,
            ..Self::new()
        }
    }
    
    /// Sets receiver (ReceiverCard or PaymentRequest)
    ///
    /// # State Transition
    /// New → ReceiverSet
    pub fn receiver(mut self, receiver: ReceiverInput) -> Result<Self, BuilderError> {
        // Validate receiver input immediately
        // NOTE: In production, inject TimeProvider as dependency
        let time_provider = SystemTimeProvider::default();
        let current_time = time_provider.unix_timestamp();
        
        receiver.validate(current_time)
            .map_err(BuilderError::InvalidReceiver)?
        
        self.receiver = Some(receiver);
        Ok(self)
    }
    
    /// Sets amount to send
    ///
    /// # State Transition
    /// ReceiverSet → AmountSet
    pub fn amount(mut self, amount: u64) -> Result<Self, BuilderError> {
        // Validate amount range
        // ⚠️ NOTE: `1u64 << 64` would be UB (overflow) in Rust — use u64::MAX instead.
        // Any u64 value is a valid amount; the only meaningful constraint is amount > 0.
        if amount == 0 {
            return Err(BuilderError::InvalidAmount("Amount must be positive".into()));
        }
        // amount <= u64::MAX is tautologically true for u64 — no upper-bound check needed here
        
        self.amount = Some(amount);
        Ok(self)
    }
    
    /// Validates inputs using Section 5.1 (Sender Prerequisites)
    ///
    /// # State Transition
    /// AmountSet → InputsValidated
    ///
    /// # Validates
    /// - Receiver view_pk is valid Ristretto point (not identity)
    /// - Owner_handle is correct length (32 bytes)
    /// - PaymentRequest expiry not passed
    /// - PaymentRequest signature valid (if present)
    pub fn validate_inputs(mut self) -> Result<Self, BuilderError> {
        let receiver = self.receiver.as_ref()
            .ok_or(BuilderError::MissingField("receiver"))?;
        
        // Create ValidatedPaymentInput using Section 5.1
        let validated_input = ValidatedPaymentInput::from_receiver_input(receiver)
            .map_err(BuilderError::ValidationFailed)?;
        
        self.validated_input = Some(validated_input);
        Ok(self)
    }
    
    /// Creates output using Section 5.2 (14-step algorithm)
    ///
    /// # State Transition
    /// InputsValidated → Created
    ///
    /// # Performs
    /// - 14-step output creation (Section 5.2)
    /// - Hedged randomness generation (H-3)
    /// - R cache checking (ephemeral key repeat detection)
    /// - Encryption with leaf_ad binding
    pub fn create(mut self) -> Result<Self, BuilderError> {
        let validated_input = self.validated_input.as_ref()
            .ok_or(BuilderError::InvalidState(
                "Must call validate_inputs() before create()"
            ))?;
        
        let amount = self.amount
            .ok_or(BuilderError::MissingField("amount"))?;
        
        // Initialize RNG if not already done
        if self.rng.is_none() {
            self.rng = Some(
                self.config.rng_provider
                    .take()
                    .unwrap_or_else(|| Box::new(SystemRngProvider::default()))
                    .rng()
            );
        }
        
        let _ = self.rng.as_mut(); // rng available for future use
        
        // TODO: implement:
        //   let output = build_tx_stealth_output(
        //       &receiver_card, payment_request.as_deref(), &sender_wallet,
        //       &tx_digest, out_index, amount, &asset_id
        //   ).map_err(BuilderError::CreationFailed)?;
        //   self.output = Some(output);
        //   // k_dh stored inline — no SenderWitness type
        todo!("OutputBuilder::create() — use build_tx_stealth_output() directly")
    }
    
    /// Validates output using Section 5.3
    ///
    /// # State Transition
    /// Created → Validated
    ///
    /// # Validates
    /// - Self-decryption (can sender decrypt own enc_pack?)
    /// - Commitment consistency (C_amount opens to (amount, blinding)?)
    /// - Asset ID consistency (asset_id derived from s_out?)
    /// - Owner tag correctness (matches receiver?)
    pub fn validate(self) -> Result<Self, BuilderError> {
        let output = self.output.as_ref()
            .ok_or(BuilderError::InvalidState(
                "Must call create() before validate()"
            ))?;
        
        // TODO: implement when validate_output_self() is available:
        //   validate_output_self(output, &k_dh, &owner_handle, &asset_id)
        //     where k_dh, owner_handle, asset_id stored in self during create()
        todo!("OutputBuilder::validate() — see §5.3.3 Phase 6")
    }
    
    /// Builds final TxStealthOutput (consumes builder)
    /// ⚠️ CORRECTION: `OutputLeaf` does NOT exist; return type is `TxStealthOutput`
    /// ⚠️ CORRECTION: `SenderWitness` does NOT exist; not returned
    ///
    /// # State Transition
    /// Validated → Built (terminal state)
    ///
    /// # Returns
    /// - `TxStealthOutput` ready for submission
    pub fn build(self) -> Result<TxStealthOutput, BuilderError> {  // NOT (OutputLeaf, SenderWitness)
        let output = self.output
            .ok_or(BuilderError::InvalidState(
                "Must call create() and validate() before build()"
            ))?;
        
        Ok(output)
    }
    
    /// Builds final TxStealthOutput without exposing intermediate values
    /// ⚠️ CORRECTION: `OutputLeaf`/`SenderWitness` do NOT exist; both replaced by `TxStealthOutput`
    ///
    /// # Note
    /// k_dh and blinding factors are not exposed in the returned TxStealthOutput.
    /// Use build() for production — this method is now equivalent.
    pub fn build_output_only(self) -> Result<TxStealthOutput, BuilderError> {  // NOT OutputLeaf
        self.build()
    }
    
    /// Resets builder to initial state (keeps config)
    pub fn reset(mut self) -> Self {
        self.receiver = None;
        self.amount = None;
        self.validated_input = None;
        self.output = None;
        self.rng = None;  // Force new RNG on next create()
        self
    }
}

impl Default for OutputBuilder {
    fn default() -> Self {
        Self::new()
    }
}
```

**Builder Error Type:**

```rust
#[derive(Debug, Error)]
pub enum BuilderError {
    #[error("Missing required field: {0}")]
    MissingField(&'static str),
    
    #[error("Invalid receiver: {0}")]
    // ⚠️ InputError does NOT exist — use ReceiverCardError or PaymentRequestError from z00z_wallets::core::address
    InvalidReceiver(#[from] ReceiverCardError),
    
    #[error("Invalid amount: {0}")]
    InvalidAmount(String),
    
    #[error("Invalid builder state: {0}")]
    InvalidState(&'static str),
    
    #[error("Input validation failed: {0}")]
    // ⚠️ ValidationError is from §5.3 (output_validator.rs — TODO: not yet implemented)
    ValidationFailed(ValidationError),
    
    #[error("Output creation failed: {0}")]
    // ⚠️ OutputError does NOT exist — use StealthError from z00z_wallets::core::stealth
    CreationFailed(StealthError),
}
```

---

#### ✅ Implementation Checklist — Phase 22: API Diagrams, Testing & Performance

> **Scope:** Validation of spec diagrams, integration tests, performance targets  
> **Status:** ❌ NOT done — validate spec diagrams match implementation, add benchmarks.

- [ ] **Verify `create_output()` flow diagram** matches implementation:
  - [ ] Diagram shows: `OutputConfig → pre-flight validate → build_tx_stealth_output → [optional validate_output_self] → TxStealthOutput`
  - [ ] If implementation differs → update SPEC (not code)
- [ ] **Verify `OutputBuilder` typestate diagram** matches implementation:
  - [ ] States match: `NeedsCard → NeedsAsset → NeedsAmount → Ready → TxStealthOutput`
  - [ ] Transitions labeled with method names
- [ ] **Verify `create_outputs_batch()` diagram** matches atomic semantics
- [ ] **Performance targets** (document and verify with benchmarks):
  - [ ] Single output build: < 5 ms on target hardware (Criterion)
  - [ ] Self-validation: < 2 ms
  - [ ] Batch of 100 outputs: < 500 ms (sequential)
  - [ ] Range proof generation: < 100 ms (dominates total time)
- [ ] **Integration tests** (end-to-end, in `tests/` directory):
  - [ ] `tests/stealth_output_integration.rs` — create file
  - [ ] `test_create_and_validate_single_output`
  - [ ] `test_create_outputs_batch_consistency` — all outputs have unique r_pub values
  - [ ] `test_builder_vs_direct_api_same_result` — both produce valid, verifiable outputs
  - [ ] `test_range_proof_verifies_externally` — verify range proof using verifier crate
  - [ ] `test_tag16_unique_per_output` — batch of 10 outputs → all tag16 values differ (probabilistically)
- [ ] **Fuzz testing** (optional SHOULD):
  - [ ] Fuzz `from_untrusted_bytes()` for PaymentRequest and ReceiverCard
  - [ ] Fuzz `build_tx_stealth_output()` with partially garbage receiver_card
- [ ] **CI pipeline check**:
  - [ ] `cargo test --all -- --test-threads=4` passes
  - [ ] `cargo bench -p z00z_wallets --bench stealth_output --no-run` compiles without error
  - [ ] Add benchmark to CI only as compile check (not runtime, too slow)

---

### 👉🏾Phase 22 — API Diagrams, Testing & Performance

### 5.4.6 API Flow Diagrams

#### Simple `create_output()` Flow

```mermaid
flowchart TD
    Start["create_output(receiver, amount, config)"] --> ValidateReceiver{"Validate Receiver"}
    
    ValidateReceiver -->|Invalid| Error1["OutputApiError::InvalidReceiver"]
    ValidateReceiver -->|Valid| LoadConfig["Load or create default config"]
    
    LoadConfig --> CreateRNG["Create RNG provider"]
    CreateRNG --> ValidateInput["ValidatedPaymentInput::from_receiver_input\n(Section 5.1)"]
    
    ValidateInput -->|Failed| Error2["OutputApiError::ValidationFailed"]
    ValidateInput -->|Success| AttemptLoop{"Attempt < max_retries?"}
    
    AttemptLoop -->|Yes| CreateLowLevel["build_tx_stealth_output\n(Section 5.2)"]
    AttemptLoop -->|No| Error3["OutputApiError::MaxRetriesExceeded"]
    
    CreateLowLevel -->|Failed| CheckRetry1{"More retries?"}
    CreateLowLevel -->|Success| ValidateOutput["validate_output_self\n(Section 5.3)"]
    
    CheckRetry1 -->|Yes| AttemptLoop
    CheckRetry1 -->|No| Error4["OutputApiError::CreationFailed"]
    
    ValidateOutput -->|Failed| CheckRetry2{"More retries?"}
    ValidateOutput -->|Success| Success["Return TxStealthOutput"]
    %% NOTE: NOT OutputLeaf
    
    CheckRetry2 -->|Yes| AttemptLoop
    CheckRetry2 -->|No| Error5["OutputApiError::ValidationFailed"]
    
    style Start fill:#aff
    style Success fill:#8f8
    style Error1 fill:#f88
    style Error2 fill:#f88
    style Error3 fill:#f88
    style Error4 fill:#f88
    style Error5 fill:#f88
```

#### OutputBuilder Flow

```mermaid
stateDiagram-v2
    [*] --> New

    state "New: OutputBuilder.new()" as New
    state "Receiver set: receiver(input)" as ReceiverSet
    state "Amount set: amount(u64)" as AmountSet
    state "Inputs validated: validate_inputs()" as InputsValidated
    state "Created: create()" as Created
    state "Validated: validate()" as Validated
    state "Built: build()" as Built
    state "Error" as Error

    New --> ReceiverSet
    ReceiverSet --> AmountSet
    AmountSet --> InputsValidated
    InputsValidated --> Created
    Created --> Validated
    Validated --> Built

    Built --> [*]: "TxStealthOutput"  // ⚠️ formerly (OutputLeaf, SenderWitness) — both do NOT exist

    New --> Error: "Missing receiver"
    ReceiverSet --> Error: "Missing amount"
    AmountSet --> Error: "Validation failed"
    InputsValidated --> Error: "Creation failed"
    Created --> Error: "Validation failed"

    Error --> [*]

    note right of ReceiverSet
        Immediate validation:
        - view_pk valid point
        - owner_handle 32 bytes
        - expiry check (if Request)
    end note

    note right of InputsValidated
        Section 5.1:
        ValidatedPaymentInput
    end note

    note right of Created
        Section 5.2:
        14-step algorithm
        + H-3 hedged randomness
    end note

    note right of Validated
        Section 5.3:
        4 validation checks
    end note

```

---

### 5.4.7 Implementation Phases

> ⚠️ **Path/type corrections for all phases below:**  
>
> - `z00z_core/src/tx/` → `crates/z00z_wallets/src/core/stealth/`  
> - `z00z_core/src/payment/` → `crates/z00z_wallets/src/core/address/`  
> - `CompressedRistretto` → `[u8; 32]`  
> - `ReceiverInput` enum → does NOT exist (use `ReceiverCard` + `Option<&PaymentRequest>`)  
> - `CardError`/`RequestError` → `ReceiverCardError`/`PaymentRequestError`  
> - Phase 1 (Input Types) is ✅ **ALREADY IMPLEMENTED** in `stealth_card.rs`/`stealth_request.rs`

**Recommended incremental development approach:**

#### Phase 1: Input Types (~300 lines)

> ✅ **IMPLEMENTED** — `ReceiverCard` in `stealth_card.rs`, `PaymentRequest` in `stealth_request.rs`  
> See §5.1.1 for actual implementation details.

> ⚠️ OLD notes below are from the pre-implementation spec and NO LONGER accurate:
>
> - ~~Uses `CompressedRistretto` from `curve25519_dalek`~~ → actual type: `[u8; 32]`
> - ~~Uses `ZkHash` for owner_handle derivation~~ → actual: `hash_zk::<WalletReceiverIdHashProdDomain>`

**Tests:**

- Valid/invalid view_pk parsing
- Owner_handle derivation from receiver_secret
- Request expiry checking
- Canonical serialization round-trip

---

#### Phase 2: OutputConfig (~100 lines)

**Deliverables:**

- `OutputConfig` struct with Default impl
- Configuration validation
- RNG/Time provider integration

**Module:** `crates/z00z_wallets/src/core/stealth/output_api.rs` (⚠️ TODO — does NOT yet exist; old spec said `z00z_core/src/tx/output_api.rs` which is WRONG)

**Key Integration:**

- Uses `z00z_utils::rng::RngProvider`
- Uses `z00z_utils::time::TimeProvider`

**Tests:**

- Default configuration correctness
- Custom RNG provider injection (for deterministic tests)
- Mock time provider (for expiry testing)

---

#### Phase 3: `create_output()` Function (~200 lines)

**Deliverables:**

- High-level `create_output()` function
- `OutputApiError` enum
- Retry logic with exponential backoff
- Integration with Section 5.2 + 5.3

**Module:** `crates/z00z_wallets/src/core/stealth/output_api.rs` (⚠️ TODO — does NOT yet exist; old spec said `z00z_core/src/tx/output_api.rs` which is WRONG)

**Key Integration:**

- Calls `ValidatedPaymentInput::from_receiver_input()` (Section 5.1)
- Calls `build_tx_stealth_output()` (Section 5.2) — ⚠️ `create_output_leaf()` does NOT exist
- Calls `validate_output_self()` (Section 5.3)

**Tests:**

- Success case (valid receiver + amount)
- Invalid receiver rejection
- Retry logic on transient failures
- Validation failure handling

---

#### Phase 4: Batch Creation (~150 lines)

**Deliverables:**

- `create_outputs_batch()` function
- Atomic all-or-nothing semantics
- Efficient RNG sharing

**Module:** `crates/z00z_wallets/src/core/stealth/output_api.rs` (⚠️ TODO — does NOT yet exist; old spec said `z00z_core/src/tx/output_api.rs` which is WRONG)

**Key Integration:**

- Reuses `create_output()` internally
- Shares OutputConfig across outputs

**Tests:**

- Batch of valid outputs
- First output failure (atomic rollback)
- Middle output failure (atomic rollback)
- Empty batch handling

---

#### Phase 5: OutputBuilder (~400 lines)

**Deliverables:**

- `OutputBuilder` struct with full state machine
- All builder methods (receiver, amount, validate_inputs, create, validate, build)
- `BuilderError` enum
- State transition validation

**Module:** `crates/z00z_wallets/src/core/stealth/output_builder_api.rs` (⚠️ TODO — does NOT yet exist; old spec said `z00z_core/src/tx/output_builder_api.rs` which is WRONG)

**Key Integration:**

- Calls same low-level functions as `create_output()`
- ⚠️ Does NOT expose `SenderWitness` (does not exist); k_dh recomputable from sender_wallet

**Tests:**

- Happy path (all steps in order)
- Invalid state transitions (skip step detection)
- Reset and reuse
- Multiple outputs from same builder (after reset)

---

#### Phase 6: Documentation & Examples (~200 lines rustdoc)

**Deliverables:**

- Comprehensive rustdoc comments for all public APIs
- Usage examples in doc comments
- Integration examples (wallet workflow)
- Error handling patterns

**Module:** All public API modules

**See:** Rustdoc examples already provided in spec above

---

### 5.4.8 Testing Strategy

#### Input Type Unit Tests

**Input Types Tests:**

> ⚠️ **OUTDATED PSEUDOCODE** — the following test code references APIs that do NOT exist or have wrong signatures:
>
> - `ReceiverCard::from_receiver_secret()` does **NOT** exist — use `ReceiverKeys::from_receiver_secret()` then `ReceiverCard::new(&keys, ...)`
> - `card.view_pk.decompress()` — `view_pk` is `[u8;32]`, not `CompressedRistretto`; use `z00z_crypto::Z00ZRistrettoPoint::from_canonical_bytes(&card.view_pk)` instead
> - `request.is_expired(current_time)` — actual `is_expired()` takes **NO argument** (uses internal `SystemTimeProvider`)
> - `request.validate(current_time)` — not a direct method; use `request.check_validity()` or `ValidatePaymentRequest::validate(request, chain_id)`
> - `ReceiverInput` enum and its methods (`view_pk()`, `owner_handle()`, `req_id()`) do **NOT** exist
> **Actual API**: `build_tx_stealth_output(receiver_card, Option<&PaymentRequest>, ...)` takes `ReceiverCard` and `Option<&PaymentRequest>` separately.

**✅ Minimal correct skeleton for §5.4.8 tests (compile-ready, use this as base):**

```rust
#[cfg(test)]
mod tests_section_5_4 {
    use z00z_wallets::core::stealth::output::{
        build_tx_stealth_output, TxStealthOutput, SenderWallet,
    };
    use z00z_wallets::core::address::{
        ReceiverCard, ReceiverKeys, PaymentRequest, ValidityStatus,
    };
    use z00z_wallets::core::key::ReceiverSecret;
    use z00z_utils::time::SystemTimeProvider;

    fn make_card(secret: &[u8; 32]) -> ReceiverCard {
        // ReceiverKeys::from_receiver_secret() takes owned ReceiverSecret, NOT &[u8; 32]
        let receiver_secret = ReceiverSecret::from_bytes(*secret)
            .expect("non-zero secret");
        let keys = ReceiverKeys::from_receiver_secret(receiver_secret)
            .expect("valid keys");
        ReceiverCard::new(&keys, None, None).expect("valid card")
    }

    #[test]
    fn test_receiver_card_view_pk_valid() {
        let card = make_card(&[0x42u8; 32]);
        // view_pk is [u8;32] — use Z00ZRistrettoPoint::from_canonical_bytes, NOT .decompress()
        use z00z_crypto::Z00ZRistrettoPoint;
        assert!(Z00ZRistrettoPoint::from_canonical_bytes(&card.view_pk).is_ok());
        assert_eq!(card.owner_handle.len(), 32);
    }

    #[test]
    fn test_payment_request_validity() {
        // Use check_validity(), NOT is_expired(timestamp) or validate(timestamp)
        // check_validity() uses SystemTimeProvider internally — no argument
        // For deterministic tests: TODO add check_validity_at(u64) (§5.1.2.2)
    }
}
```


---

### 5.4.9 Performance Considerations

**Cost Analysis:**

| Operation                                      | Time       | Bottleneck            |
| ---------------------------------------------- | ---------- | --------------------- |
| Input validation                               | ~10μs      | Point decompression   |
| Section 5.1 (ReceiverCard validation)          | ~20μs      | ECDH check            |
| Section 5.2 (build_tx_stealth_output)          | ~200μs     | Pedersen + Encryption |
| Section 5.3 (validate_output_self)             | ~90μs      | Decryption + Checks   |
| **Total (create_output)**                      | **~320μs** | Acceptable for wallet |

**Batch Optimization:**

```rust
// Sequential (slow): ~320μs × N outputs
for (receiver, amount) in outputs_spec {
    create_output(receiver, amount, config)?;
}

// Batch (optimized): ~220μs × N outputs
// (Shares RNG, config parsing, validation setup)
create_outputs_batch(outputs_spec, config)?;

// Potential future: Parallel batch (Rayon)
// ~220μs × N / num_cores (if N large)
outputs_spec.par_iter()
    .map(|(r, a)| create_output(r, a, config))
    .collect()
```

---

### 5.4.10 Security Analysis

**Threat Model:**

| Threat                     | Attack Vector                    | Defense                       | Result                   |
| -------------------------- | -------------------------------- | ----------------------------- | ------------------------ |
| **Invalid Receiver**       | Malicious/corrupted ReceiverCard | Immediate validation          | Rejected before creation |
| **Expired Request**        | Old PaymentRequest               | Expiry check                  | Rejected                 |
| **Directory Substitution** | MITM on ReceiverCard             | Identity signature (optional) | Detectable               |
| **RNG Failure**            | Weak entropy, VM snapshot        | H-3 hedged randomness + retry | Recovered                |
| **Implementation Bug**     | Wrong crypto                     | Section 5.3 validation        | Caught before submission |

**What Section 5.4 provides:**

- ✅ **User-friendly error messages** (not just "crypto error")
- ✅ **Automatic retry** for transient failures
- ✅ **Builder pattern** for explicit control
- ✅ **Type safety** (compile-time state machine)

**What Section 5.4 does NOT protect:**

- ❌ **Sender wallet compromise** (secret key stolen)
- ❌ **Receiver identity confusion** (wrong card pinned)
- ❌ **Network-level attacks** (MITM on submission)

---

### 👉🏾Phase 23 — Integration Summary & Cleanup

### 5.4.11 Integration Summary

**Dependencies (what Section 5.4 uses):**

| Component | From Section | Purpose |
| --- | --- | --- |
| `ReceiverCard` | 5.1 | Input (⚠️ `ValidatedPaymentInput` does NOT exist) |
| `build_tx_stealth_output()` | 5.2 | Low-level creation (⚠️ `create_output_leaf()` does NOT exist) |
| `validate_output_self()` | 5.3 | Validation (TODO: not yet implemented) |
| `TxStealthOutput` | 5.2.14 | Output structure (⚠️ `OutputLeaf` does NOT exist) |
| (no public struct) | 5.2.15 | Intermediate values (⚠️ `SenderWitness` does NOT exist) |
| `RngProvider` | `z00z_utils` | RNG abstraction |
| `TimeProvider` | `z00z_utils` | Time abstraction |

**Reverse Dependencies (what uses Section 5.4):**

| Component          | From Section | How it uses Section 5.4                   |
| ------------------ | ------------ | ----------------------------------------- |
| Wallet TX creation | Future       | Calls `create_output()` / `OutputBuilder` |
| Multi-recipient TX | Future       | Calls `create_outputs_batch()`            |
| Testing harness    | Tests        | Uses `OutputBuilder` with mock providers  |

**Module Hierarchy:**

```text
// ⚠️ PLANNED TODO — z00z_core::tx does NOT exist
// Actual planned location: z00z_wallets::core::stealth

z00z_wallets::core::stealth             (PLANNED — does NOT yet exist as sub-modules)
├── output_api          (Section 5.4 - THIS — ⚠️ PLANNED TODO)
│   ├── create_output()
│   ├── create_outputs_batch()
│   └── OutputBuilder
├── output              (Section 5.2)
│   └── build_tx_stealth_output()       // ✅ IMPLEMENTED in output.rs
├── output_validator    (Section 5.3)
│   └── validate_output_self()          // ⚠️ PLANNED TODO — does not yet exist
└── (types in z00z_core::assets::leaf)
    └── TxStealthOutput  // ⚠️ NOT OutputLeaf (does not exist)

// ⚠️ PLANNED TODO — z00z_core::payment does NOT exist
// Actual planned location: z00z_wallets::core::stealth

z00z_wallets::core::stealth             (PLANNED)
└── receiver_input                      // ⚠️ PLANNED TODO
    ├── ReceiverCard
    ├── PaymentRequest
    └── ReceiverInput                   // ⚠️ PLANNED TODO — does not yet exist
```

---

### 5.4.12 Next Steps for Implementation

**Development Path:**

1. **Phase 1** (Input Types) - ~2-3 hours
   - ⚠️ ALREADY IMPLEMENTED: `ReceiverCard` in `stealth_card.rs`, `PaymentRequest` in `stealth_request.rs`
   - ~~`z00z_core/src/payment/`~~ → actual location: `crates/z00z_wallets/src/core/address/`
   - `ReceiverInput` enum does NOT exist — no need to create it

2. **Phase 2** (OutputConfig) - ~1 hour
   - Add OutputConfig to `crates/z00z_wallets/src/core/stealth/output_api.rs` (⚠️ TODO — file does NOT exist yet)
   - Integrate RngProvider/TimeProvider
   - Write default config tests

3. **Phase 3** (`create_output()`) - ~3-4 hours
   - Implement high-level function
   - Add retry logic
   - Write success/failure tests

4. **Phase 4** (Batch) - ~2 hours
   - Implement `create_outputs_batch()`
   - Add atomic semantics
   - Write batch tests

5. **Phase 5** (OutputBuilder) - ~4-5 hours
   - Implement builder state machine
   - Add all builder methods
   - Write state transition tests

6. **Phase 6** (Documentation) - ~2-3 hours
   - Complete rustdoc comments
   - Add usage examples
   - Write integration guide

#### Estimated Total Effort: ~14-18 hours

**Success Criteria:**

- [ ] All input types implemented and tested
- [ ] `create_output()` working with Section 5.2+5.3
- [ ] Batch creation tested with multiple outputs
- [ ] OutputBuilder state machine validated
- [ ] All unit tests passing (>90% coverage)
- [ ] Integration tests with receiver-side decryption
- [ ] Rustdoc examples compile and run
- [ ] Performance benchmarks meet targets

---

### 👉🏾Phase 24

## 🗑️ Codebase Cleanup — Deprecated Items

### ✅ 1. `facade_ecdh::sender_derive_dh()` — **REMOVED**

**File:** `crates/z00z_wallets/src/core/stealth/facade_ecdh.rs`  
**Reason:** Bypassed H-3 hedged randomness; used raw ECDH without domain separation.  
**Done:** Function deleted. `tx/mod.rs` migrated to `sender_derive_dh_with_r` + `SystemRngProvider`. Tests updated.

### ✅ 2. `facade_ecdh::generate_hedged_r()` — **REMOVED**

**File:** `crates/z00z_wallets/src/core/stealth/facade_ecdh.rs`  
**Reason:** Legacy hash path using `h2scalar_zk` without domain parameter.  
**Done:** Function deleted. Test callers migrated to `derive_r_hedged()` from `z00z_wallets::core::stealth::ephemeral`.

### 3. `h2scalar_zk()` — legacy non-domain-parameterized hash

**File:** `crates/z00z_crypto/src/hash.rs` (definition)  
**Callers (non-test):** `crates/z00z_core/src/assets/leaf.rs`, `compute_golden.rs`  
**Reason:** Predates domain-separation design; not parameterized by hash domain.  
**Action:**

1. Add `#[deprecated(since = "0.0.0", note = "Use h2s_zk::<D>() with explicit domain parameter")]` to function.
2. Migrate each production caller to `h2s_zk::<D>()` / `hash_zk::<D>()` with the appropriate domain.
3. Keep function accessible from `compute_golden.rs` for golden-vector tests only.
4. Remove once all production callers are migrated.

### ✅ 4. `ephemeral::generate_independent_sender_salt()` — **REMOVED**

**File:** `crates/z00z_wallets/src/core/stealth/ephemeral.rs`  
**Reason:** Functionally identical to `generate_sender_salt()`; name "independent" was misleading.  
**Done:** Function and its test deleted. Use `generate_sender_salt()` directly.  

---

#### ✅ Implementation Checklist — Phase 23: Integration Summary & Cleanup

> **Files:** `lib.rs`, `TxStealthOutput`, domain files, deprecated functions  
> **Status:** ❌ NOT done — CRITICAL cleanup tasks required before first release.

- [ ] **`TxStealthOutput.tag16` migration plan** — currently `Option<u16>` in production API:
  - [ ] Keep current wire/API compatibility while field is `Option<u16>`
  - [ ] Enforce runtime invariant: creation path MUST set `tag16 = Some(value)` (never `None`)
  - [ ] Prepare semver-safe migration path to `u16` in next MAJOR version
  - [ ] Update serializer/tests only in the migration PR (not as a silent PATCH/MINOR break)
- [ ] **Deprecate `h2scalar_zk()`** (legacy function):
  - [ ] Add `#[deprecated(since = "0.0.0", note = "Use h2s_zk::<Domain>() with explicit domain parameter")]`
  - [ ] Audit all callers: `grep -rn "h2scalar_zk" crates/ --include="*.rs"`
  - [ ] Migrate every production caller to `h2s_zk::<Domain>(label, inputs)`
  - [ ] Keep accessible from `compute_golden.rs` for golden-vector tests only
  - [ ] Schedule removal in next MAJOR version once all production callers migrated
- [ ] **Re-export audit in `z00z_wallets/src/lib.rs`**:
  - [ ] `pub use core::stealth::output::TxStealthOutput;`
  - [ ] `pub use core::stealth::output_api::{OutputConfig, OutputApiError, create_output, create_outputs_batch};`
  - [ ] `pub use core::stealth::output_builder_api::OutputBuilder;`
  - [ ] `pub use core::stealth::recent_r_cache::RecentRCache;`
  - [ ] `pub use core::address::pinned_cards::{PinnedReceiverCards, PinCheckResult};`
  - [ ] `pub use core::address::stealth_card::{ReceiverCard, ReceiverKeys, ReceiverCardError};`
  - [ ] `pub use core::address::stealth_request::{PaymentRequest, PaymentRequestError, ValidityStatus, ValidatedRequest};`
  - [ ] Verify NO internal types leak into public API surface
- [ ] **`cargo doc --no-deps` — zero warnings** for `z00z_wallets`:
  - [ ] Every public item has `///` doc comment
  - [ ] Every `/// # Examples` block compiles
  - [ ] No broken intra-doc links
- [ ] **Final quality gate before PR**:
  - [ ] `cargo fmt --all` — no diffs
  - [ ] `cargo clippy --all-targets --all-features -- -D warnings` — zero warnings
  - [ ] `cargo test --all` — all tests pass
  - [ ] `cargo doc --no-deps` — zero doc warnings
  - [ ] `./scripts/run-deepwiki.sh crate z00z_wallets` — updated wiki generated
- [ ] **Version bump** via `./scripts/version-manager.sh`:
  - [ ] MINOR bump (new public API added)
  - [ ] `./scripts/version-manager.sh minor -m "Add OutputBuilder, batch API, sender-side validation, PinnedReceiverCards"`
  - [ ] Sync: `./scripts/version-manager.sh sync -b z00z-wallet`
- [ ] **Signal**: `./scripts/play_tone.sh`

---
