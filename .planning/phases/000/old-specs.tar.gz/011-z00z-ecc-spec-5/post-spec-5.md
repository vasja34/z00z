# Post-Spec-5 Integration And Closure Spec

📌 This file is the only canonical post-Spec-5 document for explanation, planning, and implementation of the remaining Stage-3 and Stage-4 protocol work.

📌 It replaces the former roadmap split. No remaining track in this area may rely on a second roadmap file, a planning note, or a matrix note as an equal source of truth.

📌 This document is intentionally self-contained. It carries the closure rules, the blocker model, the Stage-1 dependency contract summary, the Stage-3 and Stage-4 live verifier map, the recommended implementation order, and code-accurate snippets that show where the work lands.

📌 The remaining out-of-scope work is limited to exactly four tracks:

1. claim proof;
2. chain authority;
3. spend-proof verifier;
4. fee-proof verifier.

📌 No fifth track may be introduced in this area unless this file is updated first.

📌 Checklist completion in this file means the closure contract has been reviewed and frozen accurately at the documentation layer. It does not, by itself, mean that protocol-complete implementation already exists for the four remaining tracks.

## Phase 1. Purpose And Current Decision

### 1.1 Document Role

📌 The purpose of this file is to let the repository explain, implement, and close the remaining post-Spec-5 work without pretending that authenticated Stage-1 authority, the final public claim proof, the final public spend proof, or the final public fee proof are already done.

📌 This file is the only closure contract. Matrix files remain descriptive runtime snapshots only.

📌 Phase 1 is complete only when the repository has one unambiguous post-Spec-5 closure document and that document already contains the closure model needed by later phases.

#### Document Checklist

- [x] Establish `post-spec-5.md` as the only normative post-Spec-5 closure document.
- [x] Remove the former split-roadmap dependency so Phase 1 no longer points to a second canonical planning artifact.
- [x] State explicitly that runtime matrix files are descriptive only and cannot override closure logic.
- [x] Keep the blocker model, track boundaries, and closure conditions inside this file so a developer does not need deleted roadmap material to understand post-Spec-5 scope.

### 1.2 Decision Boundary

📌 Protocol-complete issues stay open until the closure gate for the relevant track is satisfied in code and tests.

📌 There is no principal architecture blocker to consolidating all remaining work here.

📌 There is one real cross-track dependency blocker class: the chain-authority track cannot be closed until Stage-3 consumes a verified Stage-1 artifact set rather than transitional fixed-root or zero-root authority shortcuts.

📌 This does not mean that chain authority is the only remaining blocker overall. Claim proof, spend proof, and fee proof still have their own protocol-complete closure gates and must not be marked complete before their transitional final-acceptance paths are retired.

📌 Phase 1 must therefore freeze two things at once: the one cross-track blocker model and the rule that every track still owns its own protocol-complete closure gate.

#### Boundary Checklist

- [x] Record that chain authority is the only cross-track dependency blocker across the four remaining tracks.
- [x] Record separately that claim proof, spend proof, and fee proof still retain independent protocol-complete closure gates.
- [x] Forbid global post-Spec-5 completion claims while any one track-level closure gate remains open.
- [x] Freeze the distinction between documentation-layer closure and protocol-complete closure so later phases cannot collapse them into one status.

## Phase 2. Relationship To ECC Part 1 And Live Code

### 2.1 Source Hierarchy

📌 `crates/Z00Z-ECC-SPEC_part1.md` remains the source for cryptographic logic, ownership semantics, public-statement discipline, and the general direction of movement.

📌 The current codebase remains the implementation authority for exact module ownership, live helper names, and active function signatures.

📌 Therefore the rule is:

- use ECC Part 1 for logic and cryptography;
- use live Rust code for exact implementation surfaces;
- do not revive obsolete APIs just because they appear in older text.

📌 Live helper presence does not upgrade a transitional helper into a final public verifier. If a live path still depends on `recv_sec`, reconstructed witness material, self-decrypt state, or verifier-owned local secrets, that path stays transitional even when its module location and function signature are canonical.

📌 Phase 2 is complete only when this precedence rule is frozen clearly enough that later phases cannot reinterpret old text as API authority or reinterpret live code as cryptographic-logic authority.

#### Source Hierarchy Checklist

- [x] Freeze ECC Part 1 as the authority for cryptographic logic, ownership semantics, and public-statement intent.
- [x] Freeze live Rust modules as the implementation authority for exact function names, module ownership, and active function signatures.
- [x] Freeze the mismatch-resolution rule: Part 1 controls logic, live code controls implementation surfaces.
- [x] Forbid revival of obsolete Part 1 APIs as implementation authority in later phases.

### 2.2 Mandatory Imported Principles

📌 The following Part 1 principles remain mandatory for all four tracks:

- public statements stay explicit and domain-separated;
- fail-closed verification stays the default behavior;
- owner binding must remain tied to receiver-bound stealth semantics rather than transport-only bytes;
- no verifier may be called public if final acceptance still depends on local secret material, local witness reconstruction, or verifier-owned decryption state;
- authenticated chain authority must come from an explicit verified artifact path and not from folklore constants.

📌 Phase 2 is complete only when these principles are frozen as non-negotiable design constraints for all later claim, authority, spend, and fee work.

📌 In the current codebase this means, at minimum, that secret-bound helpers such as self-decrypt and spend-witness gates remain transitional verifier material rather than final public-verifier endpoints until their final acceptance logic no longer depends on local secret recovery or witness reconstruction.

#### Imported Principles Checklist

- [x] Freeze explicit named statement objects as mandatory for every final verifier path.
- [x] Freeze explicit domain separation and explicit statement-hash inputs as mandatory design constraints.
- [x] Freeze fail-closed malformed-bytes and malformed-statement handling as mandatory verifier behavior.
- [x] Freeze the rule that no verifier is public if final acceptance still consumes `recv_sec`, reconstructed witness state, or decrypt-only local state, and treat such helpers as transitional until that dependency is removed.
- [x] Freeze the rule that authenticated authority cannot be inferred from fixed roots, zero roots, unnamed constants, or deployment folklore.

## Phase 3. Canonical Boundary Summary

### 3.1 Canonical Artifact Set

📌 The post-Spec-5 area has five canonical artifact classes, but only this file defines the full closure contract.

| Artifact | Canonical role | Normative scope |
| --- | --- | --- |
| `spec-5.md` | frozen Spec-5 scope | historical and parent freeze only |
| `post-spec-5.md` | full closure contract | full |
| `stage-1-authority-boundary.md` | Stage-1 dependency boundary | narrow Stage-1 contract |
| `stage-3-assumptions.md` | Stage-3 upstream wallet assumptions | narrow Stage-3 assumptions |
| subordinate boundary note set | frozen or descriptive subordinate notes | non-normative |

#### Artifact Checklist

- [x] Freeze `post-spec-5.md` as the only full post-Spec-5 closure contract for closure rules, target mechanisms, blocker classes, and issue-closure conditions.
- [x] Freeze `stage-1-authority-boundary.md` as a narrow Stage-1 dependency document only, without promoting it into a cross-track closure source.
- [x] Freeze `stage-3-assumptions.md` as the only Stage-3 upstream wallet-assumptions source, without letting it grow cross-track closure logic.
- [x] Freeze the canonical-boundary rule that no second normative document may duplicate this file's closure tables without explicit deprecation and replacement of the old source.

### 3.2 Frozen And Runtime Note Limits

📌 The Phase-3 boundary notes are:

- `stage-3-frozen-model.md`;
- `stage-3-proof-matrix.md`;
- `stage4-trust-boundary.md`;
- `stage4-verifier-matrix.md`.

📌 `stage-3-frozen-model.md` is a narrow frozen-slice note. It may freeze the current approved Stage-3 slice boundary, but it must not add closure rules, upstream wallet assumptions, or protocol guarantees beyond this file and `stage-3-assumptions.md`.

📌 `stage-3-proof-matrix.md`, `stage4-trust-boundary.md`, and `stage4-verifier-matrix.md` are descriptive notes. They may record current behavior, active gates, owner modules, and locked tests, but they must not add closure rules or protocol guarantees beyond this file.

📌 In the current repository state, each boundary note already links back to this file as the canonical closure source and stays subordinate to it rather than acting as an independent closure authority.

#### Boundary Note Checklist

- [x] Freeze the rule that the Stage-3 frozen-model note is a narrow slice-boundary note only and not a second runtime or closure authority source.
- [x] Freeze the rule that descriptive notes mirror live-path behavior, active gates, owner modules, and locked tests rather than inventing closure policy ahead of implementation.
- [x] Freeze the rule that forward-looking boundary language is allowed in subordinate notes only when it is already defined by this file or by the canonical assumptions document.
- [x] Freeze the same-PR repair rule: any disagreement between a subordinate boundary note and this file is a documentation bug that must be corrected together.

## Phase 4. Four-Track Status Ledger

### 4.1 Open Track Inventory

📌 All four remaining tracks are open.

| Track | Live owner modules | Main blocker class | Can close before Stage-1 authority is complete |
| --- | --- | --- | --- |
| Claim proof | `z00z_crypto::claim`, `z00z_wallets::core::tx::claim_tx` | final public proof design and verifier replacement | Yes |
| Chain authority | `z00z_crypto::claim`, `z00z_wallets::core::tx::claim_tx`, `z00z_simulator::scenario_1::stage_3` | verified Stage-1 artifact consumption | No |
| Spend-proof verifier | `z00z_wallets::core::tx::output_flow`, `z00z_wallets::core::tx::witness_gate`, `z00z_simulator::scenario_1::stage_4` | witness-bound to public-proof replacement | Yes |
| Fee-proof verifier | `z00z_wallets::core::tx::output_flow`, `z00z_simulator::scenario_1::stage_4` | formula split to public-proof replacement | Yes |

📌 “Yes” means the track may be designed, implemented, and closed before Stage-1 authenticated authority is complete, but it still must not over-claim chain-authenticated meaning or silently freeze transitional authority placeholders into the final design.

📌 In the current repository state, each track already has one explicit live owner-module set in code and in the subordinate notes. The remaining open work is final-mechanism replacement, not owner discovery. For chain authority, the current live surface already spans statement and signature code in `z00z_crypto::claim`, verifier code in `z00z_wallets::core::tx::claim_tx`, and transitional package-emission code in `z00z_simulator::scenario_1::stage_3`, while the later verified Stage-1 verifier integration surface remains future work.

#### Track Ledger Checklist

- [x] Freeze one explicit live owner-module set for each track in this ledger so later implementation work starts from named code ownership rather than module discovery.
- [x] Freeze one replacement direction per track in this ledger and forbid parallel competing final-design claims in the same repository state.
- [x] Freeze the rule that authority-closure work stays blocked on a verified Stage-1 artifact-consumption path rather than on transitional placeholder semantics.
- [x] Freeze the rule that claim, spend, and fee tracks may proceed before Stage-1 only as non-authenticated-authority work.

### 4.2 Cross-Track Dependency Diagram

```mermaid
flowchart TD
    P1[ECC Part 1 Logic] --> Claim
    P1 --> Spend
    P1 --> Fee
    P1 --> Auth
    Stage1[Verified Stage-1 Artifact Set] --> Auth
    Claim[Claim Proof Track]
    Spend[Spend-Proof Track]
    Fee[Fee-Proof Track]
    Auth[Chain Authority Track]
    Claim --> Close[Protocol-Complete Closure]
    Spend --> Close
    Fee --> Close
    Auth --> Close
```

📌 The current codebase still matches this dependency model: chain authority is the only track that already names a verified Stage-1 artifact dependency, while spend and fee paths stay bound to witness, balance, and formula gates without consuming authenticated Stage-1 facts.

#### Dependency Diagram Checklist

- [x] Freeze this dependency model as the current canonical map unless a new hard dependency is proven in code and documented here first.
- [x] Freeze the rule that spend proof does not become Stage-1-dependent unless spend acceptance starts consuming authenticated-authority facts directly.
- [x] Freeze the rule that fee proof does not become Stage-1-dependent unless fee acceptance starts consuming authenticated-authority facts directly.
- [x] Freeze the rule that claim proof must be reclassified before merge if it ever begins consuming authenticated-authority fields.

## Phase 5. Global Closure Rules

### 5.1 Track-Level Closure Conditions

📌 A track may be marked closed only when all of the following are true:

1. the live code path uses the target mechanism and no longer depends on the transitional path for final acceptance;
2. fail-closed tests prove that the old path is no longer a hidden success branch;
3. the relevant subordinate boundary note records the new live verifier honestly;
4. this file is still accurate after the implementation lands.

📌 In the current repository state, the named transitional final-acceptance branches are already explicit enough to ground this rule: the typed placeholder claim-proof path plus `owner_attest_hex` for claim-owner binding, the typed authority-signature path plus `ZERO_ROOT` and equivalent non-authoritative authority placeholders for chain authority, `verify_spend_witness_gate` for final witness-bound spend acceptance, and the `verify_fee_matches_formula` plus `verify_plaintext_balance_with_fee` split for fee acceptance.

#### Track Closure Checklist

- [x] Freeze the rule that each track must name its exact transitional final-acceptance branch before any closure claim is allowed.
- [x] Freeze the rule that transitional success paths must be removed or demoted in code before closure is claimed in documentation.
- [x] Freeze the rule that protocol-complete closure requires both one positive final-path test and fail-closed coverage against each retired transitional success branch.
- [x] Freeze the rule that the relevant subordinate boundary note is updated only after code and tests establish the new live verifier.
- [x] Freeze the rule that this file must be re-read and updated whenever implementation changes blockers, live verifiers, or closure gates.

### 5.2 Issue Closure Policy

📌 An issue may be closed as editorial-only before code lands only if it makes no protocol-complete claim.

📌 No protocol-complete issue may be closed while any transitional success branch named in this file still determines final acceptance.

📌 The current policy boundary is therefore strict: editorial and planning cleanup may close early, but any issue that implies final claim proof, authenticated authority, final public spend proof, final public fee proof, or global post-Spec-5 completion stays open until the corresponding track-level closure conditions are satisfied in code, tests, subordinate notes, and this file.

#### Issue Policy Checklist

- [x] Freeze the issue taxonomy required by this file: editorial, planning, implementation, protocol-complete, or cross-track dependency.
- [x] Freeze the rule that editorial and planning issues may close early only when they make no protocol-complete claim.
- [x] Freeze the rule that protocol-complete issues stay open until the exact track-level closure conditions are satisfied in code, tests, subordinate notes, and this file.
- [x] Freeze the rule that partial implementation summaries must not be treated as final completion for issue closure.

## Phase 6. Stage-1 Dependency Contract Summary

### 6.1 Verified Artifact Set

📌 Stage-1 authority integration is intentionally narrow. Later Stage-3 and Stage-4 consumers may rely only on a verified three-artifact set:

| Artifact | Required purpose | Later-stage readable facts |
| --- | --- | --- |
| `GenesisAuthority` | authenticated authority statement | `manifest_hash` only |
| `GenesisManifest` | canonical accepted manifest payload | `manifest_hash`, `config_hash`, `root_hash` |
| `Stage1Assumptions` | machine-readable mirror bundle | `manifest_hash`, `config_hash`, `accepted_root_hash` |

📌 In the current repository state, this is a frozen dependency contract only. The exact three-artifact set and the exact readable field surface are already fixed here and in `stage-1-authority-boundary.md`, but the repository does not yet expose a final verified Stage-1 authority bundle as a live code path.

#### Artifact Set Checklist

- [x] Freeze the exact three-artifact Stage-1 contract for later Spec-5 consumers: `GenesisAuthority`, `GenesisManifest`, and `Stage1Assumptions`.
- [x] Freeze the exact readable field surface that later Stage-3 and Stage-4 code may consume from those artifacts.
- [x] Freeze the rule that raw manifest bytes, extra policy fields, and ad hoc deployment metadata are outside the allowed Stage-1 read surface.
- [x] Freeze the rule that later implementation must enforce this narrow field surface through typed accessors or typed adapter code rather than through comments alone.

### 6.2 Acceptance Rule

📌 The acceptance rule for authenticated authority is exact:

1. the canonical Stage-1 verifier accepts `GenesisAuthority` by validating `authority_sig` against `authority_pk`;
2. `GenesisAuthority.manifest_hash` equals `GenesisManifest.manifest_hash`;
3. `Stage1Assumptions.manifest_hash` equals `GenesisManifest.manifest_hash`;
4. `Stage1Assumptions.config_hash` equals `GenesisManifest.config_hash`;
5. `Stage1Assumptions.accepted_root_hash` equals `GenesisManifest.root_hash`.

📌 If any of those checks is missing, later stages may use only transitional non-authoritative bindings and must not describe them as authenticated authority.

📌 In the current repository state, this acceptance rule is fully specified but not yet materialized as one canonical live verifier entry point. The rule remains normative for later implementation and for judging whether any Stage-3 or Stage-4 path may claim authenticated authority.

#### Acceptance Rule Checklist

- [x] Freeze the rule that the canonical Stage-1 verifier must enforce all five acceptance checks as one atomic result before any authenticated-authority claim is allowed.
- [x] Freeze the rule that any missing, malformed, unsigned, or mismatched artifact forces a fail result rather than partial authenticated success.
- [x] Freeze the rule that later Stage-1 verifier output must stay typed so partially checked artifacts cannot be treated as fully verified authority.
- [x] Freeze the requirement that later implementation adds locked negative coverage for each one of the five acceptance checks.

### 6.3 Replacement Rule

📌 Once the verified three-artifact set exists, it replaces every transitional fixed-root and zero-root authority success path in live claim-authority code and supporting tests.

📌 In the current repository state, those transitional authority shortcuts are still live in both code and tests: `z00z_wallets::core::tx::claim_tx` builds `GenesisClaimStatement` with `ZERO_ROOT`, `z00z_simulator::scenario_1::stage_3` emits the same placeholder root in its claim statement builder, `z00z_simulator::tests::support::claim_pkg_crypto` still encodes the same placeholder-root path in test support, and `z00z_wallets::core::tx::claim_tx_tests` still synthesizes success coverage from the same verifier-built placeholder-root statement path.

#### Replacement Rule Checklist

- [x] Freeze the rule that every live claim-authority path still succeeding through fixed-root or zero-root authority assumptions must be explicitly located before authority closure is claimed.
- [x] Freeze the rule that each such live code or test path must be replaced with consumption of the verified Stage-1 authority bundle before authority closure is claimed.
- [x] Freeze the rule that tests encoding fixed-root or zero-root authority as authenticated success must be removed or converted into explicit non-authoritative coverage.
- [x] Freeze the rule that the implementation PR for authority closure must prove, including by repository search, that transitional authority shortcuts are no longer reachable as authenticated success paths.

## Phase 7. Live Runtime Map

### 7.1 Current Acceptance Table

📌 The current code already exposes the exact choke points that define the remaining work.

| Track | Current live acceptance path | Current status |
| --- | --- | --- |
| Claim proof | `ClaimTxVerifierImpl::verify` runs `verify_structure`, `verify_scope`, `verify_tx_fields`, `verify_nullifier`, `verify_recipient_card`, `verify_portable_leaf`, `verify_claim_proof`, `verify_claim_authority`, `verify_owner_attest`, and `verify_digest` in one fail-closed order | fail-closed but still transitional because the typed placeholder proof and `owner_attest_hex` branch remain part of final success |
| Chain authority | `ClaimTxVerifierImpl::verify_claim_authority` and `verify_claim_authority_sig` run after proof verification and before owner-attest and digest success | typed statement-signature path, not final authenticated Stage-1 manifest authority |
| Spend proof | `load_claim_pkgs`, `verify_self_decrypt`, `verify_fee_matches_formula`, `verify_plaintext_balance_with_fee`, `verify_commitment_balance_gate`, `verify_spend_witness_gate`, and `verify_tx_package` define the current Stage-4 spend-acceptance chain | fail-closed but still witness-bound before final tx package transport verification |
| Fee proof | `verify_fee_matches_formula`, `verify_plaintext_balance_with_fee`, and the fee-inclusive commitment-balance gate run before the spend-witness gate | deterministic but still split across multiple runtime gates rather than one final public proof |

📌 In the current repository state, the current terminal Stage-3 success gate is `ClaimTxVerifierImpl::verify_digest`, while the current terminal Stage-4 verifier gate is `verify_tx_package` after the claim-package prerequisite, the fee checks, the commitment-balance gate, and the witness-bound spend gate have already succeeded.

#### Runtime Table Checklist

- [x] Treat this table as the only allowed starting point for new implementation work.
- [x] Freeze the rule that no new verifier path may be added without updating this table in the same PR.
- [x] Keep every row tied to real code entry points and live gate order rather than to conceptual names only.
- [x] Re-verify this table against the current Stage-3 and Stage-4 acceptance code before claiming this phase complete.

### 7.2 Current Acceptance Flow

```mermaid
flowchart LR
    C0[Claim Package Bytes] --> C1[verify_structure and verify_scope]
    C1 --> C2[verify_tx_fields and verify_nullifier]
    C2 --> C3[verify_recipient_card and verify_portable_leaf]
    C3 --> C4[verify_claim_proof]
    C4 --> C5[verify_claim_authority]
    C5 --> C6[verify_owner_attest]
    C6 --> C7[verify_digest]
    C7 --> C8[Stage-3 Accept]

    T0[Claim Bundle Prerequisite] --> T1[load_claim_pkgs]
    T1 --> T2[verify_self_decrypt]
    T2 --> T3[verify_fee_matches_formula]
    T3 --> T4[verify_plaintext_balance_with_fee]
    T4 --> T5[verify_commitment_balance_gate]
    T5 --> T6[verify_spend_witness_gate]
    T6 --> T7[verify_tx_package]
    T7 --> T8[Stage-4 Accept]
```

📌 The current gate-order evidence is split between live code and locked tests: `claim_tx_tests::test_report_ok` and `claim_tx_tests::test_report_stops_auth` prove that Stage-3 success still reaches `verify_digest` only after proof, authority, and owner-attest checks; `stage_4.rs` shows that `verify_tx_package` remains the current terminal Stage-4 verifier gate after the claim-package prerequisite, the fee checks, the commitment-balance gate, and the spend-witness gate; and `test_stage4_claim_gate::stage4_temp_claim_gate_ok` plus `test_stage4_gates::stage4_witness_gate_ok` lock the prerequisite and the balance-to-witness ordering that lead into that terminal package-verifier step.

#### Runtime Flow Checklist

- [x] Preserve the exact current gate order in this diagram so later migration tests can detect order drift.
- [x] Record which current terminal gate determines final verifier success for Stage-3 and for Stage-4.
- [x] Freeze the rule that this diagram may change only after a replacement gate is live and the old gate is no longer a final success path.
- [x] Freeze the rule that replacement work must keep regression coverage against hidden reintroduction of the old success path.

## Phase 8. Claim Proof Track

### 8.1 Current Mechanism And Final Target

📌 Current live mechanism:

- `ClaimTxVerifierImpl::build_claim_statement` still builds `GenesisClaimStatement` with `owner_bind_digest` derived from `hash_bind_msg`, so owner-binding meaning already enters the typed placeholder statement before proof verification;
- `ClaimTxVerifierImpl::verify_claim_proof` decodes and verifies the typed placeholder proof object;
- `verify_genesis_claim` enforces statement-bound proof validity in the current typed form;
- `ClaimTxVerifierImpl::verify_owner_attest` still accepts a transitional owner-bind branch through `owner_attest_hex`.

📌 Current status is fail-closed but not final.

📌 Final target:

- one canonical public claim statement;
- one final public claim verifier;
- no separate final-acceptance dependency on `owner_attest_hex`.

📌 This track may close before Stage-1 authority is complete only if the final claim design stays honest about authority scope. In particular, it must not treat the current transitional root placeholder or any fixed-root shortcut as authenticated chain authority.

📌 In the current repository state, owner-binding meaning is already split across two live surfaces: `GenesisClaimStatement.owner_bind_digest` binds the hashed owner-attest message into the typed placeholder proof statement, while `ClaimTxVerifierImpl::verify_owner_attest` still requires the separate `owner_attest_hex` signature branch for final acceptance.

#### Claim Target Checklist

- [x] Freeze the rule that claim-proof closure requires one final public claim statement type and forbids parallel alternative final statement layouts.
- [x] Freeze the minimum binding set that the final claim statement must cover: scope hash, nullifier, output relation, and owner-binding meaning.
- [x] Freeze the rule that owner-binding meaning must end in one canonical proof statement or one canonical public companion statement rather than in multiple acceptance branches.
- [x] Freeze the rule that `owner_attest_hex` must leave final acceptance semantics before claim-proof closure is claimed.
- [x] Freeze the rule that claim-proof work may stay independent of Stage-1 only while it makes no authenticated-authority claim anywhere in the final claim verifier or its statement.

### 8.2 Security Invariants And Forbidden Shortcuts

📌 Required preserved invariants:

- explicit transcript and statement domain separation;
- stable binding for scope hash, nullifier, output relation, and owner-binding meaning;
- fail-closed decode, fail-closed semantic verification, and no transport-only hidden success path.

📌 Forbidden shortcuts:

- do not call the track closed while `owner_attest_hex` remains a live final success branch;
- do not rename the current placeholder proof and declare victory without removing the transitional branches;
- do not move owner-binding semantics into an undocumented side channel.

📌 The current live code already shows why these shortcuts stay forbidden: the present Stage-3 acceptance chain spans explicit statement hashing under `ClaimStmtDomain`, placeholder proof verification under `ClaimProofDomain`, the adjacent authority-signature gate under `ClaimSigDomain`, and the separate owner-attestation verification path under `OWNER_ATTEST_CTX` plus `owner_attest_hex`.

📌 That full current-domain inventory must be described honestly, but claim-proof closure must not silently absorb authority-track semantics. If later work decouples final claim proof from the adjacent authority-signature gate, that boundary change must be stated explicitly rather than inherited by implication.

#### Claim Invariant Checklist

- [x] Freeze one canonical inventory of the current live claim-acceptance domains and require any later split between claim-proof scope and authority-signature scope to be documented explicitly rather than by implication.
- [x] Freeze the requirement that claim-proof closure must keep fail-closed coverage for proof decode corruption, statement mismatch, owner-binding mismatch, and domain-separation regressions.
- [x] Freeze the rule that no final claim verifier may keep `owner_attest_hex` as a fallback success path after the final verifier is introduced.
- [x] Freeze the rule that owner-binding semantics must not be hidden in transport-only JSON fields or undocumented helper state.

### 8.3 Code Anchors

📌 Current code-accurate snippet for the owner-bind field entering the typed statement:

```rust
Ok(GenesisClaimStatement {
    genesis_root: ZERO_ROOT,
    claim_source_asset_id: decode_hex32(
        &claim.claim_source_asset_id_hex,
        "claim_source_asset_id_hex",
    )?,
    claim_source_commitment: decode_hex32(
        &claim.claim_source_commitment_hex,
        "claim_source_commitment_hex",
    )?,
    claim_id: decode_hex32(&claim.claim_id_hex, "claim_id_hex")?,
    chain_id: pkg.chain_id,
    scenario_scope_hash: decode_hex32(
        &pkg.tx.context.claim_scope_hash_hex,
        "claim_scope_hash_hex",
    )?,
    recipient_binding: decode_hex32(
        &pkg.tx.context.recipient_owner_hex,
        "recipient_owner_hex",
    )?,
    nullifier: decode_hex32(&pkg.tx.context.nullifier_hex, "nullifier_hex")?,
    owner_bind_digest: Self::hash_bind_msg(&pkg.tx, pkg.chain_id, leaves)?,
    output_leaf_hashes,
})
```

📌 Current code-accurate snippet for the typed placeholder proof gate:

```rust
fn verify_claim_proof(
    tx: &ClaimTxWire,
    stmt: &GenesisClaimStatement,
) -> Result<ClaimVerifyReport, ClaimTxError> {
    if tx.proof.proof_hex.is_empty() || !is_even_hex(&tx.proof.proof_hex) {
        return Err(ClaimTxError::ProofBlobInvalidHex(
            "proof_hex invalid".to_string(),
        ));
    }
    let proof_bytes = hex::decode(&tx.proof.proof_hex)
        .map_err(|_| ClaimTxError::ProofBlobInvalidHex("proof_hex decode failed".to_string()))?;
    let proof = GenesisClaimProof::from_bytes(&proof_bytes)
        .map_err(|e| ClaimTxError::ProofBlobDecode(e.to_string()))?;

    verify_genesis_claim(stmt, &proof).map_err(|e| match e {
        ClaimProofErr::DecodeFail => ClaimTxError::ProofBlobDecode(e.to_string()),
        ClaimProofErr::BadVersion
        | ClaimProofErr::StmtMismatch
        | ClaimProofErr::ProofInvalid => ClaimTxError::ProofVerify(e.to_string()),
        ClaimProofErr::SigInvalid => ClaimTxError::ProofVerify(e.to_string()),
    })
}
```

📌 Transitional owner-bind branch currently still exists as a separate final-success requirement:

```rust
fn verify_owner_attest(
    tx: &ClaimTxWire,
    chain_id: u32,
    recipient_card: &ReceiverCard,
    leaves: &[&AssetPkgWire],
) -> Result<(), ClaimTxError> {
    for (idx, (out, leaf)) in tx.outputs.iter().zip(leaves.iter()).enumerate() {
        Self::verify_out_attest(
            out,
            Some(*leaf),
            true,
            chain_id,
            tx,
            idx as u32,
            Some(recipient_card),
        )?;
    }

    Ok(())
}
```

📌 The live claim path therefore still combines typed statement binding through `owner_bind_digest`, a typed placeholder proof gate, an authority-signature gate, and a separate owner-attestation gate before digest success.

#### Claim Anchor Checklist

- [x] Re-verify these snippets against the live code before claiming this phase complete.
- [x] Freeze the rule that any PR changing the underlying helper signatures, statement type, or acceptance order must update these snippets in the same PR.
- [x] Freeze the rule that no claim-proof PR may change the live path while leaving this section stale.
- [x] Freeze one explicit review step requiring snippet-to-code comparison before merge of later claim-proof changes.

## Phase 9. Chain Authority Track

### 9.1 Current Mechanism And Final Target

📌 Current live mechanism:

- `ClaimTxVerifierImpl::verify_claim_authority` still runs after `verify_claim_proof` and before `verify_owner_attest`, so the current Stage-3 authority gate is one fail-closed statement-signature step inside the live claim verifier order;
- `verify_claim_authority_sig` still validates only a digest-tag payload derived from `statement_hash(statement)` under `ClaimSigDomain`, while `ClaimAuthoritySig::from_statement` emits the same hash-derived token with no external signer identity, so the live gate remains a typed statement-hash consistency path rather than a verified Stage-1 manifest-authority path;
- `GenesisClaimStatement` is still built with a transitional `ZERO_ROOT` placeholder rather than a verified genesis root;
- the same placeholder-root construction still appears in `z00z_wallets::core::tx::claim_tx`, in `z00z_simulator::scenario_1::stage_3`, and in `z00z_simulator::tests::support::claim_pkg_crypto`, so the current repository still carries one explicit zero-root authority footprint across live verifier code, simulator emission code, and synthetic test support;
- locked tests already prove the current fail-closed authority position: `test_bad_auth_sig` and `test_legacy_sig_stub` reject malformed or legacy authority bytes, while `test_report_stops_auth` proves Stage-3 stops before owner-attest and digest success when the authority gate fails;
- Stage-3 must not treat fixed-root or zero-root binding as authenticated authority.

📌 Final target:

- Stage-3 authority acceptance succeeds only from the verified `GenesisAuthority`, `GenesisManifest`, and `Stage1Assumptions` bundle;
- all transitional authority success paths are removed or demoted to non-authoritative diagnostics.

📌 In the current repository state, that final target is still a frozen replacement contract rather than a live implementation. The repository does not yet expose one typed verified Stage-1 authority bundle, one canonical Stage-1 acceptance entry point, or one Stage-3 adapter that injects a verified root into `GenesisClaimStatement` before authority acceptance.

#### Authority Target Checklist

- [x] Freeze one typed Stage-1 authority bundle as the only future authenticated-authority input surface for Stage-3 closure.
- [x] Freeze the rule that Stage-3 authority verification must consume that typed bundle rather than reconstructing authority from ad hoc fields or statement-local folklore constants.
- [x] Freeze the rule that `ZERO_ROOT` and any equivalent placeholder stay non-authoritative until verified Stage-1 root injection replaces them in the final acceptance path.
- [x] Freeze the rule that every authenticated-success path still reachable through fixed-root or zero-root semantics must be removed or demoted before authority closure is claimed.

### 9.2 Security Invariants And Forbidden Shortcuts

📌 Required preserved invariants:

- authenticated authority comes only from the canonical Stage-1 verifier path;
- downstream Stage-3 readers consume only the narrow artifact field surface named in this file;
- raw manifest bytes, ad hoc root constants, and side-channel deployment notes never become authority.

📌 The current live code makes those invariants concrete by contrast: `verify_claim_authority_sig` checks only the current `GenesisClaimStatement` hash against a deterministic `ClaimSigDomain` token, while the Stage-1 boundary allows downstream readers to consume only `manifest_hash`, `config_hash`, and `accepted_root_hash` from the verified artifact set. That means the current authority-signature gate may remain live as a transitional verifier step, but it must not be described as authenticated manifest authority until it consumes the verified Stage-1 bundle and only the allowed read surface.

📌 Forbidden shortcuts:

- do not mark the track closed while any fixed-root or zero-root path can still succeed as authenticated authority;
- do not let downstream code consume `authority_sig` or `authority_pk` as policy inputs;
- do not let `Stage1Assumptions` absorb extra routing or policy fields just to simplify later code;
- do not treat simulator emission helpers or synthetic test-support builders that still encode `ZERO_ROOT` as evidence that authenticated authority already exists.

#### Authority Invariant Checklist

- [x] Freeze the narrow Stage-1 read surface as a code-level requirement for any future authority-closure PR rather than as optional prose.
- [x] Freeze the requirement for locked negative coverage if downstream Stage-3 code starts reading forbidden authority fields.
- [x] Freeze the requirement for locked negative coverage if raw manifest payload bytes or deployment notes can influence authority acceptance.
- [x] Freeze the rule that `Stage1Assumptions` must stay a hash mirror only and cannot grow convenience routing or policy fields for Spec-5 consumers.

### 9.3 Code Anchor

📌 Current code-accurate snippet showing the transitional root placeholder:

```rust
Ok(GenesisClaimStatement {
    // Current claim wire does not carry a verified genesis root yet.
    // Stage-3 therefore binds a transitional non-authoritative zero root
    // until the later authenticated-authority wire migration lands.
    genesis_root: ZERO_ROOT,
    claim_source_asset_id: decode_hex32(
        &claim.claim_source_asset_id_hex,
        "claim_source_asset_id_hex",
    )?,
    claim_source_commitment: decode_hex32(
        &claim.claim_source_commitment_hex,
        "claim_source_commitment_hex",
    )?,
    claim_id: decode_hex32(&claim.claim_id_hex, "claim_id_hex")?,
    chain_id: pkg.chain_id,
    scenario_scope_hash: decode_hex32(
        &pkg.tx.context.claim_scope_hash_hex,
        "claim_scope_hash_hex",
    )?,
    recipient_binding: decode_hex32(
        &pkg.tx.context.recipient_owner_hex,
        "recipient_owner_hex",
    )?,
    nullifier: decode_hex32(&pkg.tx.context.nullifier_hex, "nullifier_hex")?,
    owner_bind_digest: Self::hash_bind_msg(&pkg.tx, pkg.chain_id, leaves)?,
    output_leaf_hashes,
})
```

📌 Current code-accurate snippet showing that the live authority gate is still a statement-hash token check and not a verified Stage-1 manifest-authority verifier:

```rust
pub fn verify_claim_authority_sig(
    statement: &GenesisClaimStatement,
    sig: &ClaimAuthoritySig,
) -> Result<(), ClaimProofErr> {
    if sig.sig_bytes.len() != BLOB_LEN {
        return Err(ClaimProofErr::DecodeFail);
    }
    if sig.sig_bytes[0..4] != SIG_TAG {
        return Err(ClaimProofErr::SigInvalid);
    }

    let stmt_hash = statement_hash(statement);
    let want = sig_digest(&stmt_hash);
    let got = &sig.sig_bytes[4..];
    if got != want {
        return Err(ClaimProofErr::SigInvalid);
    }

    Ok(())
}
```

📌 Together these snippets fix the current boundary precisely: the repository still authenticates only a typed claim statement built with `ZERO_ROOT`, while the later Stage-1 closure target requires verified bundle consumption before any authenticated-authority claim is allowed.

📌 The locked Stage-3 tests match that boundary: `test_bad_auth_sig` and `test_legacy_sig_stub` prove malformed or legacy authority bytes fail closed, and `test_report_stops_auth` proves the verifier does not continue into owner-attest or digest success after an authority-gate failure.

#### Authority Anchor Checklist

- [x] Freeze the rule that placeholder-root construction must be replaced by verified Stage-1 root injection in the same PR that changes authority acceptance.
- [x] Freeze the requirement for at least one negative test proving that placeholder-root authority no longer succeeds once verified Stage-1 authority is live.
- [x] Freeze the rule that both snippets must be updated immediately after the authority code path changes.
- [x] Freeze the review rule that no authority-closure PR may claim completion while this section still shows `ZERO_ROOT` or a statement-hash-only authority gate as the terminal authority check.

## Phase 10. Spend-Proof Verifier Track

### 10.1 Current Mechanism And Final Target

📌 Current live mechanism:

- `verify_self_decrypt` validates decryptability, tag binding, plaintext/output consistency, commitment opening, and range proof using local output bundle state;
- `verify_fee_matches_formula`, `verify_plaintext_balance_with_fee`, and `verify_commitment_balance_gate` all run before the witness gate, so Stage-4 still uses multiple fail-closed subchecks rather than one canonical public spend verifier;
- `verify_spend_witness_gate` reconstructs input relations from decryptable witness material and local receiver secret data, including `recv_sec` and derived `s_in_vec`, before building `SpendPlan` plus `SpendWitness`;
- `verify_tx_package` remains the current terminal Stage-4 verifier gate only after the claim-package prerequisite, self-decrypt checks, fee checks, commitment-balance gate, and witness-bound spend gate have already succeeded.

📌 Current status is fail-closed but witness-bound.

📌 Final target:

- one public spend statement;
- one final public spend verifier;
- no final acceptance dependence on local witness reconstruction or verifier-owned secret material.

📌 In the current repository state, that final target is still a frozen replacement contract rather than a live implementation. The repository does not yet expose one canonical public spend statement, one proof blob verified only from public inputs, or one terminal spend-verifier path that a third party can run without `recv_sec`, local decrypt state, or reconstructed witness vectors.

#### Spend Target Checklist

- [x] Freeze one final public spend statement type and forbid multiple competing statement layouts.
- [x] Freeze the current migration inventory: decryptability, tag and output-consistency binding, commitment opening, range proof, input-ownership relation, input set binding, output set binding, and root binding must move from witness-bound helpers into the final public verifier surface.
- [x] Freeze the rule that prover-side witness preparation must stay separate from verifier-side public acceptance before the new path may be called final.
- [x] Freeze the rule that the final verifier must be runnable by a third party that has only canonical public inputs, statement bytes, and proof bytes.

### 10.2 Security Invariants And Forbidden Shortcuts

📌 Required preserved invariants:

- explicit commitment conservation;
- statement-bound output correctness rather than trust in transport bytes;
- third-party verifiability from canonical public inputs and proof bytes.

📌 The current live code already shows why those invariants are not yet fully public: `verify_self_decrypt` still depends on in-memory `OutputBundle` state, `verify_spend_witness_gate` still accepts `recv_sec` and reconstructs `s_in_vec`, and `resolve_input_secret` may recover witness material either from `item.secret` or from receiver-side decryptability. Those gates are fail closed, but they are still verifier-local witness logic rather than final public-proof verification.

📌 Forbidden shortcuts:

- do not call the witness gate a public proof;
- do not claim closure while final acceptance still needs local witness reconstruction;
- do not rename a witness-bound helper and present it as a public verifier;
- do not treat the current `verify_tx_package` terminal step as proof that Stage-4 already has a final public spend verifier, because it still executes only after the witness-bound gate has succeeded.

#### Spend Invariant Checklist

- [x] Freeze the rule that commitment conservation must stay explicit in the final public statement or in one clearly subordinate public-data subcheck.
- [x] Freeze the requirement for locked negative coverage if final acceptance still consumes `recv_sec`, reconstructed `s_in_vec`, `item.secret`, or decrypt-only bundle state after the public verifier lands.
- [x] Freeze the rule that merely renaming `verify_spend_witness_gate` or wrapping it under a public-sounding API does not satisfy spend-proof closure.
- [x] Freeze the requirement for regression coverage for malformed proof bytes, malformed statement bytes, corrupted public commitments, and hidden witness-only fallback success paths.

### 10.3 Code Anchors

📌 Current code-accurate snippets:

```rust
pub fn verify_self_decrypt(out: &OutputBundle) -> Result<(), String> {
    let leaf = &out.leaf;
    let pack = decode_output_pack(out)?;

    let blinding = Z00ZScalar::try_from_bytes(pack.blinding).map_err(|e| e.to_string())?;
    let commitment = create_commitment(pack.value, &blinding).map_err(|e| e.to_string())?;
    let commitment_bytes: [u8; 32] = commitment
        .as_bytes()
        .try_into()
        .map_err(|_| "stage4: commitment bytes size mismatch".to_string())?;
    if commitment_bytes != leaf.c_amount {
        return Err(format!(
            "stage4: commitment mismatch receiver={} serial_id={}",
            out.receiver, leaf.serial_id
        ));
    }

    let parsed = Z00ZCommitment::from_canonical_bytes(&leaf.c_amount).map_err(|e| e.to_string())?;
    verify_range_proof(
        &leaf.range_proof,
        &parsed,
        RANGE_PROOF_BITS_V1,
        AGGREGATION_FACTOR,
        MIN_VALUE_PROMISE,
    )
    .map_err(|e| {
        format!(
            "stage4: range proof verify failed receiver={} err={e}",
            out.receiver
        )
    })?;

    Ok(())
}
```

```rust
pub fn verify_spend_witness_gate(
    recv_sec: [u8; 32],
    selected_inputs: &[AssetWire],
    outputs: &[OutputBundle],
    tx_digest: &[u8; 32],
) -> Result<(), String> {
    if selected_inputs.is_empty() {
        return Err("stage4: SpendWitness gate: no selected inputs".to_string());
    }

    let s_in_vec: Vec<[u8; 32]> = selected_inputs
        .iter()
        .map(|item| resolve_input_secret(recv_sec, item))
        .collect::<Result<Vec<_>, _>>()?;

    let inputs: Vec<SpendInputRef> = selected_inputs
        .iter()
        .zip(s_in_vec.iter())
        .map(|(item, s_in)| SpendInputRef {
            asset_id: hash_zk::<AssetIdDomain>("", &[s_in]),
            serial_id: item.serial_id,
        })
        .collect();

    let leaf_sums: Vec<SpendInputLeaf> = selected_inputs
        .iter()
        .zip(s_in_vec.iter())
        .map(|(item, s_in)| {
            let r_pub = item
                .r_pub
                .ok_or_else(|| "stage4: SpendWitness gate: missing input r_pub".to_string())?;
            let owner_tag = item.owner_tag.ok_or_else(|| {
                "stage4: SpendWitness gate: missing input owner_tag".to_string()
            })?;
            Ok(SpendInputLeaf {
                asset_id: hash_zk::<AssetIdDomain>("", &[s_in]),
                r_pub,
                owner_tag,
                c_amt: item.commitment.as_bytes().try_into().map_err(|_| {
                    "stage4: SpendWitness gate: bad commitment bytes".to_string()
                })?,
            })
        })
        .collect::<Result<Vec<_>, String>>()?;

    let out_leafs: Vec<AssetLeaf> = outputs.iter().map(|out| out.leaf.clone()).collect();
    let stmt = SpendPlan {
        prev_root: *tx_digest,
        inputs,
        leaf_sums,
        outputs: out_leafs,
    };
    let wit = SpendWitness { recv_sec, s_in_vec };

    let mut cs = SpendCs;
    build_spend_assets(&mut cs, &stmt, &wit)
        .map_err(|e| format!("stage4: SpendWitness gate failed: {e}"))
}
```

📌 The current locked tests already prove the live Stage-4 spend gate boundary: `output_self_decrypt_ok`, `output_tag_fail`, `output_value_fail`, `output_commit_fail`, and `output_range_fail` lock the self-decrypt path; `balance_gate_ok` and `balance_gate_fail` lock commitment-conservation failure behavior; and `witness_gate_ok` plus `witness_gate_fail` prove that the witness gate still accepts only with witness-bound inputs and fails closed on an invalid root.

#### Spend Anchor Checklist

- [x] Re-verify these snippets against the live code before claiming this phase complete.
- [x] Freeze the rule that any PR changing the Stage-4 spend gate order, helper signatures, or witness inputs must update these snippets in the same PR.
- [x] Freeze the rule that no spend-proof PR may change the live path while leaving this section stale.
- [x] Freeze one explicit review step requiring snippet-to-code and test-to-boundary comparison before merge of later spend-proof changes.
- [x] Freeze the rule that when the public spend verifier lands, these snippets must be replaced with the new final verifier path and the old helpers must move into a clearly non-final subsection or be removed.
- [x] Freeze one explicit review step that compares this section against the actual witness-bound implementation before merge.
- [x] Freeze the rule that no PR may claim public spend-proof completion while these snippets still describe final acceptance.

## Phase 11. Fee-Proof Verifier Track

### 11.1 Current Mechanism And Final Target

📌 Current live mechanism:

- `verify_fee_matches_formula` checks that the declared fee matches the deterministic fee formula over the transaction shape;
- `verify_plaintext_balance_with_fee` checks local input/output amount balance;
- the fee-inclusive commitment-balance gate still runs as an adjacent public-data subcheck before the witness gate, but it is not a standalone public fee-proof object;
- `verify_fee_opening_eq` and `verify_fee_commitment_opening` exist as helper checks for declared fee openings, yet they are not the current terminal Stage-4 acceptance path.

📌 Current status is deterministic and fail closed, but still split across multiple runtime gates rather than one canonical public fee verifier.

📌 Final target:

- one final public fee statement;
- one public fee verifier;
- no final acceptance dependence on the current formula-plus-plaintext split.

📌 In the current repository state, that final target is still a frozen replacement contract rather than a live implementation. The repository does not yet expose one canonical fee statement, one fee-proof blob, or one single public verifier step that replaces the current formula check plus plaintext-balance split in final acceptance.

#### Fee Target Checklist

- [x] Freeze one final public fee statement and forbid multiple incompatible fee statement layouts.
- [x] Freeze the current migration inventory: declared fee, deterministic fee formula relation, fee-context binding, fee-opening relation, and fee-inclusive balance semantics must move into the final public fee verifier surface.
- [x] Freeze the rule that the current formula-plus-plaintext split must leave final acceptance once the new verifier is live.
- [x] Freeze the rule that fee-proof scope stays fee-only and does not absorb ownership, witness validity, or broader spend semantics.

### 11.2 Security Invariants And Forbidden Shortcuts

📌 Required preserved invariants:

- fee semantics remain deterministic and statement-bound;
- malformed fee relation and malformed statement context fail closed;
- fee proof scope stays fee-only and does not silently claim full spend semantics.

📌 The current live code already shows why those invariants are not yet a final public fee proof: `verify_fee_matches_formula` binds only the declared fee to the transaction shape, `verify_plaintext_balance_with_fee` still consumes plaintext amounts from local runtime state, and the fee-opening helpers remain optional adjacent checks rather than the canonical acceptance path. Those gates are useful and fail closed, but they are still split helper logic rather than one final public fee verifier.

📌 The current test evidence also remains incomplete for protocol-complete fee closure: the repository already has helper-level negative coverage for a declared/opening mismatch, but it does not yet lock one direct negative test for `verify_fee_matches_formula` mismatch or one direct negative test for the plaintext-balance side of the live fee split as standalone fee-track evidence.

📌 Forbidden shortcuts:

- do not mark the track closed while `verify_fee_matches_formula` plus `verify_plaintext_balance_with_fee` remains the final acceptance split;
- do not let the fee proof claim ownership or spend semantics beyond fee correctness;
- do not treat the adjacent fee-opening helpers as proof that the repository already has a final fee verifier while the terminal path still depends on the formula-plus-plaintext split.

#### Fee Invariant Checklist

- [x] Freeze the requirement for one positive test that proves final fee acceptance through the new public fee verifier only.
- [x] Freeze the requirement for negative coverage for fee-formula mismatch, corrupted fee statement bytes, and malformed transaction context.
- [x] Freeze the rule that no fee-verifier design may still require local plaintext-only balance as a final success condition once the public verifier lands.
- [x] Freeze the rule that no fee-verifier design may begin checking ownership, witness validity, or non-fee spend semantics.

### 11.3 Code Anchor

📌 Current code-accurate snippet for the plaintext-balance side of the live split fee path:

```rust
pub fn verify_plaintext_balance_with_fee(
    selected_inputs: &[AssetWire],
    outputs: &[OutputBundle],
    _fee: u64,
) -> Result<(), String> {
    let in_sum: u128 = selected_inputs.iter().map(|item| item.amount as u128).sum();
    let out_sum: u128 = outputs.iter().map(|out| out.value as u128).sum();
    if in_sum != out_sum {
        return Err(format!(
            "stage4: plaintext balance mismatch: in_sum={} out_sum={}",
            in_sum, out_sum
        ));
    }
    Ok(())
}
```

📌 Current code-accurate snippet for the deterministic fee-formula side of the same live split path:

```rust
fn verify_fee_matches_formula(
    inputs: &[TxInputWire],
    outputs: &[TxOutputWire],
    declared_fee: u64,
) -> Result<(), String> {
    let expected = calc_fee(inputs, outputs)?;
    if expected != declared_fee {
        return Err(format!(
            "stage4: fee mismatch: declared={} expected={}",
            declared_fee, expected
        ));
    }
    Ok(())
}
```

📌 Current code-accurate snippet for the adjacent fee-opening helper path that already exists in code but is not the terminal acceptance gate:

```rust
pub fn verify_fee_opening_eq(
    fee_commit: &Z00ZCommitment,
    fee: u64,
    fee_blind: &Z00ZScalar,
) -> Result<(), String> {
    let opening_ok = z00z_core::assets::verify_commitment_opening(fee_commit, fee, fee_blind)
        .map_err(|e| format!("stage4: fee opening verify error: {e}"))?;
    if !opening_ok {
        return Err(format!(
            "stage4: fee opening mismatch for declared fee={fee}"
        ));
    }

    let rebuilt = create_commitment(fee, fee_blind)
        .map_err(|e| format!("stage4: fee commitment rebuild failed: {e}"))?;
    if rebuilt.as_bytes() != fee_commit.as_bytes() {
        return Err("stage4: fee commitment mismatch against reconstructed opening".to_string());
    }
    Ok(())
}
```

📌 The current locked evidence for this boundary is still partial and transitional: `fee_opening_gate_rejects_declared_mismatch` proves the adjacent fee-opening helper fails closed on a declared/opening mismatch, while the live Stage-4 orchestration still runs the formula check plus plaintext-balance split before the witness gate and still lacks one locked direct negative test for each side of that split.

#### Fee Anchor Checklist

- [x] Re-verify these snippets against the live code before claiming this phase complete.
- [x] Freeze the rule that the snippet set must stay aligned with the live split fee path until the final public fee verifier replaces it.
- [x] Freeze the rule that these snippets must be replaced with the new public fee-verifier path in the same PR that changes final fee acceptance.
- [x] Freeze one review step that confirms the doc snippets and the code still match before merge, and reject any PR that claims fee-proof completion while this section still describes split final acceptance.

## 12. Stage-4 Live Acceptance Order

### 12.1 Current Gate Order

📌 Current live mechanism:

- `load_claim_pkgs` still acts as the Stage-4 claim-package prerequisite before any output or spend-path verifier work begins;
- `core_verify_self_decrypt`, `verify_fee_matches_formula`, `core_plain_balance`, `verify_commitment_balance_gate`, and `verify_spend_witness_gate` still run in that live order inside Stage-4;
- `verify_tx_package` still runs after the witness gate and remains the current terminal Stage-4 verifier gate;
- persistence, recipient checks, fee-party checks, pending-row assembly, and stage logs still run only after the current verifier path has already succeeded, so they are downstream post-verifier runtime checks or side effects rather than the terminal verifier chain itself.

📌 The current Stage-4 orchestration is therefore a good reminder of why spend-proof and fee-proof completion must stay separate from documentation closure: the witness gate is still one required witness-bound success step in the live chain, and the terminal verifier that follows it is still package transport verification rather than one final public spend-plus-fee verifier.

```rust
let _claim_pkgs = load_claim_pkgs(&claim_pkg_file).map_err(|err| {
    format!("stage4: claim package prerequisite failed: {err}")
})?;

for out_item in &outputs {
    core_verify_self_decrypt(out_item)?;
}

let tx_outputs = to_tx_output_wires(&outputs)?;
verify_fee_matches_formula(&tx_inputs, &tx_outputs, fee)?;
core_plain_balance(&selected, &outputs, fee)?;

let tx_wire = TxWire {
    tx_type: "regular_tx".to_string(),
    inputs: tx_inputs.clone(),
    outputs: tx_outputs.clone(),
    fee,
    nonce: 0,
    context: Default::default(),
    proof: Default::default(),
    auth: Default::default(),
};
let tx_digest = core_tx_digest(&tx_wire)?;
let chain_type = "devnet";
let chain_id = 3u32;
let chain_name = "z00z-devnet-1";
let tx_digest_hex = build_tx_package_digest(
    "TxPackage",
    "regular_tx",
    1,
    chain_id,
    chain_type,
    chain_name,
    &tx_wire,
)?;

verify_commitment_balance_gate(*sender.receiver_secret.reveal(), &selected, &outputs, fee)?;

verify_spend_witness_gate(
    *sender.receiver_secret.reveal(),
    &selected,
    &outputs,
    &tx_digest,
)?;

let pkg = TxPackage {
    kind: "TxPackage".to_string(),
    package_type: "regular_tx".to_string(),
    version: 1,
    chain_id,
    chain_type: chain_type.to_string(),
    chain_name: chain_name.to_string(),
    tx: tx_wire,
    tx_digest_hex: tx_digest_hex.clone(),
    status: "prepared".to_string(),
};

let tx_bytes = JsonCodec.serialize(&pkg).map_err(|e| e.to_string())?;
verify_tx_package(&tx_bytes)?;
```

📌 The decisive fact is more precise than the older wording: Stage-4 final verifier success no longer ends at the witness gate itself, because `verify_tx_package` still executes after it. But the spend-proof and fee-proof protocol-complete issues remain open because the live verifier chain still cannot succeed without the witness-bound gate and the split fee gates that precede it.

### 12.2 Locked Evidence And Replacement Boundary

📌 Current locked evidence is compositional rather than fully end-to-end:

- `stage4_temp_claim_gate_ok` and `stage4_rejects_missing_claim_pkg` lock the prerequisite boundary around `load_claim_pkgs`;
- `output_self_decrypt_ok`, `balance_gate_ok`, `balance_gate_fail`, `witness_gate_ok`, and `witness_gate_fail` lock the late Stage-4 gate behavior and its fail-closed boundary;
- `stage4_verifier_order_ok` now locks the canonical logged verifier order from self-decrypt through tx-package write and stage completion on a successful Stage-4 run;
- `verify_tx_package` still sits after those gates in live code, so any future public-verifier migration must update both the prerequisite-to-witness segment and the post-witness terminal verifier segment together;
- `verify_tx_package` is still followed by downstream runtime checks such as sender-state persistence and receiver or fee-party validation, but those later steps consume an already verified package rather than redefining the terminal verifier chain;
- the prerequisite boundary around `load_claim_pkgs` is still locked separately from the later logged verifier chain because the prerequisite itself is not yet emitted as its own Stage-4 log step.

📌 Replacement rule:

- the witness gate may leave the live acceptance chain only after the public spend verifier and the public fee verifier are both live where required;
- any helper retained after that migration must be marked explicitly as non-final;
- this section must be updated in the same PR that changes the live Stage-4 verifier order.

#### Acceptance Order Checklist

- [x] Freeze the rule that any Phase-12 description must name the claim-package prerequisite, the witness-bound gate, and the terminal package verifier as distinct live Stage-4 order points.
- [x] Freeze the requirement for one locked end-to-end test that proves the current Stage-4 verifier order before the migration replaces it.
- [x] Freeze the rule that the witness gate may leave the live acceptance chain only after the public spend verifier and public fee verifier are both live where required.
- [x] Freeze the rule that any retained helper gates must be marked explicitly as non-final once the public verifier path lands.
- [x] Freeze the rule that this section must be updated immediately in the same PR that changes the live Stage-4 verifier order.

## Phase 13. Recommended Integration Order

### 13.1 Required Execution Sequence

📌 Current live dependency boundary:

- claim-proof work still has to retire the separate `owner_attest_hex` final-success branch before the Stage-3 claim path can be called final;
- spend-proof and fee-proof work still has to replace the current Stage-4 witness-bound and split-fee acceptance chain before Stage-4 can stop depending on `verify_spend_witness_gate`, `verify_fee_matches_formula`, and `verify_plaintext_balance_with_fee` as live acceptance gates;
- authority closure still depends on the verified Stage-1 artifact bundle and therefore still cannot be the first implementation step;
- runtime matrices and boundary notes still have to follow live code rather than lead it.

📌 The recommended order therefore minimizes duplicated design work and reduces the risk of inventing temporary APIs twice.

1. freeze the final public claim statement;
2. implement the final public claim verifier and retire transitional owner-bind acceptance;
3. freeze the final public spend and fee statements;
4. implement the public spend and fee verifiers so Stage-4 no longer depends on witness-bound and split-fee final acceptance;
5. wire the verified Stage-1 artifact bundle into Stage-3 and retire transitional authority shortcuts;
6. update the runtime matrices after the live code path changes, not before.

📌 In the current repository state, this is still a frozen execution contract rather than a completed implementation schedule. The ordering is grounded by the live blockers already documented in earlier phases: claim proof still carries `owner_attest_hex`, Stage-4 still carries the witness-bound and split-fee gates, and authority still depends on the verified Stage-1 artifact set.

#### Sequence Checklist

- [x] Freeze the rule that claim-proof statement freeze comes before claim-verifier replacement because the current Stage-3 path still carries one separate `owner_attest_hex` acceptance branch.
- [x] Freeze the rule that spend-proof and fee-proof statement freeze must finish before replacing Stage-4 final acceptance because the live Stage-4 chain still depends on witness-bound and split-fee gates.
- [x] Freeze the rule that authority closure cannot start until the verified Stage-1 bundle shape and verifier result type are fixed.
- [x] Freeze the rule that runtime matrices update only after the real code path changes and locked negative tests are in place.

### 13.2 Sequence Diagram

```mermaid
flowchart TD
    A[Freeze Claim Statement] --> B[Implement Final Claim Verifier]
    B --> C[Freeze Spend And Fee Statements]
    C --> D[Implement Public Spend And Fee Verifiers]
    D --> E[Wire Verified Stage-1 Authority Bundle]
    E --> F[Retire Transitional Authority Paths]
    F --> G[Update Matrices And Close Protocol Issues]
```

📌 This diagram stays valid against the current repository state because no live code path yet shows a harder dependency in the opposite direction. Claim proof may proceed before Stage-1 if it stays honest about authority scope; Stage-4 public-proof work may proceed before authority closure; and only the authority replacement itself remains directly blocked on the verified Stage-1 bundle.

#### Diagram Checklist

- [x] Freeze this sequence as the default execution order for planning, branch decomposition, and issue dependency management.
- [x] Freeze the rule that implementation work should be split into PRs that follow the sequence rather than mixing all four tracks in one patch set.
- [x] Freeze the rule that each PR must prove which prior sequence node is already complete and which next node becomes newly unblocked.
- [x] Freeze the rule that the diagram updates only if a real code dependency change requires a different order.

## Phase 14. Issue Closure Matrix

### 14.1 What May Close Now

📌 Current closure boundary:

- the repository may close documentation and planning issues now only when they do not claim protocol-complete replacement of any live transitional acceptance path;
- claim-proof protocol completion still remains blocked by the typed placeholder proof path plus the separate `owner_attest_hex` final-success branch;
- chain-authority protocol completion still remains blocked by the missing verified Stage-1 artifact bundle in live Stage-3 acceptance;
- spend-proof and fee-proof protocol completion still remain blocked by the current Stage-4 witness-bound and split-fee acceptance chain.

📌 The repository may therefore close planning and documentation issues now, but protocol-complete closure remains gated.

| Issue class | May close now | Required condition |
| --- | --- | --- |
| Editorial cleanup | Yes | Must not claim protocol completion |
| Planning consolidation | Yes | All necessary closure logic must already live in this file |
| Implementation slice | Yes | Scoped code, tests, and documentation for that slice are complete, and the issue makes no protocol-complete claim |
| Cross-track dependency blocker | No | The blocking dependency is removed in real code, tests, runtime notes, and this file |
| Claim-proof protocol completion | No | Final public claim verifier replaces typed placeholder and `owner_attest_hex` final acceptance |
| Chain-authority protocol completion | No | Verified Stage-1 artifact set becomes the only authenticated authority source |
| Spend-proof protocol completion | No | Final public spend verifier replaces witness-bound final acceptance |
| Fee-proof protocol completion | No | Final public fee verifier replaces formula-plus-plaintext final acceptance |
| Global post-Spec-5 completion | No | All four tracks are closed in code, tests, runtime notes, and this file |

📌 This matrix is still valid against the current repository state because the live blockers named in Phases 8 through 13 are still open in code and tests, while the documentation-layer consolidation work has already been centralized into this file.

#### Closure Matrix Checklist

- [x] Freeze the rule that editorial issues may close only after confirming that no protocol-complete claim appears in the issue description, closing comment, or linked PR.
- [x] Freeze the rule that planning-consolidation issues may close only after confirming that all cross-track rules, closure gates, and blocker classes already live in this file.
- [x] Freeze the rule that all protocol-complete issues stay open until the matching row in this table becomes satisfiable in real code and tests.
- [x] Freeze the rule that any milestone summary collapsing documentation closure into protocol completion must be rejected.

### 14.2 What Must Remain Open

📌 Therefore there is no principal blocker to closing the documentation-and-plan layer now.

📌 There are still real blockers to closing protocol-complete issues for claim proof, chain authority, spend proof, fee proof, and the global post-Spec-5 completion claim.

📌 In the current repository state, those open blockers are already explicit and non-interchangeable:

- claim proof stays open until the final public claim verifier replaces both the typed placeholder proof path and the separate `owner_attest_hex` final-success branch;
- chain authority stays open until Stage-3 consumes only the verified `GenesisAuthority`, `GenesisManifest`, and `Stage1Assumptions` bundle;
- spend proof stays open until the public spend verifier replaces witness-bound final acceptance;
- fee proof stays open until the public fee verifier replaces the formula-plus-plaintext final acceptance split;
- global post-Spec-5 completion stays open until all four track-level closure gates are satisfied together in code, tests, runtime notes, and this file.

📌 Exact closure-gate map for those open protocol-complete issue classes:

- claim-proof protocol completion must point to Phase 8.1 plus the global track-level closure rule in Phase 5.1;
- chain-authority protocol completion must point to Phase 9.1, Phase 6.2, and Phase 6.3;
- spend-proof protocol completion must point to Phase 10.1 plus the Stage-4 live acceptance order boundary in Phase 12.2;
- fee-proof protocol completion must point to Phase 11.1 plus the Stage-4 live acceptance order boundary in Phase 12.2;
- global post-Spec-5 completion must point to Phase 5.1 and require all four track-level closure gates to be satisfied together.

#### Open Issue Checklist

- [x] Freeze the rule that the four track-level protocol-complete issues and any global post-Spec-5 completion meta issue or exact equivalent must remain open until their closure gates are satisfied.
- [x] Freeze the rule that each open protocol issue must link to the exact section in this file that defines its closure gate.
- [x] Freeze the rule that issue status updates happen only after code, tests, runtime notes, and this file all agree.
- [x] Freeze the rule that any attempt to close all post-Spec-5 issues as one batch while one track remains incomplete must be rejected.

## Phase 15. Global Implementation Program

### 15.1 Non-Negotiable Program

📌 Phase 15 does not introduce a fifth work track. It freezes one repository-level execution program that decomposes the already approved four-track closure work into exact implementation slices.

📌 The program is active now because every required slice already has one explicit owner surface, one explicit code landing zone, and one explicit test surface in the current repository state.

| Program slice | Current owner surface | Current code target | Current test target | Completion rule |
| --- | --- | --- | --- | --- |
| Freeze final claim statement | `z00z_crypto::claim`, `z00z_wallets::core::tx::claim_tx` | `GenesisClaimStatement` builder and the final statement type replacement boundary in `claim_tx.rs` | `claim_tx_tests::test_report_ok`, `claim_tx_tests::test_owner_binding_mismatch`, `claim_tx_tests::test_report_stops_auth` | Complete only when one canonical final claim statement layout is frozen for later verifier work, no competing statement layout remains, and this file plus the live code-facing statement boundary describe the same future replacement target |
| Implement final claim verifier | `z00z_crypto::claim`, `z00z_wallets::core::tx::claim_tx` | `verify_claim_proof`, `ClaimTxVerifierImpl::verify`, and the final Stage-3 acceptance chain | `claim_tx_tests::test_report_ok`, `claim_tx_tests::test_bad_proof_type`, `claim_tx_tests::test_bad_proof_stmt`, `claim_tx_tests::test_legacy_proof_stub` | Complete only when final claim acceptance no longer depends on the transitional placeholder verifier path |
| Remove `owner_attest_hex` final success | `z00z_wallets::core::tx::claim_tx`, `z00z_simulator::scenario_1::stage_3` | `verify_owner_attest`, claim package emission, and output wire requirements for `owner_attest_hex` | `claim_tx_tests::test_owner_binding_mismatch`, `test_claim_tx_pipeline::test_pkg_with_leaf_accepted`, `test_claim_tx_pipeline::test_owner_attest_mismatch_rejected` | Complete only when `owner_attest_hex` is no longer required for final claim success and survives, if at all, only as non-final compatibility or diagnostic state |
| Freeze public spend statement | `z00z_wallets::core::tx::witness_gate`, `z00z_simulator::scenario_1::stage_4` | `SpendPlan`, public statement bytes, and the Stage-4 spend-verifier replacement boundary | `test_stage4_gates::stage4_witness_gate_ok`, `stage_4::tests::witness_gate_fail`, `test_stage4_gates::stage4_verifier_order_ok` | Complete only when one canonical public spend statement layout is frozen for the later verifier migration, the public statement boundary is explicit, and no competing statement layout remains for Stage-4 spend replacement work |
| Implement public spend verifier | `z00z_wallets::core::tx::witness_gate`, `z00z_simulator::scenario_1::stage_4` | `verify_spend_witness_gate`, Stage-4 verifier order, and the terminal spend-verifier segment before `verify_tx_package` | `test_stage4_gates::stage4_witness_gate_ok`, `stage_4::tests::witness_gate_fail`, `test_stage4_gates::stage4_verifier_order_ok` | Complete only when Stage-4 final spend acceptance is third-party verifiable without `recv_sec`, reconstructed witness state, or verifier-local secrets |
| Freeze and implement public fee verifier | `z00z_wallets::core::tx::output_flow`, `z00z_simulator::scenario_1::stage_4` | `verify_fee_matches_formula`, `verify_plaintext_balance_with_fee`, fee-opening helpers, and the final fee statement/verifier replacement boundary | `test_stage4_gates::stage4_plain_gate_ok`, `test_stage4_gates::stage4_commit_gate_ok`, `stage_4::tests::fee_opening_gate_rejects_declared_mismatch`, `test_stage4_gates::stage4_verifier_order_ok` | Complete only when one canonical public fee verifier replaces the current formula-plus-plaintext final-acceptance split inside the controlled migration window named by this phase |
| Wire verified Stage-1 authority and retire shortcuts | `z00z_wallets::core::tx::claim_tx`, `z00z_simulator::scenario_1::stage_3`, `z00z_simulator::tests::support::claim_pkg_crypto` | Stage-3 authority adapter, `GenesisClaimStatement.genesis_root` injection path, and replacement of `ZERO_ROOT` or equivalent authenticated-success shortcuts in `claim_tx.rs`, `stage_3.rs`, and `tests/support/claim_pkg_crypto.rs` | `claim_tx_tests::test_bad_auth_sig`, `claim_tx_tests::test_legacy_sig_stub`, `claim_tx_tests::test_report_stops_auth` | Complete only when authenticated authority succeeds only from the verified Stage-1 bundle, its narrow read surface is enforced, and fixed-root or zero-root authenticated-success shortcuts are no longer reachable in the named authority surfaces |
| Lock negative coverage and sync notes | `z00z_wallets::core::tx::claim_tx`, `z00z_simulator::scenario_1::stage_4`, subordinate boundary notes | locked negative tests for retired claim, authority, spend, and fee transitional paths, plus the runtime matrices and boundary notes that mirror live verifiers | `claim_tx_tests::test_bad_proof_type`, `claim_tx_tests::test_bad_auth_sig`, `test_stage4_claim_gate::stage4_rejects_missing_claim_pkg`, `stage_4::tests::witness_gate_fail`, `stage_4::tests::fee_opening_gate_rejects_declared_mismatch` | Complete only when every retired transitional success path has fail-closed negative coverage and all runtime notes mirror the new live code instead of leading it |

📌 Program-order rule for these slices remains strict and inherits Phase 13 rather than replacing it:

1. freeze final claim statement;
2. implement final claim verifier;
3. remove `owner_attest_hex` from final success;
4. freeze public spend statement;
5. implement public spend verifier;
6. freeze and implement the public fee verifier in the same controlled migration window;
7. wire the verified Stage-1 authority bundle into Stage-3 and retire authority shortcuts in the same authority migration window;
8. lock negative coverage for every retired transitional path and update runtime notes only after the live code path changes.

📌 A slice may be tracked by one PR, one issue, or one tightly coupled PR pair, but the repository must not mark the global program complete while any row in this table still remains open.

#### Program Checklist

- [x] Convert the global program into eight explicit implementation slices without creating a fifth work track.
- [x] Keep one explicit owner surface, one explicit code target, and one explicit test target for each slice.
- [x] Freeze the rule that a slice is complete only when code, tests, runtime notes, and this file all reflect the same state.
- [x] Freeze the rule that the global program cannot be marked complete while even one slice remains open.

### 15.2 Update Discipline

📌 If a future PR changes the target mechanism, statement shape, verifier order, or closure gate of any row above, this file must be updated in the same PR and the changed row must be re-read against live code before review approval.

📌 The same discipline also applies when a PR only demotes a transitional helper instead of deleting it. A helper cannot silently remain in a final-success position while the prose claims that the public replacement is already live.

📌 Repository review must therefore reject any of the following states:

- code changes verifier semantics but Phase 15 still points at the old owner surface or test target;
- code retires a transitional path but the matching completion rule still describes that path as live;
- runtime matrices or subordinate notes move ahead of code;
- a release candidate keeps stale Phase-15 instructions after a closure-gate change.

#### Discipline Checklist

- [x] Require every PR that changes verifier semantics, statement shape, verifier order, or closure logic to update this file before merge.
- [x] Freeze the rule that review fails if code changes land without the matching Phase-15 program-row update in this file.
- [x] Re-run the repository validation lane after every accepted documentation change that modifies closure rules or implementation steps.
- [x] Treat stale instructions in this file as a release-blocking documentation defect rather than as optional cleanup.
