# Stage-2 Ledger

📌 This file tracks Stage-2 invariants that are currently enforced by runtime checks, unit tests, or integration tests.

📌 Canonical Stage-2 record invariant: downstream publication consumers must accept only `ReceiverCardRecordV1` that passes `verify_receiver_card_record(...)` in `crates/z00z_wallets/src/core/chain/receiver_card_record.rs`.

📌 Compact-wire invariant: Stage-2 `card_compact` must encode the verified publication record itself, not a legacy raw `ReceiverCard` payload, so direct raw-card injection is rejected at the compact parser boundary.

📌 Embedded-card invariant: `receiver_card_bytes` must equal the canonical serialized payload of one verified `ReceiverCard`; the record must not shadow-copy `owner_handle`, `view_pk`, `identity_pk`, or `signature` into parallel fields.

📌 Registry-binding invariant: `registry_entry_id` must equal the domain-separated binding over `(record_version, card_epoch, receiver_card_bytes)`.

📌 Revocation invariant: any record with `revocation_state = revoked` must be rejected before stale-epoch evaluation reaches success.

📌 Epoch invariant: for the same receiver identity, any record with `card_epoch` lower than the latest accepted epoch must be rejected as stale.

📌 Rotation invariant: a rotated card with the same receiver identity and a strictly newer epoch may be accepted if the new record passes canonical validation and revocation checks.

📌 Persistence invariant: the same stored card bytes must not be relabeled under a different `registry_entry_id`, and the same `registry_entry_id` must not be rebound to a different receiver identity.

📌 Test-backed tamper matrix: owner-handle tamper, `view_pk` tamper, `identity_pk` tamper, signature tamper, stale epoch, revoked record, rotated record, and relabel attempts are covered in receiver-card-record tests.
