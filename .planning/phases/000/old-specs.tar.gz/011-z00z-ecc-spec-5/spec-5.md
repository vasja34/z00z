# Spec 5: Unified Implementation Specification for Receiver Inputs and Stealth Output Creation

📌 This document is the single implementation-oriented source of truth for Spec 5 receiver input validation, sender-side stealth output creation, wallet-side output correctness invariants, and the directly related Scenario-1 work packages.

📌 This document supersedes the former split between `5_Output_Creation.md` and `notes-todo-1.md`. Those files can be removed after this document is accepted.

📌 This document is intentionally self-contained. It includes the normative contracts, the code-accurate status, and the concrete follow-up work required to freeze the Spec 5 surface.

📌 Historical audit notes are intentionally excluded. This document contains only active implementation content.

## 1. Purpose And Scope

📌 Spec 5 defines how a sender validates receiver-provided payment material, derives the stealth ECDH context, constructs a receiver-bound encrypted payload, binds that payload to public leaf fields, and hands the result to higher layers that publish or prove the output.

📌 This document covers:

- `PaymentRequest` and `ReceiverCard` as the two supported receiver input modes;
- TOFU trust pinning and validation policy;
- `k_dh`, `owner_tag`, `leaf_ad`, `s_out`, `tag16`, and `enc_pack` contracts;
- the current split between the lightweight `TxStealthOutput` path and the full `AssetLeaf` path;
- concrete implementation work required before this surface can be considered frozen for Scenario-1.

📌 This document does not fully specify:

- authenticated Stage-1 genesis authority and manifest verification;
- final Stage-3 public claim proof design;
- final Stage-3 chain authority model;
- final Stage-4 public spend-proof and fee-proof verifiers.

## 2. One Source Of Truth Rules

📌 The following code modules are canonical for this specification and MUST NOT be duplicated by parallel implementations.

| Area | Canonical module | Canonical entry points |
| --- | --- | --- |
| Receiver card model | `crates/z00z_wallets/src/core/address/stealth_card.rs` | `ReceiverCard`, `ValidateReceiverCard` |
| Payment request model | `crates/z00z_wallets/src/core/address/stealth_request.rs` | `PaymentRequest`, `ValidatePaymentRequest`, `ValidatedRequest`, `ValidationOutcome` |
| TOFU trust store | `crates/z00z_wallets/src/core/address/stealth_trust.rs` | `PinnedReceiverCards`, `PinCheckResult`, `VerifyResult` |
| Receiver key owner | `crates/z00z_wallets/src/core/key/stealth_keys.rs` | `ReceiverKeys`, `export_receiver_card()`, `rotate_view()` |
| Stealth ECDH | `crates/z00z_wallets/src/core/stealth/ecdh.rs` | `compute_dh_sender`, `compute_dh_receiver`, `derive_k_dh`, `derive_k_dh_with_req`, `derive_s_out` |
| Hedged randomness | `crates/z00z_wallets/src/core/stealth/ephemeral.rs` | `generate_r_hedged`, `derive_r_hedged`, `compute_r_pub`, `generate_sender_salt` |
| Tag and AD binding | `crates/z00z_wallets/src/core/stealth/tag.rs` | `compute_leaf_ad`, `compute_tag16`, `compute_tag16_with_req`, `encode_leaf_preimage` |
| Lightweight stealth output | `crates/z00z_wallets/src/core/stealth/output.rs` | `TxStealthOutput`, `build_tx_stealth_output()` |
| Full confidential leaf builder | `crates/z00z_wallets/src/core/tx/builder.rs` | `build_output_leaf`, `build_output_with_blind`, `build_output_with_rng`, `sender_create_output_for` |
| Plain payload wire contract | `crates/z00z_core/src/assets/leaf.rs` | `AssetLeaf`, `AssetPackPlain` |
| ZkPack runtime facade | `crates/z00z_wallets/src/core/stealth/facade_zkpack.rs` | `ZkPack::encrypt`, `ZkPack::decrypt` |

📌 No new module may re-implement these contracts under another name unless this document is updated first and the old path is explicitly deprecated.

## 3. Current Status Summary

📌 The current codebase already implements the core receiver-input and stealth-output path, but some hardening and freeze work remains.

| Area | Current status | Blocking gaps |
| --- | --- | --- |
| `PaymentRequest` | Implemented | API and semantics need freeze in this unified spec |
| `ReceiverCard` | Implemented | Publication and trust semantics need freeze |
| `PinnedReceiverCards` | Implemented | Public contract must be frozen and documented as canonical |
| `build_tx_stealth_output()` | Implemented | `validate_output_self()` absent; `RecentRCache` absent; `tag16` still `Option<u16>` |
| `AssetLeaf` builder path | Implemented | Must be explicitly related to the lightweight Spec 5 path |
| H-3 hedged randomness | Implemented | Repeat-`R` detection is missing |
| High-level validated wrapper | Not implemented | No canonical wrapper yet combines strict input validation, build, and post-build validation |
| `validate_output_self()` | Not implemented | Needs exact scope, API, tests, and integration policy |
| `RecentRCache` | Not implemented | Needs bounded cache API and integration point |
| Stage-2 publication freeze | Not implemented | `ReceiverCardRecordV1`, downstream gate, and full matrix are missing |
| Stage-2 negative and persistence matrix | Not implemented | Tamper, stale-epoch, rotation, revocation, and persistence coverage are not frozen here yet |
| Stage-3 proof and authority replacement | Not implemented | Outside current Spec 5 solution scope |

## 4. Relationship To `Z00Z-ECC-SPEC_part1.md`

📌 `crates/Z00Z-ECC-SPEC_part1.md` remains conceptually valid for the following ideas:

- receiver secret, owner handle, view keys, and ECDH stealth construction;
- `asset_id = H("Z00Z/ASSET" || s_out)` as the ownership-binding identifier and long-term ownership model;
- `leaf_ad` as the anti-malleability binding over public leaf fields;
- `tag16` as a scan hint only, not a strong DoS defense;
- production preference for signed `PaymentRequest` over bare `ReceiverCard`.

📌 The current codebase is authoritative where the implementation differs from older text in Part 1.

📌 The most important code-accurate corrections are:

- request signing context is `b"Z00Z/REQv1"`;
- receiver card signing context is `b"Z00Z/RCARD"`;
- `PinnedReceiverCards` already exists in `stealth_trust.rs` and is not a greenfield type anymore;
- `s_out` is currently derived deterministically as `H<SOutProdDomain>("Z00Z/S_OUT", k_dh || r_pub || serial_le)` in `stealth/ecdh.rs`;
- the lightweight sender path currently accepts caller-supplied `asset_id` and does not itself prove `asset_id = H("Z00Z/ASSET" || s_out)`;
- the active wallet `ZkPack` facade uses deterministic `ChaCha20Poly1305`, with Poseidon2 parity explicitly marked as future work;
- `TxStealthOutput.tag16` is currently `Option<u16>`, while `AssetLeaf.tag16` is canonical `u16`.

## 5. Terminology And Canonical Data Types

📌 The following terms are normative in this document.

| Term | Meaning | Canonical code |
| --- | --- | --- |
| `receiver_secret` | Long-lived wallet secret from which receiver keys are derived | `core/key/stealth_keys.rs` |
| `owner_handle` | Stable receiver routing handle derived from receiver secret | `ReceiverKeys.owner_handle` |
| `view_sk` / `view_pk` | Stealth ECDH viewing key pair | `ReceiverKeys` and `stealth/ecdh.rs` |
| `identity_sk` / `identity_pk` | Long-lived identity signing key pair | `ReceiverKeys` and address modules |
| `PaymentRequest` | Signed short-lived receiver input with `req_id` and expiry | `address/stealth_request.rs` |
| `ReceiverCard` | Signed long-lived receiver input for offline use | `address/stealth_card.rs` |
| `PinnedReceiverCards` | TOFU trust store for receiver identities | `address/stealth_trust.rs` |
| `dh` | Shared ECDH point bytes computed sender-side and receiver-side | `stealth/ecdh.rs` |
| `k_dh` | Symmetric output key derived from `dh`, optionally bound to `req_id` | `stealth/ecdh.rs` |
| `owner_tag` | Receiver-bound public tag derived from `owner_handle` and `k_dh` | `stealth/output.rs` and `tx/builder.rs` |
| `leaf_ad` | Associated-data hash over public leaf fields | `stealth/tag.rs` |
| `s_out` | Output ownership secret used to derive `asset_id` and future spend capability | `stealth/ecdh.rs`, `assets/leaf.rs` |
| `asset_id` | Output identifier and JMT key | `tx/builder.rs` or caller-supplied in `stealth/output.rs` |
| `tag16` | 16-bit scan accelerator | `stealth/tag.rs` |
| `TxStealthOutput` | Lightweight Spec 5 output descriptor | `stealth/output.rs` |
| `AssetLeaf` | Full public asset leaf including range proof and canonical `u16` `tag16` | `assets/leaf.rs` |
| `AssetPackPlain` | Canonical 72-byte plaintext payload inside `enc_pack` | `assets/leaf.rs` |

## 6. Receiver Input Contract

📌 Spec 5 supports exactly two receiver input modes.

### 6.1 Supported Input Modes

📌 `PaymentRequest` is the recommended mode for production sender flows because it adds request freshness, expiry, and optional amount binding.

📌 `ReceiverCard` is the fallback long-lived mode for offline or low-interaction flows.

📌 Both input modes must ultimately supply the same cryptographic core:

- `owner_handle`;
- `view_pk`;
- `identity_pk`;
- a valid signature over canonical unsigned fields.

### 6.2 `PaymentRequest` Contract

📌 The canonical `PaymentRequest` type is defined in `crates/z00z_wallets/src/core/address/stealth_request.rs`.

📌 Normative fields are:

- `version: u8`;
- `owner_handle: [u8; 32]`;
- `view_pk: [u8; 32]`;
- `identity_pk: [u8; 32]`;
- `req_id: [u8; 32]`;
- `chain_id: u32`;
- `amount: Option<u64>`;
- `expiry: u64`;
- `metadata: Option<RequestMetadata>`;
- `signature: [u8; 64]`.

📌 The canonical request signature context is `b"Z00Z/REQv1"`.

📌 `ValidatePaymentRequest::validate_all()` is the canonical strict validation surface:

```rust
fn validate_all(
    &self,
    pins: &mut PinnedReceiverCards,
    current_chain_id: u32,
) -> Result<ValidationOutcome, PaymentRequestError>;
```

📌 The strict validation order is:

1. check version;
2. check `chain_id`;
3. check expiry;
4. validate `view_pk` and `identity_pk` as accepted Ristretto points;
5. verify the request signature;
6. consult `PinnedReceiverCards` for identity result.

### 6.3 `ReceiverCard` Contract

📌 The canonical `ReceiverCard` type is defined in `crates/z00z_wallets/src/core/address/stealth_card.rs`.

📌 Normative fields are:

- `version: u8`;
- `owner_handle: [u8; 32]`;
- `view_pk: [u8; 32]`;
- `identity_pk: [u8; 32]`;
- `card_id: Option<[u8; 16]>`;
- `metadata: Option<CardMetadata>`;
- `signature: [u8; 64]`.

📌 The canonical card signature context is `b"Z00Z/RCARD"`.

📌 `ReceiverKeys::export_receiver_card()` in `crates/z00z_wallets/src/core/key/stealth_keys.rs` is the canonical card-construction path for signed directory publication.

📌 `ReceiverCard` may carry `metadata.valid_until`; callers that rely on long-lived cards must still treat a populated `valid_until` as a real expiry boundary.

### 6.4 Trust Pinning Contract

📌 The canonical trust store is `PinnedReceiverCards` in `stealth_trust.rs`.

📌 Current trust levels are:

- `Pinned`;
- `Tentative`;
- `Expired`;
- `Revoked`.

📌 Current trust result enums are:

- `VerifyResult` for card verification and TOFU pinning;
- `PinCheckResult` for request identity checks.

📌 Spec 5 freezes these semantics as current behavior and forbids introducing a second pinning store under another module.

### 6.5 Receiver Validation Flow

```mermaid
flowchart TD
    Start[Sender receives payment material] --> Mode{Input mode}
    Mode -->|PaymentRequest| ReqA[Check version and chain_id]
    Mode -->|ReceiverCard| CardA[Validate structure]
    ReqA --> ReqB[Check expiry]
    ReqB --> ReqC[Validate view_pk and identity_pk]
    ReqC --> ReqD[Verify request signature]
    ReqD --> ReqE[Consult PinnedReceiverCards]
    CardA --> CardB[Validate ECC points]
    CardB --> CardC[Verify card signature]
    CardC --> CardD[Consult trust policy if used]
    ReqE --> Ready[Receiver input accepted]
    CardD --> Ready
```

📌 Caller responsibility is strict. A caller must not pass receiver input to the sender build path if structure validation, point validation, signature validation, expiry checks, or trust checks have failed.

### 6.6 Critical Caller Caveats

📌 `build_tx_stealth_output()` does not call `receiver_card.verify()` internally.

📌 `build_tx_stealth_output()` does not call `ValidatePaymentRequest::validate_all()` internally.

📌 The current internal helper `validate_request_bind()` only enforces:

- request signature validity;
- equality of `owner_handle`, `view_pk`, and `identity_pk` between request and card;
- optional fixed-amount match;
- request non-expiry.

📌 It does not enforce current-chain equality because `build_tx_stealth_output()` does not accept `current_chain_id`.

📌 Therefore explicit cross-chain protection for request-bound sends currently requires a pre-build call to `validate_all()`.

## 7. Output Models And Their Relationship

📌 The current codebase has two related but distinct output representations.

### 7.1 `TxStealthOutput`

📌 `TxStealthOutput` in `crates/z00z_wallets/src/core/stealth/output.rs` is the lightweight Spec 5 descriptor used by the sender-side stealth pipeline.

📌 Current fields are:

- `r_pub: [u8; 32]`;
- `owner_tag: [u8; 32]`;
- `tag16: Option<u16>`;
- `enc_pack: ZkPackEncrypted`;
- `c_amount: [u8; 32]`.

### 7.2 `AssetLeaf`

📌 `AssetLeaf` in `crates/z00z_core/src/assets/leaf.rs` is the full public leaf structure.

📌 Current fields are:

- `asset_id: [u8; 32]`;
- `serial_id: u32`;
- `r_pub: [u8; 32]`;
- `owner_tag: [u8; 32]`;
- `c_amount: [u8; 32]`;
- `enc_pack: ZkPackEncrypted`;
- `range_proof: Vec<u8>`;
- `tag16: u16`.

### 7.3 `AssetPackPlain`

📌 `AssetPackPlain` is the canonical plaintext wire payload carried inside `enc_pack`.

📌 Current canonical layout is exactly 72 bytes:

- `value[0..8]` as little-endian `u64`;
- `blinding[8..40]` as 32 bytes;
- `s_out[40..72]` as 32 bytes.

## 8. Canonical Formulae

📌 The following formulae are normative for the current implementation.

### 8.1 `k_dh`

```text
k_dh = H<KdhDomain>("", dh)
k_dh_with_req = H<KdhDomain>("", dh || req_id)
```

### 8.2 `owner_tag`

```text
owner_tag = H<OwnerTagDomain>("", owner_handle || k_dh)
```

### 8.3 `leaf_ad`

```text
leaf_ad = H<WalletLeafAdHashProdDomain>(
  "Z00Z/LEAFAD",
  asset_id || serial_id_le4 || r_pub || owner_tag || c_amount
)
```

### 8.4 `s_out`

```text
s_out = H<SOutProdDomain>("Z00Z/S_OUT", k_dh || r_pub || serial_id_le4)
```

📌 This differs from older Part 1 prose that treated `s_out` as independently random. Current Rust code is authoritative.

### 8.5 `asset_id`

📌 The current code supports two surfaces:

- in the lightweight `build_tx_stealth_output()` path, `asset_id` is an external caller input;
- in the full `AssetLeaf` builder path, `asset_id = H<AssetIdDomain>("", s_out)` is derived internally from `s_out`.

### 8.6 `tag16`

```text
tag16_card = Trunc16(H<WalletTag16HashProdDomain>("Z00Z/TAG16", k_dh || leaf_ad))
tag16_req  = Trunc16(H<WalletTag16HashProdDomain>("Z00Z/TAG16", k_dh || req_id))
```

📌 `tag16` is a scan hint only. It is not a stable address and not a sufficient DoS defense.

## 9. Sender Output Construction Contract

📌 Before any builder is called, the caller must guarantee:

1. receiver input has passed Section 6 validation;
2. the `asset_id` source is explicitly chosen and documented for the selected path;
3. `tx_digest` is stable for the output set being built;
4. `out_index` is stable within the transaction context;
5. the caller understands whether it is building a lightweight `TxStealthOutput` or a full `AssetLeaf`.

### 9.1 Lightweight Spec 5 Build Path

📌 The canonical lightweight builder is:

```rust
pub fn build_tx_stealth_output(
    receiver_card: &ReceiverCard,
    payment_request: Option<&PaymentRequest>,
    sender_wallet: &SenderWallet,
    tx_digest: &[u8; 32],
    out_index: u32,
    amount: u64,
    asset_id: &[u8; 32],
) -> Result<TxStealthOutput, StealthError>;
```

📌 The current code executes the following steps:

1. validate `payment_request` binding against `receiver_card` if the request is present;
2. derive `r = generate_r_hedged(secret_salt, tx_digest, out_index)`;
3. compute `r_pub = r * G` and encode it;
4. decode `receiver_card.view_pk` as a valid Ristretto point;
5. compute sender-side `dh = r * view_pk`;
6. derive `k_dh`, optionally request-bound by `req_id`;
7. set `serial_id = 0u32` in the current lightweight path;
8. compute `owner_tag` from `owner_handle` and `k_dh`;
9. generate fresh Pedersen blinding and compute `c_amount`;
10. compute `leaf_ad` over `(asset_id, serial_id, r_pub, owner_tag, c_amount)`;
11. derive `s_out = derive_s_out(k_dh, r_pub, serial_id)`;
12. build `AssetPackPlain { value, blinding, s_out }`;
13. encrypt that payload with `ZkPack::encrypt()`;
14. derive `tag16` from `leaf_ad` or `req_id` depending on request binding;
15. return `TxStealthOutput`.

📌 Silent-failure risk: this path does not itself verify that the caller-supplied `asset_id` is consistent with the derived `s_out`.

📌 Silent-failure risk: this path does not itself enforce `current_chain_id` for request-bound sends.

### 9.2 Full `AssetLeaf` Build Path

📌 The current full builder path in `crates/z00z_wallets/src/core/tx/builder.rs` performs the full public leaf construction including `asset_id`, `range_proof`, and canonical `u16` `tag16`.

📌 Canonical entry points are:

```rust
pub fn build_output_leaf(... ) -> Result<AssetLeaf, WalletError>;
pub fn build_output_with_blind(... ) -> Result<AssetLeaf, WalletError>;
pub fn build_output_with_rng(... ) -> Result<AssetLeaf, WalletError>;
pub fn sender_create_output_for(
    card: &ReceiverCard,
    amount: u64,
    serial_id: u32,
) -> Result<AssetLeaf, WalletError>;
```

📌 The full builder path differs from the lightweight path in three critical ways:

- it derives `asset_id` internally from `s_out`;
- it carries explicit `serial_id` rather than forcing `0u32`;
- it creates a real `range_proof` and returns a full `AssetLeaf`.

📌 There is also one critical implementation divergence that must not be hidden:

- `sender_create_output_for()` currently samples `r` directly with `Z00ZScalar::random()` and does not use the H-3 hedged randomness path.

📌 It also currently enforces `serial_id ∈ [1, 50_000]`, which is semantically different from the lightweight path's hardcoded `serial_id = 0u32`.

📌 This serial mismatch is an explicit transitional inconsistency and must be treated as such by later layers.

### 9.3 Critical Current Divergences

📌 The current codebase has three important divergences that implementers must keep visible:

1. the lightweight path uses caller-supplied `asset_id`, while the full path derives `asset_id` from `s_out`;
2. the lightweight path hardcodes `serial_id = 0u32`, while the full path requires `serial_id ∈ [1, 50_000]`;
3. the full path still uses direct random `r`, while the lightweight path uses H-3 hedged randomness.

📌 These divergences are not editorial details. They are active design and implementation gaps.

### 9.4 Build Flow Diagram

```mermaid
flowchart TD
    Start[Validated receiver input] --> H3[generate_r_hedged]
    H3 --> Rpub[compute_r_pub]
    Rpub --> View[decode receiver view_pk]
    View --> DH[compute_dh_sender]
    DH --> KDH[derive_k_dh or derive_k_dh_with_req]
    KDH --> OT[compute owner_tag]
    OT --> Commit[create commitment and c_amount]
    Commit --> AD[compute leaf_ad]
    AD --> Sout[derive_s_out]
    Sout --> Pack[build AssetPackPlain]
    Pack --> Enc[ZkPack encrypt]
    Enc --> Tag[derive tag16]
    Tag --> Light[return TxStealthOutput]
    Tag --> Full[or assemble AssetLeaf with range_proof]
```

## 10. Encryption And Payload Contract

📌 The active `ZkPack` runtime facade is defined in `crates/z00z_wallets/src/core/stealth/facade_zkpack.rs`.

📌 The current runtime behavior is:

- deterministic `ChaCha20Poly1305` AEAD;
- key derived from `derive_pack_key(k_dh, asset_id, serial_id)`;
- nonce derived from `derive_nonce(leaf_ad, r_pub, asset_id, serial_id)`;
- AAD built from `(version, leaf_ad, r_pub, asset_id, serial_id_le4)`.

📌 Fresh `r_pub` uniqueness is not optional in this runtime. Reuse of the same `(key, nonce)` context would undermine the deterministic AEAD safety assumptions.

📌 Metadata hiding is not a current goal of this runtime path. The current facade explicitly treats metadata hiding as a non-goal for the fixed V1 wire profile.

📌 The active runtime path is code-authoritative, even though older prose in Part 1 describes Poseidon2-based ZkPack parity as the long-term target.

📌 The current project MUST NOT claim that the active runtime has already reached Poseidon2 or OWF-circuit parity.

## 11. Remaining Implementation

### H-1. Freeze Receiver Input Surface

📌 Goal: make the receiver input surface explicit, canonical, and reviewable.

📌 This section is complete only when the repository exposes one canonical construction path, one canonical validation surface, one frozen validation order, and one explicit caller contract for pre-build receiver validation.

📌 Audited receiver-input entry points for this workstream:

- `PaymentRequest` construction: `PaymentRequest::generate(...)`, `create_invoice_for_merchant(...)`, `PaymentRequest::sign(...)`;
- `PaymentRequest` validation and transport: `PaymentRequest::verify(...)`, `ValidatePaymentRequest::validate_all(...)`, `decode_request_compact(...)`;
- `ReceiverCard` construction: `ReceiverKeys::export_receiver_card()`;
- `ReceiverCard` validation and transport: `ReceiverCard::verify(...)`, `ValidateReceiverCard::{validate_structure, validate_ecc_points, validate_signature}`, `decode_card_compact(...)`, `prove_ownership(...)`;
- demoted or removed bypass helpers during H-1 freeze: `validate_and_prepare_payment(...)`, `ReceiverCardOperations::create_card(...)`, `sign_receiver_card(...)`;
- request-bound send shim that remains internal and must not be treated as canonical validation: `asset_impl.rs::request_to_card(...)`.

📌 Implementation checklist:

- [x] Run a workspace audit and write down every public construction and validation entry point for `PaymentRequest` and `ReceiverCard`; do not proceed until this inventory is complete.
- [x] Keep `ReceiverKeys::export_receiver_card()` in `crates/z00z_wallets/src/core/key/stealth_keys.rs` as the only public card-export path; convert every alternate public constructor that emits a signed card into `pub(crate)` or remove it.
- [x] Keep `PaymentRequest::sign`, `PaymentRequest::verify`, `ValidatePaymentRequest::validate_all`, and `ValidateReceiverCard` as the only accepted validation surface; remove or demote any helper that bypasses one of these checks.
- [x] In `crates/z00z_wallets/src/core/address/stealth_request.rs`, define one protocol constant for the request signature context and use that exact constant from both signing and verification code paths.
- [x] In `crates/z00z_wallets/src/core/address/stealth_card.rs`, define one protocol constant for the card signature context and use that exact constant from both signing and verification code paths.
- [x] In `crates/z00z_wallets/src/core/address/mod.rs`, re-export only the canonical types and validation traits that this spec names; do not re-export convenience helpers that bypass canonical validation.
- [x] Make the validation order in `validate_all()` match Section 6 exactly: version check, chain check, expiry check, point decoding, signature verification, then pin lookup; keep this order stable and test it.
- [x] Make `ReceiverCard` verification follow one fixed order: version check, point decoding, signature verification, optional `metadata.valid_until` handling, then trust-policy use by callers.
- [x] Add one doc-comment block above `build_tx_stealth_output()` in `crates/z00z_wallets/src/core/stealth/output.rs` stating that caller-side receiver validation is mandatory and not performed internally.
- [x] Add unit tests in the receiver input modules for invalid version, invalid `view_pk`, invalid `identity_pk`, invalid signature, mismatched `owner_handle`, and expired request handling.
- [x] Add one regression test proving that an unverified `ReceiverCard` can still reach `build_tx_stealth_output()` unless the caller validates first; the test must document this as caller misuse, not builder correctness.
- [x] Update this document only after the code-level inventory, exports, constants, and tests are in place; do not mark H-1 complete on documentation alone.

### H-2. Freeze Stage-2 Trust And Publication Semantics

📌 Goal: convert current trust primitives into a stable publication contract.

📌 This section is complete only when Stage-2 publication consumes one canonical verified record type, rejects stale or revoked material deterministically, and preserves its invariants in both code and test artifacts.

📌 Canonical Stage-2 publication surface for this workstream:

- publication record owner: `crates/z00z_wallets/src/core/chain/receiver_card_record.rs`;
- canonical record type: `ReceiverCardRecordV1`;
- canonical acceptance gate: `verify_receiver_card_record(...)`;
- canonical runtime states: `RevocationState::{Active, Revoked}`;
- canonical downstream artifact source: `ReceiverCardRecordV1::to_compact()`;
- canonical invariant ledger: `specs/011-z00z-ecc-spec-5/stage-2-ledger.md`.

📌 Implementation checklist:

- [x] Create `crates/z00z_wallets/src/core/chain/receiver_card_record.rs` and keep all Stage-2 publication record logic in that file; do not place the publication record in `core/address` or any stealth-crypto module.
- [x] Define `ReceiverCardRecordV1` with one exact field set: `version: u8`, `receiver_card_bytes: Vec<u8>`, `card_epoch: u64`, `registry_entry_id: [u8; 32]`, and `revocation_state: RevocationState`.
- [x] Define `RevocationState` in the same file and keep the runtime states fixed to `Active` and `Revoked`; do not add implicit or undocumented states.
- [x] Require `receiver_card_bytes` to be the canonical serialized card payload; do not duplicate `owner_handle`, `view_pk`, `identity_pk`, or `signature` as shadow fields inside the record.
- [x] Implement one constructor for `ReceiverCardRecordV1` that accepts only an already verified `ReceiverCard` and its canonical bytes; reject creation from unchecked or partially checked input.
- [x] Implement `verify_receiver_card_record(...)` in the same module and make it the only downstream acceptance gate for Stage-2 consumers.
- [x] Re-export `ReceiverCardRecordV1`, `RevocationState`, and `verify_receiver_card_record(...)` through `crates/z00z_wallets/src/core/chain/mod.rs`; do not re-export them through `core/address`.
- [x] Make the verification order fixed and testable: parse `receiver_card_bytes`, verify the embedded card with canonical validation, verify `registry_entry_id`, evaluate `revocation_state`, then apply stale-epoch rejection.
- [x] Define the stale-epoch rule in code, not only in prose: a record with an older `card_epoch` than the latest accepted epoch for the same identity must be rejected.
- [x] Make publication artifact generation consume only `ReceiverCardRecordV1`; remove any path that generates artifacts directly from raw `ReceiverCard` input.
- [x] Add a Stage-2 persistence rule that the same stored record cannot later be relabeled under a different `registry_entry_id` or a different receiver identity.
- [x] Create `specs/011-z00z-ecc-spec-5/stage-2-ledger.md` and list every Stage-2 invariant that is enforced only by tests or runtime checks.
- [x] Add tests for tampered owner handle, tampered `view_pk`, tampered `identity_pk`, tampered signature, stale epoch, revoked record, rotated card with new epoch, and persistence relabeling attempts.
- [x] Add one integration test that proves downstream code accepts only verified `ReceiverCardRecordV1` instances and rejects direct raw-card injection.
- [x] Do not mark H-2 complete until the record type, the acceptance gate, the stale-epoch rule, the revocation rule, and the Stage-2 ledger all exist in the repository.

### H-3. Hedged Randomness Hardening And Repeat-`R` Detection

📌 Goal: keep the current H-3 implementation authoritative while adding the missing repeat-`R` hardening layer.

📌 The current canonical H-3 derivation is already implemented as:

```text
r = h2s_zk<WalletEphemeralRHashProdDomain>(
  "R",
  rng_bytes || sender_secret_salt || tx_digest || out_index_le4
)
```

📌 This section is complete only when duplicate-`R` prevention is part of the sender build path, retry behavior is deterministic and bounded, and no legacy path can silently bypass the chosen policy.

📌 Implementation checklist:

- [x] Keep `generate_r_hedged()` and `derive_r_hedged()` in `crates/z00z_wallets/src/core/stealth/ephemeral.rs` as the only scalar derivation entry points; do not introduce a second scalar-derivation helper elsewhere.
- [x] Refactor the existing `crates/z00z_wallets/src/core/address/ephemeral_cache.rs` into the canonical bounded recent-`R` cache instead of creating a second cache module with overlapping purpose.
- [x] Keep the public cache type name aligned with the existing wallet facade by re-exporting it through `crate::core::cache`; do not introduce parallel cache types for the same duplicate-`R` purpose.
- [x] Define the cache with one fixed internal model: receiver-handle keyed membership plus bounded insertion order for compressed `r_pub: [u8; 32]` values.
- [x] Implement one fixed public API on the cache type: `new(capacity: usize)`, `check_and_insert(handle: &[u8; 32], r_pub: &[u8; 32]) -> Result<(), WalletError>`, and deterministic eviction of the oldest entry for that receiver when capacity is exceeded.
- [x] Extend `SenderWallet` in `crates/z00z_wallets/src/core/stealth/output.rs` to hold a private cache instance; remove `Copy` from `SenderWallet` and make cache-using builder entry points take `&mut SenderWallet` rather than relying on global state or hidden interior mutability.
- [x] Add one retry helper in `ephemeral.rs` that derives a retry digest from `(tx_digest, retry_index)` and feeds that digest back into `generate_r_hedged()`; do not bypass H-3 by sampling a random fallback scalar.
- [x] Use one fixed retry ceiling constant in `output.rs`; fail the build with an explicit error when that ceiling is exceeded.
- [x] Change `build_tx_stealth_output()` to accept `sender_wallet: &mut SenderWallet`, derive `r`, compute `r_pub`, call the cache before any output is returned, retry on collision, and insert the accepted `r_pub` exactly once.
- [x] Keep zero-scalar rejection unchanged; a retry due to cache collision must not alter the existing zero-scalar failure classification.
- [x] Decide one policy for `sender_create_output_for()`: either migrate it to the same H-3 retry flow or mark it as legacy in code and docs; do not leave this undecided.
- [x] Add deterministic tests for first-attempt success, cache-hit retry, retry-ceiling failure, eviction behavior at capacity, and unchanged zero-scalar rejection.
- [x] Add one test proving that two outputs built with the same `(secret_salt, tx_digest, out_index)` cannot silently reuse the same `r_pub` once the cache is enabled.
- [x] Update this spec only after the cache module, sender context wiring, retry helper, and collision tests are present in code.

### H-4. Implement `validate_output_self()`

📌 Goal: add sender-side post-build validation without duplicating the build algorithm.

📌 `validate_output_self()` must be the single post-build validator for the lightweight path. It must recompute `leaf_ad`, decrypt `enc_pack`, verify `AssetPackPlain`, verify `s_out`, verify the amount commitment, verify `owner_tag`, and verify `tag16` under the correct binding mode.

📌 The validated wrapper must become the canonical strict path for request-bound sends, including `validate_all()` and `current_chain_id` enforcement before build.

📌 Implementation checklist:

- [x] Create `crates/z00z_wallets/src/core/stealth/output_validator.rs`; keep all post-build sender validation logic in that file and do not duplicate builder code in multiple modules.
- [x] Define one exact context type named `SenderValidationCtx` with the minimum required inputs: `k_dh: [u8; 32]`, `owner_handle: [u8; 32]`, `asset_id: [u8; 32]`, `serial_id: u32`, and `tag_mode: TagMode`.
- [x] Define `TagMode` with exactly two variants: `CardBound` and `RequestBound { req_id: [u8; 32] }`.
- [x] Implement `validate_output_self(output: &TxStealthOutput, ctx: &SenderValidationCtx, amount: u64) -> Result<(), StealthError>` as the only post-build validator for the lightweight path.
- [x] Recompute `leaf_ad` from public fields inside the validator and use the recomputed value for every subsequent validation step; do not trust a cached or caller-supplied `leaf_ad`.
- [x] Decrypt `enc_pack` with `ZkPack::decrypt`, decode `AssetPackPlain`, and fail immediately on decryption or decoding mismatch.
- [x] Compare the decrypted `AssetPackPlain.value` against the expected `amount` argument and fail on any mismatch before checking the commitment.
- [x] Recompute `s_out` from `ctx.k_dh`, `output.r_pub`, and `ctx.serial_id`, then compare it against the decrypted `s_out` using constant-time equality.
- [x] Recompute the commitment from the decrypted amount and blinding, then compare it against `output.c_amount`; fail on any mismatch.
- [x] Recompute `owner_tag` from `ctx.owner_handle` and `ctx.k_dh`, then compare it against `output.owner_tag`; fail on any mismatch.
- [x] Recompute `tag16` using `TagMode` and compare it against `output.tag16`; reject `None` when the validated path requires a concrete tag value.
- [x] Add one strict wrapper named `build_tx_stealth_output_validated(...)` in `output.rs` with explicit inputs for `pins: &mut PinnedReceiverCards`, `current_chain_id: u32`, and `sender_wallet: &mut SenderWallet`; it must perform request validation, build the output, derive the sender validation context, run `validate_output_self()`, and only then return success.
- [x] Require `build_tx_stealth_output_validated(...)` to call `ValidatePaymentRequest::validate_all(pins, current_chain_id)` before building any request-bound output; do not leave chain-id enforcement to documentation only.
- [x] Add negative tests for tampered `enc_pack`, wrong `asset_id`, wrong `serial_id`, wrong `owner_tag`, wrong `c_amount`, wrong `tag16`, and mismatched request-binding mode.
- [x] Add one cross-path test matrix that builds semantically equivalent outputs through the lightweight and full paths and asserts which fields must match, which fields may differ, and why.
- [x] Do not mark H-4 complete until the validator, the validated wrapper, the chain-id-enforcing pre-build path, and the negative tests all exist in code.

### H-5. Freeze Stage-3 Upstream Assumptions

📌 Goal: define what Stage-3 may assume from the sender-output layer without re-specifying wallet internals.

📌 This section is complete only when Stage-3 can consume one explicit assumptions artifact instead of inferring wallet semantics from scattered prose, tests, or implementation details.

📌 Canonical assumptions artifact: [stage-3-assumptions.md](stage-3-assumptions.md).

📌 Implementation checklist:

- [x] Create `specs/011-z00z-ecc-spec-5/stage-3-assumptions.md` and keep all Stage-3 upstream assumptions in that one file; do not spread them across notes or TODO files.
- [x] Add one normative table for `asset_id` stating the lightweight-path meaning, the full-path meaning, and the exact risk when a caller-supplied `asset_id` is inconsistent with `s_out`.
- [x] Add one normative table for `s_out` stating how it is derived, which layers may consume it, and which layers must never assume it is independently random.
- [x] Add one normative table for `leaf_ad` listing the exact field order, byte encoding, and why each field is bound.
- [x] Add one normative table for `tag16` stating that it is a scan hint only and must never be treated as ownership proof or anti-DoS proof by itself.
- [x] Add one cross-path invariants table for `TxStealthOutput` versus `AssetLeaf` listing the fields that must align, the fields that may diverge, and the reason for each divergence.
- [x] Add one explicit unresolved-boundary section for the current `serial_id` split and tie it to the acceptance criteria in this document.
- [x] Link `stage-3-assumptions.md` from this spec and make Stage-3 planning documents reference only that file for upstream wallet assumptions.
- [x] Add one review rule that Stage-3 code must not consume any wallet-side assumption that is not listed in `stage-3-assumptions.md`.
- [x] Do not mark H-5 complete until the assumptions file exists, the tables are filled, the cross-path invariants are named, and the serial split is documented as unresolved or resolved.

### H-6. Stage-1 Authority Integration Boundary

📌 Goal: explicitly mark what Spec 5 needs from Stage-1 but does not itself implement.

📌 This section is complete only when Spec 5 depends on one explicit Stage-1 authority contract with named artifacts, named fields, named replacement rules, and named rejection conditions.

📌 Canonical Stage-1 dependency contract: [stage-1-authority-boundary.md](stage-1-authority-boundary.md).

📌 Implementation checklist:

- [x] Create `specs/011-z00z-ecc-spec-5/stage-1-authority-boundary.md` and keep the Stage-1 dependency contract in that file only.
- [x] Define the exact artifact names that Spec 5 expects from Stage-1: `GenesisAuthority`, `GenesisManifest`, and one machine-readable assumptions artifact containing manifest hash, config hash, and accepted root hash.
- [x] State the exact fields that Spec 5 later stages may read from those artifacts and forbid every other implicit dependency.
- [x] Define the one replacement rule for Stage-3: authenticated manifest authority replaces any transitional fixed-root or zero-root binding when Stage-1 is ready.
- [x] Add one acceptance rule that no Stage-3 code path may claim authenticated authority unless the Stage-1 artifact has been verified by its canonical verifier.
- [x] Add one rejection matrix covering missing artifact, wrong manifest hash, wrong config hash, wrong root hash, and invalid authority signature.
- [x] Add one link from this spec to the Stage-1 boundary file and one backlink from the Stage-1 file to this spec.
- [x] Do not mark H-6 complete until the boundary file exists, the artifact set is frozen, and the replacement rule is written in one place without ambiguity.

### H-7. Stage-3 And Stage-4 Work Outside This Spec

📌 Goal: keep the remaining roadmap visible without turning Spec 5 into a false “everything is solved” document.

📌 The remaining out-of-scope work is limited to four tracks: final public claim proof replacement, final chain authority model replacement, final public spend-proof verifier, and final public fee-proof verifier.

📌 This section is complete only when each of those tracks is tracked in one canonical post-Spec-5 closure file with a current mechanism, a target mechanism, a removal condition, and an observable exit criterion.

📌 Canonical closure artifact: [post-spec-5.md](post-spec-5.md).

📌 Implementation checklist:

- [x] Create `specs/011-z00z-ecc-spec-5/post-spec-5.md` as the only canonical post-Spec-5 closure document and move all remaining Stage-3 and Stage-4 backlog items there; do not leave them scattered across notes.
- [x] Split the canonical closure document into exactly four tracks: claim proof, chain authority, spend-proof verifier, and fee-proof verifier.
- [x] For each track, write one entry that names the current transitional mechanism, the intended final mechanism, and the condition that allows the old mechanism to be removed.
- [x] For each track, write one exit criterion that is observable in code and tests, not only in prose.
- [x] Add one dependency section showing which Stage-3 and Stage-4 items are blocked by Stage-1 authority completion and which are independent of it.
- [x] Add one rule that no document in this repository may claim these four items are complete until `post-spec-5.md` says they are closed.
- [x] Link `post-spec-5.md` from this spec and from the top-level Scenario-1 planning material.
- [x] Do not mark H-7 complete until the canonical post-Spec-5 closure file exists and every remaining non-Spec-5 proof or authority item is tracked there with an exit criterion.

## 12. Implementation Order

📌 The recommended execution order is:

1. H-1 Freeze receiver input surface.
2. H-2 Freeze Stage-2 trust and publication semantics.
3. H-3 Add repeat-`R` hardening around the already-implemented H-3 core.
4. H-4 Implement `validate_output_self()`.
5. H-5 Freeze Stage-3 upstream assumptions.
6. H-6 Integrate Stage-1 authority boundary when the Stage-1 artifact is ready.
7. H-7 Continue with final Stage-3 and Stage-4 proof work outside Spec 5.

## 13. Acceptance Criteria For Spec 5 Freeze

📌 Spec 5 can be considered frozen for the current runtime only when all of the following are true:

1. receiver input surfaces are frozen to the canonical modules listed in Section 2;
2. Stage-2 publication consumes only verified receiver material;
3. Stage-2 negative, stale-epoch, revocation, rotation, and persistence-relabeling cases are covered by explicit tests or by a written waiver;
4. H-3 repeat-`R` detection is implemented or explicitly waived with written rationale;
5. `validate_output_self()` exists or an explicit decision records why it is deferred;
6. the relationship between `TxStealthOutput` and `AssetLeaf` is fully documented and tested;
7. the project documentation does not over-claim Poseidon2 or public-proof parity beyond what the runtime actually implements;
8. the project documentation explicitly records how `current_chain_id` is enforced for request-bound sends;
9. the project documentation explicitly records whether `sender_create_output_for()` remains legacy or is migrated to H-3.

## 14. Editorial Policy

📌 When this document is updated, follow these rules:

1. keep normative content in this file;
2. keep Rust code as the next authority after this file;
3. do not duplicate function bodies or struct definitions when a small signature or field list is sufficient;
4. if the code proves a statement is outdated, update the statement here instead of keeping the legacy wording;
5. if a pending feature is not implemented, do not upgrade its status here without code proof.
