# Stage-4 Verifier Matrix

📌 This matrix lists the active Stage-4 runtime gates, their owner modules, and the verifier class that is live in code today.

📌 Remaining proof and authority work outside the current Spec-5 freeze is tracked only in the canonical `post-spec-5.md` closure spec in this folder.

📌 The matrix is intentionally narrow. It records what Stage-4 really checks now, not the deferred public-proof architecture planned for later steps.

| field or gate | owner module | current verifier | verifier class | fail-closed status | notes |
| --- | --- | --- | --- | --- | --- |
| claim package prerequisite | z00z_simulator::scenario_1::stage_4 and z00z_simulator::claim_pkg_consumer | load_claim_pkgs | typed-runtime-check | yes | Stage-4 refuses to continue when tx_claim_pkg.json is missing, malformed, or semantically invalid. Tests: test_stage4_claim_gate::stage4_rejects_missing_claim_pkg, test_stage4_claim_gate::stage4_rejects_bad_claim_pkg, test_stage4_claim_gate::stage4_bad_pkg_fails. |
| output self-decrypt and range proof | z00z_wallets::core::tx::output_flow | verify_self_decrypt | witness-bound | yes | Uses sender-side output bundle state and decrypted pack data to confirm tag16, plaintext decode, commitment opening, and range proof. Tests: test_stage4_output_crypto::stage4_output_crypto_ok, test_stage4_output_crypto::stage4_output_tamper_fail. |
| fee formula match | z00z_simulator::scenario_1::stage_4 | verify_fee_matches_formula | typed-runtime-check | yes | Checks that the declared fee equals the deterministic fee formula over the built tx shape. Test: test_stage4_split::stage4_amount_fee. |
| plaintext amount balance | z00z_wallets::core::tx::output_flow | verify_plaintext_balance_with_fee | witness-bound | yes | Compares local input amounts and output amounts after fee planning. Test: test_stage4_gates::stage4_plain_gate_ok. |
| tx digest canonicalization | z00z_wallets::core::tx::output_flow and z00z_simulator::scenario_1::stage_4 | compute_tx_digest_from_wire and build_tx_package_digest | typed-runtime-check | yes | Rebuilds the tx digest from canonical tx wire before downstream package verification. Test: test_stage4_digest::stage4_digest_stable_with_seed. |
| commitment balance equation | z00z_wallets::core::tx::output_flow and z00z_simulator::scenario_1::stage_4 | z00z_wallets::core::tx::verify_commitment_balance_gate via verify_commitment_balance_gate | typed-runtime-check | yes | Pure commitment-equation check over public commitment bytes; this is a fail-closed public-data algebra gate, not a standalone proof verifier and therefore narrower than a final public spend proof. Tests: test_stage4_gates::stage4_commit_gate_ok, stage_4.rs unit test verify_commitment_balance_gate. |
| spend witness gate | z00z_wallets::core::tx::witness_gate | verify_spend_witness_gate | witness-bound | yes | Reconstructs sender-owned input relations from decryptable witness material and local receiver secret data. Tests: test_stage4_gates::stage4_witness_gate_ok, test_stage4_tamper::stage4_rejects_bad_witness. |
| tx package transport verification | z00z_wallets::core::tx::tx_verifier | TxVerifierImpl::verify | typed-runtime-check | yes | Stage-4 validates the final tx package bytes before persistence or handoff. Tests: test_tx_handoff_integration::test_tx_handoff_integration, stage_4.rs verify_tx_package path. |
