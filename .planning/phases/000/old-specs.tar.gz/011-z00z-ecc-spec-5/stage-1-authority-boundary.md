📌 Canonical parent spec: [spec-5.md](spec-5.md).

# Stage-1 Authority Boundary

📌 This file is the only Stage-1 dependency contract for Spec 5.

📌 Spec 5 does not implement authenticated genesis authority. Spec 5 only names the Stage-1 artifacts, the fields that later stages may read, the one replacement rule, and the rejection conditions that gate authenticated authority claims.

## 1. Required Artifact Set

📌 Spec 5 expects exactly three Stage-1 artifacts:

| Artifact | Role | Required status |
| --- | --- | --- |
| `GenesisAuthority` | Authenticated authority statement for one manifest | Required |
| `GenesisManifest` | Canonical manifest payload for the accepted genesis configuration | Required |
| `Stage1Assumptions` | Machine-readable hash bundle consumed by later stages | Required |

📌 `Stage1Assumptions` is the only machine-readable assumptions artifact that later stages may consume from Stage-1.

## 2. Allowed Read Surface

📌 Later Spec 5 stages may read only the fields listed in this section.

### 2.1 `GenesisAuthority`

📌 Allowed readable fields for later Stage-3 and Stage-4 consumers:

| Field | Purpose |
| --- | --- |
| `manifest_hash` | Binds the authority statement to one exact manifest |

📌 `authority_sig` and `authority_pk` are canonical-verifier inputs, not downstream consumer fields.

📌 No Stage-3 or Stage-4 code path may read any other `GenesisAuthority` field implicitly.

### 2.2 `GenesisManifest`

📌 Allowed readable fields:

| Field | Purpose |
| --- | --- |
| `manifest_hash` | Stable manifest identifier that must match the authority artifact |
| `config_hash` | Stable hash of the accepted configuration payload |
| `root_hash` | Accepted authenticated root that later stages may bind to |

📌 No Stage-3 or Stage-4 code path may treat raw manifest contents as an implicit dependency outside these named fields.

### 2.3 `Stage1Assumptions`

📌 Required exact fields:

| Field | Purpose |
| --- | --- |
| `manifest_hash` | Mirror of the accepted `GenesisManifest.manifest_hash` |
| `config_hash` | Mirror of the accepted `GenesisManifest.config_hash` |
| `accepted_root_hash` | Mirror of the accepted `GenesisManifest.root_hash` |

📌 `Stage1Assumptions` must not introduce additional authority, policy, or routing fields for Spec 5 consumers.

## 3. Explicit Dependency Fence

📌 Spec 5 later stages may depend only on the following Stage-1 facts:

- `GenesisAuthority` verifies successfully under its canonical verifier.
- `GenesisAuthority.manifest_hash` matches `GenesisManifest.manifest_hash`.
- `Stage1Assumptions.manifest_hash` matches the accepted manifest hash.
- `Stage1Assumptions.config_hash` matches the accepted config hash.
- `Stage1Assumptions.accepted_root_hash` matches the accepted manifest root hash.

📌 Every other dependency is forbidden. In particular, Spec 5 later stages must not implicitly depend on raw genesis config bytes, unnamed manifest fields, side-channel deployment notes, or ad hoc fixed roots outside this contract.

## 4. Replacement Rule

📌 Stage-3 has one replacement rule only.

📌 When Stage-1 authenticated authority is available, the verified Stage-1 artifact set replaces every transitional fixed-root binding and every zero-root binding used by Stage-3 code or tests.

📌 The verified Stage-1 artifact set is exactly `GenesisAuthority`, `GenesisManifest`, and `Stage1Assumptions` accepted together by the canonical verifier.

📌 After that replacement point, no Stage-3 path may claim that a fixed root or zero root is an authenticated authority source.

## 5. Acceptance Rule

📌 No Stage-3 code path may claim authenticated authority unless the Stage-1 artifact set has been verified by its canonical verifier.

📌 The minimum verified set is:

1. The canonical verifier accepts `GenesisAuthority` by validating `authority_sig` against `authority_pk`.
2. `GenesisAuthority.manifest_hash` equals `GenesisManifest.manifest_hash`.
3. `Stage1Assumptions.manifest_hash` equals `GenesisManifest.manifest_hash`.
4. `Stage1Assumptions.config_hash` equals `GenesisManifest.config_hash`.
5. `Stage1Assumptions.accepted_root_hash` equals `GenesisManifest.root_hash`.

📌 If any check is missing, later stages may use only transitional non-authoritative bindings and must not label them authenticated.

## 6. Rejection Matrix

📌 The following rejection conditions are mandatory.

| Condition | Required result | Authority claim allowed |
| --- | --- | --- |
| Missing artifact from the required set | Reject the Stage-1 authority set | No |
| Wrong `manifest_hash` between artifacts | Reject the Stage-1 authority set | No |
| Wrong `config_hash` between manifest and assumptions artifact | Reject the Stage-1 authority set | No |
| Wrong `accepted_root_hash` against manifest `root_hash` | Reject the Stage-1 authority set | No |
| Invalid `authority_sig` for the claimed `manifest_hash` | Reject the Stage-1 authority set | No |

## 7. Backlink To Spec 5

📌 This boundary is required by [spec-5.md](spec-5.md), Section `H-6. Stage-1 Authority Integration Boundary`.