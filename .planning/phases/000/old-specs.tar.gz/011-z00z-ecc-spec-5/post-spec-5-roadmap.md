📌 Canonical parent spec: [spec-5.md](spec-5.md).

📌 Canonical full closure contract: [post-spec-5.md](post-spec-5.md).

# Post-Spec-5 Roadmap

📌 This file is the only canonical roadmap for the remaining Stage-3 and Stage-4 work that stays outside the current Spec 5 freeze.

📌 No document in this repository may claim that the four tracks below are complete until this file marks the relevant track closed.

## 1. Scope

📌 The remaining out-of-scope work is limited to exactly four tracks:

1. claim proof;
2. chain authority;
3. spend-proof verifier;
4. fee-proof verifier.

## 2. Track Status

📌 All four tracks are open.

| Track | Current status |
| --- | --- |
| Claim proof | Open |
| Chain authority | Open |
| Spend-proof verifier | Open |
| Fee-proof verifier | Open |

## 3. Claim Proof Track

📌 Current transitional mechanism:

- Stage-3 uses the live typed placeholder claim proof slice in `z00z_crypto::claim`.
- Runtime verification is performed by `ClaimTxVerifierImpl::verify_claim_proof` together with `verify_genesis_claim`.
- Stage-3 still carries transitional `owner_attest_hex` verification through `ClaimTxVerifierImpl::verify_owner_attest` until the final public owner-bind statement is frozen.
- The current typed proof path is fail-closed, but it is not yet the final public claim proof design.

📌 Target mechanism:

- Replace the typed placeholder slice with the final public claim proof design approved for Scenario-1 and later chain integration.
- Retire transitional `owner_attest_hex` acceptance by folding owner-bind semantics into the final public claim proof design or its canonical public statement companion.

📌 Removal condition:

- The typed placeholder claim proof path may be removed only after the final public claim proof verifier is implemented, selected as canonical, and all transitional claim proof branches, including `owner_attest_hex`, are retired from Stage-3 acceptance.

📌 Observable exit criterion:

- Code and tests show that Stage-3 accepts claim packages only through the final public claim proof verifier and no longer through the current typed placeholder proof path or the transitional `owner_attest_hex` acceptance branch.

## 4. Chain Authority Track

📌 Current transitional mechanism:

- Stage-3 still relies on transitional authority handling and must not treat fixed-root or zero-root binding as authenticated authority.
- The current runtime authority check remains the typed authority signature path in `ClaimTxVerifierImpl::verify_claim_authority` and `verify_claim_authority_sig`.

📌 Target mechanism:

- Replace the transitional Stage-3 authority model with authenticated manifest authority derived from the verified Stage-1 artifact set defined in [stage-1-authority-boundary.md](stage-1-authority-boundary.md).

📌 Removal condition:

- Transitional fixed-root binding, zero-root binding, and transitional typed authority acceptance may be removed only after Stage-1 canonical verification exists and Stage-3 consumes only the verified `GenesisAuthority`, `GenesisManifest`, and `Stage1Assumptions` artifact set.

📌 Observable exit criterion:

- Code and tests show that Stage-3 authority acceptance succeeds only when the verified Stage-1 artifact set is present and rejects transitional fixed-root or zero-root authority claims.

## 5. Spend-Proof Verifier Track

📌 Current transitional mechanism:

- Stage-4 remains fail-closed through a mix of public-data algebra checks and witness-bound runtime gates.
- The live path still depends on `verify_self_decrypt`, `verify_spend_witness_gate`, and the current commitment-balance gate.
- This is not yet a third-party public spend proof because acceptance still depends on local witness reconstruction and decryptable bundle state.

📌 Target mechanism:

- Replace the witness-bound final spend gate with a final public spend-proof verifier that does not depend on local witness reconstruction for acceptance.

📌 Removal condition:

- The witness-bound spend gate may be removed only after the public spend-proof verifier covers the final spend acceptance semantics now split across `verify_self_decrypt`, `verify_spend_witness_gate`, and the current public commitment gate.

📌 Observable exit criterion:

- Code and tests show that Stage-4 final spend acceptance succeeds through the public spend-proof verifier without requiring the current witness-bound spend gate.

## 6. Fee-Proof Verifier Track

📌 Current transitional mechanism:

- Stage-4 currently uses deterministic fee formula checks plus local amount-balance checks.
- The live path depends on `verify_fee_matches_formula` and `verify_plaintext_balance_with_fee` rather than on a standalone public fee-proof object.

📌 Target mechanism:

- Replace the current fee formula and local amount-balance acceptance split with a final public fee-proof verifier.

📌 Removal condition:

- The current fee acceptance split may be removed only after the public fee-proof verifier covers the accepted fee semantics and Stage-4 no longer depends on the current transitional fee-only runtime gates for final acceptance.

📌 Observable exit criterion:

- Code and tests show that Stage-4 fee acceptance succeeds through the final public fee-proof verifier and no longer depends on the transitional fee-formula acceptance path.

## 7. Dependency Section

📌 The four tracks do not all depend on Stage-1 completion in the same way.

| Track | Stage-1 dependency | Notes |
| --- | --- | --- |
| Claim proof | Independent | Final public claim proof design may proceed before Stage-1 authority is complete, as long as it does not over-claim authenticated chain authority. |
| Chain authority | Blocked by Stage-1 | Final chain authority replacement depends directly on the verified Stage-1 artifact set and canonical verifier. |
| Spend-proof verifier | Independent | Final public spend-proof work may proceed before Stage-1 authority completion, but it must not claim authenticated chain authority on its own. |
| Fee-proof verifier | Independent | Final public fee-proof work may proceed before Stage-1 authority completion, but it must stay scoped to fee acceptance only. |

## 8. Canonical Link Set

📌 Spec 5 Section `H-7. Stage-3 And Stage-4 Work Outside This Spec` must link here.

📌 Top-level Scenario-1 planning notes that describe frozen Stage-3 or Stage-4 transitional behavior should link here instead of claiming final proof or authority completion.