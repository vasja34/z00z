# Stage-3 Upstream Assumptions

📌 Scope: this file is the single canonical source for Stage-3 assumptions about the sender-output layer used by Spec 5.

📌 Rule: Stage-3 planning, review, and code discussions MUST reference this file for upstream wallet assumptions instead of inferring semantics from tests, helper names, or scattered notes.

📌 Backlink: Spec-5 H-5 is defined in [spec-5.md](spec-5.md).

## Review Rule

🚫 Stage-3 code MUST NOT consume any wallet-side assumption that is not listed in this file.

✅ A review for Stage-3 is incomplete if it accepts new sender-output semantics without adding or updating the matching row in this document first.

## `asset_id` Normative Table

| case | meaning | canonical source | Stage-3 contract | exact risk if inconsistent with `s_out` |
| --- | --- | --- | --- | --- |
| Lightweight path | `asset_id` is caller-supplied public asset namespace bound into `leaf_ad`, `enc_pack`, and sender-side self-validation. It is not derived from `s_out` in this path. | `crates/z00z_wallets/src/core/stealth/output.rs` | Stage-3 MUST treat this value as a declared namespace only when it is intentionally consuming the lightweight sender artifact. | A caller can bind a valid ciphertext and commitment under the wrong asset namespace, so any downstream code that treats lightweight `asset_id` as if it were derived from `s_out` can route value into the wrong asset bucket, wrong JMT key, or wrong policy domain. |
| Full path | `asset_id` is the canonical leaf key derived from `s_out` as `H<AssetIdDomain>(s_out)`. | `crates/z00z_wallets/src/core/tx/builder.rs` | Stage-3 MUST treat full-path `asset_id` as the canonical imported asset key when it consumes `AssetLeaf` or artifacts built from it. | If a consumer silently swaps this meaning with the lightweight meaning, cross-path comparisons can report false mismatches or, worse, accept mismatched state transitions under the wrong asset identity. |
| Cross-path comparison | Lightweight and full-path `asset_id` are not interchangeable today. | This file plus the H-4 cross-path test | Stage-3 MUST document which path produced the artifact before it compares or persists `asset_id`. | If path provenance is dropped, Stage-3 can mistake a path divergence for tampering or mistake real tampering for an expected divergence. |

## `s_out` Normative Table

| aspect | rule | may consume | must never assume | reason |
| --- | --- | --- | --- | --- |
| Derivation | `s_out` is derived by the canonical `derive_s_out` KDF from `k_dh`, `r_pub`, and `serial_id_le`, where `serial_id` is encoded as 4-byte little-endian. | Wallet builder, sender-side validator, decrypt-and-bind logic, full-path `asset_id` derivation | No layer may treat `s_out` as raw RNG output or as entropy independent from `k_dh`, `r_pub`, and `serial_id`. | `s_out` is deterministic KDF output, not standalone randomness. |
| Exposure boundary | `s_out` is plaintext only after successful decrypt of `enc_pack` or during local build before encryption. | Wallet-local validation and canonical full-path leaf construction | Stage-3 MUST NOT assume it can recover `s_out` from public fields alone. | Public fields do not reveal `s_out`; the decrypt path or trusted build context is required. |
| Stage-3 usage | Stage-3 may rely on `s_out` only when it is carried by a canonical wallet artifact or recovered through the canonical decrypt path. | Claim-package and full-path wallet artifacts that explicitly carry or derive it | Stage-3 MUST NOT invent alternative `s_out` derivations or treat it as fungible across different `serial_id` values. | Changing `serial_id` changes `s_out`, which changes every downstream binding that depends on it. |

## `leaf_ad` Normative Table

📌 `leaf_ad` binds exactly five public fields in one fixed preimage of 132 bytes before hashing.

| order | field | bytes | encoding | why it is bound |
| --- | --- | --- | --- | --- |
| 1 | `asset_id` | 32 | raw `[u8; 32]` | Binds the ciphertext to one public asset namespace or canonical leaf key for the producing path. |
| 2 | `serial_id` | 4 | little-endian `u32` | Binds the output to one serial domain and prevents silent serial swapping. |
| 3 | `r_pub` | 32 | raw `[u8; 32]` | Binds the ciphertext to the exact sender ephemeral point used for DH and receiver recovery. |
| 4 | `owner_tag` | 32 | raw `[u8; 32]` | Binds fast ownership filtering to the same encrypted payload and prevents detached retagging. |
| 5 | `c_amount` | 32 | raw commitment bytes | Binds the encrypted plaintext to the visible amount commitment and prevents payload/commitment relinking. |

📌 The canonical preimage order is `asset_id || serial_id_le || r_pub || owner_tag || c_amount`.

🚫 Stage-3 MUST NOT reorder these fields, change the byte encoding, or describe `leaf_ad` with any alternate layout.

## `tag16` Normative Table

| item | rule | allowed use | forbidden use | reason |
| --- | --- | --- | --- | --- |
| Card-bound `tag16` | `compute_tag16(k_dh, leaf_ad)` | Receiver scan prefilter and sender-side consistency checks after the real binding data is known | Ownership proof, anti-spam proof, anti-DoS proof, or authorization proof by itself | It is only a 16-bit hint and collisions are expected. |
| Request-bound `tag16` | `compute_tag16_with_req(k_dh, req_id)` | Request-bound scan hint when the request id is the intended binding mode | Proof that the request is trusted, complete, or chain-valid by itself | It omits the full `leaf_ad` binding and remains only a short hint. |
| Missing or mismatched `tag16` | Reject on validated paths that require a concrete tag value | Fast fail after the real binding context is known | Silent accept because some other field looked plausible | The validated path treats `tag16` as a cheap consistency signal, not as the security root. |

## Cross-Path Invariants

| field | `TxStealthOutput` vs `AssetLeaf` | rule today | reason |
| --- | --- | --- | --- |
| `r_pub` | must align for semantically equivalent outputs | invariant | Both paths bind the same sender ephemeral public key into DH-related semantics. |
| `owner_tag` | must align for semantically equivalent outputs | invariant | Both paths derive ownership filtering from the same `owner_handle` and `k_dh`. |
| `c_amount` | must align for semantically equivalent outputs with the same amount and blinding | invariant | Both paths bind the same commitment bytes into output validation. |
| `asset_id` | may diverge across paths | expected divergence | Lightweight path accepts a caller-supplied namespace; full path derives the canonical leaf key from `s_out`. |
| `enc_pack` | may diverge across paths | expected divergence | The ciphertext is authenticated against path-specific `leaf_ad`, so different `asset_id` semantics produce different ciphertext even for the same plaintext. |
| `tag16` | may diverge across paths | expected divergence | `tag16` follows the path-specific binding source and inherits the `leaf_ad` or request-binding difference. |
| `range_proof` | present only on `AssetLeaf` | expected divergence | The lightweight sender-output header is not the full leaf and does not carry range-proof bytes. |
| `serial_id` | see unresolved boundary below | unresolved | The lightweight path currently fixes a local serial domain while the full path exposes the leaf serial as a public protocol field. |

## Unresolved Serial Split

📌 Current state: the lightweight sender-output path uses a fixed local `serial_id = 0` for `TxStealthOutput` self-validation, while the full-path `AssetLeaf` carries the protocol-facing leaf `serial_id` as a public field.

⚠️ This split is not resolved by Spec 5 H-5. It is recorded here so Stage-3 does not silently treat these two serial domains as interchangeable.

✅ Acceptance rule for the current runtime: Stage-3 MUST consume serial semantics only from canonical `AssetLeaf`, `AssetWire`, or claim-package artifacts. If Stage-3 touches a lightweight `TxStealthOutput`, it MUST treat the lightweight serial as a local sender-validation input only, not as the public imported asset serial.

🚫 Any Stage-3 code that maps lightweight `serial_id = 0` directly into claim, import, JMT, or persistence semantics fails H-5 review until this boundary is explicitly resolved in one canonical document.
