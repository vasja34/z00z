# Stage-4 Trust Boundary

📌 This note records the current temporary Stage-4 acceptance contract.

📌 Remaining proof and authority work outside the current Spec-5 freeze is tracked only in the canonical `post-spec-5.md` closure spec in this folder.

📌 Stage-4 is operationally fail-closed today, but final acceptance is still split between public-data algebra checks and witness-bound runtime checks. This note freezes that boundary until a later public spend-proof design is approved.

## Current Boundary

| boundary | owner module | current guard | fail-closed status | locked test | notes |
| --- | --- | --- | --- | --- | --- |
| Stage-4 requires a prior Stage-3 claim artifact | z00z_simulator::scenario_1::stage_4 | load_claim_pkgs | yes | test_stage4_claim_gate::stage4_temp_claim_gate_ok | Temporary contract: Stage-4 accepts only a claim bundle that already passed the Stage-3 claim verifier path. |
| malformed or missing claim artifact blocks Stage-4 | z00z_simulator::scenario_1::stage_4 | load_claim_pkgs | yes | test_stage4_claim_gate::stage4_rejects_missing_claim_pkg and test_stage4_claim_gate::stage4_rejects_bad_claim_pkg | No Stage-4 state files are written when the claim prerequisite is absent or malformed. |
| semantic claim-proof failure blocks Stage-4 | z00z_simulator::scenario_1::stage_4 | load_claim_pkgs and ClaimTxVerifierImpl::verify | yes | test_stage4_claim_gate::stage4_bad_pkg_fails | Stage-4 trusts Stage-3 claim gating and reuses the wallet-layer claim verifier before continuing. |
| output confidentiality and opening checks need local bundle witness data | z00z_wallets::core::tx::output_flow | verify_self_decrypt | yes | test_stage4_output_crypto::stage4_output_crypto_ok | This is not yet a third-party public proof because the verifier uses local OutputBundle state. |
| final spend acceptance still needs witness reconstruction | z00z_wallets::core::tx::witness_gate | verify_spend_witness_gate | yes | test_stage4_tamper::stage4_rejects_bad_witness | The current final spend gate is still witness-bound and must be treated as temporary until a public spend proof replaces it. |
| commitment balance gate is narrower than final public spend semantics | z00z_wallets::core::tx::output_flow | verify_commitment_balance_gate | yes | test_stage4_gates::stage4_commit_gate_ok | Public commitment balance is checked today as a public-data algebra gate, but it does not replace the witness-bound spend gate and is not itself a standalone proof object. |

## Temporary Lock Tests

📌 The current temporary contract is locked by fail-closed tests and must stay explicit until a public proof migration lands.

- `test_stage4_claim_gate::stage4_temp_claim_gate_ok`
- `test_stage4_claim_gate::stage4_rejects_missing_claim_pkg`
- `test_stage4_claim_gate::stage4_rejects_bad_claim_pkg`
- `test_stage4_claim_gate::stage4_bad_pkg_fails`
- `test_stage4_tamper::stage4_rejects_bad_witness`
