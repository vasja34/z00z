# Stage-3 Frozen Model

📌 This note freezes only the Stage-3 next slice for Scenario-1.

📌 This file is the only Stage-3 frozen-model note referenced by later implementation steps.

📌 Remaining proof and authority work outside the current Spec-5 freeze is tracked only in the canonical `post-spec-5.md` closure spec in this folder.

📌 Upstream wallet assumptions for Stage-3 portable outputs are canonical only in [../../../../../specs/011-z00z-ecc-spec-5/stage-3-assumptions.md](../../../../../specs/011-z00z-ecc-spec-5/stage-3-assumptions.md). This file may freeze planning choices, but it must not define new wallet-side assumptions.

| concept | current owner module | frozen for this slice | notes |
| --- | --- | --- | --- |
| ClaimTxPackage.version = 1 | z00z_simulator::scenario_1::stage_3 | yes | Package version stays 1 for the approved Stage-3 slice; no version migration starts here. |
| ClaimOutputWire.asset_wire is mandatory | z00z_wallets::core::tx::claim_tx | yes | Portable output carriage stays mandatory; no alternate carrier field is approved in this slice. |
| recipient_card_hex is mandatory | z00z_wallets::core::tx::claim_tx | yes | Recipient card stays required for package validation; no optional-card branch is approved in this slice. |
| owner_attest_hex remains transitional | z00z_wallets::core::tx::claim_tx | transitional | owner_attest_hex stays until owner-bind public statement is frozen; this slice does not define the final public owner-bind model. |
| asset_id remains the live JMT key | z00z_core::assets | yes | asset_id stays the live JMT key; no asset-key remapping or alternate key identity is approved in this slice. |
| claim nullifier remains anti-replay material only | z00z_wallets::core::claim::nullifier_store | yes | Claim nullifier stays anti-replay material only; this slice does not redefine it as a spend nullifier. |

## Out Of Freeze Scope

📌 The following areas are explicitly excluded from this frozen Stage-3 note.

- Stage-1 manifest authority design is excluded.
- Stage-2 registry-root publication design is excluded.
- Stage-4 spend and fee proof objects are excluded.
