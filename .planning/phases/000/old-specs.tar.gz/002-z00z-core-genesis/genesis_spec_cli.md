# Genesis CLI Tools Specification v1.0

**Version**: 1.0  
**Date**: 2025-12-09  
**Status**: Implementation Ready  
**Module**: `z00z_core/bin/genesis/`

---

## 📋 Overview

This specification defines two CLI tools for analyzing and extracting genesis assets from the output of `assets_generator_cli`:

1. **`assets_analyzer_cli`** - Analyzes genesis output files and provides detailed metadata
2. **`assets_extractor_cli`** - Extracts specific assets from genesis files

Both tools work with the output directory structure created by `assets_generator_cli`:

```
crates/z00z_core/outputs/genesis/
└── genesis_<network>_<timestamp>/
    ├── genesis_Z00Z.bin
    ├── genesis_Z00Z.json
    ├── genesis_zUSD.bin
    ├── genesis_zUSD.json
    ├── genesis_zNFT.bin
    ├── genesis_zNFT.json
    ├── genesis_zBurnSink.bin
    ├── genesis_zBurnSink.json
    └── genesis_snapshot_<network>_<timestamp>.zip
```

---

## 🔍 Tool 1: Genesis Assets Analyzer CLI

### Purpose

Analyze genesis output files (`.bin` and `.json`) and provide comprehensive metadata about their contents, including:
- Asset counts by class
- Total supply calculations
- Cryptographic verification summary
- File size statistics
- Performance metrics
- Integrity checks

### Usage

```bash
# Analyze entire genesis directory
cargo run --bin assets_analyzer_cli -- \
  --input crates/z00z_core/outputs/genesis/genesis_devnet_20251208_203739

# Analyze specific asset class
cargo run --bin assets_analyzer_cli -- \
  --input crates/z00z_core/outputs/genesis/genesis_devnet_20251208_203739 \
  --class coin

# Verbose output with detailed statistics
cargo run --bin assets_analyzer_cli -- \
  --input crates/z00z_core/outputs/genesis/genesis_devnet_20251208_203739 \
  --verbose

# JSON output format
cargo run --bin assets_analyzer_cli -- \
  --input crates/z00z_core/outputs/genesis/genesis_devnet_20251208_203739 \
  --format json

# Verify cryptographic integrity
cargo run --bin assets_analyzer_cli -- \
  --input crates/z00z_core/outputs/genesis/genesis_devnet_20251208_203739 \
  --verify
```

### Command-Line Arguments

| Argument | Type | Required | Default | Description |
|----------|------|----------|---------|-------------|
| `--input <DIR>` | String | Yes | - | Path to genesis output directory |
| `--class <CLASS>` | String | No | all | Filter by asset class: `coin`, `token`, `nft`, `void` |
| `--format <FMT>` | String | No | `table` | Output format: `table`, `json`, `yaml` |
| `--verbose` | Flag | No | false | Show detailed statistics |
| `--verify` | Flag | No | false | Verify cryptographic integrity (slow) |
| `--help, -h` | Flag | No | - | Show help message |

### Output Format

#### Table Format (Default)

```
🔍 === GENESIS ASSETS ANALYSIS ===

📂 Directory: crates/z00z_core/outputs/genesis/genesis_devnet_20251208_203739
🌐 Network: devnet
📅 Timestamp: 2025-12-08 20:37:39

📊 Asset Summary
┌────────────┬─────────┬──────────────┬────────────────┬──────────────┐
│ Class      │ Count   │ Total Supply │ Nominal Value  │ File Size    │
├────────────┼─────────┼──────────────┼────────────────┼──────────────┤
│ Coin       │     100 │   2,000,000  │        20,000  │   1.2 MB     │
│ Token      │     100 │  10,000,000  │       100,000  │   1.2 MB     │
│ NFT        │   1,000 │       1,000  │             1  │  11.8 MB     │
│ Void       │   1,000 │           0  │             0  │  11.8 MB     │
├────────────┼─────────┼──────────────┼────────────────┼──────────────┤
│ TOTAL      │   2,200 │  12,001,000  │             -  │  26.0 MB     │
└────────────┴─────────┴──────────────┴────────────────┴──────────────┘

📦 File Statistics
┌──────────────────────────┬────────────┬──────────┬──────────┐
│ File                     │ Format     │ Assets   │ Size     │
├──────────────────────────┼────────────┼──────────┼──────────┤
│ genesis_Z00Z.bin         │ Bincode    │      100 │  670 KB  │
│ genesis_Z00Z.json        │ JSON       │      100 │  580 KB  │
│ genesis_zUSD.bin         │ Bincode    │      100 │  670 KB  │
│ genesis_zUSD.json        │ JSON       │      100 │  580 KB  │
│ genesis_zNFT.bin         │ Bincode    │    1,000 │  6.5 MB  │
│ genesis_zNFT.json        │ JSON       │    1,000 │  5.3 MB  │
│ genesis_zBurnSink.bin    │ Bincode    │    1,000 │  6.5 MB  │
│ genesis_zBurnSink.json   │ JSON       │    1,000 │  5.3 MB  │
│ genesis_snapshot_*.zip   │ Archive    │    2,200 │  4.2 MB  │
└──────────────────────────┴────────────┴──────────┴──────────┘

🔐 Cryptographic Summary
┌─────────────────────────┬──────────┬──────────┐
│ Component               │ Present  │ Verified │
├─────────────────────────┼──────────┼──────────┤
│ Commitments             │  2,200   │    ✓     │
│ Range Proofs            │  2,200   │    ✓     │
│ Signatures              │  2,200   │    ✓     │
│ Nonces (unique)         │  2,200   │    ✓     │
└─────────────────────────┴──────────┴──────────┘

⚡ Performance Metrics
  Generation time:     1.2s
  Throughput:          1,833 assets/sec
  Proof size avg:      672 bytes
  Compression ratio:   6.2:1 (26MB → 4.2MB)

✅ Analysis complete!
```

#### JSON Format

```json
{
  "directory": "crates/z00z_core/outputs/genesis/genesis_devnet_20251208_203739",
  "network": "devnet",
  "timestamp": "2025-12-08T20:37:39Z",
  "summary": {
    "total_assets": 2200,
    "total_supply": 12001000,
    "asset_classes": {
      "coin": {
        "count": 100,
        "total_supply": 2000000,
        "nominal_value": 20000,
        "file_size_bytes": 1258291,
        "symbols": ["Z00Z"]
      },
      "token": {
        "count": 100,
        "total_supply": 10000000,
        "nominal_value": 100000,
        "file_size_bytes": 1258291,
        "symbols": ["zUSD"]
      },
      "nft": {
        "count": 1000,
        "total_supply": 1000,
        "nominal_value": 1,
        "file_size_bytes": 12372910,
        "symbols": ["zNFT"]
      },
      "void": {
        "count": 1000,
        "total_supply": 0,
        "nominal_value": 0,
        "file_size_bytes": 12372910,
        "symbols": ["zBurnSink"]
      }
    }
  },
  "files": [
    {
      "name": "genesis_Z00Z.bin",
      "format": "bincode",
      "asset_count": 100,
      "size_bytes": 686080,
      "compression_ratio": null
    },
    {
      "name": "genesis_Z00Z.json",
      "format": "json",
      "asset_count": 100,
      "size_bytes": 593421,
      "compression_ratio": null
    }
  ],
  "cryptography": {
    "commitments": {
      "count": 2200,
      "all_present": true,
      "verified": true
    },
    "range_proofs": {
      "count": 2200,
      "all_present": true,
      "verified": true,
      "avg_size_bytes": 672
    },
    "signatures": {
      "count": 2200,
      "all_present": true,
      "verified": true
    },
    "nonces": {
      "count": 2200,
      "all_unique": true,
      "duplicates": 0
    }
  },
  "performance": {
    "generation_time_secs": 1.2,
    "throughput_assets_per_sec": 1833,
    "compression_ratio": 6.2
  }
}
```

### Implementation Details

#### File: `crates/z00z_core/bin/genesis/assets_analyzer_cli.rs`

```rust
//! # Genesis Assets Analyzer CLI
//!
//! Analyzes genesis output files and provides comprehensive metadata.
//!
//! ## Usage
//!
//! ```bash
//! # Analyze entire genesis directory
//! cargo run --bin assets_analyzer_cli -- --input <DIR>
//!
//! # Filter by asset class
//! cargo run --bin assets_analyzer_cli -- --input <DIR> --class coin
//!
//! # JSON output
//! cargo run --bin assets_analyzer_cli -- --input <DIR> --format json
//!
//! # Verify cryptography (slow)
//! cargo run --bin assets_analyzer_cli -- --input <DIR> --verify
//! ```

use z00z_core::assets::Asset;
use z00z_utils::prelude::*;
use std::collections::{HashMap, HashSet};
use std::path::{Path, PathBuf};
use std::fs;
use serde::{Serialize, Deserialize};

/// CLI configuration
#[derive(Debug, Clone)]
struct AnalyzerConfig {
    input_dir: PathBuf,
    filter_class: Option<AssetClass>,
    output_format: OutputFormat,
    verbose: bool,
    verify_crypto: bool,
}

/// Output format options
#[derive(Debug, Clone, Copy)]
enum OutputFormat {
    Table,
    Json,
    Yaml,
}

/// Analysis results
#[derive(Debug, Serialize, Deserialize)]
struct AnalysisReport {
    directory: String,
    network: String,
    timestamp: String,
    summary: AssetSummary,
    files: Vec<FileInfo>,
    cryptography: CryptoSummary,
    performance: PerformanceMetrics,
}

#[derive(Debug, Serialize, Deserialize)]
struct AssetSummary {
    total_assets: usize,
    total_supply: u64,
    asset_classes: HashMap<String, ClassInfo>,
}

#[derive(Debug, Serialize, Deserialize)]
struct ClassInfo {
    count: usize,
    total_supply: u64,
    nominal_value: u64,
    file_size_bytes: u64,
    symbols: Vec<String>,
}

#[derive(Debug, Serialize, Deserialize)]
struct FileInfo {
    name: String,
    format: String,
    asset_count: usize,
    size_bytes: u64,
    compression_ratio: Option<f64>,
}

#[derive(Debug, Serialize, Deserialize)]
struct CryptoSummary {
    commitments: ComponentInfo,
    range_proofs: ProofInfo,
    signatures: ComponentInfo,
    nonces: NonceInfo,
}

#[derive(Debug, Serialize, Deserialize)]
struct ComponentInfo {
    count: usize,
    all_present: bool,
    verified: bool,
}

#[derive(Debug, Serialize, Deserialize)]
struct ProofInfo {
    count: usize,
    all_present: bool,
    verified: bool,
    avg_size_bytes: usize,
}

#[derive(Debug, Serialize, Deserialize)]
struct NonceInfo {
    count: usize,
    all_unique: bool,
    duplicates: usize,
}

#[derive(Debug, Serialize, Deserialize)]
struct PerformanceMetrics {
    generation_time_secs: f64,
    throughput_assets_per_sec: f64,
    compression_ratio: f64,
}

fn main() -> Result<(), Box<dyn std::error::Error>> {
    let config = parse_args();
    
    println!("🔍 Analyzing genesis output...\n");
    
    let report = analyze_genesis(&config)?;
    
    match config.output_format {
        OutputFormat::Table => print_table_report(&report),
        OutputFormat::Json => print_json_report(&report)?,
        OutputFormat::Yaml => print_yaml_report(&report)?,
    }
    
    println!("\n✅ Analysis complete!");
    
    Ok(())
}
```

#### Key Functions

1. **`analyze_genesis()`** - Main analysis orchestrator
2. **`scan_directory()`** - Scan for genesis files
3. **`load_assets()`** - Load assets from bin/json files
4. **`compute_statistics()`** - Calculate asset statistics
5. **`verify_cryptography()`** - Optional crypto verification
6. **`detect_network()`** - Extract network from directory name
7. **`format_table()`** - Format as ASCII table
8. **`format_json()`** - Format as JSON
9. **`format_yaml()`** - Format as YAML

---

## 📤 Tool 2: Genesis Assets Extractor CLI

### Purpose

Extract specific assets from genesis files based on various criteria:
- Asset class (coin, token, nft, void)
- Serial ID range
- Amount range
- Specific asset definition ID
- Output to new files (JSON, Bincode, CSV)

### Usage

```bash
# Extract all coins
cargo run --bin assets_extractor_cli -- \
  --input crates/z00z_core/outputs/genesis/genesis_devnet_20251208_203739 \
  --class coin \
  --output extracted_coins.json

# Extract specific serial range
cargo run --bin assets_extractor_cli -- \
  --input crates/z00z_core/outputs/genesis/genesis_devnet_20251208_203739 \
  --class nft \
  --serial-range 0-99 \
  --output first_100_nfts.json

# Extract by amount range
cargo run --bin assets_extractor_cli -- \
  --input crates/z00z_core/outputs/genesis/genesis_devnet_20251208_203739 \
  --class token \
  --amount-range 50000-150000 \
  --output filtered_tokens.bin

# Extract specific asset definition
cargo run --bin assets_extractor_cli -- \
  --input crates/z00z_core/outputs/genesis/genesis_devnet_20251208_203739 \
  --definition-id z00z \
  --output z00z_assets.json

# Extract to CSV (metadata only)
cargo run --bin assets_extractor_cli -- \
  --input crates/z00z_core/outputs/genesis/genesis_devnet_20251208_203739 \
  --class all \
  --output genesis_summary.csv \
  --format csv

# Extract with filters combined
cargo run --bin assets_extractor_cli -- \
  --input crates/z00z_core/outputs/genesis/genesis_devnet_20251208_203739 \
  --class coin \
  --serial-range 10-20 \
  --amount-min 15000 \
  --output selected_coins.json \
  --verbose
```

### Command-Line Arguments

| Argument | Type | Required | Default | Description |
|----------|------|----------|---------|-------------|
| `--input <DIR>` | String | Yes | - | Path to genesis output directory |
| `--output <FILE>` | String | Yes | - | Output file path |
| `--class <CLASS>` | String | No | all | Asset class: `coin`, `token`, `nft`, `void`, `all` |
| `--serial-range <RANGE>` | String | No | - | Serial ID range (e.g., `0-99`, `100-200`) |
| `--amount-range <RANGE>` | String | No | - | Amount range (e.g., `1000-5000`) |
| `--amount-min <VALUE>` | u64 | No | 0 | Minimum amount (inclusive) |
| `--amount-max <VALUE>` | u64 | No | MAX | Maximum amount (inclusive) |
| `--definition-id <ID>` | String | No | - | Filter by asset definition ID/symbol |
| `--format <FMT>` | String | No | `json` | Output format: `json`, `bincode`, `csv` |
| `--include-proofs` | Flag | No | true | Include range proofs (disable for CSV) |
| `--verbose` | Flag | No | false | Show detailed extraction progress |
| `--help, -h` | Flag | No | - | Show help message |

### Output Formats

#### JSON Format

```json
{
  "source": "genesis_devnet_20251208_203739",
  "extracted_at": "2025-12-09T06:15:30Z",
  "filters": {
    "class": "coin",
    "serial_range": "0-99"
  },
  "assets": [
    {
      "definition": {
        "id": "010203...",
        "class": "Coin",
        "symbol": "Z00Z",
        "name": "Z00Z Native Coin",
        "decimals": 8,
        "serials": 100,
        "nominal": 20000
      },
      "serial_id": 0,
      "amount": 20000,
      "commitment": "abc123...",
      "range_proof": "def456...",
      "nonce": "789abc...",
      "owner_pub": "fedcba...",
      "owner_signature": "098765..."
    }
  ],
  "summary": {
    "total_extracted": 100,
    "total_amount": 2000000,
    "output_size_bytes": 686080
  }
}
```

#### Bincode Format

Binary serialization of `Vec<Asset>` - same format as genesis output files.

#### CSV Format (Metadata Only)

```csv
symbol,class,serial_id,amount,commitment_hex,nonce_hex,has_proof,has_signature
Z00Z,Coin,0,20000,abc123...,789abc...,true,true
Z00Z,Coin,1,20000,abc124...,789abd...,true,true
Z00Z,Coin,2,20000,abc125...,789abe...,true,true
```

### Output Example

```
📤 === GENESIS ASSETS EXTRACTOR ===

📂 Source: crates/z00z_core/outputs/genesis/genesis_devnet_20251208_203739
🎯 Filters:
   - Class: coin
   - Serial range: 0-99
   - Amount min: 15000

🔍 Scanning genesis files...
   ✓ Found genesis_Z00Z.bin (100 assets)
   ✓ Found genesis_zUSD.bin (100 assets)
   ✓ Found genesis_zNFT.bin (1000 assets)
   ✓ Found genesis_zBurnSink.bin (1000 assets)

⚙️  Applying filters...
   ✓ Class filter: 100 matches
   ✓ Serial range: 100 matches
   ✓ Amount filter: 100 matches

📊 Extraction Summary:
   - Total scanned: 2200 assets
   - Matched filters: 100 assets
   - Total amount: 2,000,000
   - Output size: 686 KB

💾 Writing to: extracted_coins.json
   Format: JSON
   Include proofs: Yes

✅ Extraction complete!
   Extracted: 100 assets
   Output: extracted_coins.json (686 KB)
```

### Implementation Details

#### File: `crates/z00z_core/bin/genesis/assets_extractor_cli.rs`

```rust
//! # Genesis Assets Extractor CLI
//!
//! Extracts specific assets from genesis output files based on filters.
//!
//! ## Usage
//!
//! ```bash
//! # Extract all coins
//! cargo run --bin assets_extractor_cli -- \
//!   --input <DIR> --class coin --output coins.json
//!
//! # Extract serial range
//! cargo run --bin assets_extractor_cli -- \
//!   --input <DIR> --serial-range 0-99 --output first_100.bin
//!
//! # Extract with amount filter
//! cargo run --bin assets_extractor_cli -- \
//!   --input <DIR> --amount-min 10000 --output high_value.json
//! ```

use z00z_core::assets::{Asset, AssetClass};
use z00z_utils::prelude::*;
use std::path::{Path, PathBuf};
use std::ops::RangeInclusive;
use serde::{Serialize, Deserialize};

/// CLI configuration
#[derive(Debug, Clone)]
struct ExtractorConfig {
    input_dir: PathBuf,
    output_file: PathBuf,
    filters: AssetFilters,
    output_format: OutputFormat,
    include_proofs: bool,
    verbose: bool,
}

/// Asset filtering criteria
#[derive(Debug, Clone, Default)]
struct AssetFilters {
    class: Option<AssetClass>,
    serial_range: Option<RangeInclusive<u32>>,
    amount_range: Option<RangeInclusive<u64>>,
    definition_id: Option<String>,
}

/// Output format options
#[derive(Debug, Clone, Copy)]
enum OutputFormat {
    Json,
    Bincode,
    Csv,
}

/// Extraction result
#[derive(Debug, Serialize, Deserialize)]
struct ExtractionResult {
    source: String,
    extracted_at: String,
    filters: FilterSummary,
    assets: Vec<Asset>,
    summary: ExtractionSummary,
}

#[derive(Debug, Serialize, Deserialize)]
struct FilterSummary {
    class: Option<String>,
    serial_range: Option<String>,
    amount_range: Option<String>,
    definition_id: Option<String>,
}

#[derive(Debug, Serialize, Deserialize)]
struct ExtractionSummary {
    total_extracted: usize,
    total_amount: u64,
    output_size_bytes: u64,
}

fn main() -> Result<(), Box<dyn std::error::Error>> {
    let config = parse_args();
    
    println!("📤 === GENESIS ASSETS EXTRACTOR ===\n");
    
    if config.verbose {
        println!("📂 Source: {}", config.input_dir.display());
        print_filters(&config.filters);
    }
    
    let assets = extract_assets(&config)?;
    
    save_extracted(&assets, &config)?;
    
    println!("\n✅ Extraction complete!");
    println!("   Extracted: {} assets", assets.len());
    println!("   Output: {} ({} KB)", 
        config.output_file.display(),
        std::fs::metadata(&config.output_file)?.len() / 1024
    );
    
    Ok(())
}
```

#### Key Functions

1. **`extract_assets()`** - Main extraction orchestrator
2. **`load_genesis_files()`** - Load all genesis files
3. **`apply_filters()`** - Apply filtering criteria
4. **`filter_by_class()`** - Filter by asset class
5. **`filter_by_serial()`** - Filter by serial ID range
6. **`filter_by_amount()`** - Filter by amount range
7. **`filter_by_definition()`** - Filter by definition ID
8. **`save_json()`** - Save as JSON
9. **`save_bincode()`** - Save as Bincode
10. **`save_csv()`** - Save as CSV metadata

---

## 🛠️ Implementation Checklist

### Phase 1: Assets Analyzer CLI

- [ ] **Task 1.1**: Create `assets_analyzer_cli.rs` skeleton
- [ ] **Task 1.2**: Implement argument parsing
- [ ] **Task 1.3**: Implement directory scanning
- [ ] **Task 1.4**: Implement asset loading (bincode + json)
- [ ] **Task 1.5**: Implement statistics calculation
- [ ] **Task 1.6**: Implement table output format
- [ ] **Task 1.7**: Implement JSON output format
- [ ] **Task 1.8**: Implement YAML output format
- [ ] **Task 1.9**: Implement crypto verification (optional)
- [ ] **Task 1.10**: Add comprehensive error handling
- [ ] **Task 1.11**: Write integration tests
- [ ] **Task 1.12**: Update documentation

### Phase 2: Assets Extractor CLI

- [ ] **Task 2.1**: Create `assets_extractor_cli.rs` skeleton
- [ ] **Task 2.2**: Implement argument parsing with filters
- [ ] **Task 2.3**: Implement asset loading
- [ ] **Task 2.4**: Implement filter application
- [ ] **Task 2.5**: Implement JSON export
- [ ] **Task 2.6**: Implement Bincode export
- [ ] **Task 2.7**: Implement CSV export
- [ ] **Task 2.8**: Add filter validation
- [ ] **Task 2.9**: Add comprehensive error handling
- [ ] **Task 2.10**: Write integration tests
- [ ] **Task 2.11**: Update documentation

### Phase 3: Testing & Documentation

- [ ] **Task 3.1**: Create test genesis outputs
- [ ] **Task 3.2**: Test analyzer with various filters
- [ ] **Task 3.3**: Test extractor with various filters
- [ ] **Task 3.4**: Test error cases
- [ ] **Task 3.5**: Add CLI examples to README
- [ ] **Task 3.6**: Update genesis workflow documentation

---

## 📊 Error Handling

### Analyzer Errors

| Error | Description | Exit Code |
|-------|-------------|-----------|
| `DirectoryNotFound` | Input directory doesn't exist | 1 |
| `NoGenesisFiles` | No genesis files found in directory | 2 |
| `InvalidFormat` | File format corrupted or invalid | 3 |
| `DeserializationFailed` | Failed to deserialize assets | 4 |
| `VerificationFailed` | Crypto verification failed | 5 |

### Extractor Errors

| Error | Description | Exit Code |
|-------|-------------|-----------|
| `InvalidFilter` | Invalid filter specification | 1 |
| `NoMatchingAssets` | No assets match filters | 2 |
| `OutputPathInvalid` | Output path not writable | 3 |
| `SerializationFailed` | Failed to serialize extracted assets | 4 |

---

## 🧪 Testing Strategy

### Unit Tests

```rust
#[cfg(test)]
mod tests {
    use super::*;
    
    #[test]
    fn test_parse_serial_range() {
        let range = parse_range("0-99").unwrap();
        assert_eq!(*range.start(), 0);
        assert_eq!(*range.end(), 99);
    }
    
    #[test]
    fn test_filter_by_class() {
        let assets = create_test_assets();
        let filtered = filter_by_class(&assets, AssetClass::Coin);
        assert_eq!(filtered.len(), 100);
    }
    
    #[test]
    fn test_amount_range_filter() {
        let assets = create_test_assets();
        let filtered = filter_by_amount(&assets, 15000..=25000);
        assert!(filtered.iter().all(|a| a.amount >= 15000 && a.amount <= 25000));
    }
}
```

### Integration Tests

```rust
#[test]
fn test_analyzer_cli_full_analysis() {
    let output = Command::new("cargo")
        .args(&["run", "--bin", "assets_analyzer_cli", "--",
                "--input", "test_genesis",
                "--format", "json"])
        .output()
        .expect("failed to execute");
    
    assert!(output.status.success());
    
    let report: AnalysisReport = serde_json::from_slice(&output.stdout)?;
    assert_eq!(report.summary.total_assets, 2200);
}

#[test]
fn test_extractor_cli_class_filter() {
    let output = Command::new("cargo")
        .args(&["run", "--bin", "assets_extractor_cli", "--",
                "--input", "test_genesis",
                "--class", "coin",
                "--output", "/tmp/coins.json"])
        .output()
        .expect("failed to execute");
    
    assert!(output.status.success());
    
    let extracted: Vec<Asset> = load_json("/tmp/coins.json")?;
    assert_eq!(extracted.len(), 100);
    assert!(extracted.iter().all(|a| matches!(a.class(), AssetClass::Coin)));
}
```

---

## 📚 Usage Examples

### Example 1: Analyze Genesis for Devnet

```bash
# Generate genesis
cargo run --release --bin assets_generator_cli -- \
  --config crates/z00z_core/src/genesis/genesis_config_devnet.yaml \
  --verbose

# Analyze output
cargo run --bin assets_analyzer_cli -- \
  --input crates/z00z_core/outputs/genesis/genesis_devnet_20251209_061115 \
  --verbose

# Verify cryptography (slow but thorough)
cargo run --bin assets_analyzer_cli -- \
  --input crates/z00z_core/outputs/genesis/genesis_devnet_20251209_061115 \
  --verify
```

### Example 2: Extract Treasury Coins

```bash
# Extract first 10 coins for treasury testing
cargo run --bin assets_extractor_cli -- \
  --input crates/z00z_core/outputs/genesis/genesis_devnet_20251209_061115 \
  --class coin \
  --serial-range 0-9 \
  --output treasury_test_coins.json \
  --verbose
```

### Example 3: Create CSV Report

```bash
# Generate CSV summary of all assets
cargo run --bin assets_extractor_cli -- \
  --input crates/z00z_core/outputs/genesis/genesis_devnet_20251209_061115 \
  --class all \
  --output genesis_summary.csv \
  --format csv
```

### Example 4: Filter High-Value NFTs

```bash
# Extract NFTs with value > 0 (if any special NFTs exist)
cargo run --bin assets_extractor_cli -- \
  --input crates/z00z_core/outputs/genesis/genesis_devnet_20251209_061115 \
  --class nft \
  --amount-min 1 \
  --output special_nfts.json
```

---

## 🔐 Security Considerations

1. **Path Traversal**: Validate input/output paths to prevent directory traversal attacks
2. **Memory Limits**: Large genesis files could exhaust memory - implement streaming for large datasets
3. **Cryptographic Verification**: Optional `--verify` flag should use batch verification for performance
4. **File Permissions**: Check write permissions before attempting to save extracted assets
5. **Input Validation**: Validate all filter ranges to prevent panics (e.g., start <= end)

---

## 📦 Dependencies

### Cargo.toml Additions

```toml
[[bin]]
name = "assets_analyzer_cli"
path = "bin/genesis/assets_analyzer_cli.rs"

[[bin]]
name = "assets_extractor_cli"
path = "bin/genesis/assets_extractor_cli.rs"

[dependencies]
z00z_core = { path = ".", features = ["genesis"] }
z00z_utils = { path = "../z00z_utils" }
z00z_crypto = { path = "../z00z_crypto" }
serde = { version = "1.0", features = ["derive"] }
serde_json = "1.0"
serde_yaml = "0.9"
csv = "1.3"
prettytable-rs = "0.10"  # For ASCII table formatting
indicatif = "0.17"       # For progress bars
colored = "2.1"          # For colored terminal output
```

---

## 🎯 Success Criteria

### Analyzer CLI

✅ Successfully analyzes genesis directories with 100+ assets  
✅ Provides accurate statistics (counts, supply, file sizes)  
✅ Supports multiple output formats (table, JSON, YAML)  
✅ Optionally verifies cryptographic integrity  
✅ Handles errors gracefully with helpful messages  
✅ Performance: <1s analysis for 10k assets  

### Extractor CLI

✅ Successfully extracts assets with various filter combinations  
✅ Supports all output formats (JSON, Bincode, CSV)  
✅ Validates filter ranges and parameters  
✅ Provides clear progress indication for large extractions  
✅ Handles errors gracefully with helpful messages  
✅ Performance: <2s extraction for 10k assets with filters  

---

## 📝 Notes

1. **Streaming Support**: For very large genesis files (>1M assets), consider implementing streaming parsers
2. **Parallel Processing**: Use rayon for parallel filtering/verification in analyzer
3. **Interactive Mode**: Future enhancement - interactive TUI for exploring genesis data
4. **Diff Tool**: Future enhancement - compare two genesis outputs for differences
5. **Merkle Tree**: Future enhancement - compute and verify Merkle tree of assets

---

**End of Specification**
