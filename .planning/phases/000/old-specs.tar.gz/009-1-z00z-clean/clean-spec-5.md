# 🧭 clean-spec-5 — Final Type Consolidation Decision (Based on Current Code)

🧾 **Status:** proposal-only (documentation). No code changes in this step.

🎯 **Goal:** provide an unambiguous decision for Z00Z asset-related types:
- which structs must remain independent,
- which should be removed,
- which should be modified,
based on the current repository state.

🏗️ **Model assumed (as requested):**
- “Assets” are off-chain wallet objects.
- JMT stores an on-chain **encrypted/public mirror leaf** (UTXO set).
- Spending deletes old leaves and inserts new leaves.

---

## 📦 1) Current code inventory: structs containing target fields

🎯 Target field set: `asset_id`, `r_pub`, `owner_tag`, `enc_pack`, `tag16`.

🔎 Repo-wide scan of `crates/**/*.rs` (struct fields) shows these are the only structs with ≥2 target fields:

**(5 fields)**
- `GenesisAssetExportEntry` — `asset_id, r_pub, owner_tag, enc_pack, tag16` (export DTO)
- `UtxoLeaf` — `asset_id, r_pub, owner_tag, enc_pack, tag16` (wallet leaf/test leaf)

**(4 fields)**
- `Asset` — `r_pub, owner_tag, enc_pack, tag16` (core domain object; no `asset_id` field, but has `asset_id()` method)
- `AssetWire` — `r_pub, owner_tag, enc_pack, tag16` (wire DTO)
- `TxStealthOutput` — `r_pub, owner_tag, enc_pack, tag16` (sender header)

**(3 fields)**
- `WalletStealthOutput` — `asset_id, r_pub, owner_tag` (wallet post-decrypt record)
- `ForgedOut` — `r_pub, owner_tag, enc_pack` (example-only attack scaffolding)

🧩 Notable extra: `z00z_wallets/src/core/asset/asset_leaf.rs` defines `AssetLeaf` with **only** `r_pub` from the target set and is **not used elsewhere** (only defined + re-exported). This name collides with spec terminology and increases confusion.

---

## ⚠️ 2) Critical inconsistency: what `asset_id` means today

⚠️ The term `asset_id` is **not consistent** between spec expectations and current code.

🧮 In `z00z_core::assets::Asset`, `asset_id()` is computed as a deterministic hash over:
- `nonce`, `commitment`, `definition.id`, `serial_id`.

📌 This is an **output identifier** derived from (mostly) public/committed state.

🔒 In the stealth pipeline in `z00z_wallets`, the encrypted pack plaintext currently includes `amount` and an `asset_id` value passed in by the sender.

📚 Spec-4 treats `asset_id` as the canonical public JMT key for asset leaves; `secret_tag` is a separate ownership-side concept, not a second JMT key.

✅ **Conclusion:** today there are two competing semantics:
- **OutputId-like** (core code): `asset_id = H(nonce, commitment, definition_id, serial_id)`.
- **SecretId-like** (spec-4): `asset_id = H(s_out)`.

🚨 This impacts type design directly. Without resolving this, any “final type unification” will keep generating parallel structs.

---

## 🧭 3) “Three worlds” rule (must not be violated)

🧭 The codebase currently mixes three different roles:
- **World A (Consensus / JMT leaf):** public encrypted mirror state.
- **World B (Wallet record):** decrypted + secrets + local metadata.
- **World C (DTO / export / RPC):** serialization convenience.

🚫 **Rule:** merge only within one world. Never merge across worlds.

---

## ✅ 4) Final keep/delete/modify decisions

### ✅ 4.1 Keep (must remain independent)

✅ **Keep `TxStealthOutput`** as a dedicated sender header.
- Reason: it encodes a phase boundary with required fields; collapsing into a larger struct with many `Option<T>` creates invalid intermediate states.

✅ **Keep `WalletStealthOutput`** (or an equivalent wallet-only record).
- Reason: it is wallet-owned and allowed to contain secrets/witnesses and local indexing fields (e.g., `decrypted_at`).

✅ **Keep ONE canonical “consensus leaf” type** (JMT value schema).
- Today `UtxoLeaf` is the closest leaf-shaped struct with all stealth header fields + `asset_id`.
- However, its current location (`z00z_wallets`) and its field types are not aligned with core types.

### 🚫 4.2 Delete (remove or rename to eliminate confusion)

🚫 **Delete or rename `z00z_wallets::core::asset::AssetLeaf` (asset_leaf.rs)**.
- Reason: it is unused outside its own module/tests and its schema does not match the protocol leaf described in specs.
- Keeping this name blocks adopting `AssetLeaf` for the real consensus leaf type.

🚫 **Delete `GenesisAssetExportEntry` after merging export onto `AssetWire` (World C merge).**
- Reason: it is a near-duplicate of `AssetWire` (definition embedded + same stealth overlay fields).

### ⚙️ 4.3 Modify (make roles explicit and schemas consistent)

⚠️ **Modify “leaf” representation to be canonical and core-owned.**
- Target: a single `AssetLeafV1` (name illustrative) in `z00z_core` that is the canonical JMT value type.
- `z00z_wallets` should consume this leaf type (scan input), not define its own protocol leaf.

⚠️ **Modify `UtxoLeaf` (transition plan):**
- Either replace it with the canonical core leaf type, or restrict it to tests/examples only.

⚠️ **Modify field-type consistency across the stealth pipeline:**
- `tag16`: choose one semantic (recommended: `Option<u16>` everywhere).
- `enc_pack`: choose one representation for “encrypted blob”.
	- Today: `Vec<u8>` in core/wire/sender; `ZkPackEncrypted` in `UtxoLeaf`.
	- The final design must ensure the same bytes that are stored on-chain can be:
		- validated/bound (via `leaf_ad` concept),
		- decrypted by wallet,
		- serialized in DTOs.

⚠️ **Modify naming to match semantics:**
- If core keeps the current `asset_id()` formula (nonce+commitment+definition+serial), rename it to `output_id` (or similar) so it does not collide conceptually with the canonical leaf/JMT `asset_id`.
- Do not introduce a second public JMT-key concept from decrypted `s_out`; secret-derived material belongs to ownership and witness flows, not to the public leaf key namespace.

---

## 🧼 5) Why you should NOT proliferate AssetWire sub-structs

🧼 `AssetWire` is World C (DTO). It is not a consensus leaf and not a wallet witness record.

⚠️ Creating `AssetWireHeader`, `AssetWireLeaf`, etc. is usually a symptom of using a DTO as a domain model.

✅ The correct consolidation is:
- one **leaf** type for JMT,
- one **sender header** type,
- one **wallet record** type,
- one **DTO** type (wire/export),
and explicit conversions between them.

---

## 🧠 6) “How does wallet reconstruct full object if leaf does not contain all fields?”

🧠 There are two “full objects”:

🔑 **(A) Full spendable wallet record** (required for spending)
- Reconstructed as: `wallet_record = leaf_public + decrypt(enc_pack) + local_metadata`.
- This is exactly why `WalletStealthOutput` exists as a distinct world.

🎛️ **(B) Full rich policy-bound object** (e.g., `Asset` with `Arc<AssetDefinition>`)
- Requires a stable reference to definition/policy.

✅ Therefore, the consensus leaf MUST provide at least one stable policy reference, via one of:
- include `definition_id` explicitly in the leaf (public), or
- include `definition_id` inside the encrypted pack, or
- guarantee a deterministic mapping from leaf identifiers to definition registry.

🚫 If none of those exist, reconstructing a policy-bound object from a leaf is impossible (information is missing).

---

## ✅ 7) Final action list (unambiguous)

✅ **Keep as independent (no merging across worlds):**
- `TxStealthOutput`
- `WalletStealthOutput`
- one canonical consensus leaf type (to be defined in core)

🧩 **Merge / delete redundancy (World C only):**
- merge `GenesisAssetExportEntry` into `AssetWire` and delete the former

🚫 **Delete/rename confusing unused leaf:**
- delete or rename `z00z_wallets::core::asset::AssetLeaf` to free the name `AssetLeaf` for the real protocol leaf

⚙️ **Normalize field types:**
- `tag16: Option<u16>` consistently
- one canonical `enc_pack` representation consistently

⚠️ **Resolve `asset_id` semantics:**
- rename current `asset_id()` where needed to reflect “output id” semantics, while keeping `asset_id` as the canonical public JMT leaf key
