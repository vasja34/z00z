#  clean-spec-4 — Type Boundaries, JMT Value Choice, and What Spec-4 Adds

 **Status:** proposal-only, no code changes.

 **Scope:** answer these questions:
 1) Why `AssetWire` does not contain `Arc`, and whether it can/should be stored in JMT.
 2) Whether “my scanned `AssetLeaf` is basically a full `Asset`”.
 3) Why `WalletStealthOutput` exists if it is “just a decrypted Asset”.
 4) Why `TxStealthOutput` exists if we can put optional fields into some larger struct.
 5) What functional/security value is added by `specs/009-z00z-ecc-spec-4/4_Asset_Model.md`.

---

##  1) First principles: what *can* live in JMT

 A JMT (Jellyfish Merkle Tree) stores **canonical bytes**, not Rust runtime objects.

 Therefore, a “JMT value type” must satisfy **consensus constraints**:
 - **Deterministic encoding**: identical semantic value → identical bytes across nodes.
 - **Stable schema**: upgrades must be explicit versioned transitions.
 - **No runtime pointers**: `Arc<T>` is an in-memory sharing mechanism, not a consensus primitive.
 - **No secrets**: anything stored in JMT is public chain state.
 - **Size matters**: value size impacts storage, proof size, bandwidth, CPU.

 The important nuance is: “does not contain `Arc`” is **necessary** but not **sufficient** for a type to be a good JMT value.

---

##  2) `AssetWire` and `Arc`: why `AssetWire` has no `Arc`

 In code, `Asset` is an in-memory domain object that intentionally uses `Arc<AssetDefinition>` for sharing (`z00z_core/src/assets/assets.rs`).

 `AssetWire` is a **network DTO** that intentionally embeds `AssetDefinition` by value (`z00z_core/src/assets/wire.rs`), for the “always deserializable, no registry dependency” goal.

 So the absence of `Arc` in `AssetWire` is not an accident; it is a deliberate property:
 - `Arc` is meaningless across the network.
 - A DTO should be “owned data”, not shared pointers.
 - Serialization frameworks cannot treat `Arc` as a stable protocol primitive.

---

##  3) Can `AssetWire` be stored in JMT?

 **Technically yes**, you can store *any* bytes as a JMT leaf value.

 **But “can” ≠ “should”**. Storing `AssetWire` in JMT has major tradeoffs.

###  3.1 Pros

 - **Self-contained state proofs**: a proof can carry the embedded definition together with the asset state.
 - **No registry coupling**: light clients could validate more without fetching separate “definition registry” state.

###  3.2 Cons (the real reasons to avoid it)

 - **State bloat**: `AssetWire` embeds `AssetDefinition` (~200 bytes) per leaf. If many leaves share the same definition, this is massive duplication.
 - **Proof bloat**: larger leaf values make proofs bigger and more expensive to transport/verify.
 - **Schema drift risk**: DTOs evolve for networking convenience; JMT state must be conservative and versioned.
 - **Encoding/canonicality risk**: `serde` formats are typically not “consensus-canonical” by default. JMT value hashing must commit to one exact encoding.
 - **Privacy model mismatch**: `AssetWire` contains `amount: u64`. If the protocol goal is confidential amounts, storing plaintext amount in consensus state undermines the design. Even if *today* the chain stores amount, this choice makes later privacy upgrades harder.

 **Conclusion:** storing `AssetWire` in JMT is an architectural debt amplifier. It mixes “wire convenience” with “consensus truth”.

---

##  4) What should be stored in JMT instead

 Spec-4 repeatedly frames the JMT value as a **leaf schema** (public fields + commitments + proofs), keyed by `asset_id`.

 The “consensus leaf” should be:
 - minimal (no duplicate definition payloads),
 - public-only,
 - strongly bound to `enc_pack` via `leaf_ad` (anti-malleability),
 - explicitly versioned.

 A clean separation is:
 - **JMT key:** `asset_id`.
 - **JMT value:** “Asset leaf” (commitment/proof + stealth header + state flags).
 - **Definition registry:** separate structure keyed by `definition.id` (or embedded in block config snapshot), not repeated per leaf.

---

##  5) “If I scan JMT and get my `AssetLeaf`, it is basically a full `Asset`”

 This is the core misconception: you are mixing **protocol phases**.

 A scanned leaf is **public chain state** (plus an encrypted blob). A “full `Asset`” in the Rust codebase is an **application object** with policy references, validation APIs, and potentially non-consensus conveniences.

 Even if two structs are field-isomorphic in one snapshot of the code, they are not equivalent by *role*:
 - **Leaf (consensus):** what validators commit to and what proofs refer to.
 - **Asset (domain model):** what higher layers use after resolving definition, validating constraints, and (optionally) decrypting payload.
 - **Wallet record:** what the wallet persists for spendability (including secrets).

 Decryption in wallet is not “just toggling a boolean”:
 - decryption yields **private witness material** (`s_out`, blinding, etc.),
 - wallet must bind decrypted data to the leaf context (`leaf_ad` concept),
 - wallet may only store a minimal spend record rather than the full consensus leaf.

---

##  6) Why `WalletStealthOutput` exists

 In code, `WalletStealthOutput` (scanner output) is a **wallet-owned artifact**, not a consensus leaf and not a wire DTO.

 It carries wallet-specific concerns that do not belong to consensus types:
 - **decrypted_at** timestamp (local indexing, UX, re-scan logic),
 - **secrets placeholders** (`coin_secret`, `blinding`) that must never leak into chain or wire by accident,
 - a stable “wallet DB row” shape (this tends to be different from consensus leaf schema).

 Even if you could represent the same information as “`Asset` + extra fields”, that increases the risk of category mistakes:
 - accidentally serializing secrets into a DTO,
 - accidentally treating a partially-known asset as fully validated,
 - mixing storage lifecycles (chain state vs wallet state).

 **The functional gain** of `WalletStealthOutput` is therefore type-level safety and clearer persistence boundaries.

 If you want to reduce types, the safe direction is not “delete wallet type”, but “wrap the leaf + wallet witness” under a single wallet-only struct, e.g. `WalletUtxoRecord { leaf, witness, discovered_at }`.

---

##  7) Why `TxStealthOutput` exists

 `TxStealthOutput` is a **sender-side construction artifact**: it is exactly the minimal set needed to build the stealth header (`r_pub`, `owner_tag`, `enc_pack`, optional `tag16`).

 A larger struct with lots of `Option<T>` is not equivalent, because:
 - You lose “required vs optional” invariants at compile time.
 - You introduce invalid intermediate states that must be defended everywhere.
 - You couple sender logic to consensus validation logic (commitment/proofs/locks) prematurely.

 The fact that `TxStealthOutput` has fewer fields is not redundancy; it is a **phase boundary**.

 Practical rule:
 - “header that is always required by stealth encryption” → `TxStealthOutput`.
 - “final leaf that consensus commits to” → leaf type.
 - “wallet-only spend record + secrets” → wallet record type.

---

##  8) What spec-4 adds (real functional/security value)

 `specs/009-z00z-ecc-spec-4/4_Asset_Model.md` is not “just another document”; it introduces consensus-critical bindings and threat-driven constraints.

###  8.1 Explicit ownership object: `s_out`

 Spec-4 defines `s_out` as the ownership object and explains why spending requires both `s_out` and `receiver_secret`.

###  8.2 Deterministic `asset_id` and its role in JMT

 It defines `asset_id` as the canonical public leaf identifier and explicitly states `asset_id` is the JMT key.

###  8.3 `serial_id` is not cosmetic

 Spec-4 frames `serial_id` as a binding parameter preventing cross-output replay of `enc_pack` and as a versioning/series dimension.

###  8.4 `leaf_ad` binding (anti-malleability)

 The big functional addition is the **binding hash**:
 - `leaf_ad = H_zk("Z00Z/LEAFAD" || asset_id || serial_id || R_pub || owner_tag || C_amount)`.

 This is a security mechanism: it cryptographically ties `enc_pack` to the exact leaf context.

 Without this, you can get “externally valid but internally unspendable” outputs and replay/malleability classes of attacks.

###  8.5 Two-hash-stack framing (consensus vs wallet)

 It clarifies that consensus-critical hashing must be ZK-friendly (`H_zk`), while wallet-only hashing can be different (`H_wallet`).

 This matters because it influences what becomes part of proofs, and therefore what becomes rigidly consensus-coupled.

---

##  9) Proposal summary (no code changes)

 If the goal is fewer types without losing safety, the safe consolidation is:
 - Treat **consensus leaf** as the single JMT value type (versioned, minimal, canonical).
 - Treat `AssetWire` as a **transport/export DTO** only.
 - Treat wallet scan output as a **wallet-only record** that can contain secrets.
 - Keep a minimal sender header (`TxStealthOutput`) as a phase artifact.

 The “GenesisAssetExportEntry → AssetWire” duplication is indeed straightforward to unify, but it is orthogonal to the JMT-value decision.

---

## 🧭 10) Your model: off-chain Assets + on-chain encrypted mirror (clarified)

🧭 In the “off-chain Asset object” model, the chain state does NOT store a rich `Asset` object.

⚙️ Instead, the chain stores an **unspent set** in JMT:
- On spend: old leaf is deleted (or replaced) and new leaves are inserted.
- The wallet stores the spendable witness material off-chain.

🔒 The on-chain leaf is therefore not “an Asset”, it is an **encrypted/public mirror** sufficient for:
- consensus validation (commitment / proof / flags),
- wallet discovery (scan inputs like `r_pub`, `owner_tag`, `tag16`),
- safe decryption binding (`leaf_ad` concept).

---

## 🧩 11) Which structs must remain independent vs which can be merged

🧩 Based on clean-spec-3 (“three worlds”) + this document (“JMT value choice”), the minimal stable set is:

🏛️ **A) Consensus leaf (JMT value): keep independent**
- Keep ONE canonical leaf schema type (name: `AssetLeaf` in specs; currently `UtxoLeaf` is closest).
- This is the only type that should be treated as “state tree value”.

🧰 **B) Sender header (tx construction): keep independent**
- Keep `TxStealthOutput` as the minimal required header.

🧠 **C) Wallet record (post-decrypt): keep independent (wallet-only)**
- Keep `WalletStealthOutput` (or evolve into one wallet record that wraps leaf + witness).
- This type is allowed to contain secrets and local indexing metadata.

📦 **D) Transport/export DTO: merge where possible**
- `GenesisAssetExportEntry` and `AssetWire` are the objective redundancy: merge into ONE DTO.
- Keep `AssetWire` as “wire/export DTO”, but do NOT treat it as the canonical leaf.

🚫 The key rule: do not merge across worlds. Merge only inside the same world.

---

## 🧼 12) “Why do I need sub-structs of AssetWire?”

🧼 You generally do NOT. If your architecture is “off-chain object + on-chain mirror”, then `AssetWire` should not be the central protocol type.

⚠️ If you find yourself creating `AssetWireHeader`, `AssetWireLeaf`, `AssetWireWhatever`, that is usually a smell that you are using a DTO as a domain model.

✅ The cleaner approach is:
- 1 canonical **leaf** type for JMT.
- 1 minimal **sender header**.
- 1 wallet-only **record** (leaf + decrypted witness).
- 1 DTO **only** where serialization boundaries require it.

---

## 🧠 13) “How can the wallet reconstruct a full object from AssetLeaf if not all fields are there?”

🧠 There are two different “full objects” that people mix up:

🔑 **(1) Full spendable wallet record** (what you actually need to spend)
- This is reconstructed as: `wallet_record = leaf_public + decrypt(enc_pack) + local_metadata`.
- Decrypt yields private witness material (e.g., amount, blinding, `s_out`).
- This does NOT require embedding `AssetDefinition` in the leaf.

🎛️ **(2) Full rich domain object** (policy + UX fields)
- If you want a rich object with definition/policy attached, you need a definition reference.

📌 That creates a concrete design requirement:
- Either the JMT leaf includes a **definition reference** (e.g., `definition_id: [u8; 32]`),
- Or the encrypted pack includes the definition reference,
- Or the wallet obtains the definition from an external registry snapshot by other means.

🚫 If the leaf contains neither definition reference nor a recoverable mapping, then the wallet cannot deterministically rebuild `Arc<AssetDefinition>` from the leaf alone.
That is not a type-system issue; it is an information-theory issue: the information simply is not present.

✅ Therefore: in the “off-chain Asset object” architecture, the leaf must carry at least ONE stable identifier that lets the wallet bind the spendable record to the correct definition/policy.
