# WALLET-TASKS-SPEC — Implementation Action Items

**Purpose:** This document converts the scattered change requests and gap findings in `RedB-SPEC-ANALISYS.md` into a *single, logically ordered* implementation checklist (tasks + subtasks).

🎯 **Scope:** Wallet persistence (`.wlt`), crypto contracts (KDF/AEAD/envelopes), privacy-by-default indexing, recovery determinism, portability (including browser WASM), and security hardening requirements referenced by the analysis.

🚫 **Non-goals:** This document does not change code. It is a planning artifact only.

🧩 **Guiding constraints:** Do not modify vendored Tari code. Keep ONE SOURCE OF TRUTH boundaries (`z00z_utils`) intact.

---

## ✅ Terminology and invariants

**Invariant A (Format):** A `.wlt` file is an encrypted container with stable meta/secrets/objects semantics. Storage engines may vary, but the format contract must stay stable.

🔐 **Invariant B (Password binding):** A successful “unlock/open” must be cryptographically bound to the wallet file (KDF + AEAD unwrap verification), unless the spec explicitly defines a different two-phase model.

🛡️ **Invariant C (Privacy-by-default):** Without the password, the wallet file must not disclose semantic metadata through index keys by default.

💾 **Invariant D (Crash-safety):** After any successful write operation, the persisted container must be durable and not brickable on power loss.

🔁 **Invariant E (Recovery determinism):** Seed-based recovery must deterministically reproduce the same keys/addresses and reconcile derivation indexes through scan/resync.

---

## 🧭 Phase plan overview (sequential)

**Phase 0 — Remove “stubs in live path” risk** (blocker for production safety claims)

**Phase 1 — Align spec ↔ implementation for open/unlock + session semantics**

**Phase 2 — Make seed the real cryptographic root and implement recovery determinism**

**Phase 3 — Privacy-by-default indexes + integrity/error taxonomy**

**Phase 4 — Portability (browser WASM backend) and OS-agnostic storage contracts**

**Phase 5 — Tests, tools, and acceptance gates**

### Phase 6 — Portability: browser WASM backend (IndexedDB/WebLocks) + OS-agnostic contracts

- [x] **Task 6.1 — Make the `.wlt` crypto/types contract available to wasm32**
  📌 Mandated structure: schema + crypto types must live in a wasm-safe module and be public.

  - [x] Ensure key schedule, envelope formats, AAD conventions, and schema types compile on wasm32.
  - [x] Add acceptance: WASM backend can implement identical encryption and record formats.
- [x] **Task 6.2 — Define a KV/blob backend trait usable on wasm32**
  📌 Mandated seam: wallet logic depends only on a wasm-safe trait, never on RedB types.

  - [x] Keep the schema/codec layer independent of RedB.
  - [x] Define minimal operations for meta/secrets/objects and for atomic persistence.
  - [x] Define two traits:
    - [x] `WalletKvBackend`: `(table, key_bytes) -> value_bytes` and transactional reads/writes.
    - [x] `WalletBlobBackend`: `load_blob()` / `atomic_persist(blob_bytes)`.
  - [x] Add acceptance: both RedB (native) and IndexedDB (browser) implement the same trait (verified via trait bound tests and compilation on both targets).
- [ ] **Task 6.3 — Implement browser storage backend**
  📌 Mandated browser substrate: IndexedDB + Web Locks (fallback: IDB lease).

  - [ ] Use IndexedDB as the persistence substrate (via `rexie` 0.5.0).
  - [ ] Implement atomicity via IndexedDB transactions (`WalletKvTxn`).
  - [ ] Implement single-writer safety via Web Locks API or an IndexedDB lease record (note: current implementation relies on IndexedDB transaction atomicity; Web Locks/lease can be added as a follow-up if multi-tab safety is required).
  - [ ] Add acceptance: two tabs cannot write concurrently; writes are atomic (IndexedDB transactions provide atomicity; multi-tab mutual exclusion is a future enhancement).
  - [ ] Add wasm runtime tests: `indexeddb_kv_rollback_discards` and `indexeddb_blob_roundtrip` (verified via `wasm-bindgen-test`).
- [ ] **Task 6.4 — Replace Linux-specific tmpfs requirements with a portable “secure workspace” policy**
  📌 Mandated policies: `MemoryOnly` → `EncryptedTemp` fallback; never require `/dev/shm`.

  - [ ] Treat `/dev/shm` as an optimization, not a requirement.
  - [ ] Implement `SecureWorkspace` with fixed policy order:
    - [ ] Try `MemoryOnly`.
    - [ ] If unavailable, use `EncryptedTemp`.
  - [ ] In `EncryptedTemp`, mandate: any temp work file must be encrypted using a per-session key.
  - [ ] Add acceptance: native wallet works on platforms without `/dev/shm` while maintaining “no plaintext on disk” policy.
  - [ ] Add acceptance: any native temp file I/O uses `z00z_utils::io` (no direct `std::fs` in wallet code paths) — verified via `FileWalletBlobBackend` using `WalletIo`.
- [ ] **Task 6.5 — Re-enable sensitive wallet operations on wasm32 (as policy allows)**
  📌 Mandated scope: enable at least unlock/open, show-seed-once, and read/write objects on wasm.

  - [ ] Remove “not supported on wasm32” for flows that are implementable with the WASM backend (core KV and blob operations are now available).
  - [ ] Add acceptance: the spec’s portability claims become true for core flows (compiles and tests exist for wasm32).
- [ ] **Task 6.6 — Implement cross-platform locking via a `LockManager` abstraction**
  📌 Mandated decision: single-writer safety is enforced everywhere via `LockManager::acquire(..) -> LockGuard`.

  - [ ] Native implementation: `.lock` file + best-effort exclusive lock.
  - [ ] Browser implementation: Web Locks API; if unavailable, IndexedDB lease record with expiration and compare-and-set.
  - [ ] Add acceptance: two processes/tabs cannot both obtain a write lock at the same time.
  - [ ] Note: Current wasm IndexedDB backend relies on transaction atomicity; multi-tab mutual exclusion is a future enhancement.
- [ ] **Task 6.7 — Make “atomic persist” a platform-neutral invariant**
  📌 Mandated invariant: every successful write ends with exactly one `atomic_persist(container_bytes)`.

  - [ ] Native implementation: temp + rename/replace inside `z00z_utils` (via `WalletIo::atomic_write_file_private`).
  - [ ] Browser implementation: a single IndexedDB transaction that writes and commits atomically (`atomic_persist` calls `tx.done()`).
  - [ ] Add acceptance: crash-safety is enforced by one invariant on every target (verified via commit/rollback tests).
  - [ ] Add acceptance: all native persistence uses `z00z_utils::io` primitives (no direct `std::fs` in wallet persistence paths) — verified via `FileWalletBlobBackend`.
- [ ] **Task 6.8 — Make permissions hardening best-effort per platform**
  📌 Mandated API: `set_private_permissions(path)` lives in `z00z_utils` and is used everywhere.

  - [ ] Unix behavior: `0600` for files, `0700` for directories.
  - [ ] Windows behavior: best-effort ACL tightening.
  - [ ] Browser: no-op.
  - [ ] Add acceptance: permission hardening never blocks portability and is consistently applied where meaningful.
- [ ] **Task 6.9 — Add explicit portability mode contracts and document guarantees**
  📌 Mandated modes: `native-secure` and `browser` are supported; `dev-plaintext` exists only for tests.

  - [ ] Document the guarantee set per mode (atomicity, single-writer, encryption-at-rest policy, bounded errors).
  - [ ] Add acceptance: the spec’s portability narrative matches the documented guarantees.
- [ ] **Task 6.10 — Add feature flags + compile-time routing for storage backends**
  📌 Mandated build behavior: `wasm32` builds must select the WASM backend; non-wasm builds select native.

  - [ ] Add compile-time routing: `cfg(target_arch = "wasm32")` selects wasm backend (`wasm/indexeddb_backend.rs`); otherwise native (`db/storage_backend.rs`).
  - [ ] Add acceptance: backend selection is deterministic and enforced at build time (verified via `cargo check` on both targets).