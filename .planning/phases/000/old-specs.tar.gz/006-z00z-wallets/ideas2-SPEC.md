# Z00Z Wallets: Tari-derived Implementation SPEC (authoritative)

Дата: 2026-01-04

Цель: зафиксировать **что именно переносим из Tari** и **как внедряем это в Z00Z** (кошельки/ключи/tx/storage), без копирования кода.

Формат (строго для каждого пункта):

- **В чём идея**
- **Что взять из Tari и почему полезно (+ tradeoffs)**
- **Как реализовать в Z00Z** (с привязкой к существующим модулям)

Примечание ревью: **REVIEW**-комментарии вставляются **там, где есть конкретное замечание**, и могут находиться в любом из трёх подпунктов. Если в каком-то подпункте нет отдельного **REVIEW**, это не означает, что он “не проверен” — обычно замечание относится к пункту целиком и дано выше.

Z00Z anchor points (куда обычно “вкручивается” реализация):

- Крипто-envelopes/AAD: `z00z_crypto/src/aead_envelope.rs`
- Seed container: `z00z_crypto/src/cipher_seed.rs`
- Branch IDs: `z00z_crypto/src/key_branches.rs`
- `.wlt` persistence: `z00z_wallets/src/db/wlt_store.rs`, `z00z_wallets/src/db/redb_wallet_store.rs`
- Key manager surface: `z00z_wallets/src/core/key/key_manager.rs`, `z00z_wallets/src/core/key/key_manager_redb.rs`

---

## z00z_crypto/tari/crypto/src/signatures/commitment_and_public_key_signature.rs

### `CommitmentAndPublicKeySignature::sign`

- **В чём идея**: подпись как proof-of-knowledge по **двум независимым секретам** (opening коммитмента и секрет pubkey), где “вызов” (challenge) задаётся **снаружи**.
  Это важно, потому что в MPC/threshold/interactive-протоколах challenge часто вычисляется не внутри `sign()`, а как результат transcript’а (Fiat–Shamir): участники должны подписывать **один и тот же** challenge, иначе агрегация/проверка рушится.
  Ключевой смысл структуры: зафиксировать контракт “подписываем (R, commitment, pubkey, …) под конкретный challenge” и сделать это типобезопасно.
  - **REVIEW** ⚠️ Added value высокий только если Z00Z реально планирует MPC/threshold/ledger multi-signer; иначе это усложнение API и тест-матрицы без ощутимого выигрыша.
  - **REVIEW** ✅ Идея “challenge инжектится” корректна и важна для transcript-based протоколов; в тексте хорошо подчеркнут риск рассинхронизации challenge.
- **Что взять из Tari и почему полезно (+ tradeoffs)**: берём именно **API-идею “challenge инжектится”** и строгое разделение обязанностей:
  - Caller отвечает за вычисление challenge (с доменным разделением и каноническими байтами входов).
  - Подпись отвечает за корректное использование challenge (wide reduction → scalar) и проверку, что компоненты подписи каноничны.
    Почему полезно: Z00Z сможет поддерживать HW signer / multi-signer flow без переписывания схемы подписи.
    Tradeoffs:
  - Протокол фиксирует recipe вычисления challenge (это становится долговременным контрактом).
  - Ошибка caller’а может создать “подписали не то” → нужно агрессивно валидировать длины/домены/нулевые значения.
  - **REVIEW** ✅ Правильное разделение ответственности, но в Z00Z это стоит формализовать как “transcript spec”: список полей, порядок, encoding, domain/version.
  - **REVIEW** ⚠️ Сейчас `z00z_crypto` уже re-export’ит `tari_crypto::signatures::CommitmentAndPublicKeySignature`; добавление параллельной реализации/типов в `z00z_crypto/src/signatures/` может создать два несовместимых API и путаницу.
- **Как реализовать в Z00Z**: добавить тип(ы) подписи в `z00z_crypto` (например `signatures/`), при этом:
  - Вынести вычисление challenge в отдельный helper, который **обязательно** использует `hash_domains`.
  - В `sign_with_challenge` принимать только фиксированный массив `[u8; 64]` (или новыйтип), чтобы исключить “кривые длины”.
  - Верификацию строить поверх канонических байтов (compressed keys/signatures как boundary).
    Пример (схема, не копия):

  ```rust
  pub struct Challenge64([u8; 64]);
  
  impl Challenge64 {
      pub fn from_transcript(domain: DomainTag, msg: &[u8]) -> Self {
          // domain-separated hash → 64 bytes
          Self(hash_domains::hash_64(domain, msg))
      }
  }
  
  pub fn sign_with_challenge(
      opening: &SecretScalar,
      spend_sk: &SecretScalar,
      challenge: Challenge64,
  ) -> CapkSignature {
      // wide reduction challenge.0 → scalar
      // compute response scalars
      // return canonical signature object
  }
  ```

  Z00Z touchpoints (куда класть/что менять): `z00z_crypto/src/hash_domains.rs` (добавить tag), новый модуль `z00z_crypto/src/signatures/`, тесты в `z00z_crypto/tests` на (a) неканоничные байты, (b) challenge=0, (c) mismatch domain.
  - **REVIEW** ⚠️ Реализацию лучше начать с “обёртки” вокруг уже экспортируемых Tari-типов (или явного facade API), а не плодить новые структуры, иначе рискуете расхождением форматов/проверок.
  - **REVIEW** ✅ Фиксированный `[u8; 64]`/newtype — хороший guardrail; но также нужно явно запретить невалидные входы (например, нулевой challenge если это нежелательно по протоколу) и зафиксировать wide-reduction helper как единственный путь.

### ❌~~`verify_challenge` / `verify`~~

- **В чём идея**: два уравнения проверки можно “свернуть” в одно через случайный коэффициент (рандомизированная линейная комбинация).
  Практический смысл: если у нас есть много подписей (сканер, UI, mempool), мы экономим CPU на проверке, принимая **минимальную** вероятность ложноположительного результата.
  
  - **REVIEW** ⚠️ Для кошелька/сканера это может дать выигрыш, но только если реально есть большие batch-проверки CAPK; иначе риск “сложнее, чем нужно”.
  - **REVIEW** ✅ Хорошо, что идея явно помечена как вероятностная и не предлагается для консенсуса.
- **Что взять из Tari и почему полезно (+ tradeoffs)**: берём модель: `verify_strict()` всегда доступен, а “ускоренный” режим — это отдельный, явно помеченный API.
  Почему полезно: Z00Z сможет сделать быстрые UX-проверки (например, при импорте истории) без утечки этого режима в консенсус/валидаторы.
  Tradeoffs:
  - Вероятностность: нельзя использовать в правилах консенсуса/финальной валидации.
  - Нужен источник случайности и стабильная политика (как часто/где допускается).
  - **REVIEW** ✅ Разделение `strict`/`fast` как разные API — правильная защита от случайного misuse.
  - **REVIEW** ⚠️ Нужно явно описать policy: где именно “fast” допустим, и как гарантировать, что валидаторы/critical path никогда не вызывают его (например, feature gating, отдельный модуль, deny-by-default).
- **Как реализовать в Z00Z**:
  - В `z00z_core`/валидаторах использовать только `verify_strict()`.
  - В `z00z_wallets` (UI/сервисах) разрешить `verify_fast_randomized(rng)`.
  - API явно разделить (названием и документацией), чтобы случайно не вызвать “быстрый” метод из критического кода.
    Пример формы API:

  ```rust
  pub enum VerifyMode { Strict, FastRandomized }
  pub fn verify(sig: &CapkSignature, mode: VerifyMode, rng: Option<&mut impl RngCore>) -> Result<(), SigError>;
  ```
  - **REVIEW** ⚠️ Лучше не делать единый `verify(mode, rng)` с `Option<rng>`: это облегчает “случайно передали None и получили non-randomized fast” или наоборот; безопаснее — два разных метода/трейта.

### ❌~~`Add` impls (CAPK + CAPK, CAPK + Schnorr)~~

- **В чём идея**: “частичные” подписи (shares) могут агрегироваться, но только если:
  - они относятся к одному и тому же challenge;
  - они подписывают один и тот же набор публичных компонент (commitment/pubkey);
  - они получены по одной схеме деривации nonce/ответов.
    Смысл структуры/оператора: сделать агрегацию **первоклассной операцией**, чтобы не собирать подпись вручную из голых скаляров.
  - **REVIEW** ⚠️ Это добавляет value только если у Z00Z есть конкретный roadmap по threshold/агрегации подписей; иначе это преждевременная сложность.
  - **REVIEW** ✅ Правильно перечислены условия совместимости shares — это то место, где обычно появляются “почти всегда не проходит” баги.
- **Что взять из Tari и почему полезно (+ tradeoffs)**: берём идею “aggregation is explicit and typed”.
  Почему полезно: в Z00Z часто будет несколько signers (software, hw, remote) — и самый дорогой класс багов тут: “сложили несовместимое и получили подпись, которая почти всегда не проходит”.
  Tradeoffs:
  - Нужно хранить/передавать метаданные контекста (какой challenge, какой domain, какая схема).
  - API становится шире: `PartialSig`/`AggregateSig`/`CombineError`.
  - **REVIEW** ✅ Сильный аргумент про “дорогие баги”; но требуется чётко определить, где хранится `SigContext` и кто его авторитетно формирует.
- **Как реализовать в Z00Z**:
  - Не полагаться на `impl Add` (слишком легко случайно использовать).
  - Сделать явные функции `combine_partial_signatures(partials: &[PartialSig], ctx: &SigContext) -> Result<CapkSignature, CombineError>`.
  - `SigContext` должен включать domain-tag + canonical bytes идентификатора “что подписываем” (transcript id).
  - **REVIEW** ✅ Отказ от `impl Add` — верное решение: снижает риск случайной агрегации в “не тех” местах.

### `to_vec` + `Ord`/`Hash`

- **В чём идея**: у крипто-типов может быть несколько “эквивалентных” внутренних представлений, но для:
  - сортировок (BTreeMap),
  - дедупликации,
  - стабильных хэшей,
    требуется **одно** каноническое байтовое представление.
    Смысл структуры: обеспечить детерминизм независимо от внутреннего состояния/кэшей.
  - **REVIEW** ✅ Это базовая крипто-гигиена; особенно актуально, если вы делаете кэширование/decompress как в следующем пункте.
- **Что взять из Tari и почему полезно (+ tradeoffs)**: берём правило “`Ord`/`Hash` базируются на canonical bytes”, потому что это снимает класс багов: “один и тот же объект иногда сравнивается иначе/хэшируется иначе”.
  Tradeoffs:
  - Канонический формат становится долгоживущим контрактом.
  - Нужны тесты, гарантирующие стабильность bytes между версиями.
  - **REVIEW** ⚠️ Snapshot-тесты на bytes полезны, но могут стать “ложным тормозом” на рефакторинги; важно явно отделить storage/wire-canonical bytes (стабильные) от внутренних оптимизаций.
- **Как реализовать в Z00Z**:
  - В `z00z_crypto` для каждого crypto newtype определить `to_canonical_bytes()`.
  - В `Ord/Hash` использовать именно эти bytes.
  - На boundary (RPC/storage) хранить только compressed/canonical representation.
    Добавить snapshot тест: “canonical bytes не изменились” для важных типов.
  - **REVIEW** ✅ Это хорошо ложится на текущую философию `z00z_crypto` (ByteArray/canonical boundary), но стоит заранее определить, какие именно типы “важные” (чтобы не плодить хрупкие snapshots).

---

## z00z_crypto/tari/crypto/src/signatures/compressed_commitment_and_public_key_signature.rs

### `CompressedCommitmentAndPublicKeySignature` + `to_capk_signature`

- **В чём идея**: подпись “в покое” (на диске/в сети) хранится в компактной форме, а “полная” форма появляется только при проверке/вычислениях.
  Это снижает размер `.wlt` и нагрузку на RPC, но требует чёткой границы: где мы декодируем и где валидируем каноничность.
  - **REVIEW** ✅ Added value высокий и практически гарантированный: это прямо про размеры `.wlt`/RPC и про безопасные boundary-конверсии.
- **Что взять из Tari и почему полезно (+ tradeoffs)**: берём паттерн “compact at rest, strict decode at boundary”.
  Почему полезно: в Z00Z много слоёв (wallet store, rpc adapters, core) — и именно boundary должен быть местом, где мы отбрасываем неканоничные подписи.
  Tradeoffs:
  - Декод может быть дорогим (и может падать) → нельзя делать его “везде понемногу”.
  - Нужно избегать двойного декода (сделать единый переход compact→full).
  - **REVIEW** ✅ Это полностью соответствует текущим практикам в `z00z_crypto` (строгие size checks в AEAD envelope, вынос boundary в один слой).
- **Как реализовать в Z00Z**:
  - В `z00z_crypto` определить `CompactCapkSignature` (bytes) и `CapkSignature` (typed).
  - Конверсия только через `try_from_bytes_canonical()`.
  - `.wlt`/RPC держат `Compact*`, core/validation — `*`.
    Пример boundary-конверсии:

  ```rust
  impl CompactCapkSignature {
      pub fn try_into_full(&self) -> Result<CapkSignature, SigError> {
          CapkSignature::from_canonical_bytes(&self.0)
      }
  }
  ```
    - **REVIEW** ⚠️ Важно не дублировать уже существующие Tari-типы: `z00z_crypto` уже экспортирует `CompressedRistrettoComAndPubSig`/`RistrettoComAndPubSig`. Возможно, достаточно стандартизировать, какие именно bytes кладутся в `.wlt`, без введения новых структур.

### `new_from_capk_signature`

- **В чём идея**: для любого crypto-типа должен существовать единственный, очевидный переход full→compact.
  Смысл: чтобы сериализация не была “случайной” (например, взяли Debug-строку или внутренние поля), а всегда шла через canonical bytes.
  - **REVIEW** ✅ Корректная формализация “one obvious way” для сериализации; это снижает риск несовместимости между слоями.
- **Что взять из Tari и почему полезно (+ tradeoffs)**: берём lossless converters как часть публичного API.
  Почему полезно: упрощает `.wlt` схемы и RPC (всегда знаем, какие bytes лежат в записи).
  Tradeoffs: любое изменение compact-формата = миграция данных.
  - **REVIEW** ⚠️ В Z00Z миграции `.wlt` могут стать дорогими; нужно заранее решить стратегию schema versioning (на уровне записи/таблицы), а не только “в общем”.
- **Как реализовать в Z00Z**:
  - В `z00z_crypto` унифицировать `to_compact_bytes()` и `try_from_compact_bytes()`.
  - Для `.wlt` объектов хранить ровно compact bytes + schema version.
  - **REVIEW** ✅ Это хорошо сочетается с текущим подходом: branch IDs уже задекларированы как часть on-disk/on-wire контракта.

---

## ❌ z00z_crypto/tari/ledger_wallet/wallet/src/crypto/commitment_and_public_key_signature.rs

### `CommitmentAndPublicKeySignature` (ledger wallet)

- **В чём идея**: HW/FFI слой не должен тянуть сложные generic’и/alloc/caches — ему нужен “плоский” ABI: фиксированные массивы байт и простой parsing.
  Смысл структуры: отделить “криптография как математика” (core) от “криптография как протокол обмена байтами” (device API).
  - **REVIEW** ✅ Идея корректная и стандартная для HW/FFI.
  - **REVIEW** ⚠️ Added value появится только когда реально делаете Ledger/FFI. До этого момента это может быть чистый over-engineering и “мертвый” код.
- **Что взять из Tari и почему полезно (+ tradeoffs)**: берём архитектуру “core generic, boundary concrete”, чтобы:
  - основной код Z00Z оставался тестируемым и расширяемым;
  - hardware signer мог работать в ограниченной среде.
    Tradeoffs:
  - Появляется второй набор типов/конвертеров.
  - Нужно синхронизировать canonical bytes между слоями.
  - **REVIEW** ✅ Формулировка про canonical bytes — ключевая; без roundtrip тестов это почти гарантированный источник багов.
- **Как реализовать в Z00Z**:
  - Если/когда появится HW signer (не MVP): в `z00z_crypto` добавить feature `hw` с `struct HwCapkSig { bytes: [u8; N] }`.
  - **REVIEW** ❌ В текущем Z00Z нет Ledger HW; этот пункт должен быть явно помечен как future/out-of-scope и не быть требованием для текущей реализации.
  - Ввести конвертеры `HwCapkSig::try_into_full()` и `HwCapkSig::from_full()`.
  - Обязательно покрыть тестом “roundtrip full → hw → full”.
  - **REVIEW** ⚠️ `N` должен быть зафиксирован и документирован как wire-format (включая endianness/encoding); иначе появятся несовместимости между версиями firmware/клиента.

---

## ❌ z00z_crypto/tari/crypto/src/compressed_key.rs

### `CompressedKey<T>::to_public_key` (lazy decompress + cache)

- **В чём идея**: хранить публичные ключи в compressed bytes (минимум места) и делать decompress только когда реально нужны group операции.
  Кэширование важно, потому что один и тот же ключ может участвовать в десятках операций за одну сессию (сканирование/верификация).
  - **REVIEW** ⚠️ “compressed-by-default” — полезно, но кэширование добавляет состояние/Sync сложности; если нет измеримого bottleneck’а, лучше начать без кэша.
- **Что взять из Tari и почему полезно (+ tradeoffs)**: берём “compressed-by-default” и ленивую декомпрессию.
  Почему полезно: `.wlt` и RPC станут компактнее; hot path верификаций получит меньше аллокаций/парсинга.
  Tradeoffs:
  - Кэш = состояние → нужно понимать потоки/Sync.
  - В constrained среде кэширование может быть запрещено.
  - **REVIEW** ✅ Хорошо, что вы прямо разделяете wasm/hw vs desktop/server. Это снижает шанс протащить `OnceCell/Mutex` в неподходящую среду.
- **Как реализовать в Z00Z**:
  - В моделях `.wlt` и wire типах хранить **только bytes**.
  - В runtime типе сделать два пути:
    - `try_decode_no_cache()` для wasm/hw.
    - `try_decode_cached()` для server/desktop (через `OnceCell`/mutex).
  - Обязательное правило: все “bytes→type” переходы используют canonical decoding.
  - **REVIEW** ⚠️ В Z00Z сейчас уже есть строгие boundary-проверки в `z00z_crypto` (например, AEAD envelope size checks). Тут важно продолжить ту же линию: один централизованный decode, никаких “partial decode” по месту.

### `ByteArray::from_canonical_bytes` (length guard)

- **В чём идея**: принимать вход только строго ожидаемой длины (например, 32/64 байта) прежде чем запускать decode кривой.
  Это не про “косметику”: неверная длина часто ведёт к разным веткам ошибок, которые могут стать oracle или DoS.
  - **REVIEW** ✅ Это очень практично и дешево; почти всегда стоит сделать.
- **Что взять из Tari и почему полезно (+ tradeoffs)**: берём fail-fast length guards как обязательное правило для boundary.
  Tradeoff: больше кода в conversion слоях, но это дешёвая страховка.
  - **REVIEW** ✅ Полностью согласуется с текущими практиками `z00z_crypto::aead_envelope` (жёсткие минимальные длины и ошибки).
- **Как реализовать в Z00Z**:
  - В `z00z_wallets` RPC adapters и `.wlt` decode: сначала `if bytes.len() != EXPECTED { return Err(..) }`.
  - Только после этого — `from_canonical_bytes`/`try_from_bytes`.
  - **REVIEW** ⚠️ Важно нормализовать ошибки на boundary (не выдавать подробные разные причины на удалённой стороне), иначе получится oracle по типу ошибки.

### serde human-readable vs bytes

- **В чём идея**: один и тот же тип должен сериализоваться:
  - в человекочитаемом виде (hex/base64) для JSON/logs;
  - в raw bytes для бинарных протоколов/хранилища.
    Это снижает риск “случайно отдали бинарь в JSON” или “сломали совместимость”, когда формат плавает.
  - **REVIEW** ✅ Added value высокий для RPC/логов/CLI; снижает вероятность “случайного” формата.
- **Что взять из Tari и почему полезно (+ tradeoffs)**: берём policy на уровне типа (не на уровне каждого вызова).
  Tradeoff: нужно строго зафиксировать, что именно hex/base64 и какой alphabet.
  - **REVIEW** ⚠️ Надо выбрать один формат и не менять (скорее hex lower без `0x`, как вы и пишете), иначе backwards-compat в API будет болезненным.
- **Как реализовать в Z00Z**:
  - В `Serialize/Deserialize` проверять `serializer.is_human_readable()`.
  - В human-readable использовать один формат по проекту (например, hex lowercase без `0x`).
  - **REVIEW** ✅ Реализация через `is_human_readable()` — правильное место для политики; не размазывайте её по RPC слоям.

### `ConstantTimeEq` + `Zeroize`

- **В чём идея**: если байты считаются секретом (пароль, seed, derived secret), то:
  - сравнение должно быть constant-time (не зависеть от позиции первого отличия);
  - память должна быть очищена при drop, чтобы не оставлять секреты в heap/stack.
  - **REVIEW** ✅ Это must-have для кошелька.
  - **REVIEW** ⚠️ Важно строго определить “что секрет”: public keys/commitments не надо zeroize, иначе будет лишняя сложность и ложное ощущение безопасности.
- **Что взять из Tari и почему полезно (+ tradeoffs)**: берём строгую дисциплину “секреты не сравнивать обычным `==` и не держать как `Vec<u8>` без zeroize”.
  Tradeoff: небольшая цена по CPU и необходимость аккуратно выбирать, какие поля “секрет”.
  - **REVIEW** ✅ Подход соответствует текущему использованию `SafePassword` и `Zeroizing` паттернов в проекте.
- **Как реализовать в Z00Z**:
  - Для `SafePassword`, seed phrases, master key bytes использовать `zeroize::Zeroizing<Vec<u8>>`.
  - Для сравнения (например, проверка парольного ключа) использовать `subtle::ConstantTimeEq`.
  - В логах/Debug печатать только redacted.
  - **REVIEW** ✅ Хорошая практическая формулировка; дополнительно стоит сделать линт/ревью-правило “запрещён Debug для секретных типов”.

---

## z00z_crypto/tari/common_types/src/key_branches.rs

### `TransactionKeyManagerBranch` + `get_branch_key`

- **В чём идея**: derivation branch — это не “просто enum”, а часть схемы данных: от него зависит, какие ключи будут получены из master seed сегодня и через год.
  Поэтому branch ids должны быть стабильны, документированы и тестируемы.
  - **REVIEW** ✅ В Z00Z это уже фактически реализовано: `z00z_crypto/src/key_branches.rs` помечает IDs как контракт и имеет стабильные roundtrip тесты.
- **Что взять из Tari и почему полезно (+ tradeoffs)**: берём подход “branch ids как schema contract”.
  Почему полезно: позволяет безопасно менять внутренности key manager, не ломая восстановление кошелька.
  Tradeoffs: любое переименование/перенумерация ветви — это уже миграция/новая версия схемы.
  - **REVIEW** ✅ Тут всё корректно; это не over-engineering, а необходимая дисциплина.
- **Как реализовать в Z00Z**:
  - Единственный источник истины: `z00z_crypto/src/key_branches.rs`.
  - Добавить snapshot-тест, который падает если меняются числовые IDs или список ветвей.
  - Для новых ветвей использовать зарезервированный диапазон и документировать назначение.
  - **REVIEW** ⚠️ Snapshot-тест на “список ветвей” может быть спорным (мешает эволюции); возможно достаточно теста на неизменность существующих значений + явного процесса добавления новых.

### ❌`from_byte` / ledger sync comment

- **В чём идея**: HW signer и софт должны одинаково интерпретировать `branch_id: u8`.
  Смысл структуры: исключить ситуацию “софт просит ветвь 7, железо думает, что это ветвь 8”.
  - **REVIEW** ✅ Корректный риск; особенно если branch id реально уходит в wire/APDU.
- **Что взять из Tari и почему полезно (+ tradeoffs)**: берём “wire-level branch id” как часть протокола между компонентами.
  Tradeoffs: расширение списка ветвей требует (a) резервирования новых id, (b) возможного version negotiation.
  - **REVIEW** ⚠️ Если Z00Z пока не интегрирует Ledger/HW, то отдельная “wire” модель ветвей может быть преждевременной (но полезно держать в уме).
- **Как реализовать в Z00Z**:
  - Публичный новыйтип `Z00ZKeyBranchId(u8)` (не `enum` напрямую), чтобы можно было безопасно хранить unknown значения.
  - `TryFrom<u8>` для известных ветвей и `Unknown(u8)` для forward-compat.
  - Тест “значения не меняются”.
  - **REVIEW** ⚠️ В текущей базе уже есть `Z00ZKeyBranch` как `repr(u8)` и `from_id() -> Option`. Новыйтип имеет смысл только если реально нужен forward-compat (unknown ветви в данных). Иначе это усложнение без added value.

### ❌`is_ledger_branch`

- **В чём идея**: разные backends (software keys vs ledger) поддерживают разный набор derivation paths.
  Смысл функции: не пытаться “сделать derive”, чтобы потом получить непонятную ошибку на устройстве — а отфильтровать заранее.
  - **REVIEW** ✅ Это здравый guardrail и снижает класс “операция ушла в backend и упала поздно/непонятно”.
  - **REVIEW** ⚠️ Added value зависит от реального наличия ≥2 backend’ов (software + ledger/remote). Если пока backend один, то есть риск over-engineering.
- **Что взять из Tari и почему полезно (+ tradeoffs)**: берём capability gating до выполнения операции.
  Tradeoff: больше явных ошибок, которые нужно отразить в UI/SDK.
  - **REVIEW** ✅ Правильный tradeoff: лучше явные ошибки, чем “где-то внутри девайса отказ”.
  - **REVIEW** ⚠️ Нужно чётко решить, где policy живёт: в `KeyManager` как единственном входе (рекомендуемо), а не размазывать проверки по UI/RPC.
- **Как реализовать в Z00Z**:
  - В `z00z_wallets` хранить `SignerBackendCapabilities { supported_branches: ... }`.
  - В `KeyManager` перед `derive/sign` валидировать `branch_id`.
  - Ошибка должна быть “SupportedByBackend” (понятная и стабильная).
  - **REVIEW** ⚠️ Название ошибки выглядит перевёрнутым: обычно ожидаешь `UnsupportedByBackend`/`BranchNotSupported`. Важно, чтобы это было стабильно в публичном API.
  - **REVIEW** ⚠️ В текущей кодовой базе такого типа capabilities пока не видно (поиск по `z00z_wallets/src` не находит `SignerBackendCapabilities`). Это будет новый слой wiring — стоит заранее ограничить его минимальным интерфейсом.

---

## z00z_crypto/tari/transaction_key_manager/src/storage/sqlite_db/imported_keys.rs

### `ImportedKeySql` / `NewImportedKeySql` + `Encryptable`

- **В чём идея**: хранить секретные данные так, чтобы:
  - их нельзя было “случайно” прочитать через индекс или частичный запрос;
  - поиск/сортировка работали только по **несекретным** полям.
    Конкретный смысл структуры `*Sql` + `Encryptable`: у модели есть “публичные поля” (id, timestamps, kind) и “секретный payload”, который всегда проходит через AEAD и AAD/domain.
  - **REVIEW** ✅ Идея “INDEX vs SECRETS” — правильная и хорошо масштабируется.
  - **REVIEW** ⚠️ В Z00Z уже есть `EncryptedObjectPayload`/`EncryptedObjectRecord` и `ObjectKindId` в `.wlt` (см. `DerivationState` и другие). Лучше вписаться в эту существующую модель, чем вводить параллельные “*Sql” сущности по аналогии с sqlite.
- **Что взять из Tari и почему полезно (+ tradeoffs)**: берём паттерн “INDEX vs SECRETS” как дисциплину хранения.
  Почему полезно: в Z00Z `.wlt` уже разделяет `ObjectKindId` и данные; это место естественно расширить на секретные записи (seed, imported keys, auth tokens) без разрастания “особых случаев”.
  Tradeoffs:
  - Нельзя делать поиск по секретному содержимому (это правильно, но иногда неудобно).
  - Требуется продумать AAD так, чтобы ciphertext нельзя было переиспользовать в другом контексте.
  - **REVIEW** ✅ Вы верно отмечаете AAD как ключевой элемент: без него легко получить “context confusion”.
  - **REVIEW** ⚠️ В текущем `z00z_crypto::aead_envelope::build_aad` используется NUL-разделитель (`"z00z.aead.v1\0" || domain || "\0" || context`). Это потенциально неоднозначно при произвольном `context`. Если вносите секреты/импортированные ключи — length-prefix (см. ниже) становится не “nice-to-have”, а почти обязательным.
- **Как реализовать в Z00Z**:
  - В `.wlt` (RedB) сделать отдельную таблицу/пространство для секретов: ключ = `(wallet_id, object_kind, object_id)`.
  - Индексируемые поля держать в отдельных таблицах (или как отдельные значения), без секретного payload.
  - AAD строить length-prefixed из стабильных идентификаторов: `schema_version || wallet_id || object_kind || object_id`.
    Мини-снимок формы данных:

  ```rust
  // pseudo-structure for redb
  struct SecretRecord { aad: Vec<u8>, ciphertext: Vec<u8> }
  // index table stores non-secret metadata only
  struct ImportedKeyIndex { object_id: [u8; 32], created_at: u64, label: String }
  ```
  - **REVIEW** ✅ Предложенная форма данных хорошо ложится на текущий `.wlt`: отдельный kind для секретного payload + отдельные index-таблицы (в `redb_wallet_store` уже есть `IndexTable`).
  - **REVIEW** ⚠️ Не хватает явного ответа: будут ли imported keys жить как новый `ObjectKindId` (рекомендуемо) или как часть существующего `Keys`? Сейчас `DerivationStatePayload` достаточно “плоский”; если добавить imported keys, важно не превратить `KeysPayload` в свалку.

### `to_imported_key` (decrypt + parse + zeroize)

- **В чём идея**: decrypted bytes должны существовать ровно столько, сколько нужно для:
  1) проверки целостности/версии,
  2) парсинга в typed структуру,
  3) немедленного очищения буфера.
     Смысл: минимизировать вероятность утечки через логи, дампы памяти или reuse allocator’а.
  - **REVIEW** ✅ Это правильная дисциплина для кошелька.
- **Что взять из Tari и почему полезно (+ tradeoffs)**: берём дисциплину “decrypt→parse→wipe” и нормализацию ошибок.
  Почему полезно: Z00Z уже имеет чувствительные объекты (`cipher_seed`, `.wlt` secrets); если дешифровка/парсинг раскиданы по коду, появляются разные ветки ошибок и возможные oracles.
  Tradeoff: код становится более “церемониальным” (обёртки, временные типы).
  - **REVIEW** ⚠️ Нормализация ошибок важна, но не переусердствовать: для локального UX иногда полезно различать “не тот пароль” vs “битые данные”. Если это RPC/удалённый интерфейс — нормализовать; если это локальный CLI — можно оставить более точные причины.
- **Как реализовать в Z00Z**:
  - В `z00z_wallets` раскрывающие API сделать one-shot (например, `reveal_seed_phrase_once`).
  - Все временные buffers держать как `Zeroizing<Vec<u8>>`.
  - Ошибки decrypt/parse/версии нормализовать в ограниченный набор (например, `InvalidPasswordOrCorruptData`).
    Пример формы:

  ```rust
  use zeroize::Zeroizing;
  
  let plaintext: Zeroizing<Vec<u8>> = aead.decrypt(aad, ciphertext)?;
  let obj = ImportedKey::decode(&plaintext)?;
  // plaintext wiped on drop
  ```
  - **REVIEW** ✅ Предложение `one-shot` API хорошее: снижает шанс “seed болтается в памяти дольше чем надо”.
  - **REVIEW** ⚠️ Важно также запретить случайный `Debug/Display` для структур, которые могут содержать plaintext (даже временно), иначе `Zeroizing` не спасёт от логов.

---

## z00z_crypto/tari/tari-wallet/src/key_manager_builder.rs

### `KeyManagerBuilder::with_view_key_and_spend_key` + `try_build`

- **В чём идея**: key manager — это не один объект, а “узел сборки” нескольких решений:
  - какой backend ключей (software seed / provided keys / ledger),
  - какое хранилище состояния деривации,
  - какие политики (capabilities, ограничения ветвей, режимы кэширования).
    Смысл builder’а: дать **одну точку**, где всё это соединяется и валидируется (а не в десятках мест “по месту использования”).
  - **REVIEW** ✅ Это хорошая инженерная идея (composition root), особенно когда появится Ledger/remote signer.
  - **REVIEW** ⚠️ Если пока конфигураций мало (1-2), builder может быть over-engineering. Но по мере роста кошелька это окупается.
- **Что взять из Tari и почему полезно (+ tradeoffs)**: берём принцип “composition root + typed capabilities”.
  Почему полезно: Z00Z уже имеет границы (`WltStore`, `WalletRedbKeyManager`). Builder позволяет:
  - централизовать выбор имплементаций,
  - избежать “ledger кошелёк случайно попытался derive неподдерживаемую ветвь”,
  - сделать поведение воспроизводимым в тестах.
    Tradeoffs:
  - Builder становится критичным узлом: его надо тестировать как матрицу конфигураций.
  - Вводится слой wiring (DI), который нужно поддерживать.
  - **REVIEW** ✅ Tradeoffs честно описаны.
  - **REVIEW** ⚠️ Я бы ограничил builder как internal сервисный модуль (не публичный API) до тех пор, пока не будет нескольких реально используемых вариантов.
- **Как реализовать в Z00Z**:
  - В `z00z_wallets/src/services/` добавить тонкий builder-модуль (или разместить builder рядом с `key_service.rs`/`wallet_session_manager.rs`).
  - Builder должен принимать: `WalletType`, `WltStore`, `SignerBackend`, и возвращать: `Arc<dyn KeyManager>` + `KeyManagerCapabilities`.
  - `try_build()` обязан:
    - проверять наличие/валидность wallet identity,
    - поднимать/проверять master key (если требуется),
    - инициализировать derivation state объект(ы) в `.wlt`.
      Мини-снимок формы:

  ```rust
  pub struct KeyManagerCapabilities {
      pub supports_branch: fn(Z00ZKeyBranchId) -> bool,
      pub can_sign: bool,
      pub can_derive_private: bool,
  }
  ```
  - **REVIEW** ⚠️ `supports_branch: fn(...) -> bool` выглядит странно как часть capabilities (это поведение, а не данные). Лучше хранить data (`HashSet`/bitset/диапазоны) или enum-политику, чтобы capabilities можно было сериализовать/логировать/тестировать.
  - **REVIEW** ✅ Вписывание в существующие границы (`WltStore`, `WalletRedbKeyManager`) — правильное направление.

---

## z00z_crypto/tari/transaction_key_manager/src/storage/sqlite_db/key_manager_state.rs

### `KeyManagerStateSql::set_state`

- **В чём идея**: derivation cursor (например, “какой индекс в ветви уже использован”) — это минимальная, но критичная часть состояния.
  Смысл `set_state`: сделать запись состояния:
  - идемпотентной (повторная запись того же значения безопасна),
  - атомарной (не оставляет “полузаписанное” состояние),
  - защищённой от случайного rollback.
  - **REVIEW** ✅ Важная часть: если cursor откатывается назад, кошелёк может переиспользовать адреса/ключи.
  - **REVIEW** ⚠️ В текущем `.wlt` уже есть `DerivationStatePayload { next_account_index, next_address_index }` (см. `z00z_wallets/src/db/redb_wallet_store.rs`). Спека говорит “cursor per branch”, но реализация сейчас про 2 конкретных счётчика. Нужно согласовать терминологию и модель данных.
- **Что взять из Tari и почему полезно (+ tradeoffs)**: берём “cursor = DB truth”:
  - восстановление кошелька зависит только от seed + cursor;
  - cursor не должен “прыгать назад” без явного recovery режима.
    Tradeoffs:
  - Нужно определить политику rollback (только в recovery, только под флагом, только с записью audit trail).
  - При ошибках записи cursor важно не потерять инвариант монотонности.
  - **REVIEW** ✅ Монотонность — ключевой инвариант; это должно быть тестами закреплено.
- **Как реализовать в Z00Z**:
  - Продолжать использовать `.wlt` как truth: `ObjectKindId::DerivationState`.
  - При `set_state` запрещать уменьшение `next_index` (или требовать `force=true`).
  - В `z00z_wallets/src/core/key/key_manager_redb.rs` добавить helper `update_branch_cursor(branch, new_cursor)`.
  - Тесты: (a) upsert, (b) monotonicity, (c) recovery override.
  - **REVIEW** ⚠️ В Z00Z потребуется решить: recovery override — это отдельная команда/режим? И как это отражается в `.wlt` (audit trail/метка)? Иначе риск “скрытого” rollback.

### `Encryptable::domain` (length-prefix)

- **В чём идея**: AAD (associated data) должен однозначно кодировать список частей.
  Проблема разделителей (например, NUL): разные наборы частей могут дать одинаковую строку/байты, если значения содержат разделитель.
  Смысл length-prefix: каждая часть кодируется как `[len_be_u32][bytes...]`, что устраняет неоднозначность.
  - **REVIEW** ✅ Это действительно устраняет класс коллизий из-за разделителей.
- **Что взять из Tari и почему полезно (+ tradeoffs)**: берём именно **length-prefix encoding** как безопасный стандарт.
  Почему полезно: Z00Z уже отмечал риск в `build_aad` — это прямое устранение класса атак “AAD collision / context confusion”.
  Tradeoffs:
  - Это меняет AAD → любой существующий ciphertext больше не расшифруется без миграции.
  - Нужно версионировать AAD (или envelope), чтобы поддержать постепенный переход.
  - **REVIEW** ⚠️ Сейчас `z00z_crypto::aead_envelope::build_aad` уже зафиксировал строковый формат `z00z.aead.v1\0...`. Переход на length-prefix почти неизбежно потребует явного `AadV2` + `envelope_version` и миграционного пути для уже созданных `.wlt`.
- **Как реализовать в Z00Z**:
  - В `z00z_crypto/src/aead_envelope.rs`:
    - добавить `AadV2` builder (length-prefix),
    - оставить `AadV1` только для backward-compat (если нужно),
    - связать выбор версии с `schema_version`/`envelope_version`.
      Мини-снимок builder:

  ```rust
  pub fn aad_len_prefixed(parts: &[&[u8]]) -> Vec<u8> {
      let mut out = Vec::new();
      for p in parts {
          out.extend_from_slice(&(p.len() as u32).to_be_bytes());
          out.extend_from_slice(p);
      }
      out
  }
  ```
  - **REVIEW** ✅ Нормальная форма, но важно фиксировать endianness/тип длины (u32 BE) как часть контракта.
  - **REVIEW** ⚠️ В Z00Z уже используется `build_aad(domain, context)` (domain string + context bytes). Перед внедрением `AadV2` нужно решить: останется ли “domain string” вообще, или домен станет отдельной частью `parts`.

---

## z00z_crypto/tari/crypto/src/keys.rs

### ❌`trait SecretKey` / `trait PublicKey`

- **В чём идея**: протокольные компоненты (tx builder, validator, hashing recipes) не должны быть “прикручены” к конкретной реализации кривой/ключа.
  Смысл trait-абстракции: код, который не зависит от конкретных типов ключей, проще тестировать, портировать и заменять backend (например, software → HW).
  - **REVIEW** ⚠️ В `z00z_crypto` уже re-export’ятся `tari_crypto::keys::SecretKey`/`PublicKey` трейты (`SecretKeyTrait`/`PublicKeyTrait`). Добавлять ещё один слой trait’ов стоит только если есть чёткая потребность и граница (иначе усложнение без added value).
- **Что взять из Tari и почему полезно (+ tradeoffs)**: берём decoupling, но с аккуратным ограничением области:
  - core протоколы/валидация могут быть generic;
  - storage/RPC/FFI — всегда concrete и canonical-bytes oriented.
    Tradeoffs:
  - Rust generics усложняют типы и могут ухудшить читаемость.
  - Абстракции иногда мешают “просто посмотреть, какой тип ключа используется”.
  - **REVIEW** ✅ Хорошо, что вы явно ограничиваете область generic’ов — это снижает “generic-сползание” по проекту.
- **Как реализовать в Z00Z**:
  - Не пытаться сделать весь проект generic.
  - Ограничить generic’и в `z00z_core`/`z00z_crypto` протокольных местах.
  - В `z00z_wallets` и RPC держать конкретные байтовые типы (compact keys/signatures).
  - **REVIEW** ✅ Это совпадает с текущей архитектурой: `z00z_wallets` хранит байты/конвертит на boundary, а `z00z_crypto` предоставляет примитивы.

### `SecretKey::from_uniform_bytes` (+ `WIDE_REDUCTION_LEN`)

- **В чём идея**: когда мы делаем scalar из хэша, безопасно делать это через wide-reduction фиксированной длины (обычно 64 байта).
  Смысл: все места, где “хэш → scalar”, должны давать одинаковое распределение и одинаковые edge-cases.
  - **REVIEW** ✅ Идея корректная; это устраняет расхождения между разными реализациями challenge derivation.
- **Что взять из Tari и почему полезно (+ tradeoffs)**: берём “one true reduction”:
  - один helper,
  - одна длина,
  - один набор тестов.
    Почему полезно: убирает дрейф между разными реализациями challenge/nonce derivation (особенно когда добавится HW signer).
    Tradeoff: нужно договориться, что длина фиксирована (64) и это часть протокола.
  - **REVIEW** ⚠️ Snapshot-тесты “input → scalar bytes” полезны, но их нужно привязать к явно документированному backend’у/кривой (сейчас это Tari/Ristretto). При смене backend такие тесты будут мешать.
- **Как реализовать в Z00Z**:
  - В `z00z_crypto` добавить `fn wide_reduce_64(bytes: [u8; 64]) -> SecretScalar`.
  - Все challenge/nonces/“hash-to-scalar” использовать только это.
  - Тесты: фиксированный вектор input → ожидаемый scalar bytes (snapshot).
  - **REVIEW** ✅ Главное — реально обеспечить, что ВСЕ места используют один helper (не только новые).

### ❌`PublicKey::batch_mul`

- **В чём идея**: multiscalar multiplication (MSM) — базовый примитив для batch verify, агрегаций и некоторых proof’ов.
  Смысл размещения в API: чтобы высокоуровневый код не пытался сам “собирать” MSM из низкоуровневых операций (это приводит к ошибкам и плохой производительности).
  - **REVIEW** ⚠️ Это потенциально over-engineering, если в Z00Z пока нет реальных batch verify hot-path’ов именно для подписей/доказательств вне range proofs (которые Tari уже оптимизирует). Сначала бенчмарки.
- **Что взять из Tari и почему полезно (+ tradeoffs)**: берём MSM как официальный путь оптимизации.
  Почему полезно: в Z00Z валидаторы и сканеры смогут проверять пачки подписей/доказательств быстрее.
  Tradeoff: backend кривой должен уметь эффективно делать MSM; иначе будет сложность без выигрыша.
  - **REVIEW** ✅ Хорошо, что вы прямо ставите условие “включать только если есть выигрыш”.
- **Как реализовать в Z00Z**:
  - В `z00z_crypto` сделать `msm(points: &[PublicKey], scalars: &[Scalar]) -> PublicKey`.
  - В валидаторах группировать проверки и использовать MSM.
  - Добавить microbench в `z00z_crypto/benches` и включать MSM только если есть выигрыш.
  - **REVIEW** ✅ Microbench обязателен, иначе невозможно объективно понять added value.

---

## z00z_crypto/tari/ledger_wallet/wallet/src/crypto/keys.rs

### ❌`RistrettoPublicKey` / `RistrettoSecretKey` (ledger wallet)

- **В чём идея**: “device-side” ключи — это не просто alias. Это типы, которые:
  - имеют фиксированный байтовый формат (для APDU/FFI);
  - избегают тяжёлых зависимостей, аллокаций и кэширования;
  - всё равно обязаны быть **канонически совместимы** с software-типами (чтобы подписи/ключи совпадали бит-в-бит).
    Смысл: позволить HW signer’у и софту говорить одним протокольным языком.
  - **REVIEW** ✅ Идея корректна.
  - **REVIEW** ⚠️ Added value нулевой до появления реального HW signer/APDU протокола. До этого лучше держать это как дизайн-заметку, а не как обязательный код.
- **Что взять из Tari и почему полезно (+ tradeoffs)**: берём идею “двойного представления”:
  - в core (software) можно иметь удобные типы, проверки, кэш;
  - на boundary (hw) — простые структуры с байтами.
    Почему полезно: Z00Z сможет поддержать `WalletType::Ledger` без переписывания wallet/tx логики.
    Tradeoffs:
  - Два набора типов → нужно поддерживать конвертеры и тестировать roundtrip.
  - Любая ошибка в canonical bytes создаст несовместимость между hw и software.
  - **REVIEW** ✅ Самый большой риск сформулирован правильно: несовместимость по bytes.
- **Как реализовать в Z00Z**:
  - Если/когда появится HW signer (не MVP): в `z00z_crypto` добавить feature `hw` и модуль `hw_types` (или `ledger_types`).
  - **REVIEW** ❌ В Z00Z сейчас нет Ledger HW; не стоит тащить `feature = "hw"`/ledger-типы в код как обязательную часть дизайна кошелька.
  - Определить `HwPublicKey([u8; 32])`, `HwSecretKey([u8; 32])` (или что соответствует вашей кривой).
  - Сделать `try_into_software()` через canonical decode.
  - Добавить тесты:
    - software→bytes→hw→software roundtrip
    - reject неканоничных байтов
      Мини-снимок:

  ```rust
  #[cfg(feature = "hw")]
  pub struct HwPublicKey(pub [u8; 32]);
  
  impl HwPublicKey {
      pub fn try_into_software(&self) -> Result<PublicKey, KeyError> {
          PublicKey::from_canonical_bytes(&self.0)
      }
  }
  ```

---

## z00z_crypto/tari/transaction_key_manager/src/memory_db_key_manager.rs

### `create_memory_db_key_manager_*`

- **В чём идея**: для тестов и симуляций нужен key manager, который:
  - не требует `.wlt`/RedB,
  - быстро создаётся,
  - детерминированно воспроизводится по seed,
  - поддерживает те же API, что и production key manager.
    Смысл: тесты должны проверять логику кошелька/tx, а не инфраструктуру диска.
  - **REVIEW** ✅ Это даёт реальную ценность: быстрее тесты/симуляции и меньше флейков из-за I/O.
  - **REVIEW** ⚠️ Риск расхождения поведения memory vs RedB (особенно вокруг cursor/state). Нужны “contract tests”: один набор тест-кейсов должен гоняться на обоих backend’ах.
- **Что взять из Tari и почему полезно (+ tradeoffs)**: берём “memory backend как полноценная имплементация трейта”, а не мок.
  Почему полезно: в Z00Z это напрямую ложится на `z00z_simulator` и на `z00z_wallets/tests`.
  Tradeoffs:
  - Нельзя смешивать с production (нужно feature gating).
  - Memory backend может не ловить классы багов дискового хранилища (schema/migrations).
  - **REVIEW** ✅ “Не мок” — правильно: моки часто тестируют не то.
  - **REVIEW** ⚠️ Feature gating важно сделать жёстким (например, `#[cfg(any(test, feature = "test-support"))]`), чтобы memory backend не оказался доступен в production бинарях.
- **Как реализовать в Z00Z**:
  - В `z00z_wallets` добавить `cfg(test)`/feature `test-support` и memory store для derivation cursors.
  - Реализовать `KeyManager` поверх `HashMap<(branch, index), key>` + `DerivationState`.
  - Экспортировать helper `create_test_key_manager(seed)` для интеграционных тестов.
    Мини-снимок:

  ```rust
  pub struct MemoryKeyManager {
      cursors: std::collections::HashMap<Z00ZKeyBranchId, u64>,
      // optional cache of derived publics
  }
  ```
  - **REVIEW** ⚠️ В текущей базе derivation state уже хранится как `DerivationStatePayload { next_account_index, next_address_index }` (не “branch → cursor”). Если переходите к branch-курсорам — это изменение модели состояния, нужно аккуратно описать миграцию и совместимость.

### `new_with_legacy_storage`

- **В чём идея**: верхний слой не должен знать, какое хранилище/бэкенд используется: тестовый, legacy, или новый.
  Смысл: API стабильный, а “как хранить state” — это внедряемая зависимость.
  - **REVIEW** ✅ Это хорошая архитектурная цель.
  - **REVIEW** ⚠️ Но “legacy storage” без чёткого определения может стать вечной прослойкой. Стоит сразу зафиксировать критерий удаления legacy.
- **Что взять из Tari и почему полезно (+ tradeoffs)**: берём DI через trait и явную композицию.
  Почему полезно: Z00Z уже имеет `WltStore` как boundary — можно тем же способом переключать key manager backend.
  Tradeoffs:
  - Wiring становится отдельной задачей (builder, конфиг, feature flags).
  - Нужно аккуратно контролировать миграции legacy→new.
  - **REVIEW** ✅ Вы верно связываете это с `WltStore`.
  - **REVIEW** ⚠️ Миграции должны быть “односторонними” и тестируемыми. Иначе получится режим, где данные могут быть прочитаны/записаны в двух форматах и расходиться.
- **Как реализовать в Z00Z**:
  - `trait KeyManager` оставить как стабильный контракт.
  - Иметь `KeyManagerRedb` и `KeyManagerMemory`.
  - Переключение делать только в одном месте: в сервисном слое `z00z_wallets/src/services/` (рядом с `key_service.rs`/`wallet_session_manager.rs`).
  - **REVIEW** ⚠️ В кодовой базе пока не видно `key_manager_builder.rs` (поиск не находит). Если добавлять — держать его тонким и максимально deterministic.

---

## ❌ z00z_crypto/tari/transaction_components/src/key_manager/memory_key_manager.rs

### `create_memory_key_manager_from_seed`

- **В чём идея**: “seed → key manager” должен быть одним понятным шагом.
  Если seed может приходить из разных источников (mnemonic, encrypted backup, provided keys), то memory key manager должен принимать **одинаковый тип seed container**, а не “случайный Vec`<u8>`”.
  - **REVIEW** ✅ Это реально предотвращает классы багов и упрощает API.
- **Что взять из Tari и почему полезно (+ tradeoffs)**: берём унификацию init flow.
  Почему полезно: в Z00Z уже есть `cipher_seed` и `.wlt` unlock flow — мы можем сделать единый вход для (a) тестов, (b) восстановления, (c) CLI инструментов.
  Tradeoffs:
  - Нужно выбрать один “канонический” seed container (и версионировать его формат).
  - **REVIEW** ✅ Tradeoff корректный: канонический контейнер нужен.
  - **REVIEW** ⚠️ В Z00Z уже есть `cipher_seed`/wallet encryption primitives; стоит избегать введения ещё одного “UnlockedSeed” формата без строгой необходимости.
- **Как реализовать в Z00Z**:
  - В `z00z_wallets/src/core/key/` добавить конструктор `KeyManager::from_unlocked_seed(seed: UnlockedSeed)`.
  - `UnlockedSeed` должен быть `Zeroize` и недоступен в сериализации.
  - Memory backend использует тот же `derive_recipe`, что и RedB backend.
  - **REVIEW** ✅ Обязательное требование: иначе тесты будут ложно-успешными.

### `MemoryKeyManagerBackend` (unimplemented trait)

- **В чём идея**: когда backend ещё не реализован (или часть функций не поддержана), он должен падать **явной, типизированной ошибкой**, а не возвращать “пустые значения”.
  Смысл: раннее обнаружение неправильных путей выполнения.
  - **REVIEW** ✅ “Fail loudly” в scaffold фазе — правильно.
- **Что взять из Tari и почему полезно (+ tradeoffs)**: берём принцип “fail loudly”.
  Почему полезно: в Z00Z Phase 1/2 есть много scaffold’ов — лучше получить стабильный `NotImplemented` в тесте, чем тихий баг в проде.
  Tradeoff: некоторые тесты/интеграции будут “красными” до реализации.
  - **REVIEW** ⚠️ Следить, чтобы `NotImplemented` не протёк в прод-пути. Лучше сделать это compile-time невозможным (feature flags), а не только runtime ошибкой.
- **Как реализовать в Z00Z**:
  - В `z00z_wallets` завести `WalletError::NotImplemented { feature: &'static str }`.
  - Все stub методы возвращают эту ошибку.
  - В местах, где функция “опциональна”, проверять capability до вызова.
  - **REVIEW** ✅ Связка “capability gating + NotImplemented” выглядит устойчиво.

---

## z00z_crypto/tari/crypto/src/ristretto/ristretto_keys.rs

### `RistrettoSecretKey` / `RistrettoPublicKey`

- **В чём идея**: concrete типы ключей — это место, где “зашиваются” инварианты:
  - как парсить канонические байты,
  - как скрывать секреты в Debug,
  - как очищать память,
  - как сравнивать в constant-time.
    Смысл: не размазывать эти правила по проекту.
  - **REVIEW** ✅ Это правильная точка концентрации security-инвариантов.
- **Что взять из Tari и почему полезно (+ tradeoffs)**: берём security-by-construction: сам тип делает небезопасные вещи сложными.
  Почему полезно: Z00Z уже работает с seed/master keys/derived keys; если ключи иногда “голые байты”, утечки и oracles становятся вероятнее.
  Tradeoffs:
  - Меньше удобства при дебаге.
  - Нужно дисциплинированно использовать эти типы везде.
  - **REVIEW** ⚠️ Дисциплина — самое слабое место: если API где-то начнёт принимать “сырые байты”, все преимущества исчезают. Нужны жёсткие boundary-правила и обзорные тесты.
- **Как реализовать в Z00Z**:
  - Убедиться, что секретные ключи всегда в обёртках с `Zeroize`.
  - Ввести `from_canonical_bytes` для публичных ключей и тесты на rejection.
  - Запретить `Debug` для секретов или сделать redacted.
  - **REVIEW** ✅ Для кошелька redacted Debug — почти обязательный.

### ❌`new_generator` (DST)

- **В чём идея**: если проект использует несколько “генераторов” (разные basepoints/commitment bases), они должны быть:
  - воспроизводимы (derivable),
  - доменно разделены, чтобы нельзя было спутать генератор для одного протокола с другим.
    Смысл DST: генератор определяется не только seed’ом, но и назначением.
  - **REVIEW** ⚠️ Added value зависит от того, действительно ли Z00Z будет генерировать свои генераторы. Если вы используете стандартные Ristretto basepoints/commitment factory из Tari, то этот пункт может быть преждевременным.
- **Что взять из Tari и почему полезно (+ tradeoffs)**: берём “DST — часть публичного контракта”.
  Почему полезно: Z00Z избегает cross-protocol reuse, и это особенно важно при генерации nonces/генераторов.
  Tradeoff: DST список должен быть стабильным и документированным.
  - **REVIEW** ✅ Верно: DST — это контракт.
- **Как реализовать в Z00Z**:
  - В `z00z_crypto/src/hash_domains.rs` завести явные домены для генераторов.
  - Все derive-генераторы строить только через этот домен.
  - **REVIEW** ⚠️ Стоит явно указать, где генераторы будут использоваться (commitments? signatures? proofs?). Иначе это выглядит как “crypto groundwork” без привязки к use-case.

### `RistrettoKdf` (domain tags)

- **В чём идея**: KDF — это не просто `H(seed||x)`. Это контракт:
  - domain tag фиксирует назначение (DEK vs signing vs nonce),
  - версия позволяет менять recipe со временем.
    Смысл: предотвращать reuse одного и того же материала в разных местах.
  - **REVIEW** ✅ Это даёт высокий added value и почти не стоит по сложности.
- **Что взять из Tari и почему полезно (+ tradeoffs)**: берём domain-tagging и версионирование.
  Почему полезно: в Z00Z много ключей (wallet master, db encryption key, tx keys). Domain tags — дешёвый способ исключить пересечения.
  Tradeoff: нужно централизованно управлять доменами и версиями.
  - **REVIEW** ⚠️ В Z00Z уже есть `hash_domains.rs` и домен для AEAD. Нужно не допустить “зоопарка” доменов без правил именования/версий.
- **Как реализовать в Z00Z**:
  - Продолжать расширять `hash_domains`.
  - Добавить `kdf_v1(domain, input)->[u8;64]` и производные helper’ы (wide reduce).
  - В `.wlt` метаданных хранить `kdf_version` для миграций.
  - **REVIEW** ⚠️ Хранить `kdf_version` имеет смысл только если вы реально допускаете смену KDF. Иначе это лишняя поверхность. Альтернатива: версия “зашита” в domain string.

### `batch_mul`

- **В чём идея**: массовые операции над точками/скалярами должны быть доступны как единый вызов, чтобы:
  - библиотека могла оптимизировать,
  - верхний уровень не писал “кривые” циклы.
  - **REVIEW** ⚠️ Повторяется с MSM выше. Есть риск дублирования: лучше один канонический примитив (MSM) и один слой-обёртка, если нужно.
- **Что взять из Tari и почему полезно (+ tradeoffs)**: берём MSM/batch primitives.
  Tradeoff: без хорошей реализации это может не дать выигрыша.
  - **REVIEW** ✅ Условие “только при выигрыше” — правильное.
- **Как реализовать в Z00Z**: как и выше для MSM — вынести в `z00z_crypto` и подтвердить выигрыш бенчами.
  - **REVIEW** ✅ Согласованно.

### `reveal()` + masked Debug

- **В чём идея**: секреты не должны “выпасть” в логи случайно (через `{:?}` или error chain).
  Смысл `reveal()`: сделать вывод секрета намеренным действием, которое можно ограничить (только в тестах/под флагом).
  - **REVIEW** ✅ Это хорошо согласуется с уже используемым `Hidden<T>` в `z00z_crypto`.
- **Что взять из Tari и почему полезно (+ tradeoffs)**: берём строгую политику логирования.
  Почему полезно: кошельки неизбежно логируют много событий; без redaction одна ошибка может слить seed/ключ.
  Tradeoff: дебаг сложнее (нужны специальные пути/флаги).
  - **REVIEW** ⚠️ Фича `dangerous_debug` должна быть очень явно ограждена (не включаться транзитивно, не включаться в release профилях).
- **Как реализовать в Z00Z**:
  - В `z00z_crypto`/`z00z_wallets` использовать единый тип `Hidden<T>`.
  - `Debug` печатает `<redacted>`.
  - `reveal()` доступен только в `cfg(test)` или под feature `dangerous_debug`.
  - **REVIEW** ✅ Это разумный минимум.

---

## z00z_crypto/tari/transaction_components/src/key_manager/tari_key_manager.rs

### `TariKeyManager::derive_private_key`

- **В чём идея**: деривация ключей должна быть:
  - детерминированной (для восстановления),
  - доменно разделённой (branch+назначение),
  - устойчивой к ошибкам инкодинга (канонический recipe).
    Смысл: чтобы “seed + состояние” однозначно определяли все ключи.
  - **REVIEW** ✅ Это core-инвариант кошелька; без этого восстановление ненадёжно.
- **Что взять из Tari и почему полезно (+ tradeoffs)**: берём фиксированный derivation recipe и DST.
  Почему полезно: Z00Z сможет восстановить кошелёк из seed и `DerivationState`, не храня приватные derived keys.
  Tradeoffs:
  - Recipe становится протокольным контрактом.
  - Любая ошибка в recipe ведёт к несовместимости восстановлений.
  - **REVIEW** ⚠️ Важно формализовать recipe как отдельный документ/тест-векторы, иначе “контракт” останется только в тексте.
- **Как реализовать в Z00Z**:
  - В `z00z_wallets/src/core/key/key_manager_impl.rs` (или рядом) зафиксировать функцию:
    `derive_scalar(seed, branch_id, index, domain_tag, version)`.
  - `branch_id` брать из `z00z_crypto/src/key_branches.rs`.
  - `index` хранить/обновлять в `.wlt` `DerivationState`.
    Мини-снимок recipe:

  ```rust
  // bytes = KDF(domain="z00z.derive.v1", seed || branch_id || be_u64(index))
  // sk = wide_reduce_64(bytes)
  ```
  - **REVIEW** ⚠️ Сейчас `DerivationStatePayload` хранит только account/address индексы. Ваша схема использует `(branch_id, index)` с `u64`. Нужно согласовать, какие именно индексы и какие ветви реально требуются в Phase 1.
  - **REVIEW** ✅ Привязка branch id к `z00z_crypto/src/key_branches.rs` — верная (стабильный контракт).

### `DerivedKey` / `DerivedPublicKey`

- **В чём идея**: “derived private key” — это производная сущность, которую почти никогда не нужно хранить на диск.
  Смысл типов `DerivedKey`/`DerivedPublicKey`:
  - private часть — всегда секрет, zeroize, не сериализуется;
  - public часть — можно кэшировать/хранить для ускорения.
  - **REVIEW** ✅ Это хороший баланс безопасности и производительности.
- **Что взять из Tari и почему полезно (+ tradeoffs)**: берём правило “secrets ephemeral, state persisted”.
  Почему полезно: уменьшает объем секретов в `.wlt`, упрощает смену пароля (меняем только wrapping master key).
  Tradeoffs:
  - Нужна unlocked-сессия и (возможно) небольшой in-memory cache.
  - Нужны аккуратные API, чтобы private key не утёк в форматирование/serde.
  - **REVIEW** ⚠️ Термин “WalletSession” уже занят в `z00z_crypto::key_branches` (есть ветвь `WalletSession`). Важно не создать путаницу: лучше назвать “UnlockedWallet”/“UnlockedContext”.
- **Как реализовать в Z00Z**:
  - В `z00z_wallets` ввести `WalletSession` (unlocked) с доступом к `KeyManager`.
  - `DerivedKey` держать как `Hidden<Zeroizing<[u8; 32]>>` (форма зависит от вашей кривой).
  - В `.wlt` хранить:
    - `DerivationState` (cursor)
    - опционально кэш public keys/addresses
  - **REVIEW** ⚠️ Кэш public keys/addresses в `.wlt` — это удобно, но может усложнить миграции/инварианты. Я бы начал без on-disk кэша, пока не будет измеримого bottleneck.

---

## ❌ z00z_crypto/tari/ledger_wallet/wallet/src/handlers/get_public_key.rs

### `handler_get_public_key`

- **В чём идея**: device handler — это **протокольная граница**, где мы принимаем произвольные байты от внешней среды и обязаны:
  - строго распарсить вход (длины, endianness, диапазоны значений),
  - вернуть ответ в стабильном wire-формате,
  - не допустить “частичного успеха” (например, ответить чем-то при некорректной длине).
    Смысл `versioned response`: можно расширять протокол без “ломания” старых клиентов.
  - **REVIEW** ✅ Идея правильная и соответствует best practices для HW/FFI.
  - **REVIEW** ⚠️ Но сейчас это выглядит как будущая работа: в текущей базе нет device protocol слоя. Это не должно блокировать Phase 1 кошелька.
- **Что взять из Tari и почему полезно (+ tradeoffs)**: берём минимальный, но строгий протокол:
  - framing: `[version: u8][payload_len: u16be?][payload...]` (или другая фиксированная схема),
  - строгие проверки до любых крипто-операций.
    Почему полезно: когда Z00Z добавит HW signer (или отдельный secure enclave), этот слой станет критичным для безопасности и совместимости.
    Tradeoffs:
  - Придётся поддерживать несколько версий (хотя бы decode старых).
  - Протокол нужно документировать и тестировать как API.
  - **REVIEW** ✅ Абсолютно; это “API”, а не “деталь реализации”.
- **Как реализовать в Z00Z**:
  - В `z00z_wallets` или `z00z_crypto` (где у вас будет device API) ввести модуль `device_protocol`:
    - `decode_request(bytes) -> RequestV{n}`
    - `encode_response(resp) -> Vec<u8>`
  - Добавить unit tests на:
    - неправильные длины (короткий/длинный input)
    - неправильный version
    - endianness
      Мини-снимок фрейминга:

  ```rust
  struct FrameV1 { version: u8, cmd: u8, payload: Vec<u8> }
  fn decode_frame(input: &[u8]) -> Result<FrameV1, ProtoError> {
      if input.len() < 2 { return Err(ProtoError::Truncated); }
      // parse version/cmd, then strict parse payload
      Ok(FrameV1 { version: input[0], cmd: input[1], payload: input[2..].to_vec() })
  }
  ```
  - **REVIEW** ⚠️ Псевдо-формат сейчас слишком свободный (где длина? где ограничения?). Для безопасности лучше фиксировать размер payload’ов и добавлять bounds (DoS) как вы уже делаете в `.wlt` (есть MAX caps).

---

## z00z_crypto/tari/ledger_wallet/wallet/src/handlers/get_public_spend_key.rs

### `handler_get_public_spend_key`

- **В чём идея**: некоторые публичные ключи (identity/view/spend) должны быть **стабильными** для кошелька и не зависеть от “какой индекс запросили”.
  Смысл: эти ключи — часть идентичности кошелька (адреса, авторизация, handshake), и их нельзя случайно “сдвинуть” из‑за неверного индекса.
  - **REVIEW** ✅ Важный инвариант; ошибка здесь реально может привести к потере средств/несовпадению адресов.
- **Что взять из Tari и почему полезно (+ tradeoffs)**: берём концепт фиксированных derivation путей для identity keys.
  Почему полезно: Z00Z сможет надёжно:
  - вычислять address/identity,
  - проверять соответствие кошелька `.wlt` и устройства,
  - избегать багов “не тот индекс → не тот ключ → потеря средств/несовпадение адреса”.
    Tradeoff: меньше гибкости — нельзя “переехать” на другой путь без миграции/версии.
  - **REVIEW** ✅ Tradeoff описан правильно: это действительно контракт.
  - **REVIEW** ⚠️ Нужна явная “identity schema version”: иначе вы зафиксируете пути навсегда без механизма эволюции.
- **Как реализовать в Z00Z**:
  - В `z00z_crypto/src/key_branches.rs` выделить ветви для identity keys (например, `WalletIdentitySpend`, `WalletIdentityView`).
  - Зафиксировать индексы (например `0`) для этих ветвей.
  - В `WalletIdentity` (в `.wlt`) хранить public keys/address, чтобы можно было сверять при подключении устройства.
    Мини-снимок:

  ```rust
  const IDENTITY_INDEX: u64 = 0;
  let spend_pk = km.derive_public(branch_wallet_identity_spend, IDENTITY_INDEX)?;
  ```
  - **REVIEW** ⚠️ Предлагаете добавлять новые ветви в `z00z_crypto/src/key_branches.rs`, но сейчас там ветви ориентированы на DB/session/backup. Если identity keys — это wallet-level крипто-идентичность, важно отделить “branches for encryption/AAD” от “branches for key derivation”, чтобы не смешать контракты.
  - **REVIEW** ✅ Хранить публичные identity ключи в `.wlt` для сверки с устройством — полезно и не секретно.

---

## z00z_crypto/tari/ledger_wallet/wallet/src/handlers/get_view_key.rs

### `handler_get_view_key`

- **В чём идея**: view key часто используется как “сканирующий” ключ (просмотр входящих/истории). Он должен быть:
  - детерминированным и воспроизводимым,
  - однозначно определённым derivation путём,
  - возвращаемым устройством в versioned wire-формате.
    Смысл: сканирование/рескан и восстановление должны работать одинаково на любом клиенте.
  - **REVIEW** ✅ Корректная постановка: view key как часть identity должен быть стабильным.
- **Что взять из Tari и почему полезно (+ tradeoffs)**: берём сочетание:
  - фиксированный путь derivation,
  - версия протокола ответа,
  - строгий parsing.
    Tradeoff: потребуется явная “wallet identity схема” (какие ключи существуют и для чего).
  - **REVIEW** ✅ Да, без описанной схемы эти handlers будут “магией”.
- **Как реализовать в Z00Z**:
  - Ввести `enum KeyType { View, Spend, ... }` в device protocol.
  - Сопоставить каждому `KeyType` фиксированную ветвь+индекс.
  - В `.wlt` сохранять `WalletIdentity` (public view/spend) и сверять при подключении устройства.
  - **REVIEW** ⚠️ Важно не хранить в `.wlt` “view private key” (если он вообще существует как секрет). Только public.
  - **REVIEW** ⚠️ Сейчас в кодовой базе есть `get_blockchain_tip`, auto-lock monitor и типизированные storage интерфейсы, но нет HW/device протокола. Эти секции нужно явно пометить как Phase 2, чтобы не смешивать приоритеты.

---

## z00z_crypto/tari/core/src/chain_storage/lmdb_db/composite_key.rs

### `CompositeKey<L>::try_from_parts` / `push`

- **В чём идея**: ключи в KV-сторах/DB часто строятся из нескольких частей (prefix + id + subkey). Если их собирать “как попало”, легко получить:
  - ключи слишком большого размера (DoS/память),
  - неоднозначные форматы,
  - баги “поменяли порядок частей”.
    Смысл bounded builder: ключи формируются строго, с ограничением длины и явной ошибкой overflow.
  - **REVIEW** ✅ Added value высокий: в `.wlt` уже есть caps на payload’ы (DoS bounds), и bounded keys логично дополняют это.
- **Что взять из Tari и почему полезно (+ tradeoffs)**: берём дисциплину composite keys.
  Почему полезно: Z00Z `.wlt` (RedB) хранит много видов объектов — индексы станут проще и безопаснее, если ключи будут типизированы.
  Tradeoff: больше типов/функций (но меньше неявных соглашений).
  - **REVIEW** ✅ Это правильная “низкоуровневая строгость”: больше типов сейчас → меньше багов потом.
- **Как реализовать в Z00Z**:
  - В `z00z_wallets/src/db/redb_wallet_store.rs` для ключей индексов добавить newtypes.
  - Вынести `CompositeKeyBuilder<const MAX: usize>` в `z00z_utils` или storage модуль.
    Мини-снимок:

  ```rust
  let key = CompositeKeyBuilder::<64>::new()
      .push(b"tx")?
      .push(&wallet_id_bytes)?
      .push(&be_u64(height))?
      .finish()?;
  ```
  - **REVIEW** ⚠️ Не стоит тащить это везде сразу: начать с 1–2 самых критичных индексов (tx/status/time), иначе рискуете сделать большой refactor без прямого выигрыша.

### `SmallBytes<L>` (stack vs heap)

- **В чём идея**: подавляющее большинство DB-ключей маленькие; хранить их на стеке дешевле, чем постоянно аллоцировать `Vec`.
  Смысл SSO: ускорить hot path и снизить давление на allocator.
  - **REVIEW** ⚠️ Это типичная premature optimization. Согласен с текстом: только после профилирования.
- **Что взять из Tari и почему полезно (+ tradeoffs)**: берём идею “оптимизацию включать только в hot paths”.
  Tradeoff: усложнение кода и риск багов в low-level storage.
  - **REVIEW** ✅ Хорошо, что прямо указан риск.
- **Как реализовать в Z00Z**: только после профилирования. До этого достаточно bounded `Vec<u8>` с caps.

### `section_iter` / `SectionIter::next_be_u64`

- **В чём идея**: если мы кодируем composite key, то decode должен быть рядом, иначе формат “уплывёт” и начнутся скрытые ошибки.
  Смысл `SectionIter`: делать разбор ключа пошагово (prefix → wallet_id → height), с явными ошибками.
  - **REVIEW** ✅ Это правильная пара к composite key builder.
- **Что взять из Tari и почему полезно (+ tradeoffs)**: берём paired encode/decode.
  Tradeoff: больше вспомогательных типов.
  - **REVIEW** ⚠️ Если decode используется только в тестах/диагностике, можно оставить проще. Делать итератор стоит, если есть реальный scan-by-prefix.
- **Как реализовать в Z00Z**:
  - Для ключей индексов, которые нужно декодировать (итерации/сканы), добавить `KeyPartsIter`.
  - Всегда использовать big-endian фикс. ширину для чисел.
  - **REVIEW** ✅ Фиксированная ширина + BE — хороший стандарт для сортируемых ключей.

### `OutputKey::new` / `InputKey::new`

- **В чём идея**: разные “классы” ключей похожи по полям, и их легко перепутать.
  Typed wrappers заставляют компилятор ловить перестановки частей.
  - **REVIEW** ✅ Это реальная практическая ценность: меньше прод-багов из-за “почти одинаковых” ключей.
- **Что взять из Tari и почему полезно (+ tradeoffs)**: берём типизацию ключей индексов.
  Tradeoff: больше типов, но меньше production-багов.
  - **REVIEW** ✅ Справедливый tradeoff.
- **Как реализовать в Z00Z**: в `.wlt` индексы оформить как `TxByHeightKey`, `UtxoByCommitmentKey`, и т.п.
  - **REVIEW** ⚠️ Не вводить десятки типов сразу. Начать с ключей, которые участвуют в сканировании/итерации и чаще всего ломаются при изменениях.

---

## ❌ z00z_crypto/tari/storage/src/key_val_store/key_val_store.rs

### `trait KeyValueStore`

- **В чём идея**: разные backends (RedB, SQLite, in-memory) имеют разные итераторы и разные требования по lifetime/borrowing.
  Callback-итерация (`for_each`) снимает часть сложностей и делает API единообразным.
  - **REVIEW** ✅ Это полезно, если Z00Z реально будет поддерживать несколько storage backend’ов.
  - **REVIEW** ⚠️ Если реальный backend один (RedB), то есть риск “абстракция ради абстракции”. Можно отложить до появления второго backend’а.
- **Что взять из Tari и почему полезно (+ tradeoffs)**: берём backend-agnostic iteration API.
  Почему полезно: Z00Z storage уже мульти-модульный, и такой API проще переиспользовать в wallet/core.
  Tradeoff: меньше гибкости (сложнее реализовать “streaming iterator” без аллокаций).
  - **REVIEW** ✅ Tradeoff честный.
- **Как реализовать в Z00Z**:
  - В `WltStore` оставить/добавить методы формата `for_each(prefix, f)`.
  - Для больших выборок добавить window/pagination параметры.
  - **REVIEW** ✅ Pagination/limit должны быть частью API по умолчанию (DoS protection).

### `IterationResult` + `for_each`

- **В чём идея**: итерация должна уметь “остановиться” по условию (нашли нужное, достигли лимита, превысили budget).
  Смысл `IterationResult::Break`: сделать early-exit частью API, а не частной договорённостью.
  - **REVIEW** ✅ Это хороший способ сделать bounded scans системным правилом.
- **Что взять из Tari и почему полезно (+ tradeoffs)**: берём bounded scans как защиту от DoS и случайных full scans.
  Tradeoff: нужно чётко документировать, что происходит при `Break` (commit/rollback/closing cursor).
  - **REVIEW** ⚠️ В RedB важно понять, что происходит с транзакциями/итераторами при early break. Документация/инварианты должны быть зафиксированы.
- **Как реализовать в Z00Z**:
  - В `.wlt` сканах всегда иметь лимит.
  - Для UI запросов “покажи последние N” — использовать `Break` после N.
  - **REVIEW** ✅ Это практично.

### `for_each_ok` / `filter_take`

- **В чём идея**: иногда при восстановлении/диагностике нужно “пройти как можно дальше”, даже если отдельные элементы битые.
  `for_each_ok` делает это явно (best-effort), а `filter_take` даёт bounded filtering.
- **Что взять из Tari и почему полезно (+ tradeoffs)**: берём инструменты для recovery/admin режимов.
  Tradeoff: best-effort может скрыть корень проблемы, поэтому надо логировать и собирать метрики.
  - **REVIEW** ✅ Да, best-effort только с явным режимом и телеметрией.
- **Как реализовать в Z00Z**:
  - Добавить `WalletRecoveryTool`/`wallet doctor` сценарии, которые используют best-effort.
  - В обычном runtime не использовать best-effort.
  - **REVIEW** ✅ Это важно: иначе можно “тихо” пропустить corruption.

---

## z00z_crypto/tari/comms/core/src/tor/control_client/commands/key_value.rs

### `KeyValueCommand` (`TorCommand`)

- **В чём идея**: протоколы (Tor control, RPC) лучше оформлять как “command objects”:
  - тип знает, как себя сериализовать,
  - тип знает, как распарсить ответ,
  - а внешний код только выполняет “send/recv”.
    Смысл: тестировать парсинг без сети.
  - **REVIEW** ✅ Хороший паттерн: transport vs protocol.
- **Что взять из Tari и почему полезно (+ tradeoffs)**: берём separation: transport vs protocol.
  Почему полезно: в Z00Z есть `z00z_networks/tor` и RPC слои — этот паттерн упрощает поддержку и диагностику.
  Tradeoff: на каждую команду появляется тип и тесты.
  - **REVIEW** ⚠️ Added value высокий только если Tor layer реально будет активно использоваться. Если Tor — опционален, можно начать с 1–2 команд и не масштабировать преждевременно.
- **Как реализовать в Z00Z**:
  - В `z00z_networks/tor` сделать `trait TorCommand { type Output; fn to_command_string(&self) -> String; fn parse(&self, lines: &[String]) -> Result<Self::Output, TorError>; }`.
  - Для критичных команд — golden tests с примерами ответов.
  - **REVIEW** ✅ Golden tests здесь реально полезны.

### `parse_responses` (drop trailing OK)

- **В чём идея**: реальные ответы протоколов часто содержат:
  - завершающие “OK/250 OK”,
  - пустые строки,
  - лишние пробелы,
    и если каждый парсер это обрабатывает по‑своему, появляются баги.
    Нормализация — это единая стадия “почистить вход”, после чего парсинг проще и стабильнее.
  - **REVIEW** ✅ Это снижает “разъехавшиеся” парсеры и edge-case баги.
- **Что взять из Tari и почему полезно (+ tradeoffs)**: берём tolerant parsing, но с телеметрией.
  Tradeoff: слишком tolerant parsing может скрыть несовместимость, поэтому надо логировать “удалили хвост OK” и неожиданные линии.
  - **REVIEW** ✅ Согласен: tolerant + telemetry, иначе дебаг ад.
- **Как реализовать в Z00Z**:
  - Общая функция `normalize_lines(lines) -> Vec<&str>`.
  - Если встретили неизвестный статус/формат — вернуть ошибку с raw lines (без секретов).
  - **REVIEW** ✅ Отлично: “без секретов” критично.

### `Output = Vec<Cow<'a, str>>`

- **В чём идея**: при частых командах (например, polling статуса) парсинг не должен создавать много `String`.
  `Cow` позволяет возвращать либо borrowed slices, либо owned строки, если пришлось трансформировать.
- **Что взять из Tari и почему полезно (+ tradeoffs)**: берём оптимизацию аллокаций только там, где есть hot loop.
  Tradeoff: сложнее lifetimes и сигнатуры.
  - **REVIEW** ⚠️ Это очень легко превратить в сложность ради микровыигрыша. Я бы начал с `String` и перешёл на `Cow` только после профилирования.
- **Как реализовать в Z00Z**:
  - Если это реально hot path — использовать `Cow<'a, str>`.
  - Иначе оставить `String` ради простоты.
  - **REVIEW** ✅ Согласен.

---

## z00z_crypto/tari/core/src/chain_storage/db_transaction.rs

### `DbTransaction` (builder)

- **В чём идея**: сложные обновления БД (особенно при reorg/rollback) лучше собирать как список операций (plan), а потом выполнять атомарно.
  Смысл:
  - можно логировать “что хотели сделать”,
  - можно тестировать план без настоящей БД,
  - можно гарантировать порядок.
  - **REVIEW** ✅ Added value высокий для wallet store: пакетные обновления и удобный дебаг.
  - **REVIEW** ⚠️ Но не стоит делать “планирование” везде: начать с мест, где реально несколько write’ов и нужен атомарный порядок.
- **Что взять из Tari и почему полезно (+ tradeoffs)**: берём “transaction plan” как объект.
  Почему полезно: в Z00Z wallet store будет делать пакетные апдейты (tx status updates, UTXO locks, sweepers). План облегчает отладку и корректность.
  Tradeoff: дополнительный слой абстракции и типов.
  - **REVIEW** ✅ Tradeoff стоит того, если есть batch updates.
- **Как реализовать в Z00Z**:
  - В `z00z_wallets/src/db/` добавить `DbTransactionPlan` (или `WltTxn`).
  - В `WltStore` добавить `apply(plan)`.
  - В тестах собирать plan и проверять список операций.
    Мини-снимок:

  ```rust
  enum WltOp { Put { key: Vec<u8>, val: Vec<u8> }, Del { key: Vec<u8> } }
  struct WltPlan { ops: Vec<WltOp> }
  ```
  - **REVIEW** ⚠️ Важно не логировать секретные значения (seed/keys). В `.wlt` payload’ы часто зашифрованы, но “план” может включать plaintext для индексов.

### `WriteOperation` enum

- **В чём идея**: закрытый enum операций заставляет каждый новый тип write-операции быть явно добавленным, а значит:
  - его можно логировать/метрить,
  - его можно покрыть тестами,
  - его можно запретить/ограничить в определённых режимах.
  - **REVIEW** ✅ Хорошая “auditability by design”.
- **Что взять из Tari и почему полезно (+ tradeoffs)**: берём auditability per variant.
  Tradeoff: расширение требует изменений enum (но это и плюс — изменения видны).
  - **REVIEW** ✅ Согласен.
- **Как реализовать в Z00Z**: в `z00z_wallets`/storage добавить `enum WriteOp` и использовать его в планах.

### `Display` for `DbTransaction` / `WriteOperation`

- **В чём идея**: когда что-то ломается, нужно видеть “что именно мы пытались записать”.
  Display/formatting должен:
  - быть читаемым,
  - не содержать секретов,
  - показывать ids/ключи/кол-во операций.
  - **REVIEW** ✅ Это ускоряет диагностику.
- **Что взять из Tari и почему полезно (+ tradeoffs)**: берём observability как часть дизайна.
  Tradeoff: риск утечек, если случайно логировать payload → надо логировать только размеры/идентификаторы.
  - **REVIEW** ✅ Критично для кошелька.
- **Как реализовать в Z00Z**:
  - Для write ops логировать только key prefix + hash(key) + len(val).
  - Для кошелька — можно логировать wallet_id/tx_id/height, но не seeds/keys.
  - **REVIEW** ✅ Хороший конкретный guideline.

### `DbKey::to_value_not_found_error`

- **В чём идея**: “not found” — это частая ошибка, и она должна быть:
  - типизированной (что искали?),
  - диагностируемой (по какому ключу?),
  - стабильной для обработки (UI/SDK).
    Смысл `to_value_not_found_error`: ключ сам знает, как описать ошибку.
  - **REVIEW** ✅ Typed “not found” реально упрощает обработку и UX.
- **Что взять из Tari и почему полезно (+ tradeoffs)**: берём богатые ошибки на storage boundary.
  Tradeoff: нужен typed key layer (newtypes), иначе нечему “знать”, что это за ключ.
  - **REVIEW** ✅ Это увязывается с typed composite keys выше.
- **Как реализовать в Z00Z**:
  - В `z00z_wallets/src/db/` ввести `enum WltKeyKind` и typed key wrappers.
  - Ошибка: `WalletStorageError::NotFound { kind, wallet_id, object_id }`.
  - На верхнем уровне маппить в понятные API ошибки (например `TxNotFound`).
  - **REVIEW** ⚠️ Для RPC важно разделить “not found” vs “wallet not unlocked/unauthorized”, чтобы клиенты не путались.

---

## z00z_crypto/tari/wallet/src/transaction_service/protocols/check_faux_transaction_status.rs

### `check_detected_transactions`

- **В чём идея**: это *reconciliation job* (фоновая “сверка реальности”), которая регулярно проверяет, совпадает ли **локальная** картина статусов транзакций с **цепочкой**.
  Ключевая мысль: локальный статус (в `.wlt`) — это *кэш*, который может стать неверным из‑за reorg/rollback/разных источников данных.
  Практически это решает два класса проблем:

  - **Reorg**: транзакция была “Confirmed” (или “Detected/Mined”), а потом блок исчез → локально она должна *деградировать* обратно в “Pending/Unconfirmed” (или “Unknown/Orphaned”, если такой статус есть).
  - **Ложные обнаружения / faux-detected**: мы “увидели” признаки транзакции (по output/commitment/receipt), но цепочка это больше не подтверждает → статус должен вернуться в более консервативный.
    Важно: цель не “доказать”, что tx существует, а *не удерживать ложную уверенность*.
  - **REVIEW** ✅ Added value высокий: reorg handling и “ложные подтверждения” — это реальные проблемы кошельков.
  - **REVIEW** ⚠️ Нужна строгая модель статусов и переходов, иначе получится “прыгающий” UX без предсказуемых правил.
- **Что взять из Tari и почему полезно (+ tradeoffs)**:

  - **Что**: периодическая сверка *только подмножества* транзакций, где риск расхождения максимален (recent confirmed/detected) — без полного рескана.
  - **Как**: берём tip height, выбираем окно `(tip - margin ..= tip)`, и для каждой “кандидатной” транзакции спрашиваем chain‑источник истины (по tx hash / по выходам / по receipt), после чего делаем строго определённый переход статуса.
  - **Зачем/почему полезно**: это превращает “reorg handling” из хаотичного edge-case в **регулярную процедуру**, которую можно тестировать и наблюдать (логами/метриками).
  - **Tradeoffs**:
    - дополнительная нагрузка на RPC и `.wlt` (лечится окнами, batching, rate limiting);
    - сложность в “источнике истины”: что именно проверять (tx hash vs outputs) зависит от доступных RPC.
    - UX: статус может “прыгать” — но это честнее, чем показывать “Confirmed”, которого нет.
  - **REVIEW** ✅ Логика “локальное = кэш” и tradeoffs описаны корректно.
  - **REVIEW** ⚠️ В Z00Z сейчас `ChainClient.get_transaction_status` помечен TODO (в impl есть TODO RPC-call). Значит реализация reconciliation должна быть привязана к реальному источнику истины, иначе это будет “монитор, который ничего не проверяет”.
- **Как реализовать в Z00Z**:

  1) **Где это живёт**: в `z00z_wallets/src/services/` отдельным монитором, по образцу background‑задач, которые уже есть (см. auto‑lock monitor в `z00z_wallets/src/services/wallet_service.rs`).
  2) **Источник tip**: использовать уже существующий `get_blockchain_tip` из `z00z_wallets/src/services/chain_service.rs` (или прокинуть через `AppService`).
  - **REVIEW** ✅ Это реально существует в кодовой базе; хороший якорь.
  3) **Какие записи проверять**:
     - взять из `z00z_wallets/src/core/storage/tx_storage.rs` и `.../tx_storage_impl.rs` операции вида `list_by_status(TxStatus::Confirmed)` и затем фильтровать по `confirmed_height` в окне;
     - если появится отдельный статус “Detected”, добавить аналогичный индекс/листинг.
  - **REVIEW** ⚠️ Уже есть `TxStorage.list_by_status(...)` и `TxStatus` в адаптерах/RPC. Нужно проверить, есть ли “confirmed_height” в записи. Если нет — придётся расширить модель хранения, иначе “окно” по height не реализуем.
  4) **Как спрашивать chain**:
     - базовый вариант: через `ChainClient.get_transaction_status` (`z00z_wallets/src/core/chain/chain_client.rs`, сейчас есть TODO в impl).
  - **REVIEW** ⚠️ Это ключевой blocker: пока `get_transaction_status` не реализован (TODO), reconciliation job лучше описать как Phase 2 и не смешивать с обязательной частью кошелька.
     - продвинутый вариант (если Z00Z опирается на UTXO/commitments): добавьте `ChainClient.get_outputs_status(commitments[..])` и используйте это как более надёжный источник.
  5) **Как обновлять**:
     - хранить переходы как небольшую state machine: `Confirmed -> Pending` если chain говорит “не найден/не подтверждён”; `Pending -> Confirmed` если chain дал включение.
     - обновление статуса должно быть атомарным вместе с receipt‑полями (height/hash/timestamp), если они есть.
    - **REVIEW** ✅ Идея “маленькой state machine” правильная: это делает поведение тестируемым.
    - **REVIEW** ⚠️ Нужно явно определить, какие chain ответы считаются “not found” vs “unconfirmed”, иначе возможны ложные деградации (особенно если RPC нестабилен).
  6) **События**: при изменениях эмитить `TransactionEvent` из `z00z_wallets/src/adapters/rpc/types/events.rs`.
    - **REVIEW** ✅ События как UX-оптимизация — уместно.
    - **REVIEW** ⚠️ Эмитить события нужно только после успешного commit в `.wlt`, иначе клиенты увидят событие без соответствующего состояния.

  Пример (Z00Z‑ориентированный, псевдокод):

  ```rust
  pub struct TxReconcileConfig {
      pub interval_secs: u64,
      pub safety_height_margin: u64,
      pub max_batch: usize,
  }
  
  pub async fn run_tx_reconciler(cfg: TxReconcileConfig, wallet_id: WalletId, chain: Arc<dyn ChainClient>, store: Arc<dyn TxStore>, events: TxEventSink) {
      let mut interval = tokio::time::interval(std::time::Duration::from_secs(cfg.interval_secs));
      loop {
          interval.tick().await;
  
          let tip = chain.get_tip_height()?;
          let check_from = tip.saturating_sub(cfg.safety_height_margin);
  
          // 1) candidates: recently confirmed
          let mut candidates = store.list_by_status(wallet_id, TxStatus::Confirmed)?;
          candidates.retain(|tx| tx.confirmed_height.unwrap_or(0) >= check_from);
          candidates.truncate(cfg.max_batch);
  
          // 2) reconcile
          for tx in candidates {
              let chain_status = chain.get_transaction_status(&tx.tx_hash)?;
              let new_status = decide_transition(tx.status, chain_status);
              if new_status != tx.status {
                  store.update_status(wallet_id, tx.tx_id, new_status)?;
                  events.try_publish(TransactionEvent::Pending { wallet_id, tx_id: tx.tx_id, timestamp: now_ms() });
              }
          }
      }
  }
  ```

### `SAFETY_HEIGHT_MARGIN` + `check_height`

- **В чём идея**: *bounded reorg-aware window* — вместо “перепроверять всё всегда” мы перепроверяем только **скользящее окно** по высотам рядом с tip.
  Интуиция:
  - reorg почти всегда ограничен глубиной (пусть и не гарантированно);
  - самое “ломкое” место — последние N блоков;
  - значит, достаточно держать локальные статусы корректными в окне последних N блоков, а старые “далеко подтверждённые” можно считать стабильными.
    `check_height` — это вычисление “с какой высоты имеет смысл пересмотреть статусы”, обычно `max(0, tip - margin)`.
  - **REVIEW** ✅ Это практичный и стандартный подход; added value высокий.
  - **REVIEW** ⚠️ Не обещайте “reorg почти всегда ограничен”: это эвристика. В тексте стоит явно отметить “защита от типичных reorg, не гарантия”.
- **Что взять из Tari и почему полезно (+ tradeoffs)**:
  - **Что**: параметр `SAFETY_HEIGHT_MARGIN` как *явный контракт* “на какую глубину мы признаём reorg возможным”.
  - **Как**: использовать margin не только в reconciliation, но и в любых задачах “догоняем цепочку / проверяем подтверждения / считаем confirmations”.
  - **Зачем**: это делает стоимость работы предсказуемой (O(margin) вместо O(chain)).
  - **Tradeoffs**:
    - если margin слишком мал → можно пропустить deep reorg (редко, но возможно);
    - если слишком велик → увеличится нагрузка на RPC/DB.
      Практический вывод: margin должен быть **конфигом сети** (devnet/testnet/mainnet) и иметь sane default.
  - **REVIEW** ✅ Конфиг по сети — правильная постановка.
  - **REVIEW** ⚠️ Желательно также иметь “ручной режим”: по запросу пользователя/админа запускать более глубокую проверку (recovery/doctor), не меняя default margin.
- **Как реализовать в Z00Z**:
  - Ввести конфиг (например `TxReconcileConfig.safety_height_margin`) и прокинуть его через `WalletService`/`AppService`.
  - Использовать tip‑информацию из `z00z_wallets/src/services/chain_service.rs`.
  - Для наблюдаемости:
    - логировать *факт деградации* статуса (Confirmed→Pending) как потенциальный reorg‑сигнал;
    - в будущем можно добавить метрику “reorg_rollbacks_total”.
  - Если Z00Z позже реализует checkpoints для скана (см. TODO в `z00z_wallets/src/core/chain/scan_engine_impl.rs`), `check_height` должен согласовываться с checkpoint‑логикой (rollback чекпоинта внутри окна).
  - **REVIEW** ✅ Хорошее замечание про согласование с checkpoint’ами.
  - **REVIEW** ⚠️ Сейчас это зависит от будущей реализации scan engine. Важно пометить этот кусок как “не блокирует текущую реализацию reconciliation”.

### `TransactionEvent::*` publishing

- **В чём идея**: события — это *сигналы изменений*, а не источник истины.
  То есть система должна работать корректно даже если:
  - подписчиков нет;
  - подписчик временно отвалился;
  - события потерялись или пришли не по порядку.
    Тогда события используются как оптимизация для UX (быстро обновить UI), а “истина” всегда восстанавливается из `.wlt` через запросы истории/деталей.
  - **REVIEW** ✅ Это правильная модель (eventual consistency), уменьшает связность.
- **Что взять из Tari и почему полезно (+ tradeoffs)**:
  - **Что**: best‑effort publishing (не ломает основной поток при ошибках доставки) + событийная “слабая связь” между core и UI.
  - **Как**: публиковать событие только тогда, когда реально произошёл переход статуса (и желательно после успешного commit в storage).
  - **Зачем**: UI/SDK могут подписаться и перестать агрессивно поллить.
  - **Tradeoffs**:
    - события не гарантируют доставку → всегда нужен API “снимка состояния” (history/details);
    - при reorg могут быть “обратные” события (Confirmed→Pending), и клиенты должны это корректно отображать.
  - **REVIEW** ⚠️ Для клиентов нужно явно описать порядок/идемпотентность событий: например, событие должно содержать `tx_id` + монотонный `updated_at`/`event_seq`, иначе out-of-order доставкой можно “откатить UI назад”.
- **Как реализовать в Z00Z**:
  - Z00Z уже имеет `TransactionEvent` в `z00z_wallets/src/adapters/rpc/types/events.rs` — используйте его как стандарт.
  - Правило: **сначала** обновляем `.wlt`, **потом** эмитим событие (иначе клиенты увидят событие и не найдут состояние).
  - Snapshot уже фактически есть через RPC методы `wallet.tx.get_transaction_details` и `wallet.tx.get_transaction_history` — это и есть “точка восстановления” для клиентов.
  - Для reconciliation (см. выше) при деградации статуса эмитить `TransactionEvent::Pending`, а при повторном подтверждении — `TransactionEvent::Confirmed` с актуальными `block_height`/`confirmations`.
  - Для тестов:
    - unit: state machine переходов (Confirmed→Pending при `not_found` от chain);
    - integration: симулировать “событие потерялось” → клиент делает `get_transaction_history` и всё равно видит корректное состояние.
  - **REVIEW** ✅ Отличный набор тестов; именно так ловятся race/out-of-order проблемы.

---

## z00z_crypto/tari/tari-cli/src/transactions/one_sided_transaction.rs

### `create_unsigned_transaction` (idempotency)

- **В чём идея**: идемпотентность в построении/отправке транзакций означает: “один и тот же запрос (с тем же ключом) не создаёт вторую транзакцию”.
  Это критично для кошельков, потому что сеть/клиент/мобильная ОС часто заставляют делать ретраи:

  - RPC‑клиент повторил запрос из‑за таймаута,
  - UI повторно нажал кнопку,
  - приложение перезапустилось между “build” и “broadcast”.
    Без идемпотентности вы получаете два разных tx, два разных набора входов/выходов и очень неприятные “двойные списания” на уровне UX.
    На практике идемпотентность — это *контракт*: пока ключ жив, операция либо возвращает прежний результат, либо возвращает “в процессе”.
  - **REVIEW** ✅ Added value очень высокий: это прям защита от дублей при ретраях.
  - **REVIEW** ⚠️ Важно формализовать, что входит в “тот же запрос”: параметры должны быть частью записи, чтобы конфликт “тот же ключ, другие параметры” надёжно ловился.
- **Что взять из Tari и почему полезно (+ tradeoffs)**:

  - **Что**: уникальный `idempotency_key` связывает внешний запрос и внутренний “pending tx” / результат операции.
  - **Как**: при новом запросе с тем же ключом система сначала проверяет “не было ли уже выполнено” и:
    - возвращает ранее созданный pending tx (или готовый ответ),
    - или продолжает незавершённую попытку.
  - **Зачем**: делает `tx.send` безопасным для ретраев и нестабильных сетей.
  - **Tradeoffs**:
    - нужно где-то хранить соответствие ключ→результат и политику TTL;
    - нужно определиться с семантикой “тот же ключ, но другие параметры” (обычно это ошибка).
  - **REVIEW** ✅ Да — это должна быть доменная ошибка, а не “переписали запись”.
- **Как реализовать в Z00Z**:

  - В Z00Z уже есть тип `IdempotencyKey` и даже `IdempotencyCacheEntry` (см. `z00z_wallets/src/adapters/rpc/types/security.rs`).
  - Сейчас в `z00z_wallets/src/adapters/rpc/methods/tx_impl.rs` используется in‑memory `idempotency_cache` + TTL `TX_SEND_IDEMPOTENCY_TTL_MS` — это хороший старт, но:
    - **не переживает рестарт процесса**,
    - не даёт гарантии при нескольких процессах/инстансах.
  - **REVIEW** ✅ В spec правильно отмечены ограничения текущей реализации.
  - **REVIEW** ⚠️ Перенос в `.wlt` — верное направление, но нужно учитывать конкуренцию: если два запроса одновременно с одним ключом, нужна атомарная операция `put_if_absent` на storage boundary.
  - Доработка до “Tari‑уровня” для продакшена:
    1) Перенести cache в `.wlt` (RedB): таблица `idempotency_cache` с ключом `(wallet_id, method, idempotency_key)`.
    2) Хранить либо “готовый ответ” (как JSON/CBOR), либо `tx_id/tx_hash` + минимальный summary.
    3) Индекс для TTL: можно повторно использовать паттерн `index_pending_by_status_expiry` (см. `INDEX_PENDING_STATUS_EXPIRY_TABLE` в `z00z_wallets/src/db/redb_wallet_store.rs`) или добавить отдельный индекс `index_idempotency_by_expiry`.
    4) При конфликте ключа:
       - если параметры совпадают → вернуть cached response;
       - если параметры отличаются → вернуть domain‑ошибку “IdempotencyKeyConflict”.
  - **REVIEW** ✅ Это правильная семантика.
  - **REVIEW** ⚠️ Хранить “готовый ответ как JSON/CBOR” может быть хрупко при изменении схемы ответа. Более стабильный минимум — хранить `tx_id` + `created_at` + status и пересобирать ответ из `.wlt` при повторе.

  Мини-снапшот (концептуально):

  ```rust
  // pseudo-interface near storage boundary
  pub trait IdempotencyStore {
      fn get(&self, wallet: &WalletId, method: &str, key: &IdempotencyKey) -> Option<IdempotencyCacheEntry>;
      fn put(&mut self, entry: IdempotencyCacheEntry);
      fn purge_expired(&mut self, now_ms: u64, max: usize) -> usize;
  }
  ```

### `expires_at` + UTXO lock TTL

- **В чём идея**: любой “lock” в кошельке (резервация входов/выходов, pending tx, временная блокировка средств) должен быть **lease‑ом**, а не вечной блокировкой.
  То есть запись о резервации должна иметь `expires_at`, чтобы:

  - падение приложения не оставляло средства заблокированными навсегда;
  - ретраи/идемпотентность могли корректно “дожать” операцию в рамках TTL;
  - UI мог честно показать “резервация истекает через N секунд”.
    Важно: TTL не “магия консенсуса”, это *wallet-level safety net*.
  - **REVIEW** ✅ Must-have для надёжного UX.
  - **REVIEW** ⚠️ TTL должен быть согласован с реальными задержками сети/коммитов; иначе вы получите “само-отмены” и повторные траты.
- **Что взять из Tari и почему полезно (+ tradeoffs)**:

  - **Что**: TTL‑локи на spendable items (UTXO/asset outputs) и связанные “pending transactions”.
  - **Как**: при создании pending tx помечаем входы/выходы как “reserved until expires_at”. Если expires_at прошёл — запись можно освободить.
  - **Зачем**: предотвращает “вечные локи” и снижает необходимость ручного repair.
  - **Tradeoffs**:
    - нужен sweeper/cleanup (фоновая задача), иначе expired записи копятся;
    - при слишком малом TTL вы получите ложные отмены на медленных сетях.
  - **REVIEW** ✅ Tradeoffs описаны правильно.
- **Как реализовать в Z00Z**:

  - Ввести явную структуру `Reservation` (lease) на storage уровне и связать её с tx (tx_hash/tx_id).
  - Хранение:
    - таблица `reservations` в `.wlt` (RedB),
    - индекс по `(status, expires_at)` — у Z00Z уже есть `index_pending_by_status_expiry` в `z00z_wallets/src/db/redb_wallet_store.rs`, его можно расширить/переиспользовать.
  - Sweeper:
    - сделать periodic task в `z00z_wallets/src/services/` по образцу фоновых задач (как auto-lock monitor в `wallet_service.rs`): раз в N секунд/минут удаляет expired reservations и снимает “reserved” флаги.
  - **REVIEW** ✅ Хорошо, что привязано к существующему паттерну фоновых задач (auto-lock monitor реально есть).
  - **REVIEW** ⚠️ Обязательно обеспечить атомарность: “сняли reservation” и “обновили UTXO/output state” должны быть одним storage plan/транзакцией, иначе возможны частичные состояния.
  - UX/API:
    - при `wallet.tx.send_transaction` возвращать `expires_at` в ответе (или в `TxInfo`), чтобы клиент понимал TTL.

  Псевдологика cleanup:

  ```rust
  loop {
      interval.tick().await;
      let now = time.now_ms();
      let expired = store.find_expired_reservations(now, max_batch)?;
      store.release_reservations(expired)?;
  }
  ```

---

## z00z_crypto/tari/tari-cli/src/db/pending_transactions.rs

### `create_pending_transaction` (unique violation mapping)

- **В чём идея**: ошибки уровня БД (например “unique constraint violation”) — это *не то*, что должен видеть клиент.
  Идея в том, чтобы на границе storage превратить “техническую причину” в **доменно‑смысловую ошибку**, которую можно:
  - показать человеку,
  - обработать программно (например, retry/return cached result),
  - залогировать без утечек.
    В контексте pending tx это обычно означает: “уже есть pending tx для этого ключа/запроса”.
  - **REVIEW** ✅ Это правильная граница ответственности: storage errors не должны протекать наружу.
- **Что взять из Tari и почему полезно (+ tradeoffs)**:
  - **Что**: явное маппирование constraint‑ошибок в domain errors (например Duplicate/AlreadyExists).
  - **Как**: на storage boundary перехватываем конкретные error kinds и возвращаем `WalletError::DuplicateIdempotencyKey`/`WalletError::PendingTxAlreadyExists`.
  - **Зачем**: это делает RPC слой проще: он не парсит строки драйвера БД.
  - **Tradeoffs**:
    - нужно поддерживать error taxonomy и тесты на маппинг;
    - для RedB (не SQL) “unique violation” проявляется иначе (overwrite/insert semantics), поэтому аналогом будет “ключ уже существует” при `insert` API.
  - **REVIEW** ✅ Хорошо, что учтена специфика RedB.
  - **REVIEW** ⚠️ Нужно явно описать, какую семантику вставки использует ваш store (overwrite vs insert-only). Если overwrite возможен по умолчанию, то идемпотентность может быть сломана.
- **Как реализовать в Z00Z**:
  - Ввести в storage API явный метод `put_if_absent(...) -> Result<Created|Existing, Err>` для idempotency/pending tx.
  - На уровне RPC:
    - если “Existing” → вернуть cached response (идемпотентность),
    - если конфликт параметров → вернуть доменную ошибку.
  - Ошибку маппить в JSON-RPC error через существующий механизм `map_wallet_error_to_rpc` (`z00z_wallets/src/adapters/rpc/error_mapping.rs`).
  - **REVIEW** ✅ Привязка к существующему маппингу ошибок — правильно.

### `find_expired_pending_transactions` / `cancel_pending_transactions_by_ids`

- **В чём идея**: pending‑объекты с TTL требуют двух примитивов:

  1) быстро найти просроченные (`find_expired_*`),
  2) массово отменить/очистить (`cancel_*_by_ids`).
     Почему это выделяется в отдельные функции: sweeper должен быть **дешёвым** и **предсказуемым** — без “сканировать всё и фильтровать в памяти”.
  - **REVIEW** ✅ Added value высокий: иначе производительность деградирует со временем.
- **Что взять из Tari и почему полезно (+ tradeoffs)**:

  - **Что**: индексируем expiry и делаем bulk‑операции.
  - **Как**: хранить `(status, expires_at)` в индекс‑ключе → тогда `find_expired` это range‑scan “до now”.
  - **Зачем**: bounded work + отсутствие деградации производительности со временем.
  - **Tradeoffs**:
    - bulk‑отмена должна быть атомарной относительно снятия резерваций (иначе можно “отменить tx, но оставить locked inputs”).
  - **REVIEW** ✅ Ключевой инвариант.
- **Как реализовать в Z00Z**:

  - Уже есть готовый паттерн индекса: `INDEX_PENDING_STATUS_EXPIRY_TABLE` в `z00z_wallets/src/db/redb_wallet_store.rs`.
  - **REVIEW** ✅ Отлично, что это уже есть — это снижает объём новой работы.
  - Сделать в storage слой операции:
    - `list_pending_by_status_expiry(status, before_ms, limit)`
    - `cancel_pending_by_ids(ids)` (bulk update)
  - В `z00z_wallets/src/services/tx_service.rs` (или отдельном `pending_tx_sweeper.rs`) добавить periodic task:
    - выбирает expired batch,
    - отменяет,
    - эмитит `TransactionEvent::Cancelled`/`Failed` (в зависимости от семантики) и/или `WalletEvent::BalanceChanged`.
  - **REVIEW** ⚠️ Нужно строго определить семантику “Expired”: это Cancelled? Failed? отдельный статус? Иначе клиенты будут по-разному интерпретировать.

  Снапшот идеи для ключа индекса (без копирования Tari):

  ```text
  index_pending_by_status_expiry key := status_u8 || be_u64(expires_at_ms) || tx_id_bytes
  value := empty | object_key
  ```

---

## z00z_crypto/tari/tari-cli/src/models/pending_transactions_status.rs

### `PendingTransactionStatus` (`Display`/`FromStr`)

- **В чём идея**: статусы — это часть “wire contract” и/или storage contract. Как только вы начали сериализовать их наружу (RPC/CLI/файлы), любая “косметическая правка” строк превращается в breaking change.
  Поэтому `Display`/`FromStr` важны не как “удобство печати”, а как **гарантия стабильности представления**.
  Ещё одна причина: строковые статусы часто используются в логах/метриках/алертах — стабильность даёт возможность надёжно агрегировать.
  - **REVIEW** ✅ Это правильный акцент: строки — это контракт, не “косметика”.
- **Что взять из Tari и почему полезно (+ tradeoffs)**:

  - **Что**: фиксированный набор строк + строгий парсер.
  - **Как**: `FromStr` принимает только известные значения; неизвестные → ошибка, а не “default”.
  - **Зачем**: fail‑fast защищает от тихой коррозии данных (особенно при миграциях).
  - **Tradeoffs**:
    - если у вас уже есть данные со “старыми строками”, нужен compat слой (alias‑mapping) или миграция.
  - **REVIEW** ⚠️ Очень важно заранее решить: допускаете ли alias’ы (compat) или делаете миграции. Для кошелька часто безопаснее миграции, чтобы не поддерживать “вечные” старые варианты.
- **Как реализовать в Z00Z**:

  - В Z00Z уже есть несколько уровней статусов:
    - storage‑уровень `TxStatus` (`z00z_wallets/src/core/storage/tx_storage.rs`) сейчас минимален (Pending/Confirmed/Failed),
    - RPC‑уровень статус/типы находятся в `z00z_wallets/src/adapters/rpc/types/tx.rs`.
  - Рекомендация:
    1) выбрать **канонический** набор строк на RPC boundary (и держать его стабильным),
    2) внутри storage можно оставаться на numeric enum (serde) — но при экспорте/импорте делать строгий mapping,
    3) если добавляете новые статусы (например Cancelled/Expired) — добавляйте их только через явный переход и тесты.
  - **REVIEW** ✅ Согласен.
  - **REVIEW** ⚠️ В текущей базе есть минимум статусов (Pending/Confirmed/Failed) на storage и отдельная модель на RPC. Нужно внимательно зафиксировать mapping между ними, иначе reconciliation/sweeper будут возвращать “не тот” статус наружу.

  Мини-снапшот парсера (ориентир):

  ```rust
  impl std::str::FromStr for TxStatusWire {
      type Err = ParseStatusError;
      fn from_str(s: &str) -> Result<Self, Self::Err> {
          match s {
              "pending" => Ok(Self::Pending),
              "confirmed" => Ok(Self::Confirmed),
              "failed" => Ok(Self::Failed),
              _ => Err(ParseStatusError::Unknown(s.to_string())),
          }
      }
  }
  ```

---

## z00z_crypto/tari/core/src/mempool/priority/prioritized_transaction.rs

### `FeePriority::new`

- **В чём идея**: иногда нужно, чтобы “сортировка по числу” совпадала с “сортировкой по байтам” (лексикографически).
  Это позволяет хранить приоритеты в:

  - KV‑индексах (range scans),
  - BTreeMap/BTreeSet,
  - RedB индекс‑таблицах,
    не держа отдельный компаратор и не распаковывая значения при каждом сравнении.
    Для беззнаковых чисел лексикографический порядок совпадает с числовым *если*:
  - используется fixed-width,
  - используется big-endian.
    Поэтому “priority key” часто делается как `be_u64(fee_per_weight)`.
  - **REVIEW** ✅ Это базовый storage-паттерн и хорошо ложится на RedB/range scans.
- **Что взять из Tari и почему полезно (+ tradeoffs)**:

  - **Что**: строим *байтовый ключ* приоритета так, чтобы обычная сортировка байтов давала правильный порядок.
  - **Как**: фиксируем ширину (u64/u128), пишем `to_be_bytes()`, и используем это в индексах.
  - **Зачем**: это упрощает реализацию очередей/индексов и делает range‑scan возможным.
  - **Tradeoffs**:
    - надо заранее выбрать масштаб/ширину (например fee в nano‑единицах, u64), иначе “переполнение” или миграции;
    - если нужен обратный порядок (high fee first), либо инвертируем (например `u64::MAX - fee`), либо просто сканируем с конца.
  - **REVIEW** ⚠️ Для “обратного порядка” в KV-индексах сканирование “с конца” не всегда удобно/доступно. Инверсия ключа часто проще и дешевле.
- **Как реализовать в Z00Z**:

  - Паттерн уже есть в Z00Z storage: см. `to_be_bytes()` в `z00z_wallets/src/db/schema_codecs.rs` и helpers вроде `object_id_to_be_bytes` в `z00z_wallets/src/db/redb_wallet_store.rs`.
  - **REVIEW** ✅ Отлично: это значит, что добавление fee priority key не будет “чужеродным” стилю базы.
  - Для mempool‑очереди/приоритизации (когда дойдёте до имплементации `ChainClient` / fee estimation):
    1) определить `FeePriorityKey([u8; 8])` или просто `Vec<u8>` фиксированного размера;
    2) собрать ключ как `fee_rate.to_be_bytes()`;
    3) использовать ключ в BTreeMap/индексе.

  Снапшот:

  ```rust
  fn fee_priority_key(fee_rate: u64) -> [u8; 8] {
      fee_rate.to_be_bytes()
  }
  ```

### `FeePriority` (tie-break)

- **В чём идея**: если приоритет — это только fee rate, то множество разных транзакций может иметь одинаковый priority.
  Если вы кладёте их в KV‑индекс или BTree‑set, то при равных ключах вы:

  - теряете элементы (overwrite), или
  - вынуждены хранить “список значений в одной ячейке”.
    Решение — *композитный ключ*: `priority || tie_break`, где tie_break гарантирует уникальность и детерминированность.
  - **REVIEW** ✅ Да: без tie-break вы либо теряете элементы (overwrite), либо городите списки.
- **Что взять из Tari и почему полезно (+ tradeoffs)**:

  - **Что**: добавляем стабильный “вторичный ключ” в конец.
  - **Как**: `priority_bytes || tx_hash_bytes` (или nonce), где tx_hash фиксированной длины.
  - **Зачем**: получаем строгий total order и корректную работу в индексах.
  - **Tradeoffs**:
    - tie-break должен быть детерминирован и стабилен (не “случайный” timestamp);
    - длина ключа растёт.
  - **REVIEW** ✅ Формулировка правильная; это именно “цена” за total order.
- **Как реализовать в Z00Z**:

  - Для любых индексов, где возможны совпадения по первичному полю (fee/amount/time), добавляйте вторичный компонент.
  - В кошельке похожая идея уже используется/обсуждается для index‑keys (см. композитные ключи и `INDEX_TX_BY_TIME_TABLE` / `INDEX_TX_BY_STATUS_TABLE` в `z00z_wallets/src/db/redb_wallet_store.rs`).
  - Для mempool‑случая tie-break = `tx_hash` (hex‑строку лучше предварительно декодировать до байтов и хранить фиксированно).
  - **REVIEW** ✅ Важно, что tie-break фиксированной длины (байты), а не строка.
  - **REVIEW** ⚠️ Для wallet-индексов tie-break разумнее делать из внутреннего идентификатора записи (object_id/tx_id) — он короче и стабильнее, чем `tx_hash`.

  Снапшот ключа:

  ```text
  key := be_u64(fee_rate) || tx_hash_32
  ```

---

## z00z_crypto/tari/app_grpc/src/conversions/transaction.rs

### `TryFrom<Transaction> for grpc::Transaction` / обратное

- **В чём идея**: любой внешний wire‑формат (gRPC/JSON-RPC/HTTP) — это *недоверенная граница*.
  Конвертация wire→core и core→wire должна:

  - быть единственным местом, где принимаются/выдаются “сырьевые” поля (bytes/hex/ints);
  - делать канонизацию и строгую валидацию;
  - не допускать “частично валидных” объектов внутрь core.
    Иначе ошибки расползаются по коду, а worst case — появляются консенсусные/крипто‑баги от некорректных байтов.
  - **REVIEW** ✅ Отличный принцип. Особенно важен для hex/bytes и enum’ов.
  - **REVIEW** ⚠️ Держите здесь только форматную валидацию/каноничность. Доменные проверки (баланс, правила кошелька) — в сервисах.
- **Что взять из Tari и почему полезно (+ tradeoffs)**:

  - **Что**: `TryFrom` (fallible) для wire→core и `From`/`TryFrom` для core→wire.
  - **Как**: валидация включает:
    - длины ключей/скаляров,
    - canonical encoding (без leading zeros где запрещено),
    - reject unknown enum variants/bitflags.
  - **Зачем**: централизуем безопасность и упрощаем тестирование.
  - **Tradeoffs**: conversion слой действительно становится “толстым”, но это плата за безопасность и поддерживаемость.
  - **REVIEW** ✅ Согласен, при условии что этот слой реально единый (без дублирования в каждом RPC методе).
- **Как реализовать в Z00Z**:

  - Z00Z сейчас использует JSON-RPC (см. `z00z_wallets/src/adapters/rpc/`). Поэтому “grpc conversions” маппятся на **RPC DTO conversions**:
    - core структуры (например будущий `z00z_core::tx::Transaction`) ↔ `z00z_wallets/src/adapters/rpc/types/tx.rs`.
  - Практический паттерн:
    1) держать преобразования в одном месте (например `z00z_wallets/src/adapters/rpc/mapping/tx.rs`);
    2) при приёме hex/bytes использовать строгие декодеры и проверять фиксированные длины;
    3) тестировать “битые входы” (короткие/длинные байты, не‑hex, неизвестный статус).
  - **REVIEW** ⚠️ Сейчас RPC DTO уже закреплены через `serde(rename_all = "snake_case")` (например `TxStatus` в `z00z_wallets/src/adapters/rpc/types/tx.rs`). Если добавляете ручной парсинг/алиасы — убедитесь, что это не расходится с serde и что ошибки декодинга маппятся в понятные JSON-RPC ошибки.
  - **REVIEW** ✅ Как только появятся “сырые” поля (tx_bytes, hashes, proofs), выделенный mapping модуль сильно снизит риск багов.

  Снапшот (концептуально):

  ```rust
  impl TryFrom<TxInfo> for CoreTxSummary {
      type Error = RpcDecodeError;
      fn try_from(dto: TxInfo) -> Result<Self, Self::Error> {
          // validate dto.id, parse hashes, clamp numbers, etc.
          Ok(Self { /* ... */ })
      }
  }
  ```

### `TryFrom<Arc<Transaction>> for grpc::Transaction`

- **В чём идея**: на hot‑path (RPC responses, mempool relay) “clone большого объекта” может быть очень дорогим.
  Но часто объект уже хранится в `Arc<T>`. Тогда можно:
  - попытаться забрать владение через `Arc::try_unwrap`,
  - если не вышло (есть другие ссылки) — сделать clone.
    Это даёт оптимизацию “бесплатно когда можно”, без изменения внешнего API.
  - **REVIEW** ⚠️ Это микро-оптимизация: добавляйте только когда появится действительно большой объект и профилирование покажет проблему clone.
- **Что взять из Tari и почему полезно (+ tradeoffs)**:
  - **Что**: условное избавление от clone.
  - **Как**: helper `arc_into_inner_or_clone(arc)`.
  - **Зачем**: снижает аллокации при сериализации/ответах.
  - **Tradeoffs**: усложнение кода и необходимость аккуратно выбирать, где это реально важно.
  - **REVIEW** ✅ Верно: держать такое только на доказанном hot-path.
- **Как реализовать в Z00Z**:
  - В Z00Z это особенно применимо, когда появится “большая” core‑tx структура или `tx_bytes` payload (см. `TxRecord.tx_bytes` в `z00z_wallets/src/core/storage/tx_storage.rs`).
  - Добавьте маленький util в `z00z_utils` или локально в adapters:

  ```rust
  pub fn arc_into_inner_or_clone<T: Clone>(v: std::sync::Arc<T>) -> T {
      std::sync::Arc::try_unwrap(v).unwrap_or_else(|a| (*a).clone())
  }
  ```

### status mapping + `not_found`

- **В чём идея**: статусы и “not found” ответы — самые частые элементы API.
  Их надо проектировать так, чтобы:
  - маппинг был **полным** (exhaustive match),
  - “не найдено” было единообразным (одинаковый код/сообщение/shape),
  - изменения статусов ломали компиляцию (а не поведение в рантайме).
  - **REVIEW** ✅ Это прям “качество протокола”: консистентные not_found и exhaustiveness экономят время всем.
- **Что взять из Tari и почему полезно (+ tradeoffs)**:
  - **Что**: отдельные функции/модули для status mapping + helper‑конструкторы ответов/ошибок.
  - **Как**: `match` без `_` для enum‑ов, чтобы добавление варианта требовало обновления.
  - **Зачем**: уменьшает “дырки” в протоколе и хаос в ошибках.
  - **Tradeoffs**: надо стабилизировать wire‑enum и иметь стратегию версионирования.
  - **REVIEW** ✅ Да; лучше заранее принять правило “строки статусов — контракт” (это уже проговорено выше).
- **Как реализовать в Z00Z**:
  - Wire статус у Z00Z уже есть: `z00z_wallets/src/adapters/rpc/types/tx.rs::TxStatus`.
  - Storage статус: `z00z_wallets/src/core/storage/tx_storage.rs::TxStatus`.
  - Сделайте явный маппинг модуль (например `z00z_wallets/src/adapters/rpc/mapping/tx_status.rs`) и helper для “tx not found”, используя уже существующий `map_wallet_error_to_rpc` (`z00z_wallets/src/adapters/rpc/error_mapping.rs`).
  - Для consistency: “not found” должен всегда возвращать один и тот же `code` и message (например через единый `WalletError::TxNotFound(tx_id)` → mapper).
  - **REVIEW** ⚠️ Сейчас уже есть расхождение: storage `TxStatus` и RPC `TxStatus` не совпадают по вариантам. Без явного mapping слоя reconciliation/sweeper легко начнут возвращать наружу неправильные значения.

---

## z00z_crypto/tari/common_types/src/transaction.rs

### ❌`LegacyTransactionStatus` vs `TransactionStatus`

- **В чём идея**: один enum “TransactionStatus” редко подходит всем слоям.
  Обычно есть минимум два домена:
  - **protocol/core**: то, что реально относится к цепочке/валидности (in_mempool/confirmed/rejected),
  - **wallet lifecycle/UI**: то, что относится к вашему локальному процессу (created, built, broadcasted, cancelled, expired, reorged).
    Смешивание приводит к “ossification”: вы боитесь менять протоколный слой, потому что UI хранит его значения в файлах/бэкапах.
  - **REVIEW** ✅ Правильный аргумент. Это помогает избежать “протокольные статусы = UX статусы”.
- **Что взять из Tari и почему полезно (+ tradeoffs)**:
  - **Что**: разделение статусов на “узкий протокольный” и “богатый кошелечный”.
  - **Как**: протокольный enum не знает про UI; wallet enum умеет маппиться на протокольный.
  - **Зачем**: легче эволюционировать и протокол, и UX.
  - **Tradeoffs**: нужна таблица маппинга и аккуратная state machine.
  - **REVIEW** ⚠️ Важно не завести 3-4 почти одинаковых enum’а. Обычно хватает: (1) chain/protocol status, (2) wallet lifecycle state.
- **Как реализовать в Z00Z**:
  - Сейчас уже виден зазор: storage `TxStatus` (Pending/Confirmed/Failed) в `z00z_wallets/src/core/storage/tx_storage.rs` и RPC `TxStatus` (Pending/Confirmed/Failed/Cancelled) в `z00z_wallets/src/adapters/rpc/types/tx.rs`.
  - Рекомендация:
    - оставить storage enum узким (и расширять очень осторожно),
    - в core/wallet слое ввести “wallet tx state” (например `WalletTxState`) который включает Cancelled/Expired/Reorged,
    - на RPC отдавать wallet‑state, но хранить в `.wlt` минимальный набор + дополнительные поля (cancel_reason/expiry) как опциональные.

### `TryFrom<i32>` + conversion error

- **В чём идея**: когда enum приезжает как число (protobuf / DB / wire), “неизвестный код” нельзя молча маппить в default.
  Иначе вы получаете:
  - тихое искажение состояния,
  - невозможность отлаживать проблемы совместимости.
    Поэтому decode должен быть строгим и возвращать ошибку с raw code.
  - **REVIEW** ✅ Must-have для совместимости и диагностики.
- **Что взять из Tari и почему полезно (+ tradeoffs)**:
  - **Что**: `TryFrom<i32>`/`TryFrom<u8>` для enum‑ов.
  - **Как**: `Err(UnknownCode(i32))` для неизвестных значений.
  - **Зачем**: fail-fast + диагностируемость.
  - **Tradeoffs**: при старых данных нужен compat слой (alias‑mapping) или миграция.
  - **REVIEW** ⚠️ Если вы выбираете compat (alias’ы), фиксируйте срок жизни и план удаления, иначе “вечная совместимость” начнёт тормозить эволюцию.
- **Как реализовать в Z00Z**:
  - В Z00Z уже используется похожий подход с кодами ошибок (см. `SecurityErrorCode` в `z00z_wallets/src/adapters/rpc/types/security.rs`).
  - Если/когда статусы транзакций будут сериализоваться числом (в `.wlt` или в будущем proto), сделайте:
    - `TxStatusCode` numeric,
    - строгий `TryFrom<i32>`,
    - логирование raw code только на boundary (storage/rpc), а не в глубине core.

### status transition helpers

- **В чём идея**: статус транзакции — это state machine. Если переходы разбросаны по коду, появляются противоречия:
  - в одном месте “Confirmed → Pending” разрешено,
  - в другом запрещено,
  - в третьем забыли обновить поля receipt.
    Поэтому лучше держать переходы в одном месте (как методы), где вы:
  - валидируете допустимость перехода,
  - обновляете связанные поля (height/hash/confirmations),
  - решаете, какое событие эмитить.
  - **REVIEW** ✅ Это сильно снижает риск “забыли обновить receipt/confirmations” при переходе.
  - **REVIEW** ⚠️ Держите state machine маленькой и компилируемо-полной (match без `_`). Реорг‑ветку особенно легко сломать в мелочах.
- **Что взять из Tari и почему полезно (+ tradeoffs)**:
  - **Что**: методы типа `confirm(height,hash)` / `unconfirm(reason)`.
  - **Как**: строгие переходы + единая логика reorg.
  - **Зачем**: меньше багов статуса и проще тесты.
  - **Tradeoffs**: нужно заранее продумать state machine и не делать её “слишком умной”.
- **Как реализовать в Z00Z**:
  - С учётом уже добавленного reconciliation (см. секцию `check_faux_transaction_status.rs` выше), вам понадобится как минимум:
    - `mark_confirmed(block_height, confirmations, receipt?)`
    - `mark_pending_due_to_reorg()`
    - `mark_failed(reason)` / `mark_cancelled()`
  - Разместить это можно рядом с storage записью (например методы на `TxRecord` в `z00z_wallets/src/core/storage/tx_storage.rs`) или в `tx_service` как “transition layer”.
  - Тесты: таблица переходов (from,to) + проверка полей.

---

## z00z_crypto/tari/core/src/proto/transaction.rs

### ❌compact vs full inputs

- **В чём идея**: input/output в транзакции может быть представлен:
  - **компактно** (reference: hash/commitment),
  - **полностью** (все поля объекта).
    Компактный формат экономит bandwidth и упрощает ретрансляцию, но требует явной логики “догрузки”.
    Критический момент: “полных данных нет” не должно превращаться в `None` где-то глубоко — это должна быть *явная ветка протокола*.
  - **REVIEW** ✅ Абсолютно. “None в глубине” почти всегда превращается в скрытые баги.
- **Что взять из Tari и почему полезно (+ tradeoffs)**:
  - **Что**: discriminated union: либо `Ref`, либо `Full`.
  - **Как**: при decode вы обязаны выбрать ветку и обработать её явно.
  - **Зачем**: экономия трафика без потери корректности.
  - **Tradeoffs**:
    - усложнение протокола и тестов;
    - нужно API для “upgrade ref → full” (chain query / UTXO lookup).
  - **REVIEW** ⚠️ Это имеет смысл только если у вас реально есть источник догрузки (chain client). Учитывая, что некоторые chain методы ещё TODO, не стоит обещать это как Phase 1.
- **Как реализовать в Z00Z**:
  - Даже если Z00Z сейчас не использует protobuf, идея переносится на любые wire типы (включая JSON-RPC):
    - DTO должен содержать либо `ref_hash`, либо `full_object` (не оба и не ни один).
  - В core добавить типы наподобие `TxInputRef`/`TxInputFull` и функцию `upgrade_with_output(...)` (см. также блок `SpentOutput` ниже — он про то же).
  - Ошибка “missing full data” должна быть typed и подниматься вверх до RPC как понятная.

### versioned component decoding

- **В чём идея**: если у транзакции много компонент (input/kernel/output), то “версия транзакции” целиком часто слишком груба.
  Независимые версии компонент дают возможность:
  - менять один компонент, не ломая другие;
  - держать более плавную обратную совместимость.
    Это особенно полезно, когда часть полей опциональна/feature-gated.
  - **REVIEW** ✅ Хорошая архитектурная подготовка под эволюцию формата.
- **Что взять из Tari и почему полезно (+ tradeoffs)**:
  - **Что**: отдельные `*Version` enum‑ы для input/kernel/output.
  - **Как**: строгий decode через `TryFrom<u8>`, неизвестное → ошибка.
  - **Зачем**: контролируемая эволюция форматов.
  - **Tradeoffs**: больше ветвлений decode и больше тестов.
  - **REVIEW** ⚠️ Чем раньше вы закрепите versioning, тем дешевле миграции. В `.wlt` уже есть “versioned payloads” — стоит выдержать такой же подход и для tx_bytes.
- **Как реализовать в Z00Z**:
  - Прямой перенос: в каждом компоненте определить:
    - `pub const CURRENT: ...` (или `get_current_version()`),
    - `TryFrom<u8>`.
  - В Z00Z это особенно важно, потому что `TxRecord.tx_bytes` пока “opaque” до стабилизации core tx (`z00z_wallets/src/core/storage/tx_storage.rs`). Когда вы стабилизируете формат — сразу заложите versioning.

### canonical bytes + reject unknown bits

- **В чём идея**: любые “флаги” и бинарные поля в транзакции должны иметь каноническое представление.
  Два главных класса атак/багов:
  - **unknown bits**: приходит бит, который ваша версия кода не понимает, но вы его молча пропускаете → расхождение правил валидации;
  - **неканоничные байты**: разные байтовые представления одного и того же смысла → разные хэши/подписи.
    Поэтому boundary должен быть строгим: либо “понимаю и принимаю”, либо “отклоняю”.
  - **REVIEW** ✅ Это фундамент: иначе получаются разные хэши/подписи и тихие несовместимости.
- **Что взять из Tari и почему полезно (+ tradeoffs)**:
  - **Что**: `bitflags::from_bits(...)` вместо `from_bits_truncate`.
  - **Как**: hard error на неизвестные биты.
  - **Зачем**: безопасность консенсуса/подписей.
  - **Tradeoffs**: если сеть уже выпустила новые биты, старые клиенты должны обновиться; нужен план roll-out.
  - **REVIEW** ✅ Правильно: strict decode = дисциплина версий/релизов.
- **Как реализовать в Z00Z**:
  - В conversions (RPC boundary) всегда валидировать bitflags строго.
  - Для hex/bytes полей: требовать фиксированные длины и запрещать альтернативные кодировки.
  - На уровне кошелька это особенно важно для receipt/tx_hash (hex) и любых крипто‑bytes.
  - **REVIEW** ⚠️ Для JSON-RPC boundary важно не использовать “мягкие” hex-декодеры (odd-length, whitespace, смешанные алфавиты), иначе каноничность будет сломана ещё на входе.

### covenant borsh blob

- **В чём идея**: иногда удобно вложить один бинарный формат в другой (например, сложный “script/covenant” в protobuf поле bytes).
  Это может упростить эволюцию и повторное использование уже существующего сериализатора.
  Но это “формат в формате”, и без версий вы получаете ад совместимости.
  - **REVIEW** ⚠️ Рабочая техника, но легко превращается в “opaque bytes” без tooling. Для Z00Z это стоит делать только при реальной необходимости (иначе over-engineering).
- **Что взять из Tari и почему полезно (+ tradeoffs)**:
  - **Что**: отдельный blob‑формат для сложной подструктуры.
  - **Как**: blob должен начинаться с версии/магии (или быть включён в версионированный контейнер выше).
  - **Зачем**: снижает связанность между proto и внутренним AST.
  - **Tradeoffs**:
    - двойная сериализация/десериализация;
    - нужно документировать и тестировать blob‑формат отдельно.
  - **REVIEW** ✅ Хорошо, что сразу требуются отдельные тесты blob-формата.
- **Как реализовать в Z00Z**:
  - Если Z00Z будет иметь scripts/covenants/политику расходов, то:
    - blob должен быть versioned (например `u8 version || payload`),
    - decode должен быть строгим (unknown version → error),
    - hash/signature должны фиксировать именно канонические bytes blob (не “объект после нормализации”, если это не оговорено).
  - **REVIEW** ✅ Критично: иначе разные реализации “нормализуют” по-разному и ломают подписи.

---

## z00z_crypto/tari/transaction_components/src/transaction_components/transaction.rs

### ❌`Transaction { offset, body, script_offset }`

- **В чём идея**: “offset” в Confidential Transactions часто используется, чтобы сбалансировать сумму blinding factors.
  Но “script_offset” — это другой смысл: он отделяет “offset для value/commitments” от “offset для script‑части/подписей/скриптовых ключей”.
  Зачем разделять:
  - разные домены криптографии (commitment balance vs script key relations),
  - разные правила валидации,
  - возможность менять скриптовую часть без переопределения основного offset.
    На уровне разработчика это выглядит как: tx имеет два независимых “балансирующих” элемента, и оба должны учитываться в hash/signature rules.
  - **REVIEW** ⚠️ Это очень протокольно-специфично; в wallet-spec лучше явно пометить как “future core tx format”, чтобы не воспринималось как Phase 1.
- **Что взять из Tari и почему полезно (+ tradeoffs)**:
  - **Что**: два отдельных offsets как часть протокольного формата.
  - **Как**: builder обязан требовать их установку; валидатор обязан проверять соответствующие балансы.
  - **Зачем**: более точная модель “что именно подписываем/валидируем” и меньше неявных зависимостей.
  - **Tradeoffs**: усложнение формата, больше полей → больше тестов и чёткий spec.
  - **REVIEW** ✅ Согласен: такое изменение требует тест-векторов и строгого encoding.
- **Как реализовать в Z00Z**:
  - Сейчас Z00Z кошелёк хранит `tx_bytes` как opaque (см. `TxRecord` в `z00z_wallets/src/core/storage/tx_storage.rs`), т.е. core tx формат ещё не стабилизирован.
  - Когда будете стабилизировать `z00z_core::tx::Transaction`, заложите:
    1) `offset` и `script_offset` как отдельные поля,
    2) versioned encoding (см. блоки про `*Version` выше),
    3) валидатор, который проверяет обе части отдельно.
  - На wallet уровне это влияет на:
    - конвертацию/парсинг tx bytes,
    - подтверждение receipt (hash должен учитывать offsets канонически).
  - **REVIEW** ✅ Правильно привязано к hash/signature правилам.

### `impl Add for Transaction`

- **В чём идея**: агрегация транзакций (объединение inputs/outputs/kernels) полезна для:

  - coinjoin/aggregation,
  - сборки “batched” транзакций,
  - оптимизаций relay.
    `Add` (или отдельная функция) превращает это в чистую, тестируемую операцию над структурами данных.
    Но важный нюанс: агрегированный результат должен быть **детерминирован** (иначе hash/signature/fee computation может зависеть от порядка).
  - **REVIEW** ✅ Детерминизм — главная “точка риска” здесь.
- **Что взять из Tari и почему полезно (+ tradeoffs)**:

  - **Что**: “сложение” транзакций как композиция.
  - **Как**: после объединения делается canonical sorting компонентов.
  - **Зачем**: одинаковый набор компонент → одинаковые bytes/hash.
  - **Tradeoffs**:
    - нужно определить строгий порядок сортировки (например по hash/commitment);
    - не всегда допустимо агрегировать без пересчёта signatures/offsets.
  - **REVIEW** ⚠️ Стоит подчеркнуть, что “aggregate” почти всегда означает пересборку/переподпись (не просто merge списков).
- **Как реализовать в Z00Z**:

  - В Z00Z лучше начать с явной функции (а не `impl Add`), чтобы было сложнее случайно использовать там, где нельзя:

  ```rust
  pub fn aggregate(mut a: Transaction, mut b: Transaction) -> Result<Transaction, TxBuildError> {
      // merge lists
      // canonical sort by fixed keys
      // recompute/validate offsets invariants
      Ok(tx)
  }
  ```

  - Canonical sorting можно выразить через байтовые ключи (см. паттерн `to_be_bytes`/composite keys выше): например сортировать по `hash()`/`commitment.as_bytes()`.
  - **REVIEW** ✅ Поддерживаю рекомендацию начать с явной функции, а не operator overloading.

---

## z00z_crypto/tari/transaction_components/src/transaction_components/transaction_builder.rs

### `CoreTransactionBuilder`

- **В чём идея**: это “узкий” builder, который гарантирует **протокольные инварианты** транзакции.
  - Смысл для разработчика:
    - в одном месте фиксируется: какие поля обязательны, в каком порядке они вычисляются, и что считается “final tx”;
    - builder убирает класс ошибок “частично собранная tx” (забыли offset/script_offset, не отсортировали body, подписали не те байты);
    - builder — composition root для low-level tx: получает fee/inputs/outputs/kernel features и отдаёт объект, который уже можно хэшировать/подписывать/валидировать.
  - **REVIEW** ✅ Added value высокий: это “single source of truth” для canonical bytes и обязательных полей.

- **Что взять из Tari и почему полезно (+ tradeoffs)**:
  - Что взять:
    - минимальный, инвариант-центричный builder (а не “кошелёчный” DSL);
    - жёсткий запрет “build без обязательных offsets/полей” (fail fast);
    - canonical ordering/sorting внутри builder’а, чтобы разные клиенты не строили разные байты для “одной и той же” логики;
    - разделение обязанностей: builder строит структуру tx, а подписи/ключи приходят извне (важно для HW/remote signer).
  - Почему полезно:
    - это естественная граница между `z00z_core` (протокол/валидация) и `z00z_wallets` (UX/оркестрация);
    - проще тестировать: builder можно покрыть инвариантами и golden vectors.
  - Tradeoffs:
    - API менее “магический”: больше явных параметров (fee, lock_height, features);
    - изменение порядка/recipe внутри builder’а = совместимость → нужны версии и тесты canonical bytes.
  - **REVIEW** ⚠️ Без golden vectors/compat тестов builder легко “случайно” ломает совместимость даже без изменения полей.

- **Как реализовать в Z00Z**:
  - В `z00z_core/src/tx/` (или эквивалентном модуле) держать протокольный `CoreTransactionBuilder` (без доступа к `.wlt`, без UI-политик).
  - В `z00z_wallets` держать orchestration, который:
    - выбирает inputs/outputs,
    - оценивает fee,
    - вызывает core builder,
    - затем запускает signing через `KeyManager`/`SignerBackend`.
  - Для deterministic bytes: иметь единый `encode_tx_for_signature_v1(...)` и не дублировать recipe в нескольких слоях.
  - Мини-снимок формы (схема):
    ```rust
    pub struct CoreTransactionBuilder {
        inputs: Vec<TxInput>,
        outputs: Vec<TxOutput>,
        kernels: Vec<TxKernel>,
        fee: MicroCoins,
        lock_height: u64,
    }
    
    impl CoreTransactionBuilder {
        pub fn add_input(mut self, input: TxInput) -> Self { /* ... */ self }
        pub fn add_output(mut self, output: TxOutput) -> Self { /* ... */ self }
        pub fn with_fee(mut self, fee: MicroCoins) -> Self { /* ... */ self }
        pub fn finalize(self) -> Result<Transaction, TxBuildError> {
            // 1) canonical sort body
            // 2) compute offsets/script_offset
            // 3) return Transaction ready for signing/validation
            Ok(/* ... */)
        }
    }
    ```

---

## z00z_crypto/tari/transaction_components/src/transaction_components/transaction_input.rs

### `SpentOutput` (hash-only vs full)

- **В чём идея**: один и тот же input может существовать в двух формах:
  - **hash-only / reference**: минимальный идентификатор (commitment/hash/output-id), достаточный для узла/валидатора, у которого есть UTXO set;
  - **full**: полный `TxOutput`, достаточный для оффлайн/HW-signing и для некоторых локальных проверок без доступа к chain state.
    Смысл для разработчика: это развязывает “размер данных на проводе” и “полноту данных для подписи/валидации”.
  - **REVIEW** ✅ Модель “Ref vs Full” — хороший способ сделать boundary явным и тестируемым.
- **Что взять из Tari и почему полезно (+ tradeoffs)**:
- Берём **явный enum двух представлений** + явный апгрейд `ref -> full`.
- Почему полезно в Z00Z:
  - `z00z_rollup_node`/валидаторы: в mempool/relay можно держать компактные входы, а полный output доставать из storage/DA layer.
  - `z00z_wallets`: перед подписью (особенно с HW/remote signer) проще гарантировать “все данные уже полные”, чем пытаться делать догрузку внутри подписи.
    Tradeoffs:
- Появляется состояние “данных пока не хватает” → нужен типизированный `MissingOutputData` и понятный пайплайн догрузки.
- В окне reorg input-ref может перестать соответствовать output → апгрейд обязан проверять соответствие hash/commitment.
  - **REVIEW** ✅ Отлично, что вы сразу учитываете reorg и требуете проверку соответствия при апгрейде.
- **Как реализовать в Z00Z**:
  - В протокольном слое (`z00z_core/src/tx/` или рядом с типами tx) ввести форму input’а как enum:
    ```rust
    pub enum SpentOutput {
        Ref { output_hash: [u8; 32] },
        Full { output: TransactionOutput },
    }
    
    pub enum TxInputError { MissingOutputData, MismatchedOutput }
    
    impl SpentOutput {
        pub fn upgrade_with_output(self, output: TransactionOutput) -> Result<SpentOutput, TxInputError> {
            match self {
                SpentOutput::Ref { output_hash } => {
                    if output.hash() != output_hash { return Err(TxInputError::MismatchedOutput); }
                    Ok(SpentOutput::Full { output })
                }
                SpentOutput::Full { .. } => Ok(self),
            }
        }
    }
    ```
  - Где брать full output в Z00Z:
    - узел/валидатор: из chain storage / индексера,
    - кошелёк: через chain client RPC “give me outputs by hash/commitment” (батчем) перед подписью.
  - **REVIEW** ⚠️ Сейчас многие chain/RPC куски ещё в стадии TODO (в частности методы для статуса/поиска). В spec стоит явно пометить “batched outputs lookup” как Phase 2, иначе кажется, что это уже доступно.

### `build_script_signature_message` / `finalize_script_signature_challenge`

- **В чём идея**: разделяем “что подписываем” на два стабильных слоя:
  - `message`: каноническая сериализация контекста (скрипт + ссылки на вход/выход + ограничения),
  - `challenge`: финальный wide-hash фиксированного размера, который подаётся в подпись.
    Это HW/remote-signer friendly: устройство видит фиксированные 32/64 байта, а не огромные структуры.
  - **REVIEW** ✅ Это правильная форма для HW/remote signer: фиксированный challenge + жёсткий рецепт.
- **Что взять из Tari и почему полезно (+ tradeoffs)**:
  - Берём **message/challenge split** как протокольный контракт + строгую domain separation.
  - Почему полезно в Z00Z:
    - единый рецепт подписи для software/HW/remote backends,
    - можно писать golden tests: “вот вход → вот message hash → вот challenge”.
      Tradeoffs:
  - Любой change в recipe требует versioning (домены/версии), иначе подписи перестанут совпадать между клиентами.
  - Нужно строго определить canonical encoding полей (endianness, presence bits, длины).
  - **REVIEW** ✅ Согласен: здесь versioning и domain separation не “nice to have”, а обязательны.
- **Как реализовать в Z00Z**:
  - В `z00z_crypto/src/hash_domains.rs` завести домены:
    - `z00z.tx.script_sig.msg.v1`
    - `z00z.tx.script_sig.challenge.v1`
  - В `z00z_core/src/tx/` (или `z00z_crypto` если это чистый hashing) добавить функции фиксированной формы:
    ```rust
    pub fn build_script_sig_message_v1(ctx: &ScriptSigContext) -> [u8; 32] {
        // encode fields canonically, hash under msg domain
        let _ = ctx;
        [0u8; 32]
    }
    
    pub fn finalize_script_sig_challenge_v1(msg_hash: [u8; 32], pub_data: &[u8]) -> [u8; 64] {
        // wide hash under challenge domain
        let _ = (msg_hash, pub_data);
        [0u8; 64]
    }
    
    pub struct ScriptSigContext;
    ```
  - В wallet signing pipeline:
    - сначала `msg_hash`,
    - затем `challenge`,
    - затем `signer.sign_with_challenge(challenge)`.
  - **REVIEW** ⚠️ Убедитесь, что “pub_data” (если требуется) тоже канонизировано и не допускает двусмысленностей (например, length-prefix vs NUL separators — ровно та же проблема, что и в AAD).

### `add_output_data`

- **В чём идея**: “late binding” — это выделенная стадия, которая делает input пригодным для:
  - построения сообщения на подпись (скрипт/ковенант/фичи часто нужны полностью),
  - строгой local validation (где это возможно без chain state).
    Смысл: не прятать догрузку внутри валидатора/подписи, а сделать её явным шагом пайплайна.
  - **REVIEW** ✅ Отличная декомпозиция: уменьшает “магические” падения подписи и делает UX управляемым.
- **Что взять из Tari и почему полезно (+ tradeoffs)**:
  - Берём явный метод апгрейда, который:
    - проверяет соответствие (hash/commitment),
    - возвращает типизированную ошибку, если данных не хватает.
  - Почему полезно в Z00Z:
    - упрощает UX: сервис знает, что “нужно догрузить outputs”, а не “подпись внезапно упала”.
    - упрощает оптимизацию: догрузку можно делать батчами.
      Tradeoffs:
  - Больше промежуточных состояний (ref-only, partial-full, full).
  - Нужно аккуратно проектировать error mapping (RPC/CLI) без утечки лишних деталей.
  - **REVIEW** ✅ Да: наружу лучше отдавать “missing output data” как доменную ошибку, без внутренних ключей/таблиц.
- **Как реализовать в Z00Z**:
  - В `z00z_wallets` в шаге “prepare for signing”:
    - собрать все `output_hash` из ref inputs,
    - сделать batched запрос к chain client,
    - прогнать `upgrade_with_output`.
  - **REVIEW** ⚠️ Это упирается в наличие chain API “outputs by hash/commitment”. Если в ближайшем плане это не реализуется, можно начать с более простого варианта: хранить full outputs в `.wlt` для собственных UTXO, а chain lookup делать позже.
  - Мини-снимок (shape) batched upgrade:
    ```rust
    pub fn upgrade_inputs(inputs: Vec<SpentOutput>, outputs_by_hash: &std::collections::HashMap<[u8; 32], TransactionOutput>)
        -> Result<Vec<SpentOutput>, TxInputError>
    {
        inputs.into_iter().map(|i| {
            match i {
                SpentOutput::Ref { output_hash } => {
                    let out = outputs_by_hash.get(&output_hash).ok_or(TxInputError::MissingOutputData)?.clone();
                    SpentOutput::Ref { output_hash }.upgrade_with_output(out)
                }
                full => Ok(full),
            }
        }).collect()
    }
    
    pub struct TransactionOutput;
    impl TransactionOutput { pub fn hash(&self) -> [u8; 32] { [0u8; 32] } }
    ```

---

## z00z_crypto/tari/transaction_components/src/transaction_components/transaction_input_version.rs

### `TransactionInputVersion` (`TryFrom<u8>`)

- **В чём идея**: version byte — это “предохранитель” от тихой несовместимости.
  Входные данные (RPC/bytes-at-rest/сеть) мы сначала классифицируем по версии, и только затем парсим по соответствующему рецепту.
  - **REVIEW** ✅ Must-have для long-lived wallet data и для независимых релизов компонентов.
- **Что взять из Tari и почему полезно (+ tradeoffs)**:
  - Берём паттерн `TryFrom<u8>` с hard-error на неизвестную версию.
  - Почему полезно: Z00Z кошелёк хранит данные долго, а разные компоненты могут обновляться несинхронно.
    Лучше “unsupported version” сейчас, чем частично распарсить и получить некорректную подпись/баланс.
    Tradeoffs:
  - Decode становится ветвящимся (V1/V2/...), и это нужно покрывать тестами.
  - Любая новая версия требует плана совместимости.
  - **REVIEW** ✅ Хорошо, что это явно сказано.
- **Как реализовать в Z00Z**:
  - В `z00z_core/src/tx/` стандартизировать:
    ```rust
    #[repr(u8)]
    pub enum TransactionInputVersion { V1 = 1 }
    
    impl TryFrom<u8> for TransactionInputVersion {
        type Error = TxInputError;
        fn try_from(v: u8) -> Result<Self, Self::Error> {
            match v { 1 => Ok(TransactionInputVersion::V1), _ => Err(TxInputError::MissingOutputData) }
        }
    }
    ```
  - **REVIEW** ❌ В примере для unknown version возвращается `MissingOutputData` — это неверная семантика. Нужна отдельная ошибка вроде `UnsupportedVersion(v)`/`UnknownVersion(v)`.
  - На boundary decode: `read version -> match -> strict parse with length guards`.

---

## z00z_crypto/tari/transaction_components/src/validation/transaction/transaction_internal_validator.rs

### `TransactionInternalConsistencyValidator::{validate,validate_with_current_tip}`

- **В чём идея**: internal consistency — это проверки, которые **не требуют chain state**:
  - корректность структуры транзакции (поле/флаги/версии/len guards),
  - каноничность сериализаций ключей/скаляров,
  - базовые инварианты суммы (если применимо),
  - проверка сигнатур/пруфов, которые могут быть проверены без UTXO DB.
    Смысл: это “дешёвый фильтр” для mempool/wallet, который можно прогонять до любых запросов к хранилищу.
  - **REVIEW** ✅ Отличная декомпозиция: сначала дешёвое и строгое, потом DB/IO.
- **Что взять из Tari и почему полезно (+ tradeoffs)**:
  - Берём чёткое разделение: `Internal` vs `ChainLinked` vs `Full`.
  - Почему полезно в Z00Z:
    - меньше DoS поверхности на узле: не трогаем DB для очевидно битых tx,
    - кошелёк может валидировать “то, что он сам собрал” оффлайн,
    - тестируемость: internal validator можно покрывать property tests на байты.
      Tradeoffs:
  - Нужно поддерживать список “что считается internal”, иначе проверки расползутся.
  - Некоторые проверки могут быть условными (например, “если есть full input data”).
  - **REVIEW** ⚠️ Да: если “internal” начнёт тащить chain lookups, вы потеряете смысл стадий. Границы лучше зафиксировать в виде trait’ов и тестов.
- **Как реализовать в Z00Z**:
  - В `z00z_core/src/tx/validation/` (или рядом) ввести интерфейс:
    ```rust
    pub trait TxInternalValidator {
        fn validate(&self, tx: &Transaction) -> Result<(), TxValidateError>;
    }
    
    pub enum TxValidateError {
        UnsupportedVersion,
        InvalidSignature,
        InvalidRangeProof,
        InvalidCanonicalEncoding,
        MissingRequiredData,
    }
    
    pub struct Transaction;
    ```
  - Практика пайплайна:
    - mempool/relay: `internal.validate(tx)` всегда,
    - wallet before signing: `internal.validate(unsigned_tx)` (часть проверок отключить или переключить режимом).

---

## z00z_crypto/tari/core/src/validation/transaction/transaction_chain_validator.rs

### `TransactionChainLinkedValidator::validate`

- **В чём идея**: chain-linked validation — это проверки, для которых нужен **контекст текущей цепи**:
  - существование/непотраченность входов (UTXO set),
  - консенсусные лимиты (max tx size, max script size, fee rules, maturity, timelocks),
  - сверка с текущим tip (height/epoch).
    Смысл: эта стадия может быть дорогой (DB/IO) и должна идти после internal.
  - **REVIEW** ✅ Логичный пайплайн и хорошая защита от DoS по IO.
- **Что взять из Tari и почему полезно (+ tradeoffs)**:
  - Берём явный интерфейс “chain context” вместо прямого доступа к конкретной DB.
  - Почему полезно в Z00Z:
    - `z00z_rollup_node` может валидировать tx и против локального state, и против DA snapshots,
    - проще мокать в тестах и симуляторе (`z00z_simulator`).
      Tradeoffs:
  - Нужен дизайн контракта: какие именно данные валидатор вправе запрашивать.
  - Возможны race conditions (между проверкой и включением в блок) → надо определять, что validator гарантирует.
  - **REVIEW** ⚠️ Это нужно проговорить чётче: validator обычно гарантирует “валидно относительно snapshot/tip на момент проверки”, не больше.
- **Как реализовать в Z00Z**:
  - Ввести контекст:
    ```rust
    pub trait ChainContext {
        fn tip_height(&self) -> u64;
        fn is_unspent(&self, output_hash: [u8; 32]) -> Result<bool, TxValidateError>;
        fn consensus(&self) -> ConsensusConstants;
    }
    
    pub struct ConsensusConstants;
    ```
  - Валидатор:
    ```rust
    pub struct TxChainLinkedValidator<'a, C: ChainContext> { pub ctx: &'a C }
    impl<'a, C: ChainContext> TxChainLinkedValidator<'a, C> {
        pub fn validate(&self, tx: &Transaction) -> Result<(), TxValidateError> {
            let _ = tx;
            Ok(())
        }
    }
    ```

---

## z00z_crypto/tari/core/src/validation/transaction/transaction_full_validator.rs

### `TransactionFullValidator::validate`

- **В чём идея**: `FullValidator` — это композиция стадий, которая даёт один контракт: “валидно ли это для включения/принятия”.
  При этом он может возвращать **структурированную причину отказа**.
  - **REVIEW** ✅ Хороший entrypoint: единые правила и единая таксономия ошибок.
- **Что взять из Tari и почему полезно (+ tradeoffs)**:
  - Берём единый entrypoint, который внутри:
    - вызывает internal,
    - затем вызывает chain-linked.
  - Почему полезно в Z00Z:
    - одна точка для mempool admission policy,
    - унифицированное маппинг-логирование/метрики по типам ошибок,
    - проще обеспечить “same rules everywhere” (wallet + node).
      Tradeoffs:
  - Нужны режимы (например, “wallet unsigned tx” vs “node fully signed tx”).
  - Если FullValidator начнёт делать enrichment, границы расплывутся — лучше держать его чистым.
  - **REVIEW** ✅ Согласен: enrichment (догрузка/запросы) — отдельный шаг пайплайна, не часть “validate”.
- **Как реализовать в Z00Z**:
  - Собрать композицию:
    ```rust
    pub struct TxFullValidator<I, C> {
        pub internal: I,
        pub chain: C,
    }
    
    impl<I, C> TxFullValidator<I, C>
    where
        I: TxInternalValidator,
        C: TxChainValidator,
    {
        pub fn validate(&self, tx: &Transaction) -> Result<(), TxValidateError> {
            self.internal.validate(tx)?;
            self.chain.validate(tx)?;
            Ok(())
        }
    }
    
    pub trait TxChainValidator { fn validate(&self, tx: &Transaction) -> Result<(), TxValidateError>; }
    ```
  - В `z00z_rollup_node` использовать в mempool pipeline (до gossip).

---

## z00z_crypto/tari/app_grpc/src/conversions/transaction_input.rs

### `TryFrom<grpc::TransactionInput> for TransactionInput` / обратное

- **В чём идея**: RPC boundary — это место, где нужно:
  - различить варианты (ref/full) без догадок,
  - проверить каноничность bytes (ключи/скаляры),
  - reject неизвестные версии/флаги,
  - вернуть точную ошибку, которую можно маппить в gRPC status.
  - **REVIEW** ✅ Всё верно: boundary должен быть строгим и диагностируемым.
- **Что взять из Tari и почему полезно (+ tradeoffs)**:
  - Берём симметричные конверторы `TryFrom`/`From`.
  - Почему полезно в Z00Z:
    - единообразие: все входы в core проходят через один “узкий” слой,
    - безопасность: неправильные/неполные inputs не попадут глубже.
      Tradeoffs:
  - Conversion слой разрастается, но это осознанная цена за boundary safety.
  - Нужно держать тесты на “bad bytes” (non-canonical, wrong length, unknown version).
  - **REVIEW** ⚠️ У Z00Z кошелька сейчас JSON-RPC DTO уже в `z00z_wallets/src/adapters/rpc/types/`. Этот раздел лучше явно переформулировать как “общий паттерн conversions для любого wire”, иначе читатель может подумать, что Z00Z уже на gRPC.
- **Как реализовать в Z00Z**:
  - В `z00z_networks/rpc` (или `z00z_wallets` если это wallet-only) завести `rpc/conversions/transaction_input.rs`.
  - Код-форма:
    ```rust
    impl TryFrom<grpc::TransactionInput> for TransactionInput {
        type Error = RpcConversionError;
        fn try_from(v: grpc::TransactionInput) -> Result<Self, Self::Error> {
            // 1) validate version
            // 2) validate either ref or full
            // 3) canonical decode cryptographic bytes
            let _ = v;
            Err(RpcConversionError::InvalidInput)
        }
    }
    
    pub struct TransactionInput;
    pub enum RpcConversionError { InvalidInput, UnsupportedVersion }
    pub mod grpc { pub struct TransactionInput; }
    ```

---

## z00z_crypto/tari/app_grpc/src/conversions/transaction_kernel.rs

### `TryFrom<grpc::TransactionKernel> for TransactionKernel` / `From<TransactionKernel>`

- **В чём идея**: kernel — консенсусный объект, значит boundary decode должен:
  - reject неизвестные bitflags,
  - проверять каноничность подписи/пабликов,
  - enforce versioning,
  - не доверять derived полям (hash/id считаем сами).
  - **REVIEW** ✅ Отличная формулировка: derived поля должны вычисляться локально, не приходить “как истина” снаружи.
- **Что взять из Tari и почему полезно (+ tradeoffs)**:
  - Берём patten: `from_bits` + hard-error на unknown bits.
  - Почему полезно в Z00Z:
    - защищает от “future flags” атак/несовместимости,
    - консенсусные ошибки ловятся на входе, а не где-то в глубине.
      Tradeoffs:
  - Требует дисциплины при апгрейде версий (feature gating + negotiation).
  - **REVIEW** ⚠️ Для Z00Z важно разделить “wallet boundary” и “node boundary”: strictness для консенсуса должна жить в core/node валидаторах, а не расползаться по wallet слоям.
- **Как реализовать в Z00Z**:
  - В conversions:
    ```rust
    impl TryFrom<grpc::TransactionKernel> for TransactionKernel {
        type Error = RpcConversionError;
        fn try_from(v: grpc::TransactionKernel) -> Result<Self, Self::Error> {
            let _ = v;
            Err(RpcConversionError::InvalidInput)
        }
    }
    
    pub struct TransactionKernel;
    pub mod grpc { pub struct TransactionKernel; }
    ```
  - Derived fields (например, hash) не передавать по RPC как “истину”; если нужно — вычислять и возвращать как отдельный response field.

---

## z00z_crypto/tari/transaction_components/src/transaction_components/transaction_kernel.rs

### `TransactionKernel::hash`

- **В чём идея**: kernel hash — это стабильный идентификатор, который обязан быть:
  - детерминированным,
  - domain-separated (не совпадает с hash других объектов),
  - основанным на канонической сериализации полей.
    Это нужно для index’ов, ссылок, и как ключ в storage.
  - **REVIEW** ✅ Да: stable id требует canonical encoding + domain separation.
- **Что взять из Tari и почему полезно (+ tradeoffs)**:
  - Берём domain separation + “включаемые поля = протокольный контракт”.
  - Почему полезно в Z00Z:
    - одинаковый kernel id в wallet/node/DA watchers,
    - проще дедуп/кеширование.
      Tradeoffs:
  - Любая смена набора полей/кодека должна быть версионирована (иначе ломает ссылки).
  - **REVIEW** ✅ Именно. Это один из главных источников “тихих” breaking changes.
- **Как реализовать в Z00Z**:
  - В `z00z_crypto/src/hash_domains.rs` завести `z00z.tx.kernel.hash.v1`.
  - Определить canonical encoding (например, borsh/scale + explicit lengths) и написать:
    ```rust
    impl TransactionKernel {
        pub fn hash(&self) -> [u8; 32] {
            // hash(domain, version || canonical_fields)
            let _ = self;
            [0u8; 32]
        }
    }
    ```

### `build_kernel_signature_message` / `finalize_kernel_signature_challenge`

- **В чём идея**: как и со script signature, kernel signature делаем через 2-шаговый рецепт:
  - message hash — фиксированный и тестируемый,
  - challenge — финальный wide-hash, который идёт в подпись.
    Это позволяет HW/remote signer подписывать фиксированные байты без знания всей структуры kernel.
  - **REVIEW** ✅ Паттерн консистентный со script sig и хорошо ложится на HW.
- **Что взять из Tari и почему полезно (+ tradeoffs)**:
  - Берём разделение message/challenge + versioned domains.
  - Почему полезно в Z00Z:
    - одинаковые подписи на разных backend’ах (software/HW/remote),
    - проще обновлять: новый рецепт = новая версия домена.
      Tradeoffs:
  - recipe становится частью консенсуса → нужно явно документировать и покрывать golden tests.
  - **REVIEW** ✅ Согласен: без golden tests любые “рефакторинги” становятся опасными.
- **Как реализовать в Z00Z**:
  - Домены:
    - `z00z.tx.kernel.sig.msg.v1`
    - `z00z.tx.kernel.sig.challenge.v1`
  - Код-форма:
    ```rust
    pub fn build_kernel_sig_message_v1(kernel: &TransactionKernel) -> [u8; 32] {
        let _ = kernel;
        [0u8; 32]
    }
    
    pub fn finalize_kernel_sig_challenge_v1(msg_hash: [u8; 32], nonce_commitment: [u8; 32]) -> [u8; 64] {
        let _ = (msg_hash, nonce_commitment);
        [0u8; 64]
    }
    ```

### `verify_signature`

- **В чём идея**: `bool` недостаточно — при отладке/метриках нужно знать:
  - где именно ошибка (какой kernel),
  - какой тип (bad sig, bad pubkey bytes, bad challenge),
  - можно ли ретраить (например, missing data vs cryptographic invalid).
  - **REVIEW** ✅ Полезно и для node, и для wallet UX.
- **Что взять из Tari и почему полезно (+ tradeoffs)**:
  - Берём `Result<(), Error>` с понятной таксономией.
  - Почему полезно в Z00Z:
    - RPC может вернуть корректный status/reason,
    - mempool может вести метрики по классам отказов,
    - wallet UX может отличать “не хватает данных” от “подпись неверна”.
      Tradeoffs:
  - Больше типов ошибок/вариантов → нужно удерживать их стабильными и не утекать секретные детали.
  - **REVIEW** ⚠️ Да: наружу (RPC/logs) не должны попадать чувствительные байты/ключи; максимум — идентификаторы (hash) и категория ошибки.
- **Как реализовать в Z00Z**:
  - Ошибка уровня tx validation:
    ```rust
    pub enum TxValidateError {
        InvalidKernelSignature { kernel_hash: [u8; 32] },
        InvalidCanonicalEncoding,
    }
    ```
  - Проверку подписи вызывать внутри internal validator (если signature проверяема без chain state).

---

## z00z_crypto/tari/transaction_components/src/transaction_components/transaction_kernel_version.rs

### `TransactionKernelVersion::{get_current_version,TryFrom<u8>}`

- **В чём идея**: kernel — консенсусный объект, который живёт долго. Версия kernel позволяет:
  - менять/добавлять поля kernel (или правила хеширования/подписи) без “тихого” несовпадения,
  - обеспечивать fail-fast на границе: если версия не поддерживается — транзакцию нельзя принимать.
    Важно: версия kernel независима от версии input/output/tx-body — это даёт более тонкую эволюцию протокола.
  - **REVIEW** ✅ Независимые версии компонент — правильная архитектура для эволюции.
- **Что взять из Tari и почему полезно (+ tradeoffs)**:
  - Берём паттерн:
    - `get_current_version()` как единый “источник правды” для формирования новых объектов,
    - `TryFrom<u8>` для строгого decode.
  - Почему полезно в Z00Z:
    - в rollup-узле и кошельке можно безопасно обрабатывать старые tx из storage/DA,
    - при несовпадении версий лучше вернуть явный `UnsupportedKernelVersion`, чем продолжать с неверной логикой.
      Tradeoffs:
  - Любая новая версия = матрица совместимости (node/wallet/indexer/DA watchers).
  - Код становится ветвящимся (V1/V2/...) и требует golden tests по байтовым сериализациям.
  - **REVIEW** ⚠️ Матрица совместимости (wallet/node/indexer/watchers) быстро растёт — стоит заранее определить правило “сколько версий поддерживаем” и политику deprecation.
- **Как реализовать в Z00Z**:
  - В `z00z_core/src/tx/` (или `z00z_crypto` если тип лежит там) определить:
    ```rust
    #[repr(u8)]
    #[derive(Clone, Copy, Debug, Eq, PartialEq)]
    pub enum TransactionKernelVersion {
        V1 = 1,
    }
    
    impl TransactionKernelVersion {
        pub const CURRENT: TransactionKernelVersion = TransactionKernelVersion::V1;
        pub fn get_current_version() -> TransactionKernelVersion { Self::CURRENT }
    }
    
    impl TryFrom<u8> for TransactionKernelVersion {
        type Error = TxValidateError;
        fn try_from(v: u8) -> Result<Self, Self::Error> {
            match v {
                1 => Ok(TransactionKernelVersion::V1),
                _ => Err(TxValidateError::UnsupportedVersion),
            }
        }
    }
    ```
  - На decode boundary (RPC/bytes-at-rest): `read version -> try_from -> parse_vN`.

---

## z00z_crypto/tari/app_grpc/src/conversions/transaction_output.rs

### `TryFrom<grpc::TransactionOutput> for TransactionOutput` + `grpc_output_with_payref`

- **В чём идея**: `TransactionOutput` пересекает границы (storage/RPC/network). На границе нужно:
  - строго распарсить крипто-байты (commitment, keys, signatures, range proof bytes),
  - отфильтровать неизвестные версии/флаги,
  - разделить **core output** (консенсусные поля) и **enriched view** (например payref/memo, которые доступны только в кошельковом контексте).
    `grpc_output_with_payref` — это именно “view builder”: он не должен менять консенсусную сущность, только добавлять удобные поля ответа.
  - **REVIEW** ✅ Отличное разделение: strict conversion для core, enrichment/view builder отдельно.
  - **REVIEW** ⚠️ В Z00Z уже есть понятие `payref` в `z00z_crypto` (модуль `payref`). Стоит явно связать эти идеи и не плодить несколько несовместимых форматов payref на разных слоях.
- **Что взять из Tari и почему полезно (+ tradeoffs)**:
  - Берём чёткое правило: conversion слой отвечает за **валидность входных байтов**, а enrichment — за **добавление производных/контекстных данных**.
  - Почему полезно в Z00Z:
    - `z00z_rollup_node` и `z00z_wallets` получают одинаково строгую границу,
    - payref/мемо не “просачиваются” в core типы и не влияют на hash/signature.
      Tradeoffs:
  - Conversion слой крупный и требует тестов на: short/long bytes, non-canonical encodings, unknown versions.
  - Нужно аккуратно определить, какие поля считаются “enriched” и могут отсутствовать.
  - **REVIEW** ✅ Да: enriched поля должны быть опциональными и не влиять на hash/signature.
- **Как реализовать в Z00Z**:
  - Держать protobuf/grpc модели в `z00z_networks/rpc` и конвертеры рядом (как отдельный модуль `conversions`).
  - Core тип `TransactionOutput` — в `z00z_core/src/tx/`.
  - Code-shape:
    ```rust
    pub mod grpc { pub struct TransactionOutput; }
    
    pub struct TransactionOutput {
        pub version: TransactionOutputVersion,
        // commitment, script, covenant, range_proof, metadata_sig, ...
    }
    
    pub enum RpcConversionError { InvalidOutput, UnsupportedVersion }
    
    impl TryFrom<grpc::TransactionOutput> for TransactionOutput {
        type Error = RpcConversionError;
        fn try_from(v: grpc::TransactionOutput) -> Result<Self, Self::Error> {
            let _ = v;
            // 1) parse version (TryFrom<u8>)
            // 2) parse cryptographic bytes with from_canonical_bytes
            // 3) enforce length bounds (proof bytes, script bytes, covenant bytes)
            Err(RpcConversionError::InvalidOutput)
        }
    }
    
    pub struct OutputView { pub core: TransactionOutput, pub payref: Option<String> }
    pub fn grpc_output_with_payref(core: TransactionOutput, payref: Option<String>) -> OutputView {
        OutputView { core, payref }
    }
    ```

---

## z00z_crypto/tari/transaction_components/src/transaction_components/transaction_output.rs

### `TransactionOutput::hash`

- **В чём идея**: output hash — это “ID” output’а, который используется в:
  - ссылках input’ов (ref form),
  - индексах storage/mempool,
  - дедупликации и кэшах.
  Чтобы hash был стабильным и однозначным, нужны:
  - domain separation,
  - каноническая сериализация,
  - версия (или явный recipe version),
  - явные presence markers для optional полей (иначе `None` и `Some(empty)` могут совпасть).
  - **REVIEW** ✅ Presence markers — ключевой момент, который часто забывают.
- **Что взять из Tari и почему полезно (+ tradeoffs)**:
  - Берём идею “optional field presence” как часть recipe (бит/байт присутствия или sentinel).
  - Почему полезно в Z00Z:
    - меньше неоднозначностей при миграциях/serde,
    - проще строить `SpentOutput::Ref { output_hash }` и апгрейдить его до full.
      Tradeoffs:
  - Recipe становится протокольным контрактом: менять без версии нельзя.
  - Нужны golden tests: “вот canonical output → вот hash”.
  - **REVIEW** ✅ Согласен: без golden tests hash-рецепт быстро “уплывает”.
- **Как реализовать в Z00Z**:
  - Завести домен `z00z.tx.output.hash.v1` в `z00z_crypto/src/hash_domains.rs`.
  - Держать сам recipe рядом с tx-core (например, `z00z_core/src/tx/`): `output_hash_v1(out) -> [u8; 32]`.
  - Каноническое кодирование полей + presence bits (предпочтительно), чтобы избежать ad-hoc sentinel’ов:
    ```rust
    impl TransactionOutput {
        pub fn hash(&self) -> [u8; 32] {
            // pseudo:
            // H(domain || version || commitment || script || covenant || (opt_field_present? value : sentinel))
            let _ = self;
            [0u8; 32]
        }
    }
    ```

### `build_metadata_signature_challenge` / `metadata_signature_message_from_parts`

- **В чём идея**: metadata signature обычно подписывает “мелкие, но критичные” поля output’а (features, script, covenant, sender_offset, и т.д.).
  Чтобы:
  - поддерживать HW/remote signing,
  - уменьшать размер данных,
  - избежать пересечений с другими подписями,
    вводим helpers:
  - `build_metadata_sig_message` → фиксированный hash,
  - `finalize_metadata_sig_challenge` → wide-hash для подписи.
  Дополнительно полезно иметь sub-hash (например, `common_parts_hash`), который можно кэшировать в процессе сборки tx.
  - **REVIEW** ✅ Хорошая оптимизация: sub-hash упрощает и ускоряет сборку/проверку.
- **Что взять из Tari и почему полезно (+ tradeoffs)**:
  - Берём layered hashing: sub-hash (immutable/common) + финальный message/challenge.
  - Почему полезно в Z00Z:
    - ускоряет повторные проверки (кэш sub-hash),
    - делает один и тот же рецепт доступным для wallet и node.
      Tradeoffs:
  - Больше доменов/версий → дисциплина именования и тестирования.
  - Любая ошибка в canonical encoding = несовместимость.
  - **REVIEW** ⚠️ Здесь будет много доменов/версий. Рекомендую заранее зафиксировать единый нейминг и “policy” для добавления новых доменов (иначе начнётся зоопарк).
- **Как реализовать в Z00Z**:
  - Домены:
    - `z00z.tx.output.metadata.msg.v1`
    - `z00z.tx.output.metadata.challenge.v1`
  - Разделить immutable/common vs dynamic parts:
    - `common_output_metadata_hash_v1(out) -> [u8; 32]`
    - `metadata_sig_message_v1(common_hash, dynamic_parts) -> [u8; 32]`
    - `metadata_sig_challenge_v1(msg_hash, pub_data) -> [u8; 64]`
  - Code-shape:
    ```rust
    pub fn build_output_metadata_sig_message_v1(out: &TransactionOutput) -> [u8; 32] {
        let _ = out;
        [0u8; 32]
    }
    
    pub fn finalize_output_metadata_sig_challenge_v1(msg_hash: [u8; 32], pub_data: &[u8]) -> [u8; 64] {
        let _ = (msg_hash, pub_data);
        [0u8; 64]
    }
    ```

### `verify_range_proof` / `revealed_value_range_proof_check`

- **В чём идея**: range proof — консенсусно значимая проверка, которая гарантирует, что committed value лежит в допустимом диапазоне и не раскрывает значение.
  Практически протокол часто поддерживает несколько “режимов”:

  - полноценный zero-knowledge range proof,
  - раскрытый value (reveal) для некоторых спец-outputs/тестов,
  - версии proof’а.
    `revealed_value_range_proof_check` — отдельная проверка-инвариант для режима “значение раскрыто” (и тогда проверка другая и проще).
  - **REVIEW** ✅ Явное моделирование режимов — правильно: это снижает риск “приняли reveal там, где нужен ZK”.
- **Что взять из Tari и почему полезно (+ tradeoffs)**:
  - Берём явное моделирование proof modes как enum + строгие правила для каждого режима.
  - Почему полезно в Z00Z:
    - чётко отделяем консенсусные пути от “диагностических/тестовых”,
    - избегаем случая “приняли reveal там, где ожидался ZK proof”.
      Tradeoffs:
  - Больше ветвлений в коде и больше тестов.
  - Нужно закрепить правила: какие режимы допустимы где (consensus vs wallet-only/tooling).
  - **REVIEW** ⚠️ Режим `Revealed` лучше сразу ограничить tooling/симулятором. В противном случае очень легко случайно протащить его в консенсусный путь.
- **Как реализовать в Z00Z**:
  - В `z00z_core/src/tx/` (протокольный слой) добавить версионированный enum:
    ```rust
    pub enum RangeProof {
        ProofV1(Vec<u8>),
        Revealed { value: u64 },
    }
    
    pub enum RangeProofError { Oversized, Invalid, ModeNotAllowed }
    
    pub fn verify_range_proof(out: &TransactionOutput, rp: &RangeProof) -> Result<(), RangeProofError> {
        match rp {
            RangeProof::ProofV1(bytes) => {
                if bytes.len() > 8192 { return Err(RangeProofError::Oversized); }
                // cryptographic verify here
                let _ = &out.commitment;
                Ok(())
            }
            RangeProof::Revealed { value: _ } => {
                // only valid if output flags say “revealed allowed”
                Ok(())
            }
        }
    }
    ```
  - В consensus validators возвращать `ModeNotAllowed` для `Revealed` (если этот режим нужен — ограничить `z00z_simulator`/tooling).
  - Запретить “best-effort”/вероятностные проверки в консенсусном валидаторе: только строгие правила + чёткая taxonomy ошибок.

### `batch_verify_range_proofs`

- **В чём идея**: range proof verification — одна из самых дорогих проверок в валидации транзакций/блоков.
  Batch verify позволяет проверять много proof’ов вместе (если схема это поддерживает), снижая число дорогостоящих операций.
  Важно: batch verify должен быть “официальным путём” (централизованная реализация), иначе оптимизации расползутся по кодовой базе и появятся трудно воспроизводимые perf баги.
  - **REVIEW** ✅ Это правильная инженерная дисциплина: одна реализация batch verify, один набор лимитов/guard’ов.
- **Что взять из Tari и почему полезно (+ tradeoffs)**:
  - Берём подход “batch verify как официальный путь”, плюс группировку по типу/версии и fallback “pinpoint” при провале.
  - Почему полезно в Z00Z:
    - валидаторы/rollup node будут валидировать много tx → batch критичен,
    - сканеры кошелька смогут дешевле обрабатывать историю.
      Tradeoffs:
  - Batch verify сложнее дебажить: при провале нужен fallback на поштучную проверку.
  - Нельзя смешивать разные версии/типы proof’ов в одном batch без аккуратной логики.
  - **REVIEW** ⚠️ Сложность высокая. Если Z00Z пока не валидирует блоки/много tx, имеет смысл пометить как node-phase (rollup node), а не wallet-phase.
- **Как реализовать в Z00Z**:
  - В `z00z_core/src/tx/validation/` сделать:
    - `batch_verify_range_proofs(outputs: &[TransactionOutput]) -> Result<(), RangeProofError>`,
    - стратегию fallback: если батч упал — проверить поштучно и вернуть конкретный индекс/ID.
  - Не допускать DoS-орекл:
    - сначала дешёвые guards (версии/длины/битфлаги),
    - затем группировка по variant/version,
    - затем batch, и только при ошибке — поштучный “pinpoint” с лимитом.
  - Где это живёт в Z00Z:
    - крипто-примитивы/батч-проверка: `z00z_crypto`,
    - протокольные правила и error taxonomy: `z00z_core/src/tx/validation/`.
  - Мини-снимок (shape) группировки + fallback:
    ```rust
    pub enum RangeProofError { Oversized, ModeNotAllowed, Invalid, InvalidAtIndex { index: usize } }
    
    pub fn batch_verify_range_proofs(outputs: &[TransactionOutput]) -> Result<(), RangeProofError> {
        let mut v1 = Vec::new();
        for (i, out) in outputs.iter().enumerate() {
            match &out.range_proof {
                RangeProof::ProofV1(bytes) => {
                    if bytes.len() > 8192 { return Err(RangeProofError::Oversized); }
                    v1.push((i, bytes.as_slice(), &out.commitment));
                }
                RangeProof::Revealed { .. } => {
                    return Err(RangeProofError::ModeNotAllowed);
                }
            }
        }
    
        if !v1.is_empty() {
            if crypto_batch_verify_v1(&v1).is_err() {
                for (idx, bytes, _commitment) in v1 {
                    if crypto_verify_v1(bytes).is_err() {
                        return Err(RangeProofError::InvalidAtIndex { index: idx });
                    }
                }
                return Err(RangeProofError::Invalid);
            }
        }
        Ok(())
    }
    
    fn crypto_batch_verify_v1(_items: &[(usize, &[u8], &[u8; 32])]) -> Result<(), ()> { Ok(()) }
    fn crypto_verify_v1(_bytes: &[u8]) -> Result<(), ()> { Ok(()) }
    ```

---

## z00z_crypto/tari/transaction_components/src/transaction_components/transaction_output_version.rs

### `TransactionOutputVersion::{get_current_version,TryFrom<u8>}`

- **В чём идея**: формат output’а почти наверняка будет эволюционировать (новые features, новые поля, новые proof форматы).
  Версия output’а делает эту эволюцию контролируемой: по версии выбираем правила decode/hash/signature.
  
  - **REVIEW** ✅ Да: это ровно тот же принцип, что уже применяется в `.wlt` (versioned payloads).
- **Что взять из Tari и почему полезно (+ tradeoffs)**:
  - Берём строгий `TryFrom<u8>` + `CURRENT`/`get_current_version()`.
  - Почему полезно в Z00Z:
    - кошелёк и узел могут безопасно хранить/передавать outputs между версиями,
    - unknown version не “просачивается” в подписи и не даёт silent corruption.
      Tradeoffs:
  - Ветка `decode_vN` должна иметь чёткие bounds и тесты.
- **Как реализовать в Z00Z**:
  - Аналогично kernel/input:
    ```rust
    #[repr(u8)]
    pub enum TransactionOutputVersion { V1 = 1 }
    
    impl TransactionOutputVersion {
        pub const CURRENT: TransactionOutputVersion = TransactionOutputVersion::V1;
        pub fn get_current_version() -> TransactionOutputVersion { Self::CURRENT }
    }
    
    impl TryFrom<u8> for TransactionOutputVersion {
        type Error = TxValidateError;
        fn try_from(v: u8) -> Result<Self, Self::Error> {
            match v { 1 => Ok(TransactionOutputVersion::V1), _ => Err(TxValidateError::UnsupportedVersion) }
        }
    }
    ```

---

## z00z_crypto/tari/transaction_components/src/rpc/models/transaction_query.rs

### `TxLocation` / `TxQueryResponse`

- **В чём идея**: UI/интеграции часто не нужны все детали транзакции — им нужно быстро понять:
  - где она сейчас (mempool/в блоке/не найдена/отклонена),
  - какие ключевые метаданные (height, block hash, confirmation state),
  - стоит ли retry/resubmit.
    `TxLocation` и `TxQueryResponse` — это “узкий” ответ, который:
  - дешёв в вычислении,
  - стабилен по схеме,
  - хорошо кешируется.
  - **REVIEW** ✅ Отличная идея для UX/perf: “узкий” эндпоинт для polling.
- **Что взять из Tari и почему полезно (+ tradeoffs)**:
  - Берём практику “location-only query” вместо “всегда отдавать full tx”.
  - Почему полезно в Z00Z:
    - меньше нагрузка на RPC и на storage,
    - проще строить polling UI,
    - удобнее для watcher’ов/агрегаторов (в `z00z_runtime`).
      Tradeoffs:
  - Появляются дополнительные типы/эндпоинты.
  - Нужно чётко определить семантику `NotFound` vs `Rejected` vs `Unknown`.
  - **REVIEW** ⚠️ Да, это критично для кошелька. Учитывая, что часть chain query функционала ещё TODO, лучше сразу пометить, какие состояния реально доступны в Phase 1.
- **Как реализовать в Z00Z**:
  - В `z00z_networks/rpc` добавить модели:
    ```rust
    pub enum TxLocation {
        Mempool,
        Mined { height: u64 },
        NotFound,
        Rejected { reason: String },
    }
    
    pub struct TxQueryResponse {
        pub tx_id: [u8; 32],
        pub location: TxLocation,
    }
    ```
  - В сервисе кошелька/ноды:
    - сначала быстрый lookup по индексам,
    - затем (опционально) enrich для mined (confirmation count).

### `TryFrom<Signature> for CompressedSignature`

- **В чём идея**: подпись может существовать в “полной” форме (структура) и в “сжатой” форме (фиксированное количество байт).
  На границе (RPC/storage) мы обязаны:
  - принимать только каноничные байты (чтобы не было разных представлений одной и той же подписи),
  - фиксировать длины,
  - возвращать нормализованную ошибку.
  - **REVIEW** ✅ Каноничность и фиксированные длины — правильный контракт.
- **Что взять из Tari и почему полезно (+ tradeoffs)**:
  - Берём strict canonical parsing.
  - Почему полезно в Z00Z:
    - предотвращает malleability на уровне сериализации,
    - упрощает кеши/индексы (одни и те же байты всегда означают одно и то же).
      Tradeoffs:
  - Старые клиенты, которые отправляют “почти валидные” байты, будут ломаться (и это правильно, но требует coordination).
  - **REVIEW** ⚠️ В Z00Z `z00z_crypto` уже реэкспортит некоторые signature types из Tari. Перед введением новых `Signature/CompressedSignature` стоит проверить, нельзя ли обернуть/переиспользовать существующие типы, чтобы не получить “две подписи” в API.
- **Как реализовать в Z00Z**:
  - В `z00z_crypto` определить API:
    ```rust
    pub struct Signature;
    
    pub struct CompressedSignature([u8; 64]);
    pub enum SigError { NonCanonical, WrongLength }
    
    impl TryFrom<Signature> for CompressedSignature {
        type Error = SigError;
        fn try_from(s: Signature) -> Result<Self, Self::Error> {
            let _ = s;
            Err(SigError::NonCanonical)
        }
    }
    ```
  - На decode (bytes -> signature): использовать `from_canonical_bytes` (или эквивалент) и сразу возвращать `SigError::NonCanonical`.

---

## z00z_crypto/tari/wallet/src/transaction_service/protocols/transaction_validation_protocol.rs

### `check_for_reorgs`

- **В чём идея**: кошелёк не является источником истины о цепи, но он хранит локальные статусы “mined/unmined/confirmed”.
  При reorg транзакция может “выпасть” из блока или оказаться в другом блоке/на другой высоте.
  Поэтому нужен дешёвый периодический чек:
  - взять “последнюю известную mined tx” (или несколько последних),
  - сверить, что блок/хедер на этой высоте всё ещё тот же,
  - если нет — инициировать перескан/понижение статусов.
    Смысл для девелопера: это защищает UX от “застрявших” mined-статусов после reorg.
  - **REVIEW** ✅ Хорошая и практичная идея: дешёвый reorg detector вместо вечного полного rescan.
- **Что взять из Tari и почему полезно (+ tradeoffs)**:
  - Берём прагматичный подход: **не полный rescan всегда**, а “cheap reorg detector” по одному-нескольким якорям.
  - Почему полезно в Z00Z:
    - `z00z_wallets` может работать и на full node, и на лёгком клиенте — reorg всё равно возможен,
    - снижает нагрузку: вместо постоянных тяжёлых запросов делаем маленькие проверки.
      Tradeoffs:
  - Ложные срабатывания возможны при неполной синхронизации или нестабильном RPC.
  - Выбор якорей (сколько tx/на каких высотах) влияет на вероятность пропуска reorg.
  - Реакция должна быть идемпотентной (можно повторить несколько раз без вреда).
  - **REVIEW** ✅ Идемпотентность здесь критична.
- **Как реализовать в Z00Z**:
  - В `z00z_wallets/src/services/tx_service.rs` (или рядом в сервисном слое) держать таблицу “mined anchors”:
    - `tx_id`, `mined_height`, `mined_block_hash`.
  - В фоне (tokio task) периодически выполнять:
    ```rust
    pub struct MinedAnchor {
        pub tx_id: [u8; 32],
        pub height: u64,
        pub block_hash: [u8; 32],
    }
    
    pub enum ReorgCheckOutcome {
        NoReorg,
        ReorgDetected { at_height: u64 },
        RpcUnavailable,
    }
    
    pub async fn check_for_reorgs(anchors: &[MinedAnchor], chain: &dyn ChainClient) -> ReorgCheckOutcome {
        // idea: query header hash at anchor.height and compare
        let _ = (anchors, chain);
        ReorgCheckOutcome::NoReorg
    }
    
    pub trait ChainClient {
        fn get_header_hash(&self, height: u64) -> std::pin::Pin<Box<dyn std::future::Future<Output = Result<[u8; 32], ()>> + Send>>;
    }
    ```
  - Если `ReorgDetected`:
    - пометить потенциально затронутые tx как `Unmined` (или `PendingReorg`),
    - запустить `rescan_wallet(from_height)`.
  - **REVIEW** ⚠️ Это требует реального chain API для заголовков по высоте. Учитывая, что часть chain client функционала ещё TODO, лучше пометить как Phase 2 и привязать к уже описанному `SAFETY_HEIGHT_MARGIN`/reconciliation.

### `query_base_node_for_transactions`

- **В чём идея**: кошелёк периодически спрашивает узел/chain-client: “что с моими транзакциями?”.
  Нормальная реализация должна:
  - делать запросы **батчами** (иначе UI polling быстро станет DoS’ом),
  - учитывать, что не для каждой локальной записи есть query key (например, imported/watch-only/legacy записи),
  - правильно различать: `NotFound`, `InMempool`, `Mined`, `Rejected`.
    Смысл: это “sync loop” статусов кошелька с chain view.
  - **REVIEW** ✅ Added value высокий: без этого статусы будут устаревать и UX ломается.
- **Что взять из Tari и почему полезно (+ tradeoffs)**:
  - Берём:
    - batched query API,
    - отдельный путь для “missing query key”,
    - строгий маппинг ответов в локальные статусы.
  - Почему полезно в Z00Z:
    - у Z00Z может быть несколько источников истины (rollup node, DA watcher, индексер) — batched queries позволяют унифицировать polling,
    - imported tx (например, от внешнего signer’а) не должны ломать sync loop.
      Tradeoffs:
  - Требуются дополнительные состояния в БД (например, `needs_recovery_query_key`).
  - При сетевых ошибках нельзя “откатывать” статусы — нужна осторожная политика retry/backoff.
  - **REVIEW** ✅ Да: лучше “no-op + retry”, чем деградация статуса от временного RPC.
- **Как реализовать в Z00Z**:
  - В `z00z_wallets` хранить для каждой tx опциональный query-key (например, `tx_id` или `kernel_hash`):
    ```rust
    pub struct WalletTxRecord {
        pub tx_id: [u8; 32],
        pub query_key: Option<[u8; 32]>,
        pub status: WalletTxStatus,
    }
    
    pub enum WalletTxStatus { Pending, Broadcast, Mined, Rejected, Unknown }
    ```
  - В sync task:
    - собрать `query_key` для записей, где он есть,
    - выполнить batched RPC `query_transactions(keys)` через `z00z_networks/rpc`,
    - результаты применить транзакционно в `z00z_storage`.
  - **REVIEW** ⚠️ Сейчас `ChainClient.get_transaction_status` в имплементации помечен TODO. Этот блок стоит явно обозначить как зависимый от реализации источника истины (node/indexer/watchers), иначе кажется, что он готов.
  - Для записей без ключа:
    - либо пометить “не отслеживается автоматически”,
    - либо попытаться восстановить ключ (если есть достаточно данных).

### `update_transaction_as_mined` / `update_transaction_as_unmined`

- **В чём идея**: “tx стала mined” — это не просто смена статуса.
  Обычно нужно согласованно обновить несколько вещей:
  - статус транзакции,
  - mined height / block hash / confirmations,
  - UTXO lock/unlock,
  - derived balance,
  - события для UI.
    Если это делать в разных местах, легко получить баг: “статус обновился, а баланс нет” или “событие ушло, а commit в БД не случился”.
    Поэтому нужен один централизованный путь “apply chain observation”.
  - **REVIEW** ✅ Сильная рекомендация: один транзакционный путь = меньше расхождений баланса/статуса/ивентов.
- **Что взять из Tari и почему полезно (+ tradeoffs)**:
  - Берём идею “single place for state transition + side effects” с транзакционностью.
  - Почему полезно в Z00Z:
    - гарантирует инвариант “emit after commit” (события только после успешной записи),
    - упрощает reorg handling: `update_as_unmined` делает обратную трансформацию тем же кодом.
      Tradeoffs:
  - Центральная функция разрастается и требует хорошей структуры входных данных.
  - Нужно осторожно проектировать идемпотентность (повторная обработка одного и того же mined-события не должна ломать состояние).
  - **REVIEW** ✅ Да, особенно важно при ретраях/дублирующихся событиях.
- **Как реализовать в Z00Z**:
  - В `z00z_wallets/src/services/tx_service.rs` ввести входной тип наблюдения цепи:
    ```rust
    pub struct ChainTxObservation {
        pub tx_id: [u8; 32],
        pub mined: Option<MinedInfo>,
        pub rejection_reason: Option<String>,
    }
    
    pub struct MinedInfo { pub height: u64, pub block_hash: [u8; 32] }
    ```
  - Одна функция применяет изменение внутри DB transaction (`z00z_storage`):
    ```rust
    pub async fn apply_chain_observation(db: &WalletDb, obs: ChainTxObservation) -> Result<(), WalletDbError> {
        let _ = (db, obs);
        // 1) begin tx
        // 2) update tx status + mined fields
        // 3) update UTXO locks / outputs state
        // 4) commit
        // 5) emit events (outside tx)
        Ok(())
    }
    
    pub struct WalletDb;
    pub enum WalletDbError { WriteFailed }
    ```
  - `update_transaction_as_mined` и `update_transaction_as_unmined` становятся тонкими wrappers вокруг `apply_chain_observation`.
  - **REVIEW** ✅ Отлично.
  - **REVIEW** ⚠️ Следите за правилом “emit after commit” (это уже проговорено в секции про `TransactionEvent` publishing). Лучше явно сослаться на него здесь.

---

## z00z_crypto/tari/common_types/src/tari_address/single_address.rs

### `SingleAddress::{from_bytes,to_vec}`

- **В чём идея**: address — это не просто “строка”. Это **протокольный контейнер байтов**, который должен:
  - быть однозначно распарсиваемым (фиксированный или ограниченный формат),
  - содержать network/discriminator (чтобы нельзя было случайно отправить на другую сеть),
  - иметь checksum/контроль целостности (чтобы ловить опечатки/битые данные),
  - сохранять каноничность (одни и те же данные → одни и те же bytes).
    `from_bytes` — это boundary decode (строгое принятие внешних байтов), а `to_vec` — каноническая сериализация обратно.
  - **REVIEW** ✅ Правильно: address parsing/serialization должен быть строгим и каноническим.
  - **REVIEW** ⚠️ Важно централизовать это в одном месте, чтобы разные слои (wallet/rpc/storage) не имели “слегка разных” парсеров и не принимали разные варианты одного и того же адреса.
- **Что взять из Tari и почему полезно (+ tradeoffs)**:
  - Берём практику “fail-fast на границе”:
    - проверка длины,
    - проверка network byte,
    - проверка checksum,
    - reject неизвестных feature bits.
  - Почему полезно в Z00Z:
    - кошелёк/CLI сразу ловит ошибку адреса до создания tx,
    - меньше риск пользовательских потерь (wrong network / typo),
    - проще поддерживать несколько кодеков (emoji/base58) поверх одного bytes-представления.
      Tradeoffs:
  - Формат адреса становится контрактом: изменить можно только через версионирование.
  - Если сделать формат слишком “свободным”, возрастает DoS/амбигуити при парсинге.
  - **REVIEW** ✅ Всё по делу: адрес — это протокольный контракт, а не строка.
- **Как реализовать в Z00Z**:
  - Вынести address в отдельный crate/модуль (логичнее в `z00z_wallets` или общий `z00z_core/src/address/` если адрес нужен и ноде):
    ```rust
    pub enum NetworkId { Mainnet, Testnet, Devnet }
    
    #[derive(Clone, Debug, Eq, PartialEq)]
    pub struct Z00ZSingleAddress {
        pub network: NetworkId,
        pub payload: [u8; 32],
    }
    
    pub enum AddressError { WrongLength, BadChecksum, UnsupportedNetwork }
    
    impl Z00ZSingleAddress {
        pub const BYTES_LEN: usize = 1 + 32 + 4; // network + payload + checksum
    
        pub fn from_bytes(bytes: &[u8]) -> Result<Self, AddressError> {
            if bytes.len() != Self::BYTES_LEN { return Err(AddressError::WrongLength); }
            let network = match bytes[0] {
                0x00 => NetworkId::Mainnet,
                0x01 => NetworkId::Testnet,
                0x02 => NetworkId::Devnet,
                _ => return Err(AddressError::UnsupportedNetwork),
            };
            let mut payload = [0u8; 32];
            payload.copy_from_slice(&bytes[1..33]);
            // checksum = bytes[33..37]; verify
            Ok(Self { network, payload })
        }
    
        pub fn to_vec(&self) -> Vec<u8> {
            // canonical encode + checksum
            let _ = self;
            vec![]
        }
    }
    ```
  - В `z00z_wallets` enforcement:
    - любые UI/CLI/RPC вводы адреса сначала идут в `from_bytes`/`from_base58`/`from_emoji`,
    - перед отправкой tx проверять `address.network == wallet.network`.
  - **REVIEW** ⚠️ Перед тем как вводить новый `Z00ZSingleAddress`, стоит проверить, можно ли переиспользовать/обернуть существующий тип адреса из Tari (чтобы не иметь два параллельных формата адресов в проекте).

### ❌`to_emoji_string` / `from_emoji_string`

- **В чём идея**: emoji-кодек — это “человекоориентированная упаковка” для тех же канонических байтов адреса.
  Он решает практическую проблему: пользователи часто пересылают адресы вручную/голосом/скриншотами.
  Emoji-алфавит при правильном выборе:
  
  - снижает вероятность путаницы похожих символов (как `O/0/I/l` в base58),
  - легче диктовать/проверять визуально.
    Важно: emoji-string **не является источником истины** — источником истины остаются bytes адреса + checksum.
  - **REVIEW** ✅ Правильно сформулировано: emoji — только представление.
- **Что взять из Tari и почему полезно (+ tradeoffs)**:
  - Берём идею “два представления”:
    - bytes (каноничные),
    - emoji (UX представление).
  - Почему полезно в Z00Z:
    - хорошая UX-опция для мобильного/чатов,
    - checksum + строгий decode дают ранний reject при ошибке символа.
      Tradeoffs:
  - Нужен **стабильный emoji alphabet** и его версионирование (иначе старые клиенты не смогут декодить).
  - Некоторые платформы/шрифты рендерят emoji неодинаково → важно ограничить alphabet на “простые” emoji.
  - Строки могут быть длиннее base58.
  - **REVIEW** ⚠️ Added value зависит от продукта (мобилка/чат). Если это не приоритет, можно оставить как “optional later” — иначе большой тестовый surface ради UX-эксперимента.
- **Как реализовать в Z00Z**:
  - Держать emoji-кодек на “edge” (UI/CLI/RPC layer), но реализацию — в общем модуле address codecs:
    - **REVIEW** ⚠️ В `z00z_wallets` сейчас нет `src/address/...`; если кодек нужен, лучше держать его в `z00z_core` (или отдельном crate для адресов), а в `z00z_wallets` оставить только использование.
  - Code-shape:
    ```rust
    impl Z00ZSingleAddress {
        pub fn to_emoji_string(&self) -> String {
            // bytes -> base-N digits -> emoji alphabet
            let _ = self;
            String::new()
        }
    
        pub fn from_emoji_string(s: &str) -> Result<Self, AddressError> {
            // emoji digits -> bytes -> from_bytes (checksum/network validation)
            let _ = s;
            Err(AddressError::BadChecksum)
        }
    }
    ```
  - Инвариант: `from_emoji_string(to_emoji_string(addr)) == addr`.

### `from_base58` / `to_base58`

- **В чём идея**: base58 — это “дефолтный” переносимый текстовый формат:
  - копируется/вставляется,
  - не содержит пробелов/спецсимволов,
  - обычно хорошо поддержан библиотеками.
    Как и emoji, он должен быть просто представлением канонических bytes.
    Критично, чтобы ошибки были **семантическими** (wrong checksum, wrong network), а не “parse failed”.
  - **REVIEW** ✅ Да: UX выигрывает, когда ошибка говорит “wrong network”, а не “invalid”.
- **Что взять из Tari и почему полезно (+ tradeoffs)**:
  - Берём:
    - checksum в байтовом формате,
    - network byte/discriminator,
    - чёткую дифференциацию ошибок.
  - Почему полезно в Z00Z:
    - совместимость с типичными UX потоками (QR, копипаст),
    - возможность делать “network mismatch” предупреждение, а не просто “invalid address”.
      Tradeoffs:
  - Две кодировки (base58 + emoji) — это поверхность тестирования.
  - base58 не решает проблему похожих символов полностью.
  - **REVIEW** ⚠️ Не пишите base58 руками. Лучше выбрать одну хорошо поддержанную crate и стандартизировать её usage (и тест-вектора) во всём репо.
- **Как реализовать в Z00Z**:
  - Добавить модуль `address/codecs/base58.rs`:
    ```rust
    impl Z00ZSingleAddress {
        pub fn to_base58(&self) -> String {
            let bytes = self.to_vec();
            let _ = bytes;
            String::new()
        }
    
        pub fn from_base58(s: &str) -> Result<Self, AddressError> {
            let _ = s;
            // decode -> from_bytes
            Err(AddressError::WrongLength)
        }
    }
    ```
  - В `z00z_wallets` при вводе адреса:
    - поддержать auto-detect (если строка начинается с определённого prefix или содержит emoji → выбрать codec),
    - но финальная валидация всегда через `from_bytes`.

---

## z00z_crypto/tari/common_types/src/tari_address/dual_address.rs

### `DualAddress::new` + `memo_field_payment_id`

- **В чём идея**: dual address объединяет два публичных компонента (условно “view key” и “spend key”) в одном адресе.
  Это позволяет:
  - отделить “видимость/сканирование” и “трату”,
  - дать кошельку возможность watch-only режима,
  - гибко расширять адрес (например, добавить memo/payment id) без изменения основного payload.
    `memo_field_payment_id` — это пример controlled extension: часть адреса, которая может переносить небольшой идентификатор платежа.
  - **REVIEW** ✅ “feature bits + optional section” — правильный способ расширять адрес без ломания старых клиентов.
- **Что взять из Tari и почему полезно (+ tradeoffs)**:
  - Берём паттерн: **feature bits + optional section**.
    - feature bit однозначно говорит, есть ли memo,
    - memo имеет bounded длину.
  - Почему полезно в Z00Z:
    - можно добавить payment-id/metadata для UX (например, авто-сопоставление входящих платежей),
    - сохраняем обратную совместимость: старый клиент увидит feature bit и сможет отказать или игнорировать по политике.
  - **REVIEW** ⚠️ У Z00Z уже есть `payref`-концепт. Если добавить ещё и `payment_id` в адрес, важно не получить два параллельных идентификатора платежа с разной семантикой (что хранить, что отдавать наружу, что проверять).
      Tradeoffs:
  - Больше вариантов кодека → нужна строгая спецификация и тесты.
  - memo в адресе — это потенциальная утечка метаданных (privacy tradeoff) → должно быть опционально и ограничено.
- **Как реализовать в Z00Z**:
  - Тип:
    ```rust
    pub struct Z00ZDualAddress {
        pub network: NetworkId,
        pub view_pk: [u8; 32],
        pub spend_pk: [u8; 32],
        pub payment_id: Option<[u8; 8]>,
    }
    
    impl Z00ZDualAddress {
        pub fn new(network: NetworkId, view_pk: [u8; 32], spend_pk: [u8; 32]) -> Self {
            Self { network, view_pk, spend_pk, payment_id: None }
        }
    
        pub fn memo_field_payment_id(mut self, pid: [u8; 8]) -> Self {
            self.payment_id = Some(pid);
            self
        }
    }
    ```
  - В `z00z_wallets`:
    - payreq/payref integration: если payment-id нужен, привязать его к invoice/контракту,
    - но по умолчанию оставить `None`.

### `from_bytes` / `to_vec` (bounded variable length)

- **В чём идея**: как только в формате появляется variable-length часть (memo/extra fields), это становится DoS поверхностью.
  Поэтому правило простое:
  - у любой variable-length секции есть явный `MAX_*`,
  - decode проверяет длину до аллокаций/копирований,
  - encode всегда выдаёт каноничную длину (без “лишних нулей”).
  - **REVIEW** ✅ Абсолютно: bounds до аллокаций — это must.
- **Что взять из Tari и почему полезно (+ tradeoffs)**:
  - Берём строго bounded encoding для memo/address extensions.
  - Почему полезно в Z00Z:
    - защита RPC/UI от адресов “на мегабайты”,
    - предсказуемые размеры QR/строк,
    - проще обеспечить стабильный hash/checksum.
      Tradeoffs:
  - Нужно выбрать MAX. Если слишком мал — неудобно для будущих расширений.
  - Если в будущем понадобятся большие поля, придётся вводить новую версию адреса.
  - **REVIEW** ✅ Это правильный tradeoff: лучше новая версия, чем “неограниченный memo”.
- **Как реализовать в Z00Z**:
  - Пример bounded decode (shape):
    ```rust
    impl Z00ZDualAddress {
        pub const MAX_MEMO_LEN: usize = 32;
    
        pub fn from_bytes(bytes: &[u8]) -> Result<Self, AddressError> {
            // 1) base len checks (network + 2 pubkeys + flags)
            // 2) if memo bit set: read memo_len and require memo_len <= MAX_MEMO_LEN
            let _ = bytes;
            Err(AddressError::WrongLength)
        }
    
        pub fn to_vec(&self) -> Vec<u8> {
            // canonical: if payment_id None, do not emit memo section
            let _ = self;
            vec![]
        }
    }
    ```
  - В `z00z_wallets`/`z00z_networks` при приёме адреса из RPC:
    - не аллоцировать `Vec` под memo до проверки bounds.
  - **REVIEW** ⚠️ Убедитесь, что checksum/hmac (если есть) считается по каноническим bytes (включая отсутствие секции, когда `None`). Иначе возможны “две сериализации одного адреса”.

---

## z00z_crypto/tari/comms/core/src/net_address/mutliaddresses_with_stats.rs

### `MultiaddressesWithStats::merge`

- **В чём идея**: у одного peer’а может быть несколько адресов (tcp, onion, tor, ws, и т.д.).
  Кроме самих адресов важны **наблюдаемые метрики качества**:
  - latency (пинг/handshake RTT),
  - last_seen / last_attempt,
  - success/fail counters,
  - “source” (откуда адрес узнали: seed, gossip, manual).
    `merge` — это операция “объединить новый набор объявленных адресов с локально накопленной статистикой”, не теряя полезные наблюдения.
    Смысл: адреса часто устаревают/меняются, но статистика помогает выбирать лучший адрес без гаданий.
  - **REVIEW** ✅ Added value высокий для сетевого слоя: это уменьшает churn и ускоряет соединения.
- **Что взять из Tari и почему полезно (+ tradeoffs)**:
  - Берём:
    - хранение “много адресов + stats” вместо “один адрес”,
    - merge, который не выбрасывает накопленную статистику без причины,
    - понятные правила: когда заменять адрес, когда обновлять timestamps, когда обнулять метрики.
  - Почему полезно в Z00Z:
    - `z00z_networks` (http/tor/rpc) может иметь разные dial paths; статистика позволит быстрее подключаться,
    - уменьшает churn соединений: выбираем “best known address”,
    - защищает от stale gossip: не прыгаем на каждый новый advertised addr.
      Tradeoffs:
  - Merge правила легко сделать “магическими” → нужно детерминированное и документированное поведение.
  - Адреса могут быть злонамеренно навязаны (poisoning) → обязательно bounds + source weighting.
  - **REVIEW** ✅ Хорошо, что poisoning указан явно.
- **Как реализовать в Z00Z**:
  - В `z00z_networks` завести типы (или в `z00z_utils` если это общий util):
    ```rust
    use std::collections::BTreeMap;
    use std::time::{Duration, SystemTime};
    
    #[derive(Clone, Debug, Eq, PartialEq, Ord, PartialOrd)]
    pub struct Multiaddr(String);
    
    #[derive(Clone, Debug)]
    pub enum AddressSource { Seed, Gossip, Manual }
    
    #[derive(Clone, Debug)]
    pub struct AddressStats {
        pub last_seen: Option<SystemTime>,
        pub last_attempt: Option<SystemTime>,
        pub avg_latency: Option<Duration>,
        pub success: u32,
        pub fail: u32,
        pub source: AddressSource,
    }
    
    #[derive(Clone, Debug)]
    pub struct MultiaddressesWithStats {
        pub addrs: BTreeMap<Multiaddr, AddressStats>,
    }
    
    impl MultiaddressesWithStats {
        pub fn merge(&mut self, advertised: Vec<(Multiaddr, AddressSource)>, now: SystemTime) {
            // rule-of-thumb:
            // - add new addresses with empty stats
            // - update source (maybe keep strongest)
            // - keep existing stats for known addresses
            // - optionally drop addresses not seen for long (handled by prune/sort step)
            let _ = (advertised, now);
        }
    }
    ```
  - Key point: ключом является сам multiaddr string (канонизированный), а не “индекс”. Тогда merge становится детерминированным.
  - **REVIEW** ⚠️ “канонизированный” multiaddr нужно определить (нормализация, lowercasing где применимо, снятие лишних слэшей и т.п.), иначе одинаковый адрес может существовать в нескольких строковых формах.

### `sort_and_truncate_addresses` + `MAX_ADDRESSES`

- **В чём идея**: адресов может накопиться много (особенно через gossip). Это проблема:
  - память/DB растёт,
  - попытки коннекта становятся дорогими,
  - появляется DoS поверхность.
    Поэтому нужен:
  - жёсткий верхний предел `MAX_ADDRESSES`,
  - детерминированная сортировка (чтобы разные компоненты принимали одинаковые решения),
  - выбор “лучших” адресов по скору.
  - **REVIEW** ✅ Наличие жёсткого `MAX_*` и детерминированного выбора — обязательная защита от DoS.
- **Что взять из Tari и почему полезно (+ tradeoffs)**:
  - Берём bounding + scoring.
  - Почему полезно в Z00Z:
    - `z00z_rollup_node`/p2p watchers могут поддерживать стабильные соединения,
    - ограничиваем влияние злонамеренного flood адресов.
      Tradeoffs:
  - Любой scoring — это политика. Плохая политика может “уронить” хороший адрес.
  - Нужна observability: лог/метрика “почему адрес был отброшен”.
  - **REVIEW** ✅ Да: иначе вы не сможете отлаживать “почему не коннектимся”.
- **Как реализовать в Z00Z**:
  - Ввести `MAX_ADDRESSES` и scoring функцию:
    ```rust
    impl MultiaddressesWithStats {
        pub const MAX_ADDRESSES: usize = 16;
    
        pub fn sort_and_truncate_addresses(&mut self) {
            // 1) compute score for each addr
            // 2) keep top MAX_ADDRESSES
            // 3) drop the rest
        }
    
        fn score(stats: &AddressStats) -> i64 {
            // example (shape only): prefer successful + recently seen + low latency
            let _ = stats;
            0
        }
    }
    ```
  - В `z00z_networks` dialer:
    - всегда сначала пробовать top-1/top-2,
    - остальные — только при фейле.

### latency/last_seen updates

- **В чём идея**: “лучший адрес” нельзя выбрать один раз навсегда.
  Реальность меняется (NAT, tor circuits, мобильные сети). Поэтому мы постоянно обновляем stats:
  - при успешном коннекте: `last_seen = now`, `success += 1`, обновить `avg_latency`,
  - при провале: `fail += 1`, `last_attempt = now`, возможно penalize.
    Смысл: dialer становится data-driven: он учится на своих попытках.
  - **REVIEW** ✅ Это логичное продолжение `merge/sort`: без обновлений stats всё быстро протухнет.
- **Что взять из Tari и почему полезно (+ tradeoffs)**:
  - Берём минимум метрик, которые реально помогают:
    - `last_seen`,
    - `avg_latency` (EMA),
    - counters.
  - Почему полезно в Z00Z:
    - быстрый reconnection,
    - меньше “слепых” попыток по плохим адресам,
    - можно аккуратно деградировать при флаппинге сети.
      Tradeoffs:
  - Метрики могут быть отравлены (если attacker провоцирует фейлы) → scoring должен учитывать source/кап.
  - Нужно ограничивать память (не хранить бесконечный history).
  - **REVIEW** ⚠️ Для `avg_latency`/EMA важно определить поведение при outlier’ах и при “нет данных” (иначе scoring станет нестабильным).
- **Как реализовать в Z00Z**:
  - EMA вместо хранения большого списка latency:
    ```rust
    impl AddressStats {
        pub fn record_success(&mut self, now: SystemTime, latency: Duration) {
            self.last_seen = Some(now);
            self.success = self.success.saturating_add(1);
            self.avg_latency = Some(match self.avg_latency {
                None => latency,
                Some(old) => {
                    // EMA-ish: new = old*0.8 + latency*0.2
                    old
                }
            });
        }
    
        pub fn record_failure(&mut self, now: SystemTime) {
            self.last_attempt = Some(now);
            self.fail = self.fail.saturating_add(1);
        }
    }
    ```
  - В dialer после каждой попытки обновлять stats и сохранять в storage (если адреса persistятся).

---

## z00z_crypto/tari/comms/core/src/test_utils/factories/net_address.rs

### `NetAddressFactory` / `NetAddressesFactory`

- **В чём идея**: сетевые тесты сложно писать, если адреса/peer id генерируются случайно.
  Фабрики дают:
  - детерминированные multiaddr по seed/индексу,
  - возможность быстро собрать топологию (N peers) без ручного хардкода,
  - воспроизводимость flaky багов.
    Смысл: “fixtures for networking”.
  - **REVIEW** ✅ Полезная тестовая инфраструктура, особенно для flaky сетевых сценариев.
- **Что взять из Tari и почему полезно (+ tradeoffs)**:
  - Берём pattern “test-only factories”, которые живут в отдельном модуле/feature и не попадают в prod.
  - Почему полезно в Z00Z:
    - `z00z_simulator` сможет создавать сценарии с predictable адресами,
    - `z00z_networks/*` тесты смогут стабильно проверять dial/merge/scoring.
      Tradeoffs:
  - Есть риск утечки test-utils в production binary → надо прятать за feature/`cfg(test)`.
  - **REVIEW** ✅ Да, это обязательное требование.
  - Фабрика должна генерировать только валидные адреса (иначе тесты “тестируют мусор”).
- **Как реализовать в Z00Z**:
  - В `z00z_networks` (или `z00z_utils`) завести `test_utils` модуль:
    ```rust
    #[cfg(any(test, feature = "test-utils"))]
    pub struct NetAddressFactory {
        pub base_port: u16,
    }
    
    #[cfg(any(test, feature = "test-utils"))]
    impl NetAddressFactory {
        pub fn tcp_localhost(&self, i: u16) -> String {
            format!("/ip4/127.0.0.1/tcp/{}", self.base_port + i)
        }
    }
    ```
  - Использовать в тестах `MultiaddressesWithStats::merge`/`sort_and_truncate_addresses` и в симуляторе сценариев.

---

## z00z_crypto/tari/utils/src/password.rs

### `SafePassword` + constructors + serde policy

- **В чём идея**: пароль — это high-risk секрет, который легко утечь:
  - через `Debug`/`Display`,
  - через panic/backtrace (если пароль попал в форматируемую строку),
  - через сериализацию (JSON/YAML),
  - через долгоживущие `String` в памяти.
  Поэтому его нужно упаковывать в тип, который:
  - **маскирует вывод** (redacted `Debug`),
  - **zeroize-on-drop** (очищает байты при уничтожении),
  - ограничивает API (нельзя “случайно” получить `&str` и разнести по логам),
  - запрещает/ограничивает serde сериализацию.
  Конструкторы важны не меньше самого типа: они определяют, где и как пароль впервые появляется в памяти.
  - **REVIEW** ✅ Абсолютно правильная постановка проблемы (Debug/serde/panic/memory lifetime).
- **Что взять из Tari и почему полезно (+ tradeoffs)**:
  - Берём:
    - явный тип-обёртку для секрета,
    - redacted debug,
    - zeroize,
    - чёткую позицию по serde: **пароль нельзя сериализовать** обратно наружу.
  - Почему полезно в Z00Z:
    - `z00z_wallets` и `z00z_storage` часто работают в окружениях с подробным логированием; этот тип снижает вероятность фатальных утечек,
    - проще сделать код-ревью: “пароль должен быть только `SafePassword`”,
    - позволяет единообразно прокидывать пароль в KDF/AEAD без конвертации в `String`.
    Tradeoffs:
  - Чуть меньше удобства при дебаге (и это хорошо).
  - Нужно аккуратно проектировать “reveal” API (строго минимальный и по возможности одноразовый).
  - Невозможно полностью контролировать, как пароль попал в память (терминал/GUI), но можно уменьшить время жизни и копирования.
  - **REVIEW** ✅ Хорошая “реалистичная” оговорка.
- **Как реализовать в Z00Z**:
  - В `z00z_crypto` или `z00z_utils` (если нужен вне крипто) определить тип:
    ```rust
    use zeroize::Zeroize;
    
    pub struct SafePassword(Vec<u8>);
    
    impl Drop for SafePassword {
        fn drop(&mut self) { self.0.zeroize(); }
    }
    
    impl core::fmt::Debug for SafePassword {
        fn fmt(&self, f: &mut core::fmt::Formatter<'_>) -> core::fmt::Result {
            f.write_str("SafePassword(**redacted**)")
        }
    }
    
    impl SafePassword {
        pub fn from_utf8(s: &str) -> Self { Self(s.as_bytes().to_vec()) }
        pub fn as_bytes(&self) -> &[u8] { &self.0 }
    }
    ```
  - Serde policy:
    - `Deserialize` допустим только для входных boundary (CLI config, если нужно),
    - `Serialize` либо отсутствует, либо всегда возвращает ошибку.
  - **REVIEW** ⚠️ Важно отметить, что `SafePassword` уже используется в кодовой базе Z00Z (например, `z00z_wallets` импортирует `z00z_crypto::SafePassword`). Этот раздел скорее про закрепление политики/инвариантов, чем про новую фичу.
  - В `z00z_wallets`/RPC:
    - не принимать пароль как “обычный” string-параметр RPC без необходимости,
    - лучше: принимать “passphrase” только для локального CLI, а удалённый API — через заранее установленный secret channel.

---

## z00z_crypto/tari/app_grpc/src/authentication/salted_password.rs

### `create_salted_hashed_password`

- **В чём идея**: пароль нельзя хранить и нельзя “просто хешировать”. Нужно хранить результат password hashing (PHF/KDF) так, чтобы:
  - salt был уникальным и хранился рядом,
  - параметры (m/t/p, версия алгоритма) были частью записи,
  - формат был самодокументируемым и расширяемым.
  PHC string (например, `$argon2id$v=19$m=...,t=...,p=...$<salt>$<hash>`) — удобный стандартный контейнер.
  Важный смысл: **verify** должен читать параметры из PHC, а не из “текущих дефолтов”, иначе старые записи станут непроверяемыми.
  - **REVIEW** ✅ Это правильный контракт для долгоживущих wallet DB.
- **Что взять из Tari и почему полезно (+ tradeoffs)**:
  - Берём:
    - хранение PHC string как единственного storage формата,
    - возможность мягкого upgrade параметров: “верифицировали старый PHC → при следующей записи перехешировали на новые параметры”.
  - Почему полезно в Z00Z:
    - в `z00z_storage`/wallet DB можно хранить один string и не думать о миграциях структуры при изменении параметров,
    - проще проводить security **REVIEW**s: salt/params явно видны в формате,
    - можно настраивать параметры по сети/платформе (мобильный vs сервер) без ломания формата.
    Tradeoffs:
  - Нужна зависимость (argon2) и аккуратная настройка параметров.
  - Стоимость вычислений должна быть ограничена (иначе DoS при verify, если PHC параметры злонамеренно огромные) → нужны bounds.
  - Любые отличающиеся сообщения ошибок могут стать oracle (например, “bad format” vs “wrong password”) — ошибки лучше нормализовать.
  - **REVIEW** ✅ Да: нормализация ошибок и bounds на параметры PHC — обязательны.
- **Как реализовать в Z00Z**:
  - В `z00z_crypto` (или `z00z_wallets` auth layer) зафиксировать:
    - `PasswordHash` как newtype над PHC string,
    - max длину PHC строки,
    - политику upgrade.
  - Code-shape:
    ```rust
    pub struct PasswordHashPhc(String);
    
    pub enum PasswordHashError {
        InvalidFormat,
        ParamsTooLarge,
        HashFailed,
    }
    
    pub fn create_salted_hashed_password(pw: &SafePassword) -> Result<PasswordHashPhc, PasswordHashError> {
        let _ = pw;
        // 1) generate random salt
        // 2) hash with argon2id and chosen params
        // 3) return PHC string
        Err(PasswordHashError::HashFailed)
    }
    
    pub fn verify_password(pw: &SafePassword, phc: &PasswordHashPhc) -> Result<bool, PasswordHashError> {
        let _ = (pw, phc);
        // parse PHC, enforce param bounds, then verify
        Ok(false)
    }
    ```
  - В `z00z_storage`:
    - хранить `PasswordHashPhc` как строку,
    - при verify всегда проверять bounds параметров из PHC.

---

## z00z_crypto/tari/common_types/src/seeds/cipher_seed.rs

### `CipherSeed::encipher`

- **В чём идея**: `CipherSeed` — это “мастер-секрет” кошелька, который нужно:
  - безопасно хранить в БД (шифрованно),
  - безопасно экспортировать как backup (mnemonic/bytes),
  - уметь импортировать обратно без oracle-утечек.
  `encipher` отвечает за создание **долгоживущего контейнера**: набор байтов, который включает:
  - версию формата,
  - birthday (оптимизация scanning: мы знаем, с какого времени сканировать),
  - KDF параметры (или ссылку на них),
  - nonce/IV,
  - ciphertext,
  - MAC/AEAD tag (целостность).
  Ключевой смысл: **все поля, которые влияют на проверку целостности/валидности, должны быть аутентифицированы**.
  - **REVIEW** ✅ Отличная спецификация контейнера: versioning + KDF params + AEAD/MAC и всё аутентифицировано.
- **Что взять из Tari и почему полезно (+ tradeoffs)**:
  - Берём:
    - versioned binary container,
    - “birthday as first-class field” для ускорения восстановления,
    - строгий контракт: decode возможен только если прошла аутентификация.
  - Почему полезно в Z00Z:
    - `z00z_wallets` и `z00z_storage` получают один устойчивый формат backup’а,
    - birthday позволяет `z00z_wallets` делать rescan быстрее и дешевле,
    - versioning даёт возможность менять KDF/AEAD в будущем.
    Tradeoffs:
  - Это “формат навсегда”: любое изменение требует новой версии и backward compatibility.
  - Контейнер нужно строго ограничивать по размерам (anti-DoS) при импорте.
  - Ошибки нужно нормализовать (не различать “MAC неверен” vs “структура неверна” слишком детально), чтобы не давать oracle.
  - **REVIEW** ✅ Да: это критично для import/backup.
- **Как реализовать в Z00Z**:
  - В `z00z_crypto/src/cipher_seed.rs` сделать явный контейнер:
    ```rust
    pub struct SafePassword(Vec<u8>);
    
    pub struct CipherSeed([u8; 32]);
    
    pub struct EncipheredCipherSeed(Vec<u8>);
    
    pub enum CipherSeedError {
        InvalidCipherSeed,
        UnsupportedVersion,
        ParamsTooLarge,
    }
    
    pub fn encipher(seed: &CipherSeed, pass: &SafePassword) -> Result<EncipheredCipherSeed, CipherSeedError> {
        let _ = (seed, pass);
        // shape:
        // bytes = version || kdf_params || birthday || nonce || ciphertext || tag
        Ok(EncipheredCipherSeed(vec![]))
    }
    ```
  - **REVIEW** ⚠️ В примере повторно определяется `SafePassword(Vec<u8>)`. В Z00Z `SafePassword` уже есть и используется — лучше не создавать второй “почти такой же” тип даже в примере.
  - Where it plugs in:
    - `z00z_wallets`: export/import flows produce/consume `EncipheredCipherSeed`.
    - `z00z_storage`: хранит `EncipheredCipherSeed` как blob; не пытается “понимать” формат.

### `CipherSeed::from_enciphered_bytes`

- **В чём идея**: импорт seed — это adversarial boundary: входные bytes может подать кто угодно.
  Цель парсинга:
  - не аллоцировать/не паниковать на мусоре,
  - не раскрывать подробности ошибок (oracle),
  - сделать один безопасный результат: либо “валидный seed”, либо “InvalidCipherSeed”.
  Правильный порядок:
  1) минимальные length guards,
  2) parse version/параметры в пределах bounds,
  3) криптографическая проверка целостности (AEAD tag / MAC) и только потом — “смысловые” проверки.
  - **REVIEW** ✅ Порядок проверок корректный: сначала guards/version/bounds, потом AEAD/MAC.
- **Что взять из Tari и почему полезно (+ tradeoffs)**:
  - Берём идею “normalized error surface”:
    - внешнему миру почти всегда возвращаем одну ошибку,
    - детальную причину пишем только в debug logs (и то осторожно).
  - Почему полезно в Z00Z:
    - снижает риск oracle-атак на пароль/контейнер,
    - делает UX проще: “неверный пароль или повреждённый backup”,
    - облегчает поддержку нескольких версий контейнера.
    Tradeoffs:
  - Сложнее диагностика при разработке (компенсируется feature-логами).
  - Больше кода: bounds, version dispatch, CT comparisons.
  - **REVIEW** ⚠️ Для password/seed сравнения и проверок используйте constant-time where applicable, но не усложняйте без нужды там, где это не влияет (например, различение unsupported version).
- **Как реализовать в Z00Z**:
  - API shape:
    ```rust
    pub fn from_enciphered_bytes(bytes: &[u8], pass: &SafePassword) -> Result<CipherSeed, CipherSeedError> {
        // 1) bounds
        // 2) parse version
        // 3) parse params within bounds
        // 4) decrypt/verify tag
        // 5) return seed
        let _ = (bytes, pass);
        Err(CipherSeedError::InvalidCipherSeed)
    }
    ```
  - Важно: различать `UnsupportedVersion` (это не секрет) и `InvalidCipherSeed` (всё остальное), но наружу можно маппить оба в безопасный общий error.

### `apply_stream_cipher` (nonce derivation)

- **В чём идея**: если используется stream-cipher/AEAD, nonce/IV не должен:
  - повторяться для одного ключа,
  - пересекаться между протоколами (cross-protocol reuse).
  Нормальная практика: derive nonce через domain separation tag (DST) + соль/контекст.
  Смысл: даже если где-то повторится “сырой” ввод, nonce для другого протокола будет другим.
  - **REVIEW** ✅ DST-based derivation — правильная защита от cross-protocol reuse.
- **Что взять из Tari и почему полезно (+ tradeoffs)**:
  - Берём DST-derivation как обязательную часть крипто-контракта.
  - Почему полезно в Z00Z:
    - `z00z_crypto` уже имеет `hash_domains`/DST подход — это ложится естественно,
    - снижает риск “случайно тем же ключом/nonce шифруем разные вещи”.
    Tradeoffs:
  - DST список нужно фиксировать и версионировать.
  - Нужно аккуратно описать, какие inputs участвуют (salt, birthday, version).
  - **REVIEW** ⚠️ Да: если inputs не зафиксировать, разные имплементации начнут derivation “по-своему” и сломают совместимость.
- **Как реализовать в Z00Z**:
  - В `z00z_crypto/src/hash_domains.rs` добавить домен, например `z00z.cipher_seed.nonce.v1`.
  - Code-shape:
    ```rust
    pub fn derive_cipher_seed_nonce_v1(salt: &[u8], version: u8) -> [u8; 12] {
        let _ = (salt, version);
        [0u8; 12]
    }
    ```

### `Mnemonic<CipherSeed>` conversions

- **В чём идея**: mnemonic — это UX формат. Крипто-контейнер должен быть wordlist-agnostic:
  - crypto слой работает с bytes,
  - wallet/UI слой решает, какой wordlist и какие правила ввода/нормализации использовать.
  Это важно для:
  - поддержки разных языков,
  - строгой нормализации пробелов/регистра,
  - предотвращения утечек (mnemonic нельзя логировать).
  - **REVIEW** ✅ Правильно: mnemonic — это исключительно UI/edge concern.
- **Что взять из Tari и почему полезно (+ tradeoffs)**:
  - Берём разделение “контейнер bytes” vs “mnemonic adapter”.
  - Почему полезно в Z00Z:
    - `z00z_crypto` остаётся минимальным и тестируемым,
    - `z00z_wallets` может поддерживать разные UX потоки (CLI, GUI, QR) не меняя crypto формата.
    Tradeoffs:
  - Нужен adapter слой и аккуратные тесты round-trip.
  - Важно выбрать “источник правды” для нормализации (NFKD/whitespace rules).
  - **REVIEW** ⚠️ Нормализация и “no logging” политика должны быть частью security требований, иначе это легко нарушается на практике.
- **Как реализовать в Z00Z**:
  - В `z00z_wallets/src/recovery/` (или `z00z_wallets/src/seed/`) держать conversion:
    ```rust
    pub struct SeedWords(Vec<String>);
    
    pub fn enciphered_seed_to_mnemonic(words: &Wordlist, bytes: &[u8]) -> SeedWords {
        let _ = (words, bytes);
        SeedWords(vec![])
    }
    
    pub fn mnemonic_to_enciphered_seed(words: &Wordlist, sw: &SeedWords) -> Result<Vec<u8>, ()> {
        let _ = (words, sw);
        Err(())
    }
    
    pub struct Wordlist;
    ```
  - Инвариант: `mnemonic_to_enciphered_seed(enciphered_seed_to_mnemonic(bytes)) == bytes`.

---

## z00z_crypto/tari/common_types/src/seeds/seed_words.rs

### `SeedWords` + parsing/join

- **В чём идея**: `SeedWords` — это не просто `Vec<String>`, а *тип-граница* между “мнемоника как UX” и “seed bytes как источник истины”.
  - Дев-смысл: в коде должно быть максимально мало мест, где seed представлен в человекочитаемом виде. В идеале: мнемоника появляется только на UI-границе (показ/ввод), а внутри системы живут байты (`CipherSeed`, `SeedBytes`, `EncipheredSeedBytes`).
  - `SeedWords` помогает:
    - централизовать нормализацию (trim/whitespace),
    - проверять инварианты (кол-во слов, допустимые символы/алфавит),
    - скрывать утечки в логах/`Debug`,
    - уменьшить “случайные” преобразования (join/split в разных местах и разные правила).
  - Ключевой инвариант уровня API: “мнемоника — это лишь *кодек*”. Если кодек обратим, то:
    - `mnemonic_to_enciphered_seed(enciphered_seed_to_mnemonic(bytes)) == bytes`.
  - **REVIEW** ✅ Сильная идея: минимизировать количество мест, где seed живёт как текст.
  - **REVIEW** ⚠️ Если `SeedWords` хранит `Vec<String>`, это всё равно high-risk. Хорошо бы явно обозначить, что это должно жить только на UI boundary и как можно короче по времени.

- **Что взять из Tari и почему полезно (+ tradeoffs)**: в Tari seed-слова оформлены как отдельный тип и кодируются/декодируются через `Wordlist`.
  - Что именно взять:
    - “Слова — это секрет” → запретить случайный `Debug`/логирование.
    - “Один источник истины” → валидация/парсинг в одном месте, а не раскидана по UI/сервисам.
    - Явные ошибки парсинга (невалидное слово, неверная длина, неверная контрольная сумма/словарь).
  - Почему полезно:
    - снижает риск утечек через telemetry/логирование,
    - делает восстановление кошелька детерминированным (одни правила split/join),
    - упрощает тестирование: есть один модуль, который гарантирует round-trip.
  - Tradeoffs:
    - больше “обёрток” и типов → чуть больше кода и конверсий;
    - иногда хочется “просто строку” (например, CLI) — придётся сделать адаптер слой, который аккуратно преобразует строку → `SeedWords`.
  - **REVIEW** ✅ Ок. Главное — чтобы “просто строка” не стала внутренним стандартом.

- **Как реализовать в Z00Z**:
  - Где жить типам:
    - `z00z_crypto`: типы и кодеки, которые должны быть одинаковыми для всех клиентов (core truth).
    - `z00z_wallets` (или wallet service слой): UI/CLI адаптеры (парсинг ввода пользователя, отображение, one-shot reveal).
  - Минимальный дизайн типов (code-shape):
    ```rust
    // z00z_crypto/src/seeds/seed_words.rs
    pub struct SeedWords {
        // Можно хранить нормализованные слова без лишних пробелов.
        // Если хочется защититься от случайного копирования, держим внутри секретный контейнер.
        words: Vec<String>,
    }
    
    impl SeedWords {
        pub fn parse(input: &str) -> Result<Self, SeedWordsError> {
            // 1) normalize whitespace
            // 2) split
            // 3) validate bounds (min/max words)
            // 4) validate allowed charset (зависит от Wordlist)
            todo!()
        }
    
        pub fn join_redacted(&self) -> String {
            // Для UI можно вернуть "word1 … wordN" или маску.
            // Для логов — только длины/хэши (без слов).
            todo!()
        }
    
        pub fn as_slice(&self) -> &[String] {
            &self.words
        }
    }
    
    #[derive(Debug, thiserror::Error)]
    pub enum SeedWordsError {
        #[error("empty mnemonic")]
        Empty,
        #[error("invalid word count")]
        InvalidWordCount,
        #[error("invalid word")]
        InvalidWord,
        #[error("checksum mismatch")]
        Checksum,
    }
    ```
  - Кодек bytes ⇄ words как отдельный слой, чтобы не смешивать “парсинг строки” и “кодирование seed”:
    ```rust
    // z00z_crypto/src/seeds/codec.rs
    pub trait MnemonicCodec {
        fn bytes_to_words(&self, bytes: &[u8]) -> Result<SeedWords, SeedWordsError>;
        fn words_to_bytes(&self, words: &SeedWords) -> Result<Vec<u8>, SeedWordsError>;
    }
    ```
  - Политика безопасности (важно для Z00Z):
    - В `Debug`/логах показывать только метаданные (кол-во слов, language id, checksum ok/failed) — без самих слов.
    - На границе UI сделать `one_shot_reveal()` (возвращает `String` и сразу обнуляет буфер, если используется secret-container).
    - Везде, где возможно, хранить внутри процесса seed в виде байт (`CipherSeed`/`EncipheredSeedBytes`), а `SeedWords` использовать только для ввода/вывода.

### `get_birthday_from_unix_epoch_in_seconds`

- **В чём идея**: `birthday` — это *сжатое представление “как далеко в прошлое сканировать”*, чтобы ускорять initial sync / recovery.
  - Дев-смысл: если у кошелька есть “дата рождения” (например, время создания seed), то при восстановлении мы не сканируем всю историю сети, а стартуем с разумной нижней границы.
  - Главный смысл функции — “один канонический алгоритм”: конверсия unix-seconds → birthday должна быть одинаковой во всех местах (wallet, storage, rpc, tests). Иначе появится дрейф: один компонент считает одно, другой — другое, и появляются неуловимые баги (пропущенные UTXO/notes, лишняя нагрузка, разный UX).
  - **REVIEW** ✅ Отличное требование: единый алгоритм = меньше “призрачных” багов восстановления.

- **Что взять из Tari и почему полезно (+ tradeoffs)**: в Tari подход обычно такой: birthday вычисляется централизованно, хранится рядом с seed/identity, и используется как параметр сканирования.
  - Что взять:
    - централизованный helper, который *жёстко фиксирует* epoch/единицы измерения/округление;
    - saturating/checked арифметику и bounds (чтобы “странные” значения времени не ломали восстановление);
    - хранить и использовать birthday *в scan state*, а не вычислять “на лету” в каждом рескане.
  - Почему полезно:
    - performance: резкое снижение объёма сканирования при восстановлении;
    - correctness: единый источник истины по преобразованию времени → скан-граница;
    - observability: проще логировать *не секретные* метрики (birthday value, computed start height) без утечек.
  - Tradeoffs:
    - нужен явный выбор epoch (например, chain genesis timestamp или “wallet epoch”) и фиксированное округление;
    - если birthday слишком “молодой” (например, из-за неверных часов), можно пропустить старые средства → нужен fallback (например, allow “rescan from genesis” режим).
  - **REVIEW** ✅ Абсолютно: нужен пользовательский/админский fallback на глубокий рескан.

- **Как реализовать в Z00Z**:
  - Место в коде:
    - `z00z_crypto`: утилита конверсии, если она используется и вне кошелька.
    - или `z00z_wallets`: если birthday — сугубо wallet-скан параметр (часто логичнее так).
  - Явно зафиксировать семантику (spec-level):
    - какой epoch используется (genesis unix timestamp или “wallet epoch”);
    - что означает birthday (дни? недели? блок-эпохи?);
    - какое округление (floor vs ceil).
  - Code-shape с bounds/checked:
    ```rust
    // z00z_wallets/src/recovery/birthday.rs
    pub const WALLET_BIRTHDAY_EPOCH_UNIX_SECONDS: u64 = /* согласовать */ 0;
    pub const SECONDS_PER_DAY: u64 = 24 * 60 * 60;
    
    #[derive(Clone, Copy, Debug, PartialEq, Eq)]
    pub struct WalletBirthday(pub u16);
    
    pub fn get_birthday_from_unix_epoch_in_seconds(unix_seconds: u64) -> WalletBirthday {
        // Принцип: безопасно, детерминированно, без panics.
        let delta = unix_seconds.saturating_sub(WALLET_BIRTHDAY_EPOCH_UNIX_SECONDS);
        let days = (delta / SECONDS_PER_DAY).min(u16::MAX as u64) as u16;
        WalletBirthday(days)
    }
    ```
  - Как это ложится на текущую инфраструктуру Z00Z:
    - В `scan state` (например, `z00z_wallets/src/scan/state.rs`) хранить `WalletBirthday` как часть persisted состояния.
    - При `rescan`:
      - вычислить стартовую высоту/диапазон на основе birthday (через chain params / base-node RPC),
      - запускать recovery pipeline с нижней границей,
      - иметь user-visible переключатель “глубокий рескан” (fallback) если есть подозрение на неверный birthday.
  - Минимальные изменения по файлам (ориентир):
    - добавить `recovery/birthday.rs` (или аналог) и использовать в `wallet open/recover` пайплайне;
    - расширить persisted scan state структурой `WalletBirthday`;
    - добавить тесты: фиксированные unix timestamps → ожидаемые birthday значения (включая границы и saturating cases).

---

## z00z_crypto/tari/p2p/src/peer_seeds.rs

### `DnsSeedResolver::{connect_secure,connect,resolve}`

- **В чём идея**: DNS seeds — это “первый шаг” сети, который должен быть максимально *tolerant* к мусору и частичным сбоям.
  - Дев-смысл: bootstrap — это зона, где у тебя ещё нет доверенных peer’ов, а входные данные (DNS ответы) могут быть:
    - частично недоступны (timeouts),
    - частично неверны (плохие multiaddr, неподдерживаемые схемы),
    - частично вредоносны (переполнение списками, попытка подсунуть self/loopback).
  - `DnsSeedResolver` обычно решает две задачи:
    1) получить кандидатов (resolve),
    2) попытаться подключиться к подмножеству (connect/connect_secure), *не падая всем процессом* из-за отдельных плохих записей.
  - Важно: “успех” bootstrap — это не “все записи подключились”, а “удалось получить/подключить хотя бы N валидных peer’ов за bounded время”.
  - **REVIEW** ✅ Правильно: bootstrap должен быть resilient и bounded по времени/ресурсам.

- **Что взять из Tari и почему полезно (+ tradeoffs)**: у Tari подход прагматичный: резолвим много, валидируем/фильтруем агрессивно, подключаемся ограниченно, ошибки агрегируем, но не фейлим весь процесс.
  - Что взять:
    - строгую валидацию и нормализацию входа: multiaddr parsing, допустимые протоколы, запрет очевидно плохих адресов;
    - bounded поведение:
      - лимит на число DNS записей,
      - лимит на число одновременных попыток connect,
      - таймауты resolve/connect,
      - backoff/повтор на следующем тике, а не tight loop;
    - `connect_secure` как отдельная “политика подключения”:
      - например, требовать handshake/identity match/transport security,
      - или хотя бы проверку, что peer отвечает ожидаемым протоколом.
  - Почему полезно:
    - повышает шанс “поднять сеть” при деградациях DNS/интернета;
    - снижает поверхность DoS (DNS может вернуть тысячи записей);
    - улучшает наблюдаемость: можно метриками видеть, что именно ломается (resolve vs connect vs parse).
  - Tradeoffs:
    - больше кода и состояний (лимиты, таймауты, статистика);
    - нужно аккуратно логировать: адреса — не секрет, но могут быть PII/операционные данные → политика логирования (уровень, редактирование, sampling).
  - **REVIEW** ✅ Хорошо, что logging policy явно упомянута — это обычно всплывает уже в проде.

- **Как реализовать в Z00Z**:
  - Где жить:
    - если у Z00Z уже есть `z00z_networks/*` и/или `z00z_crypto/tari/...` как upstream integration, то:
      - “ядро резолвера” можно оставить в tari-модуле,
      - а политики/конфиги (лимиты, таймауты, allowlist протоколов) — в `z00z_networks` или `z00z_rollup_node` конфиге.
  - Какие изменения (минимально):
    - добавить `SeedConfig` в конфиг сети (`dns_seeds`, `max_records`, `connect_parallelism`, `resolve_timeout`, `connect_timeout`, `max_good_peers`).
    - добавить “pipeline валидации кандидатов” до connect:
      - parse multiaddr
      - filter unsupported protocols
      - drop local/self addresses
      - dedup
      - truncate to max_records
  - Code-shape (ориентир):
    ```rust
    pub struct DnsSeedResolver {
        config: SeedConfig,
        // зависимости: dns client + dialer + clock + rng (если нужно shuffle)
    }
    
    impl DnsSeedResolver {
        pub async fn resolve(&self) -> Vec<SeedPeer> {
            // 1) query DNS for seed domains
            // 2) parse into SeedPeer candidates
            // 3) validate/filter/dedup/truncate
            todo!()
        }
    
        pub async fn connect(&self) -> Vec<ConnectedPeer> {
            // best-effort connect with bounded parallelism
            todo!()
        }
    
        pub async fn connect_secure(&self) -> Vec<ConnectedPeer> {
            // connect + handshake/identity verification
            todo!()
        }
    }
    ```
  - Telemetry (не “nice to have”, а must для bootstrap):
    - counters: `dns_seed.resolve_ok`, `dns_seed.resolve_err`, `dns_seed.candidates_total`, `dns_seed.candidates_valid`.
    - histograms: `dns_seed.resolve_latency_ms`, `dns_seed.connect_latency_ms`.
    - structured reasons for drops: `invalid_multiaddr`, `unsupported_proto`, `self_addr`, `too_many_records`.

### `SeedPeer` (`FromStr`)

- **В чём идея**: `SeedPeer` — это минимальный self-contained формат “в одной строке”, который можно хранить в конфиге/DNS TXT/CLI и который однозначно парсится.
  - Дев-смысл: при bootstrap мы хотим:
    - *публичный ключ* (или node id), чтобы можно было проверить, что мы подключились “к тому”,
    - *адреса подключения* (multiaddr), которые могут меняться/быть несколькими.
  - Формат `pubkey_hex::multiaddr` — это компромисс:
    - легко читается,
    - легко вставляется в конфиги,
    - строго парсится.
  - **REVIEW** ✅ Хороший минимальный формат: удобно для конфигов/DNS и легко тестируется.

- **Что взять из Tari и почему полезно (+ tradeoffs)**: Tari делает `SeedPeer` строгим (FromStr), с явными ошибками и предсказуемыми правилами.
  - Что взять:
    - fixed delimiter (например, `::`), строгий split на 2 части;
    - строгий hex decode (длина, символы);
    - строгий multiaddr parse + фильтрация поддерживаемых протоколов;
    - единая нормализация: например, canonical string для multiaddr (чтобы dedup работал корректно).
  - Почему полезно:
    - меньше “магии” и меньше скрытых допущений → меньше прод-багов в bootstrap;
    - проще тестировать и поддерживать backward compatibility (версионирование формата, если понадобится);
    - можно валидировать конфиг на старте процесса и fail-fast (с хорошей ошибкой).
  - Tradeoffs:
    - формат нужно зафиксировать и поддерживать (breaking change = painful);
    - если понадобится несколько адресов на один pubkey, придётся расширять формат (например, `pubkey_hex::addr1,addr2`).
  - **REVIEW** ⚠️ Если расширение вероятно, можно заранее зарезервировать версию/префикс формата (например `v1:...`). Иначе любой future change станет болезненным breaking change.

- **Как реализовать в Z00Z**:
  - Вариант минимального формата (один адрес):
    ```rust
    pub struct SeedPeer {
        pub public_key: PublicKey,
        pub address: Multiaddr,
    }
    
    impl std::str::FromStr for SeedPeer {
        type Err = SeedPeerParseError;
    
        fn from_str(s: &str) -> Result<Self, Self::Err> {
            let (pk_hex, addr_str) = s.split_once("::").ok_or(SeedPeerParseError::Format)?;
            let pk_bytes = hex::decode(pk_hex).map_err(|_| SeedPeerParseError::PublicKeyHex)?;
            let public_key = PublicKey::from_bytes(&pk_bytes).map_err(|_| SeedPeerParseError::PublicKey)?;
            let address: Multiaddr = addr_str.parse().map_err(|_| SeedPeerParseError::Multiaddr)?;
            // optionally: validate protocols / reject local addresses
            Ok(Self { public_key, address })
        }
    }
    ```
  - Где это подключить:
    - `z00z_networks`/node config parsing: принимать `Vec<SeedPeer>` из конфигурации;
    - DNS TXT parser: превращать строки в `SeedPeer`, а ошибки учитывать как “drop bad record”, не “stop the world”.
  - Тесты (must):
    - table-driven parse tests: good/bad pk hex, missing delimiter, invalid multiaddr.
    - round-trip tests: `seed_peer.to_string().parse() == seed_peer` (если добавите `Display`).

---

## z00z_crypto/tari/comms/dht/src/network_discovery/seed_strap.rs

### `SeedStrap::next_event`

- **В чём идея**: bootstrap — это не “вызвали connect и ждём”, а маленькая *bounded state machine*, которая выдаёт события (`next_event`) и сама контролирует:
  - сколько времени мы тратим на попытки,
  - сколько кандидатов обрабатываем,
  - сколько параллельных connect допускаем,
  - когда и как мы повторяем попытки.
  - Дев-смысл `next_event`: один “тик” bootstrap’а должен быть детерминированным и наблюдаемым. Он либо:
    - выдаёт событие “попробуй подключиться к этим peer’ам”,
    - либо “подожди/перезапланируй”,
    - либо “bootstrap завершён/исчерпан”.
  - Такой дизайн даёт важное свойство: bootstrap становится тестируемым (можно подать фиктивные inputs и проверить sequence событий).
  - **REVIEW** ✅ Отличный паттерн для надёжного bootstrap: bounded + тестируемый event loop.

- **Что взять из Tari и почему полезно (+ tradeoffs)**: Tari делает bootstrap через событийный цикл с явными cap’ами и таймингами.
  - Что взять:
    - “bounded попытки”: ограничения по времени/кол-ву peer’ов/кол-ву итераций;
    - “event-driven”: вместо блокирующих операций — события, которые выполняются внешним executor’ом;
    - “метрики и причины”: каждое решение bootstrap’а (skip, retry, done) наблюдаемо.
  - Почему полезно:
    - предотвращает hangs (вечные ожидания DNS/соединений),
    - предотвращает DoS (слишком много кандидатов),
    - упрощает интеграцию: bootstrap становится модулем, который можно подключить в node runtime.
  - Tradeoffs:
    - больше состояний и переходов → нужно аккуратно документировать инварианты;
    - требуется “контекст времени” (clock/timers) и конфиг cap’ов.
  - **REVIEW** ⚠️ Для реальной детерминированности в тестах стоит инжектить clock и RNG (если есть shuffle), а не брать их глобально.

- **Как реализовать в Z00Z**:
  - Как это ложится на существующую структуру:
    - “bootstrap state machine” логично держать рядом с DHT/discovery (в `z00z_networks` или в tari-integration модуле, если он остаётся upstream).
    - фактические операции (DNS resolve, dial, handshake) лучше инжектить как зависимости/трейты (чтобы тестировать).
  - Минимальный набор состояний/событий (code-shape):
    ```rust
    pub enum SeedStrapEvent {
        ResolveSeeds,
        DialCandidates { peers: Vec<SeedPeer> },
        Wait { until_ms: u64 },
        Done { connected: usize },
    }
    
    pub struct SeedStrap {
        config: SeedStrapConfig,
        // внутренняя очередь кандидатов, статистика попыток, счетчики, таймеры
    }
    
    impl SeedStrap {
        pub fn next_event(&mut self, now_ms: u64) -> SeedStrapEvent {
            // 1) если нет кандидатов/устарели — ResolveSeeds
            // 2) если есть кандидаты и есть budget — DialCandidates (bounded)
            // 3) если budget исчерпан — Done
            // 4) если нужно backoff — Wait
            todo!()
        }
    }
    ```
  - Какие изменения где (ориентир):
    - `z00z_networks/*`: добавить конфиг `SeedStrapConfig` (caps/timeouts/backoff),
    - `z00z_rollup_node`: при старте сети запускать bootstrap loop, который вызывает `next_event` и исполняет события,
    - `z00z_telemetry`: метрики по каждому событию/переходу.

### `discover_peers_via_seeds`

- **В чём идея**: `discover_peers_via_seeds` — это “реализация” события bootstrap’а: взять источники seed’ов → получить кандидатов → провалидировать → попытаться подключиться → вернуть небольшой набор “живых” peer’ов.
  - Дев-смысл: discovery — это pipeline, а не одна функция:
    1) ingest: DNS/конфиг/seed list,
    2) parse/validate: multiaddr + pubkey,
    3) rank/dedup/truncate,
    4) dial + handshake,
    5) output: connected peers + причины ошибок (для telemetry).
  - Ограничения (must): всё должно быть bounded по времени и по объёму.
  - **REVIEW** ✅ Хорошая декомпозиция pipeline; bounded constraints — must.
  - **REVIEW** ⚠️ Этот pipeline лучше строить поверх уже описанных механизмов dedup/scoring/bounds (например `MultiaddressesWithStats`), иначе появятся два “похожих, но разных” выбора адресов.

- **Что взять из Tari и почему полезно (+ tradeoffs)**: Tari делает discovery устойчивым: timeouts, caps, фильтрация кандидатов и защита от “вечных потоков”.
  - Что взять:
    - timeout на каждый шаг (resolve/connect/handshake),
    - cap на кандидатов (max N addresses/peers),
    - cap на параллелизм dial’ов,
    - фильтрация self (не подключаться к себе) и локальных/неподдерживаемых адресов,
    - дедуп по (pubkey, multiaddr).
  - Почему полезно:
    - discovery не превращается в “вечный фон”, который жрёт ресурсы;
    - уменьшает шанс подцепиться к мусорным адресам;
    - улучшает UX: узел быстрее выходит в “готов” состояние.
  - Tradeoffs:
    - caps/timeouts требуют настройки под разные сети/окружения;
    - слишком жёсткие ограничения могут ухудшить подключаемость в плохих сетях → нужен sane defaults + возможность override.

- **Как реализовать в Z00Z**:
  - Увязка с тем, что уже есть:
    - использовать уже описанные выше `SeedPeer` и `DnsSeedResolver` как источники кандидатов;
    - переиспользовать `MultiaddressesWithStats` (если он уже есть в проекте) для ранжирования/сортировки кандидатов;
    - использовать “dialer”/transport из `z00z_networks` или tari comms.
  - Code-shape (ориентир):
    ```rust
    pub async fn discover_peers_via_seeds(
        resolver: &DnsSeedResolver,
        dialer: &impl Dialer,
        cfg: &SeedDiscoveryConfig,
        self_pk: &PublicKey,
    ) -> DiscoveryResult {
        // 1) candidates = resolver.resolve().await
        // 2) filter: not self, supported protos
        // 3) dedup + truncate
        // 4) dial in parallel (bounded)
        // 5) return connected peers + stats
        todo!()
    }
    ```
  - Конкретные изменения:
    - `z00z_networks`: определить `SeedDiscoveryConfig { max_candidates, max_parallel_dials, resolve_timeout, connect_timeout }`.
    - `z00z_rollup_node`/node runtime: запускать discovery на старте и потом периодически (если сеть пустая).
    - `z00z_telemetry`: отчёт по причинам drop/fail, чтобы можно было дебажить bootstrap в проде.

---

## z00z_crypto/tari/comms/dht/examples/memorynet_graph_network_join_multiple_seeds.rs

### `main`

- **В чём идея**: пример/сценарий `memorynet_graph_*` — это “инструментальная проверка” bootstrap’а и discovery.
  - Дев-смысл: такие примеры нужны не как документация, а как *регрессионный симулятор*:
    - поднять несколько узлов,
    - дать им разные seed источники,
    - проверить, что в итоге граф соединений “сшивается” и сеть становится связной.
  - Это особенно ценно для систем, где bootstrap/discovery сильно зависят от таймингов и сетевых условий.
  - **REVIEW** ✅ Это очень практичный, “анти-регресс” кусок: для P2P он обычно даёт больше пользы, чем ещё один слой абстракций в прод-коде.

- **Что взять из Tari и почему полезно (+ tradeoffs)**: Tari держит такие сценарии, потому что discovery — одна из самых “ломких” частей P2P: любой мелкий рефактор может деградировать подключаемость.
  - Что взять:
    - сценарии, которые легко запускать локально/в CI (memory transports, deterministic seeds),
    - фиксированные ожидания (например, “через T секунд сеть связна” или “каждый узел видит >=K peers”),
    - артефакты outputs (лог/снимок графа), чтобы проще расследовать регрессии.
  - Tradeoffs:
    - сценарии требуют поддержки (иногда flaky из-за таймингов) → нужно детерминизировать (seed RNG, фиктивные таймеры).
  - **REVIEW** ⚠️ Важно реально детерминизировать время/рандом (вплоть до “виртуальных часов”), иначе такие тесты быстро становятся flaky и перестают запускаться в CI.

- **Как реализовать в Z00Z**:
  - Куда положить:
    - перенести идею в `z00z_simulator` как scenario (а не как “пример, который никто не запускает”).
  - Что проверять (MVP):
    - сеть из N узлов, которые стартуют с разными seed наборами;
    - через bounded время каждый узел имеет хотя бы 1–2 соединения;
    - нет бесконечных retry loops (лимиты/таймауты соблюдаются).
  - Code-shape сценария:
    ```rust
    // z00z_simulator/scenarios/bootstrap_connectivity.rs
    pub async fn run_bootstrap_connectivity_scenario(cfg: ScenarioConfig) -> ScenarioReport {
        // 1) spawn N nodes (in-memory transport)
        // 2) configure seed lists
        // 3) run for T
        // 4) collect graph metrics + logs snapshot
        todo!()
    }
    ```
  - Outputs snapshots:
    - сохранять “граф” (edge list) и краткую статистику (degree distribution) в `z00z_simulator/outputs/...` для диффа между запусками.
  - **REVIEW** ✅ Хорошая привязка к `z00z_simulator`: это снижает риск “примеров, которые не компилируются”. Минимально достаточно метрик связности/степени, не нужно усложнять до полной визуализации.

---

## z00z_crypto/tari/wallet/src/wallet.rs

### `Wallet::start`

- **В чём идея**: `Wallet::start` — это *composition root* (точка сборки) всех подсистем кошелька и их жизненного цикла.
  - Дев-смысл: кошелёк почти всегда состоит из 5–10 “сервисов” (storage, key manager, scan/sync, tx service, output manager, contacts, p2p/rpc clients, notifier/telemetry). Если их запускать “где-то по месту”, появляется:
    - дрейф зависимостей (один сервис создал клиент с одними таймаутами, другой — с другими),
    - гонки старта/остановки,
    - сложности с тестированием и graceful shutdown.
  - `Wallet::start` решает это так: *создать зависимости один раз, провалидировать конфиг, поднять фоновые задачи, вернуть handle*. Это делает жизненный цикл управляемым.
  - **REVIEW** ✅ Как паттерн — корректно и полезно (composition root + fail-fast). Это хорошо бьёт по классу “таймауты/клиенты разъехались”.
  - **REVIEW** ⚠️ В текущем `z00z_wallets` (судя по структуре) уже есть сервисно-сессионная архитектура (`WalletService`, `WalletSessionManager` и т.п.). Важно не вводить параллельный “второй” `Wallet` API, а описать это как узкую композицию вокруг существующих сервисов.

- **Что взять из Tari и почему полезно (+ tradeoffs)**: в Tari `Wallet::start` — это паттерн “оркестратор + сервисы”, где:
  - каждый сервис имеет чёткие входы (DB handle, identity, network client) и выходы (events/handles);
  - фоновые задачи запускаются централизованно, с общей стратегией shutdown;
  - ошибки старта выявляются рано (fail-fast), а не “через 5 минут в фоне”.
  - Почему полезно:
    - стабильнее поведение (единые таймауты/лимиты),
    - проще трассировать (одна точка, где включается telemetry и задаются теги),
    - проще тесты (можно собрать wallet с фейковыми зависимостями).
  - Tradeoffs:
    - больше wiring-кода и структур конфигурации;
    - если слишком много логики поместить в `start`, он станет “god function” → нужно разделять “build” и “run”.
  - **REVIEW** ✅ Замечание про “build vs run” ключевое: это прямой предохранитель от разрастания `start` в непокрываемую тестами мегу.

- **Как реализовать в Z00Z**:
  - Как это ложится на текущие crates:
    - `z00z_wallets`: публичный API кошелька (start/open/recover), composition root.
    - `z00z_storage`: storage/session (редб/sqlite) + миграции.
    - `z00z_crypto`: ключи, seed, подписания.
    - `z00z_networks`: rpc/p2p клиенты.
    - `z00z_telemetry`: единая инициализация трассировки/метрик.
  - Предложение по форме API (code-shape):
    ```rust
    pub struct Wallet {
        handles: WalletHandles,
        shutdown: ShutdownHandle,
    }
    
    pub struct WalletConfig {
        pub storage: StorageConfig,
        pub network: NetworkConfig,
        pub scanning: ScanConfig,
    }
    
    impl Wallet {
        pub async fn start(cfg: WalletConfig) -> Result<Self, WalletStartError> {
            // 1) open storage + run migrations
            // 2) load identity (or create)
            // 3) init key manager (locked/unlocked)
            // 4) build services
            // 5) spawn background loops (scan/broadcast/etc)
            // 6) return handles
            todo!()
        }
    }
    ```
  - Concrete changes:
    - в `z00z_wallets/src/wallet.rs`: собрать сервисы и явно описать порядок старта;
    - выделить `WalletHandles` (только то, что нужно внешнему миру) и `ShutdownHandle`;
    - “emit after commit”: события (например, `WalletEvent`) должны выпускаться после успешных транзакций в storage.
  - **REVIEW** ⚠️ Перед тем как фиксировать публичный `Wallet::start`, стоит привязать этот “composition root” к уже существующим точкам входа (например, сессии/сервисы) и не обещать конкретные имена файлов/типов (`z00z_wallets/src/wallet.rs`, `WalletHandles`), если их ещё нет.
  - **REVIEW** ✅ “emit after commit” — критично для корректности. В этом разделе полезно также явно указать: события должны быть идемпотентны и восстановимы из storage (чтобы не зависеть от “потерянных” in-memory каналов).

### `read_or_create_master_seed`

- **В чём идея**: master seed — это “корень” всех ключей. Его нельзя *случайно* перезаписать.
  - Дев-смысл: `read_or_create_master_seed` делает два режима явными:
    1) “открыть существующий кошелёк” → seed должен существовать и быть согласованным с метаданными,
    2) “создать новый кошелёк” → seed генерируется и сохраняется ровно один раз.
  - Самая опасная ошибка UX/кодинга: пользователь думает, что “импортирует seed”, а код в фоне создал новый и затёр старый — это необратимая потеря средств.
  - **REVIEW** ✅ Это корректно и по сути must-have invariant для кошелька: никаких implicit overwrite.

- **Что взять из Tari и почему полезно (+ tradeoffs)**: Tari обычно разделяет “open existing” и “create new” и использует инвариант “seed immutable unless explicit migrate”.
  - Что взять:
    - явный флаг/enum режима (`CreateNew | OpenExisting | RecoverFromSeed`),
    - строгую проверку “seed already exists” → error,
    - отказ от implicit overwrite,
    - атомарную запись seed + метаданных (version, birthday, kdf params) в одном commit.
  - Почему полезно:
    - recovery-safety: предотвращает silent data loss,
    - проще расследовать: ошибки становятся явными и типизированными,
    - лучше миграции: можно отдельно сделать “migrate wallet to new seed” как сознательное действие.
  - Tradeoffs:
    - нужно проектировать явный migration flow (иначе пользователи будут упираться в “нельзя перезаписать”);
    - может понадобиться “reset wallet” режим для dev/test.
  - **REVIEW** ⚠️ Для “reset wallet” важно не смешивать dev/test и prod: в проде это должно быть отдельное явное действие с барьерами (иначе снова риск silent data loss).

- **Как реализовать в Z00Z**:
  - Увязка с уже обсуждёнными `CipherSeed`/`SeedWords`:
    - seed должен храниться как versioned encrypted container (`CipherSeed`/`MasterKeyRecord`-подобная структура),
    - мнемоника (`SeedWords`) — только для UI импорта/экспорта.
  - Предложение по API (code-shape):
    ```rust
    pub enum SeedInitMode {
        OpenExisting,
        CreateNew { birthday: WalletBirthday },
        RecoverFromMnemonic { words: SeedWords, birthday: WalletBirthday },
    }
    
    pub async fn read_or_create_master_seed(
        store: &WalletStore,
        mode: SeedInitMode,
    ) -> Result<MasterSeedHandle, WalletSeedError> {
        // OpenExisting: require present
        // CreateNew/Recover: require absent (or require explicit Migrate)
        todo!()
    }
    ```
  - Где менять:
    - `z00z_wallets`: добавить `SeedInitMode` и разделить paths open/create/recover;
    - `z00z_storage`: обеспечить транзакционную запись seed+meta (“all-or-nothing”);
    - `z00z_crypto`: генерация/импорт seed и zeroization секретов.
  - Поведение при конфликте:
    - если seed уже есть и пришёл `RecoverFromMnemonic`: вернуть явную ошибку “SeedAlreadyExists” и требовать отдельной команды/флага migrate.
  - **REVIEW** ✅ Разделение режимов через enum — хороший guardrail против “случайно создали новый кошелёк”.
  - **REVIEW** ⚠️ Важно согласовать этот API с текущей реальностью `z00z_wallets`: сейчас (по структуре) seed/пароль/сессии заведены через сервисы/хранилище, а не через единый `WalletStore` в этом виде. Спека должна ссылаться на реальные слои (`redb_wallet_store`, key manager) чтобы не получился “параллельный дизайн”.
  - **REVIEW** ✅ Seed+meta в одном commit — правильно; дополнительно стоит зафиксировать “wallet birthday”/chain params как часть meta (иначе сканер может начать с неверной высоты).

### `read_or_create_wallet_type` + gating

- **В чём идея**: `WalletType` — это “режим кошелька”, который влияет на доступные фичи и инварианты, и поэтому должен быть *persisted*.
  - Дев-смысл: тип кошелька нельзя определять “по текущим флагам в конфиге”, иначе после обновления приложения или миграции БД кошелёк может внезапно сменить поведение.
  - Примеры, что может зависеть от типа:
    - какие протоколы/транзакции поддерживаются,
    - какие сервисы запускаются,
    - какие поля обязаны существовать в storage,
    - какие политики приватности/telemetry включены.
  - **REVIEW** ✅ Смысл корректный: тип/режим должен быть частью persisted state, а не “плавающим конфигом”.
  - **REVIEW** ⚠️ В `z00z_wallets` уже есть `WalletIdentity` с `network/chain`, которая валидируется на `open`. Если добавлять `wallet_type`, лучше явно решить: это расширение `WalletIdentity` (с миграцией формата) или отдельная persisted структура (например, в root/meta), чтобы не смешать “идентичность сети/цепи” с “режимом/возможностями”.

- **Что взять из Tari и почему полезно (+ tradeoffs)**: Tari хранит wallet type и делает gating на уровне сервисов.
  - Что взять:
    - тип сохраняется при создании и проверяется при открытии,
    - конфигурация не может “молча” изменить тип — только явная миграция,
    - gating делать ближе к границе API (чтобы нельзя было вызвать запрещённую операцию глубоко внутри).
  - Почему полезно:
    - предсказуемый UX: кошелёк “всегда один и тот же тип”,
    - меньше security/logic багов: нельзя случайно включить неподдерживаемую фичу,
    - проще миграции и совместимость.
  - Tradeoffs:
    - больше ветвлений в коде и тестах,
    - нужно управлять версионированием типов/возможностей.
  - **REVIEW** ✅ Правильный акцент: gating должен быть ближе к API. Это снижает риск “запрещённую операцию всё равно можно вызвать внутренним путём”.

- **Как реализовать в Z00Z**:
  - Где хранить:
    - логично держать `WalletType` в `WalletIdentity` (persisted) и прокидывать в каждый сервис при старте.
  - Code-shape (ориентир):
    ```rust
    #[derive(Clone, Copy, Debug, PartialEq, Eq)]
    pub enum WalletType {
        Standard,
        // например: WatchOnly, Validator, Custodial, etc.
    }
    
    pub struct WalletIdentity {
        pub wallet_type: WalletType,
        pub node_public_key: PublicKey,
        // ...
    }
    
    pub fn ensure_wallet_type_allowed(
        wallet_type: WalletType,
        requested: WalletCapability,
    ) -> Result<(), WalletTypeError> {
        todo!()
    }
    ```
  - Конкретные изменения:
    - `z00z_wallets`: на `open` читать `WalletIdentity`, проверять совместимость с текущими фичами/конфигом;
    - в публичных API методах делать gating (например, `send_tx`, `import_outputs`, `rescan_wallet`, …) по `WalletCapability`.
  - **REVIEW** ❌ В Z00Z нет майнинга; пример `start_mining` здесь вводит в заблуждение и должен быть убран/заменён на реальную для кошелька операцию.
  - **REVIEW** ⚠️ Формулировка “держать в `WalletIdentity`” сейчас выглядит чуть преждевременно: в коде `WalletIdentity` пока про `network/chain`. Added value будет выше, если сначала зафиксировать, что именно является “type” vs “capabilities” (часто лучше хранить именно “type”, а матрицу capability выводить из него по версии приложения).

### `persist_one_sided_payment_script_for_node_identity`

- **В чём идея**: one-sided payment script (или любой “скан-скрипт/скан-ключ”) — это часть *истории обнаружения средств*, и поэтому его нельзя рассматривать как “текущую настройку”, которую можно просто заменить.
  - Дев-смысл: если node identity/ключи/скрипты ротируются, старые UTXO/выходы могли быть созданы под старые скрипты. Чтобы кошелёк продолжал находить и распознавать такие средства при сканировании цепочки, он должен хранить “набор известных скриптов” (или производных ключей) как историческое состояние.
  - `persist_one_sided_payment_script_for_node_identity` по сути означает: при изменении identity/ключевого материала, мы *добавляем* новый скрипт в “известные”, а не перезаписываем один-единственный слот.
  - **REVIEW** ✅ Корректный correctness-аргумент: без history скриптов легко “потерять видимость” старых средств после ротаций.
  - **REVIEW** ⚠️ Added value зависит от продукта: если identity/скрипты детерминированы из seed и ротации редки, часть history можно воспроизводить, но импортированные/внешние артефакты всё равно требуют persistence.

- **Что взять из Tari и почему полезно (+ tradeoffs)**: в Tari подход примерно такой: поддерживать history/набор известных payment scripts, чтобы scanning оставался корректным при ротациях.
  - Что взять:
    - persistence как часть wallet state (не в памяти),
    - дедупликация (один и тот же скрипт/ключ не добавляется бесконечно),
    - bounds и политика pruning (иначе state будет расти вечно),
    - порядок/метаданные (когда добавлен, какой identity породил) для отладки.
  - Почему полезно:
    - correctness: не потеряете видимость “старых” средств после ротации;
    - recovery: после восстановления из seed можно заново воспроизвести нужные скрипты/ключи и/или подтянуть сохранённые метаданные;
    - debugging: можно понять, почему тот или иной output был распознан.
  - Tradeoffs:
    - state растёт → обязательно вводить ограничения и стратегию очистки;
    - усложняется модель сканирования (сканируем по множеству скриптов/ключей, а не по одному).
  - **REVIEW** ✅ Bounds/pruning — не “опционально”, это обязательная часть дизайна, иначе получите DoS по storage и времени скана.

- **Как реализовать в Z00Z**:
  - Где хранить:
    - в wallet storage (`z00z_storage` / wallet DB) как таблицу/коллекцию `KnownOneSidedScripts` или более общее `KnownScanArtifacts`.
  - Как связать с текущей инфраструктурой:
    - `z00z_wallets`/scan service должен получать список известных скриптов при старте и использовать их при matching.
    - `z00z_crypto` должен уметь воспроизвести/валидировать скрипт и связать его с derivation path (если применимо).
  - Code-shape (ориентир):
    ```rust
    pub struct KnownOneSidedScript {
        pub script: Vec<u8>,
        pub added_at_ms: u64,
        pub source_identity_fingerprint: [u8; 32],
    }
    
    pub trait WalletStore {
        fn add_known_one_sided_script(&self, s: KnownOneSidedScript) -> Result<(), StoreError>;
        fn list_known_one_sided_scripts(&self, limit: usize) -> Result<Vec<KnownOneSidedScript>, StoreError>;
    }
    ```
  - Bounds политика (минимально):
    - лимит, например `max_known_scripts` (конфигurable);
    - при превышении: удалять самые старые *или* те, которые давно не “попадались” при сканировании (если ведёте usage stats).
  - Важный инвариант: любые изменения списка “known scripts” должны делаться транзакционно и события/нотификации выпускать после commit.
  - **REVIEW** ✅ “after commit” здесь особенно важно: иначе UI/сервисы могут начать сканировать с артефактами, которых фактически нет в storage.

### `sign_message` / `verify_message_signature`

- **В чём идея**: подпись кошельком должна быть *domain-separated*, чтобы одну и ту же подпись нельзя было переиспользовать в другом протоколе/контексте.
  - Дев-смысл: если вы подписываете “человеческое сообщение” тем же ключом/тем же форматом, что и “авторизацию RPC” или “часть транзакции”, то появляется риск cross-protocol атаки: атакующий может подсунуть сообщение, подпись которого затем интерпретируется как подпись другого типа.
  - Поэтому `sign_message`/`verify_message_signature` должны:
    - чётко фиксировать домен (DST/tag),
    - нормализовать сообщение (bytes как источник истины),
    - возвращать/принимать формат подписи, который невозможно перепутать.
  - **REVIEW** ✅ Domain separation — обязательная мера. Этот раздел “про безопасность”, а не про удобство.
  - **REVIEW** ⚠️ Уточните, что именно является “нормализацией”: лучше прямо сказать “подписываем bytes”, а для строковых сообщений UI должен явно задавать кодировку/нормализацию (например, UTF-8 bytes без скрытых преобразований), иначе получите “подписал одно — увидел другое”.

- **Что взять из Tari и почему полезно (+ tradeoffs)**: Tari систематически использует домены/теги в хешировании и подписи.
  - Что взять:
    - набор доменов для разных задач: `wallet_message`, `wallet_auth`, `tx_kernel`, `contacts`, и т.д.;
    - сигнатура как `sign(domain, message_bytes)` (а не “просто sign(message)”).
    - строгая верификация: verify всегда требует домен.
  - Почему полезно:
    - security: уменьшает риск повторного использования подписи между протоколами;
    - compatibility: формат подписи и домены можно версионировать.
  - Tradeoffs:
    - нужно вести реестр доменов и не менять их “тихо” (иначе сломаете верификацию);
    - больше кода и более строгие API.
  - **REVIEW** ✅ Да: домены — это часть протокола. Любое изменение должно быть версионировано (v1/v2), иначе вы ломаете backward verification.

- **Как реализовать в Z00Z**:
  - Где “источник доменов”:
    - `z00z_crypto` уже имеет `hash_domains` (по структуре репозитория) — именно там и держать DST константы.
  - Code-shape:
    ```rust
    // z00z_crypto/src/hash_domains.rs
    pub const DST_WALLET_MESSAGE: &[u8] = b"z00z.wallet.message.v1";
    
    // z00z_wallets/src/crypto/signing.rs
    pub fn sign_message(sk: &SecretKey, msg: &[u8]) -> Signature {
        // signature over H(DST || msg)
        todo!()
    }
    
    pub fn verify_message_signature(pk: &PublicKey, msg: &[u8], sig: &Signature) -> bool {
        todo!()
    }
    ```
  - Интеграция:
    - RPC/auth: отдельный домен `DST_WALLET_AUTH` (не смешивать с “human message”).
    - UI: подписываем bytes, а отображаем “каноническую строку” пользователю отдельно (чтобы избежать различий нормализации строк).
  - Тесты (обязательные):
    - подпись в одном домене не должна верифицироваться в другом домене;
    - deterministic fixtures: одинаковые входы → одинаковая подпись (если схема детерминированная) или хотя бы verify passes.
  - **REVIEW** ⚠️ Не требуйте “одинаковые входы → одинаковая подпись” как инвариант, если используете схему с рандомизированным nonce (часто так и есть). Для тестов достаточно фиксировать seed RNG/nonce или проверять только `verify` + кросс-доменный fail.

### `import_unblinded_output_as_non_rewindable`

- **В чём идея**: “import unblinded output” — это ситуация, когда пользователь/система добавляет в кошелёк выход (UTXO/asset note) *не через обычный receive протокол*, а из внешнего источника (backup, экспорт, миграция, airdrop, watch-only импорт).
  - Дев-смысл: такие средства отличаются от обычных:
    - они могут быть “не rewindable” (кошелёк не сможет восстановить детали из chain rewind механизма/сканирования, если потеряет локальные метаданные),
    - они требуют явного audit trail (откуда взялись),
    - их lifecycle (spend/mark spent) может отличаться.
  - Поэтому Tari выделяет отдельный путь `import_unblinded_output_as_non_rewindable`: это сигнал в модели данных “это импорт, и он не восстанавливается как обычный”.
  - **REVIEW** ✅ Полезная категоризация: вы заранее не обещаете пользователю “рескан всё восстановит”, если это не так.

- **Что взять из Tari и почему полезно (+ tradeoffs)**:
  - Что взять:
    - явную маркировку output’а как imported/non-rewindable,
    - отдельные причины/источник импорта (метаданные),
    - отдельный “контейнер транзакции” (faux tx/placeholder), чтобы история кошелька оставалась последовательной.
  - Почему полезно:
    - correctness: не обещаем пользователю “восстановится само при скане”, если это не так;
    - UX: в UI можно показать “Imported funds” с объяснением;
    - безопасность: легче контролировать доступ/разрешения на импорт.
  - Tradeoffs:
    - больше типов и переходов состояний (обычные vs импортированные);
    - нужно внимательно определить, как такие outputs участвуют в балансах и в рескане.
  - **REVIEW** ⚠️ Самое опасное место здесь — баланс/рескан семантика. Нужно явно определить: импортированные выходы участвуют в “available” сразу или требуют подтверждения/проверки, и что именно происходит при рескане (пересоздаём запись? сверяем? не трогаем?).

- **Как реализовать в Z00Z**:
  - В модель данных:
    - добавить в output record поля:
      - `source: OutputSource` (NormalReceived | Imported),
      - `rewindable: bool` (или более явный enum),
      - `import_metadata` (опционально: кто/когда/откуда).
  - В историю транзакций:
    - создать “faux transaction” (локальная запись), чтобы:
      - output отображался в истории,
      - состояние “spent/unspent” было связано с объектом tx/operation.
  - Code-shape (ориентир):
    ```rust
    pub enum OutputSource {
        Normal,
        Imported { note: Option<String> },
    }
    
    pub struct WalletOutputRecord {
        pub commitment: [u8; 32],
        pub value: u64,
        pub source: OutputSource,
        pub rewindable: bool,
    }
    
    pub async fn import_unblinded_output_as_non_rewindable(
        store: &WalletStore,
        output: WalletOutputRecord,
    ) -> Result<(), WalletError> {
        // 1) validate invariants (no duplicates, sane value)
        // 2) insert output + create placeholder tx record atomically
        todo!()
    }
    ```
  - Где менять:
    - `z00z_wallets`: добавить публичную операцию import (доступную только в нужных `WalletType`/capabilities),
    - `z00z_storage`: транзакционная запись output + faux tx + индексы,
    - `z00z_core`/validation (если нужно): правила, как такие outputs учитываются при балансе.

---

## z00z_crypto/tari/wallet/src/storage/sqlite_db/wallet.rs

### `get_db_cipher` (KEK protects DEK)

- **В чём идея**: не шифровать “всю БД” напрямую паролем пользователя. Вместо этого:
  - из пароля выводим KEK (Key Encryption Key) через KDF (например, Argon2),
  - генерируем случайный DEK (Data Encryption Key),
  - KEK шифрует/оборачивает DEK (wrap/unwrap),
  - а уже DEK используется для шифрования данных/полей в БД.
  - Дев-смысл: пароль — это нестабильный/медленный источник ключа (KDF дорогой), а DEK — стабильный быстрый ключ для реального шифрования полей.
  - Плюс: смена пароля = “перешифровать только DEK”, а не всю БД.
  - **REVIEW** ✅ Схема KEK→DEK — это стандартная, практичная крипто-архитектура для кошельков; аргументы про KDF-cost и смену пароля корректны.
  - **REVIEW** ⚠️ Раздел ссылается на `sqlite_db/wallet.rs`, но у Z00Z сейчас `.wlt`/RedB-стек. Лучше описывать это как концепт, привязанный к вашим реальным мета-ключам/контейнерам, иначе читатель будет ожидать SQLite-подсистему.

- **Что взять из Tari и почему полезно (+ tradeoffs)**:
  - Что взять:
    - схему KEK→DEK (“master key record”):
      - хранить *только* зашифрованный DEK и метаданные KDF,
      - никогда не хранить пароль/KEK;
    - явное разделение ответственности:
      - KDF параметры/версия в метаданных,
      - AEAD wrap для DEK,
      - отдельный “db cipher” объект, который создаётся только после успешного unlock;
    - жёсткие инварианты чтения мета-полей (если не хватает данных → ошибка, а не “best effort”).
  - Почему полезно:
    - performance: KDF вызывается редко (unlock), а не при каждом чтении поля;
    - UX: change password быстрый;
    - security: проще правильно строить AAD и версионировать формат.
  - Tradeoffs:
    - нужно очень аккуратно проектировать метаданные (версии, AAD, схема миграций);
    - потребуется единая стратегия ошибок (не превращать unlock в oracle по типам ошибок).
  - **REVIEW** ✅ Про “oracle” замечание важное: в RPC/UI лучше различать ошибки аккуратно (подробнее — в логах/телеметрии, но не в ответах злоумышленнику).

- **Как реализовать в Z00Z**:
  - Как это ложится на текущую архитектуру:
    - `z00z_storage` должен уметь хранить “master key record” (зашифрованный DEK + kdf meta + version),
    - `z00z_crypto` должен давать AEAD wrap/unwrap и KDF,
    - `z00z_wallets` управляет unlock flow (получить пароль → derive KEK → unwrap DEK → создать `DbCipher`).
  - Code-shape (ориентир):
    ```rust
    pub struct MasterKeyRecord {
        pub kdf: KdfParamsRecord,
        pub wrapped_dek: Vec<u8>,
        pub schema_version: u32,
    }
    
    pub struct DbCipher {
        dek: [u8; 32],
    }
    
    impl DbCipher {
        pub fn new_from_password(password: &SafePassword, mkr: &MasterKeyRecord) -> Result<Self, UnlockError> {
            // 1) derive KEK via Argon2 (using mkr.kdf)
            // 2) unwrap DEK via AEAD (AAD binds schema_version/wallet_id)
            todo!()
        }
    }
    ```
  - Где менять (ориентир):
    - `z00z_storage`: структура `MasterKeyRecord` + read/write + транзакционность обновления;
    - `z00z_wallets`: unlock path создаёт `DbCipher` и кладёт в `WltSession`/store wrapper;
    - `z00z_crypto`: AEAD envelope + KDF и домены/AAD builder.
  - **REVIEW** ⚠️ AAD binding — ключевой момент: привязка к `wallet_id`/версии/chain params должна быть зафиксирована в одном месте (builder), чтобы разные слои не “собрали AAD по-разному”.

### `Argon2Parameters::from_version`

- **В чём идея**: KDF параметры не вечны. То, что “достаточно” сегодня, может стать слабым завтра. Поэтому параметры (и их версия) должны быть:
  - сохранены вместе с кошельком,
  - однозначно восстанавливаемы,
  - обновляемы по политике (upgrade path).
  - Дев-смысл `from_version`: по “версии политики” можно получить параметры (m_cost, t_cost, p_cost, output_len, salt_len и т.п.) и обеспечить совместимость.
  - **REVIEW** ✅ Подход “policy version → параметры” корректен, если версия действительно полностью определяет политику (иначе храните и версию, и параметры, как вы и пишете ниже).

- **Что взять из Tari и почему полезно (+ tradeoffs)**:
  - Что взять:
    - хранить `kdf_version` + конкретные параметры;
    - возможность “мягкого апгрейда”:
      - при успешном unlock старым KDF можно перегенерировать wrap DEK с новыми параметрами,
      - но делать это атомарно и безопасно;
    - bounds/guardrails: не принимать параметры из хранилища без sanity checks (защита от corrupted/hostile DB).
  - Почему полезно:
    - постепенное усиление безопасности без breaking recovery;
    - проще поддерживать несколько поколений кошельков;
    - возможность tune под разные платформы.
  - Tradeoffs:
    - больше метаданных и логики миграции;
    - upgrade KDF может быть дорогим → нужно делать его редко/по флагу.
  - **REVIEW** ⚠️ Числа в примере (64–128 MiB) стоит явно пометить как ориентир: для мобилок/low-mem окружений это может быть слишком тяжело, а для десктопа — слишком мягко. Лучше зафиксировать диапазоны и sanity checks.

- **Как реализовать в Z00Z**:
  - Хранение:
    - в wallet meta (`META_WALLET_KDF`) хранить `kdf_version` + параметры (или параметры выводить по версии, но тогда версия должна быть достаточной).
  - Code-shape:
    ```rust
    #[derive(Clone, Copy, Debug)]
    pub enum KdfVersion { V1, V2 }
    
    pub struct Argon2Parameters {
        pub memory_kib: u32,
        pub iterations: u32,
        pub parallelism: u32,
    }
    
    impl Argon2Parameters {
        pub fn from_version(v: KdfVersion) -> Self {
            match v {
                KdfVersion::V1 => Self { memory_kib: 64 * 1024, iterations: 3, parallelism: 1 },
                KdfVersion::V2 => Self { memory_kib: 128 * 1024, iterations: 3, parallelism: 1 },
            }
        }
    }
    ```
  - Upgrade policy:
    - при `unlock`:
      - если `stored_version < current_version` и пароль верный → пересоздать wrap DEK новым KDF и записать atomically.
    - ошибки unlock нормализовать (не раскрывать “версия не поддерживается” vs “пароль неверный” в продовом UX, если это oracle-risk).
  - **REVIEW** ✅ Согласуется с предыдущими разделами: хранить подробности для диагностики можно, но наружу выдавать аккуратно.

### `DatabaseEncryptionFields::read/write`

- **В чём идея**: если кошелёк/БД помечены как “зашифрованы”, то набор мета-полей для расшифровки должен быть *полным*.
  - Дев-смысл: частично заполненные поля (есть salt, но нет wrapped_dek; есть version, но нет AAD meta) — это почти всегда:
    - corruption,
    - незавершённая миграция,
    - баг записи,
    - или попытка атакующего создать неоднозначный state.
  - Поэтому `DatabaseEncryptionFields::read/write` должны поддерживать инвариант “all-or-nothing”: либо всё присутствует и валидно, либо это ошибка.
  - **REVIEW** ✅ Это правильный invariant. “Частично заполненная крипто-мета” почти всегда означает потерю корректности/безопасности.

- **Что взять из Tari и почему полезно (+ tradeoffs)**:
  - Что взять:
    - строгий read: проверять наличие всех ключей, version compatibility и bounds;
    - строгий write: записывать мета-поля атомарно в одной транзакции (или с commit-marker);
    - явные типы ошибок для диагностики, но нормализуемые для внешнего UX.
  - Почему полезно:
    - раннее обнаружение проблем (лучше упасть на open, чем “тихо” читать мусор);
    - проще миграции (можно проверять инвариант после апгрейда);
    - меньше багов класса “вроде unlocked, но некоторые таблицы не читаются”.
  - Tradeoffs:
    - более строгие ошибки могут ломать очень старые/поломанные данные → нужен чёткий recovery story (backup/repair/export).
  - **REVIEW** ⚠️ Recovery story здесь реально нужен в тексте: что именно пользователь делает при повреждении meta (экспорт seed? создание нового `.wlt`? repair tool?). Иначе строгий invariant превратится в “кошелёк не открывается, и непонятно что делать”.

- **Как реализовать в Z00Z**:
  - В `z00z_storage`:
    - определить структуру `DatabaseEncryptionFields`, которая включает все обязательные куски: `schema_version`, `kdf`, `wrapped_dek`, `aad_policy`/`wallet_id`.
    - при `open`:
      - если `encrypted=true` → требовать полный набор;
      - если `encrypted=false` → требовать отсутствие encryption fields (или игнорировать, но лучше тоже строго).
  - Code-shape:
    ```rust
    pub struct DatabaseEncryptionFields {
        pub schema_version: u32,
        pub master_key_record: MasterKeyRecord,
        pub wallet_id: [u8; 16],
    }
    
    impl DatabaseEncryptionFields {
        pub fn read(meta: &MetaStore) -> Result<Option<Self>, EncryptionMetaError> {
            // return None if encryption not enabled
            // else require all fields
            todo!()
        }
    
        pub fn write(&self, meta: &mut MetaStoreTx) -> Result<(), EncryptionMetaError> {
            // atomic write of all fields
            todo!()
        }
    }
    ```
  - Практический совет для Z00Z: сделать “commit marker” (например, `META_ENCRYPTION_READY=true`) который ставится последним, чтобы crash посередине не оставлял двусмысленное состояние.
  - **REVIEW** ✅ Commit marker — хороший трюк для crash-consistency, особенно если запись meta делается несколькими ключами.

### `change_passphrase`

- **В чём идея**: смена пароля должна быть “дешёвой” операцией: мы меняем только KEK-обёртку вокруг DEK, не трогая шифртексты данных.
  - Дев-смысл: если хранить DEK (data key) отдельно и оборачивать его KEK’ом (derived from password), то смена пароля =
    1) derive old KEK → unwrap DEK,
    2) derive new KEK → wrap тот же DEK,
    3) атомарно заменить `MasterKeyRecord`.
  - Это намного быстрее и безопаснее, чем “перешифровать всю БД”, и снижает вероятность частичных ошибок.
  - **REVIEW** ✅ Корректно и практично: смена пароля должна менять только wrap DEK, иначе операция становится рискованной и долгой.

- **Что взять из Tari и почему полезно (+ tradeoffs)**:
  - Что взять:
    - протокол “unwrap старым → wrap новым” как единственный путь;
    - атомарность: запись нового `MasterKeyRecord` должна быть единым транзакционным событием;
    - нормализация ошибок: нельзя выдавать наружу различимые ответы “старый пароль неверный” vs “БД повреждена” в местах, где это может стать oracle (зависит от threat model, но Tari обычно осторожен).
  - Почему полезно:
    - UX: change password быстрый (KDF+wrap),
    - reliability: меньше шансов “сломать” кошелёк посередине долгой перешифровки,
    - security: DEK не меняется → не нужно мигрировать все зашифрованные поля.
  - Tradeoffs:
    - если DEK скомпрометирован, смена пароля не помогает → нужна отдельная операция “rotate DEK” (редко, но можно предусмотреть);
    - требуется строгий контроль транзакционности и crash-consistency.
  - **REVIEW** ⚠️ Ротация DEK — это “редкий аварийный инструмент”; не стоит тащить его в MVP, но полезно явно отметить как отдельную команду/путь восстановления.

- **Как реализовать в Z00Z**:
  - API на уровне кошелька:
    ```rust
    pub async fn change_passphrase(
        store: &WalletStore,
        old: &SafePassword,
        new: &SafePassword,
    ) -> Result<(), WalletError> {
        // 1) read MasterKeyRecord
        // 2) unwrap DEK with old password
        // 3) wrap DEK with new password (possibly with upgraded KDF params)
        // 4) write new MasterKeyRecord atomically
        todo!()
    }
    ```
  - Где менять:
    - `z00z_wallets`: orchestration (политика, проверки, UX ошибки);
    - `z00z_storage`: транзакционная операция “заменить master key record”; желательно lock на время операции;
    - `z00z_crypto`: KDF derivation + AEAD wrap/unwrap.
  - Crash-consistency:
    - использовать commit-marker подход (как выше) или запись “нового MTR” + swap pointer, чтобы при падении не остаться с полуполями.

### AAD prefix + version

- **В чём идея**: AAD (additional authenticated data) — это способ “привязать” шифртекст к контексту *без* включения этого контекста в plaintext.
  - Дев-смысл: если вы шифруете поле (например, seed, key, notes), то важно, чтобы этот ciphertext нельзя было:
    - подменить на ciphertext другого поля,
    - перенести между кошельками,
    - интерпретировать в другой версии формата.
  - Для этого в AAD включают:
    - версию схемы/формата,
    - идентификатор кошелька,
    - “тип объекта” и “имя поля”.
  - Итог: даже если атакующий переставит ciphertext местами, AEAD tag не сойдётся.
  - **REVIEW** ✅ Корректно. AAD — это то место, где “поле перепутали местами” превращается из критического бага в безопасный отказ.

- **Что взять из Tari и почему полезно (+ tradeoffs)**:
  - Что взять:
    - строгий, канонический builder AAD: один алгоритм сборки байт, без “случайных строк”;
    - version в AAD (anti-replay между форматами);
    - wallet binding (wallet_id в AAD), чтобы ciphertext не переносился между wallet-файлами.
  - Почему полезно:
    - предотвращает класс ошибок “не тем ключом расшифровали не то поле”;
    - делает миграции безопаснее: форматная версия становится частью аутентификации.
  - Tradeoffs:
    - изменение AAD схемы = миграция (нужно перешифровать соответствующие поля/records);
    - важно стабилизировать сериализацию AAD (endianness, длины, разделители).
  - **REVIEW** ⚠️ Лучше заранее зафиксировать “wire encoding” AAD: числовые kind_id вместо строк, length-prefix для field, big-endian для чисел. Это уменьшит риск несовместимости между версиями/языками.

- **Как реализовать в Z00Z**:
  - Где разместить AAD builder:
    - `z00z_crypto` (рядом с AEAD envelope), чтобы все пользователи делали одинаково.
  - Code-shape (ориентир):
    ```rust
    pub enum AadObjectKind {
        MasterKeyRecord,
        WalletSecret,
        OutputNote,
    }
    
    pub fn build_aad(
        schema_version: u32,
        wallet_id: [u8; 16],
        kind: AadObjectKind,
        field: &'static str,
    ) -> Vec<u8> {
        // canonical encoding: version || wallet_id || kind_id || field_bytes
        todo!()
    }
    ```
  - Политика:
    - включать `schema_version` и `wallet_id` обязательно;
    - `field` должен быть фиксированным литералом (не пользовательский ввод).
  - Использование:
    - `get_db_cipher`/wrap DEK: AAD = (schema_version, wallet_id, MasterKeyRecord, "wrapped_dek").
  - **REVIEW** ✅ Привязка к `wallet_id` must-have; без неё ciphertext становится переносимым между wallet-файлами.

### `derive_secondary_key`

- **В чём идея**: иногда нужен “вторичный ключ” (secondary key) или “commitment”, чтобы:
  - быстро понять, что пароль подходит (или наоборот),
  - не пытаясь расшифровать множество полей,
  - и не выдавая лишней информации наружу.
  - Дев-смысл: `derive_secondary_key` обычно строится как KDF(password, salt, params) + доменная привязка (DST/AAD), а затем из результата выводится:
    - либо ключ для дополнительного шифрования,
    - либо короткий commitment, который хранится в метаданных и проверяется при unlock.
  - **REVIEW** ⚠️ Added value зависит от того, насколько “дорог” ваш unlock сегодня: если unwrap DEK и так один AEAD-decrypt, вторичный commitment может быть избыточен. Если же есть много полей/операций до первого отказа — это может упростить UX.

- **Что взять из Tari и почему полезно (+ tradeoffs)**:
  - Что взять:
    - доменную привязку: secondary key для “wallet unlock check” не должен совпадать с KEK/другими ключами;
    - хранить commitment так, чтобы он не стал “быстрым оффлайн-оракулом” (в реальности KDF всё равно дорогой, но важно не создавать дополнительных упрощений);
    - нормализацию ошибок и rate limiting попыток.
  - Почему полезно:
    - unlock flow быстрее и стабильнее (проверка до тяжёлых операций);
    - можно отделить “неверный пароль” от “коррупция” внутри системы, но наружу отдавать аккуратно.
  - Tradeoffs:
    - любой password-check механизм — потенциальный oracle, если ошибки/тайминги различаются → нужно дисциплинированно:
      - одинаковые задержки,
      - одинаковые ошибки на UI,
      - лимиты попыток.
  - **REVIEW** ✅ Хорошо, что это явно описано как oracle-risk. Здесь нельзя “слегка недоделать” — иначе вы сами создадите ускоренную проверку пароля.

- **Как реализовать в Z00Z**:
  - Спецификация ключа:
    - secondary key derivation должна иметь свой DST:
      - `DST_WALLET_SECONDARY_KEY = "z00z.wallet.secondary_key.v1"`.
  - Code-shape (ориентир):
    ```rust
    pub fn derive_secondary_key(
        password: &SafePassword,
        salt: &[u8],
        params: &Argon2Parameters,
    ) -> [u8; 32] {
        // 1) run Argon2(password, salt, params) -> key_material
        // 2) hash with DST to separate domains
        todo!()
    }
    ```
  - Rate limiting:
    - хранить в `z00z_wallets`/session счётчик неуспешных попыток + backoff;
    - в storage (опционально) хранить “last_failed_unlock_at” для persistence.
  - Ошибки:
    - наружу (UI/RPC) отдавать один тип ошибки “unlock failed”;
    - внутрь логировать классификацию (invalid password vs corrupted meta) без утечки секретов.
  - **REVIEW** ✅ Это хорошо стыкуется с уже обсуждённой нормализацией ошибок в unlock/change-passphrase.

---

## z00z_crypto/tari/wallet/src/storage/sqlite_utilities/wallet_db_connection.rs

### `WalletDbConnection`

- **В чём идея**: `WalletDbConnection` — это не просто “обёртка над connection”, а *носитель политики конкурентного доступа* к wallet DB.
  - Дев-смысл: для кошелька критично, чтобы операции записи были последовательными (single-writer), иначе легко получить:
    - гонки “две задачи одновременно меняют статус транзакции”,
    - partial updates (одна транзакция записала outputs, другая — tx record, а в итоге несогласованность),
    - deadlocks/`database is locked` в sqlite.
  - Поэтому lock должен жить столько же, сколько “сессия” доступа к БД, а не “сколько длится один вызов функции”. Wrapper помогает сделать это явным.
  - **REVIEW** ✅ Это правильная модель: single-writer на уровне сессии, а не “лок” внутри каждой функции.

- **Что взять из Tari и почему полезно (+ tradeoffs)**: Tari использует идею “соединение + lock” как один объект, который удерживается сервисом/протоколом на время транзакции.
  - Что взять:
    - RAII: lock берётся при создании `WalletDbConnection` и освобождается при drop;
    - явный тип “write session” vs “read session” (если нужно), чтобы не держать write-lock дольше необходимого;
    - понятный lifecycle: кто владелец соединения, когда оно закрывается, как происходит shutdown.
  - Почему полезно:
    - меньше flaky ошибок sqlite и меньше гонок;
    - проще reasoning: если есть `WalletDbConnection`, то у вас уже есть право писать;
    - легче внедрять транзакционность (begin/commit вокруг операций).
  - Tradeoffs:
    - риск “держим lock слишком долго” → нужно дисциплинировать: короткие транзакции и минимум await внутри lock;
    - увеличивается количество типов/обёрток.

- **Как реализовать в Z00Z**:
  - Как это ложится на текущую инфраструктуру:
    - в `z00z_storage` логично иметь `WltSession`/`StoreSession`, который содержит:
      - соединение/handle,
      - write lock,
      - возможно, контекст транзакции.
  - Code-shape (ориентир):
    ```rust
    pub struct WltSession {
        // lock живет столько же, сколько session
        _write_guard: WriteGuard,
        conn: DbConn,
    }
    
    impl WltSession {
        pub async fn begin_write(store: &WalletStore) -> Result<Self, StoreError> {
            // acquire write lock + open/checkout connection
            todo!()
        }
    
        pub fn conn(&self) -> &DbConn { &self.conn }
    }
    ```
  - Практика для Z00Z:
    - избегать `await` внутри удерживаемого sqlite write-lock, либо “собирать данные снаружи → потом быстро записывать внутри транзакции”.
  - **REVIEW** ✅ В Z00Z уже есть `WltSession` и file-lock/session подход вокруг `.wlt`. Этот раздел лучше привязать к текущей реализации (RedB транзакции + file lock), а не к sqlite, чтобы не получился “дизайн второго хранилища”.

---

## z00z_crypto/tari/wallet/src/util/wallet_identity.rs

### `WalletIdentity`

- **В чём идея**: `WalletIdentity` — это *один* canonical объект, который описывает “кто я” для всех подсистем кошелька.
  - Дев-смысл: в кошельке очень много мест, где нужен identity/context:
    - публичные ключи/адрес,
    - network (chain id / network discriminator),
    - wallet_id/fingerprint,
    - тип кошелька (capabilities),
    - узловая identity (если кошелёк общается через p2p).
  - Если эти данные размазаны (каждый сервис держит свою копию), неизбежно появится дрейф:
    - сервис А думает, что network=testnet, сервис Б — mainnet,
    - один компонент подписывает одним ключом, другой проверяет другим.
  - **REVIEW** ✅ Это уже реализовано в `z00z_wallets` на базовом уровне: `WalletIdentity` (network/chain) persisted и валидируется при `open`. Раздел скорее про расширение и дисциплину распространения identity по сервисам.
  - **REVIEW** ⚠️ Не перегружайте `WalletIdentity` чувствительными полями (seed/секреты). Если добавляете fingerprint/wallet_id — заранее определите политику редактирования в логах.

- **Что взять из Tari и почему полезно (+ tradeoffs)**:
  - Что взять:
    - “identity как value object” → создаётся при `Wallet::start/open` один раз и передаётся всем сервисам;
    - persistence: identity сохраняется в wallet storage и читается при открытии;
    - версионирование структуры identity (поля могут добавляться).
  - Почему полезно:
    - меньше багов конфигурации/сети;
    - проще audit/debug: есть один объект, который можно вывести (в redacted виде) в диагностику;
    - проще миграции: меняем schema identity в одном месте.
  - Tradeoffs:
    - нужно аккуратно управлять совместимостью и миграциями (добавление полей, значения по умолчанию);
    - нельзя бездумно логировать identity (часть полей может быть чувствительной).

- **Как реализовать в Z00Z**:
  - Где хранить:
    - в `.wlt` / wallet DB отдельный record `WalletIdentityRecord` (schema-versioned).
  - Code-shape (ориентир):
    ```rust
    pub struct WalletIdentity {
        pub wallet_id: [u8; 16],
        pub network: NetworkId,
        pub wallet_type: WalletType,
        pub node_public_key: PublicKey,
    }
    
    impl WalletIdentity {
        pub fn redacted_debug(&self) -> String {
            // показываем только fingerprint/id, без секретов
            todo!()
        }
    }
    ```
  - Встраивание:
    - `z00z_wallets::Wallet::start`: читает/создаёт identity и прокидывает в сервисы;
    - `z00z_networks`: использует `network`/`node_public_key` для handshake;
    - `z00z_storage`: использует `wallet_id` для AAD builder (см. блок AAD).
  - **REVIEW** ⚠️ В Z00Z уже есть `WalletIdentity` (network/chain) persisted и валидируется на `open`. В этом разделе лучше говорить про расширение/версионирование существующего persisted identity, чтобы не получить два разных `WalletIdentity` с разным набором полей.
  - **REVIEW** ✅ Идея `redacted_debug()` правильная: identity часто нужно для диагностики, но логировать без редактирования — риск.

---

## z00z_crypto/tari/wallet/src/transaction_service/protocols/transaction_broadcast_protocol.rs

### `TransactionBroadcastProtocol::execute`

- **В чём идея**: broadcast транзакции — это не “один RPC вызов”, а жизненный цикл с повторными попытками, проверками статуса и корректным shutdown.
  - Дев-смысл: сеть нестабильна, node может быть недоступен, mempool может временно отклонять. Если реализовать broadcast как “один раз отправили и забыли”, то:
    - пользователь будет видеть “pending навсегда”,
    - кошелёк будет спамить сеть (если retry без ограничений),
    - при shutdown можно оставить БД в промежуточном состоянии.
  - Поэтому `execute` обычно — state machine loop: отправить → подождать → спросить статус → решить retry/cancel/done.
  - **REVIEW** ✅ Это корректный “протокольный” взгляд: broadcast действительно должен быть state machine с persisted шагами, иначе будут вечные pending и гонки.

- **Что взять из Tari и почему полезно (+ tradeoffs)**:
  - Что взять:
    - `tokio::select!`/event-driven loop:
      - реагировать на shutdown signal,
      - реагировать на таймеры/интервалы,
      - реагировать на события (например, “tx mined” от другого протокола);
    - bounded retries + backoff + “окно ресабмита”;
    - строгие переходы состояний и запись в БД после каждого значимого шага.
  - Почему полезно:
    - resilience: меньше “застрявших” транзакций;
    - контроль нагрузки: retry bounded;
    - корректность: state transitions централизованы.
  - Tradeoffs:
    - больше состояния и тестов;
    - нужно аккуратно выбирать таймауты/пороги для разных сетей.

- **Как реализовать в Z00Z**:
  - Как это ложится на существующие модули:
    - `z00z_wallets`: владелец протокола и его конфигурации;
    - `z00z_networks`: RPC client для submit/query;
    - `z00z_storage`: хранение состояния broadcast-попыток (timestamps, attempts, last_error_class).
  - Code-shape (ориентир):
    ```rust
    pub struct BroadcastConfig {
        pub max_attempts: u32,
        pub base_backoff_ms: u64,
        pub resubmit_window_ms: u64,
    }
    
    pub async fn execute(
        tx_id: TxId,
        cfg: BroadcastConfig,
        store: &WalletStore,
        rpc: &impl BaseNodeClient,
        shutdown: &ShutdownSignal,
    ) -> Result<(), BroadcastError> {
        let mut attempts = 0;
        loop {
            tokio::select! {
                _ = shutdown.cancelled() => break,
                _ = tokio::time::sleep(backoff(attempts, cfg.base_backoff_ms)) => {
                    // submit + query + update state
                    attempts += 1;
                    todo!()
                }
            }
            if attempts >= cfg.max_attempts { break; }
        }
        Ok(())
    }
    ```
  - Инварианты для Z00Z:
    - “emit after commit”: любые UI events (“tx broadcasted”, “tx rejected”) выпускать только после записи в storage;
    - retry должен быть bounded и подчиняться конфигу;
    - при shutdown протокол должен gracefully выйти, оставив корректный persisted state.
  - **REVIEW** ⚠️ Термин “cancel” здесь лучше разделить на два смысла: (1) пользователь отменил, (2) протокол завершился в `BroadcastFailed`. Иначе можно случайно отобразить пользователю “вы отменили”, хотя это был сетевой фейл.

### `submit_transaction` (rejection mapping + cancel)

- **В чём идея**: `submit_transaction` — это “точка принятия решения”, где сырая ошибка/ответ от node переводится в *конкретное действие* над локальным состоянием транзакции.
  - Дев-смысл: base node/mempool может вернуть множество причин отказа, но кошелёк должен:
    - не превращать это в хаотичный UX (“то retry, то cancel без объяснения”),
    - не спамить повторными отправками там, где это бессмысленно,
    - сохранить консистентное состояние (pending → rejected/cancelled/queued-for-retry).
  - Поэтому нужна таблица “rejection → action”: классифицируем причину и выбираем стратегию.
  - **REVIEW** ✅ Это даёт высокий added value: превращает “хаос ошибок сети” в предсказуемую политику и покрываемые тестами правила.

- **Что взять из Tari и почему полезно (+ tradeoffs)**: Tari обычно делает явное сопоставление причин (enum) к действиям протокола.
  - Что взять:
    - стабильный enum причин отказа (на уровне RPC types) и маппинг:
      - *Permanent* (никогда не пройдет) → terminal state (cancel/rejected),
      - *Transient* (сеть/временная) → retry/backoff,
      - *AlreadyMined/AlreadyInMempool* → считать успехом и перейти к query/monitor,
      - *FeeTooLow/BadInputs* → часто terminal (или “needs user action”).
    - нормализация ошибок: внешний слой не должен зависеть от текста ошибок.
  - Почему полезно:
    - UX становится предсказуемым: одинаковые ошибки → одинаковые результаты;
    - меньше сетевой нагрузки: не retry’им бессмысленное;
    - тестируемость: таблица маппинга тестируется как чистая функция.
  - Tradeoffs:
    - нужно поддерживать enum причин и обновлять при изменениях RPC/base node;
    - иногда причина неоднозначна → потребуются conservative defaults.

- **Как реализовать в Z00Z**:
  - Вынести классификацию в отдельную функцию (чистую):
    ```rust
    pub enum SubmitOutcome {
        Accepted,
        AlreadyKnown,
        RetryLater { backoff_ms: u64 },
        Cancel { reason: CancelReason },
    }
    
    pub fn map_rejection_to_outcome(err: BaseNodeSubmitError) -> SubmitOutcome {
        // match on typed error codes, not strings
        todo!()
    }
    ```
  - Где хранить и применять:
    - `z00z_wallets`: `TransactionBroadcastProtocol` вызывает `submit_transaction`, получает `SubmitOutcome`, делает state transition.
    - `z00z_networks`: вернуть типизированные ошибки из RPC (ошибочные коды), чтобы не парсить строки.
    - `z00z_storage`: хранить `last_submit_result`, `attempt_count`, `last_attempt_at`, `terminal_reason`.
  - Инвариант: решение (cancel/retry) должно быть записано в storage транзакционно и только потом эмититься в UI.
  - **REVIEW** ⚠️ Если RPC сейчас возвращает только строки/общий `Error`, добавлять “типизированные причины” нужно на уровне `z00z_networks`/RPC types в первую очередь, иначе маппинг неизбежно превратится в brittle string parsing.

### `transaction_query` (resubmission window)

- **В чём идея**: даже если submit “прошёл”, транзакция может не попасть в mempool/не быть видимой сразу. Тогда протокол делает query.
  - Дев-смысл: `transaction_query` отвечает на вопросы:
    - “видит ли node эту транзакцию сейчас?”
    - “стоит ли ресабмитить (и как часто)?”
    - “когда мы перестаём ресабмитить и объявляем проблему?”
  - Ключ — *resubmission window*: ограниченное окно времени/попыток, в течение которого кошелёк делает активные действия.
  - **REVIEW** ✅ Концепт окна ресабмита — правильная защита от бесконечных ретраев и “вечного pending”.

- **Что взять из Tari и почему полезно (+ tradeoffs)**:
  - Что взять:
    - окно ресабмита (например, N минут/часов) + лимит попыток;
    - query перед resubmit: не отправлять лишний раз, если tx уже в mempool/уже mined;
    - backoff между попытками;
    - переходы состояния зависят от ответа query (InMempool/Mined/NotFound).
  - Почему полезно:
    - защита от бесконечного спама в сеть;
    - более корректная модель “pending”: он не бесконечный, а с понятной политикой.
  - Tradeoffs:
    - если сеть/узлы нестабильны, можно prematurely прекратить resubmit → важно дать пользователю/оператору опцию “retry/rescan/rebroadcast”.

- **Как реализовать в Z00Z**:
  - Persisted state:
    - хранить `first_broadcast_at`, `last_broadcast_at`, `attempts`, `resubmit_window_ms` (или ссылку на конфиг версии).
  - Code-shape:
    ```rust
    pub enum QueryResult {
        NotFound,
        InMempool,
        Mined { height: u64 },
    }
    
    pub async fn transaction_query(
        rpc: &impl BaseNodeClient,
        tx_id: TxId,
    ) -> Result<QueryResult, QueryError> {
        todo!()
    }
    ```
  - Политика:
    - если `Mined` → завершить протокол (mark mined);
    - если `InMempool` → ждать/мониторить;
    - если `NotFound` и ещё внутри окна → resubmit;
    - если `NotFound` и окно истекло → terminal state `BroadcastFailed` (но не “canceled”, если пользователь не отменял).
  - **REVIEW** ⚠️ Хорошо бы явно отметить: “window” должен быть частью persisted state, иначе после рестарта кошелька протокол может начать ресабмит заново с нуля и превратиться в долгоживущий спамер.

### `check_transaction_size` + oversized cancel

- **В чём идея**: некоторые транзакции могут быть слишком большими (по байтам/кол-ву входов/выходов) и node их гарантированно отвергнет.
  - Дев-смысл: лучше остановить это *на клиенте*, до отправки, с понятным сообщением и корректным переводом в terminal state.
  - Это защищает:
    - сеть (не шлём заведомый мусор),
    - пользователя (быстрое объяснение),
    - **REVIEW** ⚠️ Проверка размера должна опираться на chain/network параметры (консенсусные лимиты), а не на захардкоженные числа в кошельке. Иначе при смене сети/параметров вы получите ложные отказы.
    - кошелёк (не застревает в retry loop).

- **Что взять из Tari и почему полезно (+ tradeoffs)**:
  - Что взять:
    - явный `check_transaction_size` перед submit;
    - в случае превышения — перевод в terminal state (например, `RejectedOversized`) без retry;
    - лимиты должны соответствовать node-консенсусу/политике mempool.
  - Почему полезно:
    - быстрое выявление проблем (особенно при batched payments);
    - стабильный UX: “почему не отправляется” понятно.
  - Tradeoffs:
    - клиентские лимиты надо синхронизировать с node (версионирование/конфиг);
    - если лимиты меняются по сети, нужен network-specific config.

- **Как реализовать в Z00Z**:
  - Источник лимитов:
    - `z00z_networks`/chain params: хранить `max_tx_weight`/`max_tx_bytes`/`max_inputs` (как применимо) и версионировать по network.
  - Code-shape:
    ```rust
    pub fn check_transaction_size(tx: &Transaction, limits: &TxSizeLimits) -> Result<(), TxSizeError> {
        // serialize (or compute weight) and compare
        todo!()
    }
    ```
  - Поведение протокола:
    - если `Oversized` → записать terminal state + reason, эмитить UI event “Transaction too large”;
    - не пытаться resubmit.

---

## z00z_crypto/tari/tari_console_wallet/src/grpc/wallet_debouncer.rs

### `WalletDebouncer::get_balance`

- **В чём идея**: сделать `get_balance` “дешёвым” для UI и RPC за счёт кэша + обновления по событиям.
  - Дев-смысл: баланс часто запрашивается очень часто (UI polling, dashboards), но “истина” всё равно в БД/сервисах кошелька. Поэтому API должен:
    - отдавать быстрый snapshot,
    - обновлять его по триггерам (tx events, scan progress),
    - не перегружать storage и service tasks.
  - **REVIEW** ✅ Added value высокий: баланс — hot-path UI/RPC, и debouncer реально снижает нагрузку на storage и сериализацию.
  - **REVIEW** ⚠️ Нужна явная policy freshness: кешированное значение нельзя использовать как основание для критических операций (например, `send_tx`) без “force refresh” пути.

- **Что взять из Tari и почему полезно (+ tradeoffs)**:
  - Что взять:
    - debouncer/cache перед `get_balance`, который обслуживает bursty запросы;
    - invalidation по событийному fan-in (из tx service, output manager, scan/rescan);
    - чёткую политику freshness:
      - “может быть stale до N мс” либо “stale пока не пришёл trigger”.
  - Почему полезно:
    - снижает нагрузку на sqlite/redb и на CPU сериализации;
    - убирает UI lag при одновременных запросах;
    - проще масштабировать RPC/UI одновременно.
  - Tradeoffs:
    - invalidation сложнее, чем polling: нужно не пропускать ключевые события;
    - возможны “мигающие” значения при гонках (важно version/timestamp в snapshot);
    - нужно учитывать multi-wallet/multi-profile (кэш привязан к wallet_id).

- **Как реализовать в Z00Z**:
  - Где:
    - в RPC/UI слое — `WalletDebouncer` как thin helper вокруг `WalletService`.
  - Данные кэша:
    - `BalanceSnapshot { wallet_id, at_ms, available, pending_in, pending_out, locked, scan_state_version }`.
  - Инвалидация:
    - любые события, которые меняют UTXO-set или его интерпретацию:
      - new output, output spent, tx mined/confirmed, reorg, rescan progress.
  - Code-shape:
    ```rust
    pub struct BalanceSnapshot {
        pub wallet_id: String,
        pub at_ms: u64,
        pub available: u64,
        pub pending_in: u64,
        pub pending_out: u64,
    }
    
    pub struct WalletDebouncer {
        cache: tokio::sync::RwLock<Option<BalanceSnapshot>>,
        dirty: tokio::sync::watch::Receiver<bool>,
    }
    
    impl WalletDebouncer {
        pub async fn get_balance(&self, svc: &WalletService) -> Result<BalanceSnapshot, WalletError> {
            // If not dirty and cache exists → return fast.
            // If dirty or missing cache → refresh once, then clear dirty.
            todo!()
        }
    }
    ```
    - **REVIEW** ✅ Хорошо, что snapshot несёт `wallet_id` и `at_ms`: это минимальная диагностика “насколько устарело” и защита от смешивания профилей.

### `monitor_events` + readiness flags + connectivity heuristic

- **В чём идея**: один мониторинг-таск собирает события из разных сервисов кошелька и выставляет агрегированные флаги “готовности” и “онлайн/оффлайн”.
  - Дев-смысл:
    - UI/RPC не должны понимать десятки внутренних состояний (DHT, base node sync, tx service, scan);
    - нужен небольшой набор стабильных флагов, чтобы:
      - показывать “wallet ready / syncing / offline”,
      - избегать ложных “0 balance” во время startup/rescan,
      - корректно отключать опасные действия (send) при offline.
  - **REVIEW** ✅ Это правильная граница абстракции: UI/RPC получают стабильные coarse состояния вместо десятков внутренних флагов.

- **Что взять из Tari и почему полезно (+ tradeoffs)**:
  - Что взять:
    - fan-in событий (несколько источников → один агрегатор);
    - readiness как coarse state machine (не бинарно):
      - `Starting` → `Syncing` → `Ready` → `Degraded`;
    - connectivity heuristic вместо “точной истины”:
      - online = “последний успешный контакт/проба < T”.
  - Почему полезно:
    - UI перестаёт дёргаться от transient ошибок;
    - RPC возвращает стабильно интерпретируемые статусы;
    - проще трассировка и алерты (telemetry по readiness transitions).
  - Tradeoffs:
    - heuristics нужно калибровать (таймауты/окна);
    - возможны ложные positives/negatives → важно уметь показывать “degraded”.
  - **REVIEW** ⚠️ Connectivity heuristic — это UI-индикатор, не гарантия. Важно, чтобы “is_online=true” не автоматически означало “можно отправлять tx” без отдельных preflight-проверок.

- **Как реализовать в Z00Z**:
  - Ввести минимальный набор флагов в core-слое API (чтобы и UI, и RPC использовали одно):
    - `is_ready`, `is_syncing`, `is_online`, `last_contact_ms`, `scan_progress`.
  - Агрегатор:
    - отдельный task в `z00z_wallets` (или rpc/ui crate), который:
      - слушает `WalletEvent`/`ServiceEvent` из bounded channel,
      - обновляет `watch::Sender<WalletReadinessSnapshot>`.
  - Code-shape:
    ```rust
    pub struct WalletReadinessSnapshot {
        pub is_ready: bool,
        pub is_online: bool,
        pub is_syncing: bool,
        pub last_contact_ms: Option<u64>,
    }
    
    pub async fn monitor_events(
        mut events: tokio::sync::mpsc::Receiver<WalletEvent>,
        readiness_tx: tokio::sync::watch::Sender<WalletReadinessSnapshot>,
    ) {
        // fold events into snapshot; apply time-based heuristics
        todo!()
    }
    ```

---

## z00z_crypto/tari/tari_console_wallet/src/ui/state/wallet_event_monitor.rs

### `WalletEventMonitor::run` + lossy refresh triggers

- **В чём идея**: UI-слой получает “подсказки” о том, что надо обновить экран/снапшот, но не пытается быть источником истины и не требует гарантированной доставки каждого события.
  - Дев-смысл:
    - для UI важнее “в итоге прийти к консистентной картинке”, чем “увидеть каждое событие”; иначе придётся строить durable event log.
    - события могут быть lossy (drop/coalesce), а UI должен уметь пересинхронизироваться через snapshot API.
    - **REVIEW** ✅ Это хороший, не-overengineered подход: lossy triggers + snapshot как источник истины обычно проще и надёжнее durable event log для UI.

- **Что взять из Tari и почему полезно (+ tradeoffs)**:
  - Что взять:
    - отдельный UI monitor, который:
      - слушает bounded event stream,
      - coalesce-ит события в “refresh needed” (debounce),
      - периодически делает snapshot refresh.
    - явное разделение:
      - core events = внутренние переходы/ошибки,
      - ui triggers = “обнови состояние”.
  - Почему полезно:
    - UI становится простым: “получил trigger → вызвал get_state/get_balance”; 
    - снижается риск deadlocks (UI не держит locks кошелька);
    - легче тестировать: можно симулировать triggers.
  - Tradeoffs:
    - UI может пропустить событие → обязательно иметь snapshot endpoint;
    - нужно аккуратно подобрать debounce window, чтобы не спамить storage.

- **Как реализовать в Z00Z**:
  - В egui/desktop:
    - `WalletEventMonitor` живёт рядом с UI state, подписан на `WalletEvent` (или `UiTrigger`).
  - Политика:
    - “events are hints; snapshot is source of truth”.
  - **REVIEW** ✅ Эту фразу стоит считать инвариантом UX/API: тогда можно смело coalesce/drop события, не ломая консистентность интерфейса.
  - Code-shape:
    ```rust
    pub enum UiTrigger {
        RefreshSoon,
        RefreshNow,
    }
    
    pub struct WalletEventMonitor {
        triggers_rx: tokio::sync::mpsc::Receiver<UiTrigger>,
    }
    
    impl WalletEventMonitor {
        pub async fn run(mut self, api: WalletUiApi) {
            // debounce triggers; call api.get_state(); update UI model
            todo!()
        }
    }
    ```

---

## z00z_crypto/tari/tari_console_wallet/src/grpc/wallet_grpc_server.rs

### `get_state` (bundle readiness + network status)

- **В чём идея**: `get_state` — это *канонический snapshot endpoint*, который отдаёт UI/интеграциям “всё важное для экрана состояния” одним атомарным ответом.
  - Дев-смысл: UI почти всегда хочет одновременно:
    - готов ли кошелёк (locked/unlocked, синхронизирован ли),
    - есть ли связь с сетью/узлами,
    - прогресс сканирования/рескана,
    - состояние очередей/фоновых задач,
    - агрегированные балансы (или хотя бы “stale/unknown”).
  - Если это собирается десятком отдельных вызовов, появляются:
    - рассогласование во времени,
    - N round trips,
    - дублирование логики “готов/не готов” в клиентах.
  - **REVIEW** ✅ Это правильный UX/API паттерн: один snapshot снижает гонки и упрощает клиент.

- **Что взять из Tari и почему полезно (+ tradeoffs)**:
  - Что взять:
    - “single snapshot call” как основной путь для UI;
    - версионирование snapshot (добавление полей не ломает старых клиентов);
    - readiness как *набор стадий/флагов*, а не один boolean.
  - Почему полезно:
    - меньше round trips и race conditions;
    - UI проще: одна модель состояния;
    - удобнее наблюдать/дебажить (redacted snapshot можно логировать).
  - Tradeoffs:
    - snapshot легко разрастается → держать дисциплину полей (без списков транзакций/истории);
    - нужны правила для “дорогих” полей (locked/stale/unknown), чтобы не блокировать UI.
  - **REVIEW** ✅ Хорошо, что tradeoff явно описан: “не тащить историю в snapshot” — это ключ к не-овер-инжинирингу.

- **Как реализовать в Z00Z**:
  - В `z00z_wallets` собрать `WalletStateSnapshot` из внутренних сервисов; транспорт (JSON-RPC/gRPC/HTTP) сделать тонким.
  - Shape ответа (ориентир):
    ```rust
    pub struct WalletStateSnapshot {
        pub version: u32,
        pub readiness: Readiness,
        pub network: NetworkStatus,
        pub scan: ScanStatus,
        pub balances: Option<BalanceSummary>,
    }
    
    pub struct Readiness {
        pub is_unlocked: bool,
        pub is_synced: bool,
        pub is_scanning: bool,
        pub last_error: Option<String>,
    }
    ```
  - Инварианты:
    - snapshot не содержит секреты (seed/keys/raw scripts);
    - “дорогие” поля либо `Option`, либо имеют `computed_at_ms`/`is_stale`.
  - **REVIEW** ⚠️ `last_error: Option<String>` в примере потенциально приводит к stringly-typed контракту. Лучше хранить типизированный `code` + краткий `message` (и/или redacted details), чтобы клиенты не начинали парсить текст.

### `get_balance` (fast path by payref/payment_id)

- **В чём идея**: `get_balance` нужен в двух режимах:
  1) общий баланс кошелька,
  2) точечная сводка по конкретной операции/идентификатору (payref/payment_id), чтобы экран деталей открывался быстро.
  - Дев-смысл fast path: не пересчитывать всё, если UI просит ровно “вот эта операция”, особенно во время сканирования.
  - **REVIEW** ✅ Added value высокий для UX: “детальная карточка операции” обычно не должна триггерить полный пересчёт.

- **Что взять из Tari и почему полезно (+ tradeoffs)**:
  - Что взять:
    - scoped queries по payref/payment_id (через индексы/агрегаты),
    - единые инварианты учёта для scoped и global (иначе пользователи увидят расхождение).
  - Почему полезно:
    - UI отзывчивее;
    - меньше блокировок на большие пересчёты.
  - Tradeoffs:
    - нужны индексы/агрегаты в storage;
    - при рескане баланс может быть `stale/pending` → требуется явная семантика.
  - **REVIEW** ⚠️ Здесь важно не допустить расхождения учёта: scoped и global должны использовать одну и ту же логику статусов/инклюзии (иначе UI покажет разные цифры для одной операции).

- **Как реализовать в Z00Z**:
  - API уровня сервиса:
    ```rust
    pub enum BalanceQueryScope {
        Global,
        ByPayRef(PayRef),
    }
    
    pub async fn get_balance(scope: BalanceQueryScope) -> Result<BalanceSummary, WalletError> {
        todo!()
    }
    ```
  - Результат содержит `computed_at_ms` и/или `is_stale`, чтобы UI не “додумывал”.

### `stream_transaction_events` (bounded stream + backpressure)

- **В чём идея**: stream событий — это не “истина”, а механизм уведомления.
  - Дев-смысл: клиент может отвалиться/пропустить события, поэтому snapshot (`get_state`) остаётся источником истины.
  - Stream должен быть bounded и иметь политику backpressure (drop/coalesce), иначе один медленный клиент может убить сервер.
  - **REVIEW** ✅ Правильная семантика: events — только уведомления, snapshot — источник истины.
  - **REVIEW** ⚠️ Важно явно зафиксировать поведение при переполнении: например, drop oldest + единый `RefreshSoon`, чтобы клиенты не ожидали доставку каждого события.

- **Что взять из Tari и почему полезно (+ tradeoffs)**:
  - Что взять:
    - bounded delivery per subscriber;
    - “events are hints”: события приводят к `RefreshSoon/RefreshNow`, а не к попытке синхронизировать UI “по событиям”; 
    - явная политика переполнения (drop old + послать refresh trigger).
  - Почему полезно:
    - устойчивость к медленным/подвисшим подписчикам;
    - проще API для клиентов.
  - Tradeoffs:
    - клиент обязан уметь делать refresh по snapshot;
    - нужно определить, какие события “важные” (refresh now) и какие “шум” (debounce/coalesce).

- **Как реализовать в Z00Z**:
  - На RPC-слое:
    - ограничить число подписчиков (global cap),
    - каждому подписчику выделить bounded очередь,
    - при переполнении: drop old и отправить `RefreshSoon`.
  - UI/клиентская политика:
    - любое событие → trigger → затем `get_state`/`get_balance`.

### `rescan_wallet` (deterministic reset + progress)

- **В чём идея**: `rescan_wallet` — это явная операция, которая детерминированно сбрасывает scan cursor и запускает пересканирование.
  - Дев-смысл: rescan должен быть crash-safe: если процесс упал, после рестарта понятно, что rescan был запрошен и где продолжать.
  - **REVIEW** ✅ Crash-safe marker + persisted progress — must-have, иначе рескан будет источником “магических” багов после рестартов.

- **Что взять из Tari и почему полезно (+ tradeoffs)**:
  - Что взять:
    - рескан как транзакционная операция: сброс scan state + marker “rescan requested”; 
    - публикация прогресса отдельными событиями/полями snapshot.
  - Почему полезно:
    - нет “частичных” ресканов без маркера;
    - UI может корректно показывать прогресс и состояние.
  - Tradeoffs:
    - нужно продумать lock/конкуренцию: что делать, если rescan вызвали дважды;
    - желательно иметь policy (deny/queue/coalesce).
  - **REVIEW** ⚠️ Policy лучше выбрать простой: если rescan уже идёт — coalesce (вернуть “already in progress” + прогресс), без очередей и параллелизма.

- **Как реализовать в Z00Z**:
  - В storage (внутри одной write-транзакции):
    - `ScanState` → reset/truncate,
    - записать marker `rescan_requested_at_ms`,
    - после commit — эмитить trigger/событие.
  - В watcher/scan job:
    - если marker выставлен — стартовать rescan и обновлять `scan.progress` в snapshot.

---

## z00z_crypto/tari/tari_console_wallet/src/wallet_modes.rs

### `WalletMode` + `parse_command_file`

- **В чём идея**: один бинарь кошелька может запускаться в разных режимах (`WalletMode`), а автоматизация делается через “файл с CLI-командами”, без отдельного DSL.
  - Дев-смысл:
    - mode определяет transport/UX (interactive CLI, headless batch, RPC server, UI shell), но *не меняет* бизнес-логику;
    - command file — это воспроизводимые сценарии (demo/regression/CI), при этом команды остаются теми же, что и в интерактиве.
  - **REVIEW** ✅ Инвариант “mode не меняет бизнес-логику” — правильный предохранитель от дрейфа поведения CLI/RPC/UI.

- **Что взять из Tari и почему полезно (+ tradeoffs)**:
  - Что взять:
    - mode dispatch как тонкий слой вокруг одного `WalletService`/`Wallet`;
    - строгий parsing команд файла:
      - строки = команды,
      - комментарии/пустые строки игнорируются,
      - ошибки содержат line number + контекст;
    - “stop-on-first-error” как дефолт (детерминизм сценариев).
  - Почему полезно:
    - уменьшает дублирование: одна логика send/rescan/import для всех режимов;
    - улучшает поддержку: баги воспроизводятся через command file;
    - ускоряет разработку: для demo/QA не нужно писать отдельный harness.
  - Tradeoffs:
    - expressiveness ограничена (нет циклов/условий);
    - нужен аккуратный tokenizer (кавычки/эскейпы) либо reuse CLI tokenizer;
    - нужно исключить утечки секретов в логах (не логировать passphrase/seed).
  - **REVIEW** ⚠️ Command-file повышает риск утечки секретов: redaction должен применяться в ошибках парсинга/логах (вплоть до запрета печати argv для команд, где есть passphrase).

- **Как реализовать в Z00Z**:
  - Mode selector:
    - `z00z_wallets/bin`: один entrypoint, который
      - грузит config,
      - поднимает wallet core (`Wallet::start`),
      - выбирает оболочку.
  - Command file:
    - добавить флаг `--command-file <path>` в CLI режиме.
  - Code-shape:
    ```rust
    pub enum WalletMode {
        Cli,
        Rpc,
        Headless,
    }
    
    pub fn parse_command_file(contents: &str) -> Result<Vec<Vec<String>>, CommandFileError> {
        // return argv-like vectors per line
        todo!()
    }
    
    pub async fn run_mode(mode: WalletMode, cfg: WalletConfig, command_file: Option<String>) -> anyhow::Result<()> {
        let wallet = Wallet::start(cfg).await?;
        match mode {
            WalletMode::Cli => run_cli(wallet, command_file).await,
            WalletMode::Rpc => run_rpc(wallet).await,
            WalletMode::Headless => run_headless(wallet).await,
        }
    }
    ```

---

## z00z_crypto/tari/transaction_components/src/transaction_components/wallet_output.rs

### `WalletOutput` + conversions + deterministic ids

- **В чём идея**: хранить UTXO в форме, удобной кошельку (`WalletOutput`), и материализовать chain-level структуры (input/output) только при необходимости.
  - Дев-смысл:
    - chain-level output часто недостаточен для кошелька (derivation info, labels, payref, recovery/rewind data);
    - при построении транзакции нужны дополнительные локальные данные (ключи/скрипт/подписи).
  - “Deterministic ids” часть — это про стабильные идентификаторы для связывания wallet-record ↔ tx-record в БД (и для UI), чтобы:
    - не зависеть от случайного порядка,
    - уметь idempotent re-apply при reorg/rescan.
  - **REVIEW** ✅ Added value высокий: deterministic ids заметно упрощают идемпотентность при ресканах/реоргах и предотвращают дубликаты.

- **Что взять из Tari и почему полезно (+ tradeoffs)**:
  - Что взять:
    - `WalletOutput` как primary persisted record;
    - явные конверсии с проверками инвариантов:
      - `to_transaction_output`,
      - `to_transaction_input`;
    - вычисление стабильного `tx_id`/`output_id` (детерминированно из содержимого/commitment), чтобы:
      - повторные обработки не создавали дубликаты.
  - Почему полезно:
    - проще миграции и совместимость: wallet metadata меняется без изменения chain structures;
    - меньше риск рассинхронизации двух представлений;
    - легче дебажить: deterministic id стабилен между перезапусками.
  - Tradeoffs:
    - lazy-конверсия может выбрасывать ошибки “на границе” → нужно покрытие тестами;
    - если есть кэш derived частей — нужна корректная инвалидция при изменении ключей/политик.
  - **REVIEW** ⚠️ Deterministic id должен базироваться на стабильных canonical данных (обычно commitment/канонические bytes), а не на полях, которые могут меняться (labels/notes) — иначе id перестанет быть стабильным.

- **Как реализовать в Z00Z**:
  - Storage:
    - `z00z_wallets` хранит `WalletOutputRecord` в `.wlt` как source-of-truth;
    - derived tx parts можно держать только в памяти (не как второй durable источник истины).
  - Инварианты конверсий:
    - если output нельзя потратить (нет spending key ref / script invalid) → ошибка, и tx pipeline должен это обработать как terminal.
  - Code-shape:
    ```rust
    pub struct WalletOutput {
        pub commitment: [u8; 32],
        pub value: u64,
        pub spending_key_ref: KeyRef,
        pub script: Vec<u8>,
    }
    
    impl WalletOutput {
        pub fn output_id(&self) -> [u8; 32] {
            // deterministic: e.g. hash(commitment || value)
            todo!()
        }
        pub fn to_tx_output(&self) -> Result<TransactionOutput, OutputBuildError> { todo!() }
        pub fn to_tx_input(&self) -> Result<TransactionInput, InputBuildError> { todo!() }
    }
    ```
  - **REVIEW** ⚠️ Пример `hash(commitment || value)` лучше уточнить: зафиксировать каноническое кодирование (endianness/length) и по возможности предпочесть commitment-only id, если value может быть представлен по-разному/скрыт политиками.

---

## z00z_crypto/tari/transaction_components/src/transaction_components/wallet_output_builder.rs

### builder gating + recovery encryption + multi-party signing

- **В чём идея**: builder для output’а задаёт корректный порядок шагов и делает невозможным выпуск “полу-сформированного” output’а.
  - Дев-смысл:
    - output часто требует набор обязательных шагов: выбор ключей, скрипт/условия, recovery/rewind payload (если есть), (в некоторых схемах) подписи нескольких сторон.
    - builder как типизированный state machine позволяет:
      - явно “gating” обязательных полей,
      - ловить ошибки раньше,
      - упростить multi-party протоколы.
  - **REVIEW** ✅ Идея корректная: builder снижает класс ошибок “забыли обязательное поле”.
  - **REVIEW** ⚠️ Это легко увести в over-engineering. Если multi-party signing не в ближайшем scope, разумнее начать с простого builder + runtime validation, а staged-типы добавлять только при реальной необходимости.

- **Что взять из Tari и почему полезно (+ tradeoffs)**:
  - Что взять:
    - staged builder API (например, `Builder<NeedKeys> -> Builder<NeedScript> -> Builder<Ready>`);
    - recovery encryption как явный этап (и с AAD binding к context);
    - multi-party signing как протокол со строгой валидацией входных данных.
  - Почему полезно:
    - снижает класс багов “забыли заполнить обязательное поле”;
    - проще тестировать: каждый stage имеет свои инварианты;
    - безопаснее: recovery payload шифруется по правилам, а не “как получилось”.
  - Tradeoffs:
    - больше типов/стадий → выше порог входа;
    - при изменении протокола потребуется миграция builder API.

- **Как реализовать в Z00Z**:
  - `z00z_wallets` tx pipeline:
    - держать builder на границе “construct output”, чтобы выход был либо `WalletOutput`, либо явная ошибка.
  - `z00z_crypto`:
    - дать примитивы для recovery encryption и signing с domain separation.
  - Code-shape:
    ```rust
    pub struct WalletOutputBuilder<S> { /* fields */ _s: std::marker::PhantomData<S> }
    pub struct NeedKeys;
    pub struct Ready;
    
    impl WalletOutputBuilder<NeedKeys> {
        pub fn with_keys(self, key_ref: KeyRef) -> WalletOutputBuilder<Ready> { todo!() }
    }
    
    impl WalletOutputBuilder<Ready> {
        pub fn build(self) -> Result<WalletOutput, OutputBuildError> { todo!() }
    }
    ```

---

## z00z_crypto/tari/core/src/base_node/proto/wallet_rpc.rs

### `TxSubmissionResponse` / `TxSubmissionRejectionReason`

- **В чём идея**: ответы ноды на submit/query транзакции должны содержать закрытый (closed) набор причин отказа, чтобы кошелёк мог детерминированно выбрать действие.
  - Дев-смысл:
    - строковые “error messages” плохо машинно-интерпретируемы и нестабильны;
    - кошелёк должен отличать “retry позже” от “terminal failure”.
  - **REVIEW** ✅ Это напрямую поддерживает ваш broadcast-паттерн выше (rejection → action). Типизированные причины — большой выигрыш.

- **Что взять из Tari и почему полезно (+ tradeoffs)**:
  - Что взять:
    - `TxSubmissionRejectionReason` как enum с явной семантикой;
    - маппинг “rejection → policy” в broadcast протоколе:
      - `AlreadyMined` → success/terminal,
      - `InvalidSignature` → terminal,
      - `MempoolFull` → retry with backoff,
      - `Oversized` → terminal.
    - совместимое расширение:
      - добавление новых значений без поломки старых клиентов (unknown/other).
  - Почему полезно:
    - стабильный UX и стабильные автоматизации;
    - меньше ложных retries;
    - лучшее наблюдение: metrics по причинам отказов.
  - Tradeoffs:
    - enum надо версионировать в wire format;
    - при “unknown reason” нужен безопасный fallback.
  - **REVIEW** ⚠️ “Closed enum” в protobuf/RPC должен иметь безопасную обработку неизвестных значений. В кошельке conservative default обычно “RetryLater” на коротком окне или “Unknown → query”, но не “Cancel” без ясности.

- **Как реализовать в Z00Z**:
  - RPC types:
    - в `z00z_networks/rpc` или `z00z_wallets/rpc_types` определить `TxSubmissionRejectionReason`.
  - Broadcast mapping:
    - в `TransactionBroadcastProtocol` сделать функцию `map_rejection_to_action(reason) -> BroadcastAction`.
  - Code-shape:
    ```rust
    pub enum TxSubmissionRejectionReason {
        InvalidTransaction,
        InvalidSignature,
        MempoolFull,
        Oversized,
        Unknown,
    }
    ```

### `TxQueryResponse` / `TxLocation`

- **В чём идея**: ответ на `tx.query` должен быть компактным: где сейчас транзакция (mempool, mined, unknown) + опциональные mined-метаданные.
  - Дев-смысл:
    - клиенту важно различать “ещё не видно” vs “в мемпуле” vs “замайнено”;
    - mined метаданные (height, block hash, timestamp) нужны не всегда и не должны засорять ответ, если tx не в цепи.

- **Что взять из Tari и почему полезно (+ tradeoffs)**:
  - Что взять:
    - `TxLocation` как closed enum со стабильной семантикой;
    - mined metadata строго `Option<...>` (не sentinel-значения вроде 0/empty string);
    - правило совместимости: старые клиенты должны безопасно обрабатывать неизвестные варианты (`Unknown`).
  - Почему полезно:
    - меньше ошибок интерпретации на клиенте;
    - стабильное поведение автоматики (например, retry/backoff в broadcast);
    - проще UI: “pending → mined” основан на enum, а не на наборе разрозненных полей.
  - Tradeoffs:
    - нужно аккуратно задать “unknown”/“not_found” семантику, чтобы не путать с “reorg”; 
    - версионирование wire-format обязательно при расширении.
  - **REVIEW** ✅ Отдельная явная семантика для `Unknown`/`Rejected` полезна: иначе клиенты начнут угадывать по отсутствующим полям.

- **Как реализовать в Z00Z**:
  - RPC types:
    - добавить `TxLocation` и `TxQueryResponse` в общие типы RPC.
  - Политика optional:
    - если `location != Mined`, то `mined: None`.
  - Code-shape:
    ```rust
    pub enum TxLocation {
        Unknown,
        Mempool,
        Mined,
        Rejected,
    }
    
    pub struct MinedTxMeta {
        pub height: u64,
        pub block_hash: [u8; 32],
    }
    
    pub struct TxQueryResponse {
        pub location: TxLocation,
        pub mined: Option<MinedTxMeta>,
    }
    ```

---

## z00z_crypto/tari/common_types/src/wallet_types.rs

### `WalletType` / `ProvidedKeysWallet` / `LedgerWallet`

- **В чём идея**: тип кошелька — это не “косметика”, а capability-модель: какие ключи доступны локально и какие операции разрешены.
  - Дев-смысл:
    - для seed-based кошелька можно derivation/sign делать локально;
    - для `ProvidedKeysWallet` часть ключей может быть импортирована/ограничена;
    - для `LedgerWallet` подпись/derivation может требовать внешнего устройства и интерактива.
  - Это влияет на API: `sign_message`, `spend_output`, `derive_key` должны быть gated.
  - **REVIEW** ✅ Согласуется с вашим более ранним разделом про `WalletType`+gating. Главное — хранить именно тип (persisted), а capability выводить из него.
  - **REVIEW** ⚠️ Ledger/ProvidedKeys — это сильно усложняет UX и тест-матрицу. Если Z00Z не планирует такие режимы в ближайшем релизе, лучше пометить как “future” и не тащить требования в MVP.
  - **REVIEW** ❌ С учётом текущего скоупа (“в Z00Z нет Ledger HW”), разделы про `LedgerWallet` должны рассматриваться только как справка/возможное будущее, а не как обязательные требования.

- **Что взять из Tari и почему полезно (+ tradeoffs)**:
  - Что взять:
    - `WalletType` как persisted field (не вычислять “по косвенным признакам”);
    - явные capability checks в точках входа (до выполнения операции);
    - отдельные типы/ветки для ledger flow, чтобы не смешивать с обычным seed flow.
  - Почему полезно:
    - меньше опасных “тихо не подписали” или “подписали неправильным ключом”;
    - проще UX: можно показать “эта операция недоступна в Ledger режиме”;
    - проще тесты: matrix по wallet types.
  - Tradeoffs:
    - больше вариантов состояния → больше тестов;
    - миграции: смена wallet type должна быть строго контролируема (обычно запретить).

- **Как реализовать в Z00Z**:
  - Persistence:
    - хранить `WalletType` в `.wlt` meta рядом с `wallet_id` и KDF/encryption meta.
  - Gating:
    - на уровне `WalletService`:
      - `ensure_capability(Capability::SignMessage)` и т.п.
  - Code-shape:
    ```rust
    pub enum WalletType {
        SeedBased,
        ProvidedKeys,
        Ledger,
    }
    
    pub enum Capability {
        DeriveKeys,
        SignMessage,
        Spend,
    }
    ```

---

## z00z_crypto/tari/wallet/tests/wallet_integration_tests.rs

### module layout

- **В чём идея**: интеграционные тесты должны проверять границы сервисов кошелька (storage + protocol + events), но оставаться быстрыми и локальными.
  - Дев-смысл: вместо “поднимем целую сеть и будем ждать” мы строим тестовый harness:
    - детерминированные каналы,
    - in-memory/temporary DB,
    - контролируемые mock’и для внешних зависимостей.

- **Что взять из Tari и почему полезно (+ tradeoffs)**:
  - Что взять:
    - тесты “per service boundary”: tx service, output manager, broadcast protocol, scan state;
    - общий `tests/support` модуль для: конфигов, временных директорий, генераторов ключей, mock runtime.
  - Почему полезно:
    - быстрые регрессии и более стабильные CI;
    - легче покрыть edge cases (reorg/rescan) детерминированно.
  - Tradeoffs:
    - harness нужно поддерживать (иначе тесты начнут флакать);
    - иногда придётся добавлять тестовые хук’и/интерфейсы.
  - **REVIEW** ✅ Подход “harness вместо настоящей сети” — правильный: меньше flaky и быстрее CI.
  - **REVIEW** ⚠️ В Z00Z уже есть `z00z_simulator` и много injected providers (time/rng/io). Стоит явно переиспользовать эти механизмы в тестах кошелька, иначе появится второй набор тестовых утилит.

- **Как реализовать в Z00Z**:
  - Структура:
    - сделать `z00z_wallets/tests/` + `z00z_wallets/tests/support/`.
  - Принцип:
    - все async тесты должны иметь bounded timeouts и контролируемый shutdown.

---

## z00z_crypto/tari/wallet/tests/support/transaction_service_mock.rs

### `make_transaction_service_mock` / `TransactionServiceMock::run`

- **В чём идея**: мок сервисов делается не через “магический” trait-mock, а через реальный handle/API, подключённый к детерминированному backend’у.
  - Дев-смысл:
    - тест вызывает реальный `TransactionServiceHandle::submit(...)` (или аналог),
    - а backend “притворяется сервисом”, фиксирует запросы и отдаёт предопределённые ответы.
  - Это позволяет тестировать wiring и протоколы ближе к бою.
  - **REVIEW** ✅ Это хороший практичный паттерн для async-сервисов: тестируете handle/protocol, а не детали реализации.

- **Что взять из Tari и почему полезно (+ tradeoffs)**:
  - Что взять:
    - mock через channels:
      - requests channel,
      - responses channel,
      - shutdown signal;
    - request log для assert’ов;
    - явная `run()` петля, которую можно остановить.
  - Почему полезно:
    - меньше brittle тестов;
    - реалистичнее, чем мокать каждый метод;
    - проще внедрять новые сообщения/ветки.
  - Tradeoffs:
    - больше async wiring и типов сообщений;
    - нужно внимательно проектировать bounded очереди, чтобы тесты не зависали.
  - **REVIEW** ⚠️ Обязательно ставить bounded capacity + таймауты ожиданий во всех тест-хелперах, иначе CI будет зависать на редких гонках.

- **Как реализовать в Z00Z**:
  - `support::TransactionServiceMock`:
    - создаёт handle, который пишет в `mpsc::Sender<Request>`;
    - `run()` читает `Receiver<Request>` и отвечает.
  - Логи:
    - shared `Arc<Mutex<Vec<Request>>>` (или `tokio::sync::Mutex`).

### `TransactionServiceMockState`

- **В чём идея**: состояние мока — это простой журнал вызовов + несколько counters, который удобно проверять в тесте.
  - Дев-смысл: вместо ожидания “сработает ли callback” мы проверяем факты:
    - какие сообщения пришли,
    - в каком порядке,
    - сколько раз.

- **Что взять из Tari и почему полезно (+ tradeoffs)**:
  - Что взять:
    - helper API: `take_all()`, `count()`, `last()`, `wait_for_count(n, timeout)`;
    - аккуратная синхронизация (не держать lock долго, избегать deadlock).
  - Почему полезно:
    - меньше flaky тестов;
    - проще диагностика, если тест упал (видно журнал).
  - Tradeoffs:
    - state нужно проектировать как тестовую утилиту, не как часть production кода.
  - **REVIEW** ✅ Важно явно держать это в `tests/support`, чтобы тестовая диагностика не протекла в прод-API.

- **Как реализовать в Z00Z**:
  - В `tests/support`:
    - `TransactionServiceMockState` хранит `Vec<Request>` + методы чтения/очистки.

---

## z00z_crypto/tari/tari_console_wallet/src/ui/components/transactions_tab.rs

### `TransactionsTab::{draw_transaction_lists,draw_detailed_transaction}`

- **В чём идея**: UI транзакций должен масштабироваться на большие истории: список (виртуализированный/окончатый) + панель деталей.
  - Дев-смысл:
    - не пересоздавать тяжёлые view-model на каждый frame;
    - отделить “деривацию данных” (sorting/grouping/status mapping) от “рендера”.
  - **REVIEW** ✅ Это правильная архитектура для egui: immutable view-model + render снижает лаги на больших кошельках.
  - **REVIEW** ⚠️ Не стоит тащить сложные фильтры/режимы без необходимости: MVP — стабильный selection + windowing/paging.

- **Что взять из Tari и почему полезно (+ tradeoffs)**:
  - Что взять:
    - windowed lists/пэйджинг для больших списков;
    - стабильный selection state;
    - детальная панель, которая показывает поля из snapshot’а, а не ходит в сервисы в render loop.
  - Почему полезно:
    - производительность UI стабильна на больших кошельках;
    - меньше UI багов (selection не “прыгает”).
  - Tradeoffs:
    - больше UI state (scroll, selection, mode);
    - нужно аккуратно синхронизировать обновления списка и выбранного элемента.

- **Как реализовать в Z00Z**:
  - UI архитектура:
    - `derive_view_model(snapshot)` → immutable структуры для рисования;
    - `render(view_model, ui_state)`.
  - Хранить:
    - `selected_tx_id`, `scroll_offset`, `filter_mode`.

### `search_by_payref` + key handling

- **В чём идея**: поиск по `payref` — это отдельный UI sub-mode с собственным вводом, ошибками и подтверждением.
  - Дев-смысл:
    - ввод должен быть строго валиден (формат/длина/алфавит), иначе UX и безопасность страдают;
    - переходы должны быть детерминированны (Esc/Enter/Backspace и т.д.).

- **Что взять из Tari и почему полезно (+ tradeoffs)**:
  - Что взять:
    - явную state machine: `Normal` → `Search` → `ShowingResult`;
    - строгую валидацию/нормализацию `payref` на границе;
    - понятные сообщения об ошибке и подсказки формата.
  - Почему полезно:
    - меньше “магических” UI багов;
    - меньше случаев “приняли некорректный идентификатор”.
  - Tradeoffs:
    - чуть больше кода UI состояния;
    - нужно тестировать горячие клавиши/переходы.
  - **REVIEW** ✅ Явная state machine для UI ввода — хороший способ убрать “магические” клавиатурные баги.
  - **REVIEW** ⚠️ Парсинг/валидация `PayRef` должны быть едиными для UI/RPC (общий тип/парсер в core), иначе появятся расхождения “UI принял, RPC отверг”.

- **Как реализовать в Z00Z**:
  - Вынести parsing `PayRef` в core (`z00z_crypto`/`z00z_wallets`) и вызывать его из UI.
  - UI хранит:
    - `payref_input: String`, `payref_parse_error: Option<String>`.

---

## Z00Z pitfalls/issues (action items)

### `z00z_crypto/src/aead_envelope.rs::build_aad` (NUL delimiter ambiguity)

- **В чём идея**: AAD (associated authenticated data) — часть аутентификации AEAD. Если собирать AAD простым `join("\0")`, можно получить неоднозначности при наличии NUL или “склейки” полей.
  - Дев-смысл: AAD должен быть однозначно декодируемым, иначе появляются:
    - редкие, но опасные коллизии контекста,
    - сложности с миграциями формата.

- **Что взять из Tari и почему полезно (+ tradeoffs)**:
  - Что взять:
    - length-prefix encoding для доменов/частей AAD (или CBOR/SSZ-подобный формат);
    - version tag как часть AAD (чтобы при миграции не было “случайно подошло”).
  - Почему полезно:
    - снижает риск “перепутали контекст расшифровки”;
    - облегчает безопасные миграции.
  - Tradeoffs:
    - любое изменение AAD формата ломает старые ciphertext → нужна версия и миграционный путь.
  - **REVIEW** ✅ Отличный конкретный pitfall: AAD должен быть однозначным, иначе появляются редкие, но опасные коллизии контекста.
  - **REVIEW** ⚠️ “Запретить NUL” — это только частичная мера. Долгосрочно правильнее length-prefix/каноническая бинарная схема (как вы пишете ниже), даже если это чуть больше кода.

- **Как реализовать в Z00Z**:
  - Простой вариант:
    - запретить NUL в variable-length domain strings.
  - Лучший вариант:
    - `aad = version || len(part1)||part1 || len(part2)||part2 ...`.

### `z00z_crypto/src/cipher_seed.rs::Z00ZCipherSeed::decrypt` (checksum oracle)

- **В чём идея**: если различать ошибки “не тот пароль” и “не сошлась checksum/формат”, вы создаёте oracle, который помогает атакующему.
  - Дев-смысл:
    - любые проверки целостности должны быть защищены AEAD/MAC;
    - сравнения должны быть constant-time там, где это влияет на side-channel;
    - ошибки должны быть нормализованы.

- **Что взять из Tari и почему полезно (+ tradeoffs)**:
  - Что взять:
    - integrity внутри AEAD (payload включает checksum/структуру) или в AAD;
    - нормализация ошибок:
      - наружу: `InvalidPasswordOrSeed` (или аналог),
      - внутрь логов: более детально, но без утечки наружу.
  - Почему полезно:
    - снижает риск атак на seed container;
    - улучшает безопасность UX: одинаковое поведение для плохих входов.
  - Tradeoffs:
    - изменение контейнера требует версионирования и миграций;
    - сложнее диагностика без внутренних логов/trace.
  - **REVIEW** ✅ Корректно: различимые ошибки (и/или разные тайминги) действительно могут стать oracle.
  - **REVIEW** ⚠️ Нормализация должна учитывать не только текст ошибок, но и порядок проверок/тайминги: не делать “checksum до AEAD”, не ветвиться так, чтобы это было измеримо снаружи.

- **Как реализовать в Z00Z**:
  - Формат:
    - переместить checksum внутрь AEAD plaintext;
    - добавить `format_version` и включить его в AAD.
  - Ошибки:
    - наружу возвращать один error variant; детали — только в trace.

---

