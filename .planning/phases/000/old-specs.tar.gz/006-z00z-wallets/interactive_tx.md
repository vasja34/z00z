# Tari Interactive (Two-sided) Transactions: Network/Message Handlers (Upstream Check)

Date: 2026-01-08

This note answers: **where are the concrete network/message handlers for interactive (two-sided) transactions in Tari**, and what remains in the code you currently vendor at:

- `/home/vadim/Projects/z00z/crates/z00z_crypto/tari` (vendored snapshot)

If not found there, we also searched the provided checkouts:

- `/home/vadim/Projects/z00z/.temp/tari-development`
- `/home/vadim/Projects/z00z/.temp/tari-wallet`
- `/home/vadim/Projects/z00z/.temp/minotari-cli-main`

## TL;DR

- **Vendored Tari snapshot is effectively “one-sided only”.**
- **Interactive (two-sided) transaction protocol types exist** (`legacy_transaction_protocol/*`), but **there are no live network/message handlers wiring them to comms**.
- gRPC `.proto` documentation still claims `Transfer` supports interactive MW, but the **gRPC server rejects `STANDARD_MIMBLEWIMBLE` and routes everything through one-sided send**.
- The closest “handler spec” available in these repos is **commented-out test code** showing the historical message flow using `tari_comms::message::EnvelopeBody` + protobuf “parts”.

## Code anchors (vendored snapshot: `/crates/z00z_crypto/tari`)

### gRPC surface says “interactive supported”

- `app_grpc/proto/wallet.proto`:
  - `Wallet.Transfer(...)` comment: “supports standard interactive transactions (Mimblewimble)” (around `#L575`)
  - `PaymentType.STANDARD_MIMBLEWIMBLE` enum value (around `#L1890-L1892`)

### gRPC implementation rejects interactive

- `tari_console_wallet/src/grpc/wallet_grpc_server.rs`:
  - `transfer(...)` rejects `PaymentType::StandardMimblewimble` (around `#L1094-L1100`)
  - on success paths, it calls only:
    - `send_one_sided_transaction(...)` (around `#L1130-L1138`)
    - `send_one_sided_to_stealth_address_transaction(...)` (around `#L1140-L1148`)
  - `transfer_single_tx(...)` always uses `send_one_sided_multi_recipient_transaction(...)` (around `#L230-L245`)

### Interactive protocol artifacts (state machines + messages)

- `wallet/src/legacy_transaction_protocol/sender.rs`:
  - `SingleRoundSenderData` (around `#L104`)
  - `TransactionSenderMessage` enum (around `#L138`)
  - `SenderTransactionProtocol` (around `#L159`)
- `wallet/src/legacy_transaction_protocol/recipient.rs`:
  - `RecipientSignedMessage` (around `#L56`)
  - `ReceiverTransactionProtocol` (around `#L68`)

### Envelope container used by historical comms

- `comms/core/src/message/envelope.rs`:
  - `EnvelopeBody::decode_part<T>(index)` (around `#L88`)

### Historical interactive flow (commented-out test)

- `wallet/tests/transaction_service_tests/service.rs`:
  - shows intended interactive flow:
    - sender calls `transaction_service_handle.send_transaction(...)` using an interactive-only address
    - outbound message body is decoded as `EnvelopeBody`
    - protobuf payload in `EnvelopeBody` part index `1` decoded as:
      - `proto::TransactionSenderMessage` (sender → receiver)
      - `proto::RecipientSignedMessage` (receiver → sender)
  - this block starts around `#L1480` and runs through roughly `#L1610`.

## What’s missing (the actual ask: “network/message handlers”)

Within the vendored snapshot, we did not find any of the following “live” integration points:

- a transaction-service protocol module that:
  - constructs `TransactionSenderMessage` from `SenderTransactionProtocol`
  - sends it over comms / DHT / RPC to the recipient
  - receives a `RecipientSignedMessage` reply
  - advances `SenderTransactionProtocol` to finalized transaction
- protobuf `.proto` definitions for `TransactionSenderMessage` / `RecipientSignedMessage` (as real, generated types)
- inbound/outbound comms handlers/channels specifically for:
  - “transaction send message” (sender→receiver)
  - “transaction ack/signed message” (receiver→sender)

In other words: **the types exist, but the runtime “wire” is not present.**

## Upstream check: provided `.temp/*` repos

We repeated the same searches in:

- `/home/vadim/Projects/z00z/.temp/tari-development`
- `/home/vadim/Projects/z00z/.temp/tari-wallet`
- `/home/vadim/Projects/z00z/.temp/minotari-cli-main`

Result:

- `tari-development` contains the same gRPC schema + the same console wallet behavior (rejecting `StandardMimblewimble`), and also does not include a send/receive interactive transaction protocol module.
- `tari-wallet` (standalone wallet project) and `minotari-cli-main` also did not contain interactive send/receive handlers by the names or message types referenced by the legacy protocol.

## Practical takeaway for Z00Z

If Z00Z needs real two-sided interactive transactions, the options are:

1. **Design a Z00Z-owned interactive exchange protocol** over your chosen transport, and reuse Tari crypto primitives for commitments/proofs/signatures.
2. **Locate and vendor an older Tari revision** that still includes the interactive wallet-to-wallet comms pipeline (handlers + message protobufs), then encapsulate/port it.

Given the evidence in these snapshots (`STANDARD_MIMBLEWIMBLE` deprecated + actively rejected in the gRPC server), Tari appears to have moved toward **one-sided-to-(stealth)-address** sends as the supported wallet UX for payments.
