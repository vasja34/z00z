# Tari Transactions + Keys: Source-Level Summary (for Z00Z migration)

This document is a running, append-only scratchpad built from recursively inspecting:
- `crates/z00z_wallets/tari-cli/`
- `crates/z00z_wallets/tari_console_wallet/`
- `crates/z00z_wallets/tari-wallet/`
- `crates/z00z_crypto/tari/` (read-only vendor)

Goal: provide an end-to-end, source-linked understanding of how Tari wallets:
- construct transactions (selection → fees → proofs → signatures → finalization → broadcast)
- manage keys (seed/derivation → key manager → per-output keys/nonces → signing)

Rules:
- Every finding is recorded immediately with file/line links.
- Prefer following real call chains over isolated snippets.

---

## Glossary + naming (tiny)

Tari terms used in this doc:
- **UTXO / output**: a spendable coin/output entry (unspent output model).
- **Kernel**: transaction kernel carrying aggregated signature/fee/lock_height.
- **Script / covenant**: spending program and additional constraints carried by an output.
- ==**One-sided / stealth**==: sender can create an output spendable by the receiver without an interactive negotiation round.
- ==DUAL-sided ??==

Z00Z naming conventions used in “Z00Z Implementation”:
- **Asset**: a Z00Z spendable asset (analog of a Tari UTXO/output).
- Use **trait names** (`AssetSelector`, `FeeEstimator`, `TxAssembler`, `Signer`, `Prover`, `LocalVerifier`) to describe responsibilities; concrete implementations may vary.
- **Consensus tx semantics** live in `z00z_core::tx`; **wallet protocol artifacts** live in `z00z_wallets`; **crypto primitives/backends** live behind `z00z_crypto`.
- **Definition of Done: DoD**

---

## MUST reuse from Tari via `z00z_crypto` (checklist)

This checklist applies to **all Findings** in this document.

Crypto + math correctness (do not re-implement):
- **Key agreement / DH / stealth derivations** (any “shared secret”, stealth address keying, encrypted recovery keying) must be performed via Tari primitives behind `z00z_crypto`.
- **Commitments + range proofs** (commitment construction, rangeproof factories/sizes, proof verification) must reuse Tari implementations via `z00z_crypto`.
- **Signature primitives** (kernel signatures, metadata signatures, partial signatures, nonce/offset math, aggregation rules) must reuse Tari implementations via `z00z_crypto`.
- **Hashing / domain separation** for cryptographic identifiers must use the established Z00Z domain-hash utilities that wrap the Tari backend (`z00z_crypto`), not ad-hoc hashing.
- **Fee/weight math rules that affect consensus validity** (e.g. per-output rounding boundaries, integer-division pitfalls) must be treated as canonical and implemented once using Tari’s validated logic (exposed through `z00z_crypto`/`z00z_core`).

Secrets handling (reuse patterns, keep boundaries strict):
- **Secret material at rest** must be encrypted using the established AEAD patterns (e.g. XChaCha20Poly1305) and held in `z00z_crypto::Hidden` (or equivalent) when in-memory.
- **Never** log/`Debug` secrets or embed backend-specific secret encodings into wallet-owned protocol artifacts.

Encoding / wire constraints (reuse constraints, don’t guess):
- Any **canonical transaction encoding** used for size checks / network broadcast must be stable and versioned; prefer to reuse Tari’s encoding choices where interoperability or correctness depends on it, but keep the choice surfaced behind `z00z_utils::codec` + `z00z_networks_rpc` frame limits.
- **Tx-too-large** guard must be enforced at the broadcast boundary using the transport max-frame minus a margin; the size computation must follow the chosen canonical serialization (not “estimated bytes”).

What you MAY port vs MUST NOT port:
- You MAY port **control-flow, orchestration, storage workflows, and trait boundaries** into `z00z_wallets`/`z00z_core`.
- You MUST NOT port/copy Tari structs/enums as Z00Z public types; treat Tari vendor code under `crates/z00z_crypto/tari/` as read-only and access it only through `z00z_crypto`.


---

## Global Checklist Conventions (applies to all Findings)

This section exists to remove ambiguity introduced by the per-Finding implementation checklists.

Canonical IDs (define once; use everywhere):
- **TxIntentId**: created at the start of a wallet send/build pipeline *before* any locks; used to bind locks, drafts, and signing requests.
- **SigningRequestId**: stable identifier for a stored/exported signing request (it MAY equal `TxIntentId`, but the relationship must be explicit and stable).
- **TxId**: identifier for a finalized, broadcastable transaction; derived deterministically from canonical finalized transaction bytes (domain-separated).

Canonical storage lifecycle (baseline names; harmonize with existing `TxStorage`):
- **Draft** → **SigningRequested** → **Signed** → **BroadcastQueued** → **Broadcasting** → **Broadcasted** → **Confirmed** (terminal)
- Terminal alternatives: **Cancelled** (user/system) or **Failed** (non-retryable error)

Canonical export artifacts and codec requirements:
- Any exported/stored artifact that participates in signing MUST include:
	- `schema_version`
	- `codec_id` (e.g. `json-v1`, `bincode-v1`)
	- explicit hash domains for any hashes inside the transcript
- “Canonical transcript bytes” are wallet-protocol stability boundaries (wallet-local, but MUST be stable across releases that must interoperate with offline signing).
- “Must-preserve fields”: the exact set of fields included in the signature message(s) must be listed and treated as a compatibility contract.

Canonical test categories expected from checklist items:
- Determinism (fixed inputs → fixed outputs under test providers)
- Round-trip encoding/decoding (schema + codec)
- State recovery (restart/resume semantics)
- Tamper/invalid-input rejection (fails safely and explicitly)
- Secret non-serialization (type-level prevention + serialization-level checks)

Canonical locations (to prevent drift; create these modules if they do not exist yet):
- IDs: `z00z_wallets::core::tx::ids::{TxIntentId, SigningRequestId, TxId}`
- Export artifacts: `z00z_wallets::core::tx::exports::{SigningRequestV*, SigningTranscriptV*}`
- Key refs: `z00z_wallets::core::key::refs::{KeyRef, KeyPurpose}`
- Storage lifecycle state: `z00z_wallets::core::storage::tx_state::{TxLifecycleState, BroadcastState}`



---

## Finding 1: One-sided transaction (CLI) creates an unsigned/offline-signing request

Where:
- z00z_wallets/tari-cli/src/transactions/one_sided_transaction.rs

Key flow:
- `OneSidedTransaction::create_unsigned_transaction` selects Assets, builds a `TransactionBuilder`, then uses `OfflineSigner::prepare_one_sided_transaction_for_signing` to produce a `PrepareOneSidedTransactionForSigningResult`.
- The unsigned request is stored in SQLite as JSON along with an expiry timestamp, and the selected Assetss are locked until expiry.

Notes:
- Current implementation supports exactly 1 recipient (hard check).
- `fee_per_gram` is set to a constant `MicroMinotari(5)` in this flow.

Code anchors:
- TransactionBuilder setup and inputs: z00z_wallets/tari-cli/src/transactions/one_sided_transaction.rs#L52-L91
- Offline signing request creation: z00z_wallets/tari-cli/src/transactions/one_sided_transaction.rs#L93-L116
- Pending-tx persistence + output locking: z00z_wallets/tari-cli/src/transactions/one_sided_transaction.rs#L118-L154

### Z00Z Implementation

What to reuse (idea-level):
- **Two-phase spend pipeline**: build a tx skeleton + lock inputs, then finalize signatures later (offline/HSM/airgap).
- **Exportable signing request**: a stable, versioned blob/struct that can be signed outside the main process.

How to map into existing Z00Z code:
- Use the existing spending pipeline traits in `z00z_wallets::core::tx`:
	- `TxAssembler` builds the skeleton + collects all “needs signing” material.
	- `Signer` finalizes signatures (online or offline).
	- `FeeEstimator` provides deterministic fee inputs (no hidden global constants).
- Persist pending signing requests in `z00z_wallets::core::storage::TxStorage` (not ad-hoc files), using `z00z_utils::codec`.
	- JSON for debuggability, bincode for compact export.
- Input locking/encumbrance should be a storage-layer policy behind `AssetStorage`/`TxStorage` traits.

How to avoid Tari-specific leakage:
- Do not port Tari’s `TransactionBuilder` or Tari key-branch enums into Z00Z.
- Keep crypto primitives behind `z00z_crypto`, but keep *wallet protocol artifacts* (signing request formats) in `z00z_wallets`.

#### Implementation Checklist (Finding 1)

**DoD:** `OneSidedSigningRequestV1` is persisted/exportable, prepare+finalize flows exist, lock expiry works, and round-trip/expiry/failure-unlock tests pass.

- [ ] Define a versioned `OneSidedSigningRequestV1` wallet protocol type in `z00z_wallets` (explicit `version`, `created_at`, `expires_at`, `network`, `tx_intent_id`).
- [ ] Specify the request payload to contain only:
	- [ ] public recipient information (address/public keys)
	- [ ] explicit amounts/asset ids
	- [ ] export-safe `KeyRef` identifiers (no backend key ids)
	- [ ] canonical “needs-signing” transcript bytes (or an equivalent structured transcript)
- [ ] Implement `TxAssembler` to build a skeleton + signing transcript without doing I/O:
	- [ ] accept selected inputs as parameters
	- [ ] emit a deterministic “unsigned tx draft” + “signing transcript”
	- [ ] do not allocate random ids inside `TxAssembler` (use injected `RngProvider` / `TxIdFactory` if needed)
- [ ] Implement input locking behind `AssetStorage` / `TxStorage`:
	- [ ] lock selected inputs atomically with persisting the request
	- [ ] record lock expiry and the lock reason (`TxIntentId`)
	- [ ] implement `unlock_expired_locks(now)` using `TimeProvider`
- [ ] Implement `WalletService::tx_prepare_one_sided_send(...)` end-to-end:
	- [ ] validate parameters (recipient format, amount > 0, asset exists)
	- [ ] call `AssetSelector` + `FeeEstimator`
	- [ ] call `TxAssembler` and persist request + locks
	- [ ] return a stable request id and export blob
- [ ] Implement `WalletService::tx_finalize_one_sided_send(request, signature_bundle)`:
	- [ ] re-load the request from storage and verify `version` and `expires_at`
	- [ ] call `Signer` to finalize signatures (online or offline)
	- [ ] call `LocalVerifier` and only then transition request → “finalized tx”
	- [ ] ensure locks are either transitioned to “spent by tx_id” or released on failure
- [ ] Enforce “no hidden constants” for fees:
	- [ ] take `fee_policy` from injected config, not hard-coded values
	- [ ] persist the fee parameters inside the request to make offline signing deterministic
- [ ] Encode/decode requirements:
	- [ ] JSON and compact encoding round-trip via `z00z_utils::codec`
	- [ ] include explicit schema versioning; reject unknown versions
- [ ] Security invariants:
	- [ ] the exported request type is structurally unable to contain secrets (no `Hidden<T>`/secret-key fields; no secret serialization derives)
	- [ ] add a serialization test that asserts encoded exports contain no secret markers and that secret wrappers cannot be serialized via this type graph
	- [ ] sensitive fields use `z00z_crypto::Hidden` while in memory
- [ ] Tests (must be deterministic):
	- [ ] request encoding round-trip test
	- [ ] expiry unlock test using `MockTimeProvider`
	- [ ] “locks released on finalize failure” test

---

## Finding 2: tari-cli key handling and TransactionKeyManager construction

Where:
- z00z_wallets/tari-cli/src/db/accounts.rs

Key flow:
- `AccountRow::decrypt_keys` decrypts stored key material using `XChaCha20Poly1305` keyed by a password-derived 32-byte key.
- `AccountRow::get_address` derives a one-sided-only dual Tari address from a decrypted view secret key and a stored compressed spend public key.
- `AccountRow::get_key_manager` creates a `TransactionKeyManagerWrapper<MemoryKeyManagerBackend>` using:
	- a fresh `CipherSeed::new()`
	- a `WalletType::ProvidedKeys(ProvidedKeysWallet { view_key, public_spend_key, birthday, ... })`
	- `CryptoFactories::default()`

Implication for migration:
- This CLI path is not using a persistent key-manager backend (it uses `MemoryKeyManagerBackend`). It appears intended for offline signing / ephemeral use rather than a full wallet DB-backed key manager.

Code anchors:
- `get_address`: z00z_wallets/tari-cli/src/db/accounts.rs#L167-L180
- `get_key_manager`: z00z_wallets/tari-cli/src/db/accounts.rs#L182-L200

### Z00Z Implementation

What to reuse (idea-level):
- **Secret material lifecycle**: encrypted at rest → decrypted only after unlock → fed into an in-memory key manager.
- **Clear boundary** between password/KDF, AEAD, and key derivation.

How to map into existing Z00Z code:
- Treat `z00z_wallets::core::storage::SecretStore` as the single place that knows:
	- how wallet secrets are encrypted/decrypted
	- how unlock sessions are validated
- Keep `z00z_wallets::core::key::KeyManager` focused on derivation and signing material, initialized from `SecretStore`.
- Continue using `z00z_crypto::Hidden` for secrets and avoid `Debug`/logging paths.

What to *not* carry into Z00Z:
- Tari’s “ProvidedKeysWallet + CipherSeed::new()” shape (that’s a Tari wallet recovery/compat concept).
- Any Tari address feature flags directly; keep address capabilities as Z00Z-owned types behind `AddressManager`.

#### Implementation Checklist (Finding 2)

**DoD:** `SecretStore` unlock sessions + AEAD-at-rest work end-to-end, KeyManager initializes from unlocked secrets, and wrong-password/no-secret-leak tests pass.

- [ ] Define `SecretStore` as the only component that handles:
	- [ ] password/KDF verification (KDF parameters are persisted and versioned)
	- [ ] AEAD encryption/decryption of wallet secrets at rest
	- [ ] unlock session creation + expiry + lockout policy
- [ ] Ensure business logic never uses `serde_json::*`, `rand::thread_rng()`, or `SystemTime::now()` directly (use `z00z_utils` providers).
- [ ] Implement a `KeyManager::from_unlocked_secrets(...)` constructor/factory:
	- [ ] takes `Hidden<MasterSecret>` (or equivalent)
	- [ ] derives view/spend keys deterministically using domain-separated derivation
	- [ ] exposes only public keys via safe getters
- [ ] Implement `AddressManager` with Z00Z-owned address capabilities:
	- [ ] compute addresses from public keys and network parameters
	- [ ] do not embed Tari feature flags into Z00Z public types
- [ ] Define zeroization rules:
	- [ ] decrypted secrets must be held in `Hidden<T>` and zeroized on drop
	- [ ] unlock sessions must not leak secrets via logs/errors
- [ ] Add tests:
	- [ ] wrong-password rejects without side-effects
	- [ ] unlocking yields stable derived public keys
	- [ ] `Debug`/log output never contains secret bytes

---

## Finding 3: Vendor TransactionBuilder derives address + allocates protocol nonces/keys

Where:
- z00z_crypto/tari/transaction_components/src/transaction_builder/builder.rs

Key flow:
- `TransactionBuilder::new(consensus_constants, key_manager, network)` fetches:
	- `key_manager.get_view_key()`
	- `key_manager.get_spend_key()`
	Then constructs the wallet’s `own_address` (dual address) with one-sided-only features.

Key allocation patterns inside builder:
- `add_recipient(...)` allocates a kernel nonce via `TransactionKeyManagerBranch::KernelNonce` and stores the nonce key-id in the output pair (this matters for later signature protocol steps).
- `add_stealth_recipient(...)` is a core one-sided path:
	- allocates a sender-offset key via `TransactionKeyManagerBranch::OneSidedSenderOffset`
	- constructs DH-based key-ids (`TariKeyId::DHCommitmentMask`, `TariKeyId::DHEncryptedData`) bound to destination view key
	- derives the “script spending key” for the stealth address output
	- builds a `WalletOutput` with encrypted recovery data and signatures

Code anchors:
- `TransactionBuilder::new`: z00z_crypto/tari/transaction_components/src/transaction_builder/builder.rs#L56-L94
- `add_recipient`: z00z_crypto/tari/transaction_components/src/transaction_builder/builder.rs#L150-L182
- `add_stealth_recipient` (one-sided key-id/DH path): z00z_crypto/tari/transaction_components/src/transaction_builder/builder.rs#L184-L220

### Z00Z Implementation

What to reuse (idea-level):
- **Purpose-separated key allocation** (nonce vs offset vs recovery) and domain separation to prevent key reuse.
- **One-sided/stealth output building** as a first-class wallet primitive.

How to map into existing Z00Z code:
- Keep transaction assembly behind `z00z_wallets::core::tx::TxAssembler` and keep key allocation behind `z00z_wallets::core::key::KeyManager`.
- Model “key purposes” using Z00Z domains/paths (you already have `z00z_wallets::core::key::domains::*` + `Bip44Path`).
	- Add additional Z00Z-purpose domains (e.g. nonce/offset) as Z00Z names, not Tari branch strings.
- Use `z00z_crypto::hash_domain!` + `DomainHasher` for domain-separated derivation and identifiers.

What to avoid importing:
- Tari key-branch string compatibility rules (they are a Tari wallet recovery boundary).
- Tari “dual address” semantics unless Z00Z explicitly defines the same capability.

#### Implementation Checklist (Finding 3)

**DoD:** Z00Z key-purpose domains + KeyManager APIs cover nonce/offset/DH needs and determinism/purpose-separation tests pass.

- [ ] Extend Z00Z key-derivation “purpose” domains (Z00Z names, versioned):
	- [ ] kernel nonce
	- [ ] sender offset
	- [ ] one-sided sender offset
	- [ ] output commitment mask / blinding
	- [ ] encrypted recovery data key
- [ ] Add `KeyManager` API surface (wallet-facing) for:
	- [ ] `derive_nonce(purpose, index)` / `next_nonce(purpose)`
	- [ ] `derive_offset(purpose, index)` / `next_offset(purpose)`
	- [ ] `derive_shared_secret(peer_pubkey, purpose)` (implemented via `z00z_crypto`)
- [ ] Implement one-sided/stealth output construction as an explicit wallet primitive:
	- [ ] define Z00Z `OutputIntent` fields for memo/recovery payload and spend conditions
	- [ ] ensure encrypted recovery data is produced via `z00z_crypto` (no home-grown crypto)
	- [ ] ensure metadata signatures are produced via `z00z_crypto` primitives
- [ ] Ensure domain separation is enforced everywhere:
	- [ ] any derived identifier uses `hash_domain!` with explicit environment + version
	- [ ] add a test that two different purposes never produce equal derived keys
- [ ] Add tests:
	- [ ] “same seed, same output intent” determinism in test mode
	- [ ] “different purpose, different derived key” property-based test

---

## Finding 4: OfflineSigner prepares an exportable “request to sign” for one-sided sends

Where:
- z00z_crypto/tari/transaction_components/src/offline_signing/offline_signer.rs

Key flow:
- `OfflineSigner::prepare_one_sided_transaction_for_signing(...)` takes a partially prepared `TransactionBuilder` and finalizes recipient output construction (which fixes output sizing inputs used by fee estimation) by calling `tx_builder.add_stealth_recipient(...)`.
- It then “marshals” inputs/outputs/change outputs into `MarshalOutputPair` structures, after rewriting `script_key_id` into an export-safe form via `make_key_id_export_safe(...)`.
- Returns `PrepareOneSidedTransactionForSigningResult { version, tx_id, info: OneSidedTransactionInfo { ... } }`.

Why this matters:
- Tari separates “construct transaction skeleton + outputs” from “produce final signatures” by exporting a signing request that can be signed elsewhere (offline device / HSM / airgap).

Code anchors:
- Function body: z00z_crypto/tari/transaction_components/src/offline_signing/offline_signer.rs#L56-L138

### Z00Z Implementation

What to reuse (idea-level):
- A **versioned** “request to sign” format that rewrites internal key references into portable identifiers.

How to map into existing Z00Z code:
- Place the export format in `z00z_wallets::core::tx` (wallet protocol artifact), not in `z00z_crypto`.
- Use `z00z_utils::codec` for stable encoding choices (JSON for tools + bincode for compact transport).
- Represent key references in the request using Z00Z-owned identifiers:
	- `Bip44Path` + a small enum for purpose (payment/spend/nonce/offset)
	- optional peer public key bytes when DH-like construction is required

Avoid Tari-specific coupling:
- Don’t carry Tari’s `TariKeyId` export-safe transformations into Z00Z; keep the request format backend-neutral.

#### Implementation Checklist (Finding 4)

**DoD:** `KeyRef` + signing-request schema is versioned, export-safe rewrite+rehydration work, and unknown-version/tamper tests pass.

- [ ] Define `KeyRef` (export-safe) with a closed set of variants:
	- [ ] `Bip44Path { purpose }`
	- [ ] `Derived { domain_label, version, index }`
	- [ ] `DhDerived { domain_label, version, peer_pubkey }`
- [ ] Define a versioned signing-request schema that is stable across releases:
	- [ ] include `schema_version`, `network`, `wallet_compat`, and `codec` fields
	- [ ] reject unknown schema versions at decode time
- [ ] Implement “export-safe rewrite” as a pure function:
	- [ ] converts internal key handles into `KeyRef` without looking at storage
	- [ ] never serializes backend-specific ids
- [ ] Implement “rehydration” for finalize/sign:
	- [ ] `KeyManager` resolves `KeyRef` → internal key handle using deterministic derivation
	- [ ] resolution is total: unknown variants error with a dedicated `KeyRefUnsupported`
- [ ] Add negative tests:
	- [ ] decoding a future/unknown schema version fails cleanly
	- [ ] tampered request (changed recipient pubkey) fails signature verification

---

## Finding 5: Console wallet entrypoints call TransactionService and OutputManager

Where:
- z00z_wallets/tari_console_wallet/src/automation/commands.rs

Key flow:
- `send_one_sided_to_stealth_address(...)` calls `TransactionServiceHandle::send_one_sided_to_stealth_address_transaction(...)` with:
	- `dest_address, amount, selection_criteria, OutputFeatures::default(), fee_per_gram, payment_id`
- `coin_split(...)` uses `OutputManagerHandle::create_coin_split(...)` to produce `(tx_id, tx, amount)`, then calls `TransactionServiceHandle::submit_transaction(...)`.

Code anchors:
- send one-sided: z00z_wallets/tari_console_wallet/src/automation/commands.rs#L304-L329
- coin split: z00z_wallets/tari_console_wallet/src/automation/commands.rs#L331-L352

### Z00Z Implementation

What to reuse (idea-level):
- Keep UX/CLI thin: it should call service-level use-cases, not reach into core internals.

How to map into existing Z00Z code:
- Treat `z00z_wallets::adapters::rpc` as an I/O boundary only.
- Implement wallet operations in `z00z_wallets::services::WalletService` by composing existing core traits:
	- `AssetSelector` → `FeeEstimator` → `TxAssembler` → `Signer` → `Prover` → `LocalVerifier` → broadcast.
- Put broadcast/monitoring transport concerns behind `z00z_networks_rpc::RpcTransport` (or a wallet-owned network trait that is implemented using `z00z_networks_rpc`).

#### Implementation Checklist (Finding 5)

**DoD:** Representative RPC methods satisfy R1–R3 via real dispatcher calls, and RPC contains no business logic beyond decode/validate/map.

- [ ] For every RPC method that triggers tx creation/broadcast:
	- [ ] enforce R2: handler must call `WalletService` (no early returns)
	- [ ] enforce R3: `WalletService` must reach a public `Z00ZWallet` core method
- [ ] Implement a single “service use-case” entry per operation:
	- [ ] `WalletService::tx_send_one_sided(...)`
	- [ ] `WalletService::tx_broadcast(...)`
	- [ ] `WalletService::tx_cancel(...)`
- [ ] Ensure the RPC layer owns only:
	- [ ] parameter decoding/validation
	- [ ] error mapping to RPC errors
	- [ ] no storage, no signing, no fee logic
- [ ] Add an integration test that calls representative RPC methods via the real dispatcher and asserts:
	- [ ] the method is registered (R1)
	- [ ] the service method was invoked
	- [ ] a core wallet method was reached

---

## Finding 6: TransactionServiceHandle method maps 1:1 to a TransactionServiceRequest

Where:
- z00z_crypto/tari/wallet/src/transaction_service/handle.rs

Key flow:
- The console wallet calls `TransactionServiceHandle::send_one_sided_to_stealth_address_transaction(...)`.
- The handle converts that into `TransactionServiceRequest::SendOneSidedToStealthAddressTransaction { ... }` and sends it over a `SenderService` channel.

Code anchors:
- Request enum variant: z00z_crypto/tari/wallet/src/transaction_service/handle.rs#L217-L235
- Handle method (request emission): z00z_crypto/tari/wallet/src/transaction_service/handle.rs#L1284-L1312

### Z00Z Implementation

What to reuse (idea-level):
- A **typed command surface** that decouples “what to do” from “how it runs” (useful for background protocols).

How to map into existing Z00Z code:
- For now, keep it simple: `WalletService` methods call core traits directly.
- When you introduce background workflows (broadcast loop, chain scan, retry policies), add a Z00Z-owned internal command enum at the *service boundary* (e.g. `WalletCommand`) and drive it with tokio tasks.

How to avoid Tari-specific leakage:
- Do not replicate Tari’s request enum 1:1. Define commands in terms of Z00Z use-cases and Z00Z core types.

#### Implementation Checklist (Finding 6)

**DoD:** The “commands vs direct calls” decision is explicit; if commands exist, the worker+persistence+restart tests pass.

- [ ] Decide and document whether Z00Z needs a background-command surface now:
	- [ ] If not needed: explicitly keep `WalletService` synchronous (direct calls) and record this decision.
	- [ ] If needed: implement a Z00Z-owned `WalletCommand` enum at the service boundary.
- [ ] If `WalletCommand` is introduced:
	- [ ] define per-command input structs (no `serde_json::Value` inside the service)
	- [ ] implement a bounded channel + worker task runner (tokio)
	- [ ] persist command state transitions in `TxStorage` for restart recovery
	- [ ] ensure idempotency keys exist for commands that can be retried
- [ ] Add tests:
	- [ ] command dispatch is deterministic and does not lose messages
	- [ ] restart recovery replays only non-terminal commands

---

## Finding 7: TransactionService routes the request to send_one_sided_to_stealth_address_transaction

Where:
- z00z_crypto/tari/wallet/src/transaction_service/service.rs

Key flow:
- In the main request dispatcher, `TransactionServiceRequest::SendOneSidedToStealthAddressTransaction { ... }` calls:
	- `self.send_one_sided_to_stealth_address_transaction(destination, amount, selection_criteria, *output_features, fee_per_gram, payment_id, ...)`

Code anchors:
- Dispatcher arm: z00z_crypto/tari/wallet/src/transaction_service/service.rs#L880-L910

### Z00Z Implementation

What to reuse (idea-level):
- A single “dispatcher” spot that routes high-level wallet use-cases to concrete implementation functions.

How to map into existing Z00Z code:
- In Z00Z, the equivalent routing layer is `z00z_wallets::services::WalletService` + the RPC adapter.
	- Keep routing decisions in the service (not in RPC types, not in crypto).
	- Keep the actual logic behind injected `Z00ZWallet` components (`core::tx`, `core::storage`, `core::key`).

Avoid Tari coupling:
- Don’t build a Tari-like mega request enum in the core.
- Prefer a small set of Z00Z use-cases (`tx.build`, `tx.sign`, `tx.broadcast`, `tx.cancel`) that compose internally.

#### Implementation Checklist (Finding 7)

**DoD:** `WalletService` is the single routing point and routing coverage checks ensure every RPC→service→core path is reachable.

- [ ] Ensure `WalletService` is the single routing/dispatch point:
	- [ ] RPC methods map 1:1 onto `WalletService` methods
	- [ ] `WalletService` maps onto core wallet methods (public API)
- [ ] Introduce explicit request/response DTOs at the service boundary:
	- [ ] no leaking of vendor/tari types
	- [ ] version fields if serialized across processes
- [ ] Add a “routing coverage” audit (or extend existing audits) that confirms:
	- [ ] every registered RPC method calls a service method
	- [ ] every service method reaches a core wallet entry

---

## Finding 8: One-sided-to-stealth is a thin wrapper over send_one_sided_or_stealth(..., use_stealth=true)

Where:
- z00z_crypto/tari/wallet/src/transaction_service/service.rs

Key flow:
- `send_one_sided_to_stealth_address_transaction(...)` delegates to:
	- `self.send_one_sided_or_stealth(..., use_stealth_one_sided = true, payment_id)`

Code anchors:
- Wrapper function: z00z_crypto/tari/wallet/src/transaction_service/service.rs#L3458-L3483

### Z00Z Implementation

What to reuse (idea-level):
- “Thin wrapper” methods that preserve API clarity but funnel into a single implementation.

How to map into existing Z00Z code:
- Expose clear service methods (RPC-friendly names), but implement them by calling a single shared internal function that accepts a normalized parameter struct.
	- Example pattern: `send_one_sided(...)` and `send_stealth(...)` call `send_internal(params)`.

Why this matters in Z00Z:
- Keeps your public API stable while allowing multiple address types/asset types without duplicating business logic.

#### Implementation Checklist (Finding 8)

**DoD:** `send_internal(params)` exists, public wrappers only normalize params, and wrapper-equality tests pass.

- [ ] Define a single normalized internal parameter struct (e.g. `SendInternalParams`) that contains:
	- [ ] recipient address type (enum)
	- [ ] amount + asset id
	- [ ] output conditions / memo
	- [ ] fee policy override (optional) and defaults
- [ ] Implement `WalletService::send_internal(params)` and make all public send methods thin wrappers.
- [ ] Add guardrails:
	- [ ] wrappers may only normalize parameters; no additional business logic
	- [ ] wrappers must be covered by tests that assert equality of internal params
- [ ] Add tests:
	- [ ] `send_one_sided(...)` and `send_stealth(...)` produce identical internal behavior where intended

---

## Finding 9: send_one_sided_or_stealth shows the real end-to-end “wallet send” pipeline

Where:
- z00z_crypto/tari/wallet/src/transaction_service/service.rs

High-level pipeline:
1. Generate a temporary tx id (`temp_tx_id = TxId::new_random()`) used for local encumbrance/locking.
2. Possibly override the memo/payment-id from the destination address if the address has the `PAYMENT_ID` feature.
3. Ask Output Manager to prepare a transaction builder:
	 - `output_manager_service.prepare_transaction_to_send(temp_tx_id, amount, selection_criteria, output_features, fee_per_gram, script, covenant)`
4. Compute fee estimate (without change) and embed sender address info into `payment_id`.
5. Verify address features, then add recipient output:
	 - stealth one-sided: `tx_builder.add_stealth_recipient(dest_address, amount, output_features, payment_id)`
6. `tx_builder.with_memo(payment_id)` then `finalized = tx_builder.build().await?`
7. Confirm pending transaction and broadcast via `submit_transaction(...)` using `CompletedTransaction::new_with_output_hashes(...)`.

Code anchors:
- Function body (core): z00z_crypto/tari/wallet/src/transaction_service/service.rs#L2364-L2463
- Finalization + confirm + submit: z00z_crypto/tari/wallet/src/transaction_service/service.rs#L2463-L2518

### Z00Z Implementation

What to reuse (idea-level):
- Treat a “send” as a composed pipeline with explicit stages:
	1) temporary id for local bookkeeping
	2) input selection + locking
	3) fee estimate
	4) add recipient output(s)
	5) finalize build (signatures/offsets)
	6) persist + broadcast asynchronously

How to map into existing Z00Z code:
- Implement this composition in `z00z_wallets::services::WalletService` using the existing injected components on `Z00ZWallet`:
	- Selection: `core::tx::AssetSelector`
	- Fees: `core::tx::FeeEstimator`
	- Assembly: `core::tx::TxAssembler`
	- Signing: `core::tx::Signer`
	- Proofs: `core::tx::Prover`
	- Local checks: `core::tx::LocalVerifier`
	- Persistence: `core::storage::{TxStorage,AssetStorage}`
	- Network: a wallet-owned `BroadcastClient` trait implemented using `z00z_networks_rpc::RpcTransport`

How to keep it Z00Z-native:
- Keep memo/payment-id semantics as a Z00Z field in your tx types (don’t import Tari’s feature flags).
- Keep the “temporary id” as a Z00Z `TxId` that is stable across the pipeline (you already have an RPC `TxId` type; keep the core id in `core::tx` too).

#### Implementation Checklist (Finding 9)

**DoD:** The staged send pipeline persists per-stage artifacts, failures are recoverable, and stage-by-stage recovery tests pass.

- [ ] Implement a concrete “send pipeline” orchestration in `WalletService` with explicit stage boundaries:
	- [ ] `stage_1_allocate_intent_id` (deterministic `TxIntentId`)
	- [ ] `stage_2_select_and_lock_inputs`
	- [ ] `stage_3_fee_estimate`
	- [ ] `stage_4_build_outputs`
	- [ ] `stage_5_finalize_signatures_and_offsets`
	- [ ] `stage_6_attach_proofs`
	- [ ] `stage_7_local_verify`
	- [ ] `stage_8_persist_and_queue_broadcast`
- [ ] Define what is persisted after each stage in `TxStorage` (so failures are recoverable):
	- [ ] selected inputs + lock ids
	- [ ] fee parameters used
	- [ ] output intents
	- [ ] signing transcript / signature bundle
	- [ ] finalized tx bytes
- [ ] Implement memo/payment-id policy explicitly:
	- [ ] if destination can override memo, define the precedence rule and test it
	- [ ] store the resolved memo in persisted tx state
- [ ] Ensure “finalize” is the only place that can make a tx broadcastable:
	- [ ] local verification must run before state transitions to “broadcastable”
	- [ ] broadcast is queued, not inline
- [ ] Add tests:
	- [ ] stage-by-stage persistence and recovery
	- [ ] a failure at any stage releases locks or transitions to a safe terminal state

---

## Finding 10: OutputManagerService prepares TransactionBuilder by selecting + encumbering Assetss

Where:
- z00z_crypto/tari/wallet/src/output_manager_service/service.rs

Key flow:
- `prepare_transaction_to_send(tx_id, amount, selection_criteria, fee_per_gram, recipient_output_features, recipient_script, recipient_covenant)`:
	1. Computes the “features+scripts byte size” using consensus weighting.
	2. Calls `select_utxos(amount, selection_criteria, fee_per_gram, num_outputs=1, features_and_scripts_byte_size)`.
	3. Creates `TransactionBuilder::new(consensus_constants, key_manager, network)`.
	4. Applies fee policy and `prevent_fee_gt_amount` from config.
	5. Adds each selected input via `builder.with_input(uo.wallet_output.clone()).await?`.
	6. Encumbers the selected outputs in the wallet DB: `db.encumber_outputs(tx_id, selected, vec![])`.
	7. Returns the prepared `TransactionBuilder` to TransactionService.

Code anchors:
- Function body: z00z_crypto/tari/wallet/src/output_manager_service/service.rs#L936-L1011

### Z00Z Implementation

What to reuse (idea-level):
- Split responsibilities:
	- “output manager” (Assets/asset storage + locking + selection)
	- “tx builder/assembler” (pure tx construction)

How to map into existing Z00Z code:
- Use `z00z_wallets::core::storage::AssetStorage` + `TxStorage` as the home for:
	- spendable note discovery
	- locking/encumbrance (prevent double spend inside the wallet)
	- restoring/canceling locks
- Use an implementation of `z00z_wallets::core::tx::AssetSelector` to perform deterministic selection over what the storage returns.
- Keep the `TxAssembler` implementation free of DB queries; it should accept selected inputs and produce tx structures.

Avoid Tari coupling:
- Don’t bring Tari’s `OutputManagerService` APIs wholesale.
- Reuse the *separation* (storage/selection vs assembly), but keep types and policies Z00Z-owned.

#### Implementation Checklist (Finding 10)

**DoD:** Locking semantics are precise and crash-safe, selector is pure/DB-free, cancellation unlocks deterministically, and lock/unlock tests pass.

- [ ] Define `AssetStorage` locking semantics precisely:
	- [ ] atomic `lock_assets(intent_id, asset_ids, expires_at)`
	- [ ] `unlock_assets(intent_id)` and `unlock_expired_assets(now)`
	- [ ] lock records must include enough info to restore on restart
- [ ] Implement `AssetSelector` as a pure component:
	- [ ] input is an ordered list/iterator of spendable assets + policies
	- [ ] output is `SelectionPlan { selected, requires_change, fee_without_change, fee_with_change }`
	- [ ] no DB access from selector
- [ ] Implement `WalletService::prepare_transaction_to_send(...)` equivalent using Z00Z types:
	- [ ] query spendable assets from `AssetStorage`
	- [ ] call `AssetSelector` and lock selected assets
	- [ ] pass selected inputs to `TxAssembler`
- [ ] Implement cancellation path:
	- [ ] if any downstream stage fails after locking, unlock assets deterministically
	- [ ] if finalize succeeds, transition locks to “consumed by tx_id” (no lingering locks)
- [ ] Add tests:
	- [ ] lock/unlock correctness across restart (storage round-trip)
	- [ ] `TxAssembler` is DB-free (compile-time enforced by DI surface)

---

## Finding 11: Key manager API surface used by TransactionBuilder/Wallet

Where:
- z00z_crypto/tari/transaction_components/src/key_manager/interface.rs

What this is:
- `TransactionKeyManagerInterface` is the central async trait the wallet uses for key allocation, commitments, DH shared secrets, range proofs, and signature material.

Key methods (selected):
- Branch/key allocation:
	- `add_new_branch(branch)`
	- `get_next_key(branch)` (auto-increments index)
	- `get_static_key(branch)` (index 0)
	- `get_random_key()`
- Identity keys:
	- `get_view_key()`, `get_spend_key()`, `get_comms_key()`
- Stealth/DH:
	- `get_diffie_hellman_shared_secret(secret_key_id, public_key)`
	- `get_diffie_hellman_stealth_domain_hasher(secret_key_id, public_key)`
- Confidentiality primitives:
	- `get_commitment(commitment_mask_key_id, value)`
	- `construct_range_proof(commitment_mask_key_id, value, min_value)`

Code anchors:
- Trait definition (start): z00z_crypto/tari/transaction_components/src/key_manager/interface.rs#L339-L430

### Z00Z Implementation

What to reuse (idea-level):
- A unified key-manager surface that covers:
	- identity keys (view/spend)
	- per-output keys/nonces
	- DH/shared-secret derivations
	- commitments + proofs + signature material

How to map into existing Z00Z code:
- Z00Z already has `z00z_wallets::core::key::KeyManager` and Z00Z-owned derivation domains.
- Keep all Tari cryptographic primitives behind `z00z_crypto` (backend isolation), but keep the *wallet-facing* key API in `z00z_wallets`.
	- Example: `KeyManager` exposes “derive purpose key”, “derive nonce”, “derive offset”, “derive recovery key”, “derive shared secret”.
	- The implementation can call `z00z_crypto` for DH/commitment/proof primitives without leaking Tari types.

Design foundation alignment:
- Prefer trait-based DI (already used by `Z00ZWallet<...>` generic components).
- Keep domain separation via `hash_domain!` and Z00Z key domains; do not encode Tari branch strings.

#### Implementation Checklist (Finding 11)

**DoD:** Z00Z `KeyManager` trait is backend-isolated via `z00z_crypto`, and the capability test suite passes.

- [ ] Define the Z00Z wallet-facing `KeyManager` trait to cover exactly these capability groups:
	- [ ] identity keys (view/spend)
	- [ ] per-output key allocation (mask/blinding, metadata signing, script keys)
	- [ ] per-tx key allocation (kernel nonce, offsets)
	- [ ] DH/shared secret derivations
	- [ ] commitments + range proofs + verification hooks
- [ ] Implement the trait in Z00Z using `z00z_crypto` as the backend boundary:
	- [ ] no Tari types leak into `z00z_wallets` public APIs
	- [ ] all secret outputs are wrapped in `Hidden<T>`
- [ ] Ensure every method is deterministic given:
	- [ ] same master secret
	- [ ] same domain labels + indices
	- [ ] same peer pubkey when applicable
- [ ] Add a minimal “capabilities test suite” that:
	- [ ] derives view/spend public keys
	- [ ] derives two purposes and asserts they differ
	- [ ] produces a commitment and verifies a proof through the backend

---

## Finding 12: Key-branch naming is a compatibility boundary

Where:
- z00z_crypto/tari/common_types/src/key_branches.rs

What this is:
- `TransactionKeyManagerBranch` enumerates branch types (nonce, kernel nonce, sender offset, one-sided sender offset, etc).
- `get_branch_key()` returns a string key used for DB compatibility.
- The file explicitly warns that changing these strings affects backwards compatibility and wallet recovery.

Code anchors:
- Enum + branch string keys: z00z_crypto/tari/common_types/src/key_branches.rs#L27-L79

### Z00Z Implementation

What to reuse (idea-level):
- Treat “key purpose naming” as a **compatibility boundary**.

How to map into existing Z00Z code:
- Use Z00Z-owned domains in `z00z_wallets::core::key::domains` as the long-lived compatibility layer.
	- Once shipped, changing a domain label or derivation meaning should be treated as a migration/recovery-breaking change.
- Prefer *domain-separated derivation* (label + version) rather than Tari-style branch string keys.

Practical guidance:
- Version your domains (you already do with `hash_domain!(..., ..., 1)` patterns) and introduce a new domain for breaking changes.
- Keep any backend-specific derivation quirks (Tari/TODO PQ) hidden inside `KeyManagerImpl` and `z00z_crypto`.

#### Implementation Checklist (Finding 12)

**DoD:** Domains are treated as compatibility contracts, the domain registry snapshot test exists, and versioning/migration policy is documented.

- [ ] Treat domain labels + derivation meaning as a compatibility contract:
	- [ ] create a single canonical list of domains in `z00z_wallets::core::key::domains`
	- [ ] each domain has an explicit `version: u32`
- [ ] Add a “domain registry” test that will fail if labels/versions change unintentionally:
	- [ ] snapshot of `(label, version)` pairs
	- [ ] require an explicit migration step to update the snapshot
- [ ] Define migration policy:
	- [ ] breaking derivation changes must introduce a new domain version
	- [ ] old domains remain readable for recovery/import
- [ ] Ensure wallet exports/signing requests include the domain version so old exports remain verifiable.

---

## Finding 13: “Memory DB key manager” helper uses SQLite-in-memory + AEAD

Where:
- z00z_crypto/tari/transaction_key_manager/src/memory_db_key_manager.rs

What it does:
- Provides helpers to create a `TransactionKeyManagerWrapper<TransactionKeyManagerSqliteDatabase<DbConnection>>` using an in-memory shared SQLite connection.
- Encrypts the key-manager DB using `XChaCha20Poly1305` with a fresh random key.
- Supports custom rangeproof size via `CryptoFactories::new(size)`.

Code anchors:
- Type alias and constructors: z00z_crypto/tari/transaction_key_manager/src/memory_db_key_manager.rs#L23-L85

### Z00Z Implementation

What to reuse (idea-level):
- **Key-manager state is a database problem**: you need replayable derivation indices and durable state, encrypted at rest.
- **Encrypt the key DB** with AEAD, and keep the encryption key lifecycle separate from the DB.

How to map into existing Z00Z code:
- Store key-manager *state* (master secret + derivation cursor/indexes + optional cached pub material) behind:
	- `z00z_wallets::core::storage::SecretStore` (secrets + encryption)
	- `z00z_wallets::core::storage::WalletStorage` (non-secret metadata)
- If you need a DB for indices, implement it as a concrete `SecretStoreImpl` / `WalletStorageImpl` detail (SQLite, files, etc.), not as a Tari-specific key-manager DB.
- Use `z00z_utils::io` for atomic writes and `z00z_utils::codec` for stable encoding.

What to avoid importing:
- Tari’s “SQLite-in-memory shared connection” pattern. In Z00Z, treat in-memory key managers as test/dev tooling only.
- Tari’s “rangeproof factory” knobs should live in `z00z_crypto` config (backend tuning), not in wallet storage.

#### Implementation Checklist (Finding 13)

**DoD:** Encrypted-at-rest key state + durable derivation cursors exist and cursor persistence/encryption invariant tests pass.

- [ ] Implement durable key-manager state as a Z00Z-owned storage concern:
	- [ ] persist derivation cursors/indexes per purpose
	- [ ] persist master secret encrypted at rest (never plain)
	- [ ] persist non-secret public material separately if helpful
- [ ] Encryption requirements:
	- [ ] AEAD key is derived/managed by `SecretStore` (not the DB)
	- [ ] support rotation by re-wrapping without re-deriving keys
- [ ] Provide two concrete `SecretStore` backends:
	- [ ] production durable backend (file/SQLite) with atomic writes via `z00z_utils::io`
	- [ ] deterministic in-memory backend for tests
- [ ] Rangeproof configuration:
	- [ ] configure proof sizes in `z00z_crypto` only
	- [ ] wallet code consumes a trait/config without touching backend factories directly
- [ ] Add tests:
	- [ ] cursor persistence across restart
	- [ ] encrypted-at-rest invariant (file does not contain known plaintext patterns)

---

## Finding 14: TransactionBuilder::build aggregates kernel signatures and computes offsets

Where:
- z00z_crypto/tari/transaction_components/src/transaction_builder/builder.rs

High-level pipeline (inside `TransactionBuilder::build`):
1. Preconditions: `self.check_conditions()?`
2. Change output and fee:
	- `add_change_if_required(false)` returns `(total_fee, change_output, ...)`.
3. Compute total public nonce and excess across all inputs/outputs (+ change if any).
4. Construct the core transaction:
	- add all inputs (`to_transaction_input(&key_manager)`)
	- add all “custom outputs” and “recipient outputs”
5. Build kernel signature message:
	- `TransactionKernel::build_kernel_signature_message(version, fee, lock_height, kernel_features, burn_commitment)`
6. For each input and each output (custom/recipient/change), obtain partial kernel signatures and offsets:
	- `get_partial_txo_kernel_signature(..., TxoStage::{Input|Output}, ...)`
	- `get_txo_private_kernel_offset(...)`
	Then sum/accumulate signatures and offsets.
7. Compute script offset:
	- `get_script_offset(&script_keys, &sender_offset_keys)`
8. Build the kernel (fee, features, lock_height, burn_commitment, excess, aggregated signature).
9. Build the `Transaction` from the `CoreTransactionBuilder`.
10. Compute `tx_id`:
	- uses the wallet view key and output(s): either `wallet_output.output.calculate_tx_id(view_key)` (if change exists) or `tx_outputs_to_tx_id(view_key, outputs)`.
	- note: `tx_outputs_to_tx_id` uses the *first output* hash, or returns a random `TxId` if there are no outputs.
11. Assemble `FinalizedTransaction` including:
	- `payment_id` with updated fee embedded (if present)
	- sent/received/change output hashes for downstream wallet bookkeeping

Code anchors:
- Build start + assembling inputs/outputs: z00z_crypto/tari/transaction_components/src/transaction_builder/builder.rs#L831-L910
- Kernel message + partial signatures + offset accumulation: z00z_crypto/tari/transaction_components/src/transaction_builder/builder.rs#L910-L1040
- Script offset + kernel + tx_id derivation + FinalizedTransaction: z00z_crypto/tari/transaction_components/src/transaction_builder/builder.rs#L1040-L1146

### Z00Z Implementation

What to reuse (idea-level):
- A clear separation between:
	- **assembly** (structure of the tx)
	- **signing** (all signature/offset material)
	- **tx id derivation** (deterministic identifier used for tracking)
- “Offset / nonce aggregation” as an internal mechanism to prevent key leakage and support compact kernels.

How to map into existing Z00Z code:
- Map Tari’s monolithic `build()` into your existing spending pipeline components:
	- An implementation of `TxAssembler`: constructs inputs/outputs and a canonical signing transcript.
	- An implementation of `Signer`: produces signatures/offsets using `KeyManager` and `z00z_crypto` primitives.
	- An implementation of `Prover`: attaches range proofs.
	- An implementation of `LocalVerifier`: validates before persistence/broadcast.
- Define a Z00Z-native, domain-separated tx-id derivation function (you already use `hash_domain!` in the wallet):
	- Prefer `TxId = H(domain, canonical_tx_hash)`.
	- Avoid Tari’s “first output hash” trick unless Z00Z explicitly wants that property.

Avoid Tari coupling:
- Don’t bring Tari’s kernel feature taxonomy; keep Z00Z transaction semantics in `z00z_core::tx` and only use `z00z_crypto` for cryptographic proofs/signatures.

#### Implementation Checklist (Finding 14)

**DoD:** Signing transcript + aggregation are implemented, TxId derivation is deterministic, and signature invalidation tests pass.

- [ ] Define a Z00Z-native signing transcript format used by `Signer`:
	- [ ] canonical message(s) for kernel signing
	- [ ] per-input and per-output signing statements
	- [ ] explicit fields that influence fee/weight
- [ ] Implement signature/offset aggregation inside `Signer`:
	- [ ] collect partial signatures from inputs/outputs
	- [ ] aggregate nonces/excesses using backend primitives
	- [ ] produce final kernel signature + offsets
- [ ] Implement Z00Z tx-id derivation deterministically:
	- [ ] `TxId = H(domain, canonical_tx_hash)` (domain-separated)
	- [ ] ensure it is stable regardless of output ordering (if that is required)
- [ ] Define and enforce the build order:
	- [ ] assemble structure → sign/offset → attach proofs → verify → persist
- [ ] Add tests:
	- [ ] same draft yields same tx id and signature in deterministic test mode
	- [ ] changing any fee/lock_height changes the signed message and invalidates signature

---

## Finding 15: WalletOutputBuilder is the “output signing” workhorse

Where:
- z00z_crypto/tari/transaction_components/src/transaction_components/wallet_output_builder.rs

Why it matters:
- Transaction construction is not just “add outputs”; Tari requires metadata signatures and encrypted recovery data to be set correctly on each output.

Key steps:
- `encrypt_data_for_recovery(key_manager, custom_recovery_key_id, payment_id)` stores a `MemoField` and calls `key_manager.encrypt_data_for_recovery(commitment_mask_key_id, ..., value, payment_id)`.
- Metadata signature paths:
	- `sign_as_sender_and_receiver(...)` uses `key_manager.get_metadata_signature(...)` with `metadata_signature_message_from_parts(...)`.
	- `sign_as_sender_and_receiver_verified(...)` is used for one-sided outputs and calls `key_manager.get_one_sided_metadata_signature(...)` using a “common message” plus the receiver address and script.
- `try_build(key_manager)` validates that both sender and receiver signatures are present, then calls `WalletOutput::new(..., key_manager).await?` to produce a `WalletOutput`.

Code anchors:
- Builder fields + encrypt/sign methods: z00z_crypto/tari/transaction_components/src/transaction_components/wallet_output_builder.rs#L40-L209
- `try_build`: z00z_crypto/tari/transaction_components/src/transaction_components/wallet_output_builder.rs#L319-L369

### Z00Z Implementation

What to reuse (idea-level):
- “Output building” needs a disciplined checklist:
	- encrypted recovery/memo data
	- metadata signatures
	- proof attachment
	- validation that all required fields are present

How to map into existing Z00Z code:
- Treat this as part of an implementation of `TxAssembler` + an implementation of `Signer` responsibilities:
	- The `TxAssembler` implementation constructs output intent (amount, script/constraints, memo, recipient).
	- The `Signer` implementation applies the necessary per-output signatures.
	- The `Prover` implementation generates proofs.
	- The `LocalVerifier` implementation ensures completeness/validity.
- If you want a builder pattern, make it a Z00Z type under `z00z_wallets::core::tx` (e.g. `OutputIntentBuilder`) rather than adopting Tari’s output structs.

How to avoid Tari-specific leakage:
- Replace Tari’s script/covenant/memo semantics with Z00Z-native “spend conditions” and “memo” types in `z00z_core::tx`.
- Keep encryption primitives behind `z00z_crypto` and avoid embedding backend-specific serialization formats in wallet storage.

#### Implementation Checklist (Finding 15)

**DoD:** Output intents are constructed, signatures+proofs are attached, completeness rules are enforced, and output completeness tests pass.

- [ ] Define Z00Z `OutputIntent` / `OutputBuildPlan` with explicit required fields:
	- [ ] amount/value
	- [ ] recipient descriptor
	- [ ] memo/recovery payload (optional)
	- [ ] spend conditions / constraints (Z00Z type)
- [ ] Implement output construction pipeline:
	- [ ] `TxAssembler` produces intents
	- [ ] `Signer` attaches metadata signatures for each output
	- [ ] `Prover` attaches proofs
	- [ ] `LocalVerifier` asserts completeness (no “half-built” outputs)
- [ ] Define strict validation rules for “output completeness”:
	- [ ] required signatures present
	- [ ] encrypted recovery data present when memo exists
	- [ ] proof present for confidential outputs
- [ ] Add tests:
	- [ ] building an output without required signatures fails early
	- [ ] output serialization round-trip preserves memo/constraints bytes

---

## Finding 16: z00z_wallets/tari-wallet provides a KeyManagerBuilder wrapper

Where:
- z00z_wallets/tari-wallet/src/key_manager_builder.rs

What it does:
- Exposes `KeyManagerBuilder::with_view_key_and_spend_key(view_key, spend_key, birthday)` which sets `WalletType::ProvidedKeys(ProvidedKeysWallet { ... })`.
- `try_build()` returns `TransactionKeyManagerWrapper<MemoryKeyManagerBackend>`.

Important detail:
- For `ProvidedKeysWallet`, it currently uses a placeholder `CipherSeed::new()` to construct the key manager wrapper.
- It also contains a `todo!("Not implemented yet")` for non-ProvidedKeys wallet types.

Code anchors:
- Builder + provided keys wiring: z00z_wallets/tari-wallet/src/key_manager_builder.rs#L19-L44
- `try_build` placeholder seed: z00z_wallets/tari-wallet/src/key_manager_builder.rs#L46-L63

### Z00Z Implementation

What to reuse (idea-level):
- A clean *builder/factory* that constructs a key manager from “wallet identity + secrets + birthday/scan start”.

How to map into existing Z00Z code:
- Prefer your existing `z00z_wallets::core::key::KeyManagerImpl` and initialize it from `SecretStore` on unlock.
- Avoid placeholder seeds:
	- In Z00Z, the master secret should come from `SecretStore` (encrypted at rest) or from an explicit import/export flow.

Migration note:
- The Tari wrapper exists mostly because Tari key manager has multiple wallet types and backward-compat constraints.
- In Z00Z, keep the wallet types minimal and explicit (e.g. “new wallet”, “import wallet”), and hide backend differences behind trait implementations.

#### Implementation Checklist (Finding 16)

**DoD:** New/import wallet flows are explicit, no placeholder secrets exist in production paths, and creation/import tests pass.

- [ ] Define explicit wallet creation flows in Z00Z:
	- [ ] `new_wallet` (generate master secret using `SystemRngProvider`)
	- [ ] `import_wallet` (accept explicit seed/material; validate format)
- [ ] Ensure no placeholder secrets exist anywhere in production code paths:
	- [ ] forbid “temporary seed” patterns; secrets must come from `SecretStore`
- [ ] Implement a `KeyManagerFactory` that:
	- [ ] takes `SecretStore` + `TimeProvider` + config
	- [ ] creates an unlocked key manager session only after successful unlock
	- [ ] returns an object that can be dropped to wipe secrets
- [ ] Add tests:
	- [ ] new wallet produces stable public keys for the same deterministic test seed
	- [ ] import wallet rejects invalid inputs deterministically

---

## Finding 17: Interactive (non-one-sided) transactions are tracked via Sender/Receiver protocol state machines

Where:
- z00z_crypto/tari/wallet/src/transaction_service/storage/models.rs
- z00z_crypto/tari/wallet/src/legacy_transaction_protocol/sender.rs
- z00z_crypto/tari/wallet/src/legacy_transaction_protocol/recipient.rs

What this is:
- Tari’s wallet DB does not store only “a transaction”; it stores protocol state for ongoing interactive negotiation:
	- `OutboundTransaction` contains a `SenderTransactionProtocol`.
	- `InboundTransaction` contains a `ReceiverTransactionProtocol`.
- These protocols are serialized (`serde`) and persisted so the wallet can resume after restart.

Protocol artifacts:
- Receiver side produces a `RecipientSignedMessage { tx_id, output, public_spend_key, partial_signature, tx_metadata, offset }` which is sent back to the sender.
- Sender side is a state machine (`SenderState`) that progresses through “message ready”, “collect signature”, “finalize”, “finalized transaction”, etc.

Code anchors:
- Outbound/Inbound structs with protocol fields:
	- z00z_crypto/tari/wallet/src/transaction_service/storage/models.rs#L47-L111
	- z00z_crypto/tari/wallet/src/transaction_service/storage/models.rs#L79-L128
- Sender protocol type:
	- z00z_crypto/tari/wallet/src/legacy_transaction_protocol/sender.rs#L159-L206
- Receiver protocol type + signed message:
	- z00z_crypto/tari/wallet/src/legacy_transaction_protocol/recipient.rs#L55-L113

### Z00Z Implementation

Decision point for Z00Z (don’t copy, choose deliberately):
- If Z00Z only needs one-sided/offline-style sends, **do not import** interactive protocol machinery.
- If Z00Z needs interactive negotiation (multi-round protocols, co-signing, multi-party), implement it as a Z00Z-owned state machine.

How to map into existing Z00Z code (if interactive is needed):
- Put protocol orchestration in `z00z_wallets::services::WalletService` (async tasks), not in `z00z_core`.
- Persist resumable protocol state in `z00z_wallets::core::storage::TxStorage` as a versioned state blob.
- Transport messages using `z00z_networks_rpc::RpcTransport` (or a higher-level wallet protocol transport trait that wraps it).

How to keep it Z00Z-native:
- Define protocol messages in terms of Z00Z tx primitives (`z00z_core::tx`), not Tari `RecipientSignedMessage` types.
- Use `z00z_crypto` only for signatures/proofs and keep all protocol semantics in Z00Z types.

#### Implementation Checklist (Finding 17)

**DoD:** Interactive-protocol support stance is explicit; if enabled, the resumable state machine + resume tests pass.

- [ ] Make an explicit product decision (recorded in docs/config):
	- [ ] `interactive_protocols_enabled = false` by default
	- [ ] list which flows are supported (one-sided/offline only vs interactive)
- [ ] If interactive protocols are NOT supported now:
	- [ ] ensure storage schema can represent “pending interactive” without placeholders
	- [ ] keep protocol state type reserved but unused (versioned)
	- [ ] add a clear error returned by service/RPC when interactive is requested
- [ ] If interactive protocols ARE supported:
	- [ ] define Z00Z protocol messages (request/response) with versioning
	- [ ] implement a resumable state machine stored in `TxStorage`
	- [ ] implement a driver task that resumes on restart
	- [ ] implement transport abstraction using `RpcTransport` (or wallet-owned protocol transport trait)
- [ ] Add tests:
	- [ ] state machine persists and resumes correctly
	- [ ] protocol never transitions to “broadcastable” without full finalization

---

## Finding 18: Assets selection algorithm (coin selection) lives in OutputManagerService::select_utxos

Where:
- z00z_crypto/tari/wallet/src/output_manager_service/service.rs

Key flow:
- `select_utxos(amount, selection_criteria, fee_per_gram, num_outputs, features_and_scripts_byte_size)` does all of:
	1) Resolves `tip_height` via `db.get_last_scanned_height()`.
	2) Applies policy toggles:
		- if `config.autoignore_onesided_utxos` then `selection_criteria.excluding_onesided = true`.
		- always sets `selection_criteria.excluding_multisig = true`.
	3) Queries candidate outputs from DB:
		- `db.fetch_unspent_outputs_for_spending(&selection_criteria, amount, tip_height)`.
	4) Greedy-accumulates Assetss in DB-return order:
		- after each added Assets, recomputes:
			- `fee_without_change = fee_calc.calculate(fee_per_gram, 1, inputs=len(utxos), outputs=num_outputs, byte_size)`
			- `fee_with_change = fee_calc.calculate(fee_per_gram, 1, inputs=len(utxos), outputs=num_outputs+1, byte_size + default_change_features_and_scripts_size)`
		- stops early if either:
			- perfect match: `utxos_total_value == amount + fee_without_change`
			- enough-with-change: `utxos_total_value > amount + fee_with_change` (sets `requires_change_output=true`)
	5) Failure modes:
		- If non-standard filter and DB returns empty => `NoUtxosSelected { criteria }`.
		- If insufficient funds:
			- if `utxos_total_value + pending_incoming >= amount + fee_with_change` => `FundsPending`
			- else => `NotEnoughFunds`
		- If DB already returned exactly `TRANSACTION_INPUTS_LIMIT` and still not enough => `TooManyInputsToFulfillTransaction`.

Why this matters for migration:
- “Coin selection” and “change decision” are split between wallet DB query ordering and the fee re-calculation loop.
- The selection here is greedy; the strategy/ordering largely comes from `fetch_unspent_outputs_for_spending` (DB layer).

Code anchors:
- Function start + criteria tweaks + DB fetch: z00z_crypto/tari/wallet/src/output_manager_service/service.rs#L1898-L1966
- Greedy loop + fee-with/without change + decision flags: z00z_crypto/tari/wallet/src/output_manager_service/service.rs#L1996-L2072
- Insufficient-funds branches (FundsPending/NotEnoughFunds/TooManyInputs): z00z_crypto/tari/wallet/src/output_manager_service/service.rs#L2074-L2105

### Z00Z Implementation

What to reuse (idea-level):
- Deterministic selection is a combo of:
	- storage query ordering
	- a simple accumulator loop that recomputes fee and decides on change
- Explicit failure modes that distinguish:
	- not enough confirmed funds
	- funds exist but are pending (e.g. incoming, time-locked, not yet mature)
	- too many inputs (DoS / size constraints)

How to map into existing Z00Z code:
- Implement selection as:
	- `AssetStorage` query (returns spendable notes + metadata)
	- an implementation of `AssetSelector` (greedy selection with a `SelectionStrategy`)
	- an implementation of `FeeEstimator` called inside the selection loop
- Add a Z00Z selection result that mirrors the useful shape:
	- selected inputs
	- `fee_without_change` / `fee_with_change`
	- `requires_change`

How to keep it Z00Z-native:
- Replace Tari’s onesided/multisig exclusions with Z00Z-owned note categories/policies (e.g. “avoid linkable notes”, “exclude frozen notes”).
- Use `ScanStorage`/sync state (already exists) to decide what counts as “pending” vs “confirmed”.

#### Implementation Checklist (Finding 18)

**DoD:** Selection ordering/policies are explicit, failure modes are correct, and deterministic selection + pending-vs-insufficient tests pass.

- [ ] Implement `AssetSelector` greedy selection with explicit, testable policies:
	- [ ] selection ordering (smallest/largest/heuristic)
	- [ ] exclusion filters (frozen, immature, time-locked, linkable, etc.)
	- [ ] max inputs limit (DoS/size bound)
- [ ] Integrate fee recomputation inside the selection loop:
	- [ ] call `FeeEstimator` for `fee_without_change` and `fee_with_change` on each step
	- [ ] stop conditions are deterministic and documented
- [ ] Define selection failure modes as a closed enum:
	- [ ] `NoSpendableAssets`
	- [ ] `FundsPending` (and define what counts as pending)
	- [ ] `NotEnoughFunds`
	- [ ] `TooManyInputs`
- [ ] Ensure DB/storage ordering and selector policy are both represented:
	- [ ] storage returns ordered candidates given requested ordering
	- [ ] selector logic is independent and unit-tested
- [ ] Add tests:
	- [ ] deterministic selection given a fixed candidate list
	- [ ] correct `FundsPending` vs `NotEnoughFunds` classification
	- [ ] max-inputs limit is enforced

---

## Finding 19: Change output + fee logic is implemented inside TransactionBuilder (not OutputManager)

Where:
- z00z_crypto/tari/transaction_components/src/transaction_builder/builder.rs

Key flow:
- OutputManager selects inputs and returns a builder, but **TransactionBuilder decides change** during `build()` by calling `add_change_if_required(false)`.
- `add_change_if_required(calculate_tx_id)` computes:
	- `total_being_spent = sum(inputs)`
	- `total_sent = sum(custom_outputs) + sum(recipient_outputs)`
	- `fee_without_change = get_fee_estimate_without_change()`
	- `combined_sent = total_sent + fee_without_change`
	- `change_amount = total_being_spent - combined_sent`
	Then:
	- if `change_amount == 0`: no change output.
	- else estimate a change-output fee (`change_fee`) and try `change_amount - change_fee`:
		- if it underflows or becomes 0: skip change output and roll the remainder into fee.
		- else: build change output via `build_change(v)`.
	- If `fee > total_sent` it warns and (optionally) errors if `prevent_fee_gt_amount` is enabled.

Important nuance:
- Even if OutputManager’s `select_utxos` said “requires_change_output=true”, the **final** change decision is made by TransactionBuilder after the full output set is known (including any memo/size changes).

Code anchors:
- `add_change_if_required`: z00z_crypto/tari/transaction_components/src/transaction_builder/builder.rs#L448-L610
- `build_change`: z00z_crypto/tari/transaction_components/src/transaction_builder/builder.rs#L613-L739
- `build()` calling change logic: z00z_crypto/tari/transaction_components/src/transaction_builder/builder.rs#L831-L839

### Z00Z Implementation

What to reuse (idea-level):
- Change output creation is a **finalization concern**: only decide after the full output set (including memo/constraints) is fixed.
- The selector can *predict* change needs, but the assembler must make the final call.

How to map into existing Z00Z code:
- Keep the `AssetSelector` implementation responsible for picking inputs and returning a preliminary plan:
	- selected inputs
	- estimated fee ranges
	- `requires_change` (best-effort)
- Keep the `TxAssembler` implementation responsible for:
	- constructing a concrete change output intent (if needed)
	- recomputing exact fee based on the canonical “features/scripts bytes” accounting
	- possibly folding tiny remainder into fee if change becomes dust
- Enforce “fee > amount”/“fee too large” policy in the `LocalVerifier` implementation and surface a dedicated error from wallet service.

Avoid pitfalls:
- Don’t duplicate fee/change logic in both selector and assembler; allow selector to iterate, but treat assembler as authoritative.

#### Implementation Checklist (Finding 19)

**DoD:** Change decision is authoritative in assembler, dust/fee-sanity are enforced, and boundary tests pass.

- [ ] Define a single authoritative change-decision function in `TxAssembler` that takes:
	- [ ] selected inputs
	- [ ] finalized recipient outputs (including memo/constraints)
	- [ ] fee model parameters
	- [ ] dust policy
- [ ] Ensure `AssetSelector` returns only a preliminary “requires_change” hint:
	- [ ] selector is allowed to be conservative (prefer returning “requires_change”)
	- [ ] assembler must recompute exact amounts and decide definitively
- [ ] Implement dust handling explicitly:
	- [ ] define what “dust” means for change outputs
	- [ ] if change would be dust, fold it into fee and record that decision
- [ ] Enforce fee sanity as part of local verification:
	- [ ] reject `fee > total_sent` if policy says so
	- [ ] return a dedicated error type with actionable fields
- [ ] Add tests:
	- [ ] “selector says change required” but assembler decides no-change due to dust
	- [ ] “fee too large” policy rejects correctly

---

## Finding 20: Broadcast + monitoring is a dedicated async protocol loop (TransactionBroadcastProtocol)

Where:
- z00z_crypto/tari/wallet/src/transaction_service/service.rs
- z00z_crypto/tari/wallet/src/transaction_service/protocols/transaction_broadcast_protocol.rs

Key flow:
- When a send pipeline produces a `CompletedTransaction`, `TransactionService::submit_transaction(...)`:
	- inserts it into the DB (`insert_completed_transaction`)
	- checks tx size (`check_transaction_size`)
	- triggers the “send protocol completion” bookkeeping
	- broadcast actually happens asynchronously via the broadcast protocol loop.
- `broadcast_completed_transaction(...)` spawns `TransactionBroadcastProtocol::execute()` once per tx_id and tracks active protocols in `active_transaction_broadcast_protocols`.

Broadcast protocol semantics:
- The protocol alternates between two modes:
	- `TransactionSubmission`: call `client.submit_transaction(tx)`
	- `TransactionQuery`: call `client.transaction_query(kernel_sig_nonce, kernel_sig)`
- On successful submission (base node accepted the tx and the wallet transitions to broadcasted/monitoring):
	- wallet DB is updated to “broadcast” via `db.broadcast_completed_transaction(tx_id)`
	- event emitted: `TransactionEvent::TransactionBroadcast(tx_id)`
- If query shows tx missing from mempool, the protocol may resubmit once (within `transaction_mempool_resubmission_window`); otherwise it cancels as invalid.
- On hard rejection it cancels the transaction and also cancels encumbered outputs via OutputManager.

Code anchors:
- Spawn + tracking: z00z_crypto/tari/wallet/src/transaction_service/service.rs#L3817-L3851
- `submit_transaction(...)` inserts + size-checks: z00z_crypto/tari/wallet/src/transaction_service/service.rs#L4012-L4049
- Broadcast protocol main loop: z00z_crypto/tari/wallet/src/transaction_service/protocols/transaction_broadcast_protocol.rs#L88-L167
- Base-node submit + rejection mapping: z00z_crypto/tari/wallet/src/transaction_service/protocols/transaction_broadcast_protocol.rs#L175-L266
- Query/resubmit window logic: z00z_crypto/tari/wallet/src/transaction_service/protocols/transaction_broadcast_protocol.rs#L299-L356

### Z00Z Implementation

What to reuse (idea-level):
- Broadcasting is a **resumable background protocol**, not an inline “send()” call.
- Treat base-layer propagation as eventually consistent: submit, then query, resubmit once, cancel if invalid.

How to map into existing Z00Z code:
- Put broadcast/monitor as a wallet-owned protocol runner in `z00z_wallets::services::WalletService`.
- Persist per-tx broadcast state in `TxStorage` (status, last submit time, attempts, last error) so it survives restarts.
- Implement transport using `z00z_networks_rpc::RpcTransport` (or a thin `BaseLayerClient` trait implemented on top of it).

Operational notes for Z00Z:
- Make broadcast idempotent: re-submitting the same tx should not corrupt local state.
- On terminal failure, roll back/expire any “locked/encumbered” inputs in `AssetStorage`.

#### Implementation Checklist (Finding 20)

**DoD:** Broadcast protocol is resumable and persisted, resubmission policy is enforced, and idempotency/restart tests pass.

- [ ] Implement a wallet-owned broadcast protocol runner:
	- [ ] task-per-tx (or queue-based) execution model
	- [ ] explicit protocol states: `Created`, `Submitted`, `Broadcasted`, `Querying`, `Resubmitted`, `Completed`, `Cancelled`, `Failed`
- [ ] Persist protocol state in `TxStorage`:
	- [ ] last submit time
	- [ ] attempt count
	- [ ] last known mempool/query result
	- [ ] last error code/classification
- [ ] Implement two transport operations behind a trait:
	- [ ] `submit_transaction(tx_bytes)`
	- [ ] `query_transaction(kernel_sig_or_txid)` (choose canonical query key and document it)
- [ ] Implement resubmission window policy:
	- [ ] configurable window duration
	- [ ] allow at most one resubmission inside the window
	- [ ] terminal cancellation if missing after window
- [ ] Ensure idempotency and crash safety:
	- [ ] protocol can be restarted and will not double-unlock or double-mark spent
	- [ ] state transitions are atomic in storage
- [ ] Define rollback behavior on terminal failure:
	- [ ] cancel tx record
	- [ ] unlock any encumbered inputs
	- [ ] emit a single terminal event
- [ ] Add tests:
	- [ ] resubmission occurs exactly once
	- [ ] restart resumes from persisted state without corrupting locks

---

## Finding 21: Legacy interactive protocols exist, but are not wired into current TransactionService requests

Where:
- z00z_crypto/tari/wallet/src/transaction_service/handle.rs
- z00z_crypto/tari/wallet/src/transaction_service/service.rs
- z00z_crypto/tari/wallet/src/transaction_service/storage/models.rs

What I observed:
- `TransactionServiceRequest` includes many operations (one-sided send, burn, multisig, etc.) but **no request variant** for an interactive sender/receiver negotiation flow.
- `SenderTransactionProtocol` / `ReceiverTransactionProtocol` types still exist and are stored in `OutboundTransaction` / `InboundTransaction`, but current codepaths appear to create `CompletedTransaction` directly for one-sided flows.
- The main remaining usage is DB/model compatibility:
	- `CompletedTransaction::from_outbound(...)` conditionally extracts an embedded `Transaction` *only if* `tx.sender_protocol.is_finalized()`; otherwise it emits an “empty” placeholder `Transaction`.
	- Conversions from `CompletedTransaction` back to `InboundTransaction`/`OutboundTransaction` use `*_protocol::new_placeholder()`.

Implication for migration:
- If Z00Z plans to support interactive negotiation, you likely need to reintroduce (or rewire) a sender/receiver protocol driver around the legacy protocol types.
- If only one-sided is required, legacy protocol state machines may be needed only for historical DB import/backward-compat.

Code anchors:
- Request enum (no interactive variants): z00z_crypto/tari/wallet/src/transaction_service/handle.rs#L82-L239
- Model conversion using sender_protocol.finalized check: z00z_crypto/tari/wallet/src/transaction_service/storage/models.rs#L464-L505
- Placeholder protocols on conversion: z00z_crypto/tari/wallet/src/transaction_service/storage/models.rs#L526-L548

### Z00Z Implementation

What to reuse (idea-level):
- Protocol state machines can outlive the current “happy path”, mainly for **DB compatibility**.

How to map into Z00Z:
- If Z00Z supports only one-sided flows right now:
	- keep the interactive state machine out of the main send path
	- store minimal per-tx state needed for recovery/resume and future upgrades
- If Z00Z wants to support interactive flows later:
	- define a versioned protocol state type in `z00z_wallets` and persist it (not Tari’s sender/receiver protocol types)
	- implement a protocol driver that reads/writes this state and uses `RpcTransport` for message exchange

Migration/back-compat stance:
- Avoid inventing placeholder “empty transactions” as a general pattern; in Z00Z storage prefer an explicit “protocol not finalized” state.

#### Implementation Checklist (Finding 21)

**DoD:** Non-finalized txs are represented explicitly (no placeholders), and storage round-trip + migration mapping tests pass.

- [ ] Define Z00Z storage representation for “protocol in progress”:
	- [ ] explicit enum state (no placeholder/empty tx objects)
	- [ ] separate fields for: draft, partial signatures, finalized tx
- [ ] If importing/reading Tari-derived historical data is required:
	- [ ] implement a dedicated import pathway that maps to Z00Z storage states
	- [ ] keep legacy-only compatibility logic out of the main send pipeline
- [ ] Ensure conversion rules never fabricate “empty tx bytes”:
	- [ ] represent “not finalized” as `None` for tx bytes + explicit state
- [ ] Add tests:
	- [ ] storage round-trip for non-finalized vs finalized states
	- [ ] migration/import mapping is deterministic and validated

---

## Finding 22: Offline one-sided signing finalizes a full transaction via OneSidedSigner

Where:
- z00z_crypto/tari/transaction_components/src/offline_signing/one_sided_signer.rs

What this is:
- `OfflineSigner::prepare_one_sided_transaction_for_signing(...)` (Finding 4) produces a signing request.
- `OneSidedSigner::sign_transaction(tx_id, info)` is the complementary step that:
	- unmarshals export-safe key-ids back into live `TariKeyId`s
	- derives DH-based keys and script spending keys
	- constructs the recipient output (with encrypted recovery data + one-sided metadata signatures)
	- constructs the kernel signature pieces and assembles the full `Transaction`

Key cryptographic/key-manager steps:
- Allocates sender offset key from the key manager:
	- `get_next_key(TransactionKeyManagerBranch::OneSidedSenderOffset)`
- Derives DH-based key ids against recipient view key:
	- `TariKeyId::DHCommitmentMask { private_key: sender_offset_key, public_key: recipient_view_key }`
	- `TariKeyId::DHEncryptedData { private_key: sender_offset_key, public_key: recipient_view_key }`
- Derives stealth script spending key and constructs script:
	- `stealth_address_script_spending_key(commitment_mask_key_id, recipient_spend_key)`
	- `push_pubkey_script(script_spending_key)`
- Builds the output using `WalletOutputBuilder` with:
	- `encrypt_data_for_recovery(..., Some(&encryption_key), payment_id)`
	- `sign_as_sender_and_receiver_verified(..., sender_offset_key_id, recipient_address)`
- Computes aggregated public nonce/excess across inputs/outputs/change for kernel signing.
- Allocates a kernel nonce via `TransactionKeyManagerBranch::KernelNonce` and obtains:
	- `get_partial_txo_kernel_signature(..., TxoStage::Output)`
	- `get_txo_private_kernel_offset(...)`
- Packages these into a `RecipientSignedMessage { output, public_spend_key, partial_signature, offset, tx_metadata }`.

Why this matters for migration:
- This file is effectively the “offline finalizer”: it shows the exact per-branch key allocations and how a one-sided tx is converted from exported structure into a signed, broadcastable transaction.

Code anchors:
- Marshal exported key ids back into live key ids: z00z_crypto/tari/transaction_components/src/offline_signing/one_sided_signer.rs#L151-L173
- One-sided output construction + metadata signatures: z00z_crypto/tari/transaction_components/src/offline_signing/one_sided_signer.rs#L232-L295
- Kernel signing (nonce/excess aggregation + partial signature + offset): z00z_crypto/tari/transaction_components/src/offline_signing/one_sided_signer.rs#L320-L358

### Z00Z Implementation

What to reuse (idea-level):
- Split offline signing into:
	- **export**: an opaque signing request containing only public data + export-safe key references
	- **finalize**: a signer that rehydrates key refs into real keys and produces a broadcastable tx

How to map into existing Z00Z code:
- Represent exported key references as Z00Z-owned `KeyRef`/`KeyId` values from `z00z_wallets::core::key` (no backend key-id structs).
- Implement offline finalization as a `Signer`/`TxFinalizer` component in `z00z_wallets::core::tx`:
	- input: exported request + wallet secrets unlocked via `SecretStore`
	- output: finalized `Transaction` (Z00Z tx type) + tracking metadata
- Keep branch/purpose separation using your existing derivation domains (e.g. `KernelNonce`, `SenderOffset`, `DataEncrypt`) rather than Tari branches.

Security notes:
- Ensure exported requests never contain secret material; only stable identifiers plus public keys.
- Keep all “script/constraints” semantics in Z00Z types; `z00z_crypto` is used only to sign/prove.

#### Implementation Checklist (Finding 22)

**DoD:** Offline finalization produces a verifiable transaction from exported requests, tampering is rejected, and secret non-serialization invariants hold.

- [ ] Implement offline finalize as a dedicated component (service + core):
	- [ ] input: `OneSidedSigningRequestV*` + unlocked secrets
	- [ ] output: finalized tx bytes + tracking metadata
- [ ] Rehydrate key references safely:
	- [ ] resolve each `KeyRef` deterministically
	- [ ] fail fast if the request references unsupported purposes
- [ ] Build one-sided output deterministically:
	- [ ] derive DH/shared secrets via `z00z_crypto`
	- [ ] derive script spending key (Z00Z type) and build spend conditions
	- [ ] attach encrypted recovery payload if present
	- [ ] create required metadata signatures via `z00z_crypto`
- [ ] Kernel signature and offset aggregation:
	- [ ] compute aggregated nonce/excess
	- [ ] derive kernel nonce from the correct domain
	- [ ] produce final kernel signature + offsets
- [ ] Validate before returning:
	- [ ] run `LocalVerifier` on the finalized tx
	- [ ] ensure tx-id derivation matches the stored intent id linkage
- [ ] Add tests:
	- [ ] export → finalize round-trip produces a verifiable tx
	- [ ] tampering with request payload causes verification failure
	- [ ] exported request types are structurally unable to contain secrets AND a serialization test enforces secret non-serialization

---

## Finding 23: DB-layer Assets ordering strongly influences coin selection

Where:
- z00z_crypto/tari/wallet/src/output_manager_service/storage/sqlite_db/output_sql.rs

What the DB returns (important because select_utxos greedily consumes this list):
- `fetch_unspent_outputs_for_spending(selection_criteria, amount, tip_height, conn)`:
	- filters to `OutputStatus::Unspent`
	- applies `min_dust` threshold (`outputs::value.gt(min_dust)`)
	- orders by `outputs::spending_priority.desc()` first
	- in `UtxoSelectionMode::Safe`, filters on `script_lock_height <= tip_height` and `maturity <= tip_height`
	- for Standard filter:
		- only `OutputType::{Standard|Coinbase}`
		- optionally excludes onesided (`OutputSource::OneSided`) and multisig (`OutputSource::Multisig`)
	- applies `excluding` commitments list
	- then applies secondary ordering based on `UtxoSelectionOrdering`:
		- `SmallestFirst` => value asc
		- `LargestFirst` => value desc
		- `Default` => queries max Assets value at tip; if `amount > max` uses value desc (fewer inputs), else value asc.
	- limits results to `TRANSACTION_INPUTS_LIMIT`.

Migration takeaway:
- “Coin selection strategy” is actually a combination of:
	- DB query ordering (priority + value ordering)
	- greedy accumulation in `select_utxos`
- If you migrate coin selection, you need both layers (query ordering + accumulator) to match Tari behavior.

Code anchors:
- Query construction + ordering logic: z00z_crypto/tari/wallet/src/output_manager_service/storage/sqlite_db/output_sql.rs#L211-L305
- Default ordering heuristic (amount vs max Assets): z00z_crypto/tari/wallet/src/output_manager_service/storage/sqlite_db/output_sql.rs#L274-L303

### Z00Z Implementation

What to reuse (idea-level):
- Selection behavior is the sum of:
	- storage ordering
	- selector loop policy

How to map into existing Z00Z code:
- Make ordering a first-class, explicit input to `AssetStorage` queries (or return an iterator that is already ordered):
	- `SpendingPriority` (descending)
	- `UtxoSelectionOrdering` (smallest/large/heuristic)
	- maturity/lock checks relative to chain tip
- Keep the “amount vs max Assets” heuristic in the `AssetSelector` implementation (policy layer), and let `AssetStorage` only implement the requested ordering.

Avoid pitfalls:
- Don’t hide selection policy inside SQL alone; make it testable at the selector layer.

#### Implementation Checklist (Finding 23)

**DoD:** Storage ordering is explicit, the selection heuristic boundary is tested, and ordering/heuristic tests pass.

- [ ] Make storage ordering explicit in the `AssetStorage` query API:
	- [ ] primary spending priority (descending)
	- [ ] secondary ordering mode (smallest/largest/default heuristic)
	- [ ] maturity/lock constraints relative to chain tip
- [ ] Implement the “amount vs max asset” heuristic in `AssetSelector` policy:
	- [ ] selector asks storage for max value (or storage returns it with candidates)
	- [ ] if `amount > max`, choose largest-first; else smallest-first
- [ ] Add tests:
	- [ ] storage ordering is stable and deterministic
	- [ ] heuristic switches ordering exactly at the documented boundary

---

## Finding 24: Fee/weight correctness depends on per-output rounding (bytes_per_gram = 16)

Where:
- z00z_crypto/tari/transaction_components/src/weight.rs
- z00z_crypto/tari/transaction_components/src/fee.rs

What Tari calls “weight”:
- `TransactionWeight::v1()` parameters:
	- `kernel_weight = 10` grams per kernel
	- `input_weight = 8` grams per input
	- `output_weight = 53` grams per output (excluding features/scripts)
	- `features_and_scripts_bytes_per_gram = 16` (i.e. 16 bytes contribute 1 gram)

How “features+scripts bytes” contribute to grams:
- Weight calculation uses integer division:
	- `grams += rounded_features_and_scripts_bytes / 16`
- This makes rounding strategy a correctness boundary.

Critical detail: round up per output, then sum
- `TransactionWeight::calculate_body(...)` rounds each output’s `features_and_scripts_size` up to the next multiple of 16 and *then* sums.
- The code explicitly warns that doing a “single global rounding” is incorrect due to integer division:
	- `(Σ s_i)/16 != Σ (s_i/16)` in general.

Code anchors:
- Params + weight formula: z00z_crypto/tari/transaction_components/src/weight.rs#L19-L64
- Per-output rounding explanation + implementation: z00z_crypto/tari/transaction_components/src/weight.rs#L86-L134
- Fee wrapper uses `TransactionWeight::calculate`: z00z_crypto/tari/transaction_components/src/fee.rs#L23-L59

### Z00Z Implementation

What to reuse (idea-level):
- Define fee/weight rules so that *everyone* (selector, assembler, verifier) uses the same math.
- If you use integer-division weighting, you must be explicit about rounding:
	- **round per output, then sum** (or whatever rule you choose), but make it canonical.

How to map into existing Z00Z code:
- Put the canonical fee/weight model behind the `FeeEstimator` implementation and use it everywhere:
	- selection loop
	- tx assembly (change decision)
	- local verification
- Provide a helper that takes an output description and returns “features/scripts bytes rounded contribution” so the same function is reused across wallet components.

Z00Z-specific flexibility:
- Z00Z does not need Tari’s constants (e.g. 16 bytes/gram), but it *does* need a single source of truth and deterministic rounding.

Invariant test recommendation:
- Add a unit test that demonstrates why “global rounding” is wrong:
	- pick two outputs where each `features+scripts_bytes` is just over a 16-byte boundary (e.g. 17 and 17)
	- assert `round_each_then_sum != round_sum_then_divide`

#### Implementation Checklist (Finding 24)

**DoD:** Canonical rounding helper is the single source of truth and invariant/property tests for rounding pass.

- [ ] Implement a single canonical “features/scripts bytes → grams” helper:
	- [ ] rounds per-output first (or the chosen canonical rule)
	- [ ] is used by selector, assembler, verifier
- [ ] Ensure the fee estimator is the sole source of truth:
	- [ ] no duplicated rounding logic in multiple layers
	- [ ] provide a small “fee context” struct that is passed through stages
- [ ] Add the invariant tests:
	- [ ] `round_each_then_sum != round_sum_then_divide` example test
	- [ ] property test that per-output rounding is always ≥ global rounding for non-multiples

---

## Finding 25: Wallet-side fee estimation matches builder-side sizing, except a small change-output covenant mismatch

Where:
- z00z_crypto/tari/wallet/src/output_manager_service/service.rs
- z00z_crypto/tari/transaction_components/src/transaction_components/wallet_output.rs
- z00z_crypto/tari/transaction_components/src/transaction_builder/builder.rs
- z00z_crypto/tari/transaction_components/src/transaction_components/covenants/covenant.rs

What is counted as “features_and_scripts_byte_size”:
- `WalletOutput::features_and_scripts_byte_size()` returns:
	- `features.serialized_size + script.serialized_size + covenant.serialized_size`
- This is the canonical byte accounting used by `TransactionBuilder` when estimating fees.

How OutputManager estimates output bytes (to drive `select_utxos` fee loop):
- `prepare_transaction_to_send(...)` computes:
	- `round_up_features_and_scripts_size(recipient_features + recipient_script + recipient_covenant)`
- For multi-output internal txs (`create_transaction_with_outputs_internal`) it iterates outputs and sums:
	- `Σ round_up_features_and_scripts_size(features + covenant + script)`
- `select_utxos(...)` assumes it receives a *already normalised* total (i.e. per-output rounded then summed).

So for recipient outputs, the fee/weight model is consistent across layers:
- OutputManager uses the same (features + script + covenant) accounting and the same 16-byte rounding as TransactionBuilder’s `WalletOutput::features_and_scripts_byte_size()` path.

Small mismatch: change-output fee estimator in TransactionBuilder omits covenant size
- In `TransactionBuilder::add_change_if_required` the temporary change-size estimate is:
	- `OutputFeatures::default().serialized_size + temp_script.serialized_size`
	- then `round_up_features_and_scripts_size(...)`
- But the actual change output built later includes `Covenant::default()`.
- Empty covenant serialization still writes a varint length (0), so it is not necessarily “0 bytes” (it is at least 1 byte).
- With 16-byte rounding, omitting the covenant length can under-estimate the rounded size by up to 16 bytes (i.e. up to 1 gram), depending on the pre-rounding remainder.

Practical impact:
- This only affects the “is a change output worth it?” boundary inside `add_change_if_required` and the computed `change_fee`.
- The discrepancy is tiny (≈ 1 gram), but it is a real correctness footgun if you’re trying to bit-for-bit replicate Tari fee behavior.

Code anchors:
- OutputManager recipient sizing + rounding: z00z_crypto/tari/wallet/src/output_manager_service/service.rs#L949-L977
- OutputManager change default sizing includes covenant: z00z_crypto/tari/wallet/src/output_manager_service/service.rs#L1950-L1968
- WalletOutput byte accounting includes covenant: z00z_crypto/tari/transaction_components/src/transaction_components/wallet_output.rs#L576-L580
- Builder change estimator (missing covenant): z00z_crypto/tari/transaction_components/src/transaction_builder/builder.rs#L477-L517
- Builder actual change output uses `Covenant::default()`: z00z_crypto/tari/transaction_components/src/transaction_builder/builder.rs#L651-L705
- Covenant serialization writes varint length: z00z_crypto/tari/transaction_components/src/transaction_components/covenants/covenant.rs#L62-L73

### Z00Z Implementation

What to reuse (idea-level):
- Fee estimation must be based on the *exact* same byte accounting as the final tx, especially for change.

How to map into existing Z00Z code:
- Define one Z00Z function for output “aux bytes” accounting (scripts/constraints/memo/etc.) and reuse it in:
	- the `FeeEstimator` implementation
	- the `TxAssembler` implementation (change decision)
	- the `LocalVerifier` implementation
- Ensure the temporary change-output estimator includes all components that the real change output will contain.

If Z00Z introduces “constraints/covenants”:
- Make sure empty/default constraints still have a defined encoding size and include it in estimates.

#### Implementation Checklist (Finding 25)

**DoD:** Unified byte accounting is used for estimation and building (including empty constraint encoding), and estimate==built boundary tests pass.

- [ ] Define a single Z00Z function for output auxiliary byte accounting:
	- [ ] features
	- [ ] script/spend conditions
	- [ ] constraints/covenants
	- [ ] memo/recovery payload encoding
- [ ] Ensure change-output estimation uses the exact same accounting as real change output construction:
	- [ ] include empty/default constraint encoding size
	- [ ] apply the canonical 16-byte rounding rule
- [ ] Wire this function into:
	- [ ] `FeeEstimator`
	- [ ] `TxAssembler` (change decision)
	- [ ] `LocalVerifier` (post-build validation)
- [ ] Add tests:
	- [ ] “estimated bytes == built bytes” for change output in representative cases
	- [ ] boundary test where omitting a 1-byte field would change the 16-byte rounding result

---

## Finding 26: Transaction broadcast size guard is bincode size vs RPC max-frame (with a large margin)

Where:
- z00z_crypto/tari/wallet/src/transaction_service/protocols/mod.rs

What it does:
- Before broadcast (and in a few other “tx becomes completed” paths), the wallet checks that the negotiated/completed tx can fit in an RPC frame.
- Implementation:
	- bincode-serializes the transaction into a `Vec<u8>` (`serialize_into(&mut buf, transaction)`)
	- compares `buf.len()` to `rpc::RPC_MAX_FRAME_SIZE - SIZE_MARGIN`
	- with `SIZE_MARGIN = 10 KiB + 2 MiB` (comment: reserve space for frame overhead and coinbases; aim to keep single tx under ~4MB).

Migration takeaway:
- “TransactionTooLarge” is not based on weight/grams; it’s an RPC transport constraint using bincode encoding.
- If Z00Z reproduces Tari transaction broadcasting, you likely want a similar preflight guard at the boundary where tx becomes “broadcastable”.

Code anchors:
- `check_transaction_size`: z00z_crypto/tari/wallet/src/transaction_service/protocols/mod.rs#L25-L74

### Z00Z Implementation

What to reuse (idea-level):
- A hard “tx too large to broadcast” guard belongs at the boundary where tx becomes broadcastable.

How to map into existing Z00Z code:
- Add a size preflight in the wallet broadcast path (right before submit):
	- serialize using Z00Z’s canonical codec (`z00z_utils::codec`)
	- compare against transport max-frame (from `RpcTransport` config) minus a margin
- Surface a dedicated wallet error (e.g. `TxTooLarge`) and fail early before network calls.

Invariant test recommendation:
- Add a test that fixes the transport max-frame to a small value and asserts:
	- a tx just under the limit passes the preflight
	- a tx just over the limit fails with `TxTooLarge`

Avoid transport coupling:
- Keep the guard parameterized by the transport’s frame limit; don’t bake “RPC max frame” constants into tx logic.

#### Implementation Checklist (Finding 26)

**DoD:** Broadcast size preflight uses canonical serialization and transport limits, returns a dedicated error, and under/over-limit tests pass.

- [ ] Implement `WalletService::check_tx_broadcast_size(tx)` preflight:
	- [ ] uses Z00Z canonical serialization (`z00z_utils::codec`)
	- [ ] compares against `transport.max_frame_size() - margin`
	- [ ] margin is configurable and documented
- [ ] Ensure the size guard runs:
	- [ ] before any network calls
	- [ ] before persisting “broadcasted” state
- [ ] Define a dedicated error type:
	- [ ] includes `actual_bytes`, `max_allowed_bytes`, and `codec_id`
- [ ] Add tests:
	- [ ] tx just under limit passes
	- [ ] tx just over limit fails with `TxTooLarge`
	- [ ] codec change (if any) is reflected in the guard inputs deterministically
