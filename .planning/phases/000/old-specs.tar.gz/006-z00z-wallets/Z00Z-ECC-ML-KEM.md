# Z00Z ECC Wallets — Whitepaper 3

Status: FROZEN CORE (v1)

Date: 2026-01-17

---

## Table of Contents

1. [Introduction and Goals](#1-introduction-and-goals)
2. [Glossary and Canonical Definitions](#2-glossary-and-canonical-definitions)
3. [Core Protocol Model](#3-core-protocol-model)
4. [Crypto Suites and Dependencies](#4-crypto-suites-and-dependencies)
5. [Data Structures](#5-data-structures)
6. [Flows: Receive and Spend](#6-flows-receive-and-spend)
7. [Proofs: TxProof vs CheckpointProof](#7-proofs-txproof-vs-checkpointproof)
8. [Offline Forwarding and Bundles](#8-offline-forwarding-and-bundles)
9. [Security Goals and Threat Model](#9-security-goals-and-threat-model)
10. [Implementation Checklist](#10-implementation-checklist)

---

## 1. Introduction and Goals

### 1.1 What this document is

This whitepaper specifies a privacy-oriented UTXO-like system with **addressless ownership**.

Design constraint (this drives the entire ownership model): in a non-interactive receive flow, the sender inevitably knows everything they generated/encrypted (including `ss` from KEM Encaps, and even `s_out` if sender-chosen). Therefore, spend authority MUST NOT be bound to `ss` alone or `s_out` alone; otherwise the sender could steal. The solution is: **ownership = (coin secret) + (receiver wallet secret)**, where the sender does not know the receiver secret.

### 1.2 Core goals

- **No stable on-chain recipient identifier** (addressless).
- **Ownership proven in ZK** (no on-chain signatures required for ownership).
- **Offline forwarding support** (Alice → Bob → Charlie/Daniel chains can occur offline).
- **Post-quantum safety** (ownership remains secure even if ECC is broken).

### 1.3 Summary (what you get)

- Non-interactive receive: receiver publishes only a discovery card.
- No on-chain `owner_id` ⇒ no “address” in the public log.
- Sender cannot steal outputs even knowing `ss` and even knowing `s_out` (spend authority requires `receiver_secret`).
- No trusted setup assumption for proof system: TxProof + CheckpointProof are FRI/STARK-class.
- `ss` can be a private witness without proving Decaps, because `ss` is bound to `owner_tag` as a hash preimage.

### 1.4 Non-goals

- Final choice of STARK/FRI system and concrete circuits.
- Final choice of amount commitments and range proof system (they may be ECC-based; this whitepaper’s post-quantum goal is about **anti-theft spend authority**, not necessarily amount privacy under QC).
- Network-layer anonymity (Tor/I2P) requirements.
- Standardizing QR/BLE transport framing and relay protocols beyond the versioned object formats described here.

---





## Модуль `delivery` в `wallets/src/core/`: структура файлов и назначение

Ниже — практичная раскладка, чтобы логика **выдачи Receive Code / доставки секрета / сборки tx_package / сборки bundle** жила в одном месте и не расползалась по проекту.

Путь: `wallets/src/delivery/`

```
DeliveryManager
```

**Назначение**: выпускать и обрабатывать “карточки получения”, включая KEM и handle/tag.

Что внутри (логические подсекции, даже если это один struct):

- **Key material**
  - управление KEM keypair’ами (long-term / epoch / one-time)
  - derivation из seed (BIP39/HD через HKDF), если нужно
- **Receive Code issuing**
  - `owner_handle = H(RID || receiver_secret || nonce)`
  - policy: TTL/nonce/rotation
- **Output building helpers** (sender-side)
  - encapsulate → `kem_ct, ss`
  - `owner_tag = H(TAG || owner_handle || ss)`
  - `enc_pack` AEAD
- **Coin recovery** (receiver-side)
  - decaps → `ss`
  - decrypt `enc_pack` → `coin_pack_plain`
- **Transport glue (optional)**
  - QR/BLE framing (или отдельно)

То есть **DeliveryManager = “non-address receiving”**.



---

### `wallets/src/core/delivery/mod.rs`

Точка входа в модуль.

- Объявляет подмодули (`pub mod …`).
- Реэкспортит публичные типы/функции (`pub use …`), чтобы внешний код импортировал из `wallets::delivery::*`.
- Никакой криптографии и логики — только “проводка”.

------

### `wallets/src/core/delivery/types.rs`

Общие типы и “контейнеры” wire-объектов.

Что держать здесь:

- Newtype-обёртки и базовые идентификаторы:
  - `OwnerHandle`, `OwnerTag`
  - `AssetId`, `TxDigest`, `LeafHash`
  - `KemPk`, `KemCt`, `SharedSecret` (если нужно как тип)
- Версионированные структуры данных (wire objects):
  - `ReceiveCodeV1` (receiver_card)
  - `TxPackageV1`
  - `BundleV1`
- Общие сериализации/десериализации (serde), если ты фиксируешь формат (CBOR/bincode).

Зачем: чтобы вся совместимость по версиям и типам была **централизована**.

------

### `wallets/src/core/delivery/receive_code.rs`

Всё, что связано с выдачей и проверкой “карточки получения” (receiver_card / Receive Code).

Тут должно быть:

- Структура `ReceiveCodeV1` (или re-export из `types.rs`, а тут только логика).
- `issue_receive_code(...)`:
  - создание `owner_handle`
  - привязка к `kem_pk` (публичный ключ доставки)
  - policy: one-time / ttl / nonce
- `validate_receive_code(...)`:
  - проверка версии, TTL, nonce/формата.

Важно:

- **Никаких секретов получателя внутри ReceiveCode.** Только `owner_handle` (хэш) и публичные поля.
- В этом файле **нет KEM/AEAD** — это отдельные подпакеты.

------

### `wallets/src/core/delivery/kem_delivery.rs`

“Доставка секрета” через ML-KEM: encaps/decaps и derivation ключей.

Тут лежит:

- `encapsulate(kem_pk) -> (kem_ct, ss)`
- `decapsulate(kem_sk, kem_ct) -> ss`
- KDF/derive функции:
  - `derive_pack_key(ss, context)` — ключ для `enc_pack`
  - (если нужно) derive для ускорителей/контекстов

Важно:

- Здесь должны быть **все domain separation constants** для derivation (`"Z00Z/PACK"`, `"Z00Z/TAG"` и т.д.), чтобы никто не размазал их по проекту.

------

### `wallets/src/core/delivery/owner_tag.rs`

Вся логика “не-адресного” владения: handle/tag derivation.

Содержимое:

- `derive_owner_handle(receiver_secret, [nonce])`
  - например: `H("RID" || receiver_secret || nonce)`
- `derive_owner_tag(owner_handle, ss)`
  - `H("TAG" || owner_handle || ss)`
- (опционально) `derive_tag16(...)` — короткий ускоритель поиска, если используешь.

Зачем: чтобы формулы были **в одном месте**, и TxProof/Wallet/Parser не начали расходиться.

------

### `wallets/src/core/delivery/coin_pack.rs`

Упаковка/распаковка монеты: `enc_pack` (AEAD).

Тут должно быть:

- `CoinPackPlain` (например: `s_out`, `amount`, `r_out`, `serial_id`, опциональные поля)
- Каноническое кодирование (важно для совместимости).
- `encrypt_pack(ss, leaf_context, coin_pack_plain) -> enc_pack`
- `decrypt_pack(ss, leaf_context, enc_pack) -> coin_pack_plain`

Критично:

- AEAD **обязан** использовать **Associated Data (AD)**, прибитое к leaf’у
  (например `asset_id`, `owner_tag`, `kem_ct`, `serial_id` или `leaf_hash`).
  Иначе можно “переприклеивать” пакеты между выходами.

------

### `wallets/src/core/delivery/tx_package.rs`

“Оффлайн-посылка”, которую sender отдаёт receiver (и которую потом может опубликовать любая сторона).

Тут должно быть:

- `TxPackageV1`:
  - полный tx (или канонический байтовый блоб tx)
  - `receiver_out_index` (какой output предназначен получателю)
  - удобные зеркальные поля для быстрого “это моё?” (например `kem_ct`, `owner_tag` этого output)
- Хелперы:
  - `make_tx_package(tx, receiver_out_index)`
  - `verify_tx_digest_canonical(...)`
  - `verify_output_matches_receive_code(...)` (минимальные проверки перед тем как принять пакет)

------

### `wallets/src/core/delivery/bundle.rs`

Сборка bundle и работа с ancestors/зависимостями для offline-DAG.

Содержимое:

- `BundleV1` = список `TxPackageV1` (+ опционально deps-таблица).
- Алгоритмы:
  - построение dependency graph (кто тратит чей `asset_id`)
  - topo-sort
  - `compute_min_ancestor_closure(...)` (минимальный набор предков)
- Проверки целостности:
  - дубли транзакций
  - отсутствующие предки
  - циклы в DAG
  - конфликтующие траты внутри bundle (если ты хочешь ловить это до агрегатора)

Важно: здесь **нет доступа к chain state** — только структура и локальные правила.

------

### `wallets/src/core/delivery/transport.rs`

Только транспорт: QR/BLE упаковка/фрейминг/чанкинг.

Здесь:

- Фрейминг сообщений:
  - типы сообщений: `RECEIVE_CODE`, `TX_PACKAGE`, `BUNDLE`, `ACK`
  - `msg_id`, `part_index/total`, checksum
- Кодек:
  - практично: `CBOR + zstd + base64url`
  - QR: разбиение на части, склейка, контроль целостности
  - BLE: адаптация под MTU (если надо)

Ключевое правило: **никакой криптосемантики** — только “как донести байты”.

------

### `wallets/src/core/delivery/errors.rs`

Единый `DeliveryError` для всего модуля.

Примеры вариантов:

- `InvalidReceiveCode`
- `KemError`
- `PackDecryptFailed`
- `InvalidOwnerTag`
- `InvalidTxPackage`
- `BundleMissingAncestor`
- `BundleHasCycle`

Плюс `type Result<T> = std::result::Result<T, DeliveryError>;`.

------

## Опционально (если хочешь ещё жёстче порядок)

Если чувствуешь, что домены/кодирование начнут расползаться:

- `wallets/src/delivery/constants.rs` — все строковые домены, фиксированные размеры, лимиты.
- `wallets/src/delivery/canonical.rs` — каноническое кодирование для `tx_digest`, `leaf_hash`, AD.

------

## Рекомендуемый публичный API (что “торчит наружу”)

Чтобы другие части кошелька не лазили в детали:

- `issue_receive_code(...) -> ReceiveCodeV1`
- `build_output_from_receive_code(...) -> (utxo_leaf, enc_pack)`
- `recover_coin_from_leaf(...) -> CoinRecord`
- `make_tx_package(...) -> TxPackageV1`
- `build_bundle(...) -> BundleV1`

Если хочешь — набросаю это же в виде Rust `pub fn` сигнатур (без реализации), чтобы dev мог сразу начать писать код строго по контрактам.

---







Да, **BIP-32/39/44 всё ещё релевантны**, но **не “для KEM как такового”**, а как **стандартный способ детерминированно получать ключи кошелька**, в том числе **KEM-ключи** и любые другие (ECC, PQ, симметрические).

### Как правильно думать

- **BIP-39**: как ты получаешь *master seed* из мнемоники.
- **BIP-32**: как из master seed получать много разных ключей/секретов по путям (HD-деривация).
- **BIP-44**: просто стандартная “схема путей” (coin_type/account/change/index), чтобы кошельки были совместимы и предсказуемы.

**KEM** (ML-KEM) — это отдельный тип ключей. Его можно:

- либо генерировать случайно и хранить,
- ==либо **детерминированно** “выпекать” из BIP-32/BIP-39 seed через KDF (это обычно удобнее для backup/restore),==
- либо делать оба (master → root, от него одноразовые/эпохальные).

------

## Что важно: BIP-32 “по определению” про ECC, а не про ML-KEM

Классический BIP-32 определяет HD-деривацию через **secp256k1** (chain code, child key derivation, hardened/non-hardened). Для ML-KEM “родной” BIP-32 деривации не существует.

Но это **не проблема**: тебе нужен не “BIP-32 для ML-KEM”, а:

### ✅ “BIP32-style key hierarchy” (иерархия по путям) + KDF

То есть:

- путь остаётся BIP-44-подобным (как идентификатор ветки),
- ключи для ML-KEM получаются через **HKDF** от master seed + домен + путь.

------

## Рекомендованная схема для твоего `delivery` (KEM keys)

### 1) Seed

- `seed = BIP39(mnemonic, passphrase)` — стандартно.

### 2) Доменное разделение (обязательно)

- `info = "Z00Z/KEM" || chain_id || bip44_path_string`

### 3) Получение “KEM seed material”

- `kem_ikm = HKDF(seed, salt="Z00Z", info=info, L=32..64)`

### 4) KEM keypair

- `kem_keypair = ML-KEM.KeyGen( kem_ikm )`
  (или если библиотека не даёт KeyGen из seed — тогда делаешь deterministic CSPRNG из `kem_ikm` и кормишь им KeyGen)

### Что это даёт

- Восстановление кошелька из мнемоники восстанавливает и KEM-ключи.
- Можно иметь разные ветки:
  - долговременный inbox-ключ,
  - “эпохальные” ключи,
  - одноразовые receive-коды.

------

## Нужно ли соблюдать BIP-44 пути буквально?

Если ты хочешь совместимость/внятность — да, **как “метки веток”**.

Пример (не стандарт, но понятно):

- `m/44'/Z00Z'/0'/0/epoch` для epoch-KEM
- `m/44'/Z00Z'/0'/1/i` для одноразовых receive codes
- `m/44'/Z00Z'/0'/2/notify` для inbox/notify

Главное:

- **hardened** там, где нельзя допустить утечку “родителя” при компромете потомка.
- не смешивать домены: `Z00Z/KEM`, `Z00Z/ECC`, `Z00Z/SYM`.

------

## Практические caveats (важные)

- **Не пытайся применять классический BIP-32 child derivation напрямую к ML-KEM ключам.** Это другое пространство ключей.
- **Одноразовые receive codes** лучше делать не “из BIP-44 index” бесконечно, а через:
  - epoch-ключи (меняются раз в N минут/часов), или
  - truly random одноразовые, но тогда нужен локальный storage.
- Если тебе важна “compatibility with other wallets” — BIP-44 coin_type для Z00Z всё равно будет “твоим”, но структура путей остаётся узнаваемой.

------

## Короткий ответ на твой вопрос

- **Да**, BIP-39/32/44 релевантны как фундамент кошелька и **как способ получить детерминированные KEM-ключи**.
- **Нет**, они не дают “готовую деривацию ML-KEM” — для этого нужен **KDF-слой**, где путь просто входит в `info`.

Если хочешь — дам конкретный **path layout** для Z00Z (какие ветки для: spending keys, receiver_secret, KEM epoch keys, notify keys) и правила rotation/backup так, чтобы не было линковки и не было “key reuse” между доменами.

---







## 2. Glossary and Canonical Definitions

### 2.1 Core secrets and values

- `receiver_secret`: long-term wallet secret (never published).
- `owner_handle = H("Z00Z/RID" || receiver_secret)`: public off-chain handle derived from `receiver_secret`.
- `(kem_ct, ss) = Encaps(kem_pk)`: KEM ciphertext + shared secret.
- `owner_tag = H("Z00Z/TAG" || owner_handle || ss)`: on-chain ownership anchor.

Mini-glossary:

- `receiver_secret` — receiver wallet secret (never published)
- `owner_handle = H("Z00Z/RID" || receiver_secret)` — public off-chain receiver handle (may appear in the discovery card)
- `owner_tag = H("Z00Z/TAG" || owner_handle || ss)` — the only public ownership anchor placed in a leaf
- `tx_digest` — canonical tx hash (see below)
- `asset_id` — canonical UTXO leaf key

### 2.2 Canonical identifiers

- `tx_digest`: canonical transaction digest.
- `asset_id`: canonical UTXO leaf key.

Important: in the frozen core, `asset_id` is NOT computed as `H("ASSET" || s_out)`. The secret `s_out` lives inside the encrypted pack and is not an on-chain identifier.

### 2.3 Canonical hashing rules

All hashes MUST use domain-separated canonical encoding.

- `owner_handle = H("Z00Z/RID" || receiver_secret)`
- `owner_tag = H("Z00Z/TAG" || owner_handle || ss)`
- `tx_digest = H("Z00Z/TXID" || canonical_encode(tx_header, inputs, outputs_without_asset_id_and_proofs))`
- `asset_id = H("Z00Z/UTXO" || tx_digest || out_index || serial_id || C_amount || owner_tag || kem_ct)`

---

## 3. Core Protocol Model

### 3.1 Ownership core (frozen)

This document **fixes one protocol core**:

- **Ownership core = `owner_tag + witness`** (ownership proven in ZK; no on-chain signatures required).
- Other ownership models (e.g., signature-based schemes) are out of scope for this frozen core.

The key reason for this choice: the sender knows `ss` (from Encaps) and may even know `s_out` (if sender-chosen), so spend authority must depend on the receiver wallet secret.

### 3.2 Proof boundary (frozen)

We choose **Option Y (offline-DAG friendly)**:

- **TxProof proves:** ownership + value conservation + output well-formedness.
- **CheckpointProof proves:** membership/unspent checks + correct `prev_root → new_root` transition + no double spend within the checkpoint.

### 3.3 Why this is safe

- Sender knows `ss` (from KEM Encaps), but ownership is **not** `ss`.
- Ownership requires `receiver_secret`, which sender does not know.
- Even if ECC is broken, `receiver_secret` remains secure (hash-based).

---

## 4. Crypto Suites and Dependencies

### 4.1 Recommended baseline suite (v1)

- Hash: SHA-256 (domain separated).
- KDF: HKDF-SHA256.
- AEAD: XChaCha20-Poly1305.
- KEM: ML-KEM-768 (FIPS 203).

### 4.1.1 Domain separation strings (MUST)

All hashing/KDF steps MUST be domain separated.

```yaml
domains:
  RID:   "Z00Z/RID"
  TAG:   "Z00Z/TAG"
  PACK:  "Z00Z/PACK"
  ASSET: "Z00Z/ASSET"
  TXID:  "Z00Z/TXID"
  LEAF:  "Z00Z/LEAF"
```

Example (implementation-facing, not consensus-critical):

```yaml
crypto_suite_v3:
  v: 3
  kem: "ML-KEM-768"
  kdf: "HKDF-SHA256"
  aead: "XChaCha20-Poly1305"
  hash: "SHA-256"
  domains:
    RID:   "Z00Z/RID"
    TAG:   "Z00Z/TAG"
    PACK:  "Z00Z/PACK"
    ASSET: "Z00Z/ASSET"
    TXID:  "Z00Z/TXID"
    LEAF:  "Z00Z/LEAF"
    T16:   "Z00Z/T16"
```

### 4.2 TxProof crypto (why it is not “Ristretto-based”)

TxProof is a FRI/STARK-class proof: arithmeticization of computation over a finite field + hash/Merkle commitments to the trace + FRI low-degree testing.

ECC groups (Ristretto or otherwise) may appear only as *objects you decide to verify* (e.g., Pedersen commitments or Bulletproofs). The proof system itself is “field + hashes”, not an ECC signature scheme.

If amount privacy uses Pedersen/Bulletproofs (ECC), validators have two practical options:

- Variant A (typical): verify Bulletproofs separately (classically), keep TxProof lighter.
- Variant B (heavy): verify ECC relations inside TxProof (expensive trace).

### 4.3 Rust crates (recommendations)

- Hash: `sha2` or `sha3`.
- KDF: `hkdf`.
- AEAD: `chacha20poly1305`.
- KEM: Prefer a FIPS-203 aligned implementation (e.g., `oqs` or another audited ML-KEM crate).

---

## 5. Data Structures

### 5.1 Receiver discovery card

```yaml
receiver_card_discovery_v1:
  format_version: 1
  kem_suite_id: "ML-KEM-768"
  owner_handle: bytes32
  kem_pk: bytes
  scan_pk_ecc: bytes_optional
  inbox_endpoints: [string]_optional
  notify_policy: "best_effort"|"none"|"required"_optional
```

### 5.1.1 Inbox notification keys (notify-only inbox)

Inbox is a discovery accelerator: it carries only a pointer/receipt, not coin ownership.

```yaml
receiver_card_v1:
  owner_handle: H("Z00Z/RID" || receiver_secret)
  kem_pk: "<ML-KEM pk>"
  inbox_pk: "<X25519 or ML-KEM pk for inbox notifications>"
  inbox_endpoint: "<tor/i2p/http relay address>"
```

Example (more explicit, recommended for interop):

```yaml
receiver_card_v3:
  v: 3
  crypto_suite_id: "crypto_suite_v3"
  owner_handle: H("Z00Z/RID" || receiver_secret)   # 32B, off-chain public
  kem_pk: "<ML-KEM-768 public key>"
  inbox:
    pk: "<notify-only pk>"_optional
    endpoint: "<relay address>"_optional
    policy: "best_effort"|"none"|"required"_optional
  hints:
    scan_pk_ecc: "<optional ECC scan pubkey>"_optional
  card_nonce: "<16..32B random>"
  expires_at: "<unix_ts>"_optional
```

Minimal view:

```yaml
receiver_card_discovery_v1:
  owner_handle: H("Z00Z/RID" || receiver_secret)   # 32B, off-chain public
  kem_pk: "<ML-KEM public key>"
  scan_pk_ecc: "<optional ECC scan pubkey>"   # optional: speed up local discovery
```

### 5.2 UTXO leaf

```yaml
utxo_leaf_v2:
  format_version: 2
  crypto_suite_id: "crypto_suite_v1"
  asset_id: bytes32
  serial_id: u32
  C_amount: bytes
  range_proof: bytes
  kem_ct: bytes
  owner_tag: bytes32
  enc_pack: bytes
  tag16: bytes2_optional
```

Note: `tag16` may be used as an optional scanning accelerator:

```yaml
tag16 = Trunc16( H("Z00Z/T16" || ss || asset_id) )
```

`tag16` is a hint only and MUST NOT be used as consensus-critical spend authority or as a stable address.

### 5.3 Coin pack (plaintext)

This is encrypted into `enc_pack`.

```yaml
coin_pack_plain_v1:
  s_out: bytes32
  amount: u64
  r_out: bytes32
  serial_id: u32
  # optional: memo, flags, etc
```

### 5.3.1 `enc_pack` binding (MUST)

The encrypted coin record in outputs is referred to as `enc_pack` in this document. It MUST be AEAD-encrypted with associated data (AD) bound to the leaf so it cannot be replayed or “re-attached” to a different output.

Normative key derivation:

```yaml
pack_key = HKDF(
  ikm = ss,
  salt = H("Z00Z/PACK" || asset_id),
  info = H("Z00Z/PACK" || chain_id || serial_id || asset_id)
)

leaf_ad = H("Z00Z/LEAF" || asset_id || owner_tag || kem_ct || serial_id)

enc_pack = AEAD_Encrypt(
  key = pack_key,
  plaintext = coin_pack_plain_v1,
  ad = leaf_ad
)
```

Receiver MUST reject the coin if decryption succeeds but any binding fields do not match (e.g., `owner_tag` mismatch), to prevent “poisoned coins”.

### 5.4 Transaction

Inputs carry `input_ref_v1` (see §7.1.1) so TxProof verification is well-defined.

```yaml
tx_v3:
  header:
    v: 3
    chain_id: u32
    nonce: u64
    fee:
      - serial_id: u32
        fee_amount: u64
  inputs:
    - input_ref_v1: <object>
  outputs:
    - utxo_leaf_v2: <object>
  proofs:
    tx_proof: bytes
  tx_digest: bytes32
```

### 5.5 Notify payloads (examples)

Notify ciphertext is *not* an address and must not be used as spend authority.

Sender computes:

- `notify_plain = { checkpoint_hint?, leaf_key = asset_id_out, optional memo_hash }`
- `notify_ct = ENC(receiver.inbox_pk, notify_plain)` (ECC+AEAD or ML-KEM+AEAD; delivery only)

and includes it:

```yaml
output_notify_v1:
  notify_ct: "<small ciphertext ~80..200B>"
```

Minimal inbox message format (after decryption):

```yaml
inbox_notify_v1:
  leaf_ref: "asset_id_out or (checkpoint,height,index)"
  checkpoint_hint: 12345
  memo_hash16: "hex16 optional"
```

### 5.6 Transaction (compact)

The on-chain transaction format is `tx_v3` (see §5.4). There is no signature-based spend field in this ownership core; spend authority is proven in `tx_proof`.

---

## 6. Flows: Receive and Spend

### 6.1 Non-interactive receive (Business Card)

1. Sender takes `receiver_card_discovery_v1`.
2. Computes `(kem_ct, ss) = Encaps(kem_pk)`.
3. Computes `owner_tag = H("Z00Z/TAG" || owner_handle || ss)`.
4. Chooses `s_out` randomly.
5. Builds `coin_pack_plain_v1` with `s_out` and other coin metadata.
6. Derives `pack_key` and `leaf_ad` as specified in §5.3.1.
7. Encrypts: `enc_pack = AEAD_Encrypt(pack_key, plaintext=coin_pack_plain_v1, ad=leaf_ad)`.
8. Builds output leaf public fields.
9. Computes `tx_digest` canonically over outputs with `asset_id` and proofs omitted, then computes each output `asset_id` from `tx_digest` and the output fields.

Why sender cannot steal even though sender knows `ss` (and may know `s_out`): spending requires proving ownership using the receiver wallet secret (`receiver_secret`) as a witness.

### 6.2 Receive-side validation (anti-poisoning)

Receiver algorithm upon discovering a candidate leaf:

1. Attempt `ss = Decaps(receiver_kem_sk, kem_ct)`.
2. Derive `k_pack` and decrypt `enc_pack`.
3. Extract `s_out`, `amount`, `serial_id`, etc.
4. **MUST** recompute ownership anchor:
  - `owner_handle = H("Z00Z/RID" || receiver_secret)`
  - `owner_tag_expected = H("Z00Z/TAG" || owner_handle || ss)`
  - Require `owner_tag_expected == owner_tag_leaf`.
5. Only then store the coin locally.

This check is mandatory: it prevents accepting “poisoned” coins that decrypt but are not actually spendable by this wallet.

### 6.3 Spending and transaction creation

Wallet spend algorithm:

1. Select inputs (coins) to spend.
2. For each input, prepare witness values:
   - `receiver_secret`
   - `ss` (from Decaps)
   - coin opening/metadata needed for value conservation / commitments.
3. Construct outputs (repeat receive creation, possibly including change).
4. Compute `tx_digest` canonically over outputs with `asset_id` and proofs omitted, then compute each output `asset_id` from `tx_digest` and the output fields.
6. Produce `tx_proof` that proves:
   - For each input leaf: knowledge of (`receiver_secret`, `ss`) such that `owner_tag` matches.
   - Value conservation per `serial_id` over commitments.
   - Output well-formedness constraints needed by consensus.

### 6.4 Roles (who verifies what)

Sender wallet:

- Encaps (ML-KEM)
- builds leaf fields (`owner_tag`, `enc_pack`, commitments, range proofs)

Receiver wallet:

- Decaps (ML-KEM) on `kem_ct`
- decrypts `enc_pack` to obtain `s_out` and coin metadata
- MUST validate that `owner_tag` matches this wallet (`receiver_secret`) before accepting
- builds TxProof with witness when spending

Aggregator / validator:

- verifies TxProof (FRI/STARK verifier)
- verifies range proof (if not included inside TxProof)
- applies state update (delete inputs, insert outputs)
- builds CheckpointProof (e.g., via recursion) for succinct verification

### 6.5 Diagram (delivery + proof pipeline)

```mermaid
flowchart TD
  subgraph Delivery["Coin delivery (KEM + encrypted pack)"]
    S[Sender wallet] --> K[ML-KEM Encaps to receiver kem_pk]
    K --> L[Build leaf: kem_ct owner_tag enc_pack commitments]
    L --> A[Aggregator includes leaf in state update]
    R[Receiver wallet] --> D[Decaps kem_ct]
    D --> U[Decrypt enc_pack and store coin secret]
  end

  subgraph Proofs["Proof pipeline (FRI)"]
    W[Wallet builds witness] --> P[Create TxProof with FRI]
    P --> B[Aggregator batches many tx proofs]
    B --> C[Recursive CheckpointProof with FRI]
    C --> V[Validators verify proof]
    V --> N[New state root accepted]
  end

```

### 6.6 Diagram (TX → aggregator → inbox notify)

```mermaid
sequenceDiagram
  participant S as Sender wallet
  participant A as Aggregator
  participant I as Inbox relay
  participant R as Receiver wallet

  S->>A: submit tx (TxProof, outputs, notify_ct)
  A->>A: verify TxProof (+ range proofs if separate)
  A->>A: include outputs into state
  A->>I: forward notify_ct
  R->>I: fetch notify_ct
  R->>R: decrypt notify_ct -> leaf_ref / asset_id_out
  R->>R: fetch leaf by ref (no full scan)
  R->>R: Decaps kem_ct -> ss, decrypt enc_pack -> coin secret
```

---

## 7. Proofs: TxProof vs CheckpointProof

### 7.1 TxProof (ownership + balance)

TxProof proves:

- For each input: knowledge of `receiver_secret` and `ss` such that `owner_tag` matches.
- Value conservation per `serial_id`.
- Output well-formedness.

Design note: TxProof does not need to prove Decaps. It is enough to prove knowledge of witnesses (`receiver_secret`, `ss`) consistent with the public `owner_tag` (hash preimage binding).

### 7.1.1 TxProof public inputs and `enc_pack_hash` (MUST)

TxProof MUST be bound to concrete input-leaf fields so witnesses cannot be “floating”. Membership of those fields in state is verified in CheckpointProof.

To avoid carrying full `enc_pack` inside TxProof, implementations MAY include only `enc_pack_hash = H(enc_pack)` as a public input.

```yaml
input_ref_v1:
  asset_id: hex32
  serial_id: u32
  C_amount: "<commitment>"
  owner_tag: hex32
  kem_ct: "<bytes>"
  enc_pack_hash: "H(enc_pack)"
```

TxProof statement sketch (membership is intentionally excluded):

```yaml
tx_proof_statement_b1:
  public:
    - inputs[*].asset_id
    - inputs[*].serial_id
    - inputs[*].C_amount
    - inputs[*].owner_tag
    - inputs[*].kem_ct
    - inputs[*].enc_pack_hash
    - outputs[*].(asset_id, serial_id, C_amount, owner_tag, kem_ct, enc_pack_hash, tag16)

  witness:
    - for each input i:
        receiver_secret_i
        ss_i
        s_in_i

  must_prove:
    - owner_handle_i = H("Z00Z/RID" || receiver_secret_i)
    - owner_tag_i == H("Z00Z/TAG" || owner_handle_i || ss_i)
    - balance constraints (per serial_id)
```

### 7.1.2 Fiat–Shamir transcripts (`merlin`) binding guidance

To prevent replay/malleability (e.g., moving a proof between transactions), the Fiat–Shamir transcript MUST be bound to the full public context.

At minimum, bind:

- `chain_id`
- `tx_version`
- `tx_digest` (or all public fields that define it)
- optional `prev_state_root` if you choose to bind TxProof to state
- all public inputs (e.g., `asset_id` list)
- all public outputs (commitments, `kem_ct`, `owner_tag`, etc.)
- `fee`
- a domain string like `"Z00Z/TXPROOF_V2"`

Pseudocode:

```text
t = Transcript("Z00Z/TXPROOF_V2")
t.append(chain_id)
t.append(tx_digest)
t.append(prev_state_root)
t.append(all_public_inputs)
c = t.challenge_scalar("chal")
... proof uses c ...
```

**Note:** Membership checks are **not** part of TxProof.

### 7.2 CheckpointProof (membership + state transition)

CheckpointProof proves:

- Each input `asset_id` exists in `prev_root` with the correct leaf value.
- No input is spent more than once within the checkpoint.
- The state transition from `prev_root` to `new_root` is correct.

CheckpointProof is produced per accepted batch (“checkpoint” == “block/slot” in typical systems).

Checkpoint header sketch:

```yaml
checkpoint_header_b1:
  height: u64
  prev_utxo_root: hex32
  new_utxo_root: hex32
  included_tx_digests_root: hex32     # optional but recommended
  checkpoint_proof: "<bytes>"
```

Normative claim (what the proof MUST establish):

```yaml
checkpoint_proof_statement_b1:
  public:
    - prev_utxo_root
    - new_utxo_root
    - list/commitment of applied operations:
        spent_inputs:  [ (asset_id, leaf_hash_or_fields) ... ]
        created_outputs:[ (asset_id, leaf_hash_or_fields) ... ]
    - included_tx_digests_root (if used)

  witness (built by aggregator from current state):
    - for each spent input: membership_proof_in_prev_root(asset_id, leaf_value)
    - for each created output: insertion/update witness (JMT/Merkle dependent)
    - intermediate hashes needed to recompute new_utxo_root

  must_prove:
    - each spent input exists in prev_utxo_root with EXACT leaf_value
    - new_utxo_root = Update(prev_utxo_root, delete spent_inputs, insert created_outputs)
    - spent_inputs.asset_id are all distinct (no double-spend inside checkpoint)
    - created/spent sets match the committed tx list (if included_tx_digests_root is used)
```

Intuition:

- TxProof says: “if this leaf exists in state, the true owner spends it”.
- CheckpointProof says: “this leaf DID exist in `prev_root`, and we DID delete it, and inserted the new outputs, producing `new_root`”.

Implementation model: CheckpointProof can be viewed as proving correct execution of a deterministic “Merkle update program” over a batch (membership and delete/insert along authenticated paths), without validators re-running the full update.

### 7.2.1 Merkle/JMT intuition: membership, delete, insert

Model the UTXO set as a map $M[k] = v$ authenticated by a root hash $R$ (Merkle, JMT, sparse Merkle, etc.).

- **Membership:** spending input key $k$ requires a path proving $M[k]=v$ under the current root: `VerifyInclusion(R, k, v, path)=true`.
- **Delete:** delete is an update setting $M[k] := \bot$ (empty) and recomputing the new root along the authenticated path.
- **Insert:** insert is an update setting $M[k_{new}] := v_{new}$ and recomputing the new root along a “non-member/empty” witness path (in sparse structures, non-membership is well-defined).

The important property: updating a Merkle/JMT root is local to the authentication path; it does not require recomputing the whole tree.

### 7.2.2 Program view (what the proof proves)

CheckpointProof proves that there exists a witness (paths + intermediate hashes) such that a deterministic update procedure starting from `R_old` yields `R_new`.

Pseudocode sketch (conceptual):

```text
R := R_old
for tx in batch_topo_sorted:
  verify_tx_proof(tx)                 # ownership/balance/well-formedness
  for inp in tx.inputs:
    assert merkle_inclusion(R, inp.k, inp.v, inp.path)
    R := merkle_update(R, inp.k, EMPTY, inp.path)
  for out in tx.outputs:
    assert merkle_nonmember_or_empty(R, out.k, out.path_empty)
    R := merkle_update(R, out.k, out.v, out.path_empty)
assert R == R_new
```

In a STARK/FRI system, the above “program” is represented as constraints; the proof shows that some witness satisfying those constraints exists.

### 7.2.3 Mini example: intermediate roots inside a bundle window

```yaml
state:
  R_current: R0

bundle:
  - tx1:
      inputs:
        - k: U0
          v: hash(U0)
          path: path_U0_under_R0
      outputs:
        - k: U1
          v: hash(U1)
          path_empty: path_U1_empty_under_R0_or_sparse
  - tx2:
      inputs:
        - k: U1
          v: hash(U1)
          path: path_U1_under_R1   # under the intermediate root!
      outputs:
        - k: U2
          v: hash(U2)
          path_empty: path_U2_empty_under_R1_or_sparse

checkpoint_proof_claim:
  given:
    R_old: R0
    batch: [tx1, tx2]
  prove:
    - inclusion(U0 in R0) ok
    - R1 = update(R0, delete U0, insert U1)
    - inclusion(U1 in R1) ok
    - R2 = update(R1, delete U1, insert U2)
  output:
    R_new: R2
```

This explains the “virtual window” rule: later txs in the bundle are validated against intermediate roots produced by earlier txs in the same bundle/checkpoint builder.

### 7.2.4 Offline double-spend cases (important distinction)

CheckpointProof prevents double spends in accepted history, but it does not make offline handoffs final.

- (A) Double spend **inside** a single published bundle/batch: prevented by the checkpoint builder rule “inputs are unique” and proved by CheckpointProof.
- (B) Double spend **relative to the world** while offline (someone else already spent the anchor UTXO online): detected at publish time because inclusion under `R_current` fails; the bundle is rejected (or deterministically partially accepted, depending on policy).

---

## 8. Offline Forwarding and Bundles

Offline forwarding enables chains like Alice → Bob → Charlie to happen **without immediate publication**, while still allowing Charlie (later) to submit everything needed.

### 8.1 Why ancestor packages are needed

If Bob spends an output Alice→Bob **before it is published**, then Charlie cannot publish Bob→Charlie unless Charlie also has the parent transaction that created Bob’s input.

Therefore, any offline handoff that creates an output which may be spent offline MUST also support forwarding the **transitive closure of dependencies** (“ancestors”).

### 8.2 `tx_package_v1` (portable TX object)

`tx_package_v1` is what the sender hands to the receiver in Mode A (and it is also the natural unit for DAG forwarding).

Goals:

- Receiver can verify “this output is mine”.
- Receiver can store the coin record locally.
- Either party can later submit the tx (dedupe by `tx_digest`).

```yaml
tx_package_v1:
  version: 1
  # correlation id from the off-chain handshake (optional)
  ctx_id: "hex16_optional"
  created_at: "u64_unix_optional"

  # full tx object (versioned; in this whitepaper it is `tx_v3`)
  tx: "<tx object>"

  # receiver-side view hints: how to locate "my" output and keep critical fields handy
  receiver_view:
    receiver_out_index: 0
    receiver_fields:
      kem_ct: "<bytes>"

  # optional outer packaging encryption
  packaging:
    outer_encryption:
      enabled: true
      # suggestion:
      # k_pkg = HKDF(ss, "Z00Z/TXPKG/v1") where ss is the KEM shared secret
      aead: "XChaCha20-Poly1305"
      nonce: "bytes24"
      ciphertext: "<bytes>"

  submit_hints:
    mode: "either_party_can_submit"
    recommended_deadline: "u64_optional"
```

### 8.3 Minimal ancestor set rule

Minimal set for publication = **transitive closure of dependencies by inputs**, until all remaining inputs are on-chain.

Operationally:

- For each input in a tx:
  - If it spends an output created by a tx that exists only as an offline `tx_package_v1`, include that parent `tx_package_v1`.
  - Repeat recursively until all inputs reference already-on-chain UTXOs.

This rule is what makes “>1 hop offline” possible.

### 8.4 `bundle_package_v1` (DAG container)

Charlie (or any holder) can submit all required packages to an aggregator as a single object.

```yaml
bundle_package_v1:
  version: 1

  bundle_id: "hex16"
  chain_id: "hex4"

  # anchor: last-known root for on-chain inputs referenced by the bundle
  anchor:
    prev_state_root: "hex32"

  # payload: all tx_package objects, including ancestors
  tx_packages:
    - "<tx_package_v1>"  # Alice->Bob
    - "<tx_package_v1>"  # Bob->Charlie
    - "<tx_package_v1>"  # Bob->Daniel (optional)

  # explicit dependencies so the aggregator can apply in topological order
  deps:
    - child_tx: "hex32"   # tx_digest (Bob->Charlie)
      spends:
        - parent_tx: "hex32"     # tx_digest (Alice->Bob)
          parent_out_index: 0

  submission:
    can_submit_by: "any_holder"  # aligns with Mode A dual-submission
    dedupe_key: "tx_digest"      # aggregator deduplicates by tx_digest
```

### 8.5 Aggregator acceptance rules (offline DAG window)

To support offline chains, an aggregator MUST implement a “package acceptance” policy:

- Aggregator MUST topologically sort `deps`.
- Aggregator MUST apply `tx_packages` in that order.
- Within this virtual bundle window, outputs created by earlier txs MUST be treated as available inputs for later txs.
- Aggregator MUST deduplicate by `tx_digest`.
- Aggregator MUST reject conflicting spends (within the bundle and against the current on-chain state).

Note: this does not eliminate the fundamental offline limitation: Bob can still double spend elsewhere while offline. Bundles only make offline forwarding publishable; they cannot magically provide online freshness.

### 8.5.1 Detailed aggregator algorithm

Mempool layer:

1. Unpack bundle → obtain candidate tx list.
2. For each tx:
   - canonically compute/verify `tx_digest`
   - dedupe: if `tx_digest` already seen → ignore.

Checkpoint builder layer (conceptual steps):

- Build a dependency graph inside the chosen candidate set:
  - edge `TxX → TxY` if `TxY` spends an output created by `TxX`.
  - if cycles exist: reject the cyclic txs (or the whole bundle in atomic mode).
- Topologically sort.
- For each tx in topo order:
  1) Verify TxProof (ownership/balance/well-formedness; no membership).
  2) For each input:
     - check existence in the current working UTXO map (starting from `prev_root` snapshot)
     - check the input-ref matches the leaf value (or matches `leaf_hash`)
     - ensure the same `asset_id` was not spent earlier in this checkpoint.
  3) Apply: delete inputs, insert outputs (updating the working root).
  4) Append to an operation log (oplog) for CheckpointProof:
     - `spent_inputs[] = (asset_id, leaf_value_or_hash)`
     - `created_outputs[] = (asset_id, leaf_value_or_hash)`
- Finalize:
  - compute `new_root`
  - build CheckpointProof over the oplog and required Merkle/JMT witnesses.

### 8.5.2 Bundle policy (SHOULD)

An implementation SHOULD specify a deterministic policy for partially-invalid bundles:

- `atomic_bundle`: if any tx fails → reject the whole bundle.
- `best_effort`: accept all txs that are valid and reachable by dependencies.

### 8.5.3 Conflict example: two spends of the same parent output

If two txs spend the same `asset_id`, an aggregator MUST include at most one.

```yaml
tx3:
  tx_digest: "0xTX3"
  inputs:
    - input_ref_v1:
        asset_id: "0xB_OUT"
        serial_id: 1
        C_amount: "<C_BOB>"
        owner_tag: "<owner_tag_BOB>"          # = H("Z00Z/TAG" || owner_handle_bob || ss_in)
        kem_ct: "<KCT_BOB>"
        enc_pack_hash: "H(<ENC_PACK_BOB>)"
  outputs:
    - utxo_leaf_v2: <object>
  proofs:
    tx_proof: "<PROOF_TX3>"
```

Two bundles that conflict (only one branch can be accepted):

```yaml
bundle_charlie:
  bundle_id: "0xBUNDLE_C"
  tx_packages: [tx1, tx2]

bundle_daniel:
  bundle_id: "0xBUNDLE_D"
  tx_packages: [tx1, tx3]
```

Aggregator includes either `{tx1, tx2}` or `{tx1, tx3}`, but not both, because both spend `0xB_OUT`.

### 8.6 Mini-example: Alice → Bob → Charlie (offline), then Charlie publishes

1) Bob receives from Alice (offline):

- Bob shows the off-chain handshake info (Mode A).
- Alice builds the tx and hands Bob `tx_package_v1`.

1) Bob pays Charlie without internet:

- Charlie provides his handshake info.
- Bob builds Bob→Charlie as `tx_package_v1`.
- Bob forwards Charlie:
  - `tx_package(Bob→Charlie)`
  - plus ancestor `tx_package(Alice→Bob)` (because Bob→Charlie spends that output).

1) Charlie returns online:

- Charlie submits `bundle_package_v1` containing both packages.
- Aggregator applies them topologically and deduplicates by `tx_digest`.

### 8.7 Larger DAG example

Worked example for DAG forwarding and conflict handling.

Receiver card (Bob → given to Alice offline):

```yaml
bob_receiver_card_001:
  v: 3
  crypto_suite_id: "crypto_suite_v3"
  owner_handle: "0x9b2a...32bytes"
  kem_pk: "0xKEMPK...768"
  card_nonce: "0x1111...32bytes"
  expires_at: 1760000000
```

Tx1: Alice → Bob (creates Bob output):

```yaml
tx1_alice_to_bob:
  tx_v3:
    header:
      v: 3
      chain_id: 1
      nonce: 1
      fee:
        - serial_id: 1
          fee_amount: 10
    inputs:
      - input_ref_v1:
          asset_id: "0xAAAA...alice_input"
          serial_id: 1
          C_amount: "<C_ALICE>"
          owner_tag: "<owner_tag_ALICE>"
          kem_ct: "<KCT_ALICE>"
          enc_pack_hash: "H(<ENC_PACK_ALICE>)"
    outputs:
      - utxo_leaf_v2:
          format_version: 2
          crypto_suite_id: "crypto_suite_v3"
          asset_id: "0xB0B0...assetid"
          serial_id: 1
          C_amount: "<commitment>"
          range_proof: "<range_proof>"
          kem_ct: "<mlkem_ct>"
          owner_tag: "<owner_tag_BOB>"
          enc_pack: "<aead_ct>"
          tag16: "0x1a2b"_optional
    proofs:
      tx_proof: "<fri_proof>"
    tx_digest: "0xTX1..."
```

Tx2: Bob → Charlie spends the Bob output from Tx1 (Charlie gives his receiver card offline).

Tx3: Bob → Daniel may attempt to spend the same Bob output; this conflicts and MUST be rejected by an aggregator (either within a bundle window or against current state).

### 8.8 Mermaid diagrams

```mermaid
sequenceDiagram
  participant A as Alice wallet
  participant B as Bob wallet
  participant AG as Aggregator
  participant V as Validators
  participant D as Daniel wallet

  Note over B: Bob shows receiver_card offline (QR/BLE)
  A->>A: Encaps(kem_pk)->(kem_ct, ss)
  A->>AG: submit tx_v3 (outputs include kem_ct, owner_tag, enc_pack, proofs)
  AG->>AG: verify TxProof (+ range proofs)
  AG->>V: checkpoint_proof (FRI recursion)
  V->>V: verify checkpoint_proof
  Note over D: Daniel discovers outputs via inbox or scan

```

```mermaid
flowchart TD
  subgraph DAG["DAG of spends"]
    T1["Tx1: Alice→Bob"] --> T2["Tx2: Bob→Charlie"]
    T2 --> T3["Tx3: Charlie→Daniel"]
  end
```

```mermaid
flowchart TD
  subgraph Offline["Offline (QR/BLE)"]
    A[Alice] -->|Tx1| B[Bob]
    B -->|Tx2| C[Charlie]
    B -->|Tx3| D[Daniel]
    C --> PUBC[Charlie publishes later\nbundle = Tx1 + Tx2]
    D --> PUBD[Daniel publishes later\nbundle = Tx1 + Tx3]
  end

  subgraph Online["Online (Aggregator + Validators)"]
    PUBC --> AGG[Aggregator]
    PUBD --> AGG
    AGG -->|Verify TxProofs| VTX[TxProof verifier]
    AGG -->|UTXO membership| MEM[UTXO/JMT lookup]
    AGG -->|Apply state update| UPD[Delete inputs\nInsert outputs]
    UPD --> CP[CheckpointProof: FRI recursion]
    CP --> VAL[Validators verify]
    VAL --> ROOT[New UTXO root accepted]
  end

```

```mermaid
flowchart LR
  TX[TxProof] -->|proves| O[Ownership + Balance + Range]
  TX -. NO .-> M[Membership in root]
  CP[CheckpointProof] -->|proves| M2[Membership + Delete/Insert => new_root]

```

---

## 9. Security Goals and Threat Model

### 9.1 Security goals

- **Unstealable:** Sender cannot spend receiver’s coin, even though sender knows `ss`.
- **Non-addressability on-chain:** No stable recipient identifier exists on-chain.
- **Receiver safety:** Receiver must not accept “poisoned coins”.
- **Verifiability:** Validators can verify checkpoints without trusting aggregators.

Clarification (this distinction drives most design choices):

- **Unlinkability (privacy) is not the same as theft resistance (ownership/spend authority).**
- Post-quantum compromise of ECC MAY degrade unlinkability if ECC is used for scanning/stealth discovery, but MUST NOT enable theft if spend authority is not based solely on ECC secrets.

### 9.1.1 Unlinkability degradation model (QC)

We explicitly assume a future where ECC-based constructions may become retrospectively analyzable (QC). The protocol therefore aims for:

- On-chain data contains no stable receiver identifier (no `owner_id`, no stable `view_pk`).
- Spend authority remains secure under ECC compromise, because it is rooted in `receiver_secret` (hash preimage) rather than an ECC secret.

Important caveat: “one-time” outputs alone do not guarantee everlasting unlinkability if the one-time material is retroactively computable from a compromised long-term key (e.g., classic stealth scanning from a static `view_pk`).

### 9.2 Threat model

- **Passive chain observer:** reads all public chain data.
- **Active sender:** malicious sender can craft outputs.
- **Malicious aggregator:** can censor, reorder, or attempt to create invalid checkpoints.
- **Post-quantum / QC break of ECC:** assume ECC-based linkability may become possible.

### 9.3 Modes of operation (privacy vs UX)

Mode A — Interactive/Handshake:

- Sender and receiver exchange one-time parameters directly (online or offline: QR/BLE/Wi‑Fi Direct).
- Goal: maximize unlinkability by ensuring every payment uses fresh one-time parameters that are not derivable from a single public on-chain anchor.

Mode B — Non-interactive/Business-card:

- Sender uses a static discovery card and generates the output without contacting receiver.
- Privacy under classical assumptions is strong; under QC, privacy may degrade if the system relies on ECC scanning anchors.
- Theft resistance can still hold if spend authority is not based on ECC.

This document’s core is compatible with Mode B because ownership is a ZK statement tied to `receiver_secret` (not to ECC signatures).

---

## 10. Implementation Checklist

This section is normative. If you implement the system described in this whitepaper, the following requirements MUST hold.

### 10.1 Canonicalization and identifiers (MUST)

- `tx_digest` MUST be computed from a single, canonical encoding. Any ambiguity breaks deduplication, proof binding, and can enable replay/malleability.
- Output ordering MUST be deterministic: `out_index` is part of `asset_id`, so reordering outputs changes identifiers.
- `asset_id` MUST be computed exactly as specified in §2.3 and MUST NOT depend on any secret that is only inside `enc_pack`.

### 10.2 Receive-side anti-poisoning (MUST)

- A wallet MUST reject any leaf that decrypts successfully but fails the ownership-anchor check:
  - `owner_handle = H("Z00Z/RID" || receiver_secret)`
  - `owner_tag_expected = H("Z00Z/TAG" || owner_handle || ss)`
  - require `owner_tag_expected == owner_tag_leaf`

### 10.3 `enc_pack` binding (MUST)

- `enc_pack` MUST be AEAD-encrypted with AD bound to the leaf (see §5.3.1). Otherwise ciphertexts can be replayed/reattached across leaves.

### 10.4 Proof boundary (MUST)

- TxProof MUST prove ownership + conservation + output well-formedness.
- CheckpointProof MUST prove membership/unspent + correct `prev_root → new_root` transition + no repeated inputs within a checkpoint.

### 10.5 Optional scan tags / inbox (MUST/SHOULD)

- `tag16` (or any scan accelerator) MUST NOT become a stable address. A safe pattern is deriving it from secrets and per-tx context (see §5.2).
- Inbox notify is delivery/UX only; consensus validity MUST NOT depend on notify delivery.
- Version everything from day one (tx/leaf/package formats and crypto suites).

### 10.6 Offline non-finality (MUST understand)

Offline handoff cannot be made “final” at handoff time without online checks or trusted hardware. A payer can double-spend the same input via two different offline packages; only one branch can be accepted when published.

---
