Да — делаем 4 фазы “с умом”, и при этом **в каждой фазе ровно один SPEC**.

**Phase 1 — TRNASACTIONS-SPEC-2 (MVP: работает end‑to‑end в push‑режиме)**  
Спек: specs/006-z00z-wallets/TRNASACTIONS-SPEC-2.md  
Цель: “отправить → получить → подтвердить без скана”, владение = подпись по one‑time `p`.

- **1) Stealth‑ownership и восстановление `p`**
  - Реализовать формулы `R=r·G`, `s=H("z00z/stealth"||a·R||out_index)`, `P=B+s·G`, `p=b+s`.
  - DoD: кошелёк по `(P,R,out_index)` определяет “моё ли” и получает `p`.
- **2) Нормативный `asset_id`**
  - `asset_id = H("z00z/asset_id"||commitment||enc(P)||enc(R)||out_index||tx_salt)`.
  - DoD: детерминированность + тесты на каноничность `enc(P), enc(R)`.
- **3) Bundle (spends/creates/auth) + `bundle_hash` + подписи spends**
  - `bundle_hash = H("z00z/bundle"||canonical(bundle_without_auth))`.
  - Для каждого входа `i`: `msg_i = H("z00z/spend"||bundle_hash||i||asset_id_in_i)`, подпись `sig_i = Schnorr.Sign(p_in_i, msg_i)`.
  - DoD: валидатор может проверить каждую spend‑подпись по `leaf.P`.
- **4) payment_packet (push)**
  - Packet содержит `bundle_bytes` и данные outputs для получателя (как в спеке).
  - DoD: получатель импортит packet → делает pending coins.
- **5) Note encryption (только если суммы реально скрыты commitment’ом)**
  - `K = H("Z00Z_NOTE"||a·R||asset_id||out_index)`, AEAD(note) = `{amount, blinding, memo…}`.
  - DoD: получатель без скана узнаёт amount/blinding из packet.
- **6) Подтверждение через membership proof**
  - DoD: `pending → confirmed` по `prove_membership(asset_id, root@height)`.

---

**Phase 2 — ideas2-SPEC (hardening, чтобы не мигрировать болезненно позже)**  
Спек: specs/006-z00z-wallets/ideas2-SPEC.md  
Цель: укрепить boundary/секреты/хранилище и сделать “один правильный путь” для bytes/декодов.

- **1) AAD v2 (length‑prefix) + versioning**
  - Заменить NUL‑разделители на len‑prefixed части, завести версионирование.
  - DoD: AAD однозначен, готова стратегия backward‑compat/миграции.
- **2) Compact-at-rest, strict decode at boundary**
  - `.wlt`/RPC хранят compact bytes, core работает с typed.
  - DoD: единые `from_canonical_bytes` + длиновые guard’ы + нормализация ошибок.
- **3) Challenge injection (transcript discipline)**
  - Newtype `[u8;64]` challenge + единый helper + тесты.
  - DoD: нигде нет “случайного” вычисления challenge.
- **4) Secret hygiene**
  - Constant‑time сравнения для секретов, `Zeroize`, redacted Debug, decrypt→parse→wipe.
  - DoD: секреты не живут в памяти/логах дольше необходимого.
- **5) Builder/capabilities для key manager**
  - DI в одном месте, capability gating до вызовов.
  - DoD: UI/RPC не тащат проверки по всем углам.
- **6) Monotonic derivation state + recovery override policy**
  - DoD: курсоры не откатываются “тихо”.
- **7) Memory backend + contract tests**
  - DoD: одни и те же тесты гоняются на RedB и memory.

---

**Phase 3 — TRNASACTIONS-SPEC-2 (production-grade: валидатор/инварианты/receipts)**  
Спек: specs/006-z00z-wallets/TRNASACTIONS-SPEC-2.md  
Цель: “как у настоящего протокола”: строгие проверки, понятные receipts, устойчивость.

- **1) Полная логика “что проверяет валидатор”**
  - Membership входов, подписи spends, корректность creates, детерминированный state transition.
- **2) Commitments/range proofs/баланс (если протокол реально их требует)**
  - DoD: `Σ C_in == Σ C_out (+ fee)` и proof‑проверки там, где они нормативны.
- **3) Receipts и подтверждение включения**
  - Формат receipt, хранение, проверка, связь с height/root/proof.
- **4) Строгая state machine и повторные проверки**
  - Pending/confirmed/spent, ретраи/таймауты, (если релевантно) reorg‑handling.
- **5) Режимы публикации**
  - Зафиксировать режим по умолчанию (receiver broadcasts) и опциональный второй режим.

---

**Phase 4 — ideas2-SPEC (опциональные “дорогие” улучшения: perf/HW/дальняя эволюция)**  
Спек: specs/006-z00z-wallets/ideas2-SPEC.md  
Цель: делать только то, что имеет измеримый профит и/или нужно для будущих backend’ов (HW/remote).

- **1) Batch verify / MSM / ускоренные режимы**
  - Только если бенчмарки показывают выигрыш; разделение strict vs fast.
- **2) HW/FFI/device protocol (если реально появляется Ledger/secure enclave)**
  - Плоские ABI‑типы, versioned framing, строгий parsing.
- **3) Capabilities для разных signer backend’ов**
  - Явные запреты ветвей/операций до выполнения.
- **4) Дополнительные “contract snapshots” (bytes stability)**
  - Только для реально протокольных/хранилищных форматов.

Если хочешь — я следующей репликой разрежу **Phase 1** на “8 маленьких PR/коммитов” (каждый с DoD и местом в коде), чтобы ты мог идти линейно и всегда иметь рабочую сборку.