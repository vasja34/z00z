## Таблица методов/функций для UI mockup

Ниже — **полный список RPC method names, которые \*явно названы\* в `Z00Z_WALLETS_FOUNDATION.md`**.

## ✅ Полный набор RPC methods (явно перечисленные в документе)

| RPC method                           | Коротко для UI/UX                                   |
| ------------------------------------ | --------------------------------------------------- |
| `app.exit`                           | корректный выход (Exit button / quit flow)          |
| `app.settings`                       | настройки приложения (global settings)              |
| `asset.add`                          | добавить ассет (Add token/asset)                    |
| `asset.balance`                      | баланс (виджеты/хедер, refresh)                     |
| `asset.details`                      | расширенная инфа по ассету (карточка ассета)        |
| `asset.import`                       | импорт ассета в кошелёк                             |
| `asset.list`                         | список ассетов (портфель)                           |
| `asset.merge`                        | merge commitments (advanced/UTXO management UI)     |
| `asset.metadata`                     | метаданные ассета (ticker/decimals/…)               |
| `asset.receive`                      | receive flow (генерация receive address/commitment) |
| `asset.send`                         | отправка (send flow)                                |
| `asset.split`                        | split commitment (advanced UI)                      |
| `asset.staking`                      | staking                                             |
| `asset.swap`                         | swap UI                                             |
| `asset.unstaking`                    | unstake                                             |
| `backup.create`                      | создать бэкап (export/backup wizard)                |
| `backup.manager`                     | список/менеджмент бэкапов                           |
| `backup.restore`                     | restore wizard                                      |
| `backup.settings`                    | настройки бэкапа                                    |
| `key.derive`                         | derivation по HD path (advanced/dev tooling UI)     |
| `key.export_public`                  | экспорт публичного ключа (copy/share)               |
| `logging.settings`                   | настройки логирования (dev/settings)                |
| `network.settings`                   | настройки сети (network selector/config)            |
| `notifications.settings`             | настройки уведомлений                               |
| `tx.broadcast`                       | броадкаст/публикация в сеть (“Submit to network”)   |
| `tx.build`                           | сборка транзакции (preview/build step)              |
| `tx.cancel`                          | отмена pending (action в pending list)              |
| `tx.details`                         | детали транзакции (drill-down экран)                |
| `tx.estimate_fee`                    | оценка комиссии (send/swap/build)                   |
| `tx.export`                          | экспорт транзакций (CSV/JSON), шаринг               |
| `tx.history`                         | история транзакций (таблица/лента)                  |
| `tx.list_pending`                    | список pending (pending tab)                        |
| `tx.pending`                         | счётчик pending (badge/индикатор)                   |
| `tx.send`                            | отправка транзакции (submit)                        |
| `wallet.add`                         | добавить существующий (Import/Add wallet)           |
| `wallet.create`                      | создать кошелёк (wizard)                            |
| `wallet.delete`                      | удалить кошелёк (danger zone)                       |
| `wallet.export`                      | экспорт кошелька (encrypted export)                 |
| `wallet.import`                      | импорт кошелька (файл/бэкап), мастер восстановления |
| `wallet.import_seed(seed_phrase)`    | импорт seed-фразы для восстановления                |
| `wallet.list`                        | список кошельков (выбор/переключение)               |
| `wallet.lock`                        | lock (закрыть сессию)                               |
| `wallet.new_address`                 | сгенерировать новый receive-адрес (Receive → QR)    |
| `wallet.remove`                      | убрать кошелёк из приложения (detach)               |
| `wallet.rescan_blockchain()`         | рескан блокчейна при восстановлении (progress)      |
| `wallet.settings`                    | получить/обновить настройки кошелька                |
| `wallet.show_seed_phrase(wallet_id)` | показать seed-фразу (после unlock + warning)        |
| `wallet.unlock`                      | unlock (логин/пароль, старт сессии)                 |



---

### Events / подписки (тоже RPC-методы, явно добавленные)

| RPC method           | Коротко для UI/UX                                       |
| -------------------- | ------------------------------------------------------- |
| `wallet.subscribe`   | подписка UI на wallet events                            |
| `wallet.unsubscribe` | отписка                                                 |
| `asset.subscribe`    | подписка UI на asset events                             |
| `tx.subscribe`       | подписка UI на tx events                                |
| `wallet.event`       | server→client notification (пример нотификаций событий) |



------

## 🧩 Важные “functions/методы”, описанные в документе (не RPC, но напрямую подпирают UI)

Это полезно для UI mockup как “внутренние capability / backend actions”, но это **не JSON-RPC method names**:

| Компонент / Trait    | Ключевые методы (как в документе)                            | Зачем это UI                                        |
| -------------------- | ------------------------------------------------------------ | --------------------------------------------------- |
| `RpcTransport`       | `call(method, params)`                                       | единый транспорт для UI (local/wasm/remote)         |
| `WasmRpcClient`      | `new(worker_url)`, `call(...)`                               | подключение UI в браузере к воркеру                 |
| `KeyManager`         | `derive_key(chain, index)`, `derive_public_key(chain, index)` | derive/export/адреса/ключи (advanced)               |
| `AssetStore`         | `save_asset()`, `list_unspent()`, `mark_spent()`, `get_by_key_path()` | источники баланса/UTXO, рефреш, статус spent        |
| `AssetOwnership`     | `owns_asset(asset)`, `get_spending_key(asset)`               | “can spend?” / подготовка spend flow                |
| `AssetSelector`      | `select_assets(available, target, fee, rng)`                 | UX send: coin selection, ошибки insufficient funds  |
| `TransactionBuilder` | `add_input()`, `add_output()`, `with_fee()`, `build()`       | UX send: сборка tx, fee step, preview before submit |



| **RPC Метод / Функция**      | **Описание для UI/UX**                                       |
| ---------------------------- | ------------------------------------------------------------ |
|                              |                                                              |
| `wallet_create_seed`         | Генерация новой фразы (12/24 слов). Нужно рисовать сетку слов. |
| `wallet_restore_mnemonic`    | Форма ввода слов для восстановления доступа.                 |
| `wallet_encrypt_storage`     | Экран установки мастер-пароля/PIN-кода для защиты локальной БД. |
| `wallet_unlock`              | Модальное окно/экран логина (ввод пароля для доступа к приватному ключу). |
| `wallet_lock`                | Функция принудительного выхода и скрытия балансов.           |
| `wallet_change_password`     | Экран настроек безопасности: "Старый пароль -> Новый пароль". |
| `wallet_get_security_status` | Индикатор: зашифрован ли кошелек, включена ли биометрия.     |



| **RPC Метод / Функция**  | **Описание для UI/UX**                                    |
| ------------------------ | --------------------------------------------------------- |
| `account_get_public_key` | Отображение публичного ключа/public materials для внешнего аудита. |



| **RPC Метод / Функция** | **Описание для UI/UX**                                       |
| ----------------------- | ------------------------------------------------------------ |
| `tx_build_draft`        | "Черновик" транзакции: расчет сдачи и проверка возможности отправки. |
| `tx_estimate_fee`       | Слайдер комиссии: "Медленно (дешево) — Быстро (дорого)".     |
| `tx_sign`               | Экран финального подтверждения перед отправкой в сеть.       |
| `tx_get_qr_data`        | Генерация QR-кода для запроса платежа (сумма + адрес).       |



| **RPC Метод / Функция** | **Описание для UI/UX**                                       |
| ----------------------- | ------------------------------------------------------------ |
| `config_set_theme`      | Переключатель Dark/Light mode.                               |
| `config_set_language`   | Выбор языка интерфейса.                                      |
| `config_set_currency`   | Выбор фиатной валюты для отображения цен (USD, EUR, RUB).    |
| `system_get_logs`       | Экран для гиков/поддержки: просмотр логов ошибок.            |
| `system_export_db`      | Кнопка бэкапа всей базы данных кошелька.                     |
| `wallet_sign_message`   | Инструмент: поле для текста + выбор адреса -> результат подписи. |
| `wallet_verify_message` | Инструмент: проверка валидности чужой подписи.               |



| **Метод / Функция**             | **Описание для UI**         | **Что рисовать в Mockup**                          |
| ------------------------------- | --------------------------- | -------------------------------------------------- |
| `key_manager_create_master_key` | Создание корневого ключа.   | Экран "Setup Wallet" / Генерация фразы.            |
| `key_manager_derive_key`        | Генерация дочернего ключа.  | Процесс создания нового счета/адреса.              |
| `key_manager_get_public_key`    | Получение публичного ключа. | Поле "Public Key" в деталях аккаунта.              |
| `key_manager_get_address`       | Конвертация ключа в адрес.  | Поле "Your Address" + QR-код.                      |
| `key_manager_sign_message`      | Криптографическая подпись.  | Модалка "Sign Message" с полем ввода текста.       |
| `key_manager_verify_signature`  | Проверка подписи.           | Инструмент проверки: ввод текста + подпись + ключ. |
| `key_manager_export_mnemonic`   | Экспорт сид-фразы.          | Экран "Show Recovery Phrase" (с предупреждением).  |
| `key_manager_import_mnemonic`   | Импорт сид-фразы.           | Форма ввода 12/24 слов при восстановлении.         |
