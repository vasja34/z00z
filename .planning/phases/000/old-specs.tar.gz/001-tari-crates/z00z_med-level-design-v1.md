# 1. META

- **system.id:** `z00z_v1`
- **system.kind:** `rollup-chain-bootstrap`
- **system.mode:** `release-spec-system`
- **status:** `release`
- **owner:** `vadim`
- **agents.target:** GitHub Copilot / LLM assistants in IDE

------

# 2. INTENT

Assemble a **minimally working Z00Z v1** as an **MW-like private rollup**:

- Data Availability == DA: **Celestia**
- Execution/consensus: **Sovereign SDK**
- Crypto/UTXO logic: **Tari (as source of primitives)**
- Wallet UX and swaps: **MWC (as reference)**

With constraints:

- Z00Z is **NOT a fork of Tari/MWC**, but a **separate rollup**.
- Everything under `z00z/.temp/` is used **only as source of code and ideas**, not as part of the live workspace.

## High-level architecture: who talks to whom

```mermaid
%% High-level architecture: who talks to whom
flowchart TD;
  subgraph Client;
    W["Wallet & Light SDK"];
  end;

  subgraph Rollup;
    CORE["z00z_core<br/>(coin rules)"];
    CRYPTO["z00z_crypto<br/>(curve25519, commitments, proofs)"];
    RT["z00z_runtime<br/>(Sovereign SDK state machine)"];
    AGG["z00z_aggregator<br/>(batch builder)"];
    NODE["z00z_rollup_node<br/>(daemon)"];
  end;

  subgraph DA;
    C["Celestia DA<br/>(blob storage)"];
  end;

  W -->|build tx using core+crypto| CORE;
  CORE --> CRYPTO;

  W -->|submit tx| AGG;
  AGG -->|batch blob| C;
  NODE -->|read blobs| C;
  NODE -->|apply batches via runtime| RT;
  RT --> CORE;

  %% colors
  style W     fill:#e3f2fd,stroke:#1e88e5,stroke-width:1px,color:#0d47a1;
  style CORE  fill:#f3e5f5,stroke:#8e24aa,stroke-width:1px,color:#4a148c;
  style CRYPTO fill:#e8f5e9,stroke:#2e7d32,stroke-width:1px,color:#1b5e20;
  style RT    fill:#fff3e0,stroke:#ef6c00,stroke-width:1px,color:#e65100;
  style AGG   fill:#ffe0e0,stroke:#d32f2f,stroke-width:1px,color:#b71c1c;
  style NODE  fill:#eceff1,stroke:#546e7a,stroke-width:1px,color:#263238;
  style C     fill:#ede7f6,stroke:#5e35b1,stroke-width:1px,color:#311b92;

```



------

# 3. INPUTS

## 3.1. Local sources (read-only)

```text
z00z/.temp/celestia-node-main
z00z/.temp/mwc713-master
z00z/.temp/mwc-node-master
z00z/.temp/mwc-wallet-master
z00z/.temp/sovereign-sdk-dev
z00z/.temp/tari-development
```

Requirements:

- ❗ **Do NOT modify** anything inside `.temp/`.
- Use them only:
  - as a source of code for copying/adaptation;
  - as architecture/protocol references.
  - all from github repositories:
    https://github.com/tari-project/tari
    https://github.com/celestiaorg/celestia-node
    https://github.com/mwcproject
    https://github.com/Sovereign-Labs/sovereign-sdk

## 3.2. Target repository

Root:

```text
z00z/
  assets/
  config/
  crates/
  data/
  deploy/
  docker/
  docs/
  prompts/
  reports/
  scripts/
  specs/
  website/
```

Special focus: `z00z/crates/` — Rust workspace with core crates (already partially created).

------

# 4. OUTPUT / DONE-DEFINITION

By the end of **v1 bootstrap** the system must have:

1. **Working Z00Z workspace** that:
   - builds with `cargo check` at repo root;
   - successfully passes basic `cargo test --all`.
2. Minimal set of crates:
   - `z00z_crypto` — crypto engine (Curve25519/Ristretto, Pedersen, Bulletproofs, MMR).
   - `z00z_core` — coin rules: UTXO/MW output, tx format, basic validation.
   - `z00z_runtime` — integration with **Sovereign SDK** (rollup state machine).
   - `z00z_da_celestia` — DA adapter to Celestia (HTTP/RPC client).
   - `z00z_rollup_node` — rollup node binary (entry point).
   - `z00z_wallets` — skeleton wallet using `z00z_core` / `z00z_crypto`.
   - `z00z_aggregator` — non-trusted batch builder that collects wallet transactions, forms verifiable batches, and submits them to the DA layer.
   - `storage`, `telemetry`, `protocol_rules` — basic infrastructure (scaffolds already exist).
3. **End-to-end integration test** that:
   - creates a test Z00Z state,
   - forms a simple transaction via `z00z_wallets`,
   - packs it into a batch (via aggregator),
   - “publishes” it into mock Celestia,
   - reads the blob back and applies it in `z00z_runtime`,
   - verifies correct state change (balance/output set).

```mermaid
sequenceDiagram
  participant W as z00z_wallets
  participant AG as z00z_aggregator
  participant DA as z00z_da_celestia
  participant RN as z00z_rollup_node
  participant RT as z00z_runtime

  W->>W: build Z00ZTx using z00z_core + z00z_crypto
  W->>AG: submit_tx(tx)
  AG->>AG: collect txs into batch
  AG->>DA: submit_blob(namespace, batch_bytes)
  DA-->>AG: DaPointer { height, ns, proof }

  RN->>DA: get_blobs(namespace, height)
  DA-->>RN: batch_bytes
  RN->>RT: apply_batch(batch_bytes)
  RT-->>RN: new state (updated outputs)
  W->>RN: (optional) query state / inclusion

```



------

# 5. GLOBAL CONSTRAINTS

1. **No Tari PoW/consensus in Z00Z v1**
   - Do NOT import `minotari` consensus, PoW mining, block format, P2P, Tor.
   - No `tari_comms`, `tari_p2p`, `tari_libtor`, miner or merge-mining.
2. **Celestia + Sovereign = only consensus/DA stack**
   - Blocks / DA → Celestia.
   - State machine / rollup logic → Sovereign SDK.
   - Tari/MWC are used only as:
     - library crypto,
     - reference structures and wallets.
3. **.temp = source only**
   - Any code actually used in Z00Z must live under `z00z/crates/...`.
   - `.temp/*` must NOT appear as dependencies in `Cargo.toml`.

------

# 6. CRATES MAP

## 6.1. z00z_crypto

**Purpose:** single point for cryptographic primitives.

- Folder: `crates/z00z_crypto/`
- Inside:
  - `curve25519/`

**Code source:**

- From `tari-development/tari_crypto`:
  - Ristretto keys, signatures, Pedersen commitments, range proofs (`ristretto/*`, `commitment/*`).
- From `tari_bulletproofs` (or Tari’s `bulletproofs-plus` crate if present in repo):
  - Bulletproof range proofs and helpers.
- From `tari_utilities`:
  - ByteArray, hashing helpers, hex encoding used by the above.
- From `tari_mmr`:
  - MMR implementation

**Copilot task:**

- Vendor necessary `tari_*` parts into `z00z_crypto/curve25519` (keys, commitments, range proofs only).
- Do **NOT** vendor consensus, P2P, wallet, or node code.
- Remove any `tari_*` direct deps from `Cargo.toml` and keep the public API clean.
- Lift unit tests from original crates into `z00z_crypto/tests`.

```mermaid
flowchart TD;
subgraph ZC["z00z_crypto"];
  C25519["curve25519 / Ristretto primitives"];
  COMM["Pedersen commitments"];
  RP["Bulletproof range proofs"];
  MMR["MMR engine"];
end;

subgraph TariSources[".temp/tari-development (read-only)"];
  TCR["tari_crypto"];
  TBP["tari_bulletproofs (+bulletproofs-plus)"];
  TUT["tari_utilities"];
  TMMR["tari_mmr"];
end;

TCR --> C25519;
TCR --> COMM;
TBP --> RP;
TUT --> C25519;
TUT --> COMM;
TUT --> RP;
TMMR --> MMR;

style ZC fill:#e3f2fd,stroke:#1e88e5,stroke-width:1px,color:#0d47a1;
style TariSources fill:#f3e5f5,stroke:#8e24aa,stroke-width:1px,color:#4a148c;

style C25519 fill:#e8f5e9,stroke:#2e7d32,stroke-width:1px,color:#1b5e20;
style COMM   fill:#e8f5e9,stroke:#2e7d32,stroke-width:1px,color:#1b5e20;
style RP     fill:#fff3e0,stroke:#ef6c00,stroke-width:1px,color:#e65100;
style MMR    fill:#fff8e1,stroke:#f9a825,stroke-width:1px,color:#f57f17;

style TCR    fill:#ede7f6,stroke:#5e35b1,stroke-width:1px,color:#311b92;
style TBP    fill:#ede7f6,stroke:#5e35b1,stroke-width:1px,color:#311b92;
style TUT    fill:#ede7f6,stroke:#5e35b1,stroke-width:1px,color:#311b92;
style TMMR   fill:#ede7f6,stroke:#5e35b1,stroke-width:1px,color:#311b92;

```



------

## 6.2. z00z_core

**Purpose:** define the Z00Z coin protocol and local state (UTXO-style coins, kernels, fees, epoch state) **without** consensus, networking or DA. This crate is the “Mimblewimble-like core” for Z00Z.

- Folder: `crates/z00z_core/`

### 6.2.1 Responsibilities

z00z_core MUST provide:
**Idea source:**

- Modules from `tari-development/tari`:
  - `base_layer/core/src/transactions/` (TxInput, TxOutput, Transaction, Kernel)
  - `base_layer/core/src/validation/` (transaction and block validators)
- Only **as reference** — do NOT add `tari_core` as dependency.

1. **Coin & transaction types**
   - Value type (`Z00ZAmount`), asset ID (if needed later), fee type.
   - Output / input / kernel / transaction structs:
     - `Z00ZOutput` — commitment, range proof, features, script / metadata.
     - `Z00ZInput` — reference to a previous output (by commitment / out_id).
     - `Z00ZKernel` — excess, signature, fee, lock_height, extra flags.
     - `Z00ZTx` — { inputs, outputs, kernels, offset }.
   - Batch object for aggregator:
     - `Z00ZBatch` — set of `Z00ZTx` + batch metadata (epoch_id, DA slot, etc.).
2. **State model**
   - In-memory / storage-agnostic types for:
     - `UtxoSet` — map/collection of live `Z00ZOutput`s.
     - `EpochState` — is the canonical on-chain view of which offline coins (coin-ids) are currently spendable or invalidated.
   - APIs to:
     - apply a **single tx** to a state snapshot,
     - apply a **batch of txs** and get a new `EpochStateDelta`,
     - verify that `old_state + delta == new_state`.
4. **Validation rules (no consensus, only local rules)**
   - Single transaction validation:
     - no duplicate inputs,
     - all inputs reference existing UTXOs (or are in “same-batch outputs”),
     - all outputs have valid range proofs,
     - `ΣCin − ΣCout − fee = 0` in Pedersen commitments (hook into `z00z_crypto`),
     - kernel signatures valid,
     - lock_height / timelocks respected (if you keep them in v1).
   - Batch / “block-equivalent” validation:
     - total fee and total supply invariants,
     - no double-use of same output / nullifier inside the batch,
     - batch weight / size constraints (configurable).
5. **No DA, no network, no consensus**
   - This crate **MUST NOT** depend on:
     - Celestia, Sovereign SDK, P2P, Tor, gRPC, etc.
   - It is pure logic that can be called from:
     - `z00z_aggregator`,
     - `z00z_runtime`,
     - test harnesses.

```mermaid
classDiagram
  class Z00ZOutput {
    Commitment commitment
    RangeProof range_proof
    OutputFeatures features
    // script / metadata
  }

  class Z00ZInput {
    Commitment commitment // or OutId
  }

  class Z00ZKernel {
    Commitment excess
    Signature sig
    u64 fee
    u64 lock_height
    Flags flags
  }

  class Z00ZTx {
    Vec<Z00ZInput> inputs
    Vec<Z00ZOutput> outputs
    Vec<Z00ZKernel> kernels
    BlindingFactor offset
  }

  class Z00ZBatch {
    Vec<Z00ZTx> txs
    EpochId epoch_id
    DaSlot da_slot
    BatchMeta batch_meta
  }

  Z00ZTx --> Z00ZInput
  Z00ZTx --> Z00ZOutput
  Z00ZTx --> Z00ZKernel
  Z00ZBatch --> Z00ZTx

```



---

### 6.2.2 Source of ideas / reference mapping

**From Tari**

Use **Tari transaction core** as the primary design reference, but re-implement in your own types:

- Crate: `tari_transaction_components`:
  - has `Transaction`, `TransactionInput`, `TransactionOutput`, `TransactionKernel`,
    plus **validation trait & pipeline** for tx/block checks. 
- RFC for base node validation logic:
  - lists the exact checks: inputs exist in UTXO set, no duplicates, timelocks, range proofs, weight limits, excess signature, etc.   

**What to copy conceptually (NOT as dependency):**

- Structure of:
  - input / output / kernel / transaction types,
  - “excess proves Σ(in − out − fee) = 0” model,
  - separation of “transaction building” vs “validation rules”.
- Pattern of a **validation pipeline**:
  - multiple small validators chained together.

You can tell Copilot explicitly:

- Look at `tari_transaction_components` for:
  - how Tx structs and their ser/de are organized,
  
  - how validation traits & pipelines are structured,
  
  - but **DO NOT** import Tari crates — replicate the shape with `z00z_` names.
  
    

**From MWC**

MWC **is used only as a stylistic reference for file layout and helper APIs, not as a source of consensus rules or emission schedule**.:

- building a tx from inputs / outputs / kernel,
- verifying the MW balance equation and range proofs.

Again: **reference only**, no direct dependency.

---

### 6.2.3 Concrete Copilot tasks for z00z_core

When you tell Copilot what to do in this crate, be explicit:

1. **Define core types**

   - In `crates/z00z_core/src/assets/coins.rs`:
     - `pub type Z00ZAmount = u64;`
     - `pub struct Z00ZOutput { commitment: Commitment, range_proof: RangeProof, features: OutputFeatures, /* script/metadata */ }`
     - `pub struct Z00ZInput { commitment: Commitment /* or OutId */ }`
   - In `crates/z00z_core/src/tx.rs` (or `transactions/mod.rs`):
     - `Z00ZKernel` (excess, sig, fee, lock_height, flags).
     - `Z00ZTx` { inputs: Vec<Z00ZInput>, outputs: Vec<Z00ZOutput>, kernels: Vec<Z00ZKernel>, offset: BlindingFactor }.
     - `Z00ZBatch` { txs: Vec<Z00ZTx>, epoch_id, da_slot, batch_meta }.

   **Reference**: Tari’s transaction component structs (shapes and naming).   

2. **Plug into z00z_crypto**

   - Use `z00z_crypto` for:
     - Pedersen commitments: `C = v·G + r·H`,
     - range proofs,
     - excess sig verification.
   - Implement helper fns:
     - `fn verify_commitment_balance(tx: &Z00ZTx) -> Result<()>`:
       - check `ΣCin − ΣCout − fee = 0` in commitment space.
     - `fn verify_range_proofs(tx: &Z00ZTx) -> Result<()>`.

3. **State representation**

   - In `crates/z00z_core/src/state/mod.rs`:
     - `struct UtxoSet` — ideally as trait over generic storage, but start with in-memory map keyed by commitment.
     - `struct EpochState { epoch_id, utxo_root, spent_root/nullifier_root, total_supply, /* counters */ }`.
     - `struct EpochDelta { removed_utxos, added_utxos, new_roots }`.

   - Provide APIs:
     - `fn apply_tx(state: &mut EpochState, tx: &Z00ZTx) -> Result<()>`.
     - `fn apply_batch(state: &mut EpochState, batch: &Z00ZBatch) -> Result<EpochDelta>`.

   **Reference**: Tari RFC base node requirements for maintaining UTXO set and validating txs/blocks.   

4. **Genesis implementation**

   - In `crates/z00z_core/src/genesis.rs`:

     ```rust
     pub const GENESIS_NUM_COINS: u64 = 50_000;
     pub const GENESIS_COIN_NOMINAL: Z00ZAmount = 200_000;

     pub fn build_genesis_state() -> EpochState { ... }
     ```

   - Build `GENESIS_NUM_COINS` outputs with identical nominal value and distinct commitments.
   - Ensure `total_supply = GENESIS_NUM_COINS * GENESIS_COIN_NOMINAL`.

5. **Validation logic**

   - In `crates/z00z_core/src/validation.rs`:

     - Define traits:

       ```rust
       pub trait TxValidator {
           fn validate(&self, tx: &Z00ZTx, state: &EpochState) -> Result<()>;
       }
       pub struct ValidationPipeline { validators: Vec<Box<dyn TxValidator>>; }
       ```

     - Implement concrete validators:
       - `InputsExistValidator`
       - `NoDuplicateInputsValidator`
       - `RangeProofValidator`
       - `BalanceValidator`
       - `KernelSignatureValidator`
       - `WeightLimitValidator`

   - Later you can reuse the same pattern for batch / “block” validation.

   **Reference**: Tari transaction validation pipeline in `tari_transaction_components::validation`.   

6. **Tests**

   - In `crates/z00z_core/tests/basic_flow.rs`:

     - `genesis_state → first_spend (payment + change) → verify balance invariants`:
       - pick one genesis coin as input;
       - create tx: `input → payment_output + change_output + kernel(fee)`;
       - apply to `EpochState`;
       - assert:
         - total commitments balance,
         - `total_supply` unchanged,
         - UtxoSet: input removed, outputs added.

   - Add property tests later (not mandatory for v1 spec, but recommended):
     - random txs that preserve supply,
     - failure cases: duplicate inputs, bad range proofs, wrong fee, etc.

```mermaid
flowchart TD;
S0["EpochState (before)"];
TX["Z00ZTx"];
BATCH["Z00ZBatch"];
D["EpochDelta"];
S1["EpochState (after)"];

S0 -->|apply_tx| TX;
TX --> D;
D --> S1;

S0 -->|apply_batch| BATCH;
BATCH --> D;

```



------

### 6.2.4. Offline Coin Model

**Purpose:** encode Z00Z as an offline-first e-cash system, not just an online MW UTXO set.

**Write basic tests using genesis coins:**

- start from the fixed **genesis state** (50,000 coins × 200,000 Z00Z),
- take **one genesis coin** as input,
- build a tx: `genesis_coin → payment_output + change_output`,
- verify balance invariants:
  - Pedersen commitments match,
  - the nominal amount is conserved,
  - **total supply remains 50,000 × 200,000 Z00Z**.



### **Functional requirements (FR):**

- **FR-OFF-01:** A Z00Z coin MUST have an **offline representation** (file/struct) that can be held entirely off-chain by a device, without requiring continuous network access.
- **FR-OFF-02:** Spending a coin offline MUST be modeled as **re-signing ownership** from party A to party B, using `z00z_crypto` keys, without immediate interaction with Celestia or the rollup node.
- **FR-OFF-03:** The **canonical on-chain state** in `z00z_core::state` MUST track only:
  - which coin-ids (or note-ids) are currently considered spendable, and
  - which ones have been invalidated (spent, revoked, or detected as double-spent) once any party reconnects and publishes their view.
- **FR-OFF-04:** Double-spend prevention is **eventual**:
  - detection and resolution occur only when at least one participant (payer, payee, or auditor/aggregator) connects and submits its view of the coin spend(s) to the rollup;
  - runtime MUST provide a way to mark coins and/or wallets as slashed/invalid once a conflicting spend is detected.
- **FR-OFF-05:** The **offline representation format** of a coin (whether file, record, or bundle) MUST be defined in `z00z_core` types and used consistently by `z00z_wallets` for:
  - local storage,
  - offline transfer between devices,
  - later conversion into a transaction/batch suitable for publishing via aggregator + DA.

```mermaid
sequenceDiagram
  participant A as Wallet A (offline)
  participant B as Wallet B (offline)
  participant AG as z00z_aggregator
  participant RT as z00z_runtime

  A->>B: transfer coin file. (re-sign ownership)
  Note over A,B: Pure offline handover. no Celestia / DA

  B->>AG: submit_spend(coin_file) - when back online
  AG->>RT: include in Z00ZBatch
  RT-->>RT: validate with z00z_core rules - (no double spend, balance check)

```



### **Responsibilities split:**

#### ==z00z_CORE:==

**1. Recommended layering**

Think in layers:

```text
z00z_crypto         # math, commitments, proofs
   ↑
z00z_core           # coins, tokens, nfts, void, state, validation
   ↑
extensions/genesis  # how we build initial state from those types
extensions/treasury # how treasury moves value, burns, rewards, etc.
   ↑
runtime / node / wallet / aggregator
```

**Key rule:**
 `genesis` and `treasury` **depend on** `z00z_core`, but `z00z_core` must NOT depend on them.

**2. z00z_core/assets/***

All base asset types (coins, tokens, NFTs, void) are defined only in `z00z_core::assets::*`; extensions (genesis, treasury) MUST reuse these types and MUST NOT introduce parallel asset definitions.

- `coins.rs`
   The **main Z00Z coin** (your 50,000 × 200,000 Z00Z genesis units):
  - `Z00ZCoinOutput`, `Z00ZCoinFeatures`, etc.
  - used by *everything*: genesis, treasury, runtime, wallet.
- `tokens.rs`
   Fungible tokens on top of Z00Z (optional in v1, but the place is correct):
  - `Z00ZTokenId`, `Z00ZTokenOutput`.
  - treasury can later use this for governance / reward tokens.
- `nfts.rs`
   Non-fungible assets:
  - `Z00ZNftId`, `Z00ZNftOutput`.
  - not critical for v1, but the separation is fine.
- `void.rs`
   “Black hole” / burn sink:
  - a special asset/feature marking outputs as **irreversibly burned**.
  - treasury can send buyback coins here.

All of these live in **one crate**: `z00z_core`, as modules under `assets/`.

------

**3. extensions/genesis**

Path: `z00z/crates/extensions/genesis` → crate name e.g. `z00z_genesis`.

What it does:

- Depends on: `z00z_core` (especially `assets::coins`).
- Provides:
  - constants for supply (50_000, 200_000, etc.),
  - `build_genesis_state()` that:
    - creates 50,000 `Z00ZCoinOutput`s,
    - returns an initial `EpochState` (`z00z_core::state`).

What it must **not** do:

- No own coin types.
- No crypto primitives (take all from `z00z_core` + `z00z_crypto`).

------

**4. extensions/treasury**

Path: `z00z/crates/extensions/treasury` → crate name e.g. `z00z_treasury`.

What it does:

- Depends on: `z00z_core` (coins, tokens, void) and maybe `z00z_crypto`.
- Implements **policies**:
  - reward distribution,
  - buyback/burn (sending to `void`),
  - stability / incentives logic you described earlier.

What it must **not** do:

- Define new base coin formats (use `assets::coins`).
- Change core validation rules (those stay in `z00z_core`).

------

**5. Should you “re-format” them?**

Structurally you’re fine, just follow this:

1. Make each extension a **separate crate** with clear names:

   - `crates/extensions/genesis` → Cargo.toml with `name = "z00z_genesis"`.
   - `crates/extensions/treasury` → `name = "z00z_treasury"`.

2. Keep **all asset types** in `z00z_core/assets/*.rs`.

3. In `z00z_genesis` and `z00z_treasury`, only **import** those types:

   ```rust
   use z00z_core::assets::coins::Z00ZCoinOutput;
   use z00z_core::assets::void::VoidOutput;
   ```

If you stick to “core = types & rules, extensions = policies built on top”, the interaction will be clean and Copilot will understand which crate owns what.

---



#### ==z00z_WALLETS==

- owns the **offline coin lifecycle**:
  - creation of coin files/records,
  - local handover from A to B,
  - accumulation of offline history needed to construct a valid on-chain transaction.
- MUST be capable of constructing a transaction/batch that reflects the latest offline owner while encoding only the information required by `z00z_core` and the privacy model.

Tests (to be implemented in later phases):

- Wallet-level tests that:
  - move a coin between two offline “owners” without touching DA or runtime,
  - serialize the final spend into a transaction accepted by `z00z_core` validation.
- Integration tests (wallet + runtime) that:
  - submit two conflicting spends of the same offline coin and verify that:
    - runtime rejects or slashes according to the defined policy,
    - the canonical state no longer treats that coin as spendable.

**Idea source:**

- `z00z/.temp/mwc-wallet-master` (official MWC wallet)
- `z00z/.temp/mwc713-master` (legacy CLI wallet / state machine)
- Use **only wallet-side code and docs**:
  - wallet DB / state,
  - transaction building flows,
  - offline/online round trips.
- Do **NOT** use `mwc-node` consensus or libtx — protocol rules come from Tari-inspired `z00z_core`.



```mermaid
flowchart TD
  CRYPTO["z00z_crypto<br/>math, commitments, proofs"]
  CORE["z00z_core<br/>coins, tokens, nfts, void<br/>state, validation"]
  GEN["z00z_genesis<br/>initial state builder"]
  TRE["z00z_treasury<br/>policies, rewards, burns"]
  RT["z00z_runtime<br/>Sovereign SDK integration"]
  W["z00z_wallets<br/>offline coin lifecycle"]
  AGG["z00z_aggregator<br/>batch builder"]

  CRYPTO --> CORE
  CORE --> GEN
  CORE --> TRE
  CORE --> RT
  CORE --> W
  W --> AGG
  RT --> AGG

  style CRYPTO fill:#e3f2fd,stroke:#1e88e5,stroke-width:1px,color:#0d47a1
  style CORE   fill:#f3e5f5,stroke:#8e24aa,stroke-width:1px,color:#4a148c
  style GEN    fill:#e8f5e9,stroke:#2e7d32,stroke-width:1px,color:#1b5e20
  style TRE    fill:#e8f5e9,stroke:#2e7d32,stroke-width:1px,color:#1b5e20
  style RT     fill:#fff3e0,stroke:#ef6c00,stroke-width:1px,color:#e65100
  style W      fill:#eceff1,stroke:#546e7a,stroke-width:1px,color:#263238
  style AGG    fill:#ffe0e0,stroke:#d32f2f,stroke-width:1px,color:#b71c1c

```



------

## 6.3. z00z_runtime (Sovereign SDK)

**Purpose:** Z00Z rollup state machine on top of Sovereign.

- Folder: `crates/z00z_runtime/`
- Dependencies:
  - `sovereign-sdk` (as `[patch]` or `[dependencies]` with `path = "../.temp/sovereign-sdk-dev"` in the workspace `Cargo.toml`)
  - `z00z_core`
  - `z00z_crypto`
  - `storage`

**Copilot task:**

1. Define main state type, e.g.:

   ```rust
   pub struct Z00ZState {
       // active coins/outputs
       // indexes/nullifier sets
       // service data
   }
   ```

2. Implement Sovereign SDK traits for:

   - applying batches of Z00Z transactions,
   - serializing/deserializing state.

3. Write tests:

   - initialize empty state,
   - apply simple batch (genesis → transfer),
   - verify state correctness.

------

## 6.4. z00z_da_celestia

**Purpose:** DA adapter for accessing Celestia via RPC/HTTP.

- Folder: `crates/z00z_da_celestia/`
- Inside:
  - `src/lib.rs` — client implementation.
  - `celestia.md` — stays as doc; can be extended.

**Target interface:**

```rust
pub struct CelestiaDaLayer { /* http client + config */ }

impl CelestiaDaLayer {
    pub async fn submit_blob(&self, namespace: &[u8], data: &[u8]) -> Result<DaPointer, Error>;

    pub async fn get_blobs(&self, namespace: &[u8], height: u64)
        -> Result<Vec<Vec<u8>>, Error>;
}
```

**Information source:**

- HTTP/RPC spec from `z00z/.temp/celestia-node-main` (light-node / blob RPCs).
- Do NOT depend on `celestia-app` or Cosmos SDK — Z00Z only needs the DA client API.

**Copilot task:**

- Implement HTTP client (using whichever async stack is already used).
- Create mock implementation/feature for tests (no real network).
- Write unit tests with mock transport.

```mermaid
sequenceDiagram
  participant AG as z00z_aggregator
  participant DA as CelestiaDaLayer
  participant CN as celestia-node

  AG->>DA: submit_blob(namespace, batch_bytes)
  DA->>CN: HTTP: /blob/submit\n(namespace, data)
  CN-->>DA: {height, nmt_root, nmt_proof}
  DA-->>AG: DaPointer { height, namespace, proof }

```



------

## 6.5. z00z_rollup_node

**Purpose:** Z00Z rollup node binary.

- Folder: `crates/z00z_rollup_node/`
- File: `src/main.rs`

**Responsibilities:**

1. Load config (from `config/` or env).
2. Initialize:
   - `CelestiaDaLayer`,
   - `Z00ZState` + runtime,
   - storage backend.
3. Event loop:
   - poll Celestia for new blobs,
   - apply batches to state,
   - periodically publish new batches (once aggregator is there).

**Copilot task:**

- Implement minimal but compilable `main`.
- For v1 to have a loop with real Celestia.

------

## 6.6. z00z_wallets

**Purpose:** offline-oriented Z00Z wallet (v1 skeleton).

- Folder: `crates/z00z_wallets/`

**Idea source:**

- `z00z/.temp/mwc-wallet-master`
- `z00z/.temp/mwc713-master`

**Copilot task:**

- Do **not** copy 1:1, but:
  - inspect how they organize:
    - wallet state storage (`wallet/src/lib.rs`, db modules),
    - swap/transaction state machine (slate-style flows),
    - offline-signed transactions and file-based transfer.
  - Implement in Z00Z:
    - key generation on top of `z00z_crypto`,
    - local representation of coins (file/struct, Z00Z UTXO model),
    - creation of basic transactions compatible with `z00z_core` (no broadcast, only “export to file/QR”).

- Write tests:
  - create wallet (seed + key),
  - create coin,
  - build transaction and serialize it for aggregator.

------

## 6.7. Privacy Model

**Purpose:** ensure Z00Z privacy is **no worse than baseline MW**, taking into account Celestia DA and aggregators.

**Goals:**

- **G1-PRIV-BASELINE:** An external observer, seeing only Celestia blobs and public on-chain data, MUST NOT be able to link inputs ↔ outputs of a given user better than a generic MimbleWimble-style adversary with similar information.
- **G2-PRIV-AGGREGATOR:** Aggregators MAY see some transaction metadata but MUST:
  - fully aggregate and randomize transaction order before publishing to DA, and/or
  - use obfuscation techniques (padding, randomized dummy entries, shuffled grouping) so that the on-chain batch is not trivially traceable back to individual users.
- **G3-PRIV-WALLET:** Wallets MUST avoid including:
  - stable user identifiers,
  - long-lived device IDs,
  - or deterministic hints that can link multiple transactions from the same user,
     in any data that ends up in DA blobs or `z00z_core` state.
- **G4-PRIV-NON-GOALS (v1):**
  - v1 does NOT require ring signatures, Seraphis, Lelantus, or similar heavy-weight constructs;
  - v1 privacy relies on:
    - Pedersen commitments,
    - Bulletproofs,
    - transaction aggregation/mixing by the aggregator,
    - and avoidance of explicit identifiers.

**Static constraints:**

- On-chain structures defined in `z00z_core` MUST:
  - store commitments, ranges, and minimal metadata needed for validation,
  - MUST NOT store cleartext addresses, usernames, or stable correlation keys.
- Aggregator implementation MUST:
  - treat each batch as a **mixing opportunity** (reordering, grouping),
  - avoid one-tx-per-blob patterns that trivially deanonymize flows.

**Tests and checks (high-level):**

- Code review checklist:
  - any new field added to on-chain structures MUST be checked for privacy impact against this section.
- Unit / property tests:
  - simulate aggregator mixing N transactions and verify that:
    - final encoded batch order differs from input order,
    - per-user transaction patterns are not directly preserved in serialisation (e.g. no “all Alice txs first”).

------

## 6.8. z00z_aggregator

**Purpose:** define the role and **untrusted** aggregator trust model for DA batches for Z00Z. 

**Functional requirements (FR):**

- **FR-AGG-01:** An aggregator receives transaction bundles (or coin-spend intents) from wallets/offline devices and forms **provable batches** that can be verified by `z00z_runtime` using `z00z_core` rules and `z00z_crypto` proofs.
- **FR-AGG-02:** The protocol MUST allow:
  - either multiple aggregators to coexist, publishing batches independently, or
  - a clearly documented assumption of a “canonical” aggregator in v1,
     but in all cases the verifier nodes MUST be able to:
  - reconstruct state purely from DA (Celestia blobs) and runtime logic,
  - without trusting any aggregator’s off-chain state.
- **FR-AGG-03:** Wallets MUST be able to verify that:
  - their transaction/coin-spend was included in some DA batch,
  - or detect non-inclusion/censorship and retry or choose another aggregator.
     This can be done by:
  - querying DA directly (light client / RPC),
  - or via an inclusion proof API exposed by aggregators/verifier nodes.

**Trust model:**

- Aggregators MAY:
  - censor or delay specific users’ transactions,
  - choose which transactions to include in each batch.
- Aggregators MUST NOT be able to:
  - forge valid state transitions (due to cryptographic proofs checked by `z00z_runtime`),
  - silently alter balances or create coins ex nihilo.
- Misbehaviour detection:
  - any node that can read Celestia DA and run `z00z_runtime` can independently:
    - verify batches,
    - detect malformed or invalid batches,
    - reconstruct final state.
  - If a wallet sees its tx absent from DA after expected time/rounds, it can treat this as censorship and:
    - resubmit to another aggregator,
    - or escalate (out of scope for v1).

**Copilot / implementation hints:**

- `z00z_aggregator` crate (future) SHOULD:
  - define a simple API surface:
    - `submit_tx(tx) -> TxId`,
    - `build_batch() -> BlobPayload`,
    - `list_inclusions(wallet_id / coin_id) -> Vec<InclusionProof>`.
  - integrate with `z00z_da_celestia` for publishing batches.
- Integration tests SHOULD:
  - construct a batch via aggregator,
  - verify it via runtime,
  - replay the same batch using a separate “verifier node” from DA and confirm identical resulting state.

```mermaid
flowchart LR
  classDef wallet  fill:#e3f2fd,stroke:#1e88e5,stroke-width:1px,color:#0d47a1;
  classDef agg     fill:#f3e5f5,stroke:#8e24aa,stroke-width:1px,color:#4a148c;
  classDef da      fill:#e8f5e9,stroke:#2e7d32,stroke-width:1px,color:#1b5e20;
  classDef node    fill:#fff3e0,stroke:#ef6c00,stroke-width:1px,color:#e65100;
  classDef client  fill:#eceff1,stroke:#546e7a,stroke-width:1px,color:#263238;

  W[Wallet / offline device]
  AGG[z00z_aggregator]
  DA["Celestia DA<br/>(z00z_da_celestia)"]
  NODE["z00z_rollup_node<br/>+ z00z_runtime"]
  LC[Light / verification client]

  class W wallet
  class AGG agg
  class DA da
  class NODE node
  class LC client

  W -->|submit tx| AGG
  AGG -->|build batch| AGG
  AGG -->|submit blob| DA
  NODE -->|poll blobs| DA
  NODE -->|apply batch| NODE
  W -->|check inclusion| LC
  LC --> NODE

```



------

# 7. PHASED PLAN (FOR COPILOT)

## Phase 1 — z00z_crypto bootstrap

- Vendor needed parts of `tari_crypto`, `tari_bulletproofs`, `tari_utilities`, `tari_mmr` into `z00z_crypto/curve25519`.
- Adapt module/type names to `z00z_…` or generic equivalents.
- Port/create unit tests based on original tests.
- Ensure `cargo test -p z00z_crypto` is green.

## Phase 2 — z00z_core protocol

- Define coin/tx types in `z00z_core/assets` and `z00z_core/state`.
- Integrate Pedersen + Bulletproofs from `z00z_crypto`.
- Implement basic validation rules (balance/fee).
- Add unit tests (genesis_state → first_spend (payment + change)).
- Add **negative tests**:
  - transactions with incorrect sum of commitments or invalid Bulletproofs MUST fail validation and MUST NOT update state.

## Phase 3 — Sovereign runtime

- Add `sovereign-sdk` as git/path dependency.
- Implement `Z00ZState` and runtime satisfying SDK interfaces.
- Add tests with dummy batches.
- Add **negative tests**:
  - batches containing at least one invalid transaction/proof MUST be rejected by runtime,
  - runtime MUST NOT update state when batch verification fails.
  - Pin the sovereign-sdk commit hash in workspace Cargo.toml so builds are reproducible.

## Phase 4 — Celestia DA adapter

- From `celestia-node-main` derive RPC endpoints for blobs.
- Implement `CelestiaDaLayer` (submit/get).
- Add mock + tests.

## Phase 5 — Rollup node binary

- Wire `z00z_rollup_node` from `z00z_runtime` + `z00z_da_celestia` + storage.
- Implement simple loop (even with mock DA at first).
- Ensure build with `cargo build -p z00z_rollup_node`.

## Phase 6 — Wallet skeleton

- Integrate `z00z_crypto` / `z00z_core` into `z00z_wallets`.
- Use MWC state-machine ideas adapted to Z00Z.
- Add tests: wallet → coin → tx.

## Phase 7 — E2E tests

- Create `tests/e2e_dummy_chain.rs` in repo root.
- Use:
  - in-memory storage,
  - mock Celestia,
  - Z00Z runtime,
  - wallet.
- Run scenario:
  - create coin → build tx → pack into batch → “publish” → apply → verify state.
- Add **adversarial scenarios**:
  - intentionally corrupted DA blob MUST be detected and MUST NOT lead to state changes,
  - conflicting offline spends of the same coin (if both are eventually submitted) MUST trigger the defined conflict/double-spend resolution behaviour in runtime.

```mermaid
flowchart LR
  P1[Phase 1
  z00z_crypto]
  P2[Phase 2
  z00z_core]
  P3[Phase 3
  z00z_runtime]
  P4[Phase 4
  z00z_da_celestia]
  P5[Phase 5
  z00z_rollup_node]
  P6[Phase 6
  z00z_wallets]
  P7[Phase 7
  E2E tests]

  P1 --> P2 --> P3 --> P4 --> P5 --> P6 --> P7

```



------

# 8. NON-GOALS (OUT OF SCOPE V1)

- Full network architecture of nodes (P2P, Tor, gossip).
- Production wallets with GUI.
- Full port of all Tari/MWC code.
- Complex smart contracts and DAO mechanics.
- Any PoW/mining technologies.

------

# 9. NFRs (v1)

**Purpose:** define minimal non-functional requirements so that v1 implementation is not “toy-level” and can be performance-tested.

- **NFR-PERF-01 (Runtime throughput):**
   In a local benchmark on a documented reference dev machine (specs recorded in `reports/perf.md`), the Z00Z runtime SHOULD handle at least `TXS_PER_SEC_BASELINE` transactions per second with `OUTPUTS_PER_TX_BASELINE` outputs per transaction.
  - These baseline constants MUST be defined and used in the corresponding perf tests/benchmarks.
- **NFR-LAT-01 (DA publish latency):**
   On a local Celestia devnet, the DA adapter MUST be able to publish a blob of size up to **256 KB** within `PUBLISH_LATENCY_TARGET_SEC` seconds under normal conditions.
  - The target value MUST be documented and enforced via an automated test or benchmark.
- **NFR-MEM-01 (Rollup node memory footprint):**
   During the basic E2E test (Phase 7 scenario), the rollup node’s steady-state RAM usage SHOULD remain below `ROLLUP_NODE_RAM_LIMIT_MB` megabytes on the reference dev machine.
- **NFR-OBS-01 (Observability):**
   The system SHOULD expose basic metrics (e.g., processed tx/s, failed batch count, DA publish failures) via `telemetry` so that:
  - performance tests can assert NFR compliance,
  - regressions can be detected between versions.
- **NFR-CONFIG-01 (Configurability):**
   All NFR thresholds (`TXS_PER_SEC_BASELINE`, `OUTPUTS_PER_TX_BASELINE`, `PUBLISH_LATENCY_TARGET_SEC`, `ROLLUP_NODE_RAM_LIMIT_MB`) MUST be:
  - defined in a single configuration/doc location (e.g., `specs/nfr-baselines.md`),
  - referenced by tests/benchmarks,
  - adjustable without code changes to the core protocol logic.

```mermaid
flowchart LR
  C["Celestia: anchor
  (epoch, roots)"]
  N["NMT proof
  (namespace)"]
  LC["Light Client
  (in wallet)"]
  V["Verify proofs
  (roots, state)"]
  ST["Update local
  wallet state"]

  C --> N --> LC --> V --> ST

```



------

